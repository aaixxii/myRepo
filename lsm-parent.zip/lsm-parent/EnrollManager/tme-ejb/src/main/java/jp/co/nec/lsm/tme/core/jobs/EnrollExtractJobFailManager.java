package jp.co.nec.lsm.tme.core.jobs;

import java.util.Date;
import java.util.concurrent.ConcurrentLinkedQueue;

import jp.co.nec.lsm.tm.common.log.BatchJobStatusLogger;
import jp.co.nec.lsm.tm.common.log.InfoLogger;
import jp.co.nec.lsm.tm.common.log.LogConstants;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollBatchJobStatus;
import jp.co.nec.lsm.tme.common.constants.EnrollConstants;
import jp.co.nec.lsm.tme.common.constants.ExtractJobFailedReason;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author zhulk <br>
 * 
 */
public class EnrollExtractJobFailManager {

	private static Logger log = LoggerFactory
			.getLogger(EnrollExtractJobFailManager.class);

	/**
	 * change Extract Job information by Time out
	 * 
	 * @param extractJobTimeout
	 * @param maxExtractFailure
	 * @param now
	 * @return
	 */
	public void checkExtractJobByTime(Integer extractJobTimeout,
			Integer maxExtractFailure, long now) {
		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		ConcurrentLinkedQueue<LocalEnrollBatchJob> enrollLinkQueue = queueManage
				.getEnrollLinkQueue();

		printLogMessage("loop to find extract job exit by time to retry.");

		// loop local enroll queue to find extract job exit by muId to retry.
		for (LocalEnrollBatchJob batchJob : enrollLinkQueue) {
			// if enroll batch Job's status is not EXTRACTING,
			// continue loop
			if (!(batchJob.isBatchJobStatus(EnrollBatchJobStatus.EXTRACTING))) {
				continue;
			}

			printLogMessage("loop to find extract job exit by time to retry...");

			synchronized (batchJob) {
				// loop extract jobs of batchJob to find extract job exit by
				// time to retry.
				for (int jobId = EnrollConstants.EXTRACT_JOB_START_INDEX; jobId <= batchJob
						.getExtractJobCount(); jobId++) {
					LocalExtractJobInfo extractJobinfo = batchJob
							.getExtractJobInfo(jobId);
					// check extract job's Status.
					if (!(extractJobinfo != null && extractJobinfo
							.isStatus(LocalExtractJobStatus.EXTRACTING))) {
						continue;
					}
					// check extract start time
					long extractTime = extractJobinfo.getExtractStartTS()
							.getTime();
					if (now - extractTime < extractJobTimeout) {
						continue;
					}
					// make Extract Job fail
					failExtractJob(batchJob, extractJobinfo, new Date(now),
							maxExtractFailure,
							ExtractJobFailedReason.JOB_TIMEOUT);

				}
			}
		} // for (LocalEnrollBatchJob batchJob : enrollLinkQueue)
	}

	/**
	 * 
	 * @param gmvId
	 * @param maxExtractFailure
	 * @param now
	 */
	public void checkExtractJobByMFEId(long gmvId, Integer maxExtractFailure,
			Date now, ExtractJobFailedReason reason) {
		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		ConcurrentLinkedQueue<LocalEnrollBatchJob> enrollLinkQueue = queueManage
				.getEnrollLinkQueue();

		printLogMessage("loop to find extract job exit by muId to retry.");

		// loop local enroll queue to find extract job exit by muId to retry.
		for (LocalEnrollBatchJob batchJob : enrollLinkQueue) {
			// if enroll batch Job's status is not EXTRACTING,
			// continue loop
			if (!(batchJob.isBatchJobStatus(EnrollBatchJobStatus.EXTRACTING))) {
				continue;
			}

			printLogMessage("loop to find extract job exit by muId to retry...");

			synchronized (batchJob) {
				// loop extract jobs of batchJob to find extract job exit by
				// muId to retry.
				for (int jobId = EnrollConstants.EXTRACT_JOB_START_INDEX; jobId <= batchJob
						.getExtractJobCount(); jobId++) {
					LocalExtractJobInfo extractJobinfo = batchJob
							.getExtractJobInfo(jobId);
					// check extract job's Status.
					if (!(extractJobinfo != null && extractJobinfo
							.isStatus(LocalExtractJobStatus.EXTRACTING))) {
						continue;
					}
					// check gmvId
					if (gmvId != extractJobinfo.getMUId()) {
						continue;
					}
					// make Extract Job fail
					failExtractJob(batchJob, extractJobinfo, now,
							maxExtractFailure, reason);
				}
			}
		} // for (LocalEnrollBatchJob batchJob : enrollLinkQueue)
	}

	/**
	 * Process when Extract Job fail
	 * 
	 * @param batchJob
	 * @param extractJobinfo
	 * @return
	 */
	public void failExtractJob(LocalEnrollBatchJob batchJob,
			LocalExtractJobInfo extractJobinfo, Date now,
			Integer maxExtractFailure, ExtractJobFailedReason reason) {
		long batchJobId = batchJob.getBatchJobId();

		// check failCount.
		// if failCount < maxExtractFailure, retry.
		// else make extract job done
		int failCount = extractJobinfo.getFailureCount();
		if (failCount + 1 < maxExtractFailure) {
			// retry Extract Job
			retryExtractJob(failCount, batchJob, extractJobinfo, reason);

			printLogMessage(
					"extract jobs: {} of batch job: {} is timeout and retried.",
					extractJobinfo.getJobId(), batchJobId);

		} else {
			// make extract job done
			doneEctractJob(failCount, batchJob, extractJobinfo, now);
			log.warn("extract job: {} of batch job: {} is over retry times, make it done with failure.",
					extractJobinfo.getJobId(), batchJobId);	
//			printLogMessage("extract job: {} of batch job: {} is completed.",
//					extractJobinfo.getJobId(), batchJobId);

		}

	}

	/**
	 * make extract job done
	 * 
	 * @param failCount
	 * @param batchJob
	 * @param extractJobinfo
	 */
	private void retryExtractJob(int failCount, LocalEnrollBatchJob batchJob,
			LocalExtractJobInfo extractJobinfo, ExtractJobFailedReason reason) {
		if (reason == ExtractJobFailedReason.JOB_TIMEOUT) {
			log.warn(InfoLogger.retryJobInfo("Detail", "extract jobs: "
					+ extractJobinfo.getJobId() + " of batch job: "
					+ batchJob.getBatchJobId() + " assigned to MFE: "
					+ extractJobinfo.getMUId()
					+ " is retried (reason: extract job timeout)."));
		} else if (reason == ExtractJobFailedReason.MFE_TIMEOUT) {
			log.warn(InfoLogger.retryJobInfo("Detail", "extract jobs: "
					+ extractJobinfo.getJobId() + " of batch job: "
					+ batchJob.getBatchJobId() + " assigned to MFE: "
					+ extractJobinfo.getMUId() + " is retried (reason: "
					+ "mFE timeout before extract job has been done)."));
		} else if (reason == ExtractJobFailedReason.MFE_EXIT) {
			log.warn(InfoLogger.retryJobInfo("Detail", "extract jobs: "
					+ extractJobinfo.getJobId() + " of batch job: "
					+ batchJob.getBatchJobId() + " assigned to MFE: "
					+ extractJobinfo.getMUId() + " is retried (reason: "
					+ "mFE exited before extract job has been done)."));
		} else if (reason == ExtractJobFailedReason.MFE_REENTER) {
			log.warn(InfoLogger.retryJobInfo("Detail", "extract jobs: "
					+ extractJobinfo.getJobId() + " of batch job: "
					+ batchJob.getBatchJobId() + " assigned to MFE: "
					+ extractJobinfo.getMUId() + " is retried (reason: "
					+ "mFE reEntered  before extract job has been done)."));
		}

		// change batch Job information
		batchJob.retryExtractJob(extractJobinfo);

		if (batchJob.isNoExtrctJobAssigned()) {
			batchJob.setBatchJobStatus(EnrollBatchJobStatus.QUEUED);
			if (log.isInfoEnabled()) {
				BatchJobStatusLogger.outputBatchJobStatus(
						LogConstants.STATUS_CATEGORY_TME, batchJob
								.getBatchJobId(), EnrollBatchJobStatus.QUEUED
								.name());

			}
		}
	}

	/**
	 * 
	 * @param failCount
	 * @param batchJob
	 * @param extractJobinfo
	 * @return
	 */
	private void doneEctractJob(int failCount, LocalEnrollBatchJob batchJob,
			LocalExtractJobInfo extractJobinfo, Date now) {

		batchJob.doneExtractJobByInternalError(extractJobinfo, now);

	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 *            ,logParame
	 * @return
	 */
	private void printLogMessage(String logMessage, Object... objects) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage, objects);
		}
	}

}
