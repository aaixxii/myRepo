package jp.co.nec.lsm.tme.timer;

public interface EnrollBatchJobGetterPollLocal {
	void poll();
}
