package jp.co.nec.lsm.tme.timer;

import java.util.Collection;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.Timeout;
import javax.ejb.Timer;
import javax.ejb.TimerService;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import jp.co.nec.lsm.tm.common.constants.JNDIConstants;
import jp.co.nec.lsm.tm.common.util.ServiceLocator;
import jp.co.nec.lsm.tme.sessionbeans.api.EnrollHeartbeatStarterLocal;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class EnrollHeartbeatStarterBean implements EnrollHeartbeatStarterLocal {

	private static Logger log = LoggerFactory
			.getLogger(EnrollHeartbeatStarterBean.class);
	@Resource
	TimerService timerService;

	EnrollHeartbeatPollLocal pollBean;

	@PostConstruct
	public void init() {
		printLogMessage("CNTR: EnrollBatchJobHeartbeatStarterBean init");
	}

	/**
	 * constructor
	 */
	public EnrollHeartbeatStarterBean() {
	}

	@Override
	public void startTimer(int pollDuraton) {
		Collection<Timer> existingTimers = timerService.getTimers();
		if (existingTimers.isEmpty()) {
			printLogMessage("REGISTERING NEW TIMER");

			timerService.createTimer(pollDuraton, pollDuraton, null);
		} else {
			printLogMessage("TIMER ALREADY REGISTERED");
		}
	}

	@Timeout
	public void timeout(javax.ejb.Timer timer) {
		if (pollBean == null) {
			try {
				pollBean = ServiceLocator.getLookUpJndiObject(
						JNDIConstants.TME_HEARTBEAT_POLL_BEAN,
						EnrollHeartbeatPollLocal.class);
			} catch (Exception e) {
				log.warn("EnrollHeartbeatPollBean has not bound yet.");
			}
		} else {
			try {
				pollBean.poll();
			} catch (Exception e) {
				log.warn("EnrollHeartbeatPollBean poll error.", e);
			}
		}
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}
}
