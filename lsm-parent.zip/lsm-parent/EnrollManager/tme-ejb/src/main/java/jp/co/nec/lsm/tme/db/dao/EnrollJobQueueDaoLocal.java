package jp.co.nec.lsm.tme.db.dao;

import java.util.List;

import javax.ejb.Local;

import jp.co.nec.lsm.tm.db.enroll.entities.EnrollJobQueueEntity;

/**
 * @author liuj <br>
 * 
 */
@Local
public interface EnrollJobQueueDaoLocal {

	/**
	 * get all Extract Job Information.
	 * 
	 * @param batchJobId
	 *            batch Job Id
	 * @return list of EnrollJobQueueEntity
	 */
	public List<EnrollJobQueueEntity> getAllExtractJobInfo(long batchJobId);

	/**
	 * update extract job result into ENROLL_JOB_QUEUE
	 * 
	 * @param extractJobEntityList
	 *            List of EnrollJobQueueEntity
	 */
	public void updateExctractJobQueue(
			List<EnrollJobQueueEntity> extractJobEntityList);

	/**
	 * insert extract job info into ENROLL_JOB_QUEUE
	 * 
	 * @param extractJobEntityList
	 *            List of EnrollJobQueueEntity
	 */
	public void insertExctractJobQueue(
			List<EnrollJobQueueEntity> extractJobEntityList);
}
