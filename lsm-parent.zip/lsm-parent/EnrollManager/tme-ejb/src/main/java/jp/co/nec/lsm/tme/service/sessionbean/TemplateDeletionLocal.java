package jp.co.nec.lsm.tme.service.sessionbean;

import javax.ejb.Local;

import jp.co.nec.lsm.tm.protocolbuffer.deletion.DeleteResultRequestProto.DeleteResultRequest;

/**
 * @author liuj
 */
@Local
public interface TemplateDeletionLocal {
	DeleteResultRequest deleteTemplate(Long batchJobId, String referenceId);
}
