package jp.co.nec.lsm.tme.service.sessionbean;

import javax.ejb.Local;

/**
 * 
 * @author mozj
 *
 */
@Local
public interface EnrollRecoveryServiceLocal {
	public void recoverUnCompletedBatchJob();
	public void unRecoverBatchJob();
}
