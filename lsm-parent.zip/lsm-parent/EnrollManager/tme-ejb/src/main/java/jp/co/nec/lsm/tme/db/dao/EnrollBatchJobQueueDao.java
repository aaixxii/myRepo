package jp.co.nec.lsm.tme.db.dao;

import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.lsm.tm.common.communication.SegmentPosition;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollBatchJobQueueEntity;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollBatchJobStatus;
import jp.co.nec.lsm.tm.db.enroll.entityhelpers.EnrollBatchJobQueueHelper;

/**
 * @author liuj <br>
 * 
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class EnrollBatchJobQueueDao implements EnrollBatchJobQueueDaoLocal {
	@PersistenceContext(unitName = "tme-ngi")
	private EntityManager manager;
	@Resource(mappedName = "java:jboss/OracleDS")
	protected DataSource dataSource;
	private EnrollBatchJobQueueHelper batchJobQueueHelper;

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(EnrollBatchJobQueueDao.class);

	/**
	 * constructor
	 */
	public EnrollBatchJobQueueDao() {	     
	}

	public EnrollBatchJobQueueDao(EntityManager entityManager) {
        this.manager = entityManager;
    }

    @PostConstruct
	public void init() {
		batchJobQueueHelper = new EnrollBatchJobQueueHelper(manager);
		printLogMessage("EnrollBatchJobQueueDao init");
	}

	/**
	 * check Batch Job whether Exist in DB
	 * 
	 * @param batchJobId
	 * @return
	 */
	@Override
	public boolean checkBatchJobExist(long batchJobId) {
		return batchJobQueueHelper.checkBatchJobExist(batchJobId);
	}

	/**
	 * persist BatchJob to database
	 * 
	 * @param batchJobEntity
	 *            EnrollBatchJobQueueEntity Instance
	 */
	@Override
	public void persistBatchJob(EnrollBatchJobQueueEntity batchJobEntity) {
		printLogMessage("start public function persistBatchJob()..");
		if (batchJobEntity == null) {
			log.warn("EnrollBatchJobQueueEntity is null.");
			return;
		}

		// persist Enroll Batch Job Information into DB
		batchJobQueueHelper.persistBatchJob(batchJobEntity);

		printLogMessage("end public function persistBatchJob()..");
	}

	/**
	 * persist BatchJob Status
	 * 
	 * @param batchJobId
	 *            batchJobId
	 * @param jobStatus
	 *            Local Enroll Batch Job Status
	 * @param segPosArray
	 *            Segment Position Array
	 */
	@Override
	public void persistBatchJobStatus(long batchJobId, Date timeStamp,
			EnrollBatchJobStatus jobStatus, List<SegmentPosition> segPosArray) {
		printLogMessage("start public function persistBatchJobStatus()..");

		if (jobStatus == null) {
			log.warn("jobStatus is null.");
			return;
		}

		// persist batch job information into database
		batchJobQueueHelper.persistBatchJobStatus(batchJobId, timeStamp,
				jobStatus, segPosArray);

		printLogMessage("end public function persistBatchJobStatus()..");
	}

	/**
	 * get all unreturned batch jobs from database
	 * 
	 * @return all unreturned batch jobs list
	 */
	@Override
	public List<EnrollBatchJobQueueEntity> getAllUnReturnedBatchJob() {

		List<EnrollBatchJobQueueEntity> batchJobs = batchJobQueueHelper
				.getAllUnReturnedBatchJob();

		return batchJobs;
	}

	/**
	 * commit
	 */
	@Override
	public void commit() {
		batchJobQueueHelper.commit(dataSource);
	}
	
	/**
	 * delete all unreturned batch jobs from database
	 */
	@Override
	public void deleteUnReturnedBatchJobs(){
		batchJobQueueHelper.deleteUnReturnedBatchJobs();
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}
}
