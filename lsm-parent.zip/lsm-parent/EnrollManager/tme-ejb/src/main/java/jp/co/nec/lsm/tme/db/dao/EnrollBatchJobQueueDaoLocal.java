package jp.co.nec.lsm.tme.db.dao;

import java.util.Date;
import java.util.List;

import javax.ejb.Local;

import jp.co.nec.lsm.tm.common.communication.SegmentPosition;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollBatchJobQueueEntity;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollBatchJobStatus;

/**
 * @author liuj <br>
 * 
 */
@Local
public interface EnrollBatchJobQueueDaoLocal {

	/**
	 * persist BatchJob to database
	 * 
	 * @param batchJobEntity
	 *            EnrollBatchJobQueueEntity Instance
	 */
	public void persistBatchJob(EnrollBatchJobQueueEntity batchJobEntity);

	/**
	 * persist BatchJob Status
	 * 
	 * @param batchJobId
	 *            batchJobId
	 * @param jobStatus
	 *            Local Enroll Batch Job Status
	 * @param segPosArray
	 *            Segment Position Array
	 */
	public void persistBatchJobStatus(long batchJobId, Date timeStamp,
			EnrollBatchJobStatus jobStatus, List<SegmentPosition> segPosArray);

	/**
	 * get all unreturned batch jobs from database
	 * 
	 * @return all unreturned batch jobs list
	 */
	public List<EnrollBatchJobQueueEntity> getAllUnReturnedBatchJob();

	/**
	 * check Batch Job whether Exist in DB
	 * 
	 * @param batchJobId
	 * @return
	 */
	boolean checkBatchJobExist(long batchJobId);

	/**
	 * commit
	 */
	public void commit();

	/**
	 * delete all unreturned batch jobs from database
	 */
	void deleteUnReturnedBatchJobs();

}
