package jp.co.nec.lsm.tme.service.sessionbean;

import java.lang.management.ManagementFactory;
import java.util.Date;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.management.MBeanServer;
import javax.management.ObjectName;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.lsm.tm.common.constants.Constants;
import jp.co.nec.lsm.tm.common.constants.MUState;
import jp.co.nec.lsm.tm.common.constants.QueueNames;
import jp.co.nec.lsm.tm.common.log.InfoLogger;
import jp.co.nec.lsm.tm.common.log.LogConstants;
import jp.co.nec.lsm.tm.common.transition.RoleStateTransition;
import jp.co.nec.lsm.tme.common.util.EnrollBatchJobGetterTimer;
import jp.co.nec.lsm.tme.common.util.EnrollEventBus;
import jp.co.nec.lsm.tme.db.dao.EnrollDateDao;
import jp.co.nec.lsm.tme.db.dao.EnrollMatchUnitDao;
import jp.co.nec.lsm.tme.db.dao.EnrollSystemConfigDao;
import jp.co.nec.lsm.tme.db.dao.EnrollTransactionManagerDao;
import jp.co.nec.lsm.tme.timer.EnrollExpirationTimer;

/**
 * @author liuj The class used to initialize system.
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class EnrollSystemInitializationBean {
		
	@EJB
	private EnrollMatchUnitDao enrollMatchUnitDao;
	@EJB
	private EnrollSystemConfigDao systemConfigDao;
	@EJB
	private EnrollTransactionManagerDao transactionManagerDao;
	@EJB
	private EnrollDateDao dateDao;
	@EJB
	private EnrollRecoveryServiceBean recoveryService;

	private static final Logger log = LoggerFactory
			.getLogger(EnrollSystemInitializationBean.class);

	/**
	 * constructor
	 */
	public EnrollSystemInitializationBean() {
	}

	/**
	 * initialize Enroll System.
	 */
	public void initializeTME() {
		printLogMessage("start public function initializeTME()..");

		if (log.isInfoEnabled()) {
			log.info(InfoLogger.infoOutput(
					LogConstants.COMPONENT_SYSTEM_INIT_BEAN,
					LogConstants.FUNCTION_INITIALIZE_TME, "DETAIL",
					"called in SystemInitializationBean"));
		}

		if (isSystemExpiredOrRunTimer()) {
			if (log.isWarnEnabled()) {
				log.warn("TMe system is already expired..");
			}
			return;
		}

		// remove all JMS message
		removeAllJmsMessage();
		// insert TME startUpTime into TRANSACTION_MANAGERS table.
		setStartupTime();
		// write All Missing Properties into SystemConfigure of DB
		writeAllMissingProperties();
		// Change Unit State of TimeOut.
		changePidUnitState();
		// Recover uncompleted enrollBatchJob.
		if (setStartMode()) {
			recoveryService.recoverUnCompletedBatchJob();
		}
		
		
		// Start Timer.
		EnrollEventBus.notifyStartJobPollTimerService();
		EnrollEventBus.notifyStartMFEPollTimerService();
		EnrollEventBus.notifyEnrollBatchJobGetterTimerService();
		int pollDuraton = systemConfigDao.getHeartbeatPollingDuration();
		EnrollEventBus.notifyEnrollBatchJobHeartbeatStarterService(pollDuraton);

		// out put the TME System Initialization
		if (log.isInfoEnabled()) {
			log.info(InfoLogger.infoOutput("SystemInitializationBean",
					"initialize", "DETAIL",
					"TME System Initialization successfully.."));
		}

		printLogMessage("end public function initializeTME()..");

	}

	/**
	 * isSystemExpiredOrRunTimer
	 */
	private boolean isSystemExpiredOrRunTimer() {
		Date dbDate = dateDao.getDatabaseDate();
		EnrollExpirationTimer expirationTimer = new EnrollExpirationTimer(
				dbDate);
		if (expirationTimer.isExpired()) {
			EnrollBatchJobGetterTimer batchJobGetterTimer = EnrollBatchJobGetterTimer
					.getInstance();
			batchJobGetterTimer.setStop(true);
			batchJobGetterTimer.setTransitionState(RoleStateTransition.PASSIVE);
			return true;
		}
		expirationTimer.start();
		return false;
	}

	/**
	 * setStartMode
	 * 
	 * @param
	 */
	private boolean setStartMode() {
		EnrollBatchJobGetterTimer jobGetter = EnrollBatchJobGetterTimer
				.getInstance();
		String model = System.getProperty(Constants.PROPERTY_KEY_NAME);
		if (model != null && (Constants.PASSIVE.equalsIgnoreCase(model))) {
			jobGetter.setTransitionState(RoleStateTransition.PASSIVE);
			return false;
		} else {
			jobGetter.setTransitionState(RoleStateTransition.ACTIVE);
			return true;
		}
	}

	/**
	 * write All Missing Properties into SystemConfigure of DB
	 */
	private void writeAllMissingProperties() {
		printLogMessage("start private function writeAllMissingProperties()..");

		systemConfigDao.writeAllMissingProperties();

		printLogMessage("end private function writeAllMissingProperties()..");
	}

	/***
	 * Change Unit State of TimeOut.
	 */
	private void changePidUnitState() {
		printLogMessage("start private function changePidUnitState()..");

		enrollMatchUnitDao.updateMatchUnits(MUState.WORKING, MUState.TIMED_OUT);

		printLogMessage("end private function changePidUnitState()..");
	}

	/**
	 * insert TME startUpTime into TRANSACTION_MANAGERS table.
	 */
	private void setStartupTime() {
		printLogMessage("start private function setStartupTime()..");

		transactionManagerDao.createOrLookup();

		printLogMessage("end private function setStartupTime()..");
	}

	/**
	 * remove all JMS message
	 * 
	 * @param queueName
	 */
	private void removeAllJmsMessage() {
		removeJmsMessage(QueueNames.ENROLL_DLQ_NAME);

		removeJmsMessage(QueueNames.ENROLL_QUEUE_NAME);

		removeJmsMessage(QueueNames.ENROLL_SYNC_SEGMENT_QUEUE_NAME);

		removeJmsMessage(QueueNames.TEMPLATE_MANAGER_QUEUE_NAME);
	}

	/**
	 * remove JMS message
	 * 
	 * @param queueName
	 */
	private void removeJmsMessage(String queueName) {
		try {			
			MBeanServer mBeanServer = ManagementFactory.getPlatformMBeanServer();

			ObjectName target = new ObjectName("org.hornetq:module=JMS,name=\""
					+ queueName + "\",type=Queue");

			String[] sig = new String[] { "java.lang.String" };
			mBeanServer.invoke(target, "removeMessages", new String[] { "" },
					sig);

		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}

}
