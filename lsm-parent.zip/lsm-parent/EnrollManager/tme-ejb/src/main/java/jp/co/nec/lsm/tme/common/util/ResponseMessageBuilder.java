package jp.co.nec.lsm.tme.common.util;

import jp.co.nec.lsm.proto.common.CommonProto.ReturnCode;
import jp.co.nec.lsm.tm.common.constants.BusinessMessageConstants;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tme.common.constants.EnrollConstants;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.everest.proto.protobuf.BusinessMessage.CPBBusinessMessage;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBRequest;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBResponse;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBResponseAttribute;

public class ResponseMessageBuilder {
	/** log instance **/
	private static Logger log = LoggerFactory
			.getLogger(ResponseMessageBuilder.class);

	/**
	 * 
	 * @param request
	 * @param errorCode
	 * @param errormessage
	 * @return
	 */
	public static CPBBusinessMessage createBusinessMessageByRequest(
			CPBRequest request, ReturnCode returnCode, String errorCode,
			String errorMessage, String resendable) {
		printLogMessage("start public function createResponseByRequest().");

		CPBResponse response = rebuildCPBResponse(null, returnCode, errorCode,
				errorMessage, resendable);

		CPBBusinessMessage.Builder businessMessage = CPBBusinessMessage
				.newBuilder();
		businessMessage.setRequest(request);
		businessMessage.setResponse(response);

		printLogMessage("end public function createResponseByRequest().");
		return businessMessage.build();
	}

	/**
	 * 
	 * @param errorCode
	 * @param errormessage
	 * @return
	 */
	public static CPBResponse rebuildCPBResponse(CPBResponse oldResponse,
			ReturnCode returnCode, String errorCode, String errorMessage,
			String resendable) {
		CPBResponse.Builder newResponse = null;
		if (oldResponse == null) {
			newResponse = CPBResponse.newBuilder();
		} else {
			newResponse = oldResponse.toBuilder();
		}

		if (returnCode == ReturnCode.JobSuccess) {
			newResponse.setStatus(EnrollConstants.EXTRACTJOB_SUCCESS_CODE);
			newResponse.setResendable("");
		} else {
			newResponse.setStatus(errorCode);
			newResponse.setResendable(resendable);
			newResponse.setErrorMessage(errorMessage);
		}

		if (newResponse.getResponseAttributesCount() == 0) {
			CPBResponseAttribute.Builder responseAttribute = CPBResponseAttribute
					.newBuilder();
			responseAttribute
					.setAttributeName(BusinessMessageConstants.REQUEST_PARAMETER_CREATED_TIMESTAMP);
			responseAttribute.setAttributeValue(DateUtil.formatUTC(DateUtil
					.getCurrentDate()));

			newResponse.addResponseAttributes(responseAttribute);
		}

		return newResponse.build();
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}
}
