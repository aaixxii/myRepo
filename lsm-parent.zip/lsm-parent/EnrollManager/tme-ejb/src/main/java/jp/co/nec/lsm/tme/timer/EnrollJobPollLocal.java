package jp.co.nec.lsm.tme.timer;

import javax.ejb.Local;


/**
 * @author zhulk
 */
@Local
public interface EnrollJobPollLocal {
	/**
	 * deadMM, Timeout Mu by Heart Beat and Report, Sgemt Job Timeout and Extrat
	 * Job Timeout
	 */
	public void poll();	
}
