package jp.co.nec.lsm.tme.db.dao;

import javax.ejb.Local;

/**
 * @author liuj <br>
 * 
 */
@Local
public interface EnrollContactTimesSPDaoLocal {

	/***
	 * The method used to update MU_CONTACTS table.
	 * 
	 * @param dataSource
	 * @param muId
	 * @param updateLastHeartbeatFlag
	 * @param updateLastReportFlag
	 */
	public void updateContactTimes(long muId, boolean updateLastHeartbeatFlag,
			boolean updateLastReportFlag);
}
