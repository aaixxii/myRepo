package jp.co.nec.lsm.tme.db.dao;

import java.util.Date;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.lsm.tm.common.constants.TMType;
import jp.co.nec.lsm.tm.common.constants.TmState;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.db.common.entities.TransactionManagerEntity;
import jp.co.nec.lsm.tm.db.common.entityhelpers.TransactionManagerHelper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author liuj <br>
 * 
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class EnrollTransactionManagerDao implements
		EnrollTransactionManagerDaoLocal {
	@PersistenceContext(unitName = "tme-ngi")
	private EntityManager manager;
	@Resource(mappedName = "java:jboss/OracleDS")
	protected DataSource dataSource;

	private TransactionManagerHelper tmHelper;

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(EnrollTransactionManagerDao.class);

	@PostConstruct
	public void init() {
		tmHelper = new TransactionManagerHelper(manager, TMType.TME);

		printLogMessage("EnrollTransactionManagerDao init");
	}

	/**
	 * constructor
	 */
	public EnrollTransactionManagerDao() {
	}

	/**
	 * Create or update MATCH_MANAGERS TABLE. this method judge called at an
	 * initial boot timing and "update MATCH_MANAGERS set version=parameter;".
	 * 
	 * @return
	 */
	@Override
	public TransactionManagerEntity createOrLookup() {

		Date now = DateUtil.getCurrentDate();
		TransactionManagerEntity enrollTransactionManaget = tmHelper
				.createOrLookupVersion(now);
		enrollTransactionManaget.setState(TmState.WORKING);
		enrollTransactionManaget.setLastHeartbeatTs(now);
		enrollTransactionManaget.setLastPollTs(now);
		manager.merge(enrollTransactionManaget);
		manager.flush();

		return enrollTransactionManaget;
	}

	/**
	 * update MATCH_MANAGERS TABLE. this method judge called at an initial boot
	 * timing and "update MATCH_MANAGERS set version=parameter;".
	 * 
	 * @return
	 */
	@Override
	public void changeTMEToExit() {

		Date now = DateUtil.getCurrentDate();
		TransactionManagerEntity enrollTransactionManaget = tmHelper
				.createOrLookupVersion(now);
		enrollTransactionManaget.setState(TmState.EXITED);
		enrollTransactionManaget.setLastHeartbeatTs(now);
		enrollTransactionManaget.setLastPollTs(now);
		manager.merge(enrollTransactionManaget);
		manager.flush();

		return;
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}
}
