package jp.co.nec.lsm.tme.timer;

public interface EnrollHeartbeatPollLocal {

	public void poll();
}
