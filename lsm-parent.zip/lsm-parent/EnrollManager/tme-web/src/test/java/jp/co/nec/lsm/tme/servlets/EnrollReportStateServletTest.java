package jp.co.nec.lsm.tme.servlets;

import static org.junit.Assert.assertEquals;

import java.io.IOException;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.lsm.proto.control.ExitRequestProto.ExitRequest;
import jp.co.nec.lsm.proto.segment.ReportStateResponseProto.ReportStateResponse;
import jp.co.nec.lsm.tme.service.sessionbean.EnrollStatusManagerBean;
import mockit.Mock;
import mockit.MockUp;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class EnrollReportStateServletTest {
	@Resource
	private JdbcTemplate jdbcTemplate;
	@Resource
	EnrollEnterServlet enterServlet;
	@Resource
	EnrollReportStateServlet reportStateServlet;

	@Before
	public void setUp() throws ServletException {
		reportStateServlet.init();
		cleanDB();
	}

	@After
	public void tearDown() {
		cleanDB();
	}

	/**
	 * 
	 */
	private void cleanDB() {
		jdbcTemplate.execute("delete FROM MU_SEGMENTS");
		jdbcTemplate.execute("delete FROM MU_CONTACTS");
		jdbcTemplate.execute("delete FROM match_units");
	}

	/**
	 * prepare data for EnrollBatchJobQueues
	 */
	private void prepareDBforTest(int gmvId, String state) {
		jdbcTemplate.execute("insert into match_units (mu_id,"
				+ " unique_id, state, TYPE, revision, IP_ADDRESS,"
				+ " balanced_flag) values(" + gmvId + ", 'uniqueId', '" + state
				+ "', 1, 1, 1, 1)");

	}

	@Test
	public void testDoPost_Success() throws ServletException, IOException {

		cleanDB();

		new MockUp<EnrollStatusManagerBean>() {
			@Mock
			private void printLogMessage(String logMessage, Object... objects) {
				return;
			}
		};

		prepareDBforTest(1234, "WORKING");

		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse resp = new MockHttpServletResponse();

		ExitRequest.Builder exitRequest = ExitRequest.newBuilder();
		exitRequest.setGmvId(1234);

		byte[] context = exitRequest.build().toByteArray();
		req.setContent(context);

		enterServlet.doPost(req, resp);

		MockHttpServletResponse respRep = new MockHttpServletResponse();
		reportStateServlet.doPost(req, respRep);

		ReportStateResponse.Builder reportStateResponse = ReportStateResponse
				.newBuilder();
		reportStateResponse.setGmvId(1234);
		int length = reportStateResponse.build().getSerializedSize();

		assertEquals(HttpServletResponse.SC_OK, respRep.getStatus());
		assertEquals(length, respRep.getContentLength());

		cleanDB();
	}

	@Test
	public void testDoPost_InternalError() throws ServletException, IOException {

		cleanDB();

		new MockUp<EnrollStatusManagerBean>() {
			@Mock
			private void printLogMessage(String logMessage, Object... objects) {
				return;
			}
		};

		prepareDBforTest(1234, "EXIT");

		MockHttpServletRequest req = new MockHttpServletRequest();

		ExitRequest.Builder exitRequest = ExitRequest.newBuilder();
		exitRequest.setGmvId(1234);

		byte[] context = exitRequest.build().toByteArray();
		req.setContent(context);

		MockHttpServletResponse respRep = new MockHttpServletResponse();
		reportStateServlet.doPost(req, respRep);

		assertEquals(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, respRep
				.getStatus());
		assertEquals(114, respRep.getContentLength());

		cleanDB();
	}

	@Test
	public void testDoPost_StateError() throws ServletException, IOException {

		cleanDB();

		new MockUp<EnrollStatusManagerBean>() {
			@Mock
			private void printLogMessage(String logMessage, Object... objects) {
				return;
			}
		};

		MockHttpServletRequest req = new MockHttpServletRequest();

		ExitRequest.Builder exitRequest = ExitRequest.newBuilder();
		exitRequest.setGmvId(1234);

		byte[] context = exitRequest.build().toByteArray();
		req.setContent(context);

		MockHttpServletResponse respRep = new MockHttpServletResponse();
		reportStateServlet.doPost(req, respRep);

		assertEquals(HttpServletResponse.SC_SEE_OTHER, respRep.getStatus());
		assertEquals(0, respRep.getContentLength());

		cleanDB();
	}

	@Test
	public void testDoPost_NoContext() throws ServletException, IOException {

		cleanDB();

		new MockUp<EnrollStatusManagerBean>() {
			@Mock
			private void printLogMessage(String logMessage, Object... objects) {
				return;
			}
		};

		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse resp = new MockHttpServletResponse();

		reportStateServlet.doPost(req, resp);
		
		assertEquals(HttpServletResponse.SC_OK, resp.getStatus());
		assertEquals(0, resp.getContentLength());
	}
	
	@Test
	public void testDoPost_BadRequest() throws ServletException, IOException {

		cleanDB();

		new MockUp<EnrollStatusManagerBean>() {
			@Mock
			private void printLogMessage(String logMessage, Object... objects) {
				return;
			}
		};

		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse resp = new MockHttpServletResponse();

		byte[] context = new byte[] { 13, 46, 2, 0, 1, 4, 63, 13, 0 };
		req.setContent(context);

		reportStateServlet.doPost(req, resp);
		assertEquals(HttpServletResponse.SC_BAD_REQUEST, resp.getStatus());
		assertEquals(124, resp.getContentLength());
	}
}
