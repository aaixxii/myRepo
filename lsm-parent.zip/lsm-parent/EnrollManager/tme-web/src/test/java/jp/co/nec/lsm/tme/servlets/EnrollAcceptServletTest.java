package jp.co.nec.lsm.tme.servlets;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;

import jp.co.nec.lsm.tm.common.transition.RoleStateTransition;
import jp.co.nec.lsm.tm.protocolbuffer.common.BatchTypeProto.BatchType;
import jp.co.nec.lsm.tm.protocolbuffer.enroll.EnrollRequestProto.EnrollRequest;
import jp.co.nec.lsm.tme.common.util.EnrollBatchJobGetterTimer;
import jp.co.nec.lsm.tme.core.jobs.EnrollBatchJobManager;
import jp.co.nec.lsm.tme.core.jobs.LocalEnrollBatchJob;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.google.protobuf.ByteString;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBBusinessMessage;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class EnrollAcceptServletTest {
	@Resource
	private JdbcTemplate jdbcTemplate;
	@Resource
	EnrollAcceptServlet acceptSevlet;

	private final String referenceID = "_abcdefg123456789_";
	private final String referenceURL = "abcde1234_";

	@Before
	public void setUp() throws ServletException {
		acceptSevlet.init();

		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		ConcurrentLinkedQueue<LocalEnrollBatchJob> enrollLinkQueue = queueManage
				.getEnrollLinkQueue();

		for (int i = 1; i <= enrollLinkQueue.size(); i++) {
			enrollLinkQueue.poll();
		}
		EnrollBatchJobGetterTimer jobGetter = EnrollBatchJobGetterTimer
				.getInstance();
		jobGetter.setStop(false);
		jobGetter.setTransitionState(RoleStateTransition.ACTIVE);
		cleanDB();
	}

	@After
	public void tearDown() {
		EnrollBatchJobGetterTimer jobGetter = EnrollBatchJobGetterTimer
				.getInstance();
		jobGetter.setStop(false);
		jobGetter.setTransitionState(RoleStateTransition.ACTIVE);

		cleanDB();
	}

	/**
	 * 
	 */
	private void cleanDB() {
		jdbcTemplate.execute("delete FROM ENROLL_BATCH_JOB_QUEUE");
		jdbcTemplate.execute("delete FROM ENROLL_JOB_QUEUE");
	}

	/**
	 * prepare data for EnrollBatchJobQueues
	 * 
	 * @param batchJobId
	 */
	private void prepareEnrollBatchJobQueue(long batchJobId) {
		String enrollBatchJobQueueSql = "insert into ENROLL_BATCH_JOB_QUEUE ("
				+ "BATCHJOB_ID,BATCHJOB_STATUS, ENQUEUE_TS)" + " values("
				+ batchJobId + ", " + 0
				+ ", TO_DATE('29-02-2012 12:00:00', 'DD-MM-YYYY HH24.MI.SS'))";

		jdbcTemplate.execute(enrollBatchJobQueueSql);

	}

	/**
	 * 
	 * @param batchJobId
	 * @param type
	 * @param extractJobCount
	 * @param referentID
	 * @param referentURL
	 * @return
	 */
	private EnrollRequest prepareEnrollRequest(long batchJobId, BatchType type,
			int extractJobCount, String referentID, String referentURL) {
		EnrollRequest.Builder enrollrequest = EnrollRequest.newBuilder();
		enrollrequest.setBatchJobId(batchJobId);
		enrollrequest.setType(type);

		List<CPBBusinessMessage> businessMessageList = WebTestUtil
				.prepareCPBBusinessMessage(batchJobId, extractJobCount,
						referentID, referentURL, false);

		for (CPBBusinessMessage message : businessMessageList) {
			enrollrequest.addBusinessMessage(message.toByteString());
		}

		return enrollrequest.build();
	}

	/**
	 * 
	 * @throws ServletException
	 * @throws IOException
	 */
	@Test
	public void testDoPost_Duplicated() throws ServletException, IOException {
		long batchJobId = 4534;

		cleanDB();

		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		LocalEnrollBatchJob enrollbatchjob = new LocalEnrollBatchJob();
		enrollbatchjob.setBatchJobId(batchJobId);
		enrollbatchjob.setBatchJobType(BatchType.ENROLL);
		queueManage.addEnrollBatchJob(enrollbatchjob);

		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse resp = new MockHttpServletResponse();

		EnrollRequest enrollRequest = prepareEnrollRequest(batchJobId,
				BatchType.ENROLL, 10, referenceID, referenceURL);

		byte[] context = enrollRequest.toByteArray();
		req.setContent(context);

		acceptSevlet.doPost(req, resp);

		assertEquals(HttpServletResponse.SC_BAD_REQUEST, resp.getStatus());
		assertEquals(140, resp.getContentLength());

		assertJobCountInMemory(batchJobId, 1, 0);

		cleanDB();
		jdbcTemplate.execute("commit");
	}

	/**
	 * 
	 * @throws ServletException
	 * @throws IOException
	 */
	@Test
	public void testDoPost_Success() throws ServletException, IOException {
		long batchJobId = 4534;

		cleanDB();

		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse resp = new MockHttpServletResponse();

		EnrollRequest enrollRequest = prepareEnrollRequest(batchJobId,
				BatchType.ENROLL, 10, referenceID, referenceURL);

		byte[] context = enrollRequest.toByteArray();
		req.setContent(context);

		acceptSevlet.doPost(req, resp);

		assertEquals(HttpServletResponse.SC_OK, resp.getStatus());
		assertEquals(0, resp.getContentLength());

		assertJobCountInMemory(batchJobId, 1, 10);

		cleanDB();
		jdbcTemplate.execute("commit");
	}

	/**
	 * 
	 * @throws ServletException
	 * @throws IOException
	 */
	@Test
	public void testDoPost_DropRequest() throws ServletException, IOException {
		long batchJobId = 4534;

		cleanDB();

		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse resp = new MockHttpServletResponse();

		EnrollRequest.Builder enrollrequest = EnrollRequest.newBuilder();
		enrollrequest.setBatchJobId(batchJobId);
		enrollrequest.setType(BatchType.ENROLL);

		List<CPBBusinessMessage> businessMessageList = WebTestUtil
				.prepareCPBBusinessMessage(batchJobId, 10, referenceID,
						referenceURL, false);

		for (CPBBusinessMessage message : businessMessageList) {
			enrollrequest.addBusinessMessage(message.toByteString());
		}
		enrollrequest.addBusinessMessage(ByteString.copyFrom(new byte[] { 0,
				14, 0, 4, 1, 2, 2 }));

		byte[] context = enrollrequest.build().toByteArray();
		req.setContent(context);

		acceptSevlet.doPost(req, resp);

		assertEquals(HttpServletResponse.SC_OK, resp.getStatus());
		assertEquals(0, resp.getContentLength());

		assertJobCountInMemory(batchJobId, 1, 10);

		cleanDB();
		jdbcTemplate.execute("commit");
	}

	/**
	 * 
	 * @throws ServletException
	 * @throws IOException
	 */
	@Test
	public void testDoPost_InternalError() throws ServletException, IOException {
		long batchJobId = 4534;

		cleanDB();

		prepareEnrollBatchJobQueue(batchJobId);

		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse resp = new MockHttpServletResponse();

		EnrollRequest enrollRequest = prepareEnrollRequest(batchJobId,
				BatchType.ENROLL, 10, referenceID, referenceURL);

		byte[] context = enrollRequest.toByteArray();
		req.setContent(context);

		acceptSevlet.doPost(req, resp);
		assertEquals(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, resp
				.getStatus());
		assertEquals(266, resp.getContentLength());

		assertJobCountInMemory(batchJobId, 0, 10);

		cleanDB();
		jdbcTemplate.execute("commit");
	}

	/**
	 * 
	 * @throws ServletException
	 * @throws IOException
	 */
	@Test
	public void testDoPost_BadRequest() throws ServletException, IOException {
		long batchJobId = 4234;
		cleanDB();

		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse resp = new MockHttpServletResponse();

		EnrollRequest enrollRequest = prepareEnrollRequest(batchJobId,
				BatchType.DELETE, 10, referenceID, referenceURL);

		byte[] context = enrollRequest.toByteArray();
		req.setContent(context);

		acceptSevlet.doPost(req, resp);
		assertEquals(HttpServletResponse.SC_BAD_REQUEST, resp.getStatus());
		assertEquals(184, resp.getContentLength());

		assertJobCountInMemory(batchJobId, 0, 10);
	}

	/**
	 * 
	 * @throws ServletException
	 * @throws IOException
	 */
	@Test
	public void testDoPost_EmptyRequestId() throws ServletException, IOException {
		long batchJobId = 4534;

		cleanDB();

		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse resp = new MockHttpServletResponse();

		EnrollRequest.Builder enrollrequest = EnrollRequest.newBuilder();
		enrollrequest.setBatchJobId(batchJobId);
		enrollrequest.setType(BatchType.ENROLL);

		List<CPBBusinessMessage> businessMessageList = WebTestUtil
				.prepareCPBBusinessMessage(batchJobId, 10, referenceID,
						referenceURL, true);

		for (CPBBusinessMessage message : businessMessageList) {
			enrollrequest.addBusinessMessage(message.toByteString());
		}

		byte[] context = enrollrequest.build().toByteArray();
		req.setContent(context);

		acceptSevlet.doPost(req, resp);

		assertEquals(HttpServletResponse.SC_BAD_REQUEST, resp.getStatus());
		assertEquals(161, resp.getContentLength());

		assertJobCountInMemory(batchJobId, 0, 10);

		cleanDB();
	}

	/**
	 * 
	 * @throws ServletException
	 * @throws IOException
	 */
	@Test
	public void testDoPost_RequestContextSizeEmpty() throws ServletException,
			IOException {
		long batchJobId = 4034;
		cleanDB();

		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse resp = new MockHttpServletResponse();

		acceptSevlet.doPost(req, resp);
		assertEquals(HttpServletResponse.SC_OK, resp.getStatus());
		assertEquals(0, resp.getContentLength());

		assertJobCountInMemory(batchJobId, 0, 10);
	}

	/**
	 * 
	 * @throws ServletException
	 * @throws IOException
	 */
	@Test
	public void testDoPost_Stop() throws ServletException, IOException {
		long batchJobId = 40124;
		cleanDB();

		EnrollBatchJobGetterTimer jobGetter = EnrollBatchJobGetterTimer
				.getInstance();
		jobGetter.setStop(true);
		jobGetter.setTransitionState(RoleStateTransition.PASSIVE);

		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse resp = new MockHttpServletResponse();

		String str = "testDoPost_Stop";
		byte[] context = str.getBytes();
		req.setContent(context);

		acceptSevlet.doPost(req, resp);
		assertEquals(HttpServletResponse.SC_OK, resp.getStatus());
		assertEquals(0, resp.getContentLength());

		assertJobCountInMemory(batchJobId, 0, 10);
	}

	/**
	 * 
	 * @throws ServletException
	 * @throws IOException
	 */
	@Test
	public void testDoPost_PASSIVE() throws ServletException, IOException {
		long batchJobId = 40314;
		cleanDB();

		EnrollBatchJobGetterTimer jobGetter = EnrollBatchJobGetterTimer
				.getInstance();
		jobGetter.setStop(false);
		jobGetter.setTransitionState(RoleStateTransition.PASSIVE);

		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse resp = new MockHttpServletResponse();

		acceptSevlet.doPost(req, resp);
		assertEquals(HttpServletResponse.SC_OK, resp.getStatus());
		assertEquals(0, resp.getContentLength());

		assertJobCountInMemory(batchJobId, 0, 10);
	}

	/**
	 * 
	 * @param batchJobId
	 * @param batchJobCount
	 * @param topLevelJobCount
	 */
	private void assertJobCountInMemory(long batchJobId, int batchJobCount,
			int topLevelJobCount) {
		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		LocalEnrollBatchJob enrollBatchJob = queueManage
				.getEnrollBatchJobById(batchJobId);

		assertEquals(batchJobCount, queueManage.getEnrollLinkQueue().size());
		if (batchJobCount != 0) {
			assertNotNull(enrollBatchJob);
			assertEquals(topLevelJobCount, enrollBatchJob.getExtractJobCount());
		} else {
			assertNull(enrollBatchJob);
		}
	}
}
