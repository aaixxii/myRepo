package jp.co.nec.lsm.tme.servlets;

import static org.junit.Assert.assertEquals;

import java.io.IOException;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.lsm.proto.control.ExitRequestProto.ExitRequest;
import jp.co.nec.lsm.tm.common.constants.MUState;
import jp.co.nec.lsm.tm.db.common.entities.MatchUnitEntity;
import jp.co.nec.lsm.tm.db.common.entityhelpers.MatchUnitHelper;
import jp.co.nec.lsm.tme.service.sessionbean.EnrollStatusManagerBean;
import mockit.Mock;
import mockit.MockUp;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class EnrollExitServletTest {
	@Resource
	private JdbcTemplate jdbcTemplate;
	@Resource
	EnrollExitServlet exitServlet;
	@PersistenceContext(unitName = "tme-ngi")
	private EntityManager manager;

	@Before
	public void setUp() throws ServletException {
		exitServlet.init();

		cleanDB();
	}

	@After
	public void tearDown() {
		cleanDB();
	}

	/**
	 * 
	 */
	private void cleanDB() {
		jdbcTemplate.execute("delete FROM MU_SEGMENTS");
		jdbcTemplate.execute("delete FROM MU_CONTACTS");
		jdbcTemplate.execute("delete FROM match_units");
	}

	/**
	 * prepare data for EnrollBatchJobQueues
	 */
	private void prepareDBforTest(int gmvId) {
		jdbcTemplate.execute("insert into match_units (mu_id,"
				+ " unique_id, state, TYPE, revision, IP_ADDRESS,"
				+ " balanced_flag) values(" + gmvId + ", 'uniqueId',"
				+ " 'WORKING', 1, 1, 1, 1)");

	}

	@Test
	public void testDoPost_RequestContextSizeEmpty() throws ServletException,
			IOException {

		cleanDB();

		new MockUp<EnrollStatusManagerBean>() {
			@Mock
			private void printLogMessage(String logMessage, Object... objects) {
				return;
			}
		};

		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse resp = new MockHttpServletResponse();

		exitServlet.doPost(req, resp);

		assertEquals(HttpServletResponse.SC_OK, resp.getStatus());
		assertEquals(0, resp.getContentLength());

		cleanDB();
	}

	@Test
	public void testDoPost_Success() throws ServletException, IOException {

		cleanDB();

		new MockUp<EnrollStatusManagerBean>() {
			@Mock
			private void printLogMessage(String logMessage, Object... objects) {
				return;
			}
		};

		prepareDBforTest(1234);

		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse resp = new MockHttpServletResponse();

		ExitRequest.Builder exitRequest = ExitRequest.newBuilder();
		exitRequest.setGmvId(1234);

		byte[] context = exitRequest.build().toByteArray();
		req.setContent(context);

		exitServlet.doPost(req, resp);

		assertEquals(HttpServletResponse.SC_OK, resp.getStatus());
		assertEquals(0, resp.getContentLength());

		MatchUnitHelper muHelper = new MatchUnitHelper(manager);
		MatchUnitEntity mu = muHelper.findAndWarnState(1234);
		assertEquals(MUState.EXITED, mu.getState());

		cleanDB();
	}

	@Test
	public void testDoPost_InternalError() throws ServletException, IOException {

		cleanDB();

		new MockUp<EnrollStatusManagerBean>() {
			@Mock
			private void printLogMessage(String logMessage, Object... objects) {
				throw new RuntimeException();
			}
		};

		prepareDBforTest(1234);

		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse resp = new MockHttpServletResponse();

		ExitRequest.Builder exitRequest = ExitRequest.newBuilder();
		exitRequest.setGmvId(1234);

		byte[] context = exitRequest.build().toByteArray();
		req.setContent(context);

		exitServlet.doPost(req, resp);

		assertEquals(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, resp
				.getStatus());
		assertEquals(106, resp.getContentLength());

		MatchUnitHelper muHelper = new MatchUnitHelper(manager);
		MatchUnitEntity mu = muHelper.findAndWarnState(1234);
		assertEquals(MUState.WORKING, mu.getState());

		cleanDB();
	}

	@Test
	public void testDoPost_BadRequest() throws ServletException, IOException {

		cleanDB();

		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse resp = new MockHttpServletResponse();

		byte[] context = new byte[] { 13, 46, 2, 0, 1, 4, 63, 13, 0 };
		req.setContent(context);

		exitServlet.doPost(req, resp);
		assertEquals(HttpServletResponse.SC_BAD_REQUEST, resp.getStatus());
		assertEquals(118, resp.getContentLength());
	}
}
