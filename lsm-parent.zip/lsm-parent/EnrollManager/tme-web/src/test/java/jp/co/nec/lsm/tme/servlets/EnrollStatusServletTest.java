package jp.co.nec.lsm.tme.servlets;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.util.concurrent.ConcurrentLinkedQueue;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;

import jp.co.nec.lsm.tm.db.enroll.entities.EnrollBatchJobStatus;
import jp.co.nec.lsm.tme.core.jobs.EnrollBatchJobManager;
import jp.co.nec.lsm.tme.core.jobs.LocalEnrollBatchJob;
import jp.co.nec.lsm.tme.core.jobs.LocalExtractJobInfo;
import jp.co.nec.lsm.tme.core.jobs.LocalExtractJobStatus;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

public class EnrollStatusServletTest {

	EnrollStatusServlet statusSevlet;

	@Before
	public void setUp() throws ServletException {
		statusSevlet = new EnrollStatusServlet();
		statusSevlet.init();

		cleanMemoryQueue();
	}

	@After
	public void tearDown() {
		cleanMemoryQueue();
	}

	/**
	 * 
	 */
	private void cleanMemoryQueue() {
		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		ConcurrentLinkedQueue<LocalEnrollBatchJob> enrollLinkQueue = queueManage
				.getEnrollLinkQueue();

		for (LocalEnrollBatchJob enrollBatchJob : enrollLinkQueue) {
			enrollLinkQueue.remove(enrollBatchJob);
		}
	}

	/**
	 * prepare data for EnrollBatchJobQueues
	 * 
	 * @param batchJobId
	 * @param jobCount
	 */
	private void prepareEnrollBatchJobQueue(long batchJobId, int jobCount) {
		// clear Memory Queue and MATCH_UNITS table
		cleanMemoryQueue();

		// 1 - prepare EnrollBatchJob/ExtractJobRequest For test
		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		LocalEnrollBatchJob enrollBatchJob = WebTestUtil
				.prepareDateforEnrollResultRequest(batchJobId, jobCount);

		enrollBatchJob.setBatchJobStatus(EnrollBatchJobStatus.EXTRACTING);
		for (int i = 1; i <= jobCount; i++) {
			LocalExtractJobInfo extractJob = enrollBatchJob
					.getExtractJobInfo(i);
			extractJob.setMUId(13);
			extractJob.setStatus(LocalExtractJobStatus.EXTRACTING);
		}
		// 2 - call add, add LocalEnrollBatchJob to database
		queueManage.addEnrollBatchJob(enrollBatchJob);

	}

	@Test
	public void testDoPost_Success() throws ServletException, IOException {
		long batchJobId = 4513;
		int jobCount = 13;

		prepareEnrollBatchJobQueue(batchJobId, jobCount);

		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse resp = new MockHttpServletResponse();

		statusSevlet.doGet(req, resp);

		assertEquals(HttpServletResponse.SC_OK, resp.getStatus());
		assertTrue(0 == resp.getContentLength());

		cleanMemoryQueue();
	}
}
