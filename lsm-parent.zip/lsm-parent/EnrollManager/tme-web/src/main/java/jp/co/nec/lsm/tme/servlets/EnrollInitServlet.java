package jp.co.nec.lsm.tme.servlets;

import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import jp.co.nec.lsm.tme.service.sessionbean.EnrollSystemInitializationRemote;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author mozj
 * @web.servlet name="EnrollInitServlet" load-on-startup="1"
 */
public class EnrollInitServlet extends GenericServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = -1691191103315273805L;

	private static final Logger log = LoggerFactory
			.getLogger(EnrollInitServlet.class);
	
	@EJB
	EnrollSystemInitializationRemote sysInit;
	
	public void init() throws ServletException {
		printLogMessage("INIT Servlet called");

		sysInit.initializeTME();
	}

	public void service(ServletRequest request, ServletResponse response)
			throws ServletException, IOException {
		// do nothing
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}

}
