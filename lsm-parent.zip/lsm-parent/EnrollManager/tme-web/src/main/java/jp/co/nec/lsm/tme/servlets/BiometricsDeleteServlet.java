package jp.co.nec.lsm.tme.servlets;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.nec.lsm.tm.common.log.LogConstants;
import jp.co.nec.lsm.tm.common.log.PerformanceLogger;
import jp.co.nec.lsm.tm.common.servlet.AbstractTMServlet;
import jp.co.nec.lsm.tm.common.util.ServletRequestUtil;
import jp.co.nec.lsm.tm.common.validator.ValidationResult;
import jp.co.nec.lsm.tm.protocolbuffer.deletion.DeleteRequestProto.DeleteRequest;
import jp.co.nec.lsm.tm.protocolbuffer.deletion.DeleteResultRequestProto.DeleteResultRequest;
import jp.co.nec.lsm.tme.core.clientapi.request.validator.DeleteRequestValidator;
import jp.co.nec.lsm.tme.core.jobs.DeletionJobManager;
import jp.co.nec.lsm.tme.core.jobs.LocalDeletionJob;
import jp.co.nec.lsm.tme.exception.EmptyRequestIDException;
import jp.co.nec.lsm.tme.exception.EnrollRuntimeException;
import jp.co.nec.lsm.tme.sessionbeans.api.TemplateManagerLocal;

import org.apache.commons.lang.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.protobuf.InvalidProtocolBufferException;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBBusinessMessage;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBRequest;

/**
 * @author mozj
 * @web.servlet name="BiometricsDeletionServlet"
 * @web.servlet-mapping url-pattern="/Delete"
 */
public class BiometricsDeleteServlet extends AbstractTMServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1037589021453356210L;

	private static final Logger log = LoggerFactory
			.getLogger(BiometricsDeleteServlet.class);

	@EJB
	private TemplateManagerLocal templateManager;

	public void init() throws ServletException {

	}

	/**
	 * 
	 */
	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException {
		doPost(req, res);
	}

	/**
	 * 
	 */
	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException {
		if (ServletRequestUtil.isRequestContextSizeEmpty(req)) {
			log.warn("Received an empty POST request");
			return;
		}

		StopWatch stopWatch = new StopWatch();
		stopWatch.start();

		CPBRequest request = null;
		DeleteRequest deletionRequest = null;
		try {
			deletionRequest = DeleteRequest.parseFrom(req.getInputStream());

			List<CPBBusinessMessage> businessMessageList = new ArrayList<CPBBusinessMessage>();
			for (int i = 0; i < deletionRequest.getBusinessMessageCount(); i++) {
				try {
					CPBBusinessMessage businessMessage = CPBBusinessMessage
							.parseFrom(deletionRequest.getBusinessMessage(i));
					businessMessageList.add(businessMessage);
				} catch (InvalidProtocolBufferException ex) {
					log.error("error occured in parse CPBBusinessMessage."
							+ " skip this top level job.", ex);
				}
			}

			if (log.isInfoEnabled()) {
				int totalCount = deletionRequest.getBusinessMessageCount();
				int receiveCount = businessMessageList.size();
				log.info("The CPBBusinessMessages from transformer "
						+ "serialize completely, reject job count: {}, "
						+ "receive job count: {}, total count: {}",
						new Object[] { totalCount - receiveCount, receiveCount,
								totalCount });
			}

			validateRequest(deletionRequest, businessMessageList);

			request = businessMessageList.get(0).getRequest();
		} catch (Exception ex) {
			writeErrorToResponse(req, res, HttpServletResponse.SC_BAD_REQUEST,
					ex.getMessage(), ex);
			return;
		}

		try {
			DeletionJobManager deletionJobManager = DeletionJobManager
					.getInstance();
			deletionJobManager.enqueueDeletionJob(new LocalDeletionJob(
					deletionRequest.getBatchJobId(), request));

			DeleteResultRequest deleteResult = templateManager.deleteTemplate(
					deletionRequest.getBatchJobId(), request.getEnrollmentId());

			if (deleteResult != null) {
				// return HTTP-200
				res.setContentType("application/octet-stream");
				res.setStatus(HttpServletResponse.SC_OK);
				res.setContentLength(deleteResult.getSerializedSize());
				deleteResult.writeTo(res.getOutputStream());
				res.flushBuffer();
			} else {
				String message = "Cannot find LocalDeletionJob:(batchjobId "
						+ deletionRequest.getBatchJobId()
						+ ") in memory queue.";
				writeErrorToResponse(req, res,
						HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message,
						new Exception(message));
			}
		} catch (Exception ex) {
			Throwable exception = (ex.getCause() == null ? ex : ex.getCause());
			if (exception instanceof EmptyRequestIDException) {
				writeErrorToResponse(req, res,
						HttpServletResponse.SC_BAD_REQUEST, ex.getMessage(), ex);
			} else {
				writeErrorToResponse(req, res,
						HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
						"Biometrics deletion error.", ex);
			}
			return;
		}
		stopWatch.stop();
		PerformanceLogger.performanceOutput(
				LogConstants.COMPONENT_BIOMETRICS_DELETION_SERVLET_TME,
				LogConstants.FUNCTION_DO_POST, stopWatch.getTime());

	}

	/**
	 * validate all data in Enter Request whether there are correct.
	 * 
	 * @param extractResultRequest
	 *            Extract Result request
	 * @return
	 */
	private void validateRequest(DeleteRequest deleteRequest,
			List<CPBBusinessMessage> businessMessageList) {
		printLogMessage("start private function validateRequest().");

		ValidationResult validationResult = DeleteRequestValidator.validate(
				deleteRequest, businessMessageList);
		if (validationResult != null && validationResult.hasErrors()) {
			String validateInfo = validationResult.getRequestError().get(0)
					.getInvalidReason();
			log.error(validateInfo);
			throw new EnrollRuntimeException(validateInfo);
		}

		// all data in enroll request are correct.
		printLogMessage("end private function validateRequest().");
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}

}
