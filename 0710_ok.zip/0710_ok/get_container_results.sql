CREATE DEFINER=`aimuser`@`%` PROCEDURE `get_container_results`(
 in p_job_id BIGINT(38),
out  tab_name VARCHAR(50)
)
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN
  DECLARE t_error integer DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
  SET @@autocommit = 0;
  DROP TABLE IF EXISTS contaiber_res;
 CREATE TABLE contaiber_res(cjob_result MEDIUMTEXT) engine=InnoDB;
 INSERT INTO contaiber_res 
 SELECT cj.CONTAINER_JOB_RESULT 
FROM   CONTAINER_JOBS cj, 
       FUSION_JOBS fj, 
       JOB_QUEUE jq 
WHERE  cj.FUSION_JOB_ID = fj.FUSION_JOB_ID 
       AND fj.JOB_ID = jq.JOB_ID 
       AND jq.JOB_ID = p_job_id 
       AND cj.JOB_STATE = 2
       AND jq.JOB_STATE = 1
ORDER  BY cj.CONTAINER_JOB_ID;  
  set tab_name =  'contaiber_res';
  	IF t_error=1 THEN  
        set tab_name =  '';
	ELSE
       commit;
	END IF;
END