CREATE DEFINER=`aimuser`@`%` PROCEDURE `get_inquiry_distributor_info`(
  in p_job_id  BIGINT(38),
  in p_function_id int,
  in p_plan_id BIGINT(38),
  out tab_name VARCHAR(50)
  )
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN  
    DECLARE t_error INTEGER DEFAULT 0;  
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1;  
	DROP TEMPORARY TABLE IF EXISTS iqy_distributor_info;
	CREATE TEMPORARY TABLE iqy_distributor_info (
    failure_count INT,
    search_req_idx INT,
    inquiry_lob_xml MEDIUMTEXT,
    inquiry_job_data MEDIUMBLOB,
    container_job_timeout BIGINT,   
    container_job_id BIGINT(38)
)  ENGINE=INNODB;
   SET  @@autocommit=0; 
INSERT INTO iqy_distributor_info(failure_count,search_req_idx,inquiry_lob_xml,inquiry_job_data,container_job_timeout,container_job_id)
 SELECT jq.FAILURE_COUNT,
       fj.SEARCH_REQUEST_INDEX,
       fj.INQUIRY_JOB_XML,
       fj.INQUIRY_PROBE_DATA,
       ft.CONTAINER_JOB_TIMEOUTS,       
       cj.CONTAINER_JOB_ID
FROM   JOB_QUEUE jq,
       FUSION_JOBS fj,
       FUNCTION_TYPES ft,
       CONTAINER_JOBS cj
WHERE  jq.JOB_ID = fj.JOB_ID
       AND fj.FUNCTION_ID = ft.FUNCTION_ID
       AND fj.FUSION_JOB_ID = cj.FUSION_JOB_ID
       AND jq.JOB_ID = p_job_id
       AND fj.FUNCTION_ID = p_function_id
       AND cj.PLAN_ID = p_plan_id; 
  set tab_name= 'iqy_distributor_info';
  if t_error =1 then 
   ROLLBACK;
     set tab_name= '';   
  else 
    commit;
  end if;
END