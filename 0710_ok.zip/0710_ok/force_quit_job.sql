CREATE DEFINER=`aimuser`@`%` PROCEDURE `force_quit_job`(
IN p_code varchar(1024),
IN p_reason varchar(1024),
IN p_failure_time varchar(50),
IN p_container_job_id int,
IN p_segment_id bigint(38),
IN p_result MEDIUMTEXT,
OUT o_job_id bigint(38))
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN
  DECLARE l_job_id  bigint(38);
  DECLARE l_mr_id int;
  DECLARE l_epoch_time long;
  DECLARE v_errcode int(10);
  DECLARE l_container_job_id BIGINT(38);
  DECLARE t_error integer DEFAULT 0;  
   DECLARE not_found int DEFAULT 0;
  DECLARE v_idx int DEFAULT 999;
  DECLARE v_tmp_str varchar(50);
  DECLARE v_id int;
  DECLARE v_count int; 
  DECLARE cur CURSOR FOR
  SELECT  id FROM l_container_job_ids;  
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1; 
   DECLARE CONTINUE HANDLER FOR NOT FOUND SET not_found = 1;
  DROP TEMPORARY TABLE IF EXISTS l_container_job_ids;
  CREATE TEMPORARY TABLE l_container_job_ids (
    id BIGINT(38)
  ) ENGINE = memory;
   SET @@autocommit = 0;
   SET SQL_SAFE_UPDATES = 0;  
  SELECT
    jq.JOB_ID,
    cj.MR_ID INTO l_job_id, l_mr_id
  FROM JOB_QUEUE jq,
       FUSION_JOBS fj,
       CONTAINER_JOBS cj
  WHERE jq.JOB_ID = fj.JOB_ID
  AND fj.FUSION_JOB_ID = cj.FUSION_JOB_ID
  AND cj.CONTAINER_JOB_ID = p_container_job_id
  AND 0 < jq.REMAIN_JOBS
  AND jq.JOB_STATE < 2
   FOR UPDATE;
  SELECT UNIX_TIMESTAMP(NOW()) into l_epoch_time;
  UPDATE CONTAINER_JOBS
  SET JOB_STATE = 2,
      CONTAINER_JOB_RESULT = p_result,
      RESULT_TS = l_epoch_time
  WHERE CONTAINER_JOB_ID = p_container_job_id
  AND JOB_STATE < 2;
  call insert_failure_Reason(l_mr_id,  p_code,  p_reason, p_failure_time, p_container_job_id, p_segment_id);
  INSERT INTO l_container_job_ids (id)
   SELECT cj.CONTAINER_JOB_ID FROM JOB_QUEUE jq, FUSION_JOBS fj, CONTAINER_JOBS cj WHERE jq.JOB_ID = l_job_id AND jq.JOB_ID = fj.JOB_ID AND fj.FUSION_JOB_ID = cj.FUSION_JOB_ID AND cj.CONTAINER_JOB_ID <> p_container_job_id;
  select count(id) into v_count from l_container_job_ids;
  IF v_count > 0 THEN
    OPEN cur;
  lable_loop:
    LOOP
      FETCH cur INTO v_id;
	  IF not_found = 1 THEN
		  LEAVE lable_loop;
	 END IF;
      SET l_container_job_id = v_id;
      UPDATE CONTAINER_JOBS
      SET RESULT_TS = l_epoch_time,
          JOB_STATE = 2
      WHERE CONTAINER_JOB_ID = l_container_job_id;      
      CALL insert_failure_Reason(NULL, p_code, CONCAT('Container job failed due to the related Container job:' , p_container_job_id ,' has some error.'), p_failure_time, l_container_job_id, NULL); 
    END LOOP;
    CLOSE cur;
  END IF;
  UPDATE JOB_QUEUE
  SET REMAIN_JOBS = 0,
      FAILURE_COUNT = FAILURE_COUNT + 1
  WHERE JOB_ID = l_job_id; 
   set o_job_id = l_job_id;
  IF t_error = 1 THEN
  set o_job_id = -2;
    ROLLBACK; 
  ELSE
    COMMIT;
  END IF; 
END