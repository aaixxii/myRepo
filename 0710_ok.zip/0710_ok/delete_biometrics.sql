CREATE DEFINER=`root`@`localhost` PROCEDURE `delete_biometrics`(IN p_external_id varchar(36),
IN p_container_id int,
IN p_no bigint,
OUT o_seg_ids varchar(512),
OUT o_seg_vers varchar(512),
OUT o_bio_ids varchar(512),
OUT r_deleted_record_count int)
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
begin_lab:
  BEGIN
    DECLARE l_person_id bigint(38);
    DECLARE l_new_binary_len_comp int(16);
    DECLARE l_new_rec_count bigint(38);
    DECLARE l_new_version bigint(38);
    DECLARE l_new_revision bigint(38);
    DECLARE tmp_biometrics_id bigint(38);
    DECLARE tmp_container_id int(8);
    DECLARE tmp_biometric_data_len int(16);
    DECLARE l_deleted_record_count int DEFAULT 0;
    DECLARE l_count int DEFAULT 0;
    DECLARE tp_segment_id bigint(38);
    DECLARE tp_record_count bigint(38);
    DECLARE tp_binary_length_compacted int(16);
    DECLARE tp_version bigint(38);
    DECLARE tp_revision bigint(38);
    DECLARE del_count int(11) DEFAULT 0;
    DECLARE v_result int;
    DECLARE not_found int DEFAULT 0;
    DECLARE t_error integer DEFAULT 0;
    DECLARE v_idx int DEFAULT 999;
    DECLARE v_tmp_str varchar(64);
    DECLARE v_id int;
    DECLARE v_tmp_segId int(38);
    DECLARE v_tmp_segVer int(38);
    DECLARE r_bio_ids varchar(512) DEFAULT '';
    DECLARE r_seg_ids varchar(512) DEFAULT '';
    DECLARE r_seg_vers varchar(512) DEFAULT '';

    DECLARE cur CURSOR FOR
    SELECT biometrics_id, container_id FROM tmp_person_biometrics;
    DECLARE ext_container_cur CURSOR FOR
    SELECT
      BIOMETRICS_ID,
      CONTAINER_ID
    FROM PERSON_BIOMETRICS
    WHERE EXTERNAL_ID = p_external_id
    AND CONTAINER_ID = p_container_id
    ORDER BY BIOMETRICS_ID;
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET not_found = 1;
    SET @@autocommit = 0;
    DROP TEMPORARY TABLE IF EXISTS tmp_person_biometrics;
    CREATE TEMPORARY TABLE tmp_person_biometrics (
      biometrics_id bigint(38),
      container_id int(8)
      ) engine=memory; 

    OPEN ext_container_cur;
    ext_container_cur_lab:
    LOOP
      FETCH ext_container_cur INTO tmp_biometrics_id, tmp_container_id;
      IF not_found = 1 THEN
        LEAVE ext_container_cur_lab;
      END IF;
      INSERT INTO tmp_person_biometrics
        VALUES (tmp_biometrics_id, tmp_container_id);
    END LOOP;    
    CLOSE ext_container_cur;
    SET not_found = 0;
    OPEN cur;
  lable_loop:
    LOOP
      FETCH cur INTO tmp_biometrics_id, tmp_container_id;
      IF not_found = 1 THEN
        LEAVE lable_loop;
      END IF; 
      BEGIN
        CALL update_seg_for_del(tmp_biometrics_id, tmp_container_id,p_external_id, p_no, @segId, @segVer);	  
        IF t_error <=> 0 THEN
          SET del_count = del_count + 1;
          SELECT
            @segId INTO v_tmp_segId;
          SELECT
            @segVer INTO v_tmp_segVer;
          SET r_bio_ids = CONCAT(r_bio_ids, CAST(tmp_biometrics_id AS char), ',');
          SET r_seg_ids = CONCAT(r_seg_ids, CAST(v_tmp_segId AS char), ',');
          SET r_seg_vers = CONCAT(r_seg_vers, CAST(v_tmp_segVer AS char), ',');
        END IF;  
       END; 
    END LOOP;
    CLOSE cur;
    IF t_error = 1 THEN     
      SET r_deleted_record_count = 0;
      SET o_seg_ids = '';
      SET o_seg_vers = '';
      SET o_bio_ids = '';
    ELSE      
      SET r_deleted_record_count = del_count;
      SET o_seg_ids = r_seg_ids;
      SET o_seg_vers = r_seg_vers;
      SET o_bio_ids = r_bio_ids;
    END IF;
  END