CREATE DEFINER=`aimuser`@`%` PROCEDURE `update_seg_for_del`(IN p_biometrics_id bigint(38),
IN p_container_id int(8),
IN p_external_id varchar(36),
IN p_no int,
OUT o_seg_id bigint(38),
OUT o_seg_ver bigint(38))
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
begin_lab:
  BEGIN
    DECLARE l_segmet_id bigint(38);
    DECLARE l_segment_ver bigint(38);
    DECLARE l_seg_binary_len int(16);
    DECLARE l_seg_rec_count bigint(38);
    DECLARE l_seg_revision bigint(38);
    DECLARE del_count int;
    DECLARE l_effect_count int;
    DECLARE tmp_one_templte_size int;
    DECLARE t_error integer DEFAULT 0;
    DECLARE not_found integer DEFAULT 0;
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET not_found = 1;
    SET @@autocommit = 0;
    SELECT
      KEY_VALUE INTO tmp_one_templte_size
    FROM system_init
    WHERE KEY_NAME = 'ONE_TEMPLATET_BYTE_SIZE';
    DELETE
      FROM PERSON_BIOMETRICS
    WHERE BIOMETRICS_ID = p_biometrics_id
      AND CONTAINER_ID = p_container_id;
    SELECT
      ROW_COUNT() INTO del_count;
    IF del_count <=> 0 THEN
      SET o_seg_id = -1;
      SET o_seg_ver = -1;
      LEAVE begin_lab;
    END IF;

    SELECT
      SEGMENT_ID,
      VERSION,
      BINARY_LENGTH,
      RECORD_COUNT,
      REVISION INTO l_segmet_id, l_segment_ver, l_seg_binary_len, l_seg_rec_count, l_seg_revision
    FROM SEGMENTS
    WHERE CONTAINER_ID = p_container_id
    AND p_biometrics_id BETWEEN BIO_ID_START AND BIO_ID_END;
    IF not_found <=> 1 THEN
      SET o_seg_id = -1;
      SET o_seg_ver = -1;
      LEAVE begin_lab;
    END IF;
    UPDATE SEGMENTS s
    SET BINARY_LENGTH = l_seg_binary_len - tmp_one_templte_size,
        RECORD_COUNT = l_seg_rec_count - 1,
        VERSION = l_segment_ver + 1,
        REVISION = l_seg_revision + 1
    WHERE SEGMENT_ID = l_segmet_id;
    IF t_error <=> 1 THEN
      SET o_seg_id = -1;
      SET o_seg_ver = -1;
      LEAVE begin_lab;
    END IF;
    SELECT
      ROW_COUNT() INTO l_effect_count;
    IF l_effect_count = 0 THEN
      SET o_seg_id = -1;
      SET o_seg_ver = -1;
      LEAVE begin_lab;
    END IF;
    INSERT INTO SEGMENT_CHANGE_LOG (SEGMENT_ID, SEGMENT_VERSION,EXTERNAL_ID, CHANGE_TYPE, BIOMETRICS_ID, UPDATE_TS, P_NO)
      VALUES (l_segmet_id, l_segment_ver + 1, p_external_id,2, p_biometrics_id, CAST(NOW() AS date), p_no);
    INSERT INTO SEGMENT_VACANCIES (SEGMENT_ID, BIOMETRICS_ID, VACANCY_TS)
      VALUES (l_segmet_id, p_biometrics_id, UNIX_TIMESTAMP(NOW()));
    IF t_error = 1 THEN
      SET o_seg_id = -1;
      SET o_seg_ver = -1;
      ROLLBACK;
    ELSE
      SET o_seg_id = l_segmet_id;
      SET o_seg_ver = l_segment_ver + 1;
    
    END IF;
  END