CREATE DEFINER=`aimuser`@`%` FUNCTION `create_new_mr_plan`(
p_mr_id int
) RETURNS bigint(38)
BEGIN
  DECLARE r_batch_plan_id BIGINT(38);
  DECLARE t_error integer DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
  INSERT INTO MR_JOB_PLANS(MR_ID, PLANED_TS) VALUES(p_mr_id ,  UNIX_TIMESTAMP(NOW()));
  SELECT max(BATCH_PLAN_ID) INTO r_batch_plan_id FROM MR_JOB_PLANS;
RETURN  r_batch_plan_id;
END