CREATE DEFINER=`aimuser`@`%` PROCEDURE `create_container_job`(IN p_job_id bigint(38),
IN p_search_request_index int,
IN p_function_id int,
IN p_inquiry_requist_xml mediumtext,
IN p_inquiry_probo_data blob,
IN p_container_id int,
OUT p_empty_job bigint(38),
OUT p_remain_job int,
OUT p_fusion_job_id bigint(38))
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
begin_lab:
  BEGIN
    DECLARE l_fusion_job_id bigint(38);
    DECLARE l_result varchar(20);
    DECLARE l_count int;
    DECLARE v_result int;
    DECLARE v_id int;   
    DECLARE t_error integer DEFAULT 0;
    DECLARE not_found integer DEFAULT 0;    
    DECLARE cur CURSOR FOR
    SELECT
      c.CONTAINER_ID
    FROM CONTAINERS c
    WHERE c.CONTAINER_ID = p_container_id
    AND EXISTS (SELECT
        seg.SEGMENT_ID
      FROM SEGMENTS seg
      WHERE seg.CONTAINER_ID = c.CONTAINER_ID);
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET not_found = 1;  
    SET @@autocommit = 0;
    
    INSERT INTO fusion_jobs (FUNCTION_ID,
    JOB_ID,
    INQUIRY_JOB_XML,
    INQUIRY_PROBE_DATA,
    SEARCH_REQUEST_INDEX)
      VALUES (p_function_id, p_job_id, p_inquiry_requist_xml, p_inquiry_probo_data, p_search_request_index);
    SELECT MAX(FUSION_JOB_ID) INTO l_fusion_job_id FROM FUSION_JOBS;
    IF l_fusion_job_id < 0 THEN
      SET p_empty_job = -1;
      SET p_remain_job = -1;
      SET p_fusion_job_id = -1;
      LEAVE begin_lab;
    END IF;
    SET p_empty_job = 1;
    OPEN cur;
  lable_loop:
    LOOP
      FETCH cur INTO v_id;
      IF not_found = 1 THEN
        LEAVE lable_loop;
      END IF;
      INSERT INTO CONTAINER_JOBS (FUSION_JOB_ID, CONTAINER_ID)
        VALUES (l_fusion_job_id, v_id);
    END LOOP;
    CLOSE cur;      
    IF t_error = 0 THEN
	  COMMIT;
      SET p_fusion_job_id = l_fusion_job_id;
	  SET p_empty_job = 0;
      SET p_remain_job = 1;
     ELSE   
      ROLLBACK;
      SET p_empty_job = -1;
      SET p_remain_job = -1;
      SET p_fusion_job_id = -1;  
    END IF;
  END