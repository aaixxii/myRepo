--add partition to segment change log

ALTER TABLE segment_change_log
ADD PARTITION 
 (PARTITION p7  VALUES IN (7),
  PARTITION p8 VALUES IN (8),
  PARTITION p9  VALUES IN (9));

--delete partition sample
 ALTER TABLE segment_change_log DROP PARTITION p9;
 
 --delete data in partition, no delete partion sample
 ALTER TABLE segment_change_log TRUNCATE PARTITION p8;
 
 ALTER TABLE segment_change_log TRUNCATE PARTITION  p6,p7;
