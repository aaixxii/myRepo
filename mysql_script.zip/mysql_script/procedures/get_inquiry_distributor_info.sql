CREATE DEFINER=`aimuser`@`%` PROCEDURE `get_inquiry_distributor_info`(
  in p_job_id  int,
  in p_function_id int,
  in p_plan_id int,
  out tab_name VARCHAR(50)
  )
    READS SQL DATA
    SQL SECURITY INVOKER
BEGIN  
    DECLARE t_error INTEGER DEFAULT 0;  
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1;  
	DROP TABLE IF EXISTS iqy_distributor_info;
	CREATE TABLE iqy_distributor_info (
    failure_count INT,
    search_req_idx INT,
    inquiry_job_data BLOB,
    container_job_timeout BIGINT,
    interl_candidate_size INT,
    container_job_id BIGINT(38)
)  ENGINE=INNODB;
   SET  @@autocommit=0; 
INSERT INTO iqy_distributor_info(failure_count,search_req_idx,inquiry_job_data,container_job_timeout,interl_candidate_size,container_job_id)
 SELECT jq.FAILURE_COUNT,
       fj.SEARCH_REQUEST_INDEX,
       fj.INQUIRY_JOB_DATA,
       ft.CONTAINER_JOB_TIMEOUTS,
        GREATEST(jq.MAX_CANDIDATES, IFNULL(ft.INTERNAL_CANDIDATE_SIZE, 0)) as internal_candidate_size,
		   
       cj.CONTAINER_JOB_ID
FROM   JOB_QUEUE jq,
       FUSION_JOBS fj,
       FUNCTION_TYPES ft,
       CONTAINER_JOBS cj
WHERE  jq.JOB_ID = fj.JOB_ID
       AND fj.FUNCTION_ID = ft.FUNCTION_ID
       AND fj.FUSION_JOB_ID = cj.FUSION_JOB_ID
       AND jq.JOB_ID = p_job_id
       AND fj.FUNCTION_ID = p_function_id
       AND cj.PLAN_ID = p_plan_id; 
  set tab_name= 'iqy_distributor_info';
  if t_error =1 then 
   ROLLBACK;
     set tab_name= '';   
  else 
    commit;
  end if;
END