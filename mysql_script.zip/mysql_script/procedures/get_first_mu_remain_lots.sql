CREATE DEFINER=`aimuser`@`%` PROCEDURE `get_first_mu_remain_lots`(
   in p_max_lot int,
   out  tab_name VARCHAR(50)
)
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN
  DECLARE t_error integer DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1; 
  DROP TABLE IF EXISTS first_remain_jobs;
  CREATE TABLE first_remain_jobs( mu_id int, currentlots int, num_extractor int, remain_lots int) engine=InnoDB;
  SET  @@autocommit=0;
  INSERT INTO first_remain_jobs
  SELECT muId, 
       currentlots, 
       num_extractor, 
       remain_lots 
   FROM   (SELECT mu.MU_ID             AS muId,
               ml.PRESSURE             AS currentlots, 
               mu.NUMBER_OF_EXTRACTORS AS num_extractor, 
               p_max_lot - ml.PRESSURE AS remain_lots 
        FROM   MATCH_UNITS mu, 
               MU_EXTRACT_LOAD ml, 
               MU_ELIGIBLE_FUNCTIONS mf 
        WHERE  mu.MU_ID = ml.MU_ID 
               AND mu.MU_ID = mf.MU_ID 
               AND mu.STATE = 'WORKING' 
               AND p_max_lot- ml.PRESSURE > 0 
               AND mu.NUMBER_OF_EXTRACTORS > 0 
               AND mf.FUNCTION_ID = 17
        ORDER  BY p_max_lot - ml.PRESSURE DESC, 
                  ml.UPDATE_TS ) as temp
	LIMIT  1;  
  
  set tab_name =  'first_remain_jobs';
  	IF t_error=1 THEN
	   rollback;
        set tab_name =  '';
    ELSE
       commit;
	END IF; 
END