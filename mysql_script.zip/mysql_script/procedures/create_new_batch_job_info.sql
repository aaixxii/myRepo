CREATE DEFINER=`aimuser`@`%` PROCEDURE `create_new_batch_job_info`(
   IN   p_batch_job_id  BIGINT(38),
   IN   p_reqeust_id   VARCHAR(36),
   IN   p_reference_id  VARCHAR(36),
   IN   p_batch_type VARCHAR(30),
   IN   p_fe_job_id BIGINT(38)
)
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN
 DECLARE t_error INT DEFAULT 0;
DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
   INSERT INTO batch_job_info (
        batch_job_id,
        request_id,
        enrollment_id,
        batch_type,
        internal_job_id
     ) VALUES (
        p_batch_job_id,
        p_reqeust_id,
        p_reference_id,
        p_batch_type,
        p_fe_job_id
     );
    IF t_error = 1 THEN
       ROLLBACK;        
     ELSE
       COMMIT;         
    END IF;  
END