CREATE DEFINER=`aimuser`@`%` PROCEDURE `process_one_mu_lot`(
IN p_mu_id BIGINT,
IN p_number_of_extractors int,
OUT l_lot_job_id BIGINT)
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
mylable:
  BEGIN
    DECLARE l_one_lot_count int;    
    DECLARE l_locked_tab_count int;
    DECLARE l_mu_extract_load_count int;
    DECLARE l_fe_job_timeout int;
    DECLARE l_current_epoch_time BIGINT;
    DECLARE t_error integer DEFAULT 0;
	DECLARE  not_found integer DEFAULT 0;
    DECLARE v_idx int;
    DECLARE v_tmp_str varchar(20);
    DECLARE v_id BIGINT;
    DECLARE cur CURSOR FOR
    SELECT jobId  FROM l_locked_fe_job_ids;   
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
     DECLARE CONTINUE HANDLER FOR NOT FOUND SET not_found = 1;
    DROP TEMPORARY TABLE IF EXISTS l_locked_fe_job_ids;
    CREATE TEMPORARY TABLE l_locked_fe_job_ids (jobId BIGINT(38)) ENGINE = MEMORY;
    SET  @@autocommit=0;
    IF (p_mu_id <= 0 OR p_number_of_extractors <= 0) THEN      
      SET l_lot_job_id = -9999;
      LEAVE mylable;
    END IF;
    SET l_one_lot_count = p_number_of_extractors;
    INSERT INTO l_locked_fe_job_ids (jobId)
     SELECT JOB_ID FROM FE_JOB_QUEUE WHERE JOB_STATE = 0 AND PRIORITY = 1 ORDER BY PRIORITY, FAILURE_COUNT DESC, JOB_ID LIMIT 1;
     select count(jobId) into l_locked_tab_count from l_locked_fe_job_ids;
    IF l_locked_tab_count = 1 THEN
      SET l_one_lot_count = 1;
    ELSEIF l_locked_tab_count < 1 THEN
      INSERT INTO l_locked_fe_job_ids (jobId)
      SELECT JOB_ID        
      FROM FE_JOB_QUEUE
      WHERE JOB_STATE = 0     
      ORDER BY PRIORITY, FAILURE_COUNT DESC,JOB_ID LIMIT l_one_lot_count;        
    END IF;
     select count(jobId) into l_locked_tab_count from l_locked_fe_job_ids;
    IF  l_locked_tab_count = 0 THEN   
       SET l_lot_job_id = -9999;
      LEAVE mylable;
    END IF;
    
    SELECT  TOP_LEVEL_JOB_TIMEOUTS INTO l_fe_job_timeout     
    FROM FUNCTION_TYPES
    WHERE FUNCTION_ID = 17
    AND QUEUE_TYPE = 1;
    SET l_fe_job_timeout = l_fe_job_timeout * l_locked_tab_count;
	SELECT UNIX_TIMESTAMP(NOW()) into l_current_epoch_time;  
    INSERT INTO FE_LOT_JOBS (MU_ID, ASSIGNED_TS,TIMEOUTS) 
	VALUES (p_mu_id, l_current_epoch_time, l_fe_job_timeout);    
    SELECT MAX(LOT_JOB_ID) INTO l_lot_job_id FROM FE_LOT_JOBS; 
    UPDATE MU_EXTRACT_LOAD
    SET PRESSURE = PRESSURE + 1,
        UPDATE_TS = l_current_epoch_time
    WHERE MU_ID = p_mu_id;
    
    OPEN cur;
   lable_loop:
    LOOP
      FETCH cur INTO v_id;
	  IF not_found = 1 THEN
          LEAVE lable_loop;
	  END IF;
      UPDATE FE_JOB_QUEUE
      SET LOT_JOB_ID = l_lot_job_id,
          MU_ID = p_mu_id,
          JOB_STATE = 1,
          ASSIGNED_TS = l_current_epoch_time
      WHERE JOB_ID = v_id;
    END LOOP;
    CLOSE cur;   
    IF t_error = 1 THEN	
      ROLLBACK;
    ELSE  
      COMMIT;
    END IF;
  END