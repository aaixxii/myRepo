CREATE DEFINER=`aimuser`@`%` PROCEDURE `complete_inquiryjob`(
	in p_job_id BIGINT(38),
	in p_container_job_id BIGINT(38),
	in p_sequence  INTEGER,
    in p_result BLOB,
    out l_remain_jobs BIGINT
)
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN
    declare l_count int default 0;
	declare l_failure_count BIGINT;    
  	declare  v_errcode  int;
	declare  v_epoch_t  BIGINT;
    DECLARE t_error INTEGER DEFAULT 0; 
    DECLARE not_found int DEFAULT 0;    
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET not_found = 1;
	SET @@autocommit = 0;
    SELECT UNIX_TIMESTAMP(NOW()) INTO v_epoch_t;
	SELECT FAILURE_COUNT 
              INTO l_failure_count
              FROM JOB_QUEUE 
              WHERE JOB_ID    = p_job_id
              AND JOB_STATE    = 1
              AND 0 < REMAIN_JOBS FOR UPDATE;              
              IF p_sequence  = l_failure_count THEN                  
                  UPDATE CONTAINER_JOBS
                  SET JOB_STATE = 2,
                      RESULT_TS  = v_epoch_t,
                      CONTAINER_JOB_RESULT = p_result
                  WHERE CONTAINER_JOB_ID = p_container_job_id
				  AND JOB_STATE= 1;
                SELECT ROW_COUNT() into l_count;
                  IF 0 < l_count THEN
                      UPDATE JOB_QUEUE
                      SET REMAIN_JOBS = REMAIN_JOBS - 1
                      WHERE JOB_ID = p_job_id;
                      select REMAIN_JOBS  INTO l_remain_jobs from JOB_QUEUE  WHERE JOB_ID = p_job_id;                  
                  ELSE
                      ROLLBACK;
                     set l_remain_jobs=-3;
                  END IF;
              ELSE
                  ROLLBACK;
                  set l_remain_jobs= -2;
              END IF;
              if not_found=1 then
              rollback;
                 set l_remain_jobs = -1;
              ELSEIF  t_error=1 then            
                rollback;
                 set l_remain_jobs = -4;
			 else 
                commit;               
              end if;
END