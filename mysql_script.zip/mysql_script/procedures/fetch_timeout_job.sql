CREATE DEFINER=`aimuser`@`%` PROCEDURE `fetch_timeout_job`(
 out  tab_name VARCHAR(50)
)
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN
  DECLARE l_epoch_time long;
  DECLARE t_error integer DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
   SELECT UNIX_TIMESTAMP(NOW()) into l_epoch_time;  
  DROP TABLE IF EXISTS timeout_job_ids;
  CREATE TABLE timeout_job_ids(id bigint(38)) engine=InnoDB;
  SET  @@autocommit=0;
  INSERT INTO timeout_job_ids(id)
   SELECT
    JOB_ID
  FROM JOB_QUEUE
  WHERE JOB_STATE = 1
  AND 0 <= TIMEOUTS
  AND ASSIGNED_TS < UNIX_TIMESTAMP(NOW()) - TIMEOUTS
  ORDER BY JOB_ID;
  set tab_name =  'timeout_job_ids';
  	IF t_error=1 THEN
	   rollback;
        set tab_name =  '';
    ELSE
       commit;
	END IF;  
END