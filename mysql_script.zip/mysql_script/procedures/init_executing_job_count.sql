CREATE DEFINER=`aimuser`@`%` PROCEDURE `init_executing_job_count`()
    READS SQL DATA
    SQL SECURITY INVOKER
BEGIN
  DECLARE t_error integer DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
UPDATE INQUIRY_TRAFFIC it 
SET 
    JOB_EXEC_COUNT = (SELECT 
            COUNT(JOB_ID)
        FROM
            JOB_QUEUE jq
        WHERE
            it.FAMILY_ID = jq.FAMILY_ID
                AND jq.JOB_STATE = 1); 
END