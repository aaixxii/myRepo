CREATE DEFINER=`aimuser`@`%` PROCEDURE `complete_top_level_job`(
  in p_job_id BIGINT(38), 
  in p_failed  INTEGER , 
  in p_result MEDIUMBLOB,
  out o_job_exec_count int
)
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN
 declare  l_family_id  int; 
 declare  l_job_exec_count int; 
 declare  v_epoch_t  BIGINT;
 DECLARE t_error INTEGER DEFAULT 0;  
 DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1;  
 SET  @@autocommit=0;
 SELECT UNIX_TIMESTAMP(NOW()) INTO v_epoch_t;
  SELECT jq.FAMILY_ID 
  INTO   l_family_id 
  FROM   JOB_QUEUE jq 
  WHERE  jq.JOB_ID = p_job_id 
  FOR UPDATE;     
         UPDATE JOB_QUEUE  
         SET    RESULT = p_result, 
                RESULT_TS = v_epoch_t, 
               FAILED_FLAG = p_failed, 
               JOB_STATE = 2 
        WHERE  JOB_ID = p_job_id;
  UPDATE INQUIRY_TRAFFIC 
  SET    JOB_EXEC_COUNT = JOB_EXEC_COUNT - 1, 
       JOB_COMPLETE_COUNT = JOB_COMPLETE_COUNT + 1 
  WHERE  FAMILY_ID = l_family_id;  
        select JOB_EXEC_COUNT into l_job_exec_count from INQUIRY_TRAFFIC  WHERE  FAMILY_ID = l_family_id; 
         IF l_job_exec_count < 0 THEN 
           call init_executing_job_count(); 
		 select JOB_EXEC_COUNT  INTO l_job_exec_count from inquiry_traffic  WHERE  FAMILY_ID = l_family_id; 
         end if;
       if t_error=1 then
        rollback;
	  else 
        set o_job_exec_count = l_job_exec_count;
	   commit;
	 end if; 
END