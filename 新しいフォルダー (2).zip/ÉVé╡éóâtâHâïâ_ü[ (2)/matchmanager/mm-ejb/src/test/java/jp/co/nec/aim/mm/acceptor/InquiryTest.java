package jp.co.nec.aim.mm.acceptor;

import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Lists;

import jp.co.nec.aim.message.proto.BusinessMessage.E_REQUESET_TYPE;
import jp.co.nec.aim.message.proto.InquiryService.IdentifyRequest;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.jms.JmsSender;
import jp.co.nec.aim.mm.util.ProtobufCreater;
import mockit.Mock;
import mockit.MockUp;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration()
@Transactional
public class InquiryTest extends AbstractTransactionalJUnit4SpringContextTests {
	@Resource
	private DataSource dataSource;
	@Resource
	private JdbcTemplate jdbcTemplate;
	@PersistenceContext(unitName = "aim-db")
	private EntityManager entityManager;
	@Resource
	private Inquiry inquiry;
	private  ProtobufCreater  protobufCreater;
	 private Registration reg;

	@Before
	public void setUp() {
		reg = new Registration(dataSource, entityManager);
		jdbcTemplate.update("delete from job_queue");
		jdbcTemplate.update("delete from container_jobs");
		jdbcTemplate.update("delete from fusion_jobs");
		jdbcTemplate.update("delete from segments");
		jdbcTemplate.update("commit");
		setMockMethod();
		protobufCreater = new ProtobufCreater();
	}

	private void setMockMethod() {
		new MockUp<JmsSender>() {
			@Mock
			private void convertAndSend(String queueName, Object object) {
				return;
			}
		};
	}

	@After
	public void tearDown() {
		jdbcTemplate.update("delete from job_queue");
		jdbcTemplate.update("delete from container_jobs");
		jdbcTemplate.update("delete from fusion_jobs");
		jdbcTemplate.update("delete from segments");
		jdbcTemplate.update("commit");		
	}

	@Test
	public void testInquiryInquiryJobRequestCommonOptionsBothNull() {
		List<AimInquiryRequest> inquiryRequests = new ArrayList<AimInquiryRequest>();
		CommonOptions options = new CommonOptions();
		try {
			inquiry.inquiry(inquiryRequests, options);			

		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof AimRuntimeException);
			Assert.assertEquals("At least one search request must be given",
					e.getMessage());
		}
	}
	
	@Test
	public void testInquiry_normal() {
		List<AimSyncRequest> syncRequests = Lists.newArrayList();
		byte[] binary = { 1, 2, 2 };
		Record record = new Record(binary);
		AimSyncRequest syncRequest = new AimSyncRequest(1, record);
		AimSyncRequest syncRequest1 = new AimSyncRequest(1, record);
		syncRequests.add(syncRequest);
		syncRequests.add(syncRequest1);
		reg.insert(1, "1", syncRequests);
		
		List<AimInquiryRequest> inquiryRequests = Lists.newArrayList();
		IdentifyRequest iqyReq = protobufCreater.createIdentifyRequest(E_REQUESET_TYPE.IDENTIFY_DEFAULT);		;
		AimInquiryRequest aimIqyReq = new AimInquiryRequest("MI", Arrays.asList(new Integer[] {1}), iqyReq.toBuilder());
		inquiryRequests.add(aimIqyReq );
		CommonOptions options = new CommonOptions();		
		options.setFromServlet(true);
		// options.setMinScore(1);
		options.setMaxCandidates(255);	
		try {
			long jobId = inquiry.inquiry(inquiryRequests, options);
			System.out.print(jobId);
			Assert.assertTrue(jobId > 0);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testInquiryCommonOptions_FunctionNameIsNull() {
		List<AimInquiryRequest> inquiryRequests = Lists.newArrayList();
		IdentifyRequest iqyReq = protobufCreater.createIdentifyRequest(E_REQUESET_TYPE.IDENTIFY_DEFAULT);		;
		AimInquiryRequest aimIqyReq = new AimInquiryRequest("", Arrays.asList(new Integer[] {1}), iqyReq.toBuilder());
		inquiryRequests.add(aimIqyReq );
		CommonOptions options = new CommonOptions();		
		options.setFromServlet(true);
		// options.setMinScore(1);
		options.setMaxCandidates(255);	
		try {
			inquiry.inquiry(inquiryRequests, options);

		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof AimRuntimeException);		
		}
	}



	@Test
	public void testInquiryOptionsContainerIdISNULL() {
		List<AimInquiryRequest> inquiryRequests = Lists.newArrayList();
		IdentifyRequest iqyReq = protobufCreater.createIdentifyRequest(E_REQUESET_TYPE.IDENTIFY_DEFAULT);		;
		AimInquiryRequest aimIqyReq = new AimInquiryRequest("MI", Arrays.asList(new Integer[] {}), iqyReq.toBuilder());
		inquiryRequests.add(aimIqyReq );
		CommonOptions options = new CommonOptions();		
		options.setFromServlet(true);
		// options.setMinScore(1);
		options.setMaxCandidates(255);	
		try {
			inquiry.inquiry(inquiryRequests, options);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof AimRuntimeException);
			Assert.assertEquals(
					"At least one search container id must be given.",
					e.getMessage());
			return;
		}
		fail();
	}

}
