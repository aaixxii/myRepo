package jp.co.nec.aim.mm.sessionbeans;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;

import javax.annotation.Resource;

import jp.co.nec.aim.mm.common.TestLogger;
import jp.co.nec.aim.mm.common.TestTimerService;
import jp.co.nec.aim.mm.constants.ConfigProperties;
import jp.co.nec.aim.mm.exception.HttpPostException;
import jp.co.nec.aim.mm.sessionbeans.AMRReportBean.ReportType;
import jp.co.nec.aim.mm.util.HttpPoster;
import jp.co.nec.aim.mm.util.HttpResponseInfo;
import mockit.Mock;
import mockit.MockUp;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.RegexFileFilter;
import org.apache.commons.lang3.time.DateUtils;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class AMRReportBeanTest {

	@Resource
	private AMRReportBean bean;

	private String dir;
	private String postMessage;
	private boolean exception;

	private final SimpleDateFormat sdFormat = new SimpleDateFormat(
			"yyyy-MM-dd-HH");

	@BeforeClass
	public static void beforeClass() {
		ConfigProperties.getInstance();

		new MockUp<LoggerFactory>() {
			@Mock
			public Logger getLogger(String name) {
				return new TestLogger();
			}
		};
	}

	@AfterClass
	public static void afterClass() {		
	}

	@Before
	public void before() {
		TestLogger.isDebugEnabled = false;
		exception = false;
		dir = System.getProperty("jboss.home.dir");

		String path = this.getClass().getClassLoader()
				.getResource("jdbc.properties").getPath();
		int index = path.lastIndexOf("/");
		path = path.substring(0, index);
		System.setProperty("jboss.home.dir", path);

		cleanLog();

		TestLogger.level = "";
		TestLogger.message = "";

		postMessage = "";
		new MockUp<HttpPoster>() {
			@Mock
			public final HttpResponseInfo smPost(final String url, String body,
					Integer timeout) throws HttpPostException {
				if (exception) {
					throw new HttpPostException();
				}
				postMessage += body;
				return null;
			}
		};
	}

	@After
	public void after() {
		if (dir != null) {
			System.setProperty("jboss.home.dir", dir);
		}
		cleanLog();
	}

	private void cleanLog() {
		RegexFileFilter filter = new RegexFileFilter(".*\\.log\\..*");
		File dir = new File(getLogPath());
		Collection<File> deleteFiles = FileUtils.listFiles(dir, filter, null);
		for (File file : deleteFiles) {
			file.delete();
		}
	}

	@Test
	public void testStartReport() throws Exception {
		bean.startReport();

		assertEquals("info", TestLogger.level);
		assertEquals("Report Timer is set to ScheduleExpression[second=0"
				+ " minute=0 hour=* dayOfWeek=* dayOfMonth=* month=* year=*"
				+ " start=null end=null timezone=]", TestLogger.message);

		assertEquals("", postMessage);
		assertEquals("createCalendarTimer", TestTimerService.method);
	}

	@Test
	public void testFetchPastJobDoneLog() throws IOException {
		Date now = new Date();
		now = DateUtils.truncate(now, Calendar.HOUR);

		File file1 = writeLog(ReportType.JOB_DONE.getPrefix(), now, -2);
		File file2 = writeLog(ReportType.JOB_DONE.getPrefix(), now, -1);
		writeLog(ReportType.JOB_DONE.getPrefix(), now, 0);
		writeLog(ReportType.JOB_DONE.getPrefix(), now, 1);
		writeLog(ReportType.JOB_DONE.getPrefix(), now, 2);

		Collection<File> files = bean.fetchPastLogFile(now,
				ReportType.JOB_DONE.getPrefix());
		assertEquals(2, files.size());
		assertTrue(files.contains(file1));
		assertTrue(files.contains(file2));
	}

	@Test
	public void testFetchPastFeJobDoneLog() throws IOException {
		Date now = new Date();
		now = DateUtils.truncate(now, Calendar.HOUR);
		File file1 = writeLog(ReportType.FE_JOB_DONE.getPrefix(), now, -2);
		File file2 = writeLog(ReportType.FE_JOB_DONE.getPrefix(), now, -1);
		File file3 = writeLog(ReportType.FE_JOB_DONE.getPrefix(), now, 0);
		writeLog(ReportType.FE_JOB_DONE.getPrefix(), now, 1);
		writeLog(ReportType.FE_JOB_DONE.getPrefix(), now, 2);
		file3.setLastModified(file3.lastModified() - 1);

		Collection<File> files = bean.fetchPastLogFile(now,
				ReportType.FE_JOB_DONE.getPrefix());
		assertEquals(3, files.size());
		assertTrue(files.contains(file1));
		assertTrue(files.contains(file2));
		assertTrue(files.contains(file3));
	}

	@Test
	public void testSendReport_NoLog() throws Exception {
		TestLogger.isDebugEnabled = true;

		bean.sendReport();

		assertEquals("info", TestLogger.level);
		assertEquals("No " + ReportType.JOB_DONE + " log for sending to SM."
				+ "No " + ReportType.FE_JOB_DONE + " log for sending to SM.",
				TestLogger.message);

		assertEquals("", postMessage);
	}

	@Test
	public void testSendReport_JobDoneLog() throws Exception {
		setMock();
		String logPath = getLogPath();

		Date now = new Date();
		now = DateUtils.truncate(now, Calendar.HOUR);
		File file1 = writeLog(ReportType.JOB_DONE.getPrefix(), now, -2);
		File file2 = writeLog(ReportType.JOB_DONE.getPrefix(), now, -1);
		File file3 = writeLog(ReportType.JOB_DONE.getPrefix(), now, 0);
		File file4 = writeLog(ReportType.JOB_DONE.getPrefix(), now, 1);
		File file5 = writeLog(ReportType.JOB_DONE.getPrefix(), now, 2);

		bean.sendReport();

		RegexFileFilter regexFilter = new RegexFileFilter(
				ReportType.JOB_DONE.getPrefix() + "\\.log\\..*");
		File logDir = new File(logPath);
		Collection<File> restFiles = FileUtils.listFiles(logDir, regexFilter,
				null);
		assertEquals(3, restFiles.size());
		assertFalse(restFiles.contains(file1));
		assertFalse(restFiles.contains(file2));
		assertTrue(restFiles.contains(file3));
		assertTrue(restFiles.contains(file4));
		assertTrue(restFiles.contains(file5));

		assertEquals("info", TestLogger.level);
		assertTrue(TestLogger.message.contains("Sent file size = "));

		assertEquals("hogehoge", postMessage);
	}

	@Test
	public void testSendReport_FeJobDoneLog() throws Exception {
		setMock();
		String logPath = getLogPath();

		Date now = new Date();
		now = DateUtils.truncate(now, Calendar.HOUR);
		File file1 = writeLog(ReportType.FE_JOB_DONE.getPrefix(), now, -2);
		File file2 = writeLog(ReportType.FE_JOB_DONE.getPrefix(), now, -1);
		File file3 = writeLog(ReportType.FE_JOB_DONE.getPrefix(), now, 0);
		File file4 = writeLog(ReportType.FE_JOB_DONE.getPrefix(), now, 1);
		File file5 = writeLog(ReportType.FE_JOB_DONE.getPrefix(), now, 2);

		bean.sendReport();

		RegexFileFilter regexFilter = new RegexFileFilter(
				ReportType.FE_JOB_DONE.getPrefix() + "\\.log\\..*");
		File logDir = new File(logPath);
		Collection<File> restFiles = FileUtils.listFiles(logDir, regexFilter,
				null);
		assertEquals(3, restFiles.size());
		assertFalse(restFiles.contains(file1));
		assertFalse(restFiles.contains(file2));
		assertTrue(restFiles.contains(file3));
		assertTrue(restFiles.contains(file4));
		assertTrue(restFiles.contains(file5));

		assertEquals("info", TestLogger.level);
		assertTrue(TestLogger.message.contains("Sent file size = "));

		assertEquals("hogehoge", postMessage);
	}

	private void setMock() {
		postMessage = "";
		new MockUp<HttpPoster>() {
			@Mock
			public final HttpResponseInfo smPost(final String url, String body,
					Integer timeout) throws HttpPostException {
				HttpResponseInfo info = new HttpResponseInfo(200);
				postMessage += body;
				return info;
			}
		};

	}

	@Test
	public void testSendReport_TwoTypeLog() throws Exception {
		setMock();
		Date now = new Date();
		now = DateUtils.truncate(now, Calendar.HOUR);
		File file1 = writeLog(ReportType.JOB_DONE.getPrefix(), now, -2);
		File file3 = writeLog(ReportType.JOB_DONE.getPrefix(), now, -1);
		File file5 = writeLog(ReportType.JOB_DONE.getPrefix(), now, 0);
		File file7 = writeLog(ReportType.JOB_DONE.getPrefix(), now, 1);
		File file2 = writeLog(ReportType.FE_JOB_DONE.getPrefix(), now, -1);
		File file4 = writeLog(ReportType.FE_JOB_DONE.getPrefix(), now, 0);
		File file6 = writeLog(ReportType.FE_JOB_DONE.getPrefix(), now, 1);
		File file8 = writeLog(ReportType.FE_JOB_DONE.getPrefix(), now, 2);

		bean.sendReport();

		RegexFileFilter regexFilter = new RegexFileFilter(
				ReportType.JOB_DONE.getPrefix() + "\\.log\\..*");
		String logPath = getLogPath();
		File logDir = new File(logPath);
		Collection<File> restFiles = FileUtils.listFiles(logDir, regexFilter,
				null);
		assertEquals(2, restFiles.size());
		assertFalse(restFiles.contains(file1));
		assertFalse(restFiles.contains(file3));
		assertTrue(restFiles.contains(file5));
		assertTrue(restFiles.contains(file7));

		regexFilter = new RegexFileFilter(ReportType.FE_JOB_DONE.getPrefix()
				+ "\\.log\\..*");
		logDir = new File(logPath);
		restFiles = FileUtils.listFiles(logDir, regexFilter, null);
		assertEquals(3, restFiles.size());
		assertFalse(restFiles.contains(file2));
		assertTrue(restFiles.contains(file4));
		assertTrue(restFiles.contains(file6));
		assertTrue(restFiles.contains(file8));

		assertEquals("info", TestLogger.level);
		assertTrue(TestLogger.message.contains("Sent file size = "));

		assertEquals("hogehogehoge", postMessage);
	}

	@Test
	public void testSendReport_NotRunSM() throws Exception {
		exception = true;

		Date now = new Date();
		now = DateUtils.truncate(now, Calendar.HOUR);
		File file1 = writeLog(ReportType.JOB_DONE.getPrefix(), now, -1);
		File file2 = writeLog(ReportType.FE_JOB_DONE.getPrefix(), now, -1);
		File file3 = writeLog(ReportType.JOB_DONE.getPrefix(), now, 0);
		File file4 = writeLog(ReportType.FE_JOB_DONE.getPrefix(), now, 0);
		File file5 = writeLog(ReportType.JOB_DONE.getPrefix(), now, 1);
		File file6 = writeLog(ReportType.FE_JOB_DONE.getPrefix(), now, 1);

		bean.sendReport();

		RegexFileFilter regexFilter = new RegexFileFilter(
				ReportType.JOB_DONE.getPrefix() + "\\.log\\..*");
		String logPath = getLogPath();
		File logDir = new File(logPath);
		Collection<File> restFiles = FileUtils.listFiles(logDir, regexFilter,
				null);
		assertEquals(3, restFiles.size());
		assertTrue(restFiles.contains(file1));
		assertTrue(restFiles.contains(file3));
		assertTrue(restFiles.contains(file5));

		regexFilter = new RegexFileFilter(ReportType.FE_JOB_DONE.getPrefix()
				+ "\\.log\\..*");
		logDir = new File(logPath);
		restFiles = FileUtils.listFiles(logDir, regexFilter, null);
		assertEquals(3, restFiles.size());
		assertTrue(restFiles.contains(file2));
		assertTrue(restFiles.contains(file4));
		assertTrue(restFiles.contains(file6));

		assertEquals("warn", TestLogger.level);
		assertTrue(TestLogger.message.contains(" can't send to SM"));
		assertTrue(TestLogger.message.contains("Not any " + ReportType.JOB_DONE
				+ " report was sent to SM"));
		assertTrue(TestLogger.message.contains("Not any "
				+ ReportType.FE_JOB_DONE + " report was sent to SM"));

		assertEquals("", postMessage);
	}

	private String getLogPath() {
		String path = this.getClass().getClassLoader()
				.getResource("jdbc.properties").getPath();
		int index = path.lastIndexOf("/");
		return path.substring(0, index) + "/statistics";
	}

	private File writeLog(String name, Date date, int addHour)
			throws IOException {
		String path = getLogPath();
		Date modifiedDate = DateUtils.addHours(date, addHour);
		File file = new File(path + "/" + name + ".log."
				+ sdFormat.format(modifiedDate));
		FileUtils.writeStringToFile(file, "hoge");
		file.setLastModified(modifiedDate.getTime());
		return file;
	}

}
