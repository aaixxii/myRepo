// $(function() {
//	  var sessionId = top.window.name;
//	  if (sessionId != ""){
//		  setCookie("SZWU_SESSION_ID", sessionId);
//	  }
//
// });

$(window).on("resize orientationchange", function (e) {
	var ua = navigator.userAgent.toLowerCase();
	if((ua.indexOf("iphone") > -1) || (ua.indexOf("ipod") > -1) || (ua.indexOf("Android") > -1)){
      $("meta[name='viewport']").attr("content", "width=980px,user-scalable=yes");
	}
}).trigger("resize");


function SaveSessionId(cname, cvalue, exdays) {
    var d = new Date();
    if (exdays == undefined) exdays = 30;
    d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
    var expires = "expires=" + d.toUTCString();
    document.cookie = cname + "=" + cvalue + "; " + expires + "; path=/";
}


function doubleCheck(){

    if (window.document.readyState != null
        && window.document.readyState != 'complete') {
        return false;
    } else {
        return true;
    }
}

function submitForm(action) {
	if (!doubleCheck()) {
		return false;
	}
	var rootUrl = $("#rootUrl").val();
    document.forms[0].method = 'POST';
	document.forms[0].action = rootUrl + action;
    document.forms[0].target = '_self';
    document.forms[0].secure = true;
    document.forms[0].httpOnly = true;
    document.forms[0].submit();
}

function submitForm(formid, action) {
	if (!doubleCheck()) {
		return false;
	}
	document.getElementById(formid).method = 'POST';
	var rootUrl = $("#rootUrl").val();
	document.getElementById(formid).action = rootUrl + action;
	document.getElementById(formid).target = '_self';
    document.getElementById(formid).secure = true;
    document.getElementById(formid).httpOnly = true;
	document.getElementById(formid).submit();
}

function postcall(formid,action, params) {

	var tempform = document.createElement("form");
	var rootUrl = $("#rootUrl").val();

	tempform.action= rootUrl + action;
	tempform.method='POST';
	tempform.style.display="none";
	tempform.target = '_self';
    tempform.secure = true;
    tempform.httpOnly = true;

    for (var x in params) {
        var opt = document.createElement("input");
        opt.name = x;
        opt.value = params[x];
        opt.type = 'hidden';
        tempform.appendChild(opt);
    }


    document.body.appendChild(tempform);
    tempform.submit();

}

function szwuPagenationPost( pageSu , formName ){

    $(".szwuSelectedPage").val(pageSu);
    var actionName = "";
    if ( formName.slice(0,1) == "/" ) {
        actionName = formName + "/pagemove"
    } else {
        actionName = "/" + formName + "/pagemove"
    }
    var form = $("form").eq(0);
    var rootUrl = $("#rootUrl").val();
    formName = rootUrl + formName;
    form.attr("method","post").attr("action",formName);
    form.submit();
};

//表示件数をhiddenに退避
//引数：formName：submit()する画面名
function szwuPagenationSizeChng( formName ){
	szwuPagenationPost( 0 , formName );
};

$(document).ready().delay(100).queue(function() {
	$("ul.tabMenu div.sub").each(function(i, elem) { 
		$(this).prev("img").width($(this).width() + 30)
	});
});