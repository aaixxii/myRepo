// We make use of this 'server' variable to provide the address of the
// REST Janus API. By default, in this example we assume that Janus is
// co-located with the web server hosting the HTML pages but listening
// on a different port (8088, the default for HTTP in Janus), which is
// why we make use of the 'window.location.hostname' base address. Since
// Janus can also do HTTPS, and considering we don't really want to make
// use of HTTP for Janus if your demos are served on HTTPS, we also rely
// on the 'window.location.protocol' prefix to build the variable, in
// particular to also change the port used to contact Janus (8088 for
// HTTP and 8089 for HTTPS, if enabled).
// In case you place Janus behind an Apache frontend (as we did on the
// online demos at http://janus.conf.meetecho.com) you can just use a
// relative path for the variable, e.g.:
//
//         var server = "/janus";
//
// which will take care of this on its own.
//
//
// If you want to use the WebSockets frontend to Janus, instead, you'll
// have to pass a different kind of address, e.g.:
//
//         var server = "ws://" + window.location.hostname + ":8188";
//
// Of course this assumes that support for WebSockets has been built in
// when compiling the gateway. WebSockets support has not been tested
// as much as the REST API, so handle with care!
//
//
// If you have multiple options available, and want to let the library
// autodetect the best way to contact your gateway (or pool of gateways),
// you can also pass an array of servers, e.g., to provide alternative
// means of access (e.g., try WebSockets first and, if that fails, fall
// back to plain HTTP) or just have failover servers:
//
//        var server = [
//            "ws://" + window.location.hostname + ":8188",
//            "/janus"
//        ];
//
// This will tell the library to try connecting to each of the servers
// in the presented order. The first working server will be used for
// the whole session.
//

var janus = null;
var sfutest = null;
var opaqueId = "videoroomtest-" + Janus.randomString(12);
var myroom = 1234; // Demo room
var myid = null;
var mypvtid = null;
var audio_stream_id;
var feeds = [];
var bitrateTimer = [];
var doSimulcast = (getQueryStringValue("simulcast") === "yes" || getQueryStringValue("simulcast") === "true");

var host = null;
var audio_port = null;

function janusInitAudio(url, param_host, param_audio_port) {
	host = param_host;
	audio_port = param_audio_port;

	var server = null;
	if (window.location.protocol === 'http:') {
	    server = "http://" + url + ":8088/janus";
	} else {
	    server = "https://" + url + ":8089/janus";
	}
	var stunUrl = "stun:" + url + ":3478";
	var turnUrl = "turn:" + url + ":3478";
	console.log("stunUrl : " + stunUrl);
	console.log("turnUrl : " + turnUrl);
	var myusername = "Test User";
	var mystream = null;
	// We use this other ID just to map our subscriptions to us
	// Initialize the library (all console debuggers enabled)
	Janus.init({
	    debug: "all",
	    callback: function () {
	        // Use a button to start the demo
	        // Make sure the browser supports WebRTC
	        if (!Janus.isWebrtcSupported()) {
	            bootbox.alert("No WebRTC support... ");
	            return;
	        }
	        // Create session
	        janus = new Janus({
	            server: server,
	            iceServers: [
	                //{urls: "stun:stun.l.google.com:19302"},
	                {
	                    urls: stunUrl
	                }, {
	                    urls: turnUrl,
	                    username: 'myuser',
	                    credential: 'mypassword'
	                }
	            ],
	            success: function () {
	                // Attach to video room test plugin
	                janus.attach({
	                    plugin: "janus.plugin.videoroom",
	                    opaqueId: opaqueId,
	                    success: function (pluginHandle) {
	                        sfutest = pluginHandle;
	                        Janus.log("Plugin attached! (" + sfutest.getPlugin() + ", id=" + sfutest.getId() + ")");
	                        Janus.log("  -- This is a publisher/manager");
	                        sfutest.send({
	                            "message": {
	                                "request": "join",
	                                "room": myroom,
	                                "ptype": "publisher",
	                                "display": myusername
	                            }
	                        });
	                    },
	                    error: function (error) {
	                        Janus.error("  -- Error attaching plugin...", error);
	                        bootbox.alert("Error attaching plugin... " + error);
	                    },
	                    consentDialog: function (on) {
	                        Janus.log("Consent dialog should be " + (on ? "on" : "off") + " now");
	                        if (on) {
	                            //
	                        } else {
	                            //
	                        }
	                    },
	                    mediaState: function (medium, on) {
	                        Janus.log("Janus " + (on ? "started" : "stopped") + " receiving our " + medium);
	                    },
	                    webrtcState: function (on) {
	                        Janus.log("Janus says our WebRTC PeerConnection is " + (on ? "up" : "down") + " now");
	                        // This controls allows us to override the global room bitrate cap
	                        $('#bitrate').parent().parent().removeClass('hide').show();
	                        $('#bitrate a').click(function () {
	                            var id = $(this).attr("id");
	                            var bitrate = parseInt(id) * 1000;
	                            if (bitrate === 0) {
	                                Janus.log("Not limiting bandwidth via REMB");
	                            } else {
	                                Janus.log("Capping bandwidth to " + bitrate + " via REMB");
	                            }
	                            sfutest.send({
	                                "message": {
	                                    "request": "configure",
	                                    "bitrate": bitrate
	                                }
	                            });
	                            return false;
	                        });
	                    },
	                    onmessage: function (msg, jsep) {
	                        Janus.log(" ::: Got a message (publisher) :::");
	                        Janus.log(msg);
	                        var event = msg["videoroom"];
	                        Janus.log("Event: " + event);
	                        if (event != undefined && event != null) {
	                            if (event === "joined") {
	                                // Publisher/manager created, negotiate WebRTC and attach to existing feeds, if any
	                                myid = msg["id"];
	                                mypvtid = msg["private_id"];
	                                Janus.log("Successfully joined room " + msg["room"] + " with ID " + myid);
	                                publishOwnFeed(true);
	                                // Any new feed to attach to?
	                                if (msg["publishers"] !== undefined && msg["publishers"] !== null) {
	                                    var list = msg["publishers"];
	                                    Janus.log("Got a list of available publishers/feeds:");
	                                    Janus.log(list);
	                                    for (var f in list) {
	                                        var id = list[f]["id"];
	                                        var display = list[f]["display"];
	                                        var audio = list[f]["audio_codec"];
	                                        var video = list[f]["video_codec"];
	                                        Janus.log("  >> [" + id + "] " + display + " (audio: " + audio + ", video: " + video + ")");
	                                        newRemoteFeed(id, display, audio, video);
	                                    }
	                                }
	                                // 音声サーバへ接続する
	                                videoForward();
	                            } else if (event === "destroyed") {
	                                // The room has been destroyed
	                                Janus.warn("The room has been destroyed!");
	                                bootbox.alert("The room has been destroyed", function () {
	                                    window.location.reload();
	                                });
	                            } else if (event === "success") {
	                                // The room has been destroyed
	                                Janus.warn("The room has been destroyed!");
	                                bootbox.alert("The room has been destroyed", function () {
	                                    window.location.reload();
	                                });
	                            } else if (event === "rtp_forward") {
	                                // The room has been destroyed
	                                Janus.warn("The room has been destroyed!");
	                                bootbox.alert("The room has been destroyed", function () {
	                                    window.location.reload();
	                                });
	                            } else if (event === "event") {
	                                // Any new feed to attach to?
	                                if (msg["publishers"] !== undefined && msg["publishers"] !== null) {
	                                    var list = msg["publishers"];
	                                    Janus.log("Got a list of available publishers/feeds:");
	                                    Janus.log(list);
	                                    for (var f in list) {
	                                        var id = list[f]["id"];
	                                        var display = list[f]["display"];
	                                        var audio = list[f]["audio_codec"];
	                                        var video = list[f]["video_codec"];
	                                        Janus.log("  >> [" + id + "] " + display + " (audio: " + audio + ", video: " + video + ")");
	                                        newRemoteFeed(id, display, audio, video);
	                                    }
	                                } else if (msg["leaving"] !== undefined && msg["leaving"] !== null) {
	                                    // One of the publishers has gone away?
	                                    var leaving = msg["leaving"];
	                                    Janus.log("Publisher left: " + leaving);
	                                    var remoteFeed = null;
	                                    for (var i = 1; i < 6; i++) {
	                                        if (feeds[i] != null && feeds[i] != undefined && feeds[i].rfid == leaving) {
	                                            remoteFeed = feeds[i];
	                                            break;
	                                        }
	                                    }
	                                    if (remoteFeed != null) {
	                                        Janus.log("Feed " + remoteFeed.rfid + " (" + remoteFeed.rfdisplay + ") has left the room, detaching");
	                                        feeds[remoteFeed.rfindex] = null;
	                                        remoteFeed.detach();
	                                    }
	                                } else if (msg["unpublished"] !== undefined && msg["unpublished"] !== null) {
	                                    // One of the publishers has unpublished?
	                                    var unpublished = msg["unpublished"];
	                                    Janus.log("Publisher left: " + unpublished);
	                                    if (unpublished === 'ok') {
	                                        // That's us
	                                        sfutest.hangup();
	                                        return;
	                                    }
	                                    var remoteFeed = null;
	                                    for (var i = 1; i < 6; i++) {
	                                        if (feeds[i] != null && feeds[i] != undefined && feeds[i].rfid == unpublished) {
	                                            remoteFeed = feeds[i];
	                                            break;
	                                        }
	                                    }
	                                    if (remoteFeed != null) {
	                                        Janus.log("Feed " + remoteFeed.rfid + " (" + remoteFeed.rfdisplay + ") has left the room, detaching");
	                                        feeds[remoteFeed.rfindex] = null;
	                                        remoteFeed.detach();
	                                    }
	                                } else if (msg["error"] !== undefined && msg["error"] !== null) {
	                                    if (msg["error_code"] === 426) {
	                                        // This is a "no such room" error: give a more meaningful description
	                                        bootbox.alert("<p>Apparently room <code>" + myroom + "</code> (the one this demo uses as a test room) " + "does not exist...</p><p>Do you have an updated <code>janus.plugin.videoroom.cfg</code> " + "configuration file? If not, make sure you copy the details of room <code>" + myroom + "</code> " + "from that sample in your current configuration file, then restart Janus and try again.");
	                                    } else {
	                                        bootbox.alert(msg["error"]);
	                                    }
	                                }
	                            }
	                        }
	                        if (jsep !== undefined && jsep !== null) {
	                            Janus.log("Handling SDP as well...");
	                            Janus.log(jsep);
	                            sfutest.handleRemoteJsep({
	                                jsep: jsep
	                            });
	                            // Check if any of the media we wanted to publish has
	                            // been rejected (e.g., wrong or unsupported codec)
	                            var audio = msg["audio_codec"];
	                            if (mystream && mystream.getAudioTracks() && mystream.getAudioTracks().length > 0 && !audio) {
	                                // Audio has been rejected
	                                toastr.warning("Our audio stream has been rejected, viewers won't hear us");
	                            }
	                            var video = msg["video_codec"];
	                            if (mystream && mystream.getVideoTracks() && mystream.getVideoTracks().length > 0 && !video) {
	                                // Video has been rejected
	                                toastr.warning("Our video stream has been rejected, viewers won't see us");
	                                // Hide the webcam video //★1不要イベントのため
	                                //$('#myvideo').hide();
	                            }
	                        }
	                    },
	                    //★1.onlocalstreamイベント削除 不要イベントのため
//	                    onlocalstream: function (stream) {
//	                        Janus.log(" ::: Got a local stream :::");
//	                        mystream = stream;
//	                        Janus.log(stream);
//	                        if ($('#myvideo').length === 0) {
//	                            //                                        $('#videolocal').append('<video id="myvideo"/>');
//	                            $('#mute').click(toggleMute);
//	                            // Add an 'unpublish' button
//	                            $('#unpublish').click(unpublishOwnFeed);
//	                        }
//	                        //$('#publisher').removeClass('hide').html(myusername).show();
//	                        //Janus.attachMediaStream($('#myvideo').get(0), stream);
//	                        $("#myvideo").get(0).muted = "muted";
//	                        if (sfutest.webrtcStuff.pc.iceConnectionState !== "completed" && sfutest.webrtcStuff.pc.iceConnectionState !== "connected") {}
//	                        var videoTracks = stream.getVideoTracks();
//	                        if (videoTracks === null || videoTracks === undefined || videoTracks.length === 0) {
//	                            // No webcam
//	                            $('#myvideo').hide();
//	                        } else {
//	                            $('#myvideo').removeClass('hide').show();
//	                        }
//	                    },
	                    onremotestream: function (stream) {
	                        // The publisher stream is sendonly, we don't expect anything here
	                    },
	                    oncleanup: function () {
	                        Janus.log(" ::: Got a cleanup notification: we are unpublished now :::");
	                        mystream = null;
	                        $('#publish').click(function () {
	                            publishOwnFeed(true);
	                        });
	                        $('#bitrate').parent().parent().addClass('hide');
	                        $('#bitrate a').unbind('click');
	                    }
	                });
	            },
	            error: function (error) {
	                Janus.error(error);
	                bootbox.alert(error, function () {
	                    window.location.reload();
	                });
	            },
	            destroyed: function () {
	                window.location.reload();
	            },
	        });
	    }
	});
}

forward1 = function () {
    var cmd = {
        "request": "rtp_forward",
        "room": 1234,
        "publisher_id": myid,
        "host": "127.0.0.1",
        "audio_port": 60002,
        "secret": "adminpwd"
    };
    forwardExec(cmd);
}

stop1 = function () {
    if (audio_stream_id !== undefined || audio_stream_id !== null) {
        sfutest.send({
            "message": {
                "request": "stop_rtp_forward",
                "room": 1234,
                "publisher_id": myid,
                "stream_id": audio_stream_id,
                "secret": "adminpwd"
            }
        });
    }
}


//通話機能を起動する
videoForward = function() {
	var cmd = { "request" : "rtp_forward","room" : 1234, "publisher_id" : myid, "host" : host, "audio_port" : Number(audio_port) , "secret" : "adminpwd" }; //★2.audio_portをintで変数に挿入
	forwardExec(cmd);
}
//通話機能を中止する
videoStop = function() {
	if(audio_stream_id !== undefined && audio_stream_id !== null) {
		sfutest.send({"message": { "request" : "stop_rtp_forward", "room" : 1234, "publisher_id" : myid, "stream_id" : audio_stream_id, "secret" : "adminpwd"}});
	}
}



function publishOwnFeed(useAudio) {
    // Publish our stream
    $('#publish').attr('disabled', true).unbind('click');
    sfutest.createOffer({
        // Add data:true here if you want to publish datachannels as well
        media: {
            audioRecv: false,
            videoRecv: false,
            audioSend: useAudio,
            videoSend: true
        }, // Publishers are sendonly
        // If you want to test simulcasting (Chrome and Firefox only), then
        // pass a ?simulcast=true when opening this demo page: it will turn
        // the following 'simulcast' property to pass to janus.js to true
        simulcast: doSimulcast,
        success: function (jsep) {
            Janus.log("Got publisher SDP!");
            Janus.log(jsep);
            var publish = {
                "request": "configure",
                "audio": useAudio,
                "video": true
            };
            // You can force a specific codec to use when publishing by using the
            // audiocodec and videocodec properties, for instance:
            //         publish["audiocodec"] = "opus"
            // to force Opus as the audio codec to use, or:
            //         publish["videocodec"] = "vp9"
            // to force VP9 as the videocodec to use. In both case, though, forcing
            // a codec will only work if: (1) the codec is actually in the SDP (and
            // so the browser supports it), and (2) the codec is in the list of
            // allowed codecs in a room. With respect to the point (2) above,
            // refer to the text in janus.plugin.videoroom.cfg for more details
            sfutest.send({
                "message": publish,
                "jsep": jsep
            });
        },
        error: function (error) {
            Janus.error("WebRTC error:", error);
            if (useAudio) {
                publishOwnFeed(false);
            } else {
                bootbox.alert("WebRTC error... " + JSON.stringify(error));
                $('#publish').removeAttr('disabled').click(function () {
                    publishOwnFeed(true);
                });
            }
        }
    });
}

function toggleMute() {
    var muted = sfutest.isAudioMuted();
    Janus.log((muted ? "Unmuting" : "Muting") + " local stream...");
    if (muted) sfutest.unmuteAudio();
    else sfutest.muteAudio();
    muted = sfutest.isAudioMuted();
    $('#mute').html(muted ? "Unmute" : "Mute");
}

function unpublishOwnFeed() {
    // Unpublish our stream
    $('#unpublish').attr('disabled', true).unbind('click');
    var unpublish = {
        "request": "unpublish"
    };
    sfutest.send({
        "message": unpublish
    });
}

function newRemoteFeed(id, display, audio, video) {
    // A new feed has been published, create a new plugin handle and attach to it as a subscriber
    var remoteFeed = null;
    janus.attach({
        plugin: "janus.plugin.videoroom",
        opaqueId: opaqueId,
        success: function (pluginHandle) {
            remoteFeed = pluginHandle;
            remoteFeed.simulcastStarted = false;
            Janus.log("Plugin attached! (" + remoteFeed.getPlugin() + ", id=" + remoteFeed.getId() + ")");
            Janus.log("  -- This is a subscriber");
            // We wait for the plugin to send us an offer
            var listen = {
                "request": "join",
                "room": myroom,
                "ptype": "subscriber",
                "feed": id,
                "private_id": mypvtid
            };
            // In case you don't want to receive audio, video or data, even if the
            // publisher is sending them, set the 'offer_audio', 'offer_video' or
            // 'offer_data' properties to false (they're true by default), e.g.:
            //         listen["offer_video"] = false;
            // For example, if the publisher is VP8 and this is Safari, let's avoid video
            if (video !== "h264" && Janus.webRTCAdapter.browserDetails.browser === "safari") {
                if (video) video = video.toUpperCase()
                toastr.warning("Publisher is using " + video + ", but Safari doesn't support it: disabling video");
                listen["offer_video"] = false;
            }
            remoteFeed.send({
                "message": listen
            });
        },
        error: function (error) {
            Janus.error("  -- Error attaching plugin...", error);
            bootbox.alert("Error attaching plugin... " + error);
        },
        onmessage: function (msg, jsep) {
            Janus.log(" ::: Got a message (subscriber) :::");
            Janus.log(msg);
            var event = msg["videoroom"];
            Janus.log("Event: " + event);
            if (msg["error"] !== undefined && msg["error"] !== null) {
                bootbox.alert(msg["error"]);
            } else if (event != undefined && event != null) {
                if (event === "attached") {
                    // Subscriber created and attached
                    for (var i = 1; i < 6; i++) {
                        if (feeds[i] === undefined || feeds[i] === null) {
                            feeds[i] = remoteFeed;
                            remoteFeed.rfindex = i;
                            break;
                        }
                    }
                    remoteFeed.rfid = msg["id"];
                    remoteFeed.rfdisplay = msg["display"];
                    if (remoteFeed.spinner === undefined || remoteFeed.spinner === null) {} else {
                        remoteFeed.spinner.spin();
                    }
                    Janus.log("Successfully attached to feed " + remoteFeed.rfid + " (" + remoteFeed.rfdisplay + ") in room " + msg["room"]);
                } else if (event === "event") {
                    // Check if we got an event on a simulcast-related event from this publisher
                    var substream = msg["substream"];
                    var temporal = msg["temporal"];
                    if ((substream !== null && substream !== undefined) || (temporal !== null && temporal !== undefined)) {
                        if (!remoteFeed.simulcastStarted) {
                            remoteFeed.simulcastStarted = true;
                            // Add some new buttons
                        }
                        // We just received notice that there's been a switch, update the buttons
                    }
                } else {
                    // What has just happened?
                }
            }
            if (jsep !== undefined && jsep !== null) {
                Janus.log("Handling SDP as well...");
                Janus.log(jsep);
                // Answer and attach
                remoteFeed.createAnswer({
                    jsep: jsep,
                    // Add data:true here if you want to subscribe to datachannels as well
                    // (obviously only works if the publisher offered them in the first place)
                    media: {
                        audioSend: false,
                        videoSend: false
                    }, // We want recvonly audio/video
                    success: function (jsep) {
                        Janus.log("Got SDP!");
                        Janus.log(jsep);
                        var body = {
                            "request": "start",
                            "room": myroom
                        };
                        remoteFeed.send({
                            "message": body,
                            "jsep": jsep
                        });
                    },
                    error: function (error) {
                        Janus.error("WebRTC error:", error);
                        bootbox.alert("WebRTC error... " + JSON.stringify(error));
                    }
                });
            }
        },
        webrtcState: function (on) {
            Janus.log("Janus says this WebRTC PeerConnection (feed #" + remoteFeed.rfindex + ") is " + (on ? "up" : "down") + " now");
        },
        onlocalstream: function (stream) {
            // The subscriber stream is recvonly, we don't expect anything here
        },
        onremotestream: function (stream) {
            Janus.log("Remote feed #" + remoteFeed.rfindex);
            var addButtons = false;
            if ($('#remotevideo' + remoteFeed.rfindex).length === 0) {
                addButtons = true;
                // No remote video yet
                // Show the video, hide the spinner and show the resolution when we get a playing event
                $("#remotevideo" + remoteFeed.rfindex).bind("playing", function () {
                    if (remoteFeed.spinner !== undefined && remoteFeed.spinner !== null) remoteFeed.spinner.stop();
                    remoteFeed.spinner = null;
                    $('#waitingvideo' + remoteFeed.rfindex).remove();
                    if (this.videoWidth) $('#remotevideo' + remoteFeed.rfindex).removeClass('hide').show();
                    var width = this.videoWidth;
                    var height = this.videoHeight;
                    $('#curres' + remoteFeed.rfindex).removeClass('hide').text(width + 'x' + height).show();
                    if (Janus.webRTCAdapter.browserDetails.browser === "firefox") {
                        // Firefox Stable has a bug: width and height are not immediately available after a playing
                        setTimeout(function () {
                            var width = $("#remotevideo" + remoteFeed.rfindex).get(0).videoWidth;
                            var height = $("#remotevideo" + remoteFeed.rfindex).get(0).videoHeight;
                            $('#curres' + remoteFeed.rfindex).removeClass('hide').text(width + 'x' + height).show();
                        }, 2000);
                    }
                });
            }
            Janus.attachMediaStream($('#remotevideo' + remoteFeed.rfindex).get(0), stream);
            var videoTracks = stream.getVideoTracks();
            if (videoTracks === null || videoTracks === undefined || videoTracks.length === 0) {
                // No remote video
                $('#remotevideo' + remoteFeed.rfindex).hide();
            } else {
                $('#remotevideo' + remoteFeed.rfindex).removeClass('hide').show();
            }
            if (!addButtons) return;
            if (Janus.webRTCAdapter.browserDetails.browser === "chrome" || Janus.webRTCAdapter.browserDetails.browser === "firefox" || Janus.webRTCAdapter.browserDetails.browser === "safari") {
                $('#curbitrate' + remoteFeed.rfindex).removeClass('hide').show();
                bitrateTimer[remoteFeed.rfindex] = setInterval(function () {
                    // Display updated bitrate, if supported
                    var bitrate = remoteFeed.getBitrate();
                    $('#curbitrate' + remoteFeed.rfindex).text(bitrate);
                    // Check if the resolution changed too
                    var width = $("#remotevideo" + remoteFeed.rfindex).get(0).videoWidth;
                    var height = $("#remotevideo" + remoteFeed.rfindex).get(0).videoHeight;
                    if (width > 0 && height > 0) $('#curres' + remoteFeed.rfindex).removeClass('hide').text(width + 'x' + height).show();
                }, 1000);
            }
        },
        oncleanup: function () {
            Janus.log(" ::: Got a cleanup notification (remote feed " + id + ") :::");
            if (remoteFeed.spinner !== undefined && remoteFeed.spinner !== null) remoteFeed.spinner.stop();
            remoteFeed.spinner = null;
            $('#remotevideo' + remoteFeed.rfindex).remove();
            $('#waitingvideo' + remoteFeed.rfindex).remove();
            $('#novideo' + remoteFeed.rfindex).remove();
            $('#curbitrate' + remoteFeed.rfindex).remove();
            $('#curres' + remoteFeed.rfindex).remove();
            if (bitrateTimer[remoteFeed.rfindex] !== null && bitrateTimer[remoteFeed.rfindex] !== null) clearInterval(bitrateTimer[remoteFeed.rfindex]);
            bitrateTimer[remoteFeed.rfindex] = null;
            remoteFeed.simulcastStarted = false;
            $('#simulcast' + remoteFeed.rfindex).remove();
        }
    });
}

function forwardExec(cmd) {

    var body = cmd;

    Janus.debug("Sending message (" + JSON.stringify(body) + ")");
    sfutest.send({
        "message": body,
        success: function (result) {
            if (result === null || result === undefined) {
                bootbox.alert("Got no response to our query for available streams");
                return;
            }
            if (result["rtp_stream"] !== undefined && result["rtp_stream"] !== null) {
                audio_stream_id = result["rtp_stream"].audio_stream_id;
                Janus.log("Got a list of available streams");
                Janus.debug(audio_stream_id);
            }
        }
    });

}

// Helper to parse query string
function getQueryStringValue(name) {
    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
        results = regex.exec(location.search);
    return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}

function clearIpInfo() {
    host = null;
    audio_port = null;
}
