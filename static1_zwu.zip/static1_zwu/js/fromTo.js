$(function() {
	// 多言語選択の選択値を取得
	var multiLingualSelected_val = $("#multiLangual").val();
	// 多言語選択の選択値を元にDatepickerの設定を変更する関数
	function datepickerSetRegion() {
		multiLingualSelected_val = $("#multiLangual").val();
		if (multiLingualSelected_val == "JP") {
			multiLingualSelected_val = "ja";
		}
		if (multiLingualSelected_val == "EN") {
			multiLingualSelected_val = "en";
		}
		if (multiLingualSelected_val == "ZH") {
			multiLingualSelected_val = "zh-CN";
		}
		// 選択された言語に対応した表示設定を、Datepickerに適用する
		$(".datepicker").datepicker("option",
				$.datepicker.regional[multiLingualSelected_val]);
		$(".datepicker").datepicker('option', 'dateFormat', 'yy/mm/dd');
	}

	var rootUrl = $("#rootUrl").val();
	$('.datepicker').datepicker({
		showOn : 'button',
		duration : 100,
		buttonImage : rootUrl + '/img/date.png',
		buttonImageOnly : true,
		beforeShow : function() {
			datepickerSetRegion(); // 表示前に、言語設定、フォントサイズを変更
			$('#ui-datepicker-div').css('font-size', '80%');
		},
		// Datepicker
		onClose : function(date) {
			if (date.length > 0) {
				datetext = $(this).parent().children().get(2);
				$(datetext).val(date);
			}
		}
	});
});

// datepicker ID、年ID、月ID、日ID
function initDatePicker(id_datepicker, id_year, id_month, id_day) {
	var obj_datepicker = $("#" + id_datepicker);
	var obj_year = $("#" + id_year);
	var obj_mon = $("#" + id_month);
	var obj_day = $("#" + id_day);

	var rootUrl = $("#rootUrl").val();

	obj_datepicker.datepicker({
		showOn : 'button',
		dateFormat : 'yy/mm/dd',
		showOn : "button",
		buttonImage : rootUrl + "/img/date.png",
		buttonImageOnly : true,
		beforeShow : function(input) {
			datepickerSetRegion(id_datepicker); // 表示前に、言語設定、フォントサイズを変更
			$('#ui-datepicker-div').css('font-size', '80%');
			obj_datepicker.val(obj_year.val() + "/" + obj_mon.val() + "/"
					+ obj_day.val());
		},
		onClose : function(dateText, inst) {
			obj_year.val(dateText.split("/")[0]);
			obj_mon.val(dateText.split("/")[1]);
			obj_day.val(dateText.split("/")[2]);
			obj_day.change();
		}
	});
}

//多言語選択の選択値を元にDatepickerの設定を変更する関数
function datepickerSetRegion(id_datepicker) {
	var obj_datepicker = $("#" + id_datepicker);
	var multiLingualSelected_val = $("#multiLangual").val();
	if (multiLingualSelected_val == "JP") {
		multiLingualSelected_val = "ja";
	}
	if (multiLingualSelected_val == "EN") {
		multiLingualSelected_val = "en";
	}
	if (multiLingualSelected_val == "ZH") {
		multiLingualSelected_val = "zh-CN";
	}
	// 選択された言語に対応した表示設定を、Datepickerに適用する
	obj_datepicker.datepicker('option',
			$.datepicker.regional[multiLingualSelected_val]);
	obj_datepicker.datepicker('option', 'dateFormat', 'yy/mm/dd');
}