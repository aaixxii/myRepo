package jp.co.nec.aim.mm.sessionbeans;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.aim.mm.dao.DmTemplateDao;
import jp.co.nec.aim.mm.dao.FEJobDao;
import jp.co.nec.aim.mm.dm.client.DmJobPostManager;
import jp.co.nec.aim.mm.entities.FeJobQueueEntity;

@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class DmServiceBean {
	
	private static Logger log = LoggerFactory.getLogger(DmServiceBean.class);
	
	@PersistenceContext(unitName = "aim-db")
	private EntityManager manager;	
	
	@Resource(mappedName = "java:jboss/MySqlDS")
	private DataSource dataSource;
	
	private DmTemplateDao dmo;
	private FEJobDao feJobDao;

	public DmServiceBean() {
		// zero-arg ctor for container.
	}

	@PostConstruct
	public void init() {
		dmo = new DmTemplateDao(dataSource);
		feJobDao = new FEJobDao(manager, dataSource);
	}

	public String getSegIdBioIdByRefId(String refId) {
		return dmo.getBioIdByRefId(refId);
	}
	
	public byte[] getTemplate(String refId) {
		List<FeJobQueueEntity> resultList = null;
		try {
			resultList = feJobDao.getExResult(refId);
		} catch (Exception e) {			
		}
		
		if (resultList != null && resultList.size() > 0) {
			FeJobQueueEntity feEntity = resultList.get(0);
			byte[] templateData = feEntity.getTempalteData();
			if (templateData != null && templateData.length > 1) {
				return templateData;
			}			
		}
		
		String segIdAndBioId = "";
		try {
			segIdAndBioId = dmo.getBioIdByRefId(refId);
		} catch (Exception e) {			
		}
		
		if (StringUtils.isBlank(segIdAndBioId)) {
			log.warn("Can't found segId, bioId for refId({})", refId);
			return null;
		}
		Long segId = Long.valueOf(segIdAndBioId.split(":")[0]);
		Long bioId =  Long.valueOf(segIdAndBioId.split(":")[1]);
		if (segId == null || bioId == null) {
			log.warn("Got segId is null or  bioId is null");
			return null;
		}
//		String baseUrl = UidDmJobRunManager.getOneActiveDm();
//		baseUrl = baseUrl.endsWith("/") ? baseUrl : baseUrl +"/";
//		String url = baseUrl + jp.co.nec.aim.mm.constants.Constants.dmGetTemplate;	
		byte [] result = null;
		try {
			result = DmJobPostManager.tryGetTemplateFromDm(segId, bioId);
			//result = DmJobPoster.getTemplate(url, segId, bioId);
		} catch (Exception e) {
			log.error(e.getMessage() , e);
			result = null;					
		}	
		return result;
	}	

}
