package jp.co.nec.aim.mm.dao;

import java.util.Map;
import javax.sql.DataSource;
import org.springframework.jdbc.core.JdbcTemplate;

public class DmTemplateDao {
	
	private DataSource dataSource;

	private JdbcTemplate jdbcTemplate;

	public DmTemplateDao(DataSource ds) {
		this.dataSource = ds;
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	private static final String sql = "select ps.BIOMETRICS_ID, s.SEGMENT_ID from PERSON_BIOMETRICS ps,SEGMENTS s where ps.EXTERNAL_ID=? and  ps.BIOMETRICS_ID BETWEEN s.BIO_ID_START and s.BIO_ID_END";
	
	public String getBioIdByRefId(String refId) {
		Map<String, Object> resltMap = jdbcTemplate.queryForMap(sql, new Object[] {refId});
		if (resltMap.size() < 1) return null;
		Long bioId = (Long) resltMap.get("BIOMETRICS_ID");
		Long segId = (Long) resltMap.get("SEGMENT_ID");
		if (bioId == null || segId == null) return null;
		return segId.toString() + ":" +  bioId.toString();		
	}
}
