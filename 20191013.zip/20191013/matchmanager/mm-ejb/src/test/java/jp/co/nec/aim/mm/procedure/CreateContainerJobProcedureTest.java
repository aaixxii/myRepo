package jp.co.nec.aim.mm.procedure;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.sql.DataSource;
import javax.transaction.Transactional;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class CreateContainerJobProcedureTest {
	@Resource
	private DataSource dataSource;

	@Resource
	private JdbcTemplate jdbcTemplate;

	private CreateContainerJobProcedure createContainerJobProcedure;

	@Before
	public void setUp() throws Exception {
		createContainerJobProcedure = new CreateContainerJobProcedure(
				dataSource);
		jdbcTemplate.update("delete from job_queue");
		jdbcTemplate.update("delete from fusion_jobs");
		jdbcTemplate.update("delete from segments");
		jdbcTemplate.update("delete from container_jobs");
		jdbcTemplate
				.update("insert into job_queue(JOB_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_URL,CALLBACK_STYLE,TIMEOUTS,FAILURE_COUNT,REMAIN_JOBS,FAMILY_ID)values(1,1,1,123,'11111',0,10,0,0,1)");
		jdbcTemplate.update("commit");
	}

	@After
	public void tearDown() throws Exception {
		jdbcTemplate.update("delete from job_queue");
		jdbcTemplate.update("delete from fusion_jobs");
		jdbcTemplate.update("delete from segments");
		jdbcTemplate.update("delete from container_jobs");
		jdbcTemplate.update("commit");
	}

	@Test
	public void testExcute() {
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(1,1,1,1,83,1,1,1,83)");
		byte[] inquiryJobData = { 1, 1, 3 };
		List<Integer> containerIds = new ArrayList<Integer>();
		containerIds.add(1);
		createContainerJobProcedure.setContainerIds(containerIds);
		createContainerJobProcedure.setInquiryJobData(inquiryJobData);
		createContainerJobProcedure.setJobId(new Long(1));
		createContainerJobProcedure.setSearchRequestIndex(1);
		createContainerJobProcedure.setFunctionId(1);
		createContainerJobProcedure.execute();

		List<Map<String, Object>> listContainerJobs = jdbcTemplate
				.queryForList("select * from container_jobs");
		Assert.assertEquals(1, listContainerJobs.size());
		Map<String, Object> mapContainerJobs = listContainerJobs.get(0);
		Assert.assertEquals(1, Integer.parseInt(mapContainerJobs.get(
				"CONTAINER_ID").toString()));
		List<Map<String, Object>> listFusionJobs = jdbcTemplate
				.queryForList("select * from fusion_jobs");
		Assert.assertEquals(1, listFusionJobs.size());
		Map<String, Object> mapFusionJobs = listFusionJobs.get(0);
		Assert.assertEquals(1,
				Integer.parseInt(mapFusionJobs.get("FUNCTION_ID").toString()));
		byte[] bytes = (byte[]) mapFusionJobs.get("INQUIRY_JOB_DATA");
		Assert.assertEquals(3, bytes.length);
		int index = 0;
		for (byte data : bytes) {
			Assert.assertEquals(inquiryJobData[index++], data);
		}
		Assert.assertEquals(new Integer(0),
				createContainerJobProcedure.getEmptyJob());

	}

	@Test
	public void testExcuteContainerIds() {
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(1,1,1,1,83,1,1,1,83)");
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(2,1,1,1,83,1,1,1,83)");
		byte[] inquiryJobData = { 1, 2, 3 };
		List<Integer> containerIds = new ArrayList<Integer>();
		containerIds.add(1);
		containerIds.add(1);
		createContainerJobProcedure.setContainerIds(containerIds);
		createContainerJobProcedure.setInquiryJobData(inquiryJobData);
		createContainerJobProcedure.setJobId(new Long(1));
		createContainerJobProcedure.setSearchRequestIndex(1);
		createContainerJobProcedure.setFunctionId(1);
		createContainerJobProcedure.execute();

		List<Map<String, Object>> listContainerJobs = jdbcTemplate
				.queryForList("select * from container_jobs");
		Assert.assertEquals(1, listContainerJobs.size());
		Map<String, Object> mapContainerJobs = listContainerJobs.get(0);
		 Assert.assertEquals(1,
		 Integer.parseInt(mapContainerJobs.get("CONTAINER_ID").toString()));

		List<Map<String, Object>> listFusionJobs = jdbcTemplate
				.queryForList("select * from fusion_jobs");
		Assert.assertEquals(1, listFusionJobs.size());
		Map<String, Object> mapFusionJobs = listFusionJobs.get(0);
		Assert.assertEquals(1,
				Integer.parseInt(mapFusionJobs.get("FUNCTION_ID").toString()));
		byte[] bytes = (byte[]) mapFusionJobs.get("INQUIRY_JOB_DATA");
		Assert.assertEquals(3, bytes.length);
		int index = 0;
		for (byte data : bytes) {
			Assert.assertEquals(inquiryJobData[index++], data);
		}
		Assert.assertEquals(new Integer(0),
				createContainerJobProcedure.getEmptyJob());

	}

}
