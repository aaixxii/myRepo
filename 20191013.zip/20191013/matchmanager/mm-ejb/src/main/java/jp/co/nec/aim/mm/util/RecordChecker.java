package jp.co.nec.aim.mm.util;

import jp.co.nec.aim.mm.acceptor.Record;
import jp.co.nec.aim.mm.exception.AimRuntimeException;

/**
 * RecordChecker
 * 
 * @author liuyq
 * 
 */
public class RecordChecker {

	/**
	 * checkRecord
	 * 
	 * @param r
	 *            the instance of Record
	 */
	public static void checkRecord(Record r) {
		byte[] binary = r.getBinary();
		if (binary == null || binary.length <= 0) {
			throw new AimRuntimeException(
					"template binary to a stored extraction result must be given. "
							+ "it cannot be null.");
		}
	}
}
