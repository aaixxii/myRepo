package jp.co.nec.aim.mm.exception;

public class DistributorExcception extends AimRuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2191304681764962498L;

	public DistributorExcception() {
	}

	public DistributorExcception(Throwable ex) {
		super(ex);
	}

	public DistributorExcception(String detail, Throwable ex) {
		super(detail, ex);
	}

}
