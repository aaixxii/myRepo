package jp.co.nec.aim.mm.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the CONTAINERS database table.
 * 
 */
@Entity
@Table(name = "CONTAINERS")
public class ContainerEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "containers_generator", sequenceName = "CONTAINERS_SEQ")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "containers_generator")
	@Column(name = "CONTAINER_ID")
	private int containerId;

	@Column(name = "CONTAINER_NAME")
	private String containerName;

	@Column(name = "FORMAT_ID")
	private Integer formatId;

	@Column(name = "MAX_SEGMENT_SIZE")
	private Long maxSegmentSize;

	@Column(name = "MIN_MU_NUM_FOR_SLB")
	private Integer minMuNumForSlb;

	@Column(name = "MIN_REDUNDANCY")
	private Integer minRedundancy;

	@Column(name = "SCOPE_ID")
	private long scopeId;

	public ContainerEntity() {
	}

	public int getContainerId() {
		return this.containerId;
	}

	public void setContainerId(int containerId) {
		this.containerId = containerId;
	}

	public String getContainerName() {
		return this.containerName;
	}

	public void setContainerName(String containerName) {
		this.containerName = containerName;
	}

	public long getFormatId() {
		return this.formatId;
	}

	public void setFormatId(Integer formatId) {
		this.formatId = formatId;
	}

	public Long getMaxSegmentSize() {
		return this.maxSegmentSize;
	}

	public void setMaxSegmentSize(Long maxSegmentSize) {
		this.maxSegmentSize = maxSegmentSize;
	}

	public Integer getMinMuNumForSlb() {
		return this.minMuNumForSlb;
	}

	public void setMinMuNumForSlb(Integer minMuNumForSlb) {
		this.minMuNumForSlb = minMuNumForSlb;
	}

	public Integer getMinRedundancy() {
		return this.minRedundancy;
	}

	public void setMinRedundancy(Integer minRedundancy) {
		this.minRedundancy = minRedundancy;
	}

	public long getScopeId() {
		return this.scopeId;
	}

	public void setScopeId(long scopeId) {
		this.scopeId = scopeId;
	}

}