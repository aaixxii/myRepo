package jp.co.nec.aim.mm.procedure;

import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import jp.co.nec.aim.mm.extract.planner.MuRemainLots;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

/**
 * assign one lot jobs to mu.
 * 
 * @author xiazp
 *
 */
public class ProcessOneMuLotProcedure extends StoredProcedure {
	private static final String PROCESS_ONE_MU_LOT_SQL = "MATCH_MANAGER_API.PROCESS_ONE_MU_LOT";

	public ProcessOneMuLotProcedure(DataSource dataSource) {
		setDataSource(dataSource);
		setSql(PROCESS_ONE_MU_LOT_SQL);
		declareParameter(new SqlParameter("p_mu_id", Types.BIGINT));
		declareParameter(new SqlParameter("p_number_of_extractors",
				Types.BIGINT));
		declareParameter(new SqlOutParameter("l_lot_job_id", Types.BIGINT));
		compile();
	}

	public Long processOneMuList(MuRemainLots muRemainLots)
			throws DataAccessException, SQLException {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("p_mu_id", muRemainLots.getMuId());
		map.put("p_number_of_extractors", muRemainLots.getNumOfExtractor());
		Map<String, Object> resultMap = execute(map);
		Long lotJobId = (Long) resultMap.get("l_lot_job_id");
		return lotJobId;
	}
}
