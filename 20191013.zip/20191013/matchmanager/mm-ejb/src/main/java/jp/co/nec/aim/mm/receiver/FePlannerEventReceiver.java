package jp.co.nec.aim.mm.receiver;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.EJB;
import javax.ejb.MessageDriven;

import jp.co.nec.aim.mm.constants.Constants;
import jp.co.nec.aim.mm.constants.JNDIConstants;
import jp.co.nec.aim.mm.extract.planner.FEPlannerManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * listening and receive jms in FEPlannerQueue then clear all jms in this queue
 * starting extract planner to creating extract plans
 * 
 * @author xiazp
 */
@MessageDriven(name = "FePlannerEventReceiver", activationConfig = {
		@ActivationConfigProperty(propertyName = "destinationLookup", propertyValue = JNDIConstants.EXTRACT_JOB_PLANNER_QUEUE),
		@ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Queue"),
		@ActivationConfigProperty(propertyName = "maxSessions", propertyValue = Constants.PLAN_MAX_SESSION) })
public class FePlannerEventReceiver extends AbstractEventReceiver {
	private static Logger logger = LoggerFactory
			.getLogger(FePlannerEventReceiver.class);
	@EJB
	FEPlannerManager planManager;

	@Override
	protected void dispatchEvent() {
		try {
			planManager.makeFEPlans();
		} catch (Exception e) {
			logger.error("Exception when do makePlans.", e);
		}
	}
}
