drop table segment_change_log;

CREATE TABLE segment_change_log (
  segment_change_id BIGINT(38) ,
  biometrics_id BIGINT(38)  NOT NULL,
  external_id VARCHAR(36),
  template_data BLOB  NULL,   
  segment_id BIGINT(38)  NOT NULL ,
  segment_version BIGINT(38)  NOT NULL ,
  change_type INT(4)  NOT NULL,   #new:0,insert:1,delete:2,update:3 
  update_ts DATE  NOT NULL,
  PRIMARY KEY (segment_change_id,update_ts)
) 
PARTITION BY HASH(MOD(day(update_ts),7))
PARTITIONS 7;

insert into segment_change_log(segment_change_id, biometrics_id, external_id,segment_id,segment_version,change_type,update_ts ) values (2,2,'4',5,5,1,'2020-05-7');


select 
  partition_name part,  
  partition_expression expr,  
  partition_description descr,  
  table_rows  
from information_schema.partitions  where 
  table_schema = schema()  
  and table_name='segment_change_log';  

 	part	expr	descr	table_rows
	p0	MOD(day(update_ts),7)		1
	p1	MOD(day(update_ts),7)		1
	p2	MOD(day(update_ts),7)		1
	p3	MOD(day(update_ts),7)		1
	p4	MOD(day(update_ts),7)		1
	p5	MOD(day(update_ts),7)		1
	p6	MOD(day(update_ts),7)		1



ALTER TABLE segment_change_log 
PARTITION BY HASH(mod(update_ts +mod(mod(update_ts,7)-mod(update_ts,10)+ 10,10),10))
PARTITIONS 10;

ALTER TABLE segment_change_log 
PARTITION BY HASH(mod(day(update_ts)+4 +mod(mod(day(update_ts)+4,7)-mod(day(update_ts)+4,10)+ 10,10),10))
PARTITIONS 10;

mysql> ALTER TABLE clients COALESCE PARTITION 4;
Query OK, 0 rows affected (0.02 sec)

