package com.nec.aim.dm.dmservice.dispatch;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nec.aim.dm.dmservice.persistence.NodeRepository;

import jp.co.nec.aim.message.proto.AIMMessages.PBDmSyncRequest;

@Service
public class Dispatcher {
	
	@Autowired
	NodeRepository nodeRepository;
	
	public boolean dipatchRequest(PBDmSyncRequest dmSegReq) {
		nodeRepository
		return false;
		
		
	}

}
