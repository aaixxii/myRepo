package com.nec.aim.dm.dmservice.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Data
@Component
@ConfigurationProperties(prefix = "curator")
public class ZkpConfigProperties {

    private int retryCount;

    private int elapsedTimeMs;

    private String connectString;

    private int sessionTimeoutMs;

    private int connectionTimeoutMs;
    
    private String namespace;
    
    private String savePath;
    
    private String charset;
    
    private String heatbeatNode;
    
    private String dbAcessNode;
}  



