package com.nec.aim.dm.dmservice.persistence;

import java.util.List;
import java.util.Optional;

import com.nec.aim.dm.dmservice.entity.Node;

public interface NodeRepository {
	List<Node> findAll();
	Optional<Node> findById(Long id);

}
