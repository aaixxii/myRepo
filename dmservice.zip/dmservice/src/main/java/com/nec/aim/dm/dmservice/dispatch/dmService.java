package com.nec.aim.dm.dmservice.dispatch;

import java.sql.SQLException;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nec.aim.dm.dmservice.exception.DmServiceException;
import com.nec.aim.dm.dmservice.persistence.DmConfigRepository;
import com.nec.aim.dm.dmservice.persistence.NodeStorageManagerRepository;
import com.nec.aim.dm.dmservice.socket.HeartBeatSocketServer;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class dmService {	

	@Autowired
	NodeStorageManagerRepository nodeStorageManagerRepository;
	
	@Autowired
	DmConfigRepository dmConfigRepository;
	

	@PostConstruct
	public void getSetting() {
		try {				
			nodeStorageManagerRepository.getNodeStorageUrlAndId();
			int redundancy = dmConfigRepository.getRedundancy();
			if (redundancy < 1) {
				throw new DmServiceException("redundancy is less 1!");
			}
			DmServiceManager.setRedundancy(redundancy);
		} catch (SQLException e) {
			log.error(e.getMessage());
		}
	}

	@PreDestroy
	public void close() {
		DmServiceManager.close();
		HeartBeatSocketServer.getInstance().close();
	}
}
