package com.nec.aim.dm.dmservice.config;

import org.apache.curator.RetryPolicy;
import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.CuratorFrameworkFactory;
import org.apache.curator.framework.state.ConnectionState;
import org.apache.curator.retry.ExponentialBackoffRetry;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import lombok.extern.slf4j.Slf4j;

@Configuration
@Slf4j
public class ZkpConfiguration {
	
	@Autowired
	ZkpConfigProperties zkpConfig;
	
	@Bean(initMethod = "start")
	 public CuratorFramework curatorFramework() {
		RetryPolicy retryPolicy = new ExponentialBackoffRetry(1000, 3);
		CuratorFramework CLIENT = CuratorFrameworkFactory
				.builder()
				.connectString(zkpConfig.getConnectString())
				.sessionTimeoutMs(5000)
				.connectionTimeoutMs(5000)
				.retryPolicy(retryPolicy)				
				.namespace(zkpConfig.getNamespace()).build();
		CLIENT.getConnectionStateListenable().addListener((client, state) -> {
			if (state == ConnectionState.LOST) {
				log.info("lost session with zookeeper");
			} else if (state == ConnectionState.CONNECTED) {
				log.info("Success to connected with zookeeper");
			} else if (state == ConnectionState.RECONNECTED) {
				log.info("reconnected with zookeeper");
			}
		});	
		return CLIENT;
	}
}
