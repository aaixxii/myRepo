package com.nec.aim.dm.dmservice.persistence;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.nec.aim.dm.dmservice.entity.Node;

@Repository
public class JdbcNodeRepository implements NodeRepository{
	
	@Autowired
    private JdbcTemplate jdbcTemplate;

	@Override
	public List<Node> findAll() {	
		RowMapper<Node> nodeRowMapper = (rs, rowNum) -> {
		    Node node = new Node();
		    node.setId(rs.getLong("id"));
		    node.setAddress(rs.getString("address"));
		    node.setDiskSize(rs.getInt("disk_size"));
		    node.setSpace(rs.getInt("space"));
		    node.setStatus(rs.getInt("status"));
		    node.setTs(rs.getTimestamp("TS"));
		    return node;
		};		
		return jdbcTemplate.query("select all from node",  nodeRowMapper);
	}

	@Override
	public Optional<Node> findById(Long id) {		
		return null;
	}
	

	
	RowMapper<Node> nodeRowMapper = (rs, rowNum) -> {
	    Node node = new Node();
	    node.setId(rs.getLong("id"));
	    node.setAddress(rs.getString("address"));
	    node.setDiskSize(rs.getInt("disk_size"));
	    node.setSpace(rs.getInt("space"));
	    node.setStatus(rs.getInt("status"));
	    node.setTs(rs.getTimestamp("TS"));
	    return node;
	};
	
	

}
