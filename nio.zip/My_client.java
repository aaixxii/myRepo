import java.net.*;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.nio.charset.Charset;
import java.nio.channels.Selector;
import java.nio.channels.spi.SelectorProvider;
import java.nio.channels.SelectionKey;
import java.util.Iterator;
import java.util.Set;

public class My_client {

	public static void main(String[] args)
	{
		SocketChannel clientChannel;
		MyBasic	mine = new MyBasic();
		int	ret;

		clientChannel=mine.ClientSocket("127.0.0.1",4545);
		if (clientChannel==null)
		{
			System.out.println("No connection to server, exit.");
			System.exit(0);
		}

		//	��Thread��LM-X�����A�����ŕ��򂷂�

		ret=mine.MonitorSocket(clientChannel);
		if (ret<0)
		{
			System.out.println("Socket ERROR Event -- you have othe bug in program");
			System.exit(0);	//�ʃ��x���̃o�O��E�o���ׂ�
		}
		System.out.println("Socket event catch.");
		System.exit(0); //	�I���ł悢�A��M����̏ꍇ�A�����Ŋg�� -> RecvStrictly
	}
}
