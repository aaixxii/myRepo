import java.net.*;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.nio.charset.Charset;
import java.nio.channels.Selector;
import java.nio.channels.spi.SelectorProvider;
import java.nio.channels.SelectionKey;
import java.util.Iterator;
import java.util.Set;

public class My_server{


	public static void main(String[] args)
	{
		MyBasic	mine = new MyBasic();
		ServerSocketChannel serverChannel;
		SocketChannel clientChannel;

		serverChannel=mine.SeverSocket("0.0.0.0",4545);
		if (serverChannel != null)
			System.out.println ("Booted .....");

		clientChannel=mine.WaitConnection(serverChannel);
		if (clientChannel != null)
			System.out.println ("Connected .....");

		for (;;)
		{
			int ret=mine.MonitorSocket(clientChannel);
			//	if recv == 0 connection lost
			System.out.println ("Client messaging or disconnection.");
			int len=mine.RecvStrictly(clientChannel,100);
			if (len <1)
			{
				System.out.println ("Client closed. it's over.");
				//clientChannel.close();
				break;
			}
			else
			{
				System.out.println ("Client message=  [......]");
			}
		}
	}
}

