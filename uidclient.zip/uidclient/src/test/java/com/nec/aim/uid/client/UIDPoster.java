package com.nec.aim.uid.client;

import java.io.ByteArrayInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.json.JSONObject;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;
import com.googlecode.protobuf.format.JsonFormat;
import com.nec.aim.uid.client.util.FileUtil;
import com.nec.aim.uid.client.util.ProtobufCreater;
import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;
import com.squareup.okhttp.Response;

import jp.co.nec.aim.message.proto.BatchTypeProto.BatchType;
import jp.co.nec.aim.message.proto.BusinessMessage.E_BIOMETRIC_DATA_FORMAT;
import jp.co.nec.aim.message.proto.BusinessMessage.E_REQUESET_TYPE;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBiometricElement;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBiometricsData;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBusinessMessage;
import jp.co.nec.aim.message.proto.BusinessMessage.PBRequest;
import jp.co.nec.aim.message.proto.BusinessMessage.PBTemplateInfo;
import jp.co.nec.aim.message.proto.ExtractService.ExtractRequest;
import jp.co.nec.aim.message.proto.ExtractService.ExtractResponse;
import jp.co.nec.aim.message.proto.InquiryService.IdentifyRequest;
import jp.co.nec.aim.message.proto.InquiryService.IdentifyResponse;
import jp.co.nec.aim.message.proto.JobCommonService.PBDeleteJobRequest;
import jp.co.nec.aim.message.proto.SyncService.SyncRequest;
import jp.co.nec.aim.message.proto.SyncService.SyncResponse;

public class UIDPoster {
    private static final MediaType MEDIA_TYPE_PLAINTEXT = MediaType.parse("text/plain; charset=utf-8");
    
    private ProtobufCreater protobufCreater = new ProtobufCreater();
    
    private static AtomicLong lastBatchJobId;
    
    private static AtomicLong lastReqeustId;
    
    private static AtomicLong lastEnrollmentId;
    
    private String sequecFilePath;
    
    @Before
    public void setUp() throws Exception {
        URL url = Thread.currentThread().getContextClassLoader().getResource("uid.sequece.properties");
        sequecFilePath = url.getPath();
        PropertiesConfiguration propsConfig = new PropertiesConfiguration();
        propsConfig.setEncoding("UTF-8");
        propsConfig.load(sequecFilePath);
        long batchJobId = propsConfig.getLong("BATCH_JOB_ID");
        lastBatchJobId = new AtomicLong(batchJobId);
        long reqeustId = propsConfig.getLong("REQUEST_Id");
        lastReqeustId = new AtomicLong(reqeustId);
        long enrollmentId = propsConfig.getLong("ENROLLMENT_ID");
        lastEnrollmentId = new AtomicLong(enrollmentId);
        propsConfig = null;
    }
    
    @After
    public void tearDown() throws Exception {
        try {
            PropertiesConfiguration properties = new PropertiesConfiguration(sequecFilePath);
            properties.setProperty("BATCH_JOB_ID", String.valueOf(lastBatchJobId.get()));
            properties.setProperty("REQUEST_Id", String.valueOf(lastReqeustId.get()));
            properties.setProperty("ENROLLMENT_ID", String.valueOf(lastEnrollmentId.incrementAndGet()));
            properties.save();
            properties = null;
        } catch (ConfigurationException e) {
            System.out.println(e.getMessage());
        }
    }
    
    @Test
    public void RepeatExtractTest() throws IOException, InterruptedException {
        for (int i = 0 ; i < 50; i++) {
            try {
                testExtract_duplicate();
            } catch (InvalidProtocolBufferException e) {                
                e.printStackTrace();
            } catch (IOException e) {
               
                e.printStackTrace();
            } catch (InterruptedException e) {
              
                e.printStackTrace();
            }
        }        
        testExtract();
    }    
    
   // @Test
    public void testExtract_duplicate() throws IOException, InterruptedException {
        String enrollId = "REQ_" + String.format("%032d", lastEnrollmentId.incrementAndGet());
       
        ExtractRequest extReq = protobufCreater.createExtractRequest_dup(
            String.valueOf(lastReqeustId.incrementAndGet()), enrollId);
        // FileOutputStream fo = new FileOutputStream("C:\\Users\\000001A006PBP\\Desktop\\test\\extReq.dat");
        // extReq.writeTo(fo);
        for (int i = 0; i< 3; i++) {
            OkHttpClient client = new OkHttpClient();
            client.setReadTimeout(1000, TimeUnit.MINUTES);
            Request request = new Request.Builder()
                .url("http://10.197.23.100:8827/matchmanager/AIMExtractService/extract")            
                // .url("http://127.0.0.1:8080/matchmanager/AIMExtractService/extract")
                .post(RequestBody.create(MEDIA_TYPE_PLAINTEXT, extReq.toByteArray())).build();
            try {
                Response response = client.newCall(request).execute();           
                ExtractResponse extRes = ExtractResponse.parseFrom(response.body().bytes());
                PBBusinessMessage psMsg = PBBusinessMessage.parseFrom(extRes.getBusinessMessage(0));          
                byte[] result = psMsg.getDataBlock().getTemplateInfo().getData().toByteArray();
                FileUtil.saveBinaryToFile("C:\\Users\\000001A006PBP\\Desktop\\test1\\ext_result.bat", result); 
                System.out.println("ExtractResponse:");
                System.out.println("batchJobId:" + extRes.getBatchJobId());
                System.out.println("batchType:" + extRes.getType());            
                System.out.println(psMsg.toString());
               
            } catch (IOException e) {
                e.printStackTrace();
            }            
        }
    }
    
    @Test
    public void RepeatExtractOKTest() throws IOException, InterruptedException {
        for (int i = 0 ; i < 20; i++) {
            try {
                testExtract();
            } catch (InvalidProtocolBufferException e) {                
                e.printStackTrace();
            } catch (IOException e) {
               
                e.printStackTrace();
            } catch (InterruptedException e) {
              
                e.printStackTrace();
            }
        }        
        testExtract();
    }    
    
    @Test
    public void testExtract() throws IOException, InterruptedException {
        String enrollId = "REQ_" + String.format("%032d", lastEnrollmentId.incrementAndGet());
        ExtractRequest extReq = protobufCreater.createExtractRequest(lastBatchJobId.incrementAndGet(),
            String.valueOf(lastReqeustId.incrementAndGet()), enrollId);
        // FileOutputStream fo = new FileOutputStream("C:\\Users\\000001A006PBP\\Desktop\\test\\extReq.dat");
        // extReq.writeTo(fo);
        OkHttpClient client = new OkHttpClient();
        client.setReadTimeout(1000, TimeUnit.MINUTES);
        Request request = new Request.Builder()
            .url("http://10.197.23.100:8882/matchmanager/AIMExtractService/extract")            
            // .url("http://127.0.0.1:8080/matchmanager/AIMExtractService/extract")
            .post(RequestBody.create(MEDIA_TYPE_PLAINTEXT, extReq.toByteArray())).build();
        try {
            Response response = client.newCall(request).execute();           
            ExtractResponse extRes = ExtractResponse.parseFrom(response.body().bytes());
            PBBusinessMessage psMsg = PBBusinessMessage.parseFrom(extRes.getBusinessMessage(0));          
            byte[] result = psMsg.getDataBlock().getTemplateInfo().getData().toByteArray();
            FileUtil.saveBinaryToFile("C:\\Users\\000001A006PBP\\Desktop\\test1\\ext_result.bat", result); 
            System.out.println("ExtractResponse:");
            System.out.println("batchJobId:" + extRes.getBatchJobId());
            System.out.println("batchType:" + extRes.getType());            
            System.out.println(psMsg.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    @Test
    public void testExtract_path_miss() throws IOException, InterruptedException {
        String enrollId = "REQ_" + String.format("%032d", lastEnrollmentId.incrementAndGet());
        ExtractRequest.Builder extReq = ExtractRequest.newBuilder();
        extReq.setBatchJobId(lastBatchJobId.incrementAndGet());
        extReq.setType(BatchType.EXTRACT);
        PBBusinessMessage.Builder pbMsg = PBBusinessMessage.newBuilder();           
        PBRequest.Builder pq = PBRequest.newBuilder();      
        pq.setRequestId(String.valueOf(lastReqeustId.incrementAndGet()));
        pq.setEnrollmentId(enrollId);     
        pq.setRequestType(E_REQUESET_TYPE.INSERT_REFID_DEFAULT);
        PBBiometricsData.Builder pdBiData = PBBiometricsData.newBuilder();
        pdBiData.setDataFormat(E_BIOMETRIC_DATA_FORMAT.BIOMETRIC_INLINE_FIR);
        PBBiometricElement.Builder pbEl = PBBiometricElement.newBuilder();
        pbEl.setFilePath("http://192.168.22.117/UID/DownLoad/Image/FingerLess/file/9999888.tar");
        pbEl.setChecksum("e453d4650f180f121b308af1e9270381");
        pdBiData.setBiometricElement(pbEl.build());
        pq.setBiometricsData(pdBiData.build());
        pbMsg.setRequest(pq.build());
        extReq.addBusinessMessage(pbMsg.build().toByteString());
        
        OkHttpClient client = new OkHttpClient();
        client.setReadTimeout(1000, TimeUnit.MINUTES);
        Request request = new Request.Builder()
            .url("http://10.197.23.100:8882/matchmanager/AIMExtractService/extract")            
            // .url("http://127.0.0.1:8080/matchmanager/AIMExtractService/extract")
            .post(RequestBody.create(MEDIA_TYPE_PLAINTEXT, extReq.build().toByteArray())).build();
        try {
            Response response = client.newCall(request).execute();           
            ExtractResponse extRes = ExtractResponse.parseFrom(response.body().bytes());
            PBBusinessMessage psMsg = PBBusinessMessage.parseFrom(extRes.getBusinessMessage(0));
            System.out.println("ExtractResponse:");
            System.out.println("batchJobId:" + extRes.getBatchJobId());
            System.out.println("batchType:" + extRes.getType());            
            System.out.println(psMsg.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    @Test
    public void testExtract_check_sum_miss() throws IOException, InterruptedException {
        String enrollId = "REQ_" + String.format("%032d", lastEnrollmentId.incrementAndGet());
        ExtractRequest.Builder extReq = ExtractRequest.newBuilder();
        extReq.setBatchJobId(lastBatchJobId.incrementAndGet());
        extReq.setType(BatchType.EXTRACT);
        PBBusinessMessage.Builder pbMsg = PBBusinessMessage.newBuilder();           
        PBRequest.Builder pq = PBRequest.newBuilder();      
        pq.setRequestId(String.valueOf(lastReqeustId.incrementAndGet()));
        pq.setEnrollmentId(enrollId);     
        pq.setRequestType(E_REQUESET_TYPE.INSERT_REFID_DEFAULT);
        PBBiometricsData.Builder pdBiData = PBBiometricsData.newBuilder();
        pdBiData.setDataFormat(E_BIOMETRIC_DATA_FORMAT.BIOMETRIC_INLINE_FIR);
        PBBiometricElement.Builder pbEl = PBBiometricElement.newBuilder();
        pbEl.setFilePath("http://192.168.22.117/UID/DownLoad/Image/FingerLess/file/9999999.tar");
        pbEl.setChecksum("1234");
        pdBiData.setBiometricElement(pbEl.build());
        pq.setBiometricsData(pdBiData.build());
        pbMsg.setRequest(pq.build());
        extReq.addBusinessMessage(pbMsg.build().toByteString());
        
        OkHttpClient client = new OkHttpClient();
        client.setReadTimeout(1000, TimeUnit.MINUTES);
        Request request = new Request.Builder()
            .url("http://10.197.23.100:8882/matchmanager/AIMExtractService/extract")            
            // .url("http://127.0.0.1:8080/matchmanager/AIMExtractService/extract")
            .post(RequestBody.create(MEDIA_TYPE_PLAINTEXT, extReq.build().toByteArray())).build();
        try {
            Response response = client.newCall(request).execute();           
            ExtractResponse extRes = ExtractResponse.parseFrom(response.body().bytes());
            PBBusinessMessage psMsg = PBBusinessMessage.parseFrom(extRes.getBusinessMessage(0));
            System.out.println("ExtractResponse:");
            System.out.println("batchJobId:" + extRes.getBatchJobId());
            System.out.println("batchType:" + extRes.getType());            
            System.out.println(psMsg.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    @Test
    public void testExtract_DeL() throws IOException, InterruptedException {
        String enrollId = "REQ_00000000000000000000000000000117";
        PBDeleteJobRequest.Builder dleReq = PBDeleteJobRequest.newBuilder();
        dleReq.setReferenceId(enrollId);
        OkHttpClient client = new OkHttpClient();
        client.setReadTimeout(10, TimeUnit.MINUTES);
        Request request = new Request.Builder()
            .url("http://10.197.23.100:8882/matchmanager/AIMExtractService/deleteJob")
            // .url("http://127.0.0.1:8080/matchmanager/AIMExtractService/extract")
            .post(RequestBody.create(MEDIA_TYPE_PLAINTEXT, dleReq.build().toByteArray())).build();
        try {
            Response response = client.newCall(request).execute();
            System.out.println(response.isSuccessful());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    @Test
    public void testInquiry_DeL() throws IOException, InterruptedException {
        String enrollId = "REQ_00000000000000000000000000000080";
        PBDeleteJobRequest.Builder dleReq = PBDeleteJobRequest.newBuilder();
        dleReq.setReferenceId(enrollId);
        OkHttpClient client = new OkHttpClient();
        client.setReadTimeout(10, TimeUnit.MINUTES);
        Request request = new Request.Builder()
            .url("http://10.197.23.100:8882/matchmanager/AIMInquiryService/deleteJob")
            // .url("http://127.0.0.1:8080/matchmanager/AIMExtractService/extract")
            .post(RequestBody.create(MEDIA_TYPE_PLAINTEXT, dleReq.build().toByteArray())).build();
        try {
            Response response = client.newCall(request).execute();
            System.out.println(response.isSuccessful());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    @Test
    public void testExtract_Clear() throws IOException, InterruptedException {
        OkHttpClient client = new OkHttpClient();
        client.setReadTimeout(10, TimeUnit.MINUTES);
        Request request = new Request.Builder()
            .url("http://10.197.23.100:8882/matchmanager/AIMExtractService/clearJobs")
            // .url("http://127.0.0.1:8080/matchmanager/AIMExtractService/extract")
            .get().build();
        try {
            Response response = client.newCall(request).execute();
            System.out.println(response.isSuccessful());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    @Test
    public void testInquiry_Clear() throws IOException, InterruptedException {
        OkHttpClient client = new OkHttpClient();
        client.setReadTimeout(10, TimeUnit.MINUTES);
        Request request = new Request.Builder()
            .url("http://10.197.23.100:8882/matchmanager/AIMInquiryService/clearJobs")
            // .url("http://127.0.0.1:8080/matchmanager/AIMExtractService/extract")
            .get().build();
        try {
            Response response = client.newCall(request).execute();
            System.out.println(response.isSuccessful());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    @Test
    public void testSyncByRefUrl_dup() throws InvalidProtocolBufferException {
        String enrollId = "REQ_" + String.format("%032d", lastEnrollmentId.incrementAndGet());
        SyncRequest syncReq = protobufCreater.createInsertRequest_dup(
            String.valueOf(lastReqeustId.incrementAndGet()), enrollId, E_REQUESET_TYPE.INSERT_REFURL_DEFAULT);  
        for (int i = 0; i < 5; i++) {
            OkHttpClient client = new OkHttpClient();
            client.setReadTimeout(10, TimeUnit.MINUTES);
            Request request = new Request.Builder()
                .url("http://10.197.23.100:8882/matchmanager/AIMSyncService/sync")
                // .url("http://127.0.0.1:8080/matchmanager/AIMSyncService/sync")
                .post(RequestBody.create(MEDIA_TYPE_PLAINTEXT, syncReq.toByteArray())).build();
            try {
                Response response = client.newCall(request).execute();
                SyncResponse synRes = SyncResponse.parseFrom(response.body().bytes());
                System.out.println("SyncResponse:");
                System.out.println("batchJobId:" + synRes.getBatchJobId());
                System.out.println("batchType:" + synRes.getType());
                System.out.println(synRes.getBatchJobId());
                System.out.println(synRes.getType());
                PBBusinessMessage psMsg = PBBusinessMessage.parseFrom(synRes.getBusinessMessage(0));
                System.out.println(psMsg.toString());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }  
    }      
    
    @Test
    public void RepeatSyncOKTest() throws IOException, InterruptedException {
        for (int i = 0 ; i < 10; i++) {
            try {
                testSyncByRefUrl();
            } catch (InvalidProtocolBufferException e) {                
                e.printStackTrace();
            } 
        }        
       
    }    
    
    @Test
    public void testSyncByRefUrl() throws InvalidProtocolBufferException {
        String enrollId = "REQ_" + String.format("%032d", lastEnrollmentId.incrementAndGet());
        SyncRequest syncReq = protobufCreater.createInsertRequest(lastBatchJobId.incrementAndGet(),
            String.valueOf(lastReqeustId.incrementAndGet()), enrollId, E_REQUESET_TYPE.INSERT_REFURL_DEFAULT);    
            OkHttpClient client = new OkHttpClient();
            client.setReadTimeout(10, TimeUnit.MINUTES);
            Request request = new Request.Builder()
                .url("http://10.197.23.100:8882/matchmanager/AIMSyncService/sync")
                // .url("http://127.0.0.1:8080/matchmanager/AIMSyncService/sync")
                .post(RequestBody.create(MEDIA_TYPE_PLAINTEXT, syncReq.toByteArray())).build();
            try {
                Response response = client.newCall(request).execute();
                SyncResponse synRes = SyncResponse.parseFrom(response.body().bytes());
                System.out.println("SyncResponse:");
                System.out.println("batchJobId:" + synRes.getBatchJobId());
                System.out.println("batchType:" + synRes.getType());
                System.out.println(synRes.getBatchJobId());
                System.out.println(synRes.getType());
                PBBusinessMessage psMsg = PBBusinessMessage.parseFrom(synRes.getBusinessMessage(0));
                System.out.println(psMsg.toString());
            } catch (IOException e) {
                e.printStackTrace();
            }
    }
    
    @Test
    public void testSyncByRefUrl_path_miss() throws InvalidProtocolBufferException {
        String enrollId = "REQ_" + String.format("%032d", lastEnrollmentId.incrementAndGet());       
        E_REQUESET_TYPE reqType = E_REQUESET_TYPE.INSERT_REFURL_DEFAULT;
        SyncRequest.Builder insertReq = SyncRequest.newBuilder();
        insertReq.setBatchJobId(lastEnrollmentId.incrementAndGet());
        insertReq.setType(BatchType.ENROLL);
        PBBusinessMessage.Builder pbMsg = PBBusinessMessage.newBuilder();       
        PBRequest.Builder pq = PBRequest.newBuilder();
        pq.setRequestId(String.valueOf(lastReqeustId.incrementAndGet()));
        pq.setEnrollmentId(enrollId);
        pq.setRequestType(reqType); 
        PBBiometricsData.Builder pdBiData = PBBiometricsData.newBuilder();
        pdBiData.setDataFormat(E_BIOMETRIC_DATA_FORMAT.BIOMETRIC_INLINE_FIR);
        PBBiometricElement.Builder pbEl = PBBiometricElement.newBuilder();
        if (reqType == E_REQUESET_TYPE.INSERT_REFID_DEFAULT) {
            PBTemplateInfo.Builder template = PBTemplateInfo.newBuilder();
            template.setReferenceId(enrollId);
        } else if (reqType == E_REQUESET_TYPE.INSERT_REFURL_DEFAULT) {
            pbEl.setFilePath("http://192.168.22.117/UID/DownLoad/Image/FingerLess/file/9999888.tar");
            pbEl.setChecksum("e453d4650f180f121b308af1e9270381");
        }       
        pdBiData.setBiometricElement(pbEl.build());
        pq.setBiometricsData(pdBiData.build());
        pbMsg.setRequest(pq.build());
        insertReq.addBusinessMessage(pbMsg.build().toByteString());        
        OkHttpClient client = new OkHttpClient();
        client.setReadTimeout(10, TimeUnit.MINUTES);
        Request request = new Request.Builder()
            .url("http://10.197.23.100:8882/matchmanager/AIMSyncService/sync")
            // .url("http://127.0.0.1:8080/matchmanager/AIMSyncService/sync")
            .post(RequestBody.create(MEDIA_TYPE_PLAINTEXT, insertReq.build().toByteArray())).build();
        try {
            Response response = client.newCall(request).execute();
            SyncResponse synRes = SyncResponse.parseFrom(response.body().bytes());
            System.out.println("SyncResponse:");
            System.out.println("batchJobId:" + synRes.getBatchJobId());
            System.out.println("batchType:" + synRes.getType());
            System.out.println(synRes.getBatchJobId());
            System.out.println(synRes.getType());
            PBBusinessMessage psMsg = PBBusinessMessage.parseFrom(synRes.getBusinessMessage(0));
            System.out.println(psMsg.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    @Test
    public void testSyncByRefUrl_checkSum_miss() throws InvalidProtocolBufferException {
        String enrollId = "REQ_" + String.format("%032d", lastEnrollmentId.incrementAndGet());       
        E_REQUESET_TYPE reqType = E_REQUESET_TYPE.INSERT_REFURL_DEFAULT;
        SyncRequest.Builder insertReq = SyncRequest.newBuilder();
        insertReq.setBatchJobId(lastEnrollmentId.incrementAndGet());
        insertReq.setType(BatchType.ENROLL);
        PBBusinessMessage.Builder pbMsg = PBBusinessMessage.newBuilder();       
        PBRequest.Builder pq = PBRequest.newBuilder();
        pq.setRequestId(String.valueOf(lastReqeustId.incrementAndGet()));
        pq.setEnrollmentId(enrollId);
        pq.setRequestType(reqType); 
        PBBiometricsData.Builder pdBiData = PBBiometricsData.newBuilder();
        pdBiData.setDataFormat(E_BIOMETRIC_DATA_FORMAT.BIOMETRIC_INLINE_FIR);
        PBBiometricElement.Builder pbEl = PBBiometricElement.newBuilder();
        if (reqType == E_REQUESET_TYPE.INSERT_REFID_DEFAULT) {
            PBTemplateInfo.Builder template = PBTemplateInfo.newBuilder();
            template.setReferenceId(enrollId);
        } else if (reqType == E_REQUESET_TYPE.INSERT_REFURL_DEFAULT) {
            pbEl.setFilePath("http://192.168.22.117/UID/DownLoad/Image/FingerLess/file/9999999.tar");
            pbEl.setChecksum("123");
        }       
        pdBiData.setBiometricElement(pbEl.build());
        pq.setBiometricsData(pdBiData.build());
        pbMsg.setRequest(pq.build());
        insertReq.addBusinessMessage(pbMsg.build().toByteString());        
        OkHttpClient client = new OkHttpClient();
        client.setReadTimeout(10, TimeUnit.MINUTES);
        Request request = new Request.Builder()
            .url("http://10.197.23.100:8882/matchmanager/AIMSyncService/sync")
            // .url("http://127.0.0.1:8080/matchmanager/AIMSyncService/sync")
            .post(RequestBody.create(MEDIA_TYPE_PLAINTEXT, insertReq.build().toByteArray())).build();
        try {
            Response response = client.newCall(request).execute();
            SyncResponse synRes = SyncResponse.parseFrom(response.body().bytes());
            System.out.println("SyncResponse:");
            System.out.println("batchJobId:" + synRes.getBatchJobId());
            System.out.println("batchType:" + synRes.getType());
            System.out.println(synRes.getBatchJobId());
            System.out.println(synRes.getType());
            PBBusinessMessage psMsg = PBBusinessMessage.parseFrom(synRes.getBusinessMessage(0));
            System.out.println(psMsg.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    } 
  
    @Test
    public void testSyncByRefID_dup() {
        String enrollId = "REQ_00000000000000000000000000000039";
        SyncRequest syncReq = protobufCreater.createInsertRequest_dup(
            String.valueOf(lastReqeustId.incrementAndGet()), enrollId, E_REQUESET_TYPE.INSERT_REFID_DEFAULT);
        for (int i = 0; i < 3; i++) {
            OkHttpClient client = new OkHttpClient();
            client.setReadTimeout(5, TimeUnit.MINUTES);
            client.setConnectTimeout(10, TimeUnit.MINUTES);
            Request request = new Request.Builder()
                .url("http://10.197.23.100:8882/matchmanager/AIMSyncService/sync")
                // .url("http://127.0.0.1:8080/matchmanager/AIMSyncService/sync")
                .post(RequestBody.create(MEDIA_TYPE_PLAINTEXT, syncReq.toByteArray())).build();
            try {
                Response response = client.newCall(request).execute();
                SyncResponse synRes = SyncResponse.parseFrom(response.body().bytes());
                System.out.println("SyncResponse:");
                System.out.println("batchJobId:" + synRes.getBatchJobId());
                System.out.println("batchType:" + synRes.getType());
                PBBusinessMessage psMsg = PBBusinessMessage.parseFrom(synRes.getBusinessMessage(0));
                System.out.println(psMsg.toString());
                System.out.println("okokok");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }        
    }
    
    @Test   
    public void testSyncByRefID() {
        String enrollId = "REQ_00000000000000000000000000000064";
        SyncRequest syncReq = protobufCreater.createInsertRequest(lastBatchJobId.incrementAndGet(),
            String.valueOf(lastReqeustId.incrementAndGet()), enrollId, E_REQUESET_TYPE.INSERT_REFID_DEFAULT);      
            OkHttpClient client = new OkHttpClient();
            client.setReadTimeout(5, TimeUnit.MINUTES);
            client.setConnectTimeout(10, TimeUnit.MINUTES);
            Request request = new Request.Builder()
                .url("http://10.197.23.100:8882/matchmanager/AIMSyncService/sync")
                // .url("http://127.0.0.1:8080/matchmanager/AIMSyncService/sync")
                .post(RequestBody.create(MEDIA_TYPE_PLAINTEXT, syncReq.toByteArray())).build();
            try {
                Response response = client.newCall(request).execute();
                SyncResponse synRes = SyncResponse.parseFrom(response.body().bytes());
                System.out.println("SyncResponse:");
                System.out.println("batchJobId:" + synRes.getBatchJobId());
                System.out.println("batchType:" + synRes.getType());
                PBBusinessMessage psMsg = PBBusinessMessage.parseFrom(synRes.getBusinessMessage(0));
                System.out.println(psMsg.toString());
            } catch (IOException e) {
                e.printStackTrace();
            }
       
    }
    
    @Test
    public void RepeatIdentifyByRefTempalteTest() {
        for (int i = 0 ; i < 5; i++) {
            try {
                testIdentifyByRefTempalte();
            } catch (InvalidProtocolBufferException e) {                
                e.printStackTrace();
            }
        }
    } 
    
    //@Test
    public void testIdentifyByRefTempalte() throws InvalidProtocolBufferException {
       // String enrollId = "REQ_" + String.format("%032d", lastEnrollmentId.incrementAndGet());
        IdentifyRequest iqyReq = protobufCreater.createIdentifyRequest(lastBatchJobId.incrementAndGet(),
            String.valueOf(lastReqeustId.incrementAndGet()), null, E_REQUESET_TYPE.IDENTIFY_DEFAULT);
        OkHttpClient client = new OkHttpClient();
        client.setReadTimeout(5, TimeUnit.MINUTES);
        Request request = new Request.Builder()
            .url("http://10.197.23.100:8882/matchmanager/AIMInquiryService/inquiry")
            // .url("http://127.0.0.1:8080/matchmanager/AIMInquiryService/inquiry")
            .post(RequestBody.create(MEDIA_TYPE_PLAINTEXT, iqyReq.toByteArray())).build();
        try {
            Response response = client.newCall(request).execute();
            IdentifyResponse iqyRes = IdentifyResponse.parseFrom(response.body().bytes());
            System.out.println("IdentifyResponse:");
            System.out.println("batchJobId:" + iqyRes.getBatchJobId());
            System.out.println("batchType:" + iqyRes.getType());
            PBBusinessMessage psMsg = PBBusinessMessage.parseFrom(iqyRes.getBusinessMessage(0));
            System.out.println(psMsg.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    @Test
    public void testIdentifyByRefTempalte_err() throws InvalidProtocolBufferException {
        String enrollId = "REQ_00000000000000000000000000000021";
        E_REQUESET_TYPE type = E_REQUESET_TYPE.IDENTIFY_DEFAULT;
        IdentifyRequest.Builder iqyReq = IdentifyRequest.newBuilder();
        iqyReq.setBatchJobId(lastBatchJobId.incrementAndGet());
        iqyReq.setType(BatchType.IDENTIFY);
        PBBusinessMessage.Builder pbMsg = PBBusinessMessage.newBuilder();           
        PBRequest.Builder pq = PBRequest.newBuilder();
        pq.setRequestId( String.valueOf(lastReqeustId.incrementAndGet()));
      
        pq.setRequestType(type);
        pq.setMaxResults(10);
        pq.setTargetFpir(1);
        PBBiometricsData.Builder pdBiData = PBBiometricsData.newBuilder();
        pdBiData.setDataFormat(E_BIOMETRIC_DATA_FORMAT.BIOMETRIC_INLINE_FIR);
        PBBiometricElement.Builder pbEl = PBBiometricElement.newBuilder();
        PBTemplateInfo.Builder template = PBTemplateInfo.newBuilder();
        if (type == E_REQUESET_TYPE.IDENTIFY_REFID_DEFAULT) {           
            template.setReferenceId(enrollId);            
        } else if (type == E_REQUESET_TYPE.IDENTIFY_DEFAULT) {         
           byte[] templateData =  "/C:/Users/000001A006PBP/Desktop/test/133_template_data".getBytes();
            template.setData(ByteString.copyFrom(templateData));
        }
        pbEl.setTemplateInfo(template.build());
        pdBiData.setBiometricElement(pbEl.build());
        pq.setBiometricsData(pdBiData.build());
        pbMsg.setRequest(pq).build();
        iqyReq.addBusinessMessage(pbMsg.build().toByteString());      
        OkHttpClient client = new OkHttpClient();
        client.setReadTimeout(5, TimeUnit.MINUTES);
        Request request = new Request.Builder()
            .url("http://10.197.23.100:8882/matchmanager/AIMInquiryService/inquiry")
            // .url("http://127.0.0.1:8080/matchmanager/AIMInquiryService/inquiry")
            .post(RequestBody.create(MEDIA_TYPE_PLAINTEXT, iqyReq.build().toByteArray())).build();
        try {
            Response response = client.newCall(request).execute();
            IdentifyResponse iqyRes = IdentifyResponse.parseFrom(response.body().bytes());
            System.out.println("IdentifyResponse:");
            System.out.println("batchJobId:" + iqyRes.getBatchJobId());
            System.out.println("batchType:" + iqyRes.getType());
            PBBusinessMessage psMsg = PBBusinessMessage.parseFrom(iqyRes.getBusinessMessage(0));
            System.out.println(psMsg.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    @Test
    public void RepeatIdentifyByRefIDTest() {
        for (int i = 0 ; i < 5; i++) {
            try {
                testIdentifyByRefID_dup();
            } catch (InvalidProtocolBufferException e) {                
                e.printStackTrace();
            }
        }
    } 
    
    @Test
    public void testIdentifyByRefID_dup() throws InvalidProtocolBufferException {
        String enrollId = "REQ_00000000000000000000000000000039";
        IdentifyRequest iqyReq = protobufCreater.createIdentifyRequest_dup(
            String.valueOf(lastReqeustId.incrementAndGet()), enrollId, E_REQUESET_TYPE.IDENTIFY_REFID_DEFAULT);
        OkHttpClient client = new OkHttpClient();
        client.setReadTimeout(5, TimeUnit.MINUTES);
        Request request = new Request.Builder()
            .url("http://10.197.23.100:8882/matchmanager/AIMInquiryService/inquiry")
            // .url("http://127.0.0.1:8080/matchmanager/AIMInquiryService/inquiry")
            .post(RequestBody.create(MEDIA_TYPE_PLAINTEXT, iqyReq.toByteArray())).build();
        try {
            Response response = client.newCall(request).execute();
            IdentifyResponse iqyRes = IdentifyResponse.parseFrom(response.body().bytes());
            System.out.println("IdentifyResponse:");
            System.out.println("batchJobId:" + iqyRes.getBatchJobId());
            System.out.println("batchType:" + iqyRes.getType());
            PBBusinessMessage psMsg = PBBusinessMessage.parseFrom(iqyRes.getBusinessMessage(0));
            System.out.println(psMsg.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    @Test
    public void RepeatIdentifyByRefIDOKTest() {
        for (int i = 0 ; i < 5; i++) {
            try {
                testIdentifyByRefID();
            } catch (InvalidProtocolBufferException e) {                
                e.printStackTrace();
            }
        }
    } 
    
    //@Test
    public void testIdentifyByRefID() throws InvalidProtocolBufferException {
        String enrollId = "REQ_00000000000000000000000000000064";
        IdentifyRequest iqyReq = protobufCreater.createIdentifyRequest(lastBatchJobId.incrementAndGet(),
            String.valueOf(lastReqeustId.incrementAndGet()), enrollId, E_REQUESET_TYPE.IDENTIFY_REFID_DEFAULT);
        OkHttpClient client = new OkHttpClient();
        client.setReadTimeout(5, TimeUnit.MINUTES);
        Request request = new Request.Builder()
            .url("http://10.197.23.100:8882/matchmanager/AIMInquiryService/inquiry")
            // .url("http://127.0.0.1:8080/matchmanager/AIMInquiryService/inquiry")
            .post(RequestBody.create(MEDIA_TYPE_PLAINTEXT, iqyReq.toByteArray())).build();
        try {
            Response response = client.newCall(request).execute();
            IdentifyResponse iqyRes = IdentifyResponse.parseFrom(response.body().bytes());
            System.out.println("IdentifyResponse:");
            System.out.println("batchJobId:" + iqyRes.getBatchJobId());
            System.out.println("batchType:" + iqyRes.getType());
            PBBusinessMessage psMsg = PBBusinessMessage.parseFrom(iqyRes.getBusinessMessage(0));
            System.out.println(psMsg.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    @Test
    public void testGson() {
        IdentifyResponse iqyRes = protobufCreater.createIdentifyResponse();
        Gson gson2 = new GsonBuilder().setPrettyPrinting().create();
        String prettyJson = gson2.toJson(iqyRes.toBuilder());
        System.out.println(prettyJson);
        try (FileWriter writer = new FileWriter("C:/Users/xia/Desktop/test/result.json")) {
            gson2.toJson(iqyRes.toBuilder(), writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    @Test
    public void testProtobufFromat() throws IOException {
        PBBusinessMessage pbmsg = protobufCreater.createPBBusinessMessage();
        JsonFormat jsonFormat = new JsonFormat();
        String asJson = jsonFormat.printToString(pbmsg);
        // System.out.print(asJson);
        InputStream in = new ByteArrayInputStream(asJson.getBytes("UTF-8"));
        PBBusinessMessage.Builder newPbMsg = PBBusinessMessage.newBuilder();
        jsonFormat.merge(in, newPbMsg);
        
        FileOutputStream outputStream = new FileOutputStream("C:/Users/xia/Desktop/test/data.json");
        // pbmsg.writeTo(outputStream);
        jsonFormat.print(pbmsg, outputStream);
        outputStream.close();
        
        try (FileWriter file = new FileWriter("C:/Users/xia/Desktop/test/xia.json")) {
            file.write(asJson);
            
        }
        JSONObject jsono = new JSONObject(asJson);
        try (FileWriter file = new FileWriter("C:/Users/xia/Desktop/test/xia3.json")) {
            jsono.write(file);
        }
    }
}
