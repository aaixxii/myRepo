package com.nec.aim.uid.client.common;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.UUID;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;



public class SequenceIdCreatorTest {
	
	public static final int SIZE_CHECKSUM = 1;
	public static final int SIZE_TSZ = 4;
	public static final int SIZE_TEMPLATE_ID = 8;
	public static final int SIZE_DELETE_FLAG = 1;
	public static final int SIZE_EXTERNAL_ID = 36;
	public static final int SIZE_EVENT_ID = 4;
	public static final int SIZE_TEMPLATE_HEADER = SIZE_TSZ + SIZE_TEMPLATE_ID
			+ SIZE_DELETE_FLAG + SIZE_EXTERNAL_ID + SIZE_EVENT_ID;
	public static final int SIZE_TEMPLATE_HEADER_CHECKSUM = SIZE_TEMPLATE_HEADER + SIZE_CHECKSUM; 

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}	
	
	@Test
	public void sequenceCreateTest() {		
		String refernceId = UUID.randomUUID().toString().toUpperCase();
		
		System.out.print(refernceId  + ":" + refernceId.length());
		
	}
	
	@Test
	public void templateTest() {
		byte byteValule = (byte)0;
		System.out.println(byteValule);
	}
	
	@Test
	public void prependHeaderTest() {
		 byte[] reuslt = prependHeader(1000, "testestte".getBytes(), "xia", -999);
		 System.out.println(reuslt);
		 System.out.print(new String(reuslt, StandardCharsets.UTF_8 ));
	}

	
	public  byte[] prependHeader(long templateId, byte[] templateData, String externalId, int eventId) {
		if(templateId <= 0L) {
			throw new IllegalArgumentException(
					"TemplateId must be positive long, it's " + templateId);
		}
		if (templateData == null) {
			throw new IllegalArgumentException(
					"Attempting to prepend header onto null template");
		}
		if(externalId == null) {
			throw new IllegalArgumentException("externalId is null!");
		}
		byte[] bytesOfExtId = externalId.getBytes(StandardCharsets.UTF_8);		
		int writeTtotalTemplateSize = SIZE_TEMPLATE_HEADER_CHECKSUM + templateData.length ;
		int totalTemplateSize = SIZE_TEMPLATE_HEADER;
		byte[] byteTempateArr = new byte[writeTtotalTemplateSize];
		ByteBuffer byteTemplate = ByteBuffer.wrap(byteTempateArr);
		byte[] emptyOneByte = new byte[1];
		byteTemplate.position(0);	
		byteTemplate.put(emptyOneByte); //checkSum
		byteTemplate.putInt(totalTemplateSize);
		byteTemplate.putLong(templateId);
		byte zero = 0;
		byteTemplate.put(zero); // delete flag
		byteTemplate.put(bytesOfExtId); 
		int blankExtIdSize = SIZE_EXTERNAL_ID - bytesOfExtId.length;			
		if (blankExtIdSize > 0) {
			byte[] mustWriteblankExtIdByte = new byte[blankExtIdSize];
			byteTemplate.put(mustWriteblankExtIdByte); 
		}
		if (eventId > 0)  {
			byteTemplate.putInt(eventId);
		} else {
			byteTemplate.put(new byte[SIZE_EVENT_ID]);
		}
		byteTemplate.put(templateData);	
		return byteTempateArr;			
	}
	
	public static byte getCheckSum(byte[] data) {
		return getCheckSum(data, 0);
	}

	
	public static byte getCheckSum(byte[] data, int offset) {
		byte result = 0;
		for (int i = offset; i < data.length; i++) {
			result ^= data[i];
		}
		return result;
	}

	
}
