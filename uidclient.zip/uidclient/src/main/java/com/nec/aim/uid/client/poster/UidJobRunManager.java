package com.nec.aim.uid.client.poster;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.aim.uid.client.manager.ExecutorManager;


public class UidJobRunManager {
	private static Logger logger = LoggerFactory.getLogger(UidJobRunManager.class);
	private  static final UidJobRunManager INSTANCE = new UidJobRunManager();	
	private static BlockingQueue<String> uidJobQueue;
	private static final List<String> pendingQueue = Collections.synchronizedList(new ArrayList<>());
	private static AtomicBoolean mustRun;
	
	public Consumer<List<String>>  jobConsumer = list -> {
		addJobtoMe(list);
	 }; 

	public UidJobRunManager() {		
	}
	
	public  void init(int currCount) {
		uidJobQueue = new ArrayBlockingQueue<>(currCount);	
		mustRun = new AtomicBoolean(true);
	}

	public static UidJobRunManager getInstance() {
		return INSTANCE;
	}
	
	private void addJobtoMe(List<String> paramterFiles) {
		logger.info("queue remaining capacity before add:{}", uidJobQueue.remainingCapacity());
		paramterFiles.forEach(one -> {
			if (!uidJobQueue.offer(one)) {
				pendingQueue.add(one);
				logger.info("added requst setting file:{}", one);
			}
		});
		logger.info("queue remaining capacity after add:{}", uidJobQueue.remainingCapacity());
	}
	
	public void runJob() {
	Runnable runnable = () -> {
		doJob();
		};
		Thread thread = new Thread(runnable);
		thread.start();
	}

	private void doJob() {
		while (mustRun.get()) {
			if (pendingQueue.size() > 0) {
				int removeAbleCount = Math.min(pendingQueue.size(), uidJobQueue.remainingCapacity());
				if (removeAbleCount < 1)
					continue;
				for (int i = 0; i < removeAbleCount; i++) {
					uidJobQueue.offer(pendingQueue.remove(i));
				}
			}
			try {
				String path = uidJobQueue.poll(100, TimeUnit.MILLISECONDS);				
				ExecutorManager excutor = ExecutorManager.getInstance();
				if (path != null) {
					if (path.contains("extract"))  {
						ExtractJobPoster postTask = new ExtractJobPoster(path);
						excutor.commitPostJobTask(postTask);						
					} else if (path.contains("identify")) {
						IdentifyJobPoster postTask = new IdentifyJobPoster(path);
						excutor.commitPostJobTask(postTask);						
					} else if (path.contains("sync")) {
						SyncJobPoster syncTask = new SyncJobPoster(path); 
						excutor.commitPostJobTask(syncTask);						
					}					
				}
				Thread.sleep(1000);
			} catch (Exception e) {
				logger.error(e.getMessage(), e);
			}
		}
	}
	
	public boolean isMustRun() {
		return mustRun.get();
	}

	public void setMustRun(boolean newMustRun) {
		mustRun.set(newMustRun);
	}
	
	public void shutdown () {
		setMustRun(false);
		uidJobQueue.clear();
		pendingQueue.clear();
	}
}
