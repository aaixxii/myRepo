package com.nec.aim.uid.client.main;

import static com.nec.aim.uid.client.common.UidClientConstants.CONCURRENT_THEAD_COUNT;
import static com.nec.aim.uid.client.common.UidClientConstants.JOB_REQUEST_PATH;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.aim.uid.client.common.SequenceIdCreator;
import com.nec.aim.uid.client.manager.ExecutorManager;
import com.nec.aim.uid.client.manager.UidCommonManager;
import com.nec.aim.uid.client.monitor.DirectoryMonitor;
import com.nec.aim.uid.client.poster.UidJobRunManager;

public class UidClientMain {
	private static Logger logger = LoggerFactory.getLogger(UidClientMain.class);
	private static final String START = "start";
	private static final String STOP = "stop";
	DirectoryMonitor monitor;

	public static void main(String[] args) {
		UidClientMain uidMain = new UidClientMain();
		uidMain.handleParameter(args);
	}

	private static void pringUsage() {
		String lineSeparater = System.getProperties().getProperty("line.separator");
		StringBuilder sb = new StringBuilder();
		sb.append(lineSeparater);
		sb.append("Pring usage:");
		sb.append(lineSeparater);
		sb.append(" Usage for start uid client with files or direcotry:");
		sb.append(lineSeparater);
		sb.append("  java -jar uidclient.jar 'parameter file path ...'");
		sb.append(lineSeparater);
		sb.append(" Usage for start uid client start no parameter files:");
		sb.append(lineSeparater);
		sb.append("  java -jar uidclient.jar");
		sb.append(lineSeparater);
		sb.append("  *no parameter file path means using files in directory of jobrequests.*");
		sb.append(lineSeparater);
		// sb.delete(0, sb.length());
		sb.append(" Usage for stop uid client:");
		sb.append(lineSeparater);
		sb.append("  java -jar uidclient.jar stop");
		logger.info(sb.toString());
	}

	private void handleParameter(String[] args) {
		Runnable runnable = () -> { 
			stop();
		};
		  Runtime.getRuntime().addShutdownHook(new Thread(runnable));
		if (START.equals(args[0].toLowerCase()) && args.length == 1) {
			start(null);
		} else if (START.equals(args[0].toLowerCase()) && args.length > 1) {
			start(args);
		} else if (STOP.equals(args[0].toLowerCase())) {
			stop();
		} else {
			pringUsage();
			System.exit(0);
		}
	}

	public void start(String[] filePaths) {
		System.setProperty("file.encoding", "UTF-8");
		UidCommonManager clietnManager = UidCommonManager.getInstance();
		if (clietnManager.getMapSize() == 0) {
			if (!clietnManager.getAllProperties()) {
				String errMsg = "There are some wrong in uid.client.properties. or isn't exist!. stop process!";
				logger.error(errMsg);
				System.exit(0);
			}
		}
		SequenceIdCreator.init();
		List<String> paramterFiles = new ArrayList<>();
		if (Objects.isNull(filePaths) || filePaths.length < 1) {
			// URL url =
			// this.getClass().getClassLoader().getResource("jobrequests");
			// String paramPath = url.getPath();
			String paramPath = UidCommonManager.getValue(JOB_REQUEST_PATH);
			File parmFile = new File(paramPath);
			if (parmFile.isDirectory()) {
				File[] fileArr = parmFile.listFiles();
				for (File afile : fileArr) {
					paramterFiles.add(afile.getAbsolutePath());
				}
			} else {
				paramterFiles.add(parmFile.getAbsolutePath());
			}

		} else {
			for (int i = 0; i < filePaths.length; i++) {
				File file = new File(filePaths[i]);
				if (file.isFile()) {
					paramterFiles.add(file.getAbsolutePath());
				} else if (file.isDirectory()) {
					File[] fileList = file.listFiles();
					for (File one : fileList) {
						paramterFiles.add(one.getAbsolutePath());
					}
				}
			}
		}
		int concurrentTheadCount = Integer.valueOf(UidCommonManager.getValue(CONCURRENT_THEAD_COUNT));
		UidJobRunManager jobRunManager = UidJobRunManager.getInstance();
		jobRunManager.init(concurrentTheadCount);
		jobRunManager.jobConsumer.accept(paramterFiles);
		jobRunManager.runJob();
		monitor = new DirectoryMonitor();
		ExecutorManager.getInstance().commitMonitorTask(monitor);	
		logger.info("uid client is started!");		
		
	}

	public void stop() {
		SequenceIdCreator.saveLastSequence();
		UidCommonManager.getInstance().shutdown();
		UidJobRunManager.getInstance().shutdown();
		monitor.setStop(true);
		logger.info("uidclient sucess shutdown.");
		System.exit(0);
	}

}
