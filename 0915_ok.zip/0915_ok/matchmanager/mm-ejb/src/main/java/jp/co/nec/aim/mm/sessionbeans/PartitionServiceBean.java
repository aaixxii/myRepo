package jp.co.nec.aim.mm.sessionbeans;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.aim.mm.dao.SystemInitDao;
import jp.co.nec.aim.mm.scheduler.QuartzManager;
import jp.co.nec.aim.mm.sessionbeans.pojo.AimManager;

@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class PartitionServiceBean {
	private static Logger logger = LoggerFactory.getLogger(PartitionServiceBean.class);

	@PersistenceContext(unitName = "aim-db")
	private EntityManager manager;

	@Resource(mappedName = "java:jboss/MySqlDS")
	private DataSource dataSource;		

	private SystemInitDao systemInitDao;

	public PartitionServiceBean() {
	}

	@PostConstruct
	public void init() {
		
		systemInitDao = new SystemInitDao(manager);
	}
	
	public void startPartition() {		
		QuartzManager quartzManager = QuartzManager.getInstance(manager);
		quartzManager.startSetTodayPnoJob();
		quartzManager.startRotationTask(); 		
		logger.info("mm  partition schduler started.");	
	}	
	
	
	public  void getSegChangeLogRotationData() {
		Long segChangeSaveDays = systemInitDao.getSegChangeLogSaveDays();
		Long adjust = systemInitDao.getInUsingAdjust();
		AimManager.saveSegChangeSaveDays(segChangeSaveDays);
		AimManager.saveInUsingAdjust(adjust);
	}
}
