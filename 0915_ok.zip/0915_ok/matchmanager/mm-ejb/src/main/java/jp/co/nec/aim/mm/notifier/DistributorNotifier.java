package jp.co.nec.aim.mm.notifier;

import jp.co.nec.aim.mm.exception.HttpPostException;
import jp.co.nec.aim.mm.util.HttpPoster;
import jp.co.nec.aim.mm.util.HttpResponseInfo;

import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * DistributorNotifier
 * 
 * @author liuyq
 * 
 */
public final class DistributorNotifier {

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(DistributorNotifier.class);

	private String url;
	private byte[] objectBytes;
	private Integer retryCount;

	public DistributorNotifier() {
	}

	public DistributorNotifier(String url, byte[] objectBytes,
			Integer retryCount) {
		this.url = url;
		this.objectBytes = objectBytes;
		this.retryCount = retryCount;
	}

	/**
	 * notifyMR
	 * 
	 * @return true notify MR successfully..
	 */
	public boolean notifyMR() {
		HttpResponseInfo ret = null;
		try {
			ret = HttpPoster.post(url, objectBytes, retryCount);
		} catch (HttpPostException e) {
			log.error("HttpPostException occurred when notify MR, URL {}..",
					url);
			return false;
		}

		if (ret != null && ret.getStatusCode() == HttpStatus.SC_OK) {
			log.info("Notify MR with specified URL: {} successfully..", url);
			return true;
		}

		return false;
	}
}
