package jp.co.nec.aim.mm.exception;

public class AimIdnetifyException extends AimErrorInfoException {

	private static final long serialVersionUID = -3791343799586727948L;

	/**
	 * @param errorCode
	 * @param description
	 * @param epochTime
	 * @param uidCode
	 */
	public AimIdnetifyException(String errorCode, String description,
			String epochTime, String uidCode) {
		super(errorCode, description, epochTime, uidCode);
	}
}
