package jp.co.nec.aim.mm.sessionbeans;

import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.sql.DataSource;

import jp.co.nec.aim.mm.procedure.GarbageSegChangeLogProcedure;
import jp.co.nec.aim.mm.util.StopWatch;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Stateless Bean to call garbage_segment_change_log()
 * 
 * @author jinxl
 * 
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class GarbageSegChangeLogBean {
	private static final Logger log = LoggerFactory
			.getLogger(GarbageSegChangeLogBean.class);

	@Resource(mappedName = "java:jboss/OracleDS")
	private DataSource dataSource;

	public void execute() {
		if (log.isDebugEnabled()) {
			log.debug("Start garbage SEGMENT_CHANGE_LOG.");
		}
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		try {
			GarbageSegChangeLogProcedure procedure = new GarbageSegChangeLogProcedure(
					dataSource);
			long rows = procedure.execute();
			log.info("GarbageSegChangeLogProcedure is executed, " + rows
					+ " records were removed.");
			if (log.isDebugEnabled()) {
				log.debug("Finish garbage SEGMENT_CHANGE_LOG.");
			}
		} finally {
			stopWatch.stop();
		}
	}

}