package com.nec.aim.uid.client.post;

import static com.nec.aim.uid.client.common.UidClientConstants.DM_CONCURRENT_COUNT;
import static com.nec.aim.uid.client.common.UidClientConstants.DM_POST_TIMEOUT;
import static com.nec.aim.uid.client.common.UidClientConstants.JOB_RESULT_PATH;
import static com.nec.aim.uid.client.common.UidClientConstants.JOB_TEMPLATES_PATH;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.protobuf.ByteString;
import com.nec.aim.uid.client.exception.UidClientException;
import com.nec.aim.uid.client.manager.UidCommonManager;
import com.nec.aim.uid.client.manager.UidDmJobRunManager;
import com.nec.aim.uid.client.proerties.PropertyNames;
import com.nec.aim.uid.client.util.FileUtil;
import com.nec.aim.uid.client.util.StopWatch;
import com.squareup.okhttp.Call;
import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;
import com.squareup.okhttp.Response;

import jp.co.nec.aim.message.proto.AIMEnumTypes.SegmentSyncCommandType;
import jp.co.nec.aim.message.proto.AIMMessages.PBDmSyncRequest;
import jp.co.nec.aim.message.proto.AIMMessages.PBDmSyncResponce;
import jp.co.nec.aim.message.proto.AIMMessages.PBTargetSegmentVersion;
import jp.co.nec.aim.message.proto.BusinessMessage.PBTemplateInfo;

public class DmJobPoster {
	private static Logger logger = LoggerFactory.getLogger(DmJobPoster.class);	
	private static final MediaType MEDIA_TYPE_PLAINTEXT = MediaType.parse("text/plain; charset=utf-8");	
	
	public static void addJobToDm(List<String> fileList) {
		String concurentJobCount = UidCommonManager.getValue(DM_CONCURRENT_COUNT);
		String userPostTimeOut = UidCommonManager.getValue(DM_POST_TIMEOUT);		
		if (fileList.size() == 1 && concurentJobCount != null && Integer.valueOf(concurentJobCount) > 0) {
			for (int i = 0; i< Integer.valueOf(concurentJobCount); i++) {
				 buildDmJobRequest(fileList.get(0));
			}
		} else {
			for (String one : fileList) {
				 buildDmJobRequest(one);
			}
		}		
	}
	
	private static void buildDmJobRequest(String dmRequestFile) {
		Properties prop = new Properties();		
		try (InputStream input = new FileInputStream(dmRequestFile)) {
			prop.load(input);
			String activeDmServices = UidDmJobRunManager.getOneActiveDm();
			if (activeDmServices == null || activeDmServices.isEmpty()) {
				logger.warn("No Active Dm Service!, Skip process.");
				return;
			}
			String dmUrl =  activeDmServices + "/dmSyncSegment";
			String dmDownLoadUrl = activeDmServices + "/seg/";
			String getTemplateBaseUrl = activeDmServices + "/getTemplate";	
			String getTemplateBaseUrlByRefId = activeDmServices + "/getTemplateByRefId";	
			String dmDownloadSegId = prop.getProperty(PropertyNames.DM_DOWNLOAD_SEG_ID.name());			
			if (dmDownloadSegId != null && !dmDownloadSegId.isEmpty() && !dmDownloadSegId.startsWith("-1")) {
				String httpGetUrl = dmDownLoadUrl + dmDownloadSegId;
				byte[] downloaded = getSegment(httpGetUrl, Long.valueOf(dmDownloadSegId));
				if (downloaded != null) {
					logger.info("Download segmentData from dm , data size  ={}", downloaded.length);
				} else {
					logger.warn("there are som worg, get empty data from dm service. segmentId={}, dm service url ={}", dmDownloadSegId, httpGetUrl );
				}
				String savePath = UidCommonManager.getValue(JOB_RESULT_PATH);
				savePath = savePath + "/download/"  + dmDownloadSegId;				
				File file = new File(savePath);
				file.getParentFile().mkdirs();
				FileUtil.saveBinaryToFile(downloaded, savePath);
				//Files.write(Paths.get(savePath), downloaded);				
				return;				
			}

			String dmReqCmd = prop.getProperty(PropertyNames.DM_REQ_CMD.name());
			if (dmReqCmd != null && !dmReqCmd.isEmpty() && !dmReqCmd.startsWith("-1")) {
				if (String.format(dmReqCmd).startsWith("GEG_TEMPLATE")) {
					String segId = prop.getProperty(PropertyNames.DM_REQ_SEG_ID.name());
					boolean segIdIsValid = segId != null && !segId.isEmpty() && !segId.startsWith("-1");
					String bioId = prop.getProperty("DM_REQ_BIO_ID");
					boolean bioIdIsValid = bioId != null && !bioId.isEmpty() && !bioId.startsWith("-1");
					String refId = prop.getProperty("DM_REQ_REF_ID");
					boolean refIdIsValid = refId != null && !refId.isEmpty() && !refId.startsWith("-1");					
					byte[] template = null;
					if (segIdIsValid && bioIdIsValid) {
						template = getTemplate(getTemplateBaseUrl, Long.valueOf(segId), Long.valueOf(bioId));
					} else {
						if (!refIdIsValid) {
							String errStr = "In getTemplate by refId, referenceId can't be null or empty";
							throw new  UidClientException(errStr);
						}
						template =getTemplate(getTemplateBaseUrlByRefId, refId);
					}
					if (template != null) {
						String savePath = UidCommonManager.getValue(JOB_RESULT_PATH);
						savePath = savePath + "/" + refId;
						FileUtil.saveBinaryToFile(template, savePath);
					}				
					return;
				}
			} 
			
			Long bioIdStart = null;				
			String dmReqBioIdStart = prop.getProperty(PropertyNames.DM_REQ_BIO_ID_START.name());
			if (dmReqBioIdStart != null && !dmReqBioIdStart.isEmpty() && !dmReqBioIdStart.startsWith("-1")) {
				bioIdStart = Long.valueOf(dmReqBioIdStart);
			}
			
			String dmReqBioIdEnd = prop.getProperty(PropertyNames.DM_REQ_BIO_ID_END.name());
			String[] bioIdEndArr = null;
			if (dmReqBioIdEnd != null && !dmReqBioIdEnd.isEmpty() && !dmReqBioIdEnd.startsWith("-1")) {
				bioIdEndArr = dmReqBioIdEnd.split(",");
			}
			
			String dmReqExternalId = prop.getProperty(PropertyNames.DM_REQ_REF_ID.name());	
			String[] extIdList = null;
			if (dmReqExternalId != null && !dmReqExternalId.isEmpty() && !dmReqExternalId.startsWith("-1")) {
				extIdList = dmReqExternalId.split(",");
				if (String.format(dmReqCmd).startsWith("INSERT") ) {
					if (extIdList.length != bioIdEndArr.length) {
						throw new  UidClientException("The count of DM_REQ_REF_ID is not equal the count of bioIdEnd!");			
					}	
				}
							
			}
			
			String dmReqTemplatePath = prop.getProperty(PropertyNames.DM_REQ_TEMPLATE_DATA_PATH.name());
			String[] temPathList = null;
			if (dmReqTemplatePath != null && !dmReqTemplatePath.isEmpty() && !dmReqTemplatePath.startsWith("-1")) {
				 temPathList = dmReqTemplatePath.split(",");
				 if (extIdList.length != bioIdEndArr.length) {
					 if (temPathList.length != bioIdEndArr.length) {
						 throw new  UidClientException("The count of DM_REQ_TEMPLATE_DATA_PATH is not equal the count of bioIdEnd!");
					 } 
				 }
			}			
			
			if (dmReqCmd != null  && bioIdEndArr.length > 0) {
				for (int i = 0; i < bioIdEndArr.length; i++) {
					PBDmSyncRequest.Builder dmRequest = PBDmSyncRequest.newBuilder();
					if (String.format(dmReqCmd).startsWith("INSERT")) {
						dmRequest.setCmd(SegmentSyncCommandType.valueOf(2));
					} else if (String.format(dmReqCmd).startsWith("DELETE")) {
						dmRequest.setCmd(SegmentSyncCommandType.valueOf(3));
					}  else if (String.format(dmReqCmd).startsWith("NEW")) {	
				    	 dmRequest.setCmd(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_NEW);
				    }
					if (bioIdStart != null) {
						dmRequest.setBioIdStart(bioIdStart);
					}
					
					dmRequest.setBioIdEnd(Long.valueOf(bioIdEndArr[i]));
					PBTemplateInfo.Builder templateInfo = PBTemplateInfo.newBuilder();	
					if (extIdList != null && extIdList.length > 0) {
						templateInfo.setReferenceId(extIdList[i]);
					}					
					
					if (dmRequest.getCmd().ordinal() == 1) {
						if ( dmReqTemplatePath == null || dmReqTemplatePath.isEmpty() || dmReqTemplatePath.startsWith("-1")) {
							String templatePath = UidCommonManager.getValue(JOB_TEMPLATES_PATH);
							File templateDir = new File(templatePath);
							String[] files = templateDir.list();
							byte[] data = FileUtil.getDataFromFile(templatePath + "/" + files[0]);
							templateInfo.setData(ByteString.copyFrom(data));
							logger.info("Get template data from default path:{}", templatePath);
						} else if (dmReqTemplatePath != null && !dmReqTemplatePath.isEmpty() && !dmReqTemplatePath.startsWith("-1")) {
							byte[] data = FileUtil.getDataFromFile(temPathList[i]);
							//byte[] data = FileUtil.getDataFromFile(dmReqTemplatePath);
							templateInfo.setData(ByteString.copyFrom(data));
							logger.info("Get template data from  path:{}", temPathList[i]);
						}
						dmRequest.setTemplateData(templateInfo.build());
					} 			

					PBTargetSegmentVersion.Builder segVerBuilder = PBTargetSegmentVersion.newBuilder();
					String baseDmReqSegVer = prop.getProperty(PropertyNames.DM_REQ_SEG_VER.name());
					if (baseDmReqSegVer != null && !baseDmReqSegVer.isEmpty()) {
						segVerBuilder.setVersion(Long.valueOf(baseDmReqSegVer) + i);
					}
					String dmReqSegId = prop.getProperty(PropertyNames.DM_REQ_SEG_ID.name());
					if (dmReqSegId != null && !dmReqSegId.isEmpty() && !dmReqSegId.startsWith("-1")) {
						segVerBuilder.setId(Long.valueOf(dmReqSegId));
					}			
					dmRequest.setTargetSegment(segVerBuilder.build());
					logger.info("Send dm request to DM cluster...");
					System.out.print(dmRequest.toString());
					Boolean result = post(dmUrl, dmRequest.build());
					logger.info("Get response from dm,result ={}", result);						
				}
			}

		} catch (Exception e) {
			throw new UidClientException(e.getMessage(), e);
		} finally {
			prop.clear();
			prop = null;
		}
	}


	public static Boolean post(String url, PBDmSyncRequest dmSegReq) {
		Callable<Boolean> newPostTask = () -> {
			String cmmd = dmSegReq.getCmd().name().toLowerCase();
			OkHttpClient client = new OkHttpClient();
			client.setConnectTimeout(10, TimeUnit.SECONDS);
			client.setReadTimeout(10, TimeUnit.SECONDS);
			client.setWriteTimeout(30, TimeUnit.SECONDS);
			final StopWatch t = new StopWatch();
			t.start();
			Request request = new Request.Builder().url(url)
					.post(RequestBody.create(MEDIA_TYPE_PLAINTEXT, dmSegReq.toByteArray())).build();
			try {
				Response response = client.newCall(request).execute();				
				t.stop();
				logger.info("Post PBDmSyncRequest(segmentId={}) to {} used time={} and status={}", dmSegReq.getTargetSegment().getId(),
						url, t.elapsedTime(), response.code());
				 PBDmSyncResponce dmRes = PBDmSyncResponce.parseFrom(response.body().bytes());
				 Boolean jobResult = Boolean.valueOf(dmRes.getSuccess());
					logger.info("Post PBDmSyncRequest(cmd= {} segmentId={}) to {} used time={}, and status={} job success is {}", 
							cmmd, dmSegReq.getTargetSegment().getId(), url, t.elapsedTime(), response.code(), jobResult);
					return jobResult;				
			} catch (Exception e) {
				logger.error(e.getMessage(), e);
				return Boolean.valueOf(false);
			}
		};
		try {
			return UidDmJobRunManager.submit(newPostTask);
		} catch (InterruptedException | ExecutionException e) {
			logger.error(e.getMessage(), e);
			return Boolean.valueOf(false);
		}
	}
	
	public static byte[] getTemplate(String url, String refId) throws InterruptedException, ExecutionException {
		String getUrl = url + "/?refId=" + refId;
		Callable<byte[]> newGetTask = () -> {
			final StopWatch t = new StopWatch();
			t.start();
			OkHttpClient client = new OkHttpClient();
			client.setConnectTimeout(10, TimeUnit.SECONDS);
			client.setReadTimeout(10, TimeUnit.SECONDS);
			client.setWriteTimeout(30, TimeUnit.SECONDS);	
			Request request = new Request.Builder().get().url(getUrl).build();
			Call call = client.newCall(request);
			Response response = call.execute();
			t.stop();
			if (response.code() == 200) {
				logger.info("Send getTemplate request(refId={}) to {} used time={} and status={}", refId,
						getUrl, t.elapsedTime(), response.code());	
				 return response.body().bytes();
			} else {
				logger.warn("Faild to get template data from dm cluster, sendUrl={} refId={} and status={}",getUrl, refId, response.code());
				return null;
			}		
		};		
		return UidDmJobRunManager.submitGetRequest(newGetTask);		
	}
	
	public static byte[] getTemplate(String url, Long segId, Long bioId) throws InterruptedException, ExecutionException {
		String getUrl = url + "/?segId=" + segId + "&bioId=" + bioId;
		Callable<byte[]> newGetTask = () -> {
			final StopWatch t = new StopWatch();
			t.start();
			OkHttpClient client = new OkHttpClient();
			client.setConnectTimeout(10, TimeUnit.SECONDS);
			client.setReadTimeout(10, TimeUnit.SECONDS);
			client.setWriteTimeout(30, TimeUnit.SECONDS);	
			Request request = new Request.Builder().get().url(getUrl).build();
			Call call = client.newCall(request);
			Response response = call.execute();
			t.stop();
			if (response.code() == 200) {
				logger.info("Send getTemplate request(segId={}, bioId={}) to {} used time={} and status={}", segId, bioId,
						getUrl, t.elapsedTime(), response.code());	
				 return response.body().bytes();
			} else {
				logger.warn("Faild to get template data from dm cluster, sendUrl={} segId={}  bioId = {} and status={}", getUrl, segId, bioId,response.code());
				return null;
			}		
		};		
		return UidDmJobRunManager.submitGetRequest(newGetTask);	
	}

	public static byte[] getSegment(String getUrl, Long segId) throws InterruptedException, ExecutionException {
		Callable<byte[]> newGetTask = () -> {
			final StopWatch t = new StopWatch();
			t.start();
			OkHttpClient client = new OkHttpClient();
			client.setConnectTimeout(10, TimeUnit.SECONDS);
			client.setReadTimeout(10, TimeUnit.SECONDS);
			client.setWriteTimeout(30, TimeUnit.SECONDS);	
			Request request = new Request.Builder().get().url(getUrl).build();
			Call call = client.newCall(request);
			Response response = call.execute();
			t.stop();
			if (response.code() == 200) {
				logger.info("Send getSegment request(segmentId={}) to {} used time={} and status={}", segId,
						getUrl, t.elapsedTime(), response.code());	
				 return response.body().bytes();
			} else {
				logger.warn("Faild to get segment data from dm cluster, sendUrl={} segmentId={} and status={}", getUrl, segId, response.code());
				return null;
			}		
		};		
		return UidDmJobRunManager.submitGetRequest(newGetTask);		
	}
}
