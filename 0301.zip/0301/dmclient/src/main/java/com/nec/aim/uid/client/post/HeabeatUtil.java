package com.nec.aim.uid.client.post;

public class HeabeatUtil {
	
	

}
