package com.nec.aim.dm.dmservice.entity;

import java.sql.Timestamp;

import lombok.Data;

@Data
public class Node {	
	private Long id;
	private String address;
	private int diskSize;
	private int space;
	private int status;
	private Timestamp ts;

}
