package jp.co.nec.lsm.tma.service.sessionbean.pt;

import javax.annotation.Resource;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.carrotsearch.junitbenchmarks.AbstractBenchmark;
import com.carrotsearch.junitbenchmarks.BenchmarkOptions;

import it.unimi.dsi.fastutil.objects.ObjectCollection;
import jp.co.nec.lsm.event.Event;
import jp.co.nec.lsm.event.sender.AbstractEventSender;
import jp.co.nec.lsm.tm.common.communication.BatchJobMapStatus;
import jp.co.nec.lsm.tm.common.communication.BatchSegmentJobMap;
import jp.co.nec.lsm.tm.common.communication.ReSendable;
import jp.co.nec.lsm.tma.common.util.UtilCreateData;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyJobResult;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyResult;
import jp.co.nec.lsm.tma.core.jobs.BatchSegmentJobManager;
import jp.co.nec.lsm.tma.exception.AggregationRuntimeException;
import jp.co.nec.lsm.tma.service.sessionbean.IdentifyBatchJobResultServiceBean;
import mockit.Mock;
import mockit.MockUp;

/**
 * 
 */
@BenchmarkOptions(benchmarkRounds = 5, warmupRounds = 5)
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class IdentifyBatchJobResultServiceBeanTest extends AbstractBenchmark {
	@Resource
	IdentifyBatchJobResultServiceBean identifyBatchJobResultServiceBean;

	private final static long bJobIdStart = 10000;
	private final static int bJobCount = 2;
	private final static int jobCount = 10;
	private final static int maxCandidate = 10;
	private final static int segmentIdStart = 1000;
	private final static int segmentCount = 2;

	private BatchSegmentJobManager queueManager;

	@Before
	public void setUp() throws Exception {
		setMockMethod();
		queueManager = BatchSegmentJobManager.getInstance();
		queueManager.clear();
	}

	@After
	public void tearDown() throws Exception {
		queueManager = null;
	}

	private void setMockMethod() {
		new MockUp<AbstractEventSender>() {
			@Mock
			public void convertAndSend(Event message) {
				return;
			}
		};
	}

	@Test
	public void testNotifyBatchSegmentJobDone() {
		createIdentifyResultList(bJobIdStart, bJobCount, jobCount,
				maxCandidate + 1, segmentIdStart, segmentCount, maxCandidate);
		BatchSegmentJobMap batchSegmentJobMap = UtilCreateData
				.createBatchSegmentJobMapData(bJobIdStart + 1, jobCount,
						maxCandidate, segmentIdStart, segmentCount);
		batchSegmentJobMap.setBatchJobStatus(BatchJobMapStatus.RUNNING);
		queueManager.add(batchSegmentJobMap);

		long removeBatchJobId = queueManager.getIdentifyResults().keySet()
				.iterator().next();
		try {
			identifyBatchJobResultServiceBean
					.notifyBatchJobDone(removeBatchJobId);
		} catch (AggregationRuntimeException e) {
			Assert.assertNotNull(queueManager
					.getBatchSegmentJobMap(removeBatchJobId));
			Assert.assertNotNull(queueManager
					.getIdentifyResult(removeBatchJobId));
		}
		queueManager.remove(removeBatchJobId);

		Assert.assertNull(queueManager.getBatchSegmentJobMap(removeBatchJobId));
		Assert.assertNull(queueManager.getIdentifyResult(removeBatchJobId));

		// test BatchSegmentJobMap is null
		try {
			identifyBatchJobResultServiceBean.notifyBatchJobDone(bJobIdStart);
		} catch (AggregationRuntimeException e) {
			Assert.assertNull(queueManager.getBatchSegmentJobMap(bJobIdStart));
			Assert.assertNotNull(queueManager.getIdentifyResult(bJobIdStart));
		}

		// test IdentifyResult is null
		removeBatchJobId++;
		try {
			identifyBatchJobResultServiceBean
					.notifyBatchJobDone(removeBatchJobId);
		} catch (AggregationRuntimeException e) {
			Assert.assertNull(queueManager
					.getBatchSegmentJobMap(removeBatchJobId));
			Assert.assertNull(queueManager.getIdentifyResult(removeBatchJobId));
		}
	}

	/**
	 * create much more IdentifyResult data
	 * 
	 * @param bJobCount
	 */
	private void createIdentifyResultList(long bJobIdStart, int bJobCount,
			int jobCount, int candidateSize, long segmentIdStart,
			int segmentCount, int maxCandidate) {
		IdentifyResult identifyResult = null;
		for (long i = 0; i < bJobCount; i++) {
			identifyResult = UtilCreateData.createIdentifyResultData(
					bJobIdStart + i, jobCount, candidateSize, segmentIdStart,
					segmentCount, maxCandidate, ReSendable.EMPTY);

			// set maxCandidate
			ObjectCollection<IdentifyJobResult> SearchJobResults = identifyResult
					.getSearchJobResults().values();
			for (IdentifyJobResult jobInfo : SearchJobResults) {
				jobInfo.setMaxCandidate(maxCandidate);
			}

			queueManager.add(identifyResult);
			identifyResult = null;
		}
	}

}
