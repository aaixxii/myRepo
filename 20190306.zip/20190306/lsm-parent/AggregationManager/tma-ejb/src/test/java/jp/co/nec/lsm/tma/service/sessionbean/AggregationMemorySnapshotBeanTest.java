package jp.co.nec.lsm.tma.service.sessionbean;

import java.util.Date;
import java.util.Map;

import jp.co.nec.lsm.tm.common.communication.BatchJobMapStatus;
import jp.co.nec.lsm.tm.common.communication.BatchSegmentJobMap;
import jp.co.nec.lsm.tm.protocolbuffer.common.BatchTypeProto.BatchType;
import jp.co.nec.lsm.tm.protocolbuffer.identify.IdentifyResultRequestProto.IdentifyResultRequest;
import jp.co.nec.lsm.tma.core.jobs.BatchSegmentJobManager;
import jp.co.nec.lsm.tma.core.jobs.IdentifyResponseQueue;
import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.google.protobuf.ByteString;

public class AggregationMemorySnapshotBeanTest {

	private AggregationMemorySnapshotBean bean = new AggregationMemorySnapshotBean();

	private BatchSegmentJobManager jobManager = BatchSegmentJobManager
			.getInstance();

	private IdentifyResponseQueue queue = IdentifyResponseQueue.getInstance();

	@Before
	public void before() {
		jobManager.clear();
	}

	@After
	public void after() {
		jobManager.clear();
	}

	@Test
	public void testGetBatchSegmentJobMapAll() {
		BatchSegmentJobMap bsjm = new BatchSegmentJobMap();
		bsjm.setbJobId(121212L);
		bsjm.setBatchJobStatus(BatchJobMapStatus.OVER_RETRY_LIMIT);
		bsjm.setFailureCount(12);
		bsjm.setStartTime(new Date(12121212L));
		jobManager.add(bsjm);

		Map<Long, BatchSegmentJobMap> maps = bean.getBatchSegmentJobMap(null);
		BatchSegmentJobMap jobMap = maps.get(121212L);
		Assert.assertNotNull(jobMap);

		Assert.assertEquals(121212L, jobMap.getbJobId());
		Assert.assertEquals(BatchJobMapStatus.OVER_RETRY_LIMIT,
				jobMap.getBatchJobStatus());
		Assert.assertEquals(12, jobMap.getFailureCount());
		Assert.assertEquals(12121212L, jobMap.getStartTime().getTime());
	}

	@Test
	public void testGetBatchSegmentJobMapWithBatchJobiD() {
		BatchSegmentJobMap bsjm = new BatchSegmentJobMap();
		bsjm.setbJobId(121212L);
		bsjm.setBatchJobStatus(BatchJobMapStatus.OVER_RETRY_LIMIT);
		bsjm.setFailureCount(12);
		bsjm.setStartTime(new Date(12121212L));
		jobManager.add(bsjm);

		bsjm = new BatchSegmentJobMap();
		bsjm.setbJobId(121213L);
		bsjm.setBatchJobStatus(BatchJobMapStatus.OVER_RETRY_LIMIT);
		bsjm.setFailureCount(12);
		bsjm.setStartTime(new Date(12121212L));
		jobManager.add(bsjm);

		Map<Long, BatchSegmentJobMap> maps = bean
				.getBatchSegmentJobMap(121212L);
		BatchSegmentJobMap jobMap = maps.get(121212L);
		Assert.assertNotNull(jobMap);

		Assert.assertEquals(121212L, jobMap.getbJobId());
		Assert.assertEquals(BatchJobMapStatus.OVER_RETRY_LIMIT,
				jobMap.getBatchJobStatus());
		Assert.assertEquals(12, jobMap.getFailureCount());
		Assert.assertEquals(12121212L, jobMap.getStartTime().getTime());
	}

	@Test
	public void testGetBatchSegmentJobMapWithBatchJobiDZero() {
		BatchSegmentJobMap bsjm = new BatchSegmentJobMap();
		bsjm.setbJobId(121212L);
		bsjm.setBatchJobStatus(BatchJobMapStatus.OVER_RETRY_LIMIT);
		bsjm.setFailureCount(12);
		bsjm.setStartTime(new Date(12121212L));
		jobManager.add(bsjm);

		bsjm = new BatchSegmentJobMap();
		bsjm.setbJobId(121213L);
		bsjm.setBatchJobStatus(BatchJobMapStatus.OVER_RETRY_LIMIT);
		bsjm.setFailureCount(12);
		bsjm.setStartTime(new Date(12121212L));
		jobManager.add(bsjm);

		Map<Long, BatchSegmentJobMap> maps = bean.getBatchSegmentJobMap(0L);
		Assert.assertEquals(0, maps.size());
	}

	@Test
	public void testGetIdentifyResultRequest() {
		final long batchJobIdBg = 121213L;

		for (int i = 0; i < 150; i++) {
			IdentifyResultRequest.Builder builder = IdentifyResultRequest
					.newBuilder();
			builder.setBatchJobId(batchJobIdBg + i);
			builder.setType(BatchType.IDENTIFY);
			builder.addBusinessMessage(ByteString.EMPTY);

			queue.add(builder.build());
		}

		Map<Long, IdentifyResultRequest> maps = bean.getIdentifyResultRequest();
		Assert.assertEquals(120, maps.size());

		IdentifyResultRequest request = maps.get(batchJobIdBg);
		Assert.assertNull(request);

		IdentifyResultRequest request_remain = maps.get(batchJobIdBg + 30);
		Assert.assertNotNull(request_remain);

		Assert.assertEquals(request_remain.getBatchJobId(), batchJobIdBg + 30);
		Assert.assertEquals(request_remain.getType(), BatchType.IDENTIFY);
		Assert.assertEquals(request_remain.getBusinessMessageCount(), 1);
		Assert.assertEquals(request_remain.getBusinessMessage(0),
				ByteString.EMPTY);
	}

}
