package jp.co.nec.lsm.tma.core.jobs;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import jp.co.nec.lsm.tm.protocolbuffer.common.BatchTypeProto.BatchType;
import jp.co.nec.lsm.tm.protocolbuffer.identify.IdentifyResultRequestProto.IdentifyResultRequest;

import org.junit.Assert;
import org.junit.Test;

import com.google.protobuf.ByteString;

public class IdentifyResponseQueueTest {

	@Test
	public void testAdd() {
		IdentifyResultRequest.Builder builder = IdentifyResultRequest
				.newBuilder();
		builder.setBatchJobId(1000L);
		builder.setType(BatchType.IDENTIFY);
		builder.addBusinessMessage(ByteString.EMPTY);

		IdentifyResponseQueue instance = IdentifyResponseQueue.getInstance();
		instance.add(builder.build());

		IdentifyResultRequest request = instance.get(1000L);

		Assert.assertEquals(request.getBatchJobId(), 1000L);
		Assert.assertEquals(request.getType(), BatchType.IDENTIFY);
		Assert.assertEquals(request.getBusinessMessage(0), ByteString.EMPTY);

		instance.remove(1000L);
		instance.removeAll();
	}

	@Test
	public void testAddOver120() {
		IdentifyResponseQueue instance = IdentifyResponseQueue.getInstance();

		for (int index = 0; index <= 130; index++) {
			IdentifyResultRequest.Builder builder = IdentifyResultRequest
					.newBuilder();
			builder.setBatchJobId(1000L + index);
			builder.setType(BatchType.IDENTIFY);
			builder.addBusinessMessage(ByteString.EMPTY);
			instance.add(builder.build());
		}
		Assert.assertEquals(instance.size(), 120);
		instance.removeAll();
	}

	@Test
	public void testGetAll() {
		IdentifyResponseQueue instance = IdentifyResponseQueue.getInstance();
		instance.removeAll();

		IdentifyResultRequest.Builder builder = IdentifyResultRequest
				.newBuilder();
		builder.setBatchJobId(1000L);
		builder.setType(BatchType.IDENTIFY);
		builder.addBusinessMessage(ByteString.EMPTY);

		instance.add(builder.build());

		builder = IdentifyResultRequest.newBuilder();
		builder.setBatchJobId(1001L);
		builder.setType(BatchType.IDENTIFY);
		builder.addBusinessMessage(ByteString.EMPTY);

		instance.add(builder.build());

		Collection<IdentifyResultRequest> requests = instance.getAll();
		Assert.assertEquals(instance.size(), 2);

		List<IdentifyResultRequest> arrays = new ArrayList<IdentifyResultRequest>(
				requests);

		Collections.sort(arrays, new Comparator<IdentifyResultRequest>() {
			public int compare(IdentifyResultRequest o1,
					IdentifyResultRequest o2) {
				try {
					if (o1.getBatchJobId() < o2.getBatchJobId()) {
						return -1;
					}
				} catch (Exception ex) {
				}
				return 1;
			}
		});

		Assert.assertEquals(arrays.get(0).getBatchJobId(), 1000L);
		Assert.assertEquals(arrays.get(0).getType(), BatchType.IDENTIFY);
		Assert.assertEquals(arrays.get(0).getBusinessMessage(0),
				ByteString.EMPTY);

		Assert.assertEquals(arrays.get(1).getBatchJobId(), 1001L);
		Assert.assertEquals(arrays.get(1).getType(), BatchType.IDENTIFY);
		Assert.assertEquals(arrays.get(1).getBusinessMessage(0),
				ByteString.EMPTY);

		instance.remove(1000L);
		instance.remove(1001L);
	}
}
