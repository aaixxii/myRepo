package jp.co.nec.lsm.tme.service.pojo;

import java.util.Date;

import jp.co.nec.lsm.proto.extract.ExtractJobResultRequestProto.ExtractJobResultRequest;
import jp.co.nec.lsm.tm.common.log.InfoLogger;
import jp.co.nec.lsm.tm.common.log.LogConstants;
import jp.co.nec.lsm.tm.common.log.PerformanceLogger;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollBatchJobStatus;
import jp.co.nec.lsm.tme.core.jobs.EnrollBatchJobManager;
import jp.co.nec.lsm.tme.core.jobs.LocalEnrollBatchJob;

import org.apache.commons.lang3.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author mozj <br>
 *         update extract result into the extract jobs of the local enroll
 *         queue. if all extract jobs are completed, notify
 *         EnrollUpdateBatchJobServiceBean that Batch Job Completed by Batch Job
 *         Id, or response Identify Server the result of batchJob
 */
public class EnrollReportServiceBean {

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(EnrollReportServiceBean.class);

	/**
	 * constructor
	 */
	public EnrollReportServiceBean() {
	}

	/**
	 * update extract result into the extract jobs of the local enroll queue. if
	 * all extract jobs are completed, notify EnrollUpdateBatchJobServiceBean
	 * that Batch Job Completed by Batch Job Id, or response Identify Server the
	 * result of batchJob
	 */
	public void doReport(ExtractJobResultRequest extractResult) {
		if (extractResult == null) {
			throw new IllegalArgumentException(
					"ExtractResultRequest can not be null.");
		}

		printLogMessage("start public function doReport()..");

		StopWatch stopWatch = new StopWatch();
		stopWatch.start();

		Long batchJobId = extractResult.getBatchJobId();
		if (log.isInfoEnabled()) {
			log.info(InfoLogger.deliveryJobInfoOutput(
					LogConstants.DETAIL_ENROLL_DO_REPORT,
					LogConstants.KEY_BATCH_JOB_ID, batchJobId.toString()));
		}

		// get Enroll Batch Job By Id
		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		LocalEnrollBatchJob batchJob = queueManage
				.getEnrollBatchJobById(batchJobId);

		if (batchJob == null) {
			log.warn("Can not find the batch job(BatchJobId: {}).", batchJobId);
			return;
		}

		// check Enroll Batch Job status
		if (!(batchJob.isBatchJobStatus(EnrollBatchJobStatus.EXTRACTING))) {
			log.warn(
					"The batch job(BatchJobId: {}) status is{}. donot update.",
					batchJobId, batchJob.getBatchJobStatus().toString());
			return;
		}

		// update extract result into the extract jobs of the enroll queue.
		synchronized (batchJob) {
			updateBatchJob(extractResult, batchJob);
		}

		stopWatch.stop();

		PerformanceLogger.performanceOutput(
				LogConstants.COMPONENT_REPORT_SERVICE_BEAN,
				LogConstants.FUNCTION_DOREPORT, stopWatch.getTime());

		printLogMessage("end public function doReport()..");
		return;
	}

	/**
	 * update extract result into the extract jobs of the local enroll queue.
	 * 
	 * @param extractResult
	 * @return the number of update extract jobs
	 */
	public void updateBatchJob(ExtractJobResultRequest extractResult,
			LocalEnrollBatchJob batchJob) {
		printLogMessage("start public function updateBatchJob()..");

		// loop to update extract job info.
		printLogMessage("start loop to update extract job info...");

		Date now = DateUtil.getCurrentDate();

		batchJob.updateBatchJob(extractResult, now);

		printLogMessage("end public function updateBatchJob()..");
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}

}
