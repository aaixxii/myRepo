package jp.co.nec.lsm.tme.service.sessionbean;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import org.apache.commons.lang3.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.lsm.tm.common.communication.SegmentPosition;
import jp.co.nec.lsm.tm.common.constants.SegmentDeleteSyn;
import jp.co.nec.lsm.tm.common.log.InfoLogger;
import jp.co.nec.lsm.tm.common.log.LogConstants;
import jp.co.nec.lsm.tm.common.log.PerformanceLogger;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.common.validator.ValidationResult;
import jp.co.nec.lsm.tm.protocolbuffer.deletion.DeleteResultRequestProto.DeleteResultRequest;
import jp.co.nec.lsm.tme.common.util.EnrollEventBus;
import jp.co.nec.lsm.tme.core.clientapi.request.validator.DeleteRequestValidator;
import jp.co.nec.lsm.tme.core.clientapi.response.DeleteResultRequestBuilder;
import jp.co.nec.lsm.tme.core.jobs.DeletionJobManager;
import jp.co.nec.lsm.tme.core.jobs.LocalDeletionJob;
import jp.co.nec.lsm.tme.db.dao.EnrollPersonBiometricDao;
import jp.co.nec.lsm.tme.db.dao.EnrollSystemConfigDao;

/**
 * @author mozj <br>
 *         add the enroll request into local enroll queue.
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class TemplateDeletionBean  {
	@EJB
	private EnrollPersonBiometricDao personBiometricDao;
	@EJB
	private EnrollSystemConfigDao systemConfigDao;

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(TemplateDeletionBean.class);

	/**
	 * constructor
	 */
	public TemplateDeletionBean() {
	}

	/**
	 * delete Biometrics from Person_biometrics by referenceId
	 */	
	public DeleteResultRequest deleteTemplate(Long batchJobId,
			String referenceId) {
		printLogMessage("strat public function deleteBiometrics");

		try {
			if (log.isInfoEnabled()) {
				log.info(InfoLogger.serialExecutionInfoOutput(
						LogConstants.COMPONENT_TEMPLATE_DELETION_BEAN,
						LogConstants.FUNCTION_DELETE_TEMPLATE,
						LogConstants.DETAIL_ACTION_START, batchJobId, Thread
								.currentThread().getId()));
			}

			DeletionJobManager deletionJobManager = DeletionJobManager
					.getInstance();
			LocalDeletionJob deletejob = deletionJobManager
					.getDeletionJob(batchJobId);
			if (deletejob == null) {
				log.warn("Cannot find LocalDeletionJob:(batchjobId {}).",
						batchJobId);
				return null;
			}

			ValidationResult result = DeleteRequestValidator.validateRequest(
					batchJobId, deletejob.getRequest());

			if (result != null && result.hasErrors()) {
				deletejob.setErrorCode(result.getRequestError().get(0)
						.getErrorCode());
				deletejob.setReSendable(false);
				deletejob.setErrorMessage(result.getRequestError().get(0)
						.getInvalidReason());
				// delete Deletion Job
				DeletionJobManager.getInstance().deleteDeletionJob(deletejob);

				return createDeleteResultRequest(deletejob);
			}

			// delete Biometrics from Person_biometrics by referenceId
			printLogMessage(
					"delete Biometrics from Person_biometrics by referenceId {}.",
					referenceId);
			DeleteResultRequest deleteResult = null;

			StopWatch stopWatch = new StopWatch();
			stopWatch.start();

			SegmentPosition segmentPosition = personBiometricDao
					.deleteBiometrics(referenceId);

			stopWatch.stop();

			PerformanceLogger.performanceOutput(
					LogConstants.COMPONENT_TEMPLATE_DELETION_BEAN,
					LogConstants.FUNCTION_DELETE_TEMPLATE_DEL, stopWatch
							.getTime(), LogConstants.KEY_BATCH_JOB_ID,
					new Long(batchJobId).toString(), "Action",
					"delete_biometrics");

			stopWatch.reset();
			stopWatch.start();

			if (segmentPosition == null) {
				String message = "Delete Job ( Cannot find referenceId: "
						+ referenceId + " ).";
				log.warn(message);

				deletejob.makeSyncByNoFindData(message);

				deleteResult = createDeleteResultRequest(deletejob);
				// delete Deletion Job
				DeletionJobManager.getInstance().deleteDeletionJob(deletejob);
			} else {
				deletejob.setSegmentPosition(segmentPosition);
				deletejob.setDeleted(true);

				personBiometricDao.commit();

				deleteResult = createDeleteResultRequest(deletejob);

				String segmentDeleteSyn = systemConfigDao.getSegmentDeleteSyn();
				if (!SegmentDeleteSyn.DB.name().equals(segmentDeleteSyn)) {
					// Notify EnrollSegmentSyncServiceBean that Segment
					// synchronization.
					EnrollEventBus.notifyDeleteSync(batchJobId);
				} else {
					log.info("Skip synchronize Deletion Job");
					// delete Deletion Job
					DeletionJobManager.getInstance().deleteDeletionJob(
							deletejob);
				}
			}

			stopWatch.stop();

			PerformanceLogger.performanceOutput(
					LogConstants.COMPONENT_TEMPLATE_DELETION_BEAN,
					LogConstants.FUNCTION_DELETE_TEMPLATE_JMS, stopWatch
							.getTime(), LogConstants.KEY_BATCH_JOB_ID,
					new Long(batchJobId).toString(), "Action",
					"notify Delete Sync(JMS)");

			printLogMessage("end public function deleteBiometrics");
			return deleteResult;
		} finally {
			if (log.isInfoEnabled()) {
				log.info(InfoLogger.serialExecutionInfoOutput(
						LogConstants.COMPONENT_TEMPLATE_DELETION_BEAN,
						LogConstants.FUNCTION_DELETE_TEMPLATE,
						LogConstants.DETAIL_ACTION_END, batchJobId, Thread
								.currentThread().getId()));
			}
		}
	}

	/**
	 * 
	 * @return
	 */
	private DeleteResultRequest createDeleteResultRequest(
			LocalDeletionJob batchJob) {

		batchJob.setEndTime(DateUtil.getCurrentDate());

		DeleteResultRequest deleteResult = DeleteResultRequestBuilder
				.createDeleteResultRequest(batchJob);

		return deleteResult;
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 *            ,logParame
	 * @return
	 */
	private void printLogMessage(String logMessage, Object... objects) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage, objects);
		}
	}
}
