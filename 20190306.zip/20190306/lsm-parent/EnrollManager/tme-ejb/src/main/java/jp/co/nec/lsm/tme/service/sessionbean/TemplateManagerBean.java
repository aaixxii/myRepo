package jp.co.nec.lsm.tme.service.sessionbean;

import javax.ejb.EJB;
import javax.ejb.Lock;
import javax.ejb.LockType;
import javax.ejb.Singleton;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import org.apache.commons.lang3.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.lsm.tm.common.log.InfoLogger;
import jp.co.nec.lsm.tm.common.log.LogConstants;
import jp.co.nec.lsm.tm.common.log.PerformanceLogger;
import jp.co.nec.lsm.tm.protocolbuffer.deletion.DeleteResultRequestProto.DeleteResultRequest;

/**
 * @author mozj <br>
 *         register all extract result of the extraction completed batch job
 *         into database, and update segment information. And then update batch
 *         job information into database
 * 
 */
@Singleton
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class TemplateManagerBean  {
	@EJB
	TemplateInsertionBean templateInsertionBean;
	@EJB
	TemplateDeletionBean templateDeletionBean;

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(TemplateManagerBean.class);

	/**
	 * constructor
	 */
	public TemplateManagerBean() {
	}

	/**
	 * delete Biometrics from Person_biometrics by referenceId
	 * 
	 * @return
	 */	
	@Lock(LockType.WRITE)
	public DeleteResultRequest deleteTemplate(Long batchJobId, String referenceId) {
		printLogMessage("start public function deleteBiometrics().");

		try {
			if (log.isInfoEnabled()) {
				log.info(InfoLogger.serialExecutionInfoOutput(
						LogConstants.COMPONENT_TEMPLATE_MANAGER_BEAN,
						LogConstants.FUNCTION_DELETE_TEMPLATE,
						LogConstants.DETAIL_ACTION_START, 0, Thread
								.currentThread().getId()));
			}

			StopWatch stopWatch = new StopWatch();
			stopWatch.start();

			// delete Biometrics from Person_biometrics by referenceId
			DeleteResultRequest deleteResult =  templateDeletionBean
					.deleteTemplate(batchJobId,referenceId);

			stopWatch.stop();

			PerformanceLogger.performanceOutput(
					LogConstants.COMPONENT_TEMPLATE_MANAGER_BEAN,
					LogConstants.FUNCTION_DELETE_TEMPLATE, stopWatch.getTime());

			printLogMessage("end public function deleteBiometrics().");
			return deleteResult;
		} finally {
			if (log.isInfoEnabled()) {
				log.info(InfoLogger.serialExecutionInfoOutput(
						LogConstants.COMPONENT_TEMPLATE_MANAGER_BEAN,
						LogConstants.FUNCTION_DELETE_TEMPLATE,
						LogConstants.DETAIL_ACTION_END, 0, Thread
								.currentThread().getId()));
			}
		}
	}

	/**
	 * register templates of the batch job found by batch Job Id into DB
	 */	
	@Lock(LockType.WRITE)
	public void insertTemplates(long batchJobId) {
		printLogMessage("start public function insterTemplates()..");

		try {
			if (log.isInfoEnabled()) {
				log.info(InfoLogger.serialExecutionInfoOutput(
						LogConstants.COMPONENT_TEMPLATE_MANAGER_BEAN,
						LogConstants.FUNCTION_INSERT_TEMPLATE,
						LogConstants.DETAIL_ACTION_START, batchJobId, Thread
								.currentThread().getId()));
			}

			StopWatch stopWatch = new StopWatch();
			stopWatch.start();

			templateInsertionBean.insertTemplates(batchJobId);

			stopWatch.stop();

			PerformanceLogger.performanceOutput(
					LogConstants.COMPONENT_TEMPLATE_MANAGER_BEAN,
					LogConstants.FUNCTION_INSERT_TEMPLATE, stopWatch.getTime());
		} finally {
			if (log.isInfoEnabled()) {
				log.info(InfoLogger.serialExecutionInfoOutput(
						LogConstants.COMPONENT_TEMPLATE_MANAGER_BEAN,
						LogConstants.FUNCTION_INSERT_TEMPLATE,
						LogConstants.DETAIL_ACTION_END, batchJobId, Thread
								.currentThread().getId()));
			}
		}
		printLogMessage("end public function insterTemplates()..");
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}

}
