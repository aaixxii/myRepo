package jp.co.nec.lsm.tme.core.clientapi.response;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBBusinessMessage;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBProcessInfo;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBRequest;
import com.nec.everest.proto.protobuf.BusinessMessage.E_REQUESET_TYPE;

import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.protocolbuffer.common.BatchTypeProto.BatchType;
import jp.co.nec.lsm.tm.protocolbuffer.deletion.DeleteResultRequestProto.DeleteResultRequest;
import jp.co.nec.lsm.tme.common.constants.EnrollConstants;
import jp.co.nec.lsm.tme.core.jobs.LocalDeletionJob;

public class DeleteResultRequestBuilderTest {

	@Before
	public void setUp() {
	}

	@After
	public void tearDown() {
	}

	/**
	 * 
	 * @param batchJobId
	 * @param deleteReferenceId
	 */
	private LocalDeletionJob preparelocalDeleteJob(long batchJobId,
			String deleteReferenceId) {
		CPBRequest.Builder request = CPBRequest.newBuilder();
		request.setEnrollmentId(deleteReferenceId);
		request.setRequestId(deleteReferenceId);
		request.setRequestType(E_REQUESET_TYPE.DELETE);

		LocalDeletionJob deletionJob = new LocalDeletionJob(batchJobId, request
				.build());
		deletionJob.setSynchronized(true);
		deletionJob.setSegmentId(12);
		deletionJob.setVersion(0);
		deletionJob.setBiometricsId(213);
		deletionJob.setErrorCode("ErrorCode");
		deletionJob.setReSendable(true);
		deletionJob.setErrorMessage("ErrorMessage");

		return deletionJob;
	}

	@Test
	public void testCreateDeleteResultRequest()
			throws InvalidProtocolBufferException {
		long batchJobId = 22545;
		String deleteReferenceId = "String deleteReferenceId";

		LocalDeletionJob batchJob = preparelocalDeleteJob(batchJobId,
				deleteReferenceId);

		DeleteResultRequest resultRequest = DeleteResultRequestBuilder
				.createDeleteResultRequest(batchJob);

		assertEquals(batchJobId, resultRequest.getBatchJobId());
		assertEquals(BatchType.DELETE, resultRequest.getType());
		assertEquals(1, resultRequest.getBusinessMessageCount());

		ByteString byteString = resultRequest.getBusinessMessageList().get(0);
		CPBBusinessMessage message = CPBBusinessMessage.parseFrom(byteString);

		assertEquals(deleteReferenceId, message.getRequest().getRequestId());
		assertEquals(deleteReferenceId, message.getRequest().getEnrollmentId());
		assertEquals(E_REQUESET_TYPE.DELETE, message.getRequest()
				.getRequestType());

		assertEquals("ErrorCode", message.getResponse().getStatus());
		assertEquals("Y", message.getResponse().getResendable());
		assertEquals("ErrorMessage", message.getResponse().getErrorMessage());

		assertEquals(1, message.getDataBlock().getProcessMetric()
				.getProcessMetricCount());

		CPBProcessInfo processInfo = message.getDataBlock().getProcessMetric()
				.getProcessMetric(0);
		assertEquals(EnrollConstants.DELETE_PROCCESS_NAME, processInfo
				.getProcessName());
		assertEquals(DateUtil.formatUTC(batchJob.getStartTime()), processInfo
				.getStartTime());
		assertNotNull(processInfo.getEndTime());
	}
}
