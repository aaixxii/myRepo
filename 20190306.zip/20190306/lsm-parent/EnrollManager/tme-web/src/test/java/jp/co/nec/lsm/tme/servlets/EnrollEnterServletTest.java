package jp.co.nec.lsm.tme.servlets;

import static org.junit.Assert.assertEquals;

import java.io.IOException;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.lsm.proto.common.CommonProto.ComponentType;
import jp.co.nec.lsm.proto.control.EnterRequestProto.EnterRequest;
import jp.co.nec.lsm.proto.control.EnterResponseProto.EnterResponse;
import jp.co.nec.lsm.tme.service.sessionbean.EnrollStatusManagerBean;
import mockit.Mock;
import mockit.MockUp;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class EnrollEnterServletTest {
	@Resource
	private JdbcTemplate jdbcTemplate;
	@Resource
	EnrollEnterServlet enterServlet;

	@Before
	public void setUp() throws ServletException {
		enterServlet.init();
		cleanDB();
	}

	@After
	public void tearDown() {
		cleanDB();
	}

	/**
	 * 
	 */
	private void cleanDB() {
		jdbcTemplate.execute("delete FROM MU_SEGMENTS");
		jdbcTemplate.execute("delete FROM MU_CONTACTS");
		jdbcTemplate.execute("delete FROM match_units");
	}

	/**
	 * prepare data for EnrollBatchJobQueues
	 */
	private void prepareDBforTest() {
		jdbcTemplate.execute("insert into match_units (mu_id,"
				+ " unique_id, state, TYPE, revision, IP_ADDRESS,"
				+ " balanced_flag) values(1, 'uniqueId',"
				+ " 'WORKING', 1, 1, 1, 1)");

	}

	private EnterRequest prepareEnterRequest(String uniqueId, String URL,
			ComponentType type) {
		EnterRequest.Builder enterRequest = EnterRequest.newBuilder();

		enterRequest.setUniqueId(uniqueId);
		enterRequest.setType(type);
		enterRequest.setContactURL(URL);
		enterRequest.setVersion("2132");
		enterRequest.setNumberOfCpus(1);
		enterRequest.setPrimarySize(12124);
		enterRequest.setSecondarySize(124342332);
		return enterRequest.build();
	}

	@Test
	public void testDoPost_NoContent() throws ServletException, IOException {

		cleanDB();
		setMockMethod();

		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse resp = new MockHttpServletResponse();

		enterServlet.doPost(req, resp);
		assertEquals(HttpServletResponse.SC_OK, resp.getStatus());
		assertEquals(0, resp.getContentLength());

		cleanDB();
	}

	@Test
	public void testDoPost_Success_Add() throws ServletException, IOException {

		cleanDB();
		setMockMethod();

		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse resp = new MockHttpServletResponse();

		EnterRequest enterRequest = prepareEnterRequest("uniqueId", "URL",
				ComponentType.MFE);

		byte[] context = enterRequest.toByteArray();
		req.setContent(context);

		enterServlet.doPost(req, resp);

		int gmvId = jdbcTemplate.queryForObject("select MU_ID from MATCH_UNITS", Integer.class);
		EnterResponse.Builder enterResponse = EnterResponse.newBuilder();
		enterResponse.setGmvId(gmvId);
		int length = enterResponse.build().getSerializedSize();

		assertEquals(HttpServletResponse.SC_OK, resp.getStatus());
		assertEquals(length, resp.getContentLength());

		cleanDB();
	}

	@Test
	public void testDoPost_Success_Update() throws ServletException,
			IOException {

		cleanDB();
		setMockMethod();
		prepareDBforTest();

		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse resp = new MockHttpServletResponse();

		EnterRequest enterRequest = prepareEnterRequest("uniqueId", "URL",
				ComponentType.MFE);

		byte[] context = enterRequest.toByteArray();
		req.setContent(context);

		enterServlet.doPost(req, resp);

		int gmvId = jdbcTemplate.queryForObject("select MU_ID from MATCH_UNITS", Integer.class);
		EnterResponse.Builder enterResponse = EnterResponse.newBuilder();
		enterResponse.setGmvId(gmvId);
		int length = enterResponse.build().getSerializedSize();

		int count = jdbcTemplate
				.queryForObject("select count(*) from MU_CONTACTS", Integer.class);

		assertEquals(HttpServletResponse.SC_OK, resp.getStatus());
		assertEquals(length, resp.getContentLength());
		assertEquals(1, count);

		cleanDB();
	}

	@Test
	public void testDoPost_BadRequest() throws ServletException, IOException {

		cleanDB();

		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse resp = new MockHttpServletResponse();

		byte[] context = new byte[] { 13, 46, 2, 0, 1, 4, 63, 13, 0 };
		req.setContent(context);

		enterServlet.doPost(req, resp);
		assertEquals(HttpServletResponse.SC_BAD_REQUEST, resp.getStatus());
		assertEquals(119, resp.getContentLength());
	}

	@Test
	public void testDoPost_BadRequest2() throws ServletException, IOException {

		cleanDB();

		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse resp = new MockHttpServletResponse();

		EnterRequest enterRequest = prepareEnterRequest("uniqueId", "URL",
				ComponentType.DM);

		byte[] context = enterRequest.toByteArray();
		req.setContent(context);

		enterServlet.doPost(req, resp);

		assertEquals(HttpServletResponse.SC_BAD_REQUEST, resp.getStatus());
		assertEquals(119, resp.getContentLength());

		cleanDB();
	}

	@Test
	public void testDoPost_InternalError() throws ServletException, IOException {

		cleanDB();

		new MockUp<EnrollStatusManagerBean>() {
			@Mock
			private EnterResponse createEnterResponse(int gmvId) {
				throw new RuntimeException();
			}
		};

		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse resp = new MockHttpServletResponse();

		EnterRequest enterRequest = prepareEnterRequest("uniqueId", "URL",
				ComponentType.MFE);

		byte[] context = enterRequest.toByteArray();
		req.setContent(context);

		enterServlet.doPost(req, resp);

		assertEquals(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, resp
				.getStatus());
		assertEquals(107, resp.getContentLength());

		cleanDB();
	}

	/**
	 * setMockMethod
	 */
	private void setMockMethod() {
		new MockUp<EnrollStatusManagerBean>() {
			@Mock
			private EnterResponse createEnterResponse(int gmvId) {
				EnterResponse.Builder enterResponse = EnterResponse
						.newBuilder();
				enterResponse.setGmvId(gmvId);
				return enterResponse.build();
			}

			@Mock
			private void printLogMessage(String logMessage, Object... objects) {
				return;
			}
		};
	}
}
