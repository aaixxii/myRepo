package jp.co.nec.lsm.tme.servlets;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import com.google.protobuf.ByteString;

import jp.co.nec.lsm.proto.common.CommonProto.ReturnCode;
import jp.co.nec.lsm.proto.extract.ExtractJobResultRequestProto.ExtractJobResult;
import jp.co.nec.lsm.proto.extract.ExtractJobResultRequestProto.ExtractJobResultRequest;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollBatchJobStatus;
import jp.co.nec.lsm.tme.core.jobs.EnrollBatchJobManager;
import jp.co.nec.lsm.tme.core.jobs.LocalEnrollBatchJob;
import jp.co.nec.lsm.tme.core.jobs.LocalExtractJobInfo;
import jp.co.nec.lsm.tme.core.jobs.LocalExtractJobStatus;
import jp.co.nec.lsm.tme.service.pojo.EnrollReportServiceBean;
import mockit.Mock;
import mockit.MockUp;

public class EnrollReportServletTest {

	EnrollReportServlet reportSevlet;
	EnrollBatchJobManager queueManage;

	@Before
	public void setUp() throws ServletException {
		reportSevlet = new EnrollReportServlet();
		reportSevlet.init();

		cleanMemoryQueue();
	}

	@After
	public void tearDown() {
		cleanMemoryQueue();
	}

	/**
	 * 
	 */
	private void cleanMemoryQueue() {
		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		ConcurrentLinkedQueue<LocalEnrollBatchJob> enrollLinkQueue = queueManage
				.getEnrollLinkQueue();

		for (LocalEnrollBatchJob enrollBatchJob : enrollLinkQueue) {
			enrollLinkQueue.remove(enrollBatchJob);
		}
	}

	/**
	 * prepare data for EnrollBatchJobQueues
	 * 
	 * @param batchJobId
	 * @param jobCount
	 */
	private void prepareEnrollBatchJobQueue(long batchJobId, int jobCount) {
		// clear Memory Queue and MATCH_UNITS table
		cleanMemoryQueue();

		// 1 - prepare EnrollBatchJob/ExtractJobRequest For test
		queueManage = EnrollBatchJobManager.getInstance();
		LocalEnrollBatchJob enrollBatchJob = WebTestUtil
				.prepareDateforEnrollResultRequest(batchJobId, jobCount);

		enrollBatchJob.setBatchJobStatus(EnrollBatchJobStatus.EXTRACTING);
		for (int i = 1; i <= jobCount; i++) {
			LocalExtractJobInfo extractJob = enrollBatchJob
					.getExtractJobInfo(i);
			extractJob.setMUId(13);
			extractJob.setStatus(LocalExtractJobStatus.EXTRACTING);
		}
		// 2 - call add, add LocalEnrollBatchJob to database
		queueManage.addEnrollBatchJob(enrollBatchJob);

	}

	/**
	 * 
	 * @param batchJobId
	 * @param jobCount
	 * @return
	 */
	private ExtractJobResultRequest prepareResultRequest(long batchJobId,
			int jobCount) {
		ExtractJobResultRequest.Builder extractResult = ExtractJobResultRequest
				.newBuilder();
		extractResult.setBatchJobId(batchJobId);
		List<ExtractJobResult> extractJobResult = new ArrayList<ExtractJobResult>();

		for (int i = 1; i <= jobCount; i++) {
			ExtractJobResult.Builder jobResult = ExtractJobResult.newBuilder();
			jobResult.setJobIndex(i);
			// jobResult.setReason(Reason + i);
			jobResult.setReturnCode(ReturnCode.JobSuccess);
			jobResult.setErrorCode(i);
			jobResult.setErrorMessage("ErrorMessage_" + i);
			jobResult.setTemplate(prepareTemplate(String.valueOf(jobResult
					.getJobIndex())));
			jobResult.setResponse(WebTestUtil.preperaResponse(batchJobId, i)
					.toByteString());
			extractJobResult.add(jobResult.build());
		}
		extractResult.addAllExtractJobResult(extractJobResult);

		return extractResult.build();

	}

	/**
	 * prepare data for Template
	 * 
	 * @param jobId
	 * @return
	 */
	private ByteString prepareTemplate(String jobId) {
		int len = 200;
		byte[] bs = new byte[len];
		for (int j = 0; j < len; j++) {
			if (j < jobId.length()) {
				bs[j] = jobId.getBytes()[j];
			} else {
				bs[j] = (byte) 15;// (j % 100 + 10);
			}
		}
		return ByteString.copyFrom(bs);
	}

	@Test
	public void testDoPost_Success() throws ServletException, IOException {
		long batchJobId = 4513;
		int jobCount = 13;

		setMockMethod();

		prepareEnrollBatchJobQueue(batchJobId, jobCount);

		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse resp = new MockHttpServletResponse();

		ExtractJobResultRequest request = prepareResultRequest(batchJobId,
				jobCount);

		byte[] context = request.toByteArray();
		req.setContent(context);

		reportSevlet.doPost(req, resp);

		assertEquals(HttpServletResponse.SC_OK, resp.getStatus());
		assertTrue(0 == resp.getContentLength());

		cleanMemoryQueue();
	}

	@Test
	public void testDoPost_InternalError() throws ServletException, IOException {
		long batchJobId = 45313;
		int jobCount = 13;
		cleanMemoryQueue();

		new MockUp<EnrollReportServiceBean>() {
			@Mock
			private void printLogMessage(String logMessage) {
				throw new RuntimeException();
			}
		};

		prepareEnrollBatchJobQueue(batchJobId, jobCount);

		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse resp = new MockHttpServletResponse();

		ExtractJobResultRequest request = prepareResultRequest(batchJobId,
				jobCount);

		byte[] context = request.toByteArray();
		req.setContent(context);

		reportSevlet.doPost(req, resp);

		assertEquals(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, resp
				.getStatus());
		assertEquals(108, resp.getContentLength());

		cleanMemoryQueue();
	}

	@Test
	public void testDoPost_BadRequest() throws ServletException, IOException {

		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse resp = new MockHttpServletResponse();

		byte[] context = new byte[] { 13, 46, 2, 0, 1, 4, 63, 13, 0 };
		req.setContent(context);

		reportSevlet.doPost(req, resp);
		assertEquals(HttpServletResponse.SC_BAD_REQUEST, resp.getStatus());
		assertEquals(124, resp.getContentLength());
	}

	@Test
	public void testDoPost_NoContext() throws ServletException, IOException {

		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse resp = new MockHttpServletResponse();

		reportSevlet.doPost(req, resp);

		assertEquals(HttpServletResponse.SC_OK, resp.getStatus());
		assertEquals(0, resp.getContentLength());
	}

	/**
	 * setMockMethod
	 */
	private void setMockMethod() {
		new MockUp<EnrollReportServiceBean>() {
			@Mock
			private void printLogMessage(String logMessage) {
				return;
			}
		};
	}
}
