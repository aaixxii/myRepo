(function() {
	window.onload= function(){
//		document.getElementById("hiddenLink").style.visibility="hidden";
	};
	
 })()