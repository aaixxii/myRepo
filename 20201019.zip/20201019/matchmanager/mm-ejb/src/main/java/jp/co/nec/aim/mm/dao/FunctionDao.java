package jp.co.nec.aim.mm.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import jp.co.nec.aim.mm.entities.FunctionTypeEntity;
import jp.co.nec.aim.mm.entities.QueueType;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.util.CollectionsUtil;

/**
 * FunctionDao Utility
 * 
 * @author liuyq
 * 
 */
public class FunctionDao {
	private EntityManager manager; // EntityManager instance

	public FunctionDao(EntityManager manager) {
		this.manager = manager;
	}

	/**
	 * getFunction
	 * 
	 * @param functionId
	 * @return FunctionTypeEntity instance
	 */
	public FunctionTypeEntity getFunction(int functionId) {
		return manager.find(FunctionTypeEntity.class, functionId);
	}

	/**
	 * getFunctionByName
	 * 
	 * @param functionName
	 *            will replace '-'
	 * @return FunctionTypeEntity instance
	 */
	@SuppressWarnings("unchecked")
	public FunctionTypeEntity getFunctionByName(String functionName) {
		Query q = manager.createNamedQuery("NQ::getFunctionByName");
		q.setParameter("name", functionName);
		List<FunctionTypeEntity> results = q.getResultList();
		if (CollectionsUtil.isEmpty(results)) {
			return null;
		}
		return CollectionsUtil.getFirst(results);
	}

	@SuppressWarnings("unchecked")
	public FunctionTypeEntity getExtractFunction() {
		Query q = manager.createNamedQuery("NQ::getFunctionByType");
		q.setParameter("type", QueueType.EXTRACT);
		List<FunctionTypeEntity> results = q.getResultList();
		if (results.isEmpty())
			return null;
		if (1 < results.size()) {
			throw new AimRuntimeException(
					"Function configuration error: multiple functions of EXTRACTION type configured.");
		} else
			return results.get(0);
	}

	@SuppressWarnings("unchecked")
	public List<FunctionTypeEntity> getSearchFunctions() {
		Query q = manager.createNamedQuery("NQ::getFunctionByType");
		q.setParameter("type", QueueType.INQUIRY);
		return (List<FunctionTypeEntity>) q.getResultList();
	}

	public int getExtractTimeouts() {
		Query q = manager.createNamedQuery("NQ::getExtractTimeouts");
		Long timeouts = (Long) q.getSingleResult();
		return timeouts.intValue();
	}
}
