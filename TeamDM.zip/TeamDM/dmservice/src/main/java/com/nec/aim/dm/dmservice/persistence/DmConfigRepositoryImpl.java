package com.nec.aim.dm.dmservice.persistence;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class DmConfigRepositoryImpl implements DmConfigRepository {

	private static final String redundancySql = "select KEY_VALUE from DM_CONFIG_INFO where KEY_NAME='REDUNDANCY'";
	private static final String syncModeSql = "select KEY_VALUE from DM_CONFIG_INFO where KEY_NAME='SYNC_MODE'";

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public int getRedundancy() throws SQLException {
		return jdbcTemplate.queryForObject(redundancySql, Integer.class);
	}

	@Override
	public String getSyncMode() throws SQLException {
		return jdbcTemplate.queryForObject(syncModeSql, String.class);
	}

}
