package com.nec.aim.uid.amqclient.receiver;

import java.io.IOException;

import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.support.AmqpMessageHeaderAccessor;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import com.nec.aim.uid.amqclient.result.CallbackWriter;
import com.nec.aim.uid.amqclient.xml.XmlUtil;
import com.rabbitmq.client.Channel;

@Service
@RabbitListener(queues ="inqResQueue", ackMode = "MANUAL")
public class InqResReceiver {
	
	   @RabbitHandler
	    public void handle(@Payload String message, AmqpMessageHeaderAccessor messageHeaderAccessor, Channel channel) throws IOException {
	        System.out.println("My Recevied inq respose message "  + message);
	        try{	
	            channel.basicAck(messageHeaderAccessor.getDeliveryTag(),false);
	        }catch (Exception e){	  
	            new DirectExchange("");
	            channel.basicNack(messageHeaderAccessor.getDeliveryTag(),false,true);
	        }
	        String reqeustId = XmlUtil.getRequestId(message);
	        CallbackWriter cw = new CallbackWriter( reqeustId, message);
	        Thread th = new Thread(cw);
	        th.start();
	    }

	    @RabbitHandler
	    public void handle(@Payload byte[] bytes,AmqpMessageHeaderAccessor messageHeaderAccessor, Channel channel) throws IOException {
	        System.out.println("My Recevied message " + new String(bytes,"utf-8"));	  
	        channel.basicAck(messageHeaderAccessor.getDeliveryTag(),true);
	    }
}

//channel.basicAck(message.getMessageProperties().getDeliveryTag(), false);
//channel.basicNack(message.getMessageProperties().getDeliveryTag(), false, true);
//channel.basicReject(message.getMessageProperties().getDeliveryTag(), true);