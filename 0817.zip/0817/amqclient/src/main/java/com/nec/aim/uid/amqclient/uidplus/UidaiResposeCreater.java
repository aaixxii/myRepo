package com.nec.aim.uid.amqclient.uidplus;

import java.io.IOException;
import java.io.StringWriter;

import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;

/**
 * @author xia
 *
 */
public class UidaiResposeCreater {
	public static String buildSuccessInquiryRespose(String requeustid, String refId, String url) throws IOException {
		// xml response return:0:notused,1:Successed, 2:Failed
		 Document document = DocumentHelper.createDocument();
		 Element root = document.addElement("Response");
		 root.addElement("Return").addAttribute("value", "1");
		for (int i = 0; i< 10; i++) {
			 Element candidate = DocumentHelper.createElement("Candidate");
			 candidate.addAttribute("faceScore", "99")
			 .addAttribute("RightIrisScore", "99")
			 .addAttribute("FingerBothThumbsScore", "99")
			 .addAttribute("FingerRightSlapScore", "99")
			 .addAttribute("FingerLeftSlapScore", "99")
			 .addAttribute("scaledScore", "99")
			 .addAttribute("referenceId", "referId" + i);			 
			 root.addElement("CandidateList").addAttribute("more", "true").addAttribute("count", "10")
			 .add(candidate); 
			 
		}
		 root.addAttribute("timeStamp", String.valueOf(System.currentTimeMillis()))
		     .addAttribute("version", "3.0")
		     .addAttribute("requestId", requeustid);		 

		OutputFormat format = OutputFormat.createPrettyPrint();
		StringWriter sw = new StringWriter();
		XMLWriter writer = new XMLWriter(sw, format);
		writer.write(document);
		String resuslt = sw.toString();
		return resuslt;
	}
	
	public static String buildFaildInquiryRespose(String requeustid, String refId, String url, int returnValue, int failureReason) throws IOException {
		// xml response return:0:notused,1:Successed, 2:Failed
		 Document document = DocumentHelper.createDocument();
		 Element root = document.addElement("Response");
		 root.addElement("Return")
		 .addAttribute("value", String.valueOf(returnValue))
		 .addAttribute("failureReason", String.valueOf(failureReason));	
		 root.addAttribute("timeStamp", String.valueOf(System.currentTimeMillis()))
		     .addAttribute("version", "3.0")
		     .addAttribute("requestId", requeustid);	
		 
		 root.addAttribute("timeStamp", String.valueOf(System.currentTimeMillis()))
	     .addAttribute("version", "3.0")
	     .addAttribute("requestId", requeustid);		 

		OutputFormat format = OutputFormat.createPrettyPrint();
		StringWriter sw = new StringWriter();
		XMLWriter writer = new XMLWriter(sw, format);
		writer.write(document);
		String resuslt = sw.toString();
		return resuslt;
	}
	
	
	public static String buildExtractPayload(String refId, String url) throws IOException {
		 Document document = DocumentHelper.createDocument();
		 document.addElement( "quality-payload")
				 .addAttribute("referenceId", refId)
				 .addAttribute("referenceUrl", url);
		 OutputFormat format = OutputFormat.createPrettyPrint();
		 StringWriter sw = new StringWriter();
       XMLWriter writer  = new XMLWriter(sw, format);        
       writer.write(document);
       String resuslt = sw.toString();		 
		return resuslt;
	}
	
	public static String buildgiagnostics(int count) throws IOException {		
		 Element diagnostics = DocumentHelper.createElement("Diagnostics");
		for (int i = 0; i < count; i++) {
			 Element diagnostic = DocumentHelper.createElement("Diagnostic");
			 diagnostic.addAttribute("attempt", String.valueOf(i + 1));
			 String subType = null;
			 String type = null;
			 switch (i % 4) {
				case 0:
					subType = "finger";
					type = "finger";
				break;
				case 1:
					subType = "face";
					type = "face";
				break;	
				case 2:
					subType = "iris";
					type = "iris";
				break;
				case 3:
					subType = "voice";
					type = "voice";
				break;
				 default:
			}
			 
			 diagnostic.addAttribute("subtype", subType)				
			 .addAttribute("type", type);
			 diagnostics.add(diagnostic);
		}
		OutputFormat format = OutputFormat.createPrettyPrint();
		StringWriter sw = new StringWriter();
		XMLWriter writer = new XMLWriter(sw, format);
		writer.write(diagnostics);
		String resuslt = sw.toString();
		return resuslt;
	}
	
	public static Element buildGiagnosticsElement(int count) throws IOException {		
		 Element diagnostics = DocumentHelper.createElement("Diagnostics");
		for (int i = 0; i < count; i++) {
			 Element diagnostic = DocumentHelper.createElement("Diagnostic");
			 diagnostic.addAttribute("attempt", String.valueOf(i + 1));
			 String subType = null;
			 String type = null;
			 switch (i % 4) {
				case 0:
					subType = "finger";
					type = "finger";
				break;
				case 1:
					subType = "face";
					type = "face";
				break;	
				case 2:
					subType = "iris";
					type = "iris";
				break;
				case 3:
					subType = "voice";
					type = "voice";
				break;
				 default:
			}
			 
			 diagnostic.addAttribute("subtype", subType)				
			 .addAttribute("type", type);
			 diagnostics.add(diagnostic);
		}	
		return diagnostics;
	}
	
	public static String buildFaildExtractXmlRespose(String requestId , String success, String failureReason) throws IOException {
		 Document document = DocumentHelper.createDocument();
		 Element root = document.addElement( "Response")
				 .addAttribute("requestId", requestId)
				 .addAttribute("timeStamp", String.valueOf(System.currentTimeMillis()));
		 root.addElement("Return").addAttribute("value", String.valueOf(success));
		 root.addElement("Return").addAttribute("failureReason", String.valueOf(failureReason));
		 OutputFormat format = OutputFormat.createPrettyPrint();
		 StringWriter sw = new StringWriter();
      XMLWriter writer  = new XMLWriter(sw, format);        
      writer.write(document);
      String resuslt = sw.toString();		 
		return resuslt;		
	}	
	
	
	public static String buildSuccessExtractXmlRespose(String requestId) throws IOException {
		 Document document = DocumentHelper.createDocument();
		 Element root = document.addElement("Response");
		 root.addElement("Return").addAttribute("value", "1");
		 Element gnostics = buildGiagnosticsElement(4);
		 root.add(gnostics);
	
		 root.addAttribute("timeStamp", String.valueOf(System.currentTimeMillis()))
		     .addAttribute("version", "3.0")
		     .addAttribute("requestId", requestId);		 

		OutputFormat format = OutputFormat.createPrettyPrint();
		StringWriter sw = new StringWriter();
		XMLWriter writer = new XMLWriter(sw, format);
		writer.write(document);
		String resuslt = sw.toString();
		return resuslt;		
	}
}
