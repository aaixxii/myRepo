package com.nec.aim.uid.amqclient.util;
public enum SequenceIdType {
	
	REQUST_ID(0),
	REFERENCE_ID(1);
	

	
	private long val;
	
	private  SequenceIdType(long val) {
		this.val = val;		
	}
	
	public long getVal() {
		return val;
	}

}
