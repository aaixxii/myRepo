package com.nec.aim.uid.amqclient.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import lombok.Data;

@Data
@Component
public class ConfigProperties {
	
	@Value("${spring.rabbitmq.host}")
	private String serverName;	
	
	@Value("${spring.rabbitmq.port}")
	private String serverPort;
	
	@Value("${spring.rabbitmq.username}")
	private String userName;	
	
	@Value("${spring.rabbitmq.password}")
	private String userPasswd;
	
	@Value("${spring.rabbitmq.virtual-host}")
	private String vhost;
	
	@Value("${spring.rabbitmq.connection-timeout}")
	private String connTimeOut;
	
	@Value("${mq.command.queue}")
	private String command;	

	@Value("${mq.ext.req.direct.exchange}")
	private String extReqExchangeName;	
	
	@Value("${mq.ext.req.queue}")
	private String extReqQueueName;
	
	@Value("${mq.ext.req.routing.key}")
	private String extReqKeyName;
	
	@Value("${mq.ext.res.direct.exchange}")
	private String extResExchangeName;	
	
	@Value("${mq.ext.res.queue}")
	private String extResQueueName;
	
	@Value("${mq.ext.res.routing.key}")
	private String extResKeyName;
	
//	@Value("${mq.ext.alternate.exchange}")
//	private String extAlternateExchange;
	
	@Value("${mq.ins.req.direct.exchange}")
	private String insReqExchangeName;	
	
	@Value("${mq.ins.req.queue}")
	private String insReqQueueName;
	
	@Value("${mq.ins.req.routing.key}")
	private String insReqKeyName;
	
	@Value("${mq.ins.res.direct.exchange}")
	private String insResExchangeName;	
	
	@Value("${mq.ins.res.queue}")
	private String insResQueueName;
	
	@Value("${mq.ins.res.routing.key}")
	private String insResKeyName;
	
	@Value("${mq.del.req.direct.exchange}")
	private String delReqExchangeName;	
	
	@Value("${mq.del.req.queue}")
	private String delReqQueueName;
	
	@Value("${mq.del.req.routing.key}")
	private String delReqKeyName;
	
	@Value("${mq.del.res.direct.exchange}")
	private String delResExchangeName;	
	
	@Value("${mq.del.res.queue}")
	private String delResQueueName;
	
	@Value("${mq.del.res.routing.key}")
	private String delResKeyName;
	
//	@Value("${mq.sync.alternate.exchange}")
//	private String syncAlternateExchange;
	
	@Value("${mq.inq.req.direct.exchange}")
	private String inqReqExchangeName;	
	
	@Value("${mq.inq.req.queue}")
	private String inqReqQueueName;
	
	@Value("${mq.inq.req.routing.key}")
	private String inqReqKeyName;
	
	@Value("${mq.inq.res.direct.exchange}")
	private String inqResExchangeName;	
	
	@Value("${mq.inq.res.queue}")
	private String inqResQueueName;
	
	@Value("${mq.inq.res.routing.key}")
	private String inqResKeyName;
	
//	@Value("${mq.inq.alternate.exchange}")
//	private String inqAlternateExchange;
	
	@Value("${mq.dead.letter.exchange}")
	private String deadExchangeName;	
	
	@Value("${mq.dead.letter.queue}")
	private String deadQueueName;
	
	@Value("${mq.dead.letter.routing.key}")
	private String deadKeyName;	
	
	@Value("${udai.image.url}")
	private String udaiImageUrl;	
	
}
