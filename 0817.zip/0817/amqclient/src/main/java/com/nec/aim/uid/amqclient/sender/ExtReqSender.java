package com.nec.aim.uid.amqclient.sender;

import org.springframework.amqp.rabbit.connection.CorrelationData;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nec.aim.uid.amqclient.config.ConfigProperties;
import com.nec.aim.uid.amqclient.interf.SendMessageService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ExtReqSender implements SendMessageService {
	
	@Autowired
    private RabbitTemplate rabbitTemplate;
	
	@Autowired
    private ConfigProperties mqConfig;		

	@Override
	public void confirm(CorrelationData correlationData, boolean ack, String cause) {
		log.info("correlationData:{}; ack: {}; cause: {} ;",  correlationData, ack, cause);
	        if (ack) {
	            log.info("confirm success.");
	        } else {
	            log.info("confirm faild");
	        }
	}

	@Override
	public void sendMessage(Object message) {		 
        //rabbitTemplate.setConfirmCallback(this);       
        CorrelationData correlationData = new CorrelationData();
        rabbitTemplate.convertAndSend(mqConfig.getExtReqExchangeName(),mqConfig.getExtReqKeyName(),  message, correlationData);
        log.info("Success Send message using {} to {}", mqConfig.getExtReqExchangeName(), mqConfig.getExtReqKeyName());		
	}
	
	 public void sendSring(String data) {	     
	       this.rabbitTemplate.convertAndSend(mqConfig.getExtReqKeyName(), data);
	    }	
}
