package com.nec.aim.uid.amqclient.config;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitAdmin;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.rabbit.transaction.RabbitTransactionManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import lombok.extern.slf4j.Slf4j;


@Slf4j
@Configuration
public class AmqConfigBean {
	private  boolean durable = false;
    private boolean exclusive = false;
    private boolean autoDelete = false;       
    
    @Autowired
    private ConfigProperties mqConfig; 
    
    @Bean("amqConnectionFactory")
    public ConnectionFactory amqConnectionFactory() {
        CachingConnectionFactory connectionFactory = new CachingConnectionFactory(mqConfig.getServerName());
        connectionFactory.setUsername(mqConfig.getUserName());
        connectionFactory.setPassword(mqConfig.getUserPasswd());
        connectionFactory.setPort(Integer.valueOf(mqConfig.getServerPort()));
        connectionFactory.setVirtualHost(mqConfig.getVhost());
        return connectionFactory;
    } 
    
    @Bean(value = "amqRabbitAdmin")
    public RabbitAdmin pmsRabbitAdmin(){
        RabbitAdmin rabbitAdmin=new RabbitAdmin(amqConnectionFactory());
        rabbitAdmin.setAutoStartup(true);
        return rabbitAdmin;
    }  
    
    @Bean("extReqQueue")
    public Queue extReqQueue(){
//    	 Map<String, Object> arguments = new HashMap<>(4);
//    	 arguments.put("x-message-ttl", 10000);
//    	 arguments.put("x-dead-letter-exchange", mqConfig.getDeadExchangeName());
//    	 arguments.put("x-dead-letter-routing-key", mqConfig.getDeadKeyName());
    	return new Queue(mqConfig.getExtReqQueueName(), durable, exclusive, autoDelete);    	
    }
    
    @Bean("extReqExchange")
    DirectExchange extReqExchange() {
//    	 Map<String, Object> arguments = new HashMap<>(4);
//    	 arguments.put("alternate-exchange", mqConfig.getExtAlternateExchange());
        return new DirectExchange(mqConfig.getExtReqExchangeName(), durable, autoDelete);
    }
    
    @Bean
    public Binding extReqExchangeBinding(){    
        return  BindingBuilder.bind(extReqQueue()).to(extReqExchange()).with(mqConfig.getExtReqKeyName());
    }
    
    @Bean("extResQueue")
    public Queue extResQueue(){
//    	 Map<String, Object> arguments = new HashMap<>(4);
//    	 arguments.put("x-message-ttl", 10000);
//    	 arguments.put("x-dead-letter-exchange", mqConfig.getDeadExchangeName());
//    	 arguments.put("x-dead-letter-routing-key", mqConfig.getDeadKeyName());
    	return new Queue(mqConfig.getExtResQueueName(), durable, exclusive, autoDelete);    	
    }
    
    @Bean("extResExchange")
    DirectExchange extResExchange() {
//    	 Map<String, Object> arguments = new HashMap<>(4);
//    	 arguments.put("alternate-exchange", mqConfig.getExtAlternateExchange());
        return new DirectExchange(mqConfig.getExtResExchangeName(), durable, autoDelete);
    }
    
    @Bean
    public Binding extResExchangeBinding(){    
        return  BindingBuilder.bind(extResQueue()).to(extResExchange()).with(mqConfig.getExtResKeyName());
    } 
    
    @Bean("insReqQueue")
    public Queue insReqQueue(){
//    	 Map<String, Object> arguments = new HashMap<>(4);
//    	 arguments.put("x-message-ttl", 10000);
//    	 arguments.put("x-dead-letter-exchange", mqConfig.getDeadExchangeName());
//    	 arguments.put("x-dead-letter-routing-key", mqConfig.getDeadKeyName());
    	return new Queue(mqConfig.getInsReqQueueName(), durable, exclusive, autoDelete);    	
    }
    
    @Bean("insReqExchange")
    DirectExchange insReqExchange() {
//    	 Map<String, Object> arguments = new HashMap<>(4);
//    	 arguments.put("alternate-exchange", mqConfig.getSyncAlternateExchange());
        return new DirectExchange(mqConfig.getInsReqExchangeName(), durable, autoDelete);
    }
    
    @Bean
    public Binding insReqExchangeBinding(){    
        return  BindingBuilder.bind(insReqQueue()).to(insReqExchange()).with(mqConfig.getInsReqKeyName());
    } 
    
    @Bean("insResQueue")
    public Queue insResQueue(){
//    	 Map<String, Object> arguments = new HashMap<>(4);
//    	 arguments.put("x-message-ttl", 10000);
//    	 arguments.put("x-dead-letter-exchange", mqConfig.getDeadExchangeName());
//    	 arguments.put("x-dead-letter-routing-key", mqConfig.getDeadKeyName());
    	return new Queue(mqConfig.getInsResQueueName(), durable, exclusive, autoDelete);    	
    }
    
    @Bean("insResExchange")
    DirectExchange insResExchange() {
//    	 Map<String, Object> arguments = new HashMap<>(4);
//    	 arguments.put("alternate-exchange", mqConfig.getSyncAlternateExchange());
        return new DirectExchange(mqConfig.getInsResExchangeName(), durable, autoDelete);
    }
    
    @Bean
    public Binding insResExchangeBinding(){    
        return  BindingBuilder.bind(insResQueue()).to(insResExchange()).with(mqConfig.getInsResKeyName());
    }  
    
    //del    
    @Bean("delReqQueue")
    public Queue delReqQueue(){
//    	 Map<String, Object> arguments = new HashMap<>(4);
//    	 arguments.put("x-message-ttl", 10000);
//    	 arguments.put("x-dead-letter-exchange", mqConfig.getDeadExchangeName());
//    	 arguments.put("x-dead-letter-routing-key", mqConfig.getDeadKeyName());
    	return new Queue(mqConfig.getDelReqQueueName(), durable, exclusive, autoDelete);    	
    }
    
    @Bean("delReqExchange")
    DirectExchange delReqExchange() {
//    	 Map<String, Object> arguments = new HashMap<>(4);
//    	 arguments.put("alternate-exchange", mqConfig.getSyncAlternateExchange());
        return new DirectExchange(mqConfig.getDelReqExchangeName(), durable, autoDelete);
    }
    
    @Bean
    public Binding delReqExchangeBinding(){    
        return  BindingBuilder.bind(delReqQueue()).to(delReqExchange()).with(mqConfig.getDelReqKeyName());
    } 
    
    @Bean("delResQueue")
    public Queue delResQueue(){
//    	 Map<String, Object> arguments = new HashMap<>(4);
//    	 arguments.put("x-message-ttl", 10000);
//    	 arguments.put("x-dead-letter-exchange", mqConfig.getDeadExchangeName());
//    	 arguments.put("x-dead-letter-routing-key", mqConfig.getDeadKeyName());
    	return new Queue(mqConfig.getDelResQueueName(), durable, exclusive, autoDelete);    	
    }
    
    @Bean("delResExchange")
    DirectExchange delResExchange() {
//    	 Map<String, Object> arguments = new HashMap<>(4);
//    	 arguments.put("alternate-exchange", mqConfig.getSyncAlternateExchange());
        return new DirectExchange(mqConfig.getDelResExchangeName(), durable, autoDelete);
    }
    
    @Bean
    public Binding delResExchangeBinding(){    
        return  BindingBuilder.bind(delResQueue()).to(delResExchange()).with(mqConfig.getDelReqKeyName());
    } 
    //end del
    
    //inq
    @Bean("inqReqQueue")
    public Queue inqReqQueue(){
//    	 Map<String, Object> arguments = new HashMap<>(4);
//    	 arguments.put("x-message-ttl", 10000);
//    	 arguments.put("x-dead-letter-exchange", mqConfig.getDeadExchangeName());
//    	 arguments.put("x-dead-letter-routing-key", mqConfig.getDeadKeyName());
    	return new Queue(mqConfig.getInqReqQueueName(), durable, exclusive, autoDelete);    	
    }
    
    @Bean("inqReqExchange")
    DirectExchange inqReqExchange() {
//    	 Map<String, Object> arguments = new HashMap<>(4);
//    	 arguments.put("alternate-exchange", mqConfig.getInqAlternateExchange());
        return new DirectExchange(mqConfig.getInqReqExchangeName(), durable, autoDelete);
    }
    
    @Bean
    public Binding inqReqExchangeBinding(){    
        return  BindingBuilder.bind(inqReqQueue()).to(inqReqExchange()).with(mqConfig.getInqReqKeyName());
    }
    
    @Bean("inqResQueue")
    public Queue inqResQueue(){
//    	 Map<String, Object> arguments = new HashMap<>(4);
//    	 arguments.put("x-message-ttl", 10000);
//    	 arguments.put("x-dead-letter-exchange", mqConfig.getDeadExchangeName());
//    	 arguments.put("x-dead-letter-routing-key", mqConfig.getDeadKeyName());
    	return new Queue(mqConfig.getInqResQueueName(), durable, exclusive, autoDelete);    	
    }
    
    @Bean("inqResExchange")
    DirectExchange inqResExchange() {
//    	 Map<String, Object> arguments = new HashMap<>(4);
//    	 arguments.put("alternate-exchange", mqConfig.getInqAlternateExchange());
        return new DirectExchange(mqConfig.getInqResExchangeName(), durable, autoDelete);
    }
    
    @Bean
    public Binding inqResExchangeBinding(){    
        return  BindingBuilder.bind(inqResQueue()).to(inqResExchange()).with(mqConfig.getInqResKeyName());
    } 
    //end inq
 
    @Bean
    public RabbitTemplate rabbitTemplate() {
        RabbitTemplate rabbitTemplate = new RabbitTemplate(amqConnectionFactory());
        rabbitTemplate.setEncoding("UTF-8");
        rabbitTemplate.setMandatory(true);
        rabbitTemplate.setReturnCallback(((message,  replyCode, replyText, exchange, routingKey) -> {
            String correlationId = message.getMessageProperties().getCorrelationId();
            log.info("Mesaage：{} send faild, reply code：{}  reason：{}  exchange:{} roading key:{}", correlationId, replyCode, replyText, exchange, routingKey);
        }));
       
        rabbitTemplate.setConfirmCallback(((correlationData, ack, cause) ->{
            if (ack) {
               log.info(" send message success ,correlationId:{}",correlationData.getId());
            } else {
                log.info("send message faild,reason:{}",cause);
            }
        } ));
        
        return rabbitTemplate;
    }  
    
    @Bean("rabbitTransactionManager")
    public RabbitTransactionManager rabbitTransactionManager(CachingConnectionFactory connectionFactory) {
        return new RabbitTransactionManager(connectionFactory);
    }
    
//	@Bean
//	public SimpleMessageListenerContainer simpleMessageListenerContainer(ConnectionFactory connectionFactory) {
//		SimpleMessageListenerContainer container = new SimpleMessageListenerContainer(connectionFactory);
//		container.setQueues(extReqQueue(), insResQueue(), delResQueue(), inqResQueue());
//
//		container.setAcknowledgeMode(AcknowledgeMode.AUTO);
//		container.setConcurrentConsumers(1);
//		container.setMaxConcurrentConsumers(5);
//		container.setDefaultRequeueRejected(false);
//		container.setConsumerTagStrategy(new ConsumerTagStrategy() {
//			@Override
//			public String createConsumerTag(String s) {
//				return s + "_" + UUID.randomUUID().toString();
//			}
//		});
//		container.setMessageListener(new ChannelAwareMessageListener() {
//
//			@Override
//			public void onMessage(Message message, Channel channel) throws Exception {
//				System.out.println("-------------Received message ：" + new String(message.getBody()));
//			}
//		
//		});
//		return container;
//	}

}
