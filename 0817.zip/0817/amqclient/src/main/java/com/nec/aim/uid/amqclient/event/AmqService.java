package com.nec.aim.uid.amqclient.event;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.nec.aim.uid.amqclient.config.AmqConfigBean;
import com.nec.aim.uid.amqclient.config.ConfigProperties;
import com.nec.aim.uid.amqclient.util.SequenceCreater;
import com.rabbitmq.client.AMQP.Queue.DeclareOk;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

@Component
public class AmqService {

	@Autowired
	ConfigProperties configProperties;

	@Autowired
	AmqConfigBean amqConfigBean;

	public int getExtReqQueueCount() throws IOException, TimeoutException {		
		Connection extReqConnection = getConnection();
		Channel channel = extReqConnection.createChannel();		
		DeclareOk declareOk = channel.queueDeclarePassive(amqConfigBean.extReqQueue().getName());
		int sum = declareOk.getMessageCount();
		return sum;
	}
	
	public int getInsResQueueCount() throws IOException, TimeoutException {		
		Connection insReqConnection = getConnection();
		Channel channel = insReqConnection.createChannel();		
		DeclareOk declareOk = channel.queueDeclarePassive(amqConfigBean.insReqQueue().getName());
		int sum = declareOk.getMessageCount();
		return sum;
	}
	
	public int getDelReqQueueCount() throws IOException, TimeoutException {	
		Connection delReqConnection = getConnection();
		Channel channel = delReqConnection.createChannel();	
		DeclareOk declareOk = channel.queueDeclarePassive(amqConfigBean.delReqQueue().getName());
		int sum = declareOk.getMessageCount();
		return sum;
	}
	
	public int getInqReqQueueCount() throws IOException, TimeoutException {	
		Connection inqReqConnection =getConnection();
		Channel channel = inqReqConnection.createChannel();		
		DeclareOk declareOk = channel.queueDeclarePassive(amqConfigBean.inqReqQueue().getName());
		int sum = declareOk.getMessageCount();
		return sum;
	}
	
	private Connection getConnection() throws IOException, TimeoutException {
		ConnectionFactory factory = new ConnectionFactory();
		factory.setHost(configProperties.getServerName());
		factory.setPort(Integer.valueOf(configProperties.getServerPort()));
		factory.setUsername(configProperties.getUserName());
		factory.setPassword(configProperties.getUserPasswd());
		factory.setVirtualHost(configProperties.getVhost());
		Connection connection = factory.newConnection();
		return connection;		
	}
	
	@PreDestroy
    public void after()  {
		SequenceCreater.saveValues();
	}
}
