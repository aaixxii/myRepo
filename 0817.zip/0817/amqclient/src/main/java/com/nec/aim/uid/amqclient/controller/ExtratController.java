package com.nec.aim.uid.amqclient.controller;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.nec.aim.uid.amqclient.config.ConfigProperties;
import com.nec.aim.uid.amqclient.event.AmqService;
import com.nec.aim.uid.amqclient.sender.ExtReqSender;
import com.nec.aim.uid.amqclient.uidplus.UidaiRequestCreater;
import com.nec.aim.uid.amqclient.util.SequenceCreater;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class ExtratController {
	
	 @Autowired
	 ExtReqSender extReqSender;
	 
	 @Autowired
	 ConfigProperties configProperties;
	 
	 @Autowired
	 AmqService amqService;
	
	 @GetMapping("/ext")
	public Boolean publish(){
			String enrollId = SequenceCreater.getNextRefIdSequece();
			String requestId = SequenceCreater.getNextRequestIdSequece();
			String refUrl = configProperties.getUdaiImageUrl();
			try {
				String extReq = UidaiRequestCreater.buildExtractRequest(requestId, enrollId, refUrl);
				extReqSender.sendMessage(extReq);
				return Boolean.TRUE;
				
			} catch (IOException e) {
				log.error(e.getMessage(), e);
				return Boolean.FALSE;
			}		 
	 }
	 
	 @RequestMapping(value="/ext/{count}", method=RequestMethod.GET)
	 public int batchPublish(@PathVariable String count) {
		 int sendCount = 0;
		 int intCount = Integer.valueOf(count);
		 for (int i = 0; i < intCount; i++) {			 
			 try {
				send();
				sendCount++;
				try {
					Thread.currentThread().sleep(100);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} catch (IOException e) {
				log.error(e.getMessage(), e);
				if (sendCount > 0) {
					sendCount--;
				}
			}
		 }
		return sendCount;	   
	 }
	 
	 private void send() throws IOException {
			String enrollId = SequenceCreater.getNextRefIdSequece();
			String requestId = SequenceCreater.getNextRequestIdSequece();
			String refUrl = configProperties.getUdaiImageUrl();
			String extReq = UidaiRequestCreater.buildExtractRequest(requestId, enrollId, refUrl);
			extReqSender.sendMessage(extReq);	
	 }
	 
	 @GetMapping("/getExtReqCount")
	 public int getMessageCountInExtReqQueue() {
		try {
			return  amqService.getExtReqQueueCount();
		} catch (IOException | TimeoutException e) {			
			e.printStackTrace();
			return -999;
		}		 
	 }
}
