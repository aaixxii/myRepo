package com.nec.lmx.agent;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.lmx.agent.lmx.LicenseManager;
import com.nec.lmx.agent.socket.LmxSocketMaster;

/**
 * @author xiazp
 *
 */
public class LmxAgent {
	
	public LmxAgent() {		
	}	
	private static final Logger logger = LoggerFactory.getLogger(LmxAgent.class);		
	private static  String PORT;	
	private static  String LICENSE_SERVER_URL;
	
	
	public static void main(String[] args) {	
		LmxAgent LmxAgent = new LmxAgent();		
		LmxAgent.handleParameter(args);
		//checkLmxLibPath();		
		
		 String licenseServerUrl = System.getProperty("java.lmx.license.path");
		 if (licenseServerUrl == null || licenseServerUrl.isEmpty()) {			
			logger.error("License server url is invaild: it's empty!");
			System.exit(1);
		 }
		if (isCheckUrl(licenseServerUrl)) {
			LICENSE_SERVER_URL = licenseServerUrl;			
		} else {
			logger.error("License server url is invaild: {}", licenseServerUrl);
			System.exit(1);
		}
		startAgent();		
	}
	
	private void handleParameter(String[] args) {		
		if (args.length < 1) {			
			pringUsage();
			System.exit(1);
		} 
		
		if (args[0].isEmpty()) {
			pringUsage();
			System.exit(1);
		}
		
		 if (args[0].length() >= 1) {
			if (isMatchPort(args[0])) {
				 PORT = args[0];				 
			} 
		 }		
	}
	
	private void pringUsage() {
		String lineSeparater = System.getProperties().getProperty("line.separator");
		StringBuilder sb = new StringBuilder();
		sb.append("Usage for boot LmxAgnet:");
		sb.append(lineSeparater);
		sb.append("java - jar lmx-agent.jar port");
		logger.info(sb.toString());		
		sb.delete(0, sb.length());
	}	
	
	
	private static void startAgent() {
		LmxSocketMaster agent = new LmxSocketMaster(Integer.valueOf(PORT));	
		new Thread(agent).start();
		LicenseManager fm = LicenseManager.getInstance();
	    fm.initLmx(LICENSE_SERVER_URL);		
	    	
	}	
	
	private boolean isMatchPort(String port) {
		if (port == null || port.isEmpty()) {
			return false;
		}
		 Pattern p = Pattern.compile("^[1-9]*$");
		 Matcher m = p.matcher(port);
		 return m.matches();
		//return port.matches("^[0-9]*$");
	}
	
	private  static boolean isCheckUrl(String licenseServerUrl) {		
		if (licenseServerUrl == null || licenseServerUrl.isEmpty()) {
			return false;
		} 		
		int index = licenseServerUrl.indexOf("@");
		if (index < 0 ) {
			return false;
		} else {
			String firstEx = licenseServerUrl.substring(0, index);
			if (!firstEx.matches("^[0-9]*$")) {
				return false;				
			} else {
				 String tmp = licenseServerUrl.substring(index + 1, licenseServerUrl.length());
				if (tmp == null || tmp.length() < 1) {
					return false;
				} else {
					return true;
				}
			}
		}
	}
	
	@SuppressWarnings("unused")
	private static void checkLmxLibPath() {
		String myPath = LmxAgent.class.getProtectionDomain().getCodeSource().getLocation().getPath();
		String myBaseDir = myPath.substring(0, myPath.length() - "lib/lmx-agent.jar".length());
		myBaseDir = myBaseDir.endsWith("/") ? myBaseDir.substring(0, myBaseDir.length() - 1) : myBaseDir;
		String lmxLibPath = myBaseDir + "license/lmx/linux_x64";
		lmxLibPath = System.getProperty("java.library.path");		
		System.setProperty("java.library.path", lmxLibPath);
        System.loadLibrary("liblmxjava.so");		
	}
	
	@SuppressWarnings("unused")
	private static void checkLmxLicensePath() {
		
	}
}
