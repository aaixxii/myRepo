package com.nec.lmx.agent;


import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.SocketChannel;

import com.nec.lmx.agent.event.EventListener;
import com.nec.lmx.agent.event.EventNotifier;

class LmxSocketSenderMock implements EventListener {
	private static final int BUFF_SIZE = 256;
	private ByteBuffer sendBuff;
	private SocketChannel socketChannel;
	private Object channelLocker;	
	
	private static final LmxSocketSenderMock INSTANCE = new LmxSocketSenderMock();
	public static LmxSocketSenderMock getInstance() {
		return INSTANCE;
	}	
	
	public LmxSocketSenderMock() {	
		this.channelLocker = new Object();
		sendBuff = ByteBuffer.allocate(BUFF_SIZE);
	}
	

	public void init(SocketChannel socketChannel) {
		this.socketChannel = socketChannel;			
		System.out.println("LmxSocketSender started!");
		EventNotifier.getInstance().addListener(this);
	}

	@Override
	public void onMessage(String msg) {
		sendLinceseInfo(msg);
	}

	@Override
	public void onStop()  {
		if (socketChannel != null || socketChannel.isOpen()) {
			try {
				socketChannel.close();
			} catch (IOException e) {				
				e.printStackTrace();
			}
		}
	}

	@Override
	public void onError(String error) {
		sendLinceseInfo(error);
	}

	private void sendLinceseInfo(String licenseInfo) {
		int sendSize = 0;
		try {
			byte[] bodys = licenseInfo.getBytes("UTF-8");
			// int sizeOfBody = bodys.length;
			sendBuff.clear();
			sendBuff.order(ByteOrder.BIG_ENDIAN);
			sendBuff.put(bodys);
			sendBuff.flip();
			synchronized (channelLocker) {
				while (sendBuff.hasRemaining()) {
					sendSize = socketChannel.write(sendBuff);
					System.out.println("Send data size{}: " + sendSize);
				}
			}
			sendBuff.clear();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
