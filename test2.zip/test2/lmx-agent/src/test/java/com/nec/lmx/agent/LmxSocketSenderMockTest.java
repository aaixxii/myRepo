package com.nec.lmx.agent;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.util.concurrent.ConcurrentHashMap;

import com.nec.lmx.agent.event.EventNotifier;

public class LmxSocketSenderMockTest {
	private final static ConcurrentHashMap<String, String> licenseMap = new ConcurrentHashMap<>();

	public static void main(String[] args) {
		try {
			InetSocketAddress hostAddress = new InetSocketAddress("localhost", 8888);
			SocketChannel socketChannel = SocketChannel.open(hostAddress);
			socketChannel.configureBlocking(false);
			socketChannel.socket().setKeepAlive(true);
			Selector selector = Selector.open();
			socketChannel.register(selector, SelectionKey.OP_WRITE);
			LmxSocketSenderMock.getInstance().init(socketChannel);
			System.out.println("Connected to server.");
			
			licenseMap.put("AFIS", "TYPE=FULL;COMPONENT=VM;MODALTY=FINGER,FACE,PALM,IRIS");
			licenseMap.put("EXPIRED", "false");
			String option = licenseMap.get("AFIS");
			String expired = licenseMap.get("EXPIRED");
			StringBuilder sb = new StringBuilder();
			sb.append(option);
			sb.append(";");
			sb.append("EXPIRED");
			sb.append("=");
			sb.append(expired);				
			EventNotifier.getInstance().fireOnMessage(sb.toString());
			
			try {
				Thread.sleep(10 * 60 * 1000);
			} catch (InterruptedException e) {				
				e.printStackTrace();
			}
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		

	}

}
