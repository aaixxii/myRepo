package com.nec.lmx.agent;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;




public class LmxAgentMockerTest {
	
	LmxAgentMock mocker = new LmxAgentMock();

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testMain() {
		
	}

	@Test
	public void testHandleParameter() {
		
	}

	@Test
	public void testPringUsage() {		
	}

	@Test
	public void testIsMatchPort() {
		String tmp = "4598";
		boolean result = mocker.isMatchPort(tmp);
		System.out.println(result);
		Assert.assertTrue(result);
		
		String tmp1 = "abcd";
		boolean result1 = mocker.isMatchPort(tmp1);
		System.out.println(result1);
		Assert.assertFalse(result1);		
	}
	
	@Test
	public void testIsMatchPort1() {
		String tmp = "";
		boolean result = mocker.isMatchPort(tmp);
		System.out.println(result);
		Assert.assertFalse(result);
	}
	
	@Test
	public void testIsMatchPort3() {
		String tmp = "0";
		boolean result = mocker.isMatchPort(tmp);
		System.out.println(result);
		Assert.assertFalse(result);
		
		String tmp1 = "1";
		boolean result1 = mocker.isMatchPort(tmp1);
		System.out.println(result1);
		Assert.assertTrue(result1);	
		
	}
	
	@Test
	public void testIsMatchIP() {
		String beTest = "192.168.22.100";
		boolean result = mocker.isMatchIp(beTest);
		System.out.println(result);
		Assert.assertTrue(result);		
	}

	@Test
	public void testIsMatchUrl() {
		String beTest = "6200@192.168.22.100";
		boolean result = LmxAgentMock.isCheckUrl(beTest);
		System.out.println(result);
		Assert.assertTrue(result);	
	}
	
	@Test
	public void TestCheckUrl() {
		String beTest = "6200@192.168.22.100";
		boolean result = LmxAgentMock.isCheckUrl(beTest);
		System.out.println(result);	
		Assert.assertTrue(result);
	}
	
	@Test
	public void TestCheckUrl1() {
		String beTest = "aa@192.168.22.100";
		boolean result = LmxAgentMock.isCheckUrl(beTest);
		System.out.println(result);	
		Assert.assertFalse(result);
	}
	
	@Test
	public void TestCheckUrl2() {
		String beTest = "6200@aa.168.22.100";
		boolean result = LmxAgentMock.isCheckUrl(beTest);
		System.out.println(result);	
		Assert.assertTrue(result);
	}

}
