package jp.co.nec.aim.mm.mq.util;

import static jp.co.nec.aim.mm.mq.cons.MqConst.*;
import static org.junit.Assert.*;

import java.io.IOException;
import java.net.UnknownHostException;
import java.sql.Timestamp;
import java.util.concurrent.TimeoutException;

import org.junit.Before;
import org.junit.Test;

import com.rabbitmq.client.Channel;

import jp.co.nec.aim.mm.mq.cons.MqConst;
import jp.co.nec.aim.mm.mq.db.DbHandler;
import jp.co.nec.aim.mm.mq.info.MqSetting;
import mockit.Invocation;
import mockit.Mock;
import mockit.MockUp;

public class SimpleRabbitMqTest {

    private MqSetting expMqSetting_001;

    @Before
    public void init() {
	expMqSetting_001 = new MqSetting(1, "", "DELETE_REQ", "10.197.23.100", 25672, "admin", "kata6f", "", 1000, null,
		null, 5000L, 5000);
    }

    @Test
    public void SimpleRabbitMqTest_001_init_connection() {

	new MockUp<SimpleRabbitMq>() {
	    @Mock
	    public void execute(String key)
		    throws UnknownHostException, IOException, TimeoutException, InterruptedException {
	    }
	};

	try {
	    SimpleRabbitMq mq = new SimpleRabbitMq(MqConst.DELETE_REQ_KEY);
	    assertMqSetting(expMqSetting_001, mq.mqSetting);
	} catch (IOException | TimeoutException | InterruptedException e) {
	    e.printStackTrace();
	    fail("An unexpected exception has occurred.");
	}
    }

    // TODO Not testable...
    // @Test
    public void SimpleRabbitMqTest_002_close() {
	try {
	    SimpleRabbitMq mq = new SimpleRabbitMq(MqConst.DELETE_REQ_KEY);
	    assertMqSetting(expMqSetting_001, mq.mqSetting);
	    assertNotNull(mq.connection);
	    for (Channel channel : mq.channelList)
		assertTrue(channel.isOpen());
	    assertTrue(mq.connection.isOpen());
	    mq.close();
	    for (Channel channel : mq.channelList)
		assertFalse(channel.isOpen());
	    assertFalse(mq.connection.isOpen());
	} catch (IOException | TimeoutException | InterruptedException e) {
	    e.printStackTrace();
	    fail("An unexpected exception has occurred.");
	}
    }

    @Test
    public void SimpleRabbitMqTest_003_update() {

	new MockUp<SimpleRabbitMq>() {
	    @Mock
	    public void execute(String key)
		    throws UnknownHostException, IOException, TimeoutException, InterruptedException {
	    }
	};

	try {
	    SimpleRabbitMq mq = new SimpleRabbitMq("1");
	    mq.update();
	} catch (IOException | TimeoutException | InterruptedException e) {
	    // TODO 自動生成された catch ブロック
	    e.printStackTrace();
	}
    }

    @Test
    public void SimpleRabbitMqTest_004_checkMaster() {

	new MockUp<SimpleRabbitMq>() {
	    @Mock
	    public void connection() throws IOException, TimeoutException {
	    }

	    @Mock
	    public boolean checkMaster(Invocation invocation) throws UnknownHostException {
		boolean result = invocation.proceed();
		return result;
	    }

	};

	new MockUp<DbHandler>() {
	    @Mock
	    public void setCurrentTimeStamp(Integer id, String nodeName, Timestamp timestamp) {
	    }

	};

	try {
	    SimpleRabbitMq mq = new SimpleRabbitMq(DELETE_REQ_KEY);
	    System.out.println(mq.checkMaster());
	} catch (Exception e) {
	    // TODO 自動生成された catch ブロック
	    e.printStackTrace();
	}
    }

    private void assertMqSetting(MqSetting expMqSetting, MqSetting actMqSetting) {
	assertNotNull(actMqSetting);
	assertEquals(expMqSetting.getId().intValue(), actMqSetting.getId().intValue());
	assertEquals(expMqSetting.getExchangeName(), actMqSetting.getExchangeName());
	assertEquals(expMqSetting.getQueueName(), actMqSetting.getQueueName());
	assertEquals(expMqSetting.getHost(), actMqSetting.getHost());
	assertEquals(expMqSetting.getPort().intValue(), actMqSetting.getPort().intValue());
	assertEquals(expMqSetting.getUser(), actMqSetting.getUser());
	assertEquals(expMqSetting.getPasswd(), actMqSetting.getPasswd());
	assertEquals(expMqSetting.getvHost(), actMqSetting.getvHost());
	assertEquals(expMqSetting.getThNum(), actMqSetting.getThNum());
	assertEquals(expMqSetting.getMasterNode(), actMqSetting.getMasterNode());
	assertEquals(expMqSetting.getTimestamp(), actMqSetting.getTimestamp());
	assertEquals(expMqSetting.getTimeoutTh(), actMqSetting.getTimeoutTh());
	assertEquals(expMqSetting.getPoolingTime(), actMqSetting.getPoolingTime());
    }

}
