package jp.co.nec.aim.mm.mq.subscriber;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeoutException;

import javax.ejb.EJB;

import org.apache.commons.lang3.RandomStringUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Delivery;

import jp.co.nec.aim.mm.acceptor.service.AimExtractService;
import jp.co.nec.aim.mm.mq.cons.MqConst;
import jp.co.nec.aim.mm.mq.publisher.SimplePublisher;
import jp.co.nec.aim.mm.mq.test.util.MqTestUtility;
import mockit.Mock;
import mockit.MockUp;

public class GetQualityReqSubScriberTest {

    @EJB
    private GetQualityReqSubScriber getQualityReqSubScriber;

    private String requestId;
    private String referenceId;
    private List<Boolean> assertFlg;

    /** ロガー */
    private static final Logger log = LoggerFactory.getLogger(GetQualityReqSubScriberTest.class);

    @Before
    public void init() throws IOException, TimeoutException, InterruptedException {
	getQualityReqSubScriber = new GetQualityReqSubScriber();
	requestId = RandomStringUtils.randomNumeric(36);
	referenceId = RandomStringUtils.randomNumeric(36);
	assertFlg = new ArrayList<Boolean>();
    }

    @After
    public void tearDown() throws IOException, TimeoutException {
	if (getQualityReqSubScriber != null)
	    getQualityReqSubScriber.close();
    }

    @Test
    public void GetQualityReqSubScriberTest_001() throws IOException, TimeoutException, InterruptedException {

	// Mock
	new MockUp<AimExtractService>() {
	    @Mock
	    public String extract(String extractRequest, boolean isFromServlet) throws IOException {
		log.info(new Date().getTime() + " " + extractRequest);
		try {
		    Thread.sleep(2000);
		} catch (InterruptedException e) {
		    // TODO 自動生成された catch ブロック
		    e.printStackTrace();
		}
		return MqTestUtility.getTestResultXml();
	    }
	};

	String msg = "TEST";
	SimplePublisher publisher = new SimplePublisher(MqConst.GETQUALITY_REQ_KEY);
	for (int i = 0; i < 100; i++)
	    publisher.publish(msg + String.valueOf(i) + new Date().getTime());
	publisher.close();
	SimpleSubScriber simpleSubScriber = new SimpleSubScriber(MqConst.GETQUALIY_RES_KEY) {
	    @Override
	    public void subScribeAction(Channel channel, String consumerTag, Delivery delivery) {
		try {
		    System.out.println("simpleSubScriber1");
		    assertFlg.add(MqTestUtility.getTestResultXml().equals(new String(delivery.getBody(), "UTF-8")));
		    channel.basicAck(delivery.getEnvelope().getDeliveryTag(), true);
		} catch (Exception e) {
		    e.printStackTrace();
		    assertFlg.add(false);
		    try {
			channel.basicNack(delivery.getEnvelope().getDeliveryTag(), true, true);
		    } catch (IOException e1) {
			// TODO 自動生成された catch ブロック
			e1.printStackTrace();
		    }
		}
	    }
	};

	SimpleSubScriber simpleSubScriber2 = new SimpleSubScriber(MqConst.GETQUALIY_RES_KEY) {
	    @Override
	    public void subScribeAction(Channel channel, String consumerTag, Delivery delivery) {
		try {
		    System.out.println("simpleSubScriber2");
		    assertFlg.add(MqTestUtility.getTestResultXml().equals(new String(delivery.getBody(), "UTF-8")));
		    channel.basicAck(delivery.getEnvelope().getDeliveryTag(), true);
		} catch (Exception e) {
		    e.printStackTrace();
		    assertFlg.add(false);
		    try {
			channel.basicNack(delivery.getEnvelope().getDeliveryTag(), true, true);
		    } catch (IOException e1) {
			// TODO 自動生成された catch ブロック
			e1.printStackTrace();
		    }
		}
	    }
	};

	simpleSubScriber.subScribe(false);
	simpleSubScriber2.subScribe(false);

	MqTestUtility.waitTest(assertFlg, 100);
	MqTestUtility.checkResult(assertFlg);
	simpleSubScriber.close();
    }

}
