package jp.co.nec.aim.mm.mq.publisher;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

import jp.co.nec.aim.mm.mq.cons.MqConst;

public class GetQualityResPublisher extends SimplePublisher {

    public GetQualityResPublisher() throws IOException, TimeoutException, InterruptedException {
	super(MqConst.GETQUALIY_RES_KEY);
    }

    public void getQualityRes(String msg) throws IOException, TimeoutException {
	publish(msg);
    }

}
