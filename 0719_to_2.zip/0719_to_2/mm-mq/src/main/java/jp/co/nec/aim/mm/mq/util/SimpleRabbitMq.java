package jp.co.nec.aim.mm.mq.util;

import static jp.co.nec.aim.mm.mq.cons.MqConst.*;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeoutException;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

import jp.co.nec.aim.mm.mq.db.DbHandler;
import jp.co.nec.aim.mm.mq.info.MqSetting;

public class SimpleRabbitMq {

    public Connection connection;
    public Channel channel;
    public List<Channel> channelList = new ArrayList<Channel>();
    public MqSetting mqSetting;
    public DbHandler dbHandler;

    private String[] checkArg = { DELETE_REQ_KEY, GETQUALITY_REQ_KEY, IDENTIFY_REQ_KEY, INSERT_REQ_KEY };

    public SimpleRabbitMq(String key) throws IOException, TimeoutException, InterruptedException {
	this.dbHandler = new DbHandler();
	this.mqSetting = dbHandler.getMqSetting(key);
	execute(key);
    }

    public void execute(String key) throws UnknownHostException, IOException, TimeoutException, InterruptedException {
	if (Arrays.asList(checkArg).contains(key)) {
	    // Subscriberは片系運用
	    // TODO Polling方法精査
	    while (true) {
		if (checkMaster()) {
		    update();
		    connection();
		} else {
		    close();
		}
		Thread.sleep(mqSetting.getPoolingTime());
	    }
	} else {
	    // Publisherは常にコネクション
	    connection();
	}
    }

    public void connection() throws IOException, TimeoutException {
	if (connection == null || !connection.isOpen()) {
	    ConnectionFactory factory = new ConnectionFactory();
	    factory.setHost(mqSetting.getHost());
	    factory.setPort(mqSetting.getPort());
	    factory.setUsername(mqSetting.getUser());
	    factory.setPassword(mqSetting.getPasswd());
	    if (!mqSetting.getvHost().isEmpty())
		factory.setVirtualHost(mqSetting.getvHost());
	    ExecutorService executor = Executors.newFixedThreadPool(mqSetting.getThNum());
	    connection = factory.newConnection(executor);
	    for (int i = 0; i < mqSetting.getThNum(); i++)
		channelList.add(connection.createChannel());
	}
    }

    public void close() throws IOException, TimeoutException {
	if (channelList != null) {
	    for (Channel channel : channelList)
		channel.close();
	}
	if (connection != null)
	    connection.close();
    }

    public void update() {
	try {
	    dbHandler.setCurrentTimeStamp(mqSetting.getId(), InetAddress.getLocalHost().getHostName(),
		    new Timestamp(new Date().getTime()));
	} catch (UnknownHostException e) {
	    // TODO 自動生成された catch ブロック
	    e.printStackTrace();
	}
    }

    public boolean checkMaster() throws UnknownHostException {
	return dbHandler.checkMaster(mqSetting.getId(), InetAddress.getLocalHost().getHostName(),
		mqSetting.getTimeoutTh());
    }

}
