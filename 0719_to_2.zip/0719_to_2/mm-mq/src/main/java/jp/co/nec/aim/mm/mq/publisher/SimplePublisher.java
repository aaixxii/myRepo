package jp.co.nec.aim.mm.mq.publisher;

import java.io.IOException;
import java.util.Random;
import java.util.concurrent.TimeoutException;

import com.rabbitmq.client.AMQP;

import jp.co.nec.aim.mm.mq.util.SimpleRabbitMq;

public class SimplePublisher extends SimpleRabbitMq {

    private Random random = new Random();

    public SimplePublisher(String key) throws IOException, TimeoutException, InterruptedException {
	super(key);
    }

    public void publish(String msg) throws IOException {
	channelList.get(random.nextInt(mqSetting.getThNum())).basicPublish(mqSetting.getExchangeName(),
		mqSetting.getQueueName(), new AMQP.BasicProperties.Builder().deliveryMode(2).build(), msg.getBytes());
    }

    public void publish(byte[] msg) throws IOException {
	channelList.get(random.nextInt(mqSetting.getThNum())).basicPublish(mqSetting.getExchangeName(),
		mqSetting.getQueueName(), new AMQP.BasicProperties.Builder().deliveryMode(2).build(), msg);
    }

}
