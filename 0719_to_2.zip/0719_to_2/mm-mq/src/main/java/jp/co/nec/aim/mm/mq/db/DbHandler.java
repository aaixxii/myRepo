package jp.co.nec.aim.mm.mq.db;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.aim.mm.constants.JNDIConstants;
import jp.co.nec.aim.mm.mq.info.MqSetting;
import jp.co.nec.aim.mm.util.JndiLookup;

public class DbHandler {

    private final static Logger log = LoggerFactory.getLogger(DbHandler.class);

    private DataSource dataSource;
    private JdbcTemplate jdbcTemplate;

    public DbHandler() {
	dataSource = JndiLookup.lookUp(JNDIConstants.DataSourceName, DataSource.class);
	jdbcTemplate = new JdbcTemplate(dataSource);
    }

    public MqSetting getMqSetting(String key) {
	return jdbcTemplate.queryForObject("select * from RQ_SETTIG where ID = ?", new Object[] { new Integer(key) },
		new RowMapper<MqSetting>() {
		    public MqSetting mapRow(ResultSet rs, int rowNum) throws SQLException {
			MqSetting mqSetting = new MqSetting();
			mqSetting.setId(rs.getInt("id"));
			mqSetting.setExchangeName(rs.getString("exchange_name"));
			mqSetting.setQueueName(rs.getString("queue_name"));
			mqSetting.setHost(rs.getString("host"));
			mqSetting.setPort(rs.getInt("port"));
			mqSetting.setUser(rs.getString("user"));
			mqSetting.setPasswd(rs.getString("passwd"));
			mqSetting.setvHost(rs.getString("v_host"));
			mqSetting.setThNum(rs.getInt("th_num"));
			mqSetting.setMasterNode(rs.getString("master_node"));
			mqSetting.setTimestamp(rs.getTimestamp("timestamp"));
			mqSetting.setTimeoutTh(rs.getLong("timeout_th"));
			mqSetting.setPoolingTime(rs.getInt("pooling_time"));
			return mqSetting;
		    }
		});
    }

    public boolean checkMaster(Integer id, String nodeName, Long timeoutTh) {
	Map<String, Boolean> resMap = jdbcTemplate.queryForObject(
		"select timestamp is null as timenull,master_node is null nodenull,"
			+ " timestamp > (NOW() - INTERVAL ? MICROSECOND) as time, master_node = ? as node  from rq_settig where id = ?;",
		new Object[] { timeoutTh * 1000, nodeName, id }, new RowMapper<Map<String, Boolean>>() {
		    public Map<String, Boolean> mapRow(ResultSet rs, int rowNum) throws SQLException {
			Map<String, Boolean> map = new HashMap<String, Boolean>();
			map.put("timenull", rs.getBoolean("timenull"));
			map.put("nodenull", rs.getBoolean("nodenull"));
			map.put("time", rs.getBoolean("time"));
			map.put("node", rs.getBoolean("node"));
			return map;
		    }
		});
	if (resMap.get("nodenull") || resMap.get("node")) {
	    // master_nodeがnullである場合もしくはマスターが自分であるときはtrueを返す。
	    return true;
	} else {
	    if (resMap.get("timenull") || !resMap.get("time")) {
		// マスターは自分ではないがtimestamphがnullもしくは閾値を超えている場合はtrueを返す。
		return true;
	    } else {
		// マスターは自分ではないかつ閾値を超えていない場合はfalseを返す。
		return false;
	    }
	}

    }

    @Transactional
    public void setCurrentTimeStamp(Integer id, String nodeName, Timestamp timestamp) {
	jdbcTemplate.update("update RQ_SETTIG set master_node = ?, timestamp  = ? where id = ?",
		new Object[] { nodeName, timestamp, id });
    }

}
