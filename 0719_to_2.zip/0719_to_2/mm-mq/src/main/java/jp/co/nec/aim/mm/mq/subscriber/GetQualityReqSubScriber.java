package jp.co.nec.aim.mm.mq.subscriber;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.concurrent.TimeoutException;

import javax.ejb.ConcurrencyManagement;
import javax.ejb.ConcurrencyManagementType;
import javax.ejb.EJB;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Delivery;

import jp.co.nec.aim.mm.acceptor.service.AimExtractService;
import jp.co.nec.aim.mm.exception.DataBaseException;
import jp.co.nec.aim.mm.exception.XmlException;
import jp.co.nec.aim.mm.mq.cons.MqConst;

@Singleton
@Startup
@TransactionManagement(TransactionManagementType.BEAN)
@ConcurrencyManagement(ConcurrencyManagementType.BEAN)
public class GetQualityReqSubScriber extends SimpleSubScriber {

    private static Logger log = LoggerFactory.getLogger(GetQualityReqSubScriber.class);

    @EJB
    private AimExtractService aimExtractService;

    public GetQualityReqSubScriber() throws IOException, TimeoutException, InterruptedException {
	super(MqConst.GETQUALITY_REQ_KEY);
	getQuality();
    }

    public void getQuality() throws IOException {
	subScribe(false);
    }

    @Override
    public void subScribeAction(Channel channel, String consumerTag, Delivery delivery) {
	try {
	    // Send GetQuality
	    aimExtractService.extract(new String(delivery.getBody(), "UTF-8"), false);
	    // return dequeue ack
	    channel.basicAck(delivery.getEnvelope().getDeliveryTag(), true);
	} catch (Exception e) {
	    // TODO ErrorHandring
	    try {
		if (e instanceof UnsupportedEncodingException) {
		    log.error("An unexpected exception has occurred when encode xml.", e);
		} else if (e instanceof XmlException || e instanceof DataBaseException) {
		    log.error("An unexpected exception has occurred when AIM internal.", e);
		} else {
		    log.error("An unexpected exception has occurred.", e);
		}
		// return dequeue ack()
		channel.basicNack(delivery.getEnvelope().getDeliveryTag(), false, true);
	    } catch (IOException e1) {
		// この場合は何もできないのでログ出力のみ
		log.error("An unexpected exception has occurred.", e);
	    }
	}
    }

}
