package jp.co.nec.aim.mm.mq.subscriber;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.concurrent.TimeoutException;

import javax.ejb.ConcurrencyManagement;
import javax.ejb.ConcurrencyManagementType;
import javax.ejb.EJB;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Delivery;

import jp.co.nec.aim.mm.acceptor.service.AimInquiryService;
import jp.co.nec.aim.mm.exception.AimIdnetifyException;
import jp.co.nec.aim.mm.mq.cons.MqConst;

@Singleton
@Startup
@TransactionManagement(TransactionManagementType.BEAN)
@ConcurrencyManagement(ConcurrencyManagementType.BEAN)
public class IdentifyReqSubScriber extends SimpleSubScriber {

    private static Logger log = LoggerFactory.getLogger(InsertReqSubScriber.class);

    @EJB
    private AimInquiryService aimInquiryService;

    public IdentifyReqSubScriber() throws IOException, TimeoutException, InterruptedException {
	super(MqConst.IDENTIFY_REQ_KEY);
	identifytReq();
    }

    public void identifytReq() throws IOException {
	subScribe(false);
    }

    @Override
    public void subScribeAction(Channel channel, String consumerTag, Delivery delivery) {
	try {
	    // Send InquiryJob
	    aimInquiryService.inquiry(new String(delivery.getBody(), "UTF-8"), false);
	    // return dequeue ack
	    channel.basicAck(delivery.getEnvelope().getDeliveryTag(), false);
	} catch (Exception e) {
	    // TODO ErrorHandring
	    try {
		if (e instanceof UnsupportedEncodingException) {
		    log.error("An unexpected exception has occurred when encode xml.", e);
		} else if (e instanceof AimIdnetifyException) {
		    log.error("An unexpected exception has occurred when AIM internal.", e);
		} else {
		    log.error("An unexpected exception has occurred.", e);
		}
		// return dequeue ack()
		channel.basicNack(delivery.getEnvelope().getDeliveryTag(), false, true);
	    } catch (IOException e1) {
		// この場合は何もできないのでログ出力のみ
		log.error("An unexpected exception has occurred.", e);
	    }
	}
    }

}
