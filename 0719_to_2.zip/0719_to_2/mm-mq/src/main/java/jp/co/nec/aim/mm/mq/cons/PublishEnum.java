package jp.co.nec.aim.mm.mq.cons;

public enum PublishEnum {

    Identify, Insert, Delete, GetQuarity;

}
