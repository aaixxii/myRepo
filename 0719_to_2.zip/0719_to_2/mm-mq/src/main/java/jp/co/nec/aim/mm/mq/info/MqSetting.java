package jp.co.nec.aim.mm.mq.info;

import java.sql.Timestamp;

public class MqSetting {

    private Integer id;
    private String exchangeName;
    private String queueName;
    private String host;
    private Integer port;
    private String user;
    private String passwd;
    private String vHost;
    private Integer thNum;
    private String masterNode;
    private Timestamp timestamp;
    private Long timeoutTh;
    private Integer poolingTime;

    public MqSetting() {
    };

    public MqSetting(Integer id, String exchangeName, String queueName, String host, Integer port, String user,
	    String passwd, String vHost, Integer thNum, String masterNode, Timestamp timestamp, Long timeoutTh,
	    Integer poolingTime) {
	this.id = id;
	this.exchangeName = exchangeName;
	this.queueName = queueName;
	this.host = host;
	this.port = port;
	this.user = user;
	this.passwd = passwd;
	this.vHost = vHost;
	this.thNum = thNum;
	this.masterNode = masterNode;
	this.timestamp = timestamp;
	this.timeoutTh = timeoutTh;
	this.poolingTime = poolingTime;
    }

    public Integer getId() {
	return id;
    }

    public void setId(Integer id) {
	this.id = id;
    }

    public String getExchangeName() {
	return exchangeName;
    }

    public void setExchangeName(String exchangeName) {
	this.exchangeName = exchangeName;
    }

    public String getQueueName() {
	return queueName;
    }

    public void setQueueName(String queueName) {
	this.queueName = queueName;
    }

    public String getHost() {
	return host;
    }

    public void setHost(String host) {
	this.host = host;
    }

    public Integer getPort() {
	return port;
    }

    public void setPort(Integer port) {
	this.port = port;
    }

    public String getUser() {
	return user;
    }

    public void setUser(String user) {
	this.user = user;
    }

    public String getPasswd() {
	return passwd;
    }

    public void setPasswd(String passwd) {
	this.passwd = passwd;
    }

    public String getvHost() {
	return vHost;
    }

    public void setvHost(String vHost) {
	this.vHost = vHost;
    }

    public Integer getThNum() {
	return thNum;
    }

    public void setThNum(Integer thNum) {
	this.thNum = thNum;
    }

    public String getMasterNode() {
	return masterNode;
    }

    public Timestamp getTimestamp() {
	return timestamp;
    }

    public Long getTimeoutTh() {
	return timeoutTh;
    }

    public Integer getPoolingTime() {
	return poolingTime;
    }

    public void setMasterNode(String masterNode) {
	this.masterNode = masterNode;
    }

    public void setTimestamp(Timestamp timestamp) {
	this.timestamp = timestamp;
    }

    public void setTimeoutTh(Long timeoutTh) {
	this.timeoutTh = timeoutTh;
    }

    public void setPoolingTime(Integer poolingTime) {
	this.poolingTime = poolingTime;
    }

}
