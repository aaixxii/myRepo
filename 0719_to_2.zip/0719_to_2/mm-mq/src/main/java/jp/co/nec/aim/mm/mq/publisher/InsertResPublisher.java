package jp.co.nec.aim.mm.mq.publisher;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

import jp.co.nec.aim.mm.mq.cons.MqConst;

public class InsertResPublisher extends SimplePublisher {

    public InsertResPublisher() throws IOException, TimeoutException, InterruptedException {
	super(MqConst.INSERT_RES_KEY);
    }

    public void insertRes(String msg) throws IOException, TimeoutException {
	publish(msg);
    }

}
