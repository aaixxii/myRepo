package jp.co.nec.aim.mm.mq.publisher;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

import jp.co.nec.aim.mm.mq.cons.MqConst;

public class IdentifyDiagAmrPublisher extends SimplePublisher {

    public IdentifyDiagAmrPublisher() throws IOException, TimeoutException, InterruptedException {
	super(MqConst.IDENTIFY_DIAG_AMR_KEY);
    }

    public void insertDiagAmr(byte[] msg) throws IOException, TimeoutException {
	publish(msg);
    }

}
