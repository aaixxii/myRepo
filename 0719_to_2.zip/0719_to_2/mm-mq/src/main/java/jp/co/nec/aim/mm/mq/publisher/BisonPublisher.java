package jp.co.nec.aim.mm.mq.publisher;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

import jp.co.nec.aim.mm.constants.UidRequestType;
import jp.co.nec.aim.mm.sessionbeans.pojo.UidAimAmqResponse;

public class BisonPublisher {

    private static BisonPublisher instance;
    private DeleteResPublisher deleteResPublisher;
    private GetQualityResPublisher getQualityResPublisher;
    private IdentifyDiagAmrPublisher identifyDiagAmrPublisher;
    private IdentifyResPublisher identifyResPublisher;
    private InsertDiagQualityPublisher insertDiagQualityPublisher;
    private InsertResPublisher insertResPublisher;

    private BisonPublisher() throws IOException, TimeoutException, InterruptedException {
	this.deleteResPublisher = new DeleteResPublisher();
	this.getQualityResPublisher = new GetQualityResPublisher();
	this.identifyDiagAmrPublisher = new IdentifyDiagAmrPublisher();
	this.identifyResPublisher = new IdentifyResPublisher();
	this.insertDiagQualityPublisher = new InsertDiagQualityPublisher();
	this.insertResPublisher = new InsertResPublisher();
    }

    public static BisonPublisher getInstance() {
	if (instance == null) {
	    try {
		instance = new BisonPublisher();
	    } catch (IOException | TimeoutException | InterruptedException e) {
		e.printStackTrace();
	    }
	}
	return instance;
    }

    public void publish(UidAimAmqResponse res) {
	try {
	    if (res.getRequestType().equals(UidRequestType.Identify.name())) {
		// publish result xml.
		identifyResPublisher.identifyRes(res.getXmlResult());
		// publish result PBDiagnostics.
		identifyDiagAmrPublisher.insertDiagAmr(res.getDiagnostics());
	    } else if (res.getRequestType().equals(UidRequestType.Insert.name())) {
		// publish result xml.
		insertResPublisher.insertRes(res.getXmlResult());
		// publish result PBDiagnostics.
		insertDiagQualityPublisher.insertDiagQuality(res.getDiagnostics());
	    } else if (res.getRequestType().equals(UidRequestType.Delete.name())) {
		// publish result.
		deleteResPublisher.deleteRes(res.getXmlResult());
	    } else if (res.getRequestType().equals(UidRequestType.Quality.name())) {
		// publish result.
		getQualityResPublisher.getQualityRes(res.getXmlResult());
	    }
	} catch (IOException | TimeoutException e) {
	    // TODO 自動生成された catch ブロック
	    e.printStackTrace();
	}
    }

}
