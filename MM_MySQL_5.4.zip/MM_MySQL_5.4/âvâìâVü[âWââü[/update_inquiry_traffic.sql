CREATE DEFINER=`aimuser`@`%` PROCEDURE `update_inquiry_traffic`(
IN  p_top_job_id int
)
BEGIN 
    declare l_job_exec_count int;
	declare l_job_limit_count int;
	declare  l_family_id  int;
     declare  t_err int DEFAULT 0;
     DECLARE EXIT HANDLER FOR  SQLEXCEPTION set t_err =1;   
	 DECLARE CONTINUE HANDLER FOR SQLWARNING begin end;     
	select family_id into l_family_id from job_queue where job_id = p_top_job_id;
     UPDATE inquiry_traffic it
     SET it.job_exec_count = it.job_exec_count + 1
     WHERE it.family_id = l_family_id;
     SELECT job_exec_count,job_limit_count
     INTO l_job_exec_count,l_job_limit_count
     FROM inquiry_traffic it
     WHERE it.family_id  = l_family_id;
     IF(l_job_exec_count < 0 OR l_job_exec_count > l_job_limit_count) THEN
       UPDATE INQUIRY_TRAFFIC it
       SET it.JOB_EXEC_COUNT =
         (SELECT COUNT(JOB_ID)
         FROM JOB_QUEUE jq
         WHERE jq.FAMILY_ID = it.FAMILY_ID
         AND jq.JOB_STATE  = c_job_state_working
         )
       WHERE it.FAMILY_ID = l_family_id;
     END IF;
    commit;  
END