CREATE DEFINER=`aimuser`@`%` PROCEDURE `get_job_info_for_create_plans`(
 in limited_job_ids varchar(2048)
)
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN
     DECLARE t_error INTEGER DEFAULT 0;  
	 declare v_idx int default 999 ;
	 declare v_tmp_str varchar(20);
	 declare v_id int;     
	 declare cur cursor for select id from l_container_ids;
     DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1;  
	 DROP TEMPORARY TABLE IF EXISTS limited_ids_tab;
	 create temporary table limited_ids_tab(id int) engine=memory;
     while v_idx > 0 do
         SET v_idx = INSTR(limited_job_ids,',');
         SET v_tmp_str = substr(limited_job_ids,0,t_idx-1);    
         insert into limited_ids_tab (id)  values( CAST(v_tmp_str AS UNSIGNED));
         set limited_job_ids=substr(limited_job_ids,v_idx +1 ,LENGTH(limited_job_ids)); 
      end while;
      
	SELECT jq.job_id, 
             jq.family_id,
             fq.function_id, 
             ssj.container_id,
             ssj.container_job_id
      FROM   job_queue jq, 
             fusion_jobs fq, 
             container_jobs ssj           
      WHERE  jq.job_id = fq.job_id 
	  AND fq.fusion_job_id = ssj.fusion_job_id 
	  AND jq.job_state = 0              
	  AND ssj.container_id != (select container_id from segment_defragmentation) 
	  AND jq.job_id IN (SELECT id from limited_job_ids)                              
	  ORDER  BY priority, failure_count DESC,  job_id ;
	  if t_error=1 then
       -- select empty to return;
       select null from dual;
	   end if;
END