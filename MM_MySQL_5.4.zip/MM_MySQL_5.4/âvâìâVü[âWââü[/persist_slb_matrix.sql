CREATE DEFINER=`aimuser`@`%` PROCEDURE `persist_slb_matrix`(
 in  p_slb_matrix   varchar(2048),
 in  p_container_id   int,
 in   p_component_type  int
)
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN
   -- slb_matrix data="muId1:1000,muId2:1001,muId2:1003";
    DECLARE t_error INTEGER DEFAULT 0;  
    declare t_len int;
    declare t_idx int;
     declare t_idx_2 int;
    declare t_tmp varchar(20);
     declare t_id int;
      declare t_seg int;
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1;
	 DROP TEMPORARY TABLE IF EXISTS list_tmp;
     create temporary table list_tmp(id VARCHAR(32)) engine=memory;
    
SELECT LENGTH(p_slb_matrix) INTO t_len;
    while t_len > 0 DO
       SET t_idx = INSTR(p_slb_matrix,',');
       SET t_tmp = substr(p_slb_matrix,0,t_idx-1);
       set t_idx_2 = INSTR(t_tmp,':');       
       set t_tmp = substr(t_tmp,0,t_t_idx_2-1);     
       set t_id = CAST(substr(t_tmp,0,t_t_idx_2-1) AS UNSIGNED);
       set t_seg = CAST(substr(t_tmp,t_t_idx_2+1,LENGTH(t_tmp)) AS UNSIGNED);
        IF (p_component_type = 3) THEN
			DELETE FROM mu_segments WHERE segment_id IN (SELECT segment_id FROM SEGMENTS WHERE container_id = p_container_id);
			-- INSERT INTO mu_segments(mu_id, segment_id, rank) VALUES(t_id, t_seg, 0);
		ELSEIF (p_component_type = 1) THEN
            DELETE FROM dm_segments WHERE segment_id IN (SELECT segment_id FROM SEGMENTS WHERE container_id = p_container_id);
            -- INSERT INTO dm_segments(dm_id, segment_id, rank) VALUES(l_slb_matrix.unitId, l_slb_matrix.segId, 0);
		 END IF;
        set p_slb_matrix = substr(p_slb_matrix,t_idx+1,LENGTH(p_slb_matrix));
        set t_len = LENGTH(p_slb_matrix);
    end while;
    IF t_error = 1 THEN
      ROLLBACK;
    ELSE
      COMMIT;
   END IF;  

END