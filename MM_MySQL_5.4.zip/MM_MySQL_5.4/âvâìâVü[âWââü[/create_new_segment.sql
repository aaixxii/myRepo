CREATE DEFINER=`aimuser`@`%` PROCEDURE `create_new_segment`(
  p_container_id int,
  p_biometrics_id long,
  p_biometric_data_len long,
  out o_reated_segment_id long
)
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN
 declare  del_conatiner_id int;
 declare  l_new_segment_id long;
 DECLARE t_error INTEGER DEFAULT 0; 
DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1;  
		INSERT INTO segments
             (               
                bio_id_start,
                bio_id_end,
                binary_length_compacted,
                binary_length_uncompacted,
                record_count,
                version,
                container_id,
                revision
              )
              VALUES
               (                 
                  p_biometrics_id,
                  p_biometrics_id,
                  p_biometric_data_len + 54 + 26,
                  p_biometric_data_len + 54 + 26,
                  1,
                  0,
                  p_container_id,
                  0
                );
     select  segment_id INTO l_new_segment_id; 
      set o_reated_segment_id = l_new_segment_id;
END