CREATE DEFINER=`aimuser`@`%` PROCEDURE `complete_inquiryjob`(
	in p_job_id int,
	in p_container_job_id int,
	in p_sequence  INTEGER,
    in p_result BLOB,
    out l_remain_jobs INTEGER
)
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN
    declare l_count int default 0;
	declare l_failure_count int;   
 	declare  l_remain_jobs   int;
  	declare  v_errcode  int;
    DECLARE t_error INTEGER DEFAULT 0; 
    declare cur cursor for select id from l_container_ids;
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1;
	SELECT failure_count
              INTO l_failure_count
              FROM job_queue
              WHERE job_id     = p_job_id
              AND job_state    = 1
              AND 0 < remain_jobs FOR UPDATE;              
              IF p_sequence  = l_failure_count THEN                  
                  UPDATE CONTAINER_JOBS
                  SET JOB_STATE = 2,
                      RESULT_TS  = get_epoch_time_num(),
                      CONTAINER_JOB_RESULT = p_result
                  WHERE CONTAINER_JOB_ID = p_container_job_id
				  AND job_state= 'WORKING';
                SELECT ROW_COUNT() into l_count;
                  IF 0 < l_count THEN
                      UPDATE job_queue
                      SET remain_jobs = remain_jobs - 1
                      WHERE job_id    = p_job_id;
                      select remain_jobs  INTO l_remain_jobs from  job_queue;                    
                  ELSE
                      ROLLBACK;
                     set l_remain_jobs=-3;
                  END IF;
              ELSE
                  ROLLBACK;
                  set l_remain_jobs= -2;
              END IF;
             if t_error=1 then
                rollback;
                 set l_remain_jobs = -1;
			 else 
                commit;               
              end if;
END