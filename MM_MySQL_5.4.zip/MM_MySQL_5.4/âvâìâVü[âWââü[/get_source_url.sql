CREATE DEFINER=`aimuser`@`%` FUNCTION `get_source_url`(
 p_segment_id int
) RETURNS varchar(1024) CHARSET utf8mb4
BEGIN
 declare l_url varchar(1024);
  DECLARE t_error INTEGER DEFAULT 0; 
   DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1;
SELECT DISTINCT
    dm.contact_url
INTO l_url FROM
    data_managers dm,
    dm_seg_reports dsr,
    dm_segments ds
WHERE
    dm.dm_id = dsr.dm_id
        AND dm.dm_id = ds.dm_id
        AND dsr.segment_id = p_segment_id
        AND ds.segment_id = p_segment_id
        AND dm.state = 1
        AND dsr.status IN (0 , 1);
if t_error =1 then
  return l_url;
else 
  RETURN 1;
end if;
END