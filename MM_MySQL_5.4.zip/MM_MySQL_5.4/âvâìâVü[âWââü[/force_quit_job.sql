CREATE DEFINER=`aimuser`@`%` PROCEDURE `force_quit_job`(
 in  p_code VARCHAR(20),
 in  p_reason VARCHAR(1024),
 in  p_failure_time VARCHAR(20),
 in p_container_job_id int,
 in p_segment_id long,
 in p_result mediumblob,
 out o_job_id long
 )
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN
   declare  l_job_id long;
   declare l_mr_id  int;
   declare v_errcode int(10); 
   declare l_container_job_id  int;
    DECLARE t_error INTEGER DEFAULT 0;  
      declare v_idx int default 999 ;
      declare v_tmp_str varchar(20);
      declare v_id int;     
	declare cur cursor for select id from l_container_ids;
     DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1;  
	DROP TEMPORARY TABLE IF EXISTS l_container_job_ids;
	create temporary table l_container_job_ids(id int) engine=memory; 
	SELECT jq.job_id , cj.mr_id
	INTO l_job_id, l_mr_id
	FROM job_queue jq,
		 fusion_jobs fj,
		 container_jobs cj
	WHERE jq.job_id = fj.job_id
	AND fj.fusion_job_id  = cj.fusion_job_id
	AND cj.container_job_id= p_container_job_id
	AND 0 < jq.remain_jobs
	AND jq.job_state < 2
    FOR UPDATE;
	UPDATE container_jobs
	SET job_state =2,
		CONTAINER_JOB_RESULT = p_result,
		result_ts = get_epoch_time_num()
	WHERE container_job_id = p_container_job_id
	AND job_state  < 2;   
   call insert_failure_Reason(l_mr_id,  p_code,  p_reason, p_failure_time, p_container_job_id, p_segment_id);
	insert INTO l_container_job_ids(id) values(
		(SELECT cj.container_job_id 
	    FROM job_queue jq,fusion_jobs fj, container_jobs cj
	    WHERE jq.job_id = l_job_id		
	    AND jq.job_id = fj.job_id 
	    AND fj.fusion_job_id = cj.fusion_job_id
	    AND cj.container_job_id <> p_container_job_id)
    );
        IF l_container_job_ids.COUNT() > 0 THEN
        open cur;
		lable_loop: loop
          FETCH cur INTO v_id;
			set l_container_job_id := v_id;
            UPDATE container_jobs SET result_ts = get_epoch_time_num(), job_state = 2
            WHERE container_job_id = l_container_job_id;
            -- insert into container failure reason with other container job ids that belong to the same top level job
           call insert_failure_Reason(NULL, p_code , 'Container job failed due to the related Container job:' || p_container_job_id || ' has some error.', p_failure_time, l_container_job_id, NULL); 
        end loop;
        close cur; 
        end if;
		UPDATE job_queue
		SET remain_jobs = 0,
		failure_count = failure_count + 1
        WHERE job_id    = l_job_id;
      if t_error=1 then
        rollback;
	  else 
	   commit;
	  end if;
END