CREATE DEFINER=`aimuser`@`%` PROCEDURE `update_contact_time`(
 IN   p_unit_id int,
 IN	 p_unit_type int  
)
BEGIN
DECLARE t_error INTEGER DEFAULT 0;  
DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1;    
              IF p_unit_type = 3 THEN
                UPDATE  mu_contacts
                SET     contact_ts = get_epoch_time_num()
                WHERE mu_id = p_unit_id;
              ELSEIF p_unit_type = 1 THEN
                UPDATE dm_contacts
                  SET contact_ts = get_epoch_time_num()
                  WHERE dm_id = p_unit_id;
              ELSEIF p_unit_type = 2 THEN
                  UPDATE mr_contacts
                  SET contact_ts = get_epoch_time_num()
                  WHERE mr_id = p_unit_id;
              END IF;
	IF t_error = 1 THEN 
	  ROLLBACK;           
	ELSE          
	  COMMIT;  
    END IF; 
END