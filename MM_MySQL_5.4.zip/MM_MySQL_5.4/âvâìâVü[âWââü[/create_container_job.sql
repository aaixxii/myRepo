CREATE DEFINER=`aimuser`@`%` PROCEDURE `create_container_job`(
   IN   p_job_id int,
   IN   p_search_request_index int,
   IN   p_function_id int,
   IN   p_inquiry_job_data BLOB,
   IN   p_container_list varchar(1024),
   OUT  p_empty_job int,
   OUT  p_remain_job int,
   OUT  p_fusion_job_id int
)
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN
   declare l_fusion_job_id int;
   declare  l_count int;   
   DECLARE t_error INTEGER DEFAULT 0;  
      declare v_idx int default 999 ;
      declare v_tmp_str varchar(20);
      declare v_id int;     
	declare cur cursor for select id from l_container_ids;
     DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1;  
	DROP TEMPORARY TABLE IF EXISTS container_ids;
	create temporary table container_ids(id int  NOT NULL PRIMARY KEY UNIQUE) engine=memory; 
    	DROP TEMPORARY TABLE IF EXISTS l_container_ids;
	create temporary table l_container_ids(id int  NOT NULL PRIMARY KEY UNIQUE) engine=memory; 
	while v_idx > 0 do
         SET v_idx = INSTR(p_container_list,',');
         SET v_tmp_str = substr(p_container_list,0,t_idx-1);    
         insert into container_ids (id)  values( CAST(v_tmp_str AS UNSIGNED));
         set p_container_list=substr(p_container_list,v_idx +1 ,LENGTH(p_container_list)); 
      end while;
      call check_container_formats(p_function_id, p_container_list);
        -- first insert: create single row in fusion_jobs table.
     set l_fusion_job_id = insert_fusion_job_row( p_job_id,
                                                  p_search_request_index,
                                                  p_function_id,
                                                  p_inquiry_job_data);         
	insert into _container_ids(id) values
	((select c.container_id from  containers c WHERE                
           c.container_id IN (SELECT id from container_ids)
            AND EXISTS (SELECT seg.segment_id FROM segments seg WHERE seg.container_id = c.container_id))
	);  
	set p_empty_job := 1; -- 1 means FUSION_JOBS of l_fusion_job_id has no CONTAINER_JOBS records.
     IF 0 < l_container_ids.Count THEN
       open cur;
        lable_loop: loop
           FETCH cur INTO v_id;
           INSERT INTO container_jobs (fusion_job_id, container_id)
            VALUES(l_fusion_job_id, v_id);
		end loop;
        close cur;
       set p_empty_job := 0; -- 0 means FUSION_JOBS of l_fusion_job_id has some CONTAINER_JOBS records.      
     end if;
     set p_remain_job := l_container_ids.Count;
     if t_error=1 then
        rollback;
	 else 
	   commit;
	 end if; 
     -- select l_fusion_job_id;
     -- select  p_empty_job;
	 -- select p_remain_job;
END