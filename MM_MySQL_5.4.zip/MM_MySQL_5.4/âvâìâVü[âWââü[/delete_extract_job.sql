CREATE DEFINER=`aimuser`@`%` PROCEDURE `delete_extract_job`(
in p_extract_job_id int
)
BEGIN
DECLARE t_error INTEGER DEFAULT 0;  
DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1;
DELETE FROM fe_job_queue 
WHERE
    job_id = p_extract_job_id;
if t_error=1 then
        rollback;
else 
	   commit;
end if; 
END