CREATE DEFINER=`aimuser`@`%` PROCEDURE `get_limited_jobs_by_familiy`()
    READS SQL DATA
    SQL SECURITY INVOKER
BEGIN 
   declare l_family_id int;
   declare l_job_limit_count int;
   DECLARE t_error INTEGER DEFAULT 0;  
	declare v_idx int default 999 ;
      declare v_tmp_str varchar(20);
      declare v_id int;     
	declare cur cursor for select id from l_container_ids;
    declare limit_job_cur cursor for 
      SELECT family_id, 
             job_limit_count - job_exec_count AS limit_count 
	  FROM   inquiry_traffic
	  WHERE (job_limit_count - job_exec_count) > 0;
    
     DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1;  
	DROP TEMPORARY TABLE IF EXISTS l_job_id_tab;
	create temporary table l_job_id_tab(id int) engine=memory; 
    open cur;
	lable_loop: loop
	  FETCH cur INTO l_family_id, l_job_limit_count;
      insert into l_job_id_tab(id) values (
		(SELECT job_id
        FROM   job_queue 
        WHERE  family_id =l_family_id  and job_state = 0
        ORDER BY priority, failure_count DESC, job_id
        limit l_job_limit_count)      
      );  
	end loop;    
    close cur;
    select * from l_job_id_tab; 
END