CREATE DEFINER=`aimuser`@`%` PROCEDURE `check_container`(
   IN p_container_id int   
)
BEGIN
 declare l_count int;
 DECLARE fetch_state INT default 0;
 DECLARE EXIT HANDLER FOR SQLEXCEPTION set fetch_state=1;       
	SELECT COUNT(c.container_id) into l_count FROM containers c where c.container_id = p_container_id;
	IF l_count <= 0 THEN 
		set fetch_state=1;
	END IF;
   select @my_error;
END