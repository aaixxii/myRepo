CREATE DEFINER=`aimuser`@`%` PROCEDURE `find_unaggregated_jobs`(
)
    READS SQL DATA
    SQL SECURITY INVOKER
BEGIN
declare l_epoch_time long;
declare l_detect_time long;
 DECLARE t_error INTEGER DEFAULT 0;  
 DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1; 
  set l_epoch_time := get_epoch_time_num();
	SELECT to_number(property_value) INTO l_detect_time FROM system_config 
	WHERE property_name ='JOB_AGGREGATION.AUTO_DETECT_TIME';  
	SELECT  jq.job_id FROM job_queue jq 
        WHERE jq.job_state='WORKING'
        AND jq.remain_jobs=0 
        -- check if TopLevelJob has a record in container_jobs
        AND EXISTS (
          SELECT  cj.container_job_id FROM fusion_jobs fj, container_jobs cj
            WHERE fj.job_id = jq.job_id
            AND fj.fusion_job_id = cj.fusion_job_id 
        )
        -- check if all container_jobs record is DONE.
        AND NOT EXISTS
        (
          SELECT cj.container_job_id FROM fusion_jobs fj, container_jobs cj
            WHERE fj.job_id = jq.job_id
              AND fj.fusion_job_id = cj.fusion_job_id 
              AND cj.job_state != 2
        )
        -- select TopLevelJob whose CONTAINER_JOBS are DONE but not aggregated for l_detect_time/1000 second 
        AND EXISTS
        (
          SELECT MAX(cj.result_ts) FROM fusion_jobs fj, container_jobs cj
            WHERE jq.job_id = fj.job_id
              AND fj.fusion_job_id = cj.fusion_job_id 
            GROUP BY jq.job_id 
              HAVING MAX(cj.result_ts) < (select l_epoch_time - l_detect_time FROM dual) 
        )
        ORDER BY jq.job_id;
END