CREATE DEFINER=`aimuser`@`%` PROCEDURE `update_inquiry_load`(
   in  p_mu_id int,
   in p_inquiry_load int
)
BEGIN
 DECLARE  l_count  int;
 DECLARE t_error INTEGER DEFAULT 0;  
 DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1;  
       SELECT COUNT(pressure) into l_count  FROM mu_inquiry_load WHERE mu_id = p_mu_id;
         IF(l_count = 0)
         THEN
           INSERT INTO mu_inquiry_load(mu_id, pressure, report_ts) VALUES(p_mu_id, p_inquiry_load, get_epoch_time_num());
         ELSE
           UPDATE mu_inquiry_load SET pressure = p_inquiry_load, report_ts = get_epoch_time_num() where mu_id = p_mu_id;
         END IF; 
         IF t_error = 1 THEN    
            ROLLBACK;    
        ELSE    
            COMMIT;    
        END IF;    
   select t_error; 
END