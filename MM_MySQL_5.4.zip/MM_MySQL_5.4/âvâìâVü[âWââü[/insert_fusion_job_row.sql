CREATE DEFINER=`aimuser`@`%` PROCEDURE `insert_fusion_job_row`(
    in  p_job_id int,
	in  p_search_request_index int,
	in  p_function_id int,
    in  p_inquiry_job_data BLOB     
)
BEGIN
declare  l_fusion_job_id int;      
        INSERT INTO fusion_jobs
        (  
            function_id,
            job_id,
            inquiry_job_data,
            search_request_index
          )
          VALUES
          (           
            p_function_id,
            p_job_id,
            p_inquiry_job_data,
            p_search_request_index
          );          
         SELECT LAST_INSERT_ID() into l_fusion_job_id;

END