CREATE DEFINER=`aimuser`@`%` PROCEDURE `get_mu_pressure_ability`(IN p_mu_ids VARCHAR(1024))
    READS SQL DATA
    SQL SECURITY INVOKER
begin
  --  p_mu_ids = "1000,1001,1002,1003";
  DECLARE t_error INTEGER DEFAULT 0;
  DECLARE v_idx INT DEFAULT 999;
  DECLARE v_tmp_str VARCHAR(20);
  DECLARE v_id INT;
  DECLARE CONTINUE handler
  FOR SQLEXCEPTION
    SET t_error=1;
  DROP temporary TABLE IF EXISTS mu_ids;
  CREATE temporary TABLE mu_ids
    (
       id INT NOT NULL PRIMARY KEY UNIQUE
    )
  engine=memory;

  WHILE v_idx > 0 do
    SET v_idx = instr(p_mu_ids, ',');
    SET v_tmp_str = substr(p_mu_ids, 0, v_idx-1);
    INSERT INTO mu_ids
                (id)
    VALUES     ( Cast(v_tmp_str AS UNSIGNED));
    SET p_mu_ids=substr(p_mu_ids, v_idx +1, length(p_mu_ids));
  end WHILE;

  SELECT ml.mu_id,
         ml.pressure,
         mu.number_of_matchers * mu.reported_performance_factor AS ability,
         ml.report_ts
  FROM   mu_inquiry_load ml,
         match_units mu
  WHERE  ml.mu_id = mu.mu_id
         AND mu.state = 'WORKING'
         AND mu.mu_id IN (SELECT id
                          FROM   mu_ids)
  ORDER  BY ml.mu_id;
end