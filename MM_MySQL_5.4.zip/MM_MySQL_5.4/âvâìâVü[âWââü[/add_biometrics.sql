CREATE DEFINER=`aimuser`@`%` PROCEDURE `add_biometrics`(
	IN p_external_id  varchar(64),
	IN p_event_id  int,
    IN  p_container_id  int,
	IN p_biometric_data   MEDIUMBLOB,
    OUT p_seg_id  int,
    OUT p_seg_version int,
	OUT p_biometric_id int
)
BEGIN
    declare l_seg_created int;
	declare l_biometrics_id int;
    declare l_data_len int;


END