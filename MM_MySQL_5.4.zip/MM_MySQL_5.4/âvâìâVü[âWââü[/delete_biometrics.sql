CREATE DEFINER=`aimuser`@`%` PROCEDURE `delete_biometrics`(
    in   p_external_id     VARCHAR(20),
    in   p_event_id    int,
    in  p_container_ids  varchar(1024),
    out r_deleted_record_count int
)
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN
  declare l_person_id  long;
  declare  l_new_binary_len_comp long;
  declare  l_new_rec_count  int;
  declare  l_new_version  long;
  declare  l_new_revision  long;
  declare tmp_biometrics_id long;
  declare tmp_container_id int;
  declare tmp_biometric_data_len long;  
  declare  l_deleted_record_count int default 0;
  declare  l_count int default 0;
  declare   tp_segment_id long;
  declare  tp_record_count long;
  declare  tp_binary_length_compacted long;
  declare tp_version long;
  declare  tp_revision long;
  declare  del_count int;
  declare not_found int default 0;
    DECLARE t_error INTEGER DEFAULT 0;  
      declare v_idx int default 999 ;
      declare v_tmp_str varchar(20);
      declare v_id int;     
	declare cur cursor for select id from tmp_person_biometrics;
    declare C1 cursor for select * from seg_container FOR UPDATE;		
	DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1;  
	DECLARE  CONTINUE HANDLER FOR NOT FOUND SET not_found = 1;
	DROP TEMPORARY TABLE IF EXISTS tmp_person_biometrics;
	create temporary table tmp_person_biometrics(biometrics_id long, container_id int,biometric_data_len long);
    DROP TEMPORARY TABLE IF EXISTS tmp_container_ids;
	create temporary table tmp_container_ids(id int) engine=memory;
    DROP TEMPORARY TABLE IF EXISTS seg_container;
	create temporary table seg_container(segment_id long,record_count long, binary_length_compacted long,version long, revision long) engine=memory;
	while v_idx > 0 do
	   SET v_idx = INSTR(p_container_ids,',');
	  SET v_tmp_str = substr(p_container_ids,0,t_idx-1);    
         insert into tmp_container_ids (id)  values( CAST(v_tmp_str AS UNSIGNED));
         set p_container_ids=substr(p_container_ids,v_idx +1 ,LENGTH(p_container_ids)); 
	end while;
	IF (p_event_id IS NOT NULL) AND (p_container_ids IS NOT NULL) THEN
       insert into tmp_person_biometrics values (
			(SELECT biometrics_id, container_id,biometric_data_len
			 FROM  person_biometrics
			 WHERE external_id      = p_external_id
			 AND   event_id         = p_event_id
			 AND   container_id IN (SELECT id from tmp_container_ids)
            ORDER BY container_id, biometrics_id)      
       );     
    ELSEIF (p_event_id IS NOT NULL) AND (p_container_ids IS NULL) THEN
       insert into tmp_person_biometrics values (
			(SELECT biometrics_id, container_id,biometric_data_len
			 FROM person_biometrics
			 WHERE external_id = p_external_id
			AND   event_id    = p_event_id  
            ORDER BY container_id, biometrics_id)  
        );
	ELSEIF (p_event_id IS NULL) AND (p_container_ids IS NOT NULL) THEN
       insert into tmp_person_biometrics values (
				(SELECT biometrics_id, container_id,biometric_data_len
                FROM person_biometrics
                WHERE external_id = p_external_id 
            ORDER BY container_id, biometrics_id)      
        );
	END IF;
    
    open cur;    
	lable_loop: loop
	 FETCH cur INTO tmp_biometrics_id,tmp_container_id,tmp_biometric_data_len;
     if not_found !=1 then 
       DELETE FROM person_biometrics where BIOMETRICS_ID =tmp_biometrics_id;
        SELECT ROW_COUNT() into del_count;
        if del_count = 1 then
          set l_deleted_record_count := l_deleted_record_count + 1;
           insert into seg_container values (
               (SELECT segment_id,
						record_count,
						binary_length_compacted,
						version,
						revision
                    FROM  segments s,containers c                           
                    WHERE  s.container_id = c.container_id
                    AND   (tmp_container_id BETWEEN s.bio_id_start AND s.bio_id_end)
                    AND   (c.container_id = tmp_container_id.container_id))           
           );
           open C1;
            loop
               FETCH cur INTO tp_segment_id, tp_record_count,tp_binary_length_compacted,tp_version,tp_revision;
               set  l_new_rec_count = c1.record_count - 1;
               set  l_new_binary_len_comp := tp_binary_length_compacted - tmp_biometric_data_len  - 54;                       
               set  l_new_version =tp_version + 1;
               set  l_new_revision =tp_revision + 1;
				UPDATE segments
				SET   record_count = l_new_rec_count,
					   binary_length_compacted = l_new_binary_len_comp,
                        version = l_new_version,
                        revision = l_new_revision
				WHERE segment_id = c1.segment_id
				AND   revision  = tp_version;
				INSERT INTO segment_change_log
                    (                       
                        segment_id,
                        segment_version,
                        change_type,
                        biometrics_id
                    )
                    VALUES
                    (                        
                        tp_segment_id,
                        l_new_version,
                        1,
                        tmp_biometrics_id
                    );
              set l_count := l_count + 1;
           end loop;
           close C1;        
         end if;
     end if;
    end loop;
    close cur;
    set r_deleted_record_count = l_deleted_record_count;
 if t_error=1 then
	rollback;
    set r_deleted_record_count = -1;
  else 
	commit;
end if; 
END