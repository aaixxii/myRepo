CREATE DEFINER=`aimuser`@`%` PROCEDURE `retry_job`(
 in  p_job_id long,
 out o_job_exec_count int
)
BEGIN
   declare l_job_exec_count int;
   declare l_remain_jobs long;
   declare l_family_id int;
   DECLARE t_error INTEGER DEFAULT 0;  
   declare cur cursor for select id from l_container_ids;
	DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1;  
	DROP TEMPORARY TABLE IF EXISTS try_container_ids;
	create temporary table try_container_ids(id long) engine=memory; 
    insert into try_container_ids values (
	  (SELECT cj.container_job_id        
        FROM   job_queue jq, 
               fusion_jobs fj, 
               container_jobs cj
        WHERE  jq.job_state < 2 
        AND    0 < jq.remain_jobs 
        AND    jq.job_id = fj.job_id 
        AND    fj.fusion_job_id = cj.fusion_job_id 
        AND    jq.job_id = p_job_id  
        FOR UPDATE)     
    );
    set  l_remain_jobs= try_container_ids.count;
      IF(0 < l_remain_jobs) THEN
		UPDATE container_jobs
        SET mr_id =NULL,
            assigned_ts =NULL,
            job_state =c_job_state_queued,
            plan_id =NULL,
            result_ts =NULL,
            container_job_result =NULL
        WHERE container_job_id IN (SELECT id from try_container_ids);
		UPDATE job_queue
        SET job_state =0,
            failure_count=failure_count+1,
            assigned_ts =NULL,
            remain_jobs = l_remain_jobs
        WHERE job_id = p_job_id;
        
        SELECT jq.family_id 
            INTO   l_family_id 
            FROM   job_queue jq 
            WHERE  jq.job_id = p_job_id;
  
         UPDATE inquiry_traffic
        SET job_exec_count=job_exec_count-1
        WHERE family_id = l_family_id;
        select job_exec_count INTO l_job_exec_count from inquiry_traffic;
        
        IF l_job_exec_count <0 THEN 
         call Init_executing_job_count(); 
          select job_exec_count  INTO l_job_exec_count from inquiry_traffic
          WHERE family_id = l_family_id;
        END IF;  
	    if t_error=1 then
           rollback;
            set  o_job_exec_count = -1;
	    else 
	        commit;
           set  o_job_exec_count = l_job_exec_count;
	    end if; 
      end if;
END