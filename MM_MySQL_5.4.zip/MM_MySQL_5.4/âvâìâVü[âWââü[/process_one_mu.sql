CREATE DEFINER=`aimuser`@`%` PROCEDURE `process_one_mu`(
    IN p_max_lot int,         
    OUT l_lot_job_id int,
    OUT l_mu_id int,
	OUT l_currentlots  int
)
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
mylable :BEGIN
      declare l_num_extractor int;
      declare  l_remain_lots int;     
      declare  l_one_lot_count int;      
      declare   l_fe_job_timeout long;   
      declare  l_current_epoch_time long; 
	  DECLARE t_error INTEGER DEFAULT 0;  
      declare v_idx int default 999 ;
      declare v_tmp_str varchar(20);
      declare v_id int; 
      declare s_num int;
	declare cur cursor for select id from l_container_ids;
     DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1;  
      DECLARE EXIT HANDLER FOR NOT FOUND  SET s_num = -1;

	DROP TEMPORARY TABLE IF EXISTS  l_locked_fe_job_ids;
	create temporary table  l_locked_fe_job_ids(id int) engine=memory; 
        SELECT mus.mu_id, 
                 mls.pressure  AS currentlots, 
                 mus.number_of_extractors  AS num_extractor, 
                 p_max_lot - mls.pressure  AS remain_lots 
        INTO     l_mu_id ,l_currentlots,l_one_lot_count,l_remain_lots       
         FROM   match_units mus, 
                 mu_extract_load mls 
          WHERE  mus.mu_id = mls.mu_id 
                 AND mus.state = 'WORKING'
                 AND mus.mu_id = (SELECT mu.mu_id, 
                                             ml.pressure 
                                             AS 
                                             currentlots, 
                                             mu.number_of_extractors 
                                             AS 
                                             num_extractor, 
                                             p_max_lot - ml.pressure 
                                             AS 
                                             remain_lots                          
                                      FROM   match_units mu, 
                                             mu_extract_load ml, 
                                             mu_eligible_functions mf 
                                      WHERE  mu.mu_id = ml.mu_id 
                                             AND mu.mu_id = mf.mu_id 
                                             AND mu.state = c_working_state_string 
                                             AND  p_max_lot - ml.pressure > 0
                                             AND mf.function_id = 17) 
                                     ORDER BY ml.pressure ,  ml.update_ts  
                                      limit 1                                               
                                 for update  NOWAIT;
	if s_num < 0 then 
      rollback;
      leave mylable;
	end if;
     
                                 
    
    
     


END