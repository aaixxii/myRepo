CREATE DEFINER=`aimuser`@`%` PROCEDURE `process_one_mu`(
    IN p_max_lot int,         
    OUT l_lot_job_id int,
    OUT l_mu_id int,
	OUT l_currentlots  int
)
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
mylable :BEGIN
      declare l_num_extractor int;
      declare  l_remain_lots int;     
      declare  l_one_lot_count int;      
      declare   l_fe_job_timeout long;   
      declare  l_current_epoch_time long; 
	  DECLARE t_error INTEGER DEFAULT 0;  
      declare v_idx int default 999 ;
      declare v_tmp_str varchar(20);
      declare v_id int; 
      declare notfound int;
	declare tmp_count int;
	declare cur cursor for select id from l_locked_fe_job_ids;
     DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1;  
	DECLARE CONTINUE HANDLER FOR NOT FOUND  SET notfound = 1 ;
	DROP TEMPORARY TABLE IF EXISTS  l_locked_fe_job_ids;
	create temporary table  l_locked_fe_job_ids(id int) engine=memory; 
 
 	DROP TEMPORARY TABLE IF EXISTS  fe_job_ids_tab;
	create temporary table  fe_job_ids_tab(id int) engine=memory; 
    
        SELECT mus.mu_id, 
                 mls.pressure  AS currentlots, 
                 mus.number_of_extractors  AS num_extractor, 
                 p_max_lot - mls.pressure  AS remain_lots 
        INTO     l_mu_id ,l_currentlots,l_one_lot_count,l_remain_lots       
         FROM   match_units mus, 
                 mu_extract_load mls 
          WHERE  mus.mu_id = mls.mu_id 
                 AND mus.state = 'WORKING'
                 AND mus.mu_id = (SELECT mu.mu_id, 
                                             ml.pressure 
                                             AS 
                                             currentlots, 
                                             mu.number_of_extractors 
                                             AS 
                                             num_extractor, 
                                             p_max_lot - ml.pressure 
                                             AS 
                                             remain_lots                          
                                      FROM   match_units mu, 
                                             mu_extract_load ml, 
                                             mu_eligible_functions mf 
                                      WHERE  mu.mu_id = ml.mu_id 
                                             AND mu.mu_id = mf.mu_id 
                                             AND mu.state = c_working_state_string 
                                             AND  p_max_lot - ml.pressure > 0
                                             AND mf.function_id = 17) 
                                     ORDER BY ml.pressure ,  ml.update_ts  
                                      limit 1                                               
                                 for update of mus NOWAIT;
	if notfound =1 then 
      rollback;
      leave mylable;
	end if;
    insert into fe_job_ids_tab(id) values (
		(SELECT   fj.job_id                                            
		FROM     fe_job_queue fj 
		WHERE    fj.job_state = 0
		AND      fj.priority  = 1
        ORDER BY fj.priority, fj.failure_count DESC, fj.job_id
        limit 1) 
    );
    select count(id) into tmp_count from fe_job_ids_tab;
    if tmp_count =1 then  
      set l_one_lot_count = 1;
    elseif tmp_count < 1 then
      insert into fe_job_ids_tab(id) values (
		 (SELECT   fj.job_id                                        
	     FROM     fe_job_queue fj 
         WHERE    fj.job_state = 0  
         ORDER BY fj.priority, fj.failure_count DESC, fj.job_id
         limit 1
         FOR UPDATE OF fj NOWAIT)  
      );  
    end if;
    
     select count(id) into tmp_count from fe_job_ids_tab;
		IF (tmp_count IS NULL  OR tmp_count = 0 ) then 
        -- dbms_output.Put_line ('no fe_job to assign! return'); 
          ROLLBACK; 
        leave mylable;   
       END IF; 
     SELECT top_level_job_timeouts 
      INTO   l_fe_job_timeout 
      FROM   function_types 
      WHERE  function_id = 17 
      AND    queue_type = 1;    
      set l_fe_job_timeout = l_fe_job_timeout * l_locked_fe_job_ids.count; 
      set l_current_epoch_time = get_epoch_time_num(); 
	  INSERT INTO fe_lot_jobs 
		( 			 
			mu_id, 
			assigned_ts, 
			timeouts 
		) 
		VALUES 
		( 		
			l_mu_id, 
			l_current_epoch_time, 
			l_fe_job_timeout 
		);
        
        select max(lot_job_id) into l_lot_job_id from fe_lot_jobs;
		UPDATE mu_extract_load 
        SET    pressure = pressure + 1, 
               update_ts = l_current_epoch_time 
        WHERE  mu_id = l_mu_id; 
        open cur;
          lable_loop: loop
           FETCH cur INTO v_id;
		UPDATE fe_job_queue 
        SET  lot_job_id = l_lot_job_id, 
			 mu_id = l_mu_id, 
			job_state = 1, 
			assigned_ts = l_current_epoch_time 
        WHERE  job_id = v_id;    
		end loop;
        close cur;
	if t_error=1 then
        rollback;
	 else 
	   commit;
	 end if; 
END