use AIMDB;
 insert into extract_complete_count(complete_count,complete_ts) values(0,0);
 COMMIT;


