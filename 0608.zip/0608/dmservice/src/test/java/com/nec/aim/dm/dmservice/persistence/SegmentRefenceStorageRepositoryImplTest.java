package com.nec.aim.dm.dmservice.persistence;

import java.sql.SQLException;
import java.util.List;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.junit4.SpringRunner;

import com.nec.aim.dm.dmservice.DmserviceApplication;
import com.nec.aim.dm.dmservice.entity.SegBioNsmUrl;

@RunWith(SpringRunner.class)  
@SpringBootTest(classes={DmserviceApplication.class})
public class SegmentRefenceStorageRepositoryImplTest {
	
	@Autowired
	SegmentRefenceStorageRepository segmentRefenceStorageRepository;
	
	@Autowired
    private JdbcTemplate jdbcTemplate;

	@Before
	public void setUp() throws Exception {
		jdbcTemplate.execute("delete from segment_ref_storage_info");
		jdbcTemplate.execute("commit");
	}

	@After
	public void tearDown() throws Exception {
		jdbcTemplate.execute("delete from segment_ref_storage_info");
		jdbcTemplate.execute("commit");
	}

	@Test
	public void testInserSegmentRefenceStorageInfo() throws SQLException {
		segmentRefenceStorageRepository.inserSegmentRefenceStorageInfo(1, 1000L, 1L, "externalId1");
		Integer result = jdbcTemplate.queryForObject("select count(*) from segment_ref_storage_info", Integer.class);
		Assert.assertEquals(1, result.intValue());
		
	}

	@Test
	public void testInsertSegRefStorageWitoutRefId() throws SQLException {
		segmentRefenceStorageRepository.insertSegRefStorageWitoutRefId(1, 1000L, 1L);
		Integer result = jdbcTemplate.queryForObject("select count(*) from segment_ref_storage_info", Integer.class);
		Assert.assertEquals(1, result.intValue());
		
	}

	@Test
	public void testDeleteSegmentRefenceStorageInfo() throws SQLException {
		segmentRefenceStorageRepository.inserSegmentRefenceStorageInfo(1, 1000L, 1L, "externalId1");
		Integer result1 = jdbcTemplate.queryForObject("select count(*) from segment_ref_storage_info", Integer.class);
		Assert.assertEquals(1, result1.intValue());
		segmentRefenceStorageRepository.deleteSegmentRefenceStorageInfo(1, 1000L, 1L);
		Integer result0 = jdbcTemplate.queryForObject("select count(*) from segment_ref_storage_info", Integer.class);
		Assert.assertEquals(0, result0.intValue());
		
	}

	@Test
	public void testUpdateSegmentRefenceStorageInfo() throws SQLException {
		segmentRefenceStorageRepository.insertSegRefStorageWitoutRefId(1, 1000L, 1L);		
		Integer result = jdbcTemplate.queryForObject("select count(*) from segment_ref_storage_info", Integer.class);
		Assert.assertEquals(1, result.intValue());
		int updateCount = segmentRefenceStorageRepository.updateSegmentRefenceStorageInfo( "externaltest",1, 1000L, 1L);
		Assert.assertEquals(1, updateCount);
		jdbcTemplate.execute("commit");
		String refId = jdbcTemplate.queryForObject("select external_id from segment_ref_storage_info where storage_id=1 and segment_id=1000 and bio_id=1", String.class);
		Assert.assertEquals("externaltest", refId);	
	}

	@Test
	public void testGetInfoForGetTemplate() throws SQLException {
		segmentRefenceStorageRepository.inserSegmentRefenceStorageInfo(1, 1000L, 1L, "externalId1");
		Integer result1 = jdbcTemplate.queryForObject("select count(*) from segment_ref_storage_info", Integer.class);
		Assert.assertEquals(1, result1.intValue());
		List<SegBioNsmUrl> result = segmentRefenceStorageRepository.getInfoForGetTemplate("externalId1");
		Assert.assertNotNull(result);		
	}

}
