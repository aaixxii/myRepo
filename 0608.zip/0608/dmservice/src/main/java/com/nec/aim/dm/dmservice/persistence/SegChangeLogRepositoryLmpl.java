package com.nec.aim.dm.dmservice.persistence;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.nec.aim.dm.dmservice.entity.SegChangeLog;

@Repository
public class SegChangeLogRepositoryLmpl implements SegChangeLogRepository{
	
	private static final String insertForNewSql = "insert into segment_change_log(biometrics_id,segment_id,segment_version, change_type, update_ts) values(?,?,?,?,CURRENT_TIMESTAMP())";
	private static final String insertSql = "insert into segment_change_log(biometrics_id,external_id,template_data,segment_id,segment_version, change_type, update_ts) values(?,?,?,?,?,?,CURRENT_TIMESTAMP())";
	private static final String deleteSql = "insert into segment_change_log(biometrics_id,external_id,segment_id,segment_version, change_type,update_ts) values(?,?,?,?,?,CURRENT_TIMESTAMP())";
	@Autowired
    private JdbcTemplate jdbcTemplate;
	
	@Override
	public void insertForNewSegment(Long biometricsId, Long segmentId, Long segmentVer, Integer catchUp) throws SQLException {
		jdbcTemplate.execute("SET @@autocommit=0");
		jdbcTemplate.update(insertForNewSql, new Object[] {biometricsId, segmentId, segmentVer, catchUp});
		
	}

	@Override
	public void insert(SegChangeLog catchUp) throws SQLException {
		jdbcTemplate.execute("SET @@autocommit=0");
		jdbcTemplate.update(insertSql, new Object[] {catchUp.getBiometricsId(), catchUp.getExternalId(), catchUp.getTemplateData(), catchUp.getSegmentId(), catchUp.getSegmentVersion(),catchUp.getChangeType()});
	}

	@Override
	public void delete(SegChangeLog catchUp) throws SQLException {
		jdbcTemplate.execute("SET @@autocommit=0");
		jdbcTemplate.update(deleteSql, new Object[] {catchUp.getBiometricsId(), catchUp.getExternalId(), catchUp.getSegmentId(), catchUp.getSegmentVersion(),catchUp.getChangeType()});
	}
}
