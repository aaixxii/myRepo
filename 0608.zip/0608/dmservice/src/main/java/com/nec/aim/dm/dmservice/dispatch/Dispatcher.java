package com.nec.aim.dm.dmservice.dispatch;

import java.sql.Blob;
import java.sql.SQLException;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutionException;

import javax.sql.rowset.serial.SerialBlob;
import javax.sql.rowset.serial.SerialException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import com.nec.aim.dm.dmservice.config.ConfigProperties;
import com.nec.aim.dm.dmservice.entity.NodeStorage;
import com.nec.aim.dm.dmservice.entity.SegChangeLog;
import com.nec.aim.dm.dmservice.entity.SegmentInfo;
import com.nec.aim.dm.dmservice.entity.SegmentLoading;
import com.nec.aim.dm.dmservice.exception.DmServiceException;
import com.nec.aim.dm.dmservice.persistence.DmConfigRepository;
import com.nec.aim.dm.dmservice.persistence.DmInfoRepository;
import com.nec.aim.dm.dmservice.persistence.NodeStorageRepository;
import com.nec.aim.dm.dmservice.persistence.SegmentLoadRepository;
import com.nec.aim.dm.dmservice.persistence.SegmentRepository;
import com.nec.aim.dm.dmservice.post.HttpPoster;

import jp.co.nec.aim.message.proto.AIMEnumTypes.SegmentSyncCommandType;
import jp.co.nec.aim.message.proto.AIMMessages.PBDmSyncRequest;
import jp.co.nec.aim.message.proto.BusinessMessage.PBTemplateInfo;
import lombok.extern.slf4j.Slf4j;


@Service
@Slf4j
public class Dispatcher {
	
	@Autowired
	DmInfoRepository dmInfoRepository;

	@Autowired
	NodeStorageRepository nodeRepository;

	@Autowired
	DmConfigRepository dmConfigRepository;

	@Autowired
	SegmentLoadRepository segmentLoadRepository;

	@Autowired
	SegmentRepository segmentRepository;
	
//	@Autowired
//	SegChangeLogRepository segChangeLogRepository;
	
	@Autowired
	ConfigProperties config;
	
//	@Autowired
//	SegmentRefenceStorageRepository segmentRefenceStorageRepository;

	//@Transactional(isolation = Isolation.READ_COMMITTED)
	@Transactional
	public boolean handlePostRequest(List<NodeStorage> activeNodeStorages, PBDmSyncRequest dmSegReq, SegmentInfo segInfo) {		
		String changeType = dmSegReq.getCmd().name().toUpperCase();		
		boolean mmReturnValue = true;		
		try {
			if (changeType.equals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_NEW.name())) { // add segment	
//				int redundancy = dmConfigRepository.getRedundancy();
//				if (redundancy < 1) {
//					throw new DmServiceException("redundancy is less 1! Can't process dm service will return.");
//				}
//				List<NodeStorage>  activeNodeStorages = nodeRepository.findNeedNodeByRedundancy(redundancy);
//				log.info("activeNodeStorages=" + activeNodeStorages.size());
//				if (activeNodeStorages == null || activeNodeStorages.size() < 1) {
//					throw new DmServiceException("No active node storages! skip process and return.");
//				}
				mmReturnValue = processNewSegment(activeNodeStorages, segInfo, dmSegReq);
			}  else {
//				List<NodeStorage> targetNodeStorages = nodeRepository.getNodeStorgeBySegmentId(segInfo.getSegmentId());
//				if (targetNodeStorages == null == targetNodeStorages.size() < 1) {
//					log.warn("No active storage manager which asigned semgent("+ segInfo.getSegmentId() +"). skip process");
//					return false;
//				}
				if (changeType.equals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT.name())) { // insert template
					mmReturnValue = processTempalteInsert(activeNodeStorages, segInfo, dmSegReq);
				} else if (changeType.equals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_DELETE.name())) { // delete template
					mmReturnValue = processTempalteDelete(activeNodeStorages, segInfo, dmSegReq);
				}
			}
		} catch (SQLException e) {
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			log.error(e.getMessage());
		}	
		return mmReturnValue;
	}
	
	//@Transactional(isolation = Isolation.READ_COMMITTED)
	public List<NodeStorage> getActiveNodeStorages(String changeType, Long segId) {	
		List<NodeStorage> activeNodeStorages = null;
		int redundancy = DmServiceManager.getRedundancy().get();
		if (redundancy < 1) {
			log.warn("redundancy is less 1! Can't continue process.");
			return null;
		}
		try {
			if (changeType.equals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_NEW.name())) {
				//int redundancy = dmConfigRepository.getRedundancy();	
				activeNodeStorages = nodeRepository.findNeedNodeByRedundancy(redundancy);
				if (null == activeNodeStorages || activeNodeStorages.size() < 1) {
					log.warn("No active node storages! skip process and return.");
				}
			} else {
				activeNodeStorages = nodeRepository.getNodeStorgeBySegmentId(segId, Integer.valueOf(redundancy));
				if (activeNodeStorages == null || activeNodeStorages.size() < 1) {
					log.warn("No active storage manager which asigned semgent("+ segId +"). Can't continue process.");
				}
			}
			log.info("activeNodeStorages=" + activeNodeStorages.size());
		} catch (SQLException e) {
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			log.error(e.getMessage());
		}	
		return activeNodeStorages;
	}

	public boolean processNewSegment(List<NodeStorage> activeNodeStorages, SegmentInfo segInfo, PBDmSyncRequest dmSegReq) throws SQLException {		
		if (segInfo.getBioIdStart() == null || segInfo.getBioIdEnd() == null) {
			throw new DmServiceException("In new segment, bio_id_start and bio_id_end can't be null");
		}
		SegmentLoading segLoading = new SegmentLoading();
		segLoading.setSegmentId(segInfo.getSegmentId());
		if (segInfo.getVersion() != null) {
			segLoading.setLastVersion(segInfo.getVersion());
		} else {
			segInfo.setVersion(-1L);
		}		
		boolean mmReturnValue = false;
		try {
			segmentRepository.insertSegment(segInfo);	
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			if (e instanceof  DuplicateKeyException) {
				log.warn("segment({}) is already exists, skip process.", segInfo.getSegmentId());
				return true;	
			}	
		}
		//segChangeLogRepository.insertForNewSegment(segInfo.getBioIdStart(), segInfo.getSegmentId(), segInfo.getVersion(), 0);			 
		for (int i = 0; i < activeNodeStorages.size(); i++) {
			NodeStorage one = activeNodeStorages.get(i);
			segLoading.setStorage_id(one.getStorageId());
			segLoading.setStatus(0);
			segmentLoadRepository.insertSegmentLoad(segLoading);
			//segmentRefenceStorageRepository.insertSegRefStorageWitoutRefId(activeNodeStorages.get(i).getStorageId(), segInfo.getSegmentId(), segInfo.getBioIdStart());
	
			//String nodeUrl = dmInfoRepository.getNodeStorageUrl(one.getStorageId());
			String nodeUrl = DmServiceManager.getValueFromNodeStorageUrlMap(one.getStorageId());
			nodeUrl = nodeUrl + config.getNsmSyncMethod();
			log.info("post url is {}", nodeUrl);
			Boolean result = HttpPoster.post(nodeUrl, dmSegReq);
			try {
				if (result.booleanValue()) {
					segmentRepository.updateAfterNew(-1, segInfo.getSegmentId());
					segmentLoadRepository.updateAfterNew(-1, one.getStorageId(), segInfo.getSegmentId());
					//segLoading.setStatus(-1);
					//segmentLoadRepository.insertSegmentLoad(segLoading);
				} else {
					segmentRepository.updateAfterNew(-9, segInfo.getSegmentId());
					segmentLoadRepository.updateAfterNew(-9, one.getStorageId(), segInfo.getSegmentId());
					//segLoading.setStatus(-9);
					//segmentLoadRepository.insertSegmentLoad(segLoading);
					nodeRepository.setSignalMailFlag(one.getStorageId(), one.getDmStorageid());
				}				
			} catch (Exception e) {				
				segmentRepository.updateAfterNew(-9, segInfo.getSegmentId());
				segmentLoadRepository.updateAfterNew(-9, one.getStorageId(), segInfo.getSegmentId());
				//segLoading.setStatus(-9);
				//segmentLoadRepository.insertSegmentLoad(segLoading);
				nodeRepository.setSignalMailFlag(one.getStorageId(), one.getDmStorageid());	
				TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			}			
			mmReturnValue = mmReturnValue || result.booleanValue();
		}
		return mmReturnValue;
	}

	public boolean processTempalteInsert(List<NodeStorage> targetNodeStorages,SegmentInfo segInfo, PBDmSyncRequest dmSegReq) throws SerialException, SQLException {	
		String externalId = null;
		byte[] templateData = null;
		if (dmSegReq.hasTemplateData()) {
			PBTemplateInfo tmpData = dmSegReq.getTemplateData();
			if (tmpData.hasReferenceId()) {
				externalId = tmpData.getReferenceId();
			}
			if (tmpData.hasData()) {
				templateData = tmpData.getData().toByteArray();
			}
		}		
		if (segInfo.getBioIdEnd() == null || externalId == null || templateData == null) {
			throw new DmServiceException("In insert template,  bio_id_end, external id, template data can't be null");
		}
		boolean mmReturnValue = false;		
		SegmentLoading segLoading = new SegmentLoading();
		segLoading.setSegmentId(segInfo.getSegmentId());
		SegChangeLog changeLog = new SegChangeLog();
		changeLog.setBiometricsId(segInfo.getBioIdEnd());
		changeLog.setChangeType(1);
		changeLog.setExternalId(externalId);
		changeLog.setSegmentId(segInfo.getSegmentId());
		changeLog.setSegmentVersion(segInfo.getVersion());
		Blob blob = new SerialBlob(templateData);
		changeLog.setTemplateData(blob);
		//segChangeLogRepository.insert(changeLog);
		
		boolean needUpdateSegement = true;
		for (int i = 0; i < targetNodeStorages.size(); i++) {
			NodeStorage one = targetNodeStorages.get(i);
			segLoading.setStorage_id(one.getStorageId());
			Boolean result = null;				
			try {
				long nodoSegmentVersion = segmentLoadRepository.getLastVersion(one.getStorageId(), segInfo.getSegmentId());						
				if (segInfo.getVersion() == nodoSegmentVersion + 1) {
					if (needUpdateSegement) {
						segmentRepository.updateSegment(segInfo);
						needUpdateSegement = false;
					}					
					//segmentRefenceStorageRepository.inserSegmentRefenceStorageInfo(targetNodeStorages.get(i).getStorageId(), segInfo.getSegmentId(), segInfo.getBioIdEnd(), externalId);
					
					//String nodeUrl = dmInfoRepository.getNodeStorageUrl(one.getStorageId());
					String nodeUrl = DmServiceManager.getValueFromNodeStorageUrlMap(one.getStorageId());
					nodeUrl = nodeUrl + config.getNsmSyncMethod();
					log.info("nodeUrl= {}", nodeUrl);
					result = HttpPoster.post(nodeUrl, dmSegReq);
					if (result.booleanValue()) {						
						segLoading.setLastVersion(segInfo.getVersion());
						segmentLoadRepository.updateSegmentLoadNoMailFlag(segLoading);
					} else {
						log.warn("Http poster result is false. segmentId={}, semgnetVersion={}", segInfo.getSegmentId(), segInfo.getVersion());
						log.info("Result if false,setting mail falg");
						result = Boolean.FALSE;
						nodeRepository.setSignalMailFlag(one.getStorageId(), one.getDmStorageid());
					}
				} else {
					log.warn("segment version({}) +1 in segment_loading table is not equeal the verion from mm, segmentId={}", nodoSegmentVersion, segInfo.getSegmentId());
					result = Boolean.FALSE;
					log.info("Version not equal,setting mail falg");
					nodeRepository.setSignalMailFlag(one.getStorageId(), one.getDmStorageid());				
				}				
			} catch (Exception e) {
				log.error(e.getMessage() ,e);
				log.info("Excetpon happen setting mail falg");				
				nodeRepository.setSignalMailFlag(one.getStorageId(), one.getDmStorageid());
				TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			} 				
			mmReturnValue = mmReturnValue || result.booleanValue();
		}
		return mmReturnValue;
	}

	public boolean processTempalteDelete(List<NodeStorage> targetNodeStorages, SegmentInfo segInfo,
			PBDmSyncRequest dmSegReq) throws SQLException {	
		String externalId = null;		
		if (dmSegReq.hasTemplateData()) {
			PBTemplateInfo tmpData = dmSegReq.getTemplateData();
			if (tmpData.hasReferenceId()) {
				externalId = tmpData.getReferenceId();
			}		
		}	
		if (segInfo.getBioIdEnd() == null) {
			throw new DmServiceException("In delete template,  bio_id_end, can't be null");
		}		
		boolean mmReturnValue = false;
		
		SegmentLoading segLoading = new SegmentLoading();
		segLoading.setSegmentId(segInfo.getSegmentId());
		SegChangeLog changeLog = new SegChangeLog();
		changeLog.setBiometricsId(segInfo.getBioIdEnd());
		changeLog.setChangeType(2);
		changeLog.setExternalId(externalId);
		changeLog.setSegmentId(segInfo.getSegmentId());
		changeLog.setSegmentVersion(segInfo.getVersion());
		//segChangeLogRepository.delete(changeLog);
		
		boolean needUpdateSegement = true;			
		for (int i = 0; i < targetNodeStorages.size(); i++) {
			NodeStorage one = targetNodeStorages.get(i);
			segLoading.setStorage_id(one.getStorageId());
			Boolean result = null;			
			try {
				long nodoSegmentVersion = segmentLoadRepository.getLastVersion(one.getStorageId(),
						segInfo.getSegmentId());
				if (segInfo.getVersion() == nodoSegmentVersion + 1) {
					if (needUpdateSegement) {
						segmentRepository.updateSegmentAfterDelete(segInfo); 
						needUpdateSegement = false;
					}					
					//segmentRefenceStorageRepository.deleteSegmentRefenceStorageInfo(targetNodeStorages.get(i).getStorageId(), segInfo.getSegmentId(), segInfo.getBioIdEnd());
					//String nodeUrl = dmInfoRepository.getNodeStorageUrl(one.getStorageId());
					String nodeUrl = DmServiceManager.getValueFromNodeStorageUrlMap(one.getStorageId());
					nodeUrl = nodeUrl + config.getNsmSyncMethod();
					result = HttpPoster.post(nodeUrl, dmSegReq);
					if (result.booleanValue()) {
						segLoading.setLastVersion(segInfo.getVersion());										
						segmentLoadRepository.updateAfterDelWithNoMailFlag(segLoading);
					} else {
						log.info("Result if false,setting mail falg");
						nodeRepository.setSignalMailFlag(one.getStorageId(), one.getDmStorageid());
					}
				} else {
					log.info("Version not equal,setting mail falg");
					nodeRepository.setSignalMailFlag(one.getStorageId(), one.getDmStorageid());
				}
			} catch (Exception e) {
				nodeRepository.setSignalMailFlag(one.getStorageId(), one.getDmStorageid());
				result = false;
				log.info("Excetpon happen setting mail falg");
				TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			} 
			mmReturnValue = mmReturnValue || result.booleanValue();
		}
		return mmReturnValue;
	}	
	
	//@Transactional(isolation = Isolation.READ_COMMITTED)
	@Transactional
	public byte[] dispatchDownloadReqeust(Long segId) throws InterruptedException, ExecutionException {
		List<NodeStorage> activeList = null;
		Integer rdundancy = Integer.valueOf(DmServiceManager.getRedundancy().get());		 
		try {
			activeList = nodeRepository.getNodeStorgeBySegmentId(segId, rdundancy);
		} catch (SQLException e) {
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			log.error(e.getMessage());
		};
		if (activeList == null || activeList.size() < 1) {
			throw new DmServiceException("No active dm stroage node for process");
		}
		Collections.shuffle(activeList);
		String nodeUrl = DmServiceManager.getValueFromNodeStorageUrlMap(activeList.get(0).getStorageId());
		nodeUrl = nodeUrl.endsWith("/") ? nodeUrl : nodeUrl + "/";
		nodeUrl = nodeUrl + config.getNsmDownloadMeghod() + segId;
		byte[] result = HttpPoster.getSegment(nodeUrl, segId);
		if (null == result) {
			throw new DmServiceException("faild to get template from " + nodeUrl + ". segId=" + segId);
		}
		return result;
	}	
}
