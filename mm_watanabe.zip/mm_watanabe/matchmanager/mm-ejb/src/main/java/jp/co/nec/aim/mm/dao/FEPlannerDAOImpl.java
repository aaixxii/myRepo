package jp.co.nec.aim.mm.dao;

import java.sql.SQLException;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

import jp.co.nec.aim.mm.extract.planner.MuRemainLots;
import jp.co.nec.aim.mm.procedure.GetFirstMuRemainLotsProcedure;
import jp.co.nec.aim.mm.procedure.ProcessOneMuLotProcedure;

/**
 * get all data from database for creating extract plans
 * 
 * @author xiazp
 *
 */
public class FEPlannerDAOImpl implements FEPlannerDAO {
	private static final Logger logger = LoggerFactory
			.getLogger(FEPlannerDAOImpl.class);

	private EntityManager manager;
	private JdbcTemplate jdbcTemplate;

	private GetFirstMuRemainLotsProcedure getFirstMuRemainLotsProcedure;
	private ProcessOneMuLotProcedure processOneMuLotProcedure;	

	private static final String ROLL_BACK_FELOT_JOB_SQL = "delete from FE_LOT_JOBS where LOT_JOB_ID = ?";
	//private static final String ROLLBACK_MU_EXTRACT_LOAD_SQL = "update MU_EXTRACT_LOAD ml set ml.PRESSURE =DECODE(SIGN(ml.PRESSURE -1),-1,0,0,0,1,ml.PRESSURE -1),ml.UPDATE_TS = 0 where ml.MU_ID = ?";

	private static final String ROLLBACK_MU_EXTRACT_LOAD_SQL = "update MU_EXTRACT_LOAD ml set ml.PRESSURE=CASE SIGN(ml.PRESSURE -1) WHEN -1 THEN 0 WHEN 0 THEN 0 WHEN 1 THEN ml.PRESSURE -1 END, ml.UPDATE_TS = 0  where ml.MU_ID = ?";
	
	private static final String ROLLBACK_FE_JOB_QUQUE = ""
			+ "UPDATE FE_JOB_QUEUE SET LOT_JOB_ID = null, MU_ID = null, JOB_STATE = 0, ASSIGNED_TS = null "
			+ "WHERE LOT_JOB_ID = ?";

	private static final String GET_MAX_MU_LOT = " SELECT KEY_VALUE FROM SYSTEM_INIT "
			+ " WHERE KEY_NAME = 'NUM_OF_MAX_FE_LOT'";

	private static final String SET_PRESSURE_TO_MAX_LOT_COUNT = "update MuExtractLoadEntity ml set ml.pressure = :pressure where ml.muId = :muId";

	// private static final String LOCK_FOR_FEPLANNER =
	// "LOCK TABLE match_units, mu_extract_load,fe_job_queue IN SHARE ROW EXCLUSIVE MODE";
	private static final String LOCK_FOR_FEPLANNER = "select NAME from MM_EVENTS where NAME = 'FEJOB_PLANNER' for update";

	private static final String GET_CURRENT_MU_LOT_SQL = "select PRESSURE from MU_EXTRACT_LOAD where MU_ID = ? for update";

	public FEPlannerDAOImpl(DataSource dataSource, EntityManager manager) {
		this.manager = manager;
		this.jdbcTemplate = new JdbcTemplate(dataSource);
		getFirstMuRemainLotsProcedure = new GetFirstMuRemainLotsProcedure(
				dataSource);
		processOneMuLotProcedure = new ProcessOneMuLotProcedure(dataSource);
	}

	/**
	 * get one mu that is best fit to assign job to it
	 * 
	 * @param maxMuLot
	 * @return MuRemainLots
	 * @exception PersistenceException
	 */

	@Override
	public MuRemainLots getfirstMuRemainLots(int maxMuLot) {
		try {
			MuRemainLots resutls = getFirstMuRemainLotsProcedure
					.getfirstMuRemainLots(maxMuLot);
			return resutls;
		} catch (DataAccessException | SQLException e) {
			return null;
		}

	}

	/**
	 * assign one lot extract jobs to mu
	 * 
	 * @param muRemainLot
	 * @return assigned mu_lot_job_id
	 */
	@Override
	public Long processOneMuLot(MuRemainLots muRemainLot) {
		try {
			Long results = processOneMuLotProcedure
					.processOneMuList(muRemainLot);
			return results;
		} catch (DataAccessException | SQLException e) {
			logger.error(e.getMessage(), e);
			return null;
		}

	}

	/**
	 * get max mu lots from system_config table
	 * 
	 * @return max_mu_lots
	 */
	@Override
	public Integer getMaxMuLots() {
		Integer maxMuLot = -999;
		try {
			Query q = manager.createNativeQuery(GET_MAX_MU_LOT);
			String result = (String) q.getSingleResult();
			if (result != null) {
				maxMuLot = Integer.valueOf(result);
			}
		} catch (Exception e) {
			return -1;
		}

		return maxMuLot;
	}

	@Override
	public void setPressureToMaxLot(Long muId, Long newPressure)
			throws PersistenceException, SQLException {
		Query q = manager.createQuery(SET_PRESSURE_TO_MAX_LOT_COUNT);
		q.setParameter("pressure", newPressure);
		q.setParameter("muId", muId);
		q.executeUpdate();
		manager.flush();
	}

	@Override
	public Long getCurretMuLots(Long muId) {
		try {
			Long result = jdbcTemplate.queryForObject(GET_CURRENT_MU_LOT_SQL,
					Long.class, new Object[] { muId });
			return result;
		} catch (DataAccessException e) {
			return -1L;
		}
	}

	@Override
	public void lockForFePlanner() throws DataAccessException {
		jdbcTemplate.execute(LOCK_FOR_FEPLANNER);
	}

	@Override
	public void rollbackFeLotJobRelated(Long feLotJobId, Long muId) {
		deleteFeLotJob(feLotJobId);
		rollbackFeJobQueue(feLotJobId);
		rollbackMuExtractLoad(muId);
		jdbcTemplate.execute("commit");
	}

	public void deleteFeLotJob(Long feLotJobId) {
		jdbcTemplate.update(ROLL_BACK_FELOT_JOB_SQL, feLotJobId);
	}

	public void rollbackMuExtractLoad(Long muId) {
		jdbcTemplate.update(ROLLBACK_MU_EXTRACT_LOAD_SQL, muId);
	}

	public void rollbackFeJobQueue(Long feLotJobId) {
		jdbcTemplate.update(ROLLBACK_FE_JOB_QUQUE, feLotJobId);
	}

	@Override
	public Integer getFeLotJobCount(Long feLotJobId) {
		String countSlq = "selcet count(*) from FE_LOT_JOBS where LOT_JOB_ID = ?";
		try {
			Integer results = jdbcTemplate.queryForObject(countSlq,
					new Object[] { feLotJobId }, Integer.class);
			return results;
		} catch (EmptyResultDataAccessException e) {
			return null;
		} catch (DataAccessException e) {
			return null;
		}
	}

}
