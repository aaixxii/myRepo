/**this is file AimSyncInterface.java
 * @author xia
   @date 2020/09/24
 */
package jp.co.nec.aim.mm.acceptor.service;

import javax.ejb.Remote;

/**
 * @author xia
 *
 */
@Remote
public interface AimSyncRemote {
	public void getExtResAndDoSync(RemoteJobItem syncJobInfo);	
}
