package jp.co.nec.aim.mm.jms;

import java.io.Serializable;

public class AimJmsMessage implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 3325564250494973035L;

	private NotifierEnum notifier;
	private ReceiverEnum receiver;
	private String message;

	public AimJmsMessage(NotifierEnum notifier, ReceiverEnum receiver,
			String message) {
		this.notifier = notifier;
		this.receiver = receiver;
		this.message = message;
	}

	public NotifierEnum getNotifier() {
		return notifier;
	}

	public void setNotifier(NotifierEnum notifier) {
		this.notifier = notifier;
	}

	public ReceiverEnum getReceiver() {
		return receiver;
	}

	public void setReceiver(ReceiverEnum receiver) {
		this.receiver = receiver;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "AimJmsMessage(notifier:" + notifier.getNotifierName()
				+ ", receiver:" + receiver.getReceiverName() + ", message:"
				+ message + ").";
	}
}
