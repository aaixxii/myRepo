package com.nec.aim.dm.dmlsb;


import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DmlsbApplicationTests {

	@Test
	void contextLoads() {
	}

}
