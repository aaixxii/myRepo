package com.nec.aim.dm.dmlsb.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.nec.aim.dm.dmlsb.curator.ServiceMonitor;

import jp.co.nec.aim.message.proto.AIMMessages.PBDmSyncRequest;
import jp.co.nec.aim.message.proto.AIMMessages.PBDmSyncResponce;
import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class SegmentController extends HttpServlet{	
	private static final long serialVersionUID = 8978225136377187339L;
	
	@Autowired
	ServiceMonitor minitor;

	@RequestMapping(value = "/dmSyncSegment", method = RequestMethod.POST)
	public void dmSegmentHandler(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		PBDmSyncRequest dmSegReq =PBDmSyncRequest.parseFrom(req.getInputStream());
		PBDmSyncResponce.Builder dmRes = PBDmSyncResponce.newBuilder();
		boolean result = false;
		try {
			String leader = minitor.findLeaderIP();
			System.out.print(leader);
			result = true;
			dmRes.setSuccess(true);	
			log.info("success get respone from dm cluster, response = {}", result);
			dmRes.build().writeTo(res.getOutputStream());			
		} catch (Exception  e) {
			log.error(e.getMessage(), e);
			result = false;
			dmRes.setSuccess(result);
			dmRes.build().writeTo(res.getOutputStream());
		} 
	}
}
