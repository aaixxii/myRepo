package com.nec.aim.dm.dmlsb.curator;

import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.recipes.cache.ChildData;
import org.apache.curator.framework.recipes.cache.PathChildrenCache;
import org.apache.curator.framework.recipes.cache.PathChildrenCacheListener;
import org.apache.curator.utils.CloseableUtils;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.data.Stat;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.nec.aim.dm.dmlsb.config.ZkpConfigProperties;

import lombok.extern.slf4j.Slf4j;

@Component
@Scope("singleton")
@Slf4j
public class ServiceMonitor {

	@Autowired
	private CuratorFramework curatorFramework;

	@Autowired
	ZkpConfigProperties zkpConfig;

	private PathChildrenCache pathChildrenCache;
	 private static final ConcurrentHashMap<String, List<String>> services = new ConcurrentHashMap<>();

	@PostConstruct
	public void init() throws Exception {
		pathChildrenCache = new PathChildrenCache(curatorFramework, zkpConfig.getHeatbeatNode(), true);
		pathChildrenCache.start();
		PathChildrenCacheListener childrenCacheListener = (client, event) -> {
			ChildData data = event.getData();
			switch (event.getType()) {
			case CHILD_ADDED:
				log.info("CHILD_ADDED : " + data.getPath() + "  data:" + new String(data.getData()));
				//registerMyIP();
				break;

			case CHILD_REMOVED:
				log.info("CHILD_REMOVED : " + data.getPath() + "  data:" + new String(data.getData()));
//              serviceName = data.getPath().substring(PREFIX.length() + 1);
//              services.remove(serviceName);
//              
//              PathChildrenCache pathChildrenCache = serviceListeners.remove(serviceName);
//              if (pathChildrenCache != null) {
//            	  pathChildrenCache.getListenable().clear();
//              }
				break;
			default:
				break;
			}
		};
		pathChildrenCache.getListenable().addListener(childrenCacheListener);		
		 registerMyIP();
	}

	@PreDestroy
	public void stop() {
		CloseableUtils.closeQuietly(pathChildrenCache);
		CloseableUtils.closeQuietly(curatorFramework);
	}

	private void registerMyIP() throws Exception {
		Enumeration<NetworkInterface> e = NetworkInterface.getNetworkInterfaces();
		boolean stop = false;
		while (e.hasMoreElements() && !stop) {
			NetworkInterface n = (NetworkInterface) e.nextElement();
			Enumeration<?> ee = n.getInetAddresses();
			while (ee.hasMoreElements()) {
				InetAddress i = (InetAddress) ee.nextElement();
				if (isMyId(i)) {
					curatorFramework.create().withMode(CreateMode.EPHEMERAL_SEQUENTIAL)
							.forPath(zkpConfig.getHeatbeatNode() + "/" + i.getHostAddress(), i.getAddress());
					stop = true;
					break;
				}
			}
			if (stop) break;
		}
	}

	private boolean isMyId(InetAddress addr) {
		//String allIp = zkpConfig.getConnectString();
		String allIp = "192.168.232.143:2181,192.168.232.146:2181,127.0.0.1:2181";
		String[] ipArr = allIp.split(",") == null || allIp.split(",").length < 0 ? new String[] {allIp} :  allIp.split(",") ;
		if (ipArr.length > 0) {
			
		}
		for (String arr : ipArr) {
			int index = arr.indexOf(":");
			String ip = arr.substring(0, index);
			if (addr.getHostAddress().equals(ip)) {
				return true;
			}			
		}
		return false;
	}

	public String findLeaderIP() throws Exception {
		List<String> childList = curatorFramework.getChildren().forPath(zkpConfig.getHeatbeatNode());
		childList.forEach(one -> {
			int index = one.lastIndexOf(".");
			one = one.substring(0, index  + 2);
		} );
		Comparator<String> cmpStr = (String o1, String o2) -> {
			int reuslt = -999;
			try {
				Stat stat1 = curatorFramework.checkExists().forPath(o1);				
				Stat stat2 = curatorFramework.checkExists().forPath(o2);
				if (stat1.getCzxid() > stat2.getCzxid()) {
					reuslt = -1;
				} else if (stat1.getCzxid() == stat2.getCzxid()) {
					reuslt = 0;
				} else {
					reuslt = 1;
				}
			} catch (Exception e) {
				log.error(e.getMessage(), e);
			}
			return reuslt;

		};
		return childList.stream().min(cmpStr).get();
	}
}
