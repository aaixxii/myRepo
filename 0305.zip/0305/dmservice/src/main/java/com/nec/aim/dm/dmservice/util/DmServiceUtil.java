package com.nec.aim.dm.dmservice.util;

import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Enumeration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class DmServiceUtil {
	private static Logger logger = LoggerFactory.getLogger(DmServiceUtil.class);
	private static String allConnectionString;
	
	public static void init(String connectionString) {
		allConnectionString = connectionString;		
	}
	
	public String getMyIP() throws Exception {
		String resString = null;
		Enumeration<NetworkInterface> e = NetworkInterface.getNetworkInterfaces();
		boolean stop = false;
		InetAddress myIp = null;
		while (e.hasMoreElements() && !stop) {
			NetworkInterface n = (NetworkInterface) e.nextElement();
			Enumeration<?> ee = n.getInetAddresses();
			while (ee.hasMoreElements()) {
				InetAddress i = (InetAddress) ee.nextElement();
				if (isMyId(i)) {	
					myIp = i;
					stop = true;					
				}
				if (stop) break;
			}
			if (stop) break;
		}
		
		if (myIp != null) {
			resString = myIp.getHostAddress() + " is active";
		} else {
			resString = "";
		}
		return resString;
	}
	
	
	private boolean isMyId(InetAddress addr) {		
		if (allConnectionString == null || allConnectionString.isEmpty()) {
			logger.warn("DmServiceUtil class in not initializer yet, please call init.");
			return false;
	
		}
		//String allIp = "192.168.232.143:2181,192.168.232.146:2181,127.0.0.1:2181";
		String[] ipArr = allConnectionString.split(",") == null || allConnectionString.split(",").length < 0 ? new String[] {} :  allConnectionString.split(",") ;
		if (ipArr.length > 0) {
			for (String arr : ipArr) {
				int index = arr.indexOf(":");
				String ip = arr.substring(0, index);
				if (addr.getHostAddress().equals(ip)) {
					return true;
				}			
			}			
		}
		return false;
	}

}
