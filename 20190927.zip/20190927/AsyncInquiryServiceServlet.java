package jp.co.nec.aim.mm.async.servlet;

import static jp.co.nec.aim.mm.constants.ErrorMessage.INQ_BAD_REQUEST_ERROR;
import static jp.co.nec.aim.mm.constants.ErrorMessage.NOT_SUPPORT_METHOD;

import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.AsyncContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.nec.aim.message.proto.InquiryService.IdentifyRequest;
import jp.co.nec.aim.message.proto.InquiryService.IdentifyResponse;
import jp.co.nec.aim.message.proto.InquiryService.PBInquiryJobRequest;
import jp.co.nec.aim.message.proto.InquiryService.PBInquiryJobResponse;
import jp.co.nec.aim.message.proto.InquiryService.PBInquiryJobResult;
import jp.co.nec.aim.message.proto.JobCommonService.PBDeleteJobRequest;
import jp.co.nec.aim.message.proto.JobCommonService.PBJobResultRequest;
import jp.co.nec.aim.message.proto.JobCommonService.PBJobStatusRequest;
import jp.co.nec.aim.message.proto.JobCommonService.PBJobStatusResponse;
import jp.co.nec.aim.message.proto.JobCommonService.PBListJobIdsResponse;
import jp.co.nec.aim.mm.acceptor.service.AimInquiryService;
import jp.co.nec.aim.mm.logger.PerformanceLogger;
import jp.co.nec.aim.mm.servlet.AimAbstractServlet;
import jp.co.nec.aim.mm.util.StopWatch;
import jp.co.nec.aim.mm.web.manager.AimWebManager;

import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * InquiryServiceServlet
 * 
 * @author liuyq
 * 
 */
@WebServlet(value = "/AIMInquiryService/inquiry", asyncSupported = true)
public class AsyncInquiryServiceServlet extends AimAbstractServlet {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 3792084762155878017L;
	private static Logger log = LoggerFactory
			.getLogger(AsyncInquiryServiceServlet.class);

	private static final String INQUIRY_URL = "inquiry";	
	private static final String INQ_DELETEJOB_URL = "deletejob";
	private static final String INQ_CLEARJOBS_URL = "clearjobs";

	@EJB
	private AimInquiryService inquiryService;

	/**
	 * doPost
	 */
	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws IOException {
		final StopWatch t = new StopWatch();
		t.start();

		final String url = req.getRequestURI().toLowerCase();
		if (url.endsWith(INQUIRY_URL)) {
			doInquiry(req, res);	
		} else if (url.endsWith(INQ_DELETEJOB_URL)) {
			doDeleteJob(req, res);
		} else if (url.endsWith(INQ_CLEARJOBS_URL)) {
			doNoSuport(req, res, "clearJobs with post");
		} else {
			final String unknownMsg = String.format(NOT_SUPPORT_METHOD, "unknown");
			log.error(unknownMsg);
			writeErrorToResponse(req, res, HttpStatus.SC_METHOD_NOT_ALLOWED,
					unknownMsg, null);
			return;
		}

		t.stop();
		PerformanceLogger.log(getClass().getSimpleName(), "doPost",
				t.elapsedTime());
	}

	/**
	 * doGet
	 */
	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {

		final StopWatch t = new StopWatch();
		t.start();

		final String url = req.getRequestURI().toLowerCase();
		if (url.endsWith(INQUIRY_URL)) {
			doNoSuport(req, res, "inquiry with get");		
		} else if (url.endsWith(INQ_DELETEJOB_URL)) {
			doNoSuport(req, res, "deleteJob with get");
		} else if (url.endsWith(INQ_CLEARJOBS_URL)) {
			doClearJobs(req, res);
		} else {
			final String unknownMsg = String.format(NOT_SUPPORT_METHOD, "unknown");
			log.error(unknownMsg);
			writeErrorToResponse(req, res, HttpStatus.SC_BAD_REQUEST,
					unknownMsg, null);
			return;
		}

		t.stop();
		PerformanceLogger.log(getClass().getSimpleName(), "doPost",
				t.elapsedTime());
			
		
	}

	/**
	 * do inquiry process
	 * 
	 * @param req
	 *            HttpServletRequest
	 * @param res
	 *            HttpServletResponse
	 * @throws IOException
	 */
	private void doInquiry(final HttpServletRequest req,
			final HttpServletResponse res) throws IOException {
		AsyncContext asyncContext = req.startAsync();
		if (isContextSizeEmpty(req)) {
			writeErrorToResponse(req, res, HttpStatus.SC_BAD_REQUEST,
					EMPTY_REQUEST_MSG, null);
			return;
		}

		if (log.isDebugEnabled()) {
			log.debug("ready to deSerial from inputStream..");
		}
		IdentifyRequest request = null;
		try {
			request = IdentifyRequest.parseFrom(req.getInputStream());
		} catch (Exception ex) {
			writeErrorToResponse(req, res, HttpStatus.SC_BAD_REQUEST,
					ex.getMessage(), ex);
			return;
		}

		if (log.isDebugEnabled()) {
			log.debug("ready to call inquiry with parameter PBInquiryJobRequest..");
		}
		IdentifyResponse response = null;
		try {
			response = inquiryService.inquiry(request, true);
			AimWebManager.addToExtractJobResQueue(response.getJobId(), asyncContext);
		} catch (Exception ex) {
			handleException(ex, req, res, IdentifyResponse.newBuilder());
			return;
		}

		if (log.isDebugEnabled()) {
			log.debug("ready to Serial the PBInquiryJobResponse and write into outputstream..");
		}
		response.writeTo(res.getOutputStream());
		res.setStatus(HttpStatus.SC_OK);
	}


	/**
	 * doDeleteJob
	 * 
	 * @param req
	 * @param res
	 * @throws IOException
	 */
	private void doDeleteJob(final HttpServletRequest req,
			final HttpServletResponse res) throws IOException {
		if (isContextSizeEmpty(req)) {
			writeErrorToResponse(req, res, HttpStatus.SC_BAD_REQUEST,
					EMPTY_REQUEST_MSG, null);
			return;
		}

		if (log.isDebugEnabled()) {
			log.debug("ready to deSerial from inputStream..");
		}
		PBDeleteJobRequest request = null;
		try {
			request = PBDeleteJobRequest.parseFrom(req.getInputStream());
		} catch (Exception ex) {
			writeErrorToResponse(req, res, HttpStatus.SC_BAD_REQUEST,
					ex.getMessage(), ex);
			return;
		}

		if (log.isDebugEnabled()) {
			log.debug("ready to call deleteJob with parameter PBDeleteJobRequest..");
		}
		try {
			inquiryService.deleteJob(request);
		} catch (Exception ex) {
			handleException(ex, req, res, null);
			return;
		}

		res.setStatus(HttpStatus.SC_OK);
	}

	/**
	 * doClearJobs
	 * 
	 * @param req
	 * @param res
	 */
	private void doClearJobs(final HttpServletRequest req,
			final HttpServletResponse res) {
		if (log.isDebugEnabled()) {
			log.debug("ready to call clearJobs..");
		}
		try {
			inquiryService.clearJobs();
		} catch (Exception ex) {
			writeErrorToResponse(req, res, HttpStatus.SC_INTERNAL_SERVER_ERROR,
					ex.getMessage(), ex);
			return;
		}
	}
}
