package com.nec.lmx.agent.lmx;

import java.util.concurrent.ConcurrentHashMap;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.xformation.lmx.LmxStatus;

public class FloatingLicenseManagerTest {
	private final ConcurrentHashMap<String, String> licenseMap = new ConcurrentHashMap<>();
	private static final String VALID = "VALID";
	private static String ERR_MESSAGE = "ERR_MESSAGE";
	private static String ERR_CODE = "ERR_CODE";

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testSendLicenseInfo() {
		licenseMap.put("AFIS", "TYPE=FULL;COMPONENT=VM;MODALTY=FINGER,FACE,PALM,IRIS");
		licenseMap.put("VALID", "TRUE");
		sendLicenseInfo();
	}
	
	@Test
	public void testSendErrorInfo() {
		StringBuilder sb = new StringBuilder();	
		sb.append(VALID);
		sb.append("=");
		sb.append("FALSE");
		sb.append(";");
		sb.append(ERR_MESSAGE);
		sb.append("=");
		sb.append("mockError");	
		sb.append(";");
		sb.append(ERR_CODE);
		sb.append("=");
		sb.append(String.format("%s",LmxStatus.LMX_BAD_DATE));		
		System.out.println(sb.toString());
	}
	
	@Test
	public void testBuilderSendString() {
		licenseMap.put("AFIS", "TYPE=FULL;COMPONENT=VM;MODALTY=FINGER,FACE,PALM,IRIS");
		licenseMap.put("EXPIRED", "false");
		String option = licenseMap.get("AFIS");
		String expired = licenseMap.get("EXPIRED");
		StringBuilder sb = new StringBuilder();
		sb.append(option);
		sb.append(";");
		sb.append("EXPIRED");
		sb.append("=");
		sb.append(expired);	
		System.out.println(sb.toString());
	}
	
	private void sendLicenseInfo() {		
		String option = licenseMap.get("AFIS");
		String vaild = licenseMap.get(VALID);		
		StringBuilder sb = new StringBuilder();		
		sb.append(option);
		sb.append(";");
		sb.append(VALID);
		sb.append("=");
		sb.append(vaild);
		System.out.println(sb.toString());	
	}
	

}
