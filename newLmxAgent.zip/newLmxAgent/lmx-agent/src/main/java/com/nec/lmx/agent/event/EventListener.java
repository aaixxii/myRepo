package com.nec.lmx.agent.event;

/**
 * @author xiazp <br/>
 *  EventListener handler event while some thing happened
 */
public interface EventListener {
	public void onMessage(String msg);	
	public void onError(String error);
	public void onStop() ;
}