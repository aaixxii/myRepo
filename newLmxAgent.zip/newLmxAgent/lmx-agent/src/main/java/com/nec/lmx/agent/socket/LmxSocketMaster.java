package com.nec.lmx.agent.socket;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Objects;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.lmx.agent.lmx.LicenseManager;

/**
 * @author xiazp
 *
 */
public class LmxSocketMaster implements Runnable {
	private Selector selector;
	private SocketChannel socketChannel;
	private static Logger logger = LoggerFactory.getLogger(LmxSocketMaster.class);
	private boolean stop = false;
	private int socketTimeout = 5 * 1000;	
	private LicenseManager licenseManager = LicenseManager.getInstance();
	
	private final static int WRITTING_LATENCY = 5 * 1000;//ms
	
	/**
	 * @param port
	 */
	public LmxSocketMaster(int port) {
		try {			
			InetSocketAddress hostAddress = new InetSocketAddress("localhost", port);
			socketChannel = SocketChannel.open(hostAddress);
			socketChannel.configureBlocking(false);
			socketChannel.socket().setReuseAddress(true);
			socketChannel.socket().setKeepAlive(true);
			socketChannel.socket().setSoTimeout(socketTimeout);
			selector = Selector.open();
			socketChannel.register(selector, SelectionKey.OP_WRITE);
			LmxSocketSender.getInstance().init(socketChannel);
			logger.info(
					"Connected to " + socketChannel.socket().getInetAddress() + ":" + socketChannel.socket().getPort());				

		} catch (IOException e) {
			logger.error(e.getMessage(), e);
			System.exit(1);
		}
	}

	/* (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	@Override
	public void run() {
		SelectionKey key = null;
		try {
			while (selector.select() > 0 && !stop) {			
				Set<SelectionKey> keys = selector.selectedKeys();
				Iterator<SelectionKey> keyIterator = keys.iterator();
				while (keyIterator.hasNext()) {
					key = (SelectionKey) keyIterator.next();
					keyIterator.remove();
					if (!key.isValid()) {
						continue;
					}
				}
				 if (key.isWritable()) {
					 SocketChannel myClient = (SocketChannel) key.channel();
					if (isServerClosed(myClient.socket())) {
						stop = true;
						logger.error("Socket Channl may be Closed!");
						LmxSocketSender.getInstance().onStop();
					} else {
						String license = licenseManager.pollLastLicense();
						if (!Objects.isNull(license)) {
							LmxSocketSender.getInstance().onMessage(license);
						}
					}
				 }
				try {
					Thread.sleep(WRITTING_LATENCY);
				} catch (InterruptedException e) {
					logger.error(e.getMessage(), e);
				}
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			try {
				if (key != null) {
					key.cancel();
					key.channel().close();	
					logger.info("LmxAgent exit!!");
					System.exit(1);
				}
			} catch (Exception ex) {
				logger.error(e.getMessage(), e);
			}
		}
	}
	
	private boolean isServerClosed(Socket socket) {
		try {
			socket.sendUrgentData(0);
			return false;
		} catch (IOException e) {
			return true;
		}		
	}

}
