package com.nec.lmx.agent.socket;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.SocketChannel;
import java.text.ParseException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.lmx.agent.event.EventListener;
import com.nec.lmx.agent.lmx.LicenseManager;

/**
 * @author xiazp
 *
 */
class LmxSocketSender implements EventListener {
	private static final int BUFF_SIZE = 512;
	private ByteBuffer sendBuff;
	private SocketChannel socketChannel;
	private Object channelLocker;

	private static Logger logger = LoggerFactory.getLogger(LmxSocketSender.class);
	
	private static final LmxSocketSender INSTANCE = new LmxSocketSender();
	public static LmxSocketSender getInstance() {
		return INSTANCE;
	}	
	
	public LmxSocketSender() {	
		this.channelLocker = new Object();
		sendBuff = ByteBuffer.allocate(BUFF_SIZE);		
	}	

	/**
	* @param str
	* @return 
	* @throws ParseException
	*/
	public void init(SocketChannel socketChannel) {
		this.socketChannel = socketChannel;			
		logger.info("LmxSocketSender succss started!");		
	}

	/* (non-Javadoc)
	 * @see com.nec.lmx.agent.event.EventListener#onMessage(java.lang.String)
	 */
	@Override
	public void onMessage(String msg) {
		sendLinceseInfo(msg);
	}

	/* (non-Javadoc)
	 * @see com.nec.lmx.agent.event.EventListener#onStop()
	 */
	@Override
	public void onStop()  {
		LicenseManager.getInstance().cleanAllLmxResource();		
			try {
				socketChannel.close();				
				logger.info("LmxAgent stoped!");
				System.exit(0);
			} catch (IOException e) {
				logger.error(e.getMessage(), e);
				System.exit(1);
			}
		
	}

	/* (non-Javadoc)
	 * @see com.nec.lmx.agent.event.EventListener#onError(java.lang.String)
	 */
	@Override
	public void onError(String error) {
		sendLinceseInfo(error);
	}

	/**
	* @param str
	* @return 
	* @throws ParseException
	*/
	private void sendLinceseInfo(String licenseInfo) {
		int sendSize = 0;
		try {
			byte[] bodys = licenseInfo.getBytes("UTF-8");
			// int sizeOfBody = bodys.length;
			sendBuff.clear();
			sendBuff.order(ByteOrder.BIG_ENDIAN);
			sendBuff.put(bodys);
			sendBuff.flip();
			synchronized (channelLocker) {
				while (sendBuff.hasRemaining()) {
					sendSize = socketChannel.write(sendBuff);
					logger.info("Send data size = {}", sendSize);
				}
			}
			sendBuff.clear();
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
	}
	
	
	@SuppressWarnings("unused")
	private static void sendTestMessge() {
		String option = "TYPE=FULL;COMPONENT=MM;MODALTY=FINGER,FACE,PALM,IRIS";
		String VALID = "VALID";			
		StringBuilder sb = new StringBuilder();		
		sb.append(option);
		sb.append(";");
		sb.append(VALID);
		sb.append("=");
		sb.append("TRUE");
		LmxSocketSender.getInstance().onMessage(sb.toString().trim());	
	}	
}
