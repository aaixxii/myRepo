package jp.co.nec.aim.dm.manager;

import java.io.ByteArrayInputStream;
import java.util.LinkedHashMap;
import java.util.Map;

public class SegmentFileCache {
	private static final int MAX_ENTRIES = 20;
	private LinkedHashMap<Integer, ByteArrayInputStream> lruMap = new LinkedHashMap<Integer, ByteArrayInputStream>(
			MAX_ENTRIES, .75F, true) {
		/**
		 * 
		 */
		private static final long serialVersionUID = -1255483822242601420L;

		protected boolean removeEldestEntry(
				Map.Entry<Integer, ByteArrayInputStream> eldest) {
			return size() > MAX_ENTRIES;
		}

	};

	public synchronized void insertSegmentFile(Integer key,
			ByteArrayInputStream value) {
		lruMap.put(key, value);
	}

	public synchronized ByteArrayInputStream getSegmentFile(Integer key) {
		return lruMap.get(key);
	}

	public String toString() {
		// TODO Auto-generated method stub
		return lruMap.toString();
	}

}
