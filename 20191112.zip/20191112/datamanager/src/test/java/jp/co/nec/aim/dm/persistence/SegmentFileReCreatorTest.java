package jp.co.nec.aim.dm.persistence;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;

import javax.annotation.Resource;

import jp.co.nec.aim.dm.domain.SegmentFileName;
import jp.co.nec.aim.dm.util.SegmentUtil;
import jp.co.nec.aim.helper.SegmentFileConstants;

import org.apache.commons.io.FileUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

/**
 * Test class for SegmentFileCreator
 * 
 * @author kurosu
 * 
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class SegmentFileReCreatorTest {
	@Resource
	private JdbcTemplate jdbcTemplate;
	@Resource
	private SegmentFileReCreator segmentFileReCreator;
	@Resource
	private SegmentFileCreator segmentFileCreator;

	@Before
	public void before() {
		jdbcTemplate.execute("delete from segments");
		jdbcTemplate.execute("delete from person_biometrics");
		SegmentUtil.createDir();
	}

	@After
	public void after() {
		SegmentUtil.cleanSegmentFile();
	}

	@Test
	public void testExecute() throws IOException {
		createNewSegment();

		int unit = 40;
		int templateSize = 100;
		int version = 2001;

		int segmentId;
		for (segmentId = 1; segmentId <= 5; segmentId++) {
			segmentFileReCreator.execute(segmentId, version);
			checkSegmentFile(segmentId, unit, templateSize);
		}
	}

	/**
	 * createNewSegment
	 * 
	 * @throws IOException
	 */
	private void createNewSegment() throws IOException {
		int records = 200;
		int unit = 40;
		int templateSize = 100;

		SegmentUtil.insertSegmentRecords(records, unit, templateSize,
				jdbcTemplate);

		int version = 1;

		int segmentId;
		for (segmentId = 1; segmentId <= 5; segmentId++) {
			segmentFileCreator.execute(segmentId, version);
		}

	}

	private void checkSegmentFile(int segmentId, int records, int templateSize)
			throws IOException {
		SegmentFileName segFileName = new SegmentFileName(segmentId);
		File segFile = new File(segFileName.getName());
		assertTrue(segFile.exists());
		byte[] contents = FileUtils.readFileToByteArray(segFile);
		ByteBuffer bb = ByteBuffer.wrap(contents);
		assertEquals(SegmentFileCreator.AIM_VERSION, bb.getInt());
		assertEquals((short) 1, bb.getShort()); // EMBEDDED_ID
		assertEquals(20000000L, bb.getLong()); // MAX_SEGMENT_SIZE
		assertEquals(records, bb.getInt()); // RECORD_COUNT
		assertEquals((long) (records-1), bb.getLong()); // VERSION
		assertEquals(SegmentFileConstants.SEGMENT_HEADER_SIZE + records
				* (templateSize + SegmentFileConstants.SIZE_TEMPLATE_HEADER_CHECKSUM),
				contents.length);
	}

}