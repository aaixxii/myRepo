package jp.co.nec.aim.dm.comm;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.URL;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.nec.aim.dm.constants.SegmentStatusValue;
import jp.co.nec.aim.dm.manager.SegmentFileManager;
import jp.co.nec.aim.dm.manager.SegmentFileState;
import jp.co.nec.aim.dm.properties.Version;
import jp.co.nec.aim.dm.util.HttpTestServer;
import jp.co.nec.aim.dm.util.SegFileUtil;
import jp.co.nec.aim.message.proto.AIMEnumTypes.SegmentAssignedStateType;
import jp.co.nec.aim.message.proto.AIMEnumTypes.SegmentSyncCommandType;
import jp.co.nec.aim.message.proto.AIMMessages.PBAbilityInfo;
import jp.co.nec.aim.message.proto.AIMMessages.PBComponentInfo;
import jp.co.nec.aim.message.proto.AIMMessages.PBEnterResponse;
import jp.co.nec.aim.message.proto.AIMMessages.PBHeartBeatResponse;
import jp.co.nec.aim.message.proto.AIMMessages.PBResourceInfo;
import jp.co.nec.aim.message.proto.AIMMessages.PBSegmentCatchUpInfo;
import jp.co.nec.aim.message.proto.AIMMessages.PBSegmentCatchUpItem;
import jp.co.nec.aim.message.proto.AIMMessages.PBSegmentSyncInfo;
import jp.co.nec.aim.message.proto.AIMMessages.PBSegmentSyncItem;
import mockit.Mock;
import mockit.MockUp;

import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mortbay.jetty.Handler;
import org.mortbay.jetty.HttpConnection;
import org.mortbay.jetty.Request;
import org.mortbay.jetty.handler.AbstractHandler;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

/**
 * CommunicationThread workFlow Test
 * 
 * @author liuyq
 * 
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class CommunicationThreadTest extends
		AbstractTransactionalJUnit4SpringContextTests {

	@Resource
	private JdbcTemplate jdbcTemplate;
	
	MockUp<Version> mocked;
	MockUp<SegmentFileState> mocked1;
	

	/**
	 * setMockMethod
	 */
	private void setMockMethod() {
		mocked = new MockUp<Version>() {
			@Mock
			public String getVersion() {
				return "5.4.0";
			}
		};

		 mocked1 = new MockUp<SegmentFileState>() {
			@Mock
			public SegmentStatusValue decideStatusValue() {
				return SegmentStatusValue.ON_DISK;
			}
		};
	}

	@Test
	@Ignore
	public void testDm_communication_workflow() throws Exception {
		HttpTestServer server = null;
		DatagramSocket dSocket = null;
		CommunicationThread worker = null;
		setMockMethod();
		try {
			URL url = this.getClass().getResource("insert-sync-record.sql");
			executeSqlScript("file:///" + url.getPath(), false);
			jdbcTemplate.execute("commit");

			// SegmentFileManager.getInstance().scheduleWrite(1,
			// SegmentAssignedStateType.SEGMENT_ASSIGNED);
			// SegmentFileManager.getInstance().scheduleWrite(2,
			// SegmentAssignedStateType.SEGMENT_ASSIGNED);
			// SegmentFileManager.getInstance().scheduleWrite(3,
			// SegmentAssignedStateType.SEGMENT_ASSIGNED);

			SegmentFileManager.getInstance().scheduleWrite(1, 5);
			SegmentFileManager.getInstance().scheduleWrite(2, 4);
			SegmentFileManager.getInstance().scheduleWrite(3, 3);
			SegmentFileManager.getInstance().scheduleWrite(4, 2);

			worker = new CommunicationThread();
			Thread t = new Thread(worker);
			t.setDaemon(true);

			server = new HttpTestServer(65521);
			server.start(getMockHandler(t, false));

			t.start();
			Thread.sleep(5000);

			final byte[] msg = "1,2,3,4".getBytes();
			dSocket = new DatagramSocket();
			dSocket.setBroadcast(true);
			dSocket.setSendBufferSize(msg.length);
			dSocket.setSoTimeout(500);
			dSocket.setReuseAddress(false);
			DatagramPacket msgPacket = new DatagramPacket(msg, msg.length,
					new InetSocketAddress("127.0.0.1", 1234));
			dSocket.send(msgPacket);
			Thread.sleep(1000000);

		} catch (Exception e) {
			throw e;
		} finally {
			if (dSocket != null) {
				dSocket.close();
			}
			if (worker != null) {
				worker.releaseWakeup();
			}

			// Thread.sleep(1000);

			if (server != null) {
				server.stop();
			}

			SegmentFileManager.getInstance().clear();
			SegFileUtil.removeIndexAndSegment();
			mocked.tearDown();
			mocked1.tearDown();			
		}
	}

	@Test
	@Ignore
	public void testDm_communication_workflow_reenter() throws Exception {
		HttpTestServer server = null;
		DatagramSocket dSocket = null;
		CommunicationThread worker = null;
		setMockMethod();
		try {
			URL url = this.getClass().getResource("insert-sync-record.sql");
			executeSqlScript("file:///" + url.getPath(), false);
			jdbcTemplate.execute("commit");

			// SegmentFileManager.getInstance().scheduleWrite(1,
			// SegmentAssignedStateType.SEGMENT_ASSIGNED);
			// SegmentFileManager.getInstance().scheduleWrite(2,
			// SegmentAssignedStateType.SEGMENT_ASSIGNED);
			// SegmentFileManager.getInstance().scheduleWrite(3,
			// SegmentAssignedStateType.SEGMENT_ASSIGNED);
			// SegmentFileManager.getInstance().scheduleWrite(4,
			// SegmentAssignedStateType.SEGMENT_ASSIGNED);

			SegmentFileManager.getInstance().scheduleWrite(1, 5);
			SegmentFileManager.getInstance().scheduleWrite(2, 4);
			SegmentFileManager.getInstance().scheduleWrite(3, 3);
			SegmentFileManager.getInstance().scheduleWrite(4, 2);

			worker = new CommunicationThread();
			Thread t = new Thread(worker);
			t.setDaemon(true);

			server = new HttpTestServer(65521);
			server.start(getMockHandler(t, true));

			t.start();

			Thread.sleep(5000);

			final byte[] msg = "1,2,3,4".getBytes();
			dSocket = new DatagramSocket();
			dSocket.setBroadcast(true);
			dSocket.setSendBufferSize(msg.length);
			dSocket.setSoTimeout(500);
			dSocket.setReuseAddress(false);
			DatagramPacket msgPacket = new DatagramPacket(msg, msg.length,
					new InetSocketAddress("127.0.0.1", 1234));
			dSocket.send(msgPacket);
			Thread.sleep(10000);

		} catch (Exception e) {
			throw e;
		} finally {
			if (dSocket != null) {
				dSocket.close();
			}
			if (worker != null) {
				worker.releaseWakeup();
			}

			// Thread.sleep(1000);

			if (server != null) {
				server.stop();
			}

			SegmentFileManager.getInstance().clear();
			SegFileUtil.removeIndexAndSegment();
			mocked.tearDown();
			mocked1.tearDown();				
		}
	}

	/**
	 * getMockHandler
	 * 
	 * @return Handler
	 */
	public Handler getMockHandler(final Thread t, final boolean wrongState) {
		Handler handler = new AbstractHandler() {
			public void handle(String target, HttpServletRequest request,
					HttpServletResponse response, int dispatch)
					throws IOException, ServletException {
				Request baseRequest = request instanceof Request ? (Request) request
						: HttpConnection.getCurrentConnection().getRequest();

				String url = baseRequest.getRequestURI();
				System.out.println(url);
				if (url.equalsIgnoreCase("/matchmanager/Enter")) {
					PBComponentInfo info = PBComponentInfo.parseFrom(request
							.getInputStream());
					System.out.println(info);

					Assert.assertEquals("DATA_MANAGER", info.getComponent()
							.name());
					Assert.assertEquals("5.0.0", info.getVersion());
					Assert.assertEquals("DM:10.4.0.182", info.getUniqueId());
					Assert.assertEquals("http://10.4.0.182:8080/datamanager",
							info.getContactUrl());

					Assert.assertTrue(info.hasResourceInfo());
					PBResourceInfo resourceInfo = info.getResourceInfo();

					Assert.assertTrue(resourceInfo.hasAbilityInfo());
					PBAbilityInfo abilityInfo = resourceInfo.getAbilityInfo();

					Assert.assertEquals(0L, abilityInfo.getPrimarySize());
					Assert.assertEquals(0L, abilityInfo.getSecondarySize());
					Assert.assertEquals(4, resourceInfo.getSegmentInfoCount());

					PBEnterResponse.Builder b = PBEnterResponse.newBuilder();
					b.setId(1).setWakeUpNotifyPort(1234);

					b.addSegmentUpdates(PBSegmentSyncInfo
							.newBuilder()
							.setAssignedState(
									SegmentAssignedStateType.SEGMENT_ASSIGNED)
							.setId(1L)
							.setSyncItem(
									PBSegmentSyncItem
											.newBuilder()
											.setCatUpInfo(
													PBSegmentCatchUpInfo
															.newBuilder()
															.addCatchUpItems(
																	PBSegmentCatchUpItem
																			.newBuilder()
																			.setVersion(
																					6)
																			.setCommand(
																					SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT)
																			.setTemplateId(
																					6))
															.addCatchUpItems(
																	PBSegmentCatchUpItem
																			.newBuilder()
																			.setVersion(
																					7)
																			.setCommand(
																					SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT)
																			.setTemplateId(
																					7)))));

					b.addSegmentUpdates(PBSegmentSyncInfo
							.newBuilder()
							.setAssignedState(
									SegmentAssignedStateType.SEGMENT_ASSIGNED)
							.setId(2L)
							.setSyncItem(
									PBSegmentSyncItem
											.newBuilder()
											.setCatUpInfo(
													PBSegmentCatchUpInfo
															.newBuilder()
															.addCatchUpItems(
																	PBSegmentCatchUpItem
																			.newBuilder()
																			.setVersion(
																					5)
																			.setCommand(
																					SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT)
																			.setTemplateId(
																					5))
															.addCatchUpItems(
																	PBSegmentCatchUpItem
																			.newBuilder()
																			.setVersion(
																					6)
																			.setCommand(
																					SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT)
																			.setTemplateId(
																					6)))));

					b.addSegmentUpdates(PBSegmentSyncInfo
							.newBuilder()
							.setAssignedState(
									SegmentAssignedStateType.SEGMENT_ASSIGNED)
							.setId(3L)
							.setSyncItem(
									PBSegmentSyncItem
											.newBuilder()
											.setCatUpInfo(
													PBSegmentCatchUpInfo
															.newBuilder()
															.addCatchUpItems(
																	PBSegmentCatchUpItem
																			.newBuilder()
																			.setVersion(
																					4)
																			.setCommand(
																					SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT)
																			.setTemplateId(
																					4))
															.addCatchUpItems(
																	PBSegmentCatchUpItem
																			.newBuilder()
																			.setVersion(
																					5)
																			.setCommand(
																					SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT)
																			.setTemplateId(
																					5)))));

					System.out.println(b.toString());
					b.build().writeTo(response.getOutputStream());

					// t.interrupt();

				} else if (url.equalsIgnoreCase("/matchmanager/HeartBeat")) {
					PBComponentInfo info = PBComponentInfo.parseFrom(request
							.getInputStream());

					System.out.println(info);

					PBHeartBeatResponse.Builder b = PBHeartBeatResponse
							.newBuilder().setWrongState(wrongState);

					b.addSegmentUpdates(PBSegmentSyncInfo
							.newBuilder()
							.setAssignedState(
									SegmentAssignedStateType.SEGMENT_ASSIGNED)
							.setId(1L)
							.setSyncItem(
									PBSegmentSyncItem
											.newBuilder()
											.setCatUpInfo(
													PBSegmentCatchUpInfo
															.newBuilder()
															.addCatchUpItems(
																	PBSegmentCatchUpItem
																			.newBuilder()
																			.setVersion(
																					8)
																			.setCommand(
																					SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT)
																			.setTemplateId(
																					8)))));

					b.addSegmentUpdates(PBSegmentSyncInfo
							.newBuilder()
							.setAssignedState(
									SegmentAssignedStateType.SEGMENT_ASSIGNED)
							.setId(2L)
							.setSyncItem(
									PBSegmentSyncItem
											.newBuilder()
											.setCatUpInfo(
													PBSegmentCatchUpInfo
															.newBuilder()
															.addCatchUpItems(
																	PBSegmentCatchUpItem
																			.newBuilder()
																			.setVersion(
																					7)
																			.setCommand(
																					SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT)
																			.setTemplateId(
																					7)))));
					b.addSegmentUpdates(PBSegmentSyncInfo
							.newBuilder()
							.setAssignedState(
									SegmentAssignedStateType.SEGMENT_ASSIGNED)
							.setId(3L)
							.setSyncItem(
									PBSegmentSyncItem
											.newBuilder()
											.setCatUpInfo(
													PBSegmentCatchUpInfo
															.newBuilder()
															.addCatchUpItems(
																	PBSegmentCatchUpItem
																			.newBuilder()
																			.setVersion(
																					6)
																			.setCommand(
																					SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT)
																			.setTemplateId(
																					6)))));
					System.out.println(b.toString());
					b.build().writeTo(response.getOutputStream());

					// t.interrupt();

				} else {
					System.out.println("!!!!!!!!WARNNING!!!!!!!!!");
				}
				response.setStatus(200);
				response.setContentType("application/octet-stream");
				response.setCharacterEncoding("UTF-8");
				baseRequest.setHandled(true);
			}
		};
		return handler;
	}
	// private static AtomicBoolean isHeartBeat = new AtomicBoolean(false);
}
