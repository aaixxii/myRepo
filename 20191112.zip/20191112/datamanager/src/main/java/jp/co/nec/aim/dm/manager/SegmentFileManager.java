package jp.co.nec.aim.dm.manager;

import java.util.ArrayList;
import java.util.Collection;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import jp.co.nec.aim.dm.comm.CommunicationThread;
import jp.co.nec.aim.dm.exception.DataManagerException;
import jp.co.nec.aim.dm.persistence.SegmentFileWritingJob;
import jp.co.nec.aim.dm.properties.DynamicProperties;
import jp.co.nec.aim.dm.properties.DynamicPropertyNames;
import jp.co.nec.aim.dm.util.SumFileUtil;
import jp.co.nec.aim.message.proto.AIMEnumTypes.SegmentAssignedStateType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

public class SegmentFileManager {

	private static final Logger log = LoggerFactory
			.getLogger(SegmentFileManager.class);
	private static final SegmentFileManager INSTANCE = new SegmentFileManager();

	// internal state.
	private final ConcurrentHashMap<Integer, SegmentFileState> segFileStatesMap;
	private final ThreadPoolExecutor writeThreadPool;
	private Future<?> commThreadFuture;
	private CommunicationThread ct;
	private final int numDeletesAfterCompaction;
	/** Spring Application Context field */
	private ApplicationContext appContext;
	private JdbcTemplate jdbcTemplate;

	private SegmentFileManager() {
		writeThreadPool = buildThreadPoolExecutor();
		numDeletesAfterCompaction = Integer.parseInt(DynamicProperties
				.getInstance().getPropertyValue(
						DynamicPropertyNames.NUM_DELETES_SEGMENTFILE));
		appContext = new ClassPathXmlApplicationContext(
				"applicationContext.xml");
		jdbcTemplate = (JdbcTemplate) appContext.getBean("jdbcTemplate");
		SumFileUtil.removeSumAndSegment();
		segFileStatesMap = SegmentFileInventory.initializeSegFileStates();
		log.info("Datamanager finished initializing segment files from disk");
	}

	private ThreadPoolExecutor buildThreadPoolExecutor() {
		int corePoolSize = Integer.parseInt(DynamicProperties.getInstance()
				.getPropertyValue(DynamicPropertyNames.NUM_WRITE_THREADS));
		int maximumPoolSize = corePoolSize;
		long keepAliveTime = Long.MAX_VALUE;
		TimeUnit unit = TimeUnit.NANOSECONDS;
		BlockingQueue<Runnable> workQueue = new LinkedBlockingQueue<Runnable>();
		return new ThreadPoolExecutor(corePoolSize, maximumPoolSize,
				keepAliveTime, unit, workQueue);
	}

	public static SegmentFileManager getInstance() {
		return INSTANCE;
	}

	// starts communication thread.
	// called once at app load time.
	public void startCommucationThread() {
		try {
			ExecutorService commThreadPool = Executors
					.newSingleThreadExecutor();
			ct = new CommunicationThread();
			commThreadFuture = commThreadPool.submit(ct);
		} catch (RejectedExecutionException e) {
			throw new DataManagerException("Thread Initialization Error", e);
		}
	}

	// public CommunicationThreadView getCommThreadView() {
	// return ct.getSnapshot();
	// }

	// Called by:
	// (1) Communication Thread
	// (2) HTTP threads
	// (Write threads are constructed with references to the SegmentState
	// objects they will be altering.)
	public SegmentFileState getState(Integer segmentId) {
		return segFileStatesMap.get(segmentId);
	}

	// /////////////////////////////////////////////////////////////////////////////////////
	// QUEUE SEGMENT ACTION COMMANDS : NO-OPs if UNNECESSARY
	// //////////////////////////////
	// /////////////////////////////////////////////////////////////////////////////////////

	// Called by Communication Thread in response to MM commands.

	public void scheduleWrite(Integer segmentId, Integer serverVersion) {
		SegmentFileState state = getState(segmentId);

		if (state == null) {
			state = SegmentFileState.newInstance(segmentId, null);
			log.debug("Adding hashmap entry: " + segmentId + " -> "
					+ state.toString());
			segFileStatesMap.put(segmentId, state);
		}
		synchronized (state) {
			SegmentFileWritingJob job = new SegmentFileWritingJob(state);
			boolean needNewThread = state.scheduleWriteIfNecessary(job,
					serverVersion);
			if (needNewThread) {
				try {
					writeThreadPool.submit(job);
				} catch (RejectedExecutionException e) {
					log.error(
							"Caught RejectedExecutionException --> About to unset write action",
							e);
					state.unsetWriteAction();
				}
			} else {
			}
		}
	}

	public void scheduleWrite(Integer segmentId,
			SegmentAssignedStateType assignType) {
		SegmentFileState state = segFileStatesMap.putIfAbsent(segmentId,
				SegmentFileState.newInstance(segmentId, null));

		if (state == null) {
			state = segFileStatesMap.get(segmentId);
		}
		
		Integer serverVersion = null;
		switch (assignType) {
		case SEGMENT_ASSIGNED:
			try {
				serverVersion = jdbcTemplate.queryForInt(
						"select VERSION from SEGMENTS where SEGMENT_ID = ?",
						segmentId);
			} catch (Exception e) {
				throw new DataManagerException(
						"Could not find segment version by id:" + segmentId);
			}
			break;
		case SEGMENT_UNASSIGNED:
			log.debug("Segment Action from MM: UNASSIGN " + segmentId);
			break;
		case SEGMENT_DEFUNCT:
			log.debug("Segment Action from MM: DEFUNCT " + segmentId);
			break;
		default:
			assert false : "Unexpected SegmentUpdateItem serverStatus: "
					+ assignType;
		}
		synchronized (state) {
			SegmentFileWritingJob job = new SegmentFileWritingJob(state);
			boolean needNewThread = state.scheduleWriteIfNecessary(job,
					serverVersion);
			if (needNewThread) {
				try {
					writeThreadPool.submit(job);
				} catch (RejectedExecutionException e) {
					log.error(
							"Caught RejectedExecutionException --> About to unset write action",
							e);
					state.unsetWriteAction();
				}
			} else {
			}
		}
	}

	/**
	 * Methods to get some useful metrics
	 */
	public int getActiveCount() {
		return writeThreadPool.getActiveCount();
	}

	public long getCompletedTaskCount() {
		return writeThreadPool.getCompletedTaskCount();
	}

	public long getTaskCount() {
		return writeThreadPool.getTaskCount();
	}

	public int getWorkQueueSize() {
		return writeThreadPool.getQueue().size();
	}

	public Collection<SegmentFileStateSnapshot> getSegmentFilesNeedingCompaction() {
		Collection<SegmentFileStateSnapshot> results = new ArrayList<SegmentFileStateSnapshot>();
		for (SegmentFileStateSnapshot snapShot : getSnapshots()) {
			if (snapShot.getDeletesAfterSegmentation() > numDeletesAfterCompaction) {
				results.add(snapShot);
			}
		}
		return results;
	}

	// Called by Communication Thread to generate segment report.
	// READ-ONLY
	public Collection<SegmentFileStateSnapshot> getSnapshots() {
		Collection<SegmentFileStateSnapshot> result = new ArrayList<SegmentFileStateSnapshot>();
		for (SegmentFileState state : segFileStatesMap.values()) {
			result.add(state.getSnapShot());
		}
		return result;
	}

	public void shutdown() {
		log.info("Shutdown() called on SegmentFileManager");
		writeThreadPool.shutdownNow();
		commThreadFuture.cancel(true);
		ct.sendExit();
		// release wake up related resource
		ct.releaseWakeup();
	}

	public int getMapSize() {
		return segFileStatesMap.size();
	}

	public void clear() {
		segFileStatesMap.clear();
	}

	public ApplicationContext getAppContext() {
		return appContext;
	}

}
