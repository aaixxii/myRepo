package jp.co.nec.aim.dm.procedure;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import jp.co.nec.aim.dm.log.LogConstants;
import jp.co.nec.aim.dm.log.PerformanceLogger;
import jp.co.nec.aim.dm.persistence.SegmentInfo;
import jp.co.nec.aim.dm.util.StopWatch;
import oracle.jdbc.OracleTypes;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

/**
 * Class to call download_segment_data procedure.
 * 
 * @author kurosu
 * 
 */
public class DownloadSegmentDataProcedure extends StoredProcedure {

	private static final String SQL = "DATA_MANAGER_API.download_segment_data";
	/** max number of template to get from PERSON_BIOMETRICS */
	private long maxTemplates;
	private long segmentId;
	/** BIOMETRICS_ID to start download */
	private long startId = 1L;
	private long endId;

	public DownloadSegmentDataProcedure(DataSource dataSource, SegmentInfo segmentInfo, long maxTemplates) {
		if(segmentInfo == null) {
			throw new IllegalArgumentException("segmentInfo is null");
		}
		if(segmentInfo.getSegmentId() <= 0L) {
			throw new IllegalArgumentException("segmentInfo is "  +  segmentInfo.getSegmentId() + ", it must be positive");
		}

		this.maxTemplates = maxTemplates;
		this.segmentId = segmentInfo.getSegmentId();
		startId = segmentInfo.getBioIdStart();
		endId = segmentInfo.getBioIdEnd();
		setDataSource(dataSource);
		setSql(SQL);
		setFetchSize(10000);
		declareParameter(new SqlOutParameter("p_refcursor", OracleTypes.CURSOR, new SegmentMapper()));
		declareParameter(new SqlParameter("p_segment_id", Types.BIGINT));
		declareParameter(new SqlParameter("p_start_bio_id", Types.BIGINT));
		declareParameter(new SqlParameter("p_end_bio_id", Types.BIGINT));
		declareParameter(new SqlParameter("p_max_templates", Types.BIGINT));
		compile();
	}

	@SuppressWarnings("unchecked")
	public List<TemplateData> execute() {
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("p_segment_id", new Long(segmentId));
		map.put("p_start_bio_id", new Long(startId));
		map.put("p_end_bio_id", new Long(endId));
		map.put("p_max_templates", new Long(maxTemplates));
		Map<String, Object> resultMap = execute(map);
		List<TemplateData> segmentDataList = (List<TemplateData>) resultMap
				.get("p_refcursor");
		if (segmentDataList.size() != 0) {
			startId = segmentDataList.get(segmentDataList.size() - 1)
					.getBiometricsId() + 1L;
		}

		stopWatch.stop();
		PerformanceLogger.log(LogConstants.COMPONENT_DM, getClass()
				.getSimpleName(), LogConstants.FUNCTION_execute, stopWatch
				.elapsedTime());
		return segmentDataList;
	}

	private class SegmentMapper implements RowMapper<TemplateData> {

		@Override
		public TemplateData mapRow(ResultSet rs, int rowNum) throws SQLException {
			TemplateData segmentData = new TemplateData();
			segmentData.setBiometricsId(rs.getLong("BIOMETRICS_ID"));
			segmentData.setBiometricData(rs.getBytes("BIOMETRIC_DATA"));
			segmentData.setExternalId(rs.getString("EXTERNAL_ID"));
			segmentData.setEventId(rs.getInt("EVENT_ID"));
			return segmentData;
		}

	}

}
