package jp.co.nec.aim.dm.constants;

public enum SegmentStatusValue {
	IN_MEMORY(0), //
	ON_DISK(1), //
	CURRENTLY_DOWNLOADING(2), //
	QUEUED_FOR_DOWNLOAD(3), //
	NOT_REPORTED(null);

	private Integer val;

	private SegmentStatusValue(Integer val) {
		this.val = val;
	}

	public int getVal() {
		return val;
	}

	public boolean isStateAllowed() {
		return (this != NOT_REPORTED);
	}
}
