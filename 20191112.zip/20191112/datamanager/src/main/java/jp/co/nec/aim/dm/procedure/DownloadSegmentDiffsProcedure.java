package jp.co.nec.aim.dm.procedure;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import jp.co.nec.aim.dm.constants.DiffCommand;
import jp.co.nec.aim.dm.log.LogConstants;
import jp.co.nec.aim.dm.log.PerformanceLogger;
import jp.co.nec.aim.dm.util.StopWatch;
import oracle.jdbc.OracleTypes;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

/**
 * Class to call download_segment_diffs procedure.
 * 
 * @author kurosu
 * 
 */
public class DownloadSegmentDiffsProcedure extends StoredProcedure {

	private static final String SQL = "DATA_MANAGER_API.download_segment_diffs";
	private static final Logger log = LoggerFactory.getLogger(DownloadSegmentDiffsProcedure.class);

	public DownloadSegmentDiffsProcedure(DataSource dataSource) {
		setDataSource(dataSource);
		setSql(SQL);
		declareParameter(new SqlOutParameter("p_refcursor", OracleTypes.CURSOR,
				new SegmentDiffMapper()));
		declareParameter(new SqlParameter("p_segment_id", Types.BIGINT));
		declareParameter(new SqlParameter("p_current_segment_version",
				Types.BIGINT));
		compile();
	}

	@SuppressWarnings("unchecked")
	public List<SegmentDiffData> execute(long segmentId, long currentVersion) {
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		try {
			if (segmentId < 1L || currentVersion < 0L) {
				return new ArrayList<SegmentDiffData>();
			}
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("p_segment_id", new Long(segmentId));
			map.put("p_current_segment_version", new Long(currentVersion));
			Map<String, Object> resultMap = execute(map);
			return (List<SegmentDiffData>) resultMap.get("p_refcursor");
		} finally {
			stopWatch.stop();
			PerformanceLogger.log(LogConstants.COMPONENT_DM, getClass()
					.getSimpleName(), LogConstants.FUNCTION_execute, stopWatch
					.elapsedTime());
			log.info("It took {} msec to call " + SQL, stopWatch.elapsedTime());
		}
	}

	private class SegmentDiffMapper implements RowMapper<SegmentDiffData> {

		@Override
		public SegmentDiffData mapRow(ResultSet rs, int rowNum)
				throws SQLException {
			SegmentDiffData diffData = new SegmentDiffData();
			diffData.setVersion(rs.getInt("SEGMENT_VERSION"));
			diffData.setDiffCommand(DiffCommand.parseFromInt(rs
					.getInt("CHANGE_TYPE")));
			diffData.setTemplateId(rs.getLong("BIOMETRICS_ID"));
			diffData.setTemplate(rs.getBytes("BIOMETRIC_DATA"));
			diffData.setExternalId(rs.getString("EXTERNAL_ID"));
			diffData.setEventId(rs.getInt("EVENT_ID"));
			return diffData;
		}

	}

}
