package jp.co.nec.aim.dm.log;

public class LogConstants {
	public static final String COMPONENT_DM = "DM";
	public static final String FUNCTION_execute = "execute";
}
