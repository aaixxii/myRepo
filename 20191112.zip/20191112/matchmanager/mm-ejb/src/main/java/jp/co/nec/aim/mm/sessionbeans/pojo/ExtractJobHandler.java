package jp.co.nec.aim.mm.sessionbeans.pojo;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;

import com.google.protobuf.InvalidProtocolBufferException;

import jp.co.nec.aim.message.proto.AIMMessages.PBMuExtractJobResultItem;
import jp.co.nec.aim.message.proto.BatchTypeProto.BatchType;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBusinessMessage;
import jp.co.nec.aim.message.proto.BusinessMessage.PBResponse;
import jp.co.nec.aim.message.proto.BusinessMessage.PBResponseAttribute;
import jp.co.nec.aim.message.proto.BusinessMessage.PBTemplateInfo;
import jp.co.nec.aim.message.proto.ExtractService.ExtractResponse;
import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.dao.BatchJobInfoDao;
import jp.co.nec.aim.mm.dao.FEJobDao;
import jp.co.nec.aim.mm.entities.BatchJobInfoEntity;
import jp.co.nec.aim.mm.entities.FeJobPayloadEntity;
import jp.co.nec.aim.mm.entities.FeJobQueueEntity;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.exception.DataBaseException;
import jp.co.nec.aim.mm.logger.FeJobDoneLogger;
import jp.co.nec.aim.mm.procedure.FailExtractJobProcedure;
import jp.co.nec.aim.mm.procedure.FinishExtractJobProcedure;
import jp.co.nec.aim.mm.procedure.RetryExtractJobProcedure;

/**
 * @author mozj
 */

public class ExtractJobHandler {
	private static Logger log = LoggerFactory
			.getLogger(ExtractJobHandler.class);	
	private FEJobDao feJobDao;
	private BatchJobInfoDao batchjobDao;
	private DataSource dataSource;
	private FeJobDoneLogger feJobDoneLogger;
	

	/**
	 * Constructor is called by Java EE Container.
	 */
	public ExtractJobHandler(EntityManager entityManager,
			DataSource dataSource) {
		this.dataSource = dataSource;		
		this.feJobDao = new FEJobDao(entityManager);
		this.batchjobDao = new BatchJobInfoDao(entityManager);
		this.feJobDoneLogger = new FeJobDoneLogger(dataSource);
		
	}

	/**
	 * 
	 * @param eje
	 * @param muId
	 * @param reason
	 * @param timeout
	 * @param maxCount
	 */
	public int failExtractJob(FeJobQueueEntity eje, long muId,
			AimServiceState reason, boolean timeout, Integer maxCount) {
        log.warn("Extract job " + ((timeout) ? "or MU timedout" : "failure")
                + ": (muId " + eje.getMuId() + ") Extract Job ID " 
                + eje.getId() + " failed for reason: '" + reason.getErrorcode()
                + " : " + reason.getErrMsg() + "'");		

		Integer numFailures = (eje.getFailureCount() == null ? 0 : eje
				.getFailureCount().intValue());

		log.debug("Job " + eje.getId() + " has failed " + numFailures
				+ " times already.");

		if (numFailures >= maxCount - 1) {
			log.warn("Extract job id " + eje.getId()
					+ " failed too many times:" + (numFailures + 1)
					+ ", completing.");

			int numCompleted = 0;			
			try {
				ExtractResponse result = createPBExtractJobResult(eje.getId(),reason); //send errorRespose
				FailExtractJobProcedure failProcedure = new FailExtractJobProcedure(
						dataSource);
				numCompleted = failProcedure.execute(eje.getId(), muId, reason,result.toByteArray());
				if (0 < numCompleted) {
					feJobDoneLogger.info(eje.getId());
					AimManager.saveExtractClientJobResult(String.valueOf(eje.getId()), result);
					AimManager.finishExtractClientJob(String.valueOf(eje.getId()));	
				} else {
					log.warn("complete_extract_job called against nonexistent or already-complete extract job Id "
							+ eje.getId());
				}
						
			} catch (Exception ex) {
				String message = "DataAccessException when Failing Extract Job";
				log.error(message, ex);
				throw new AimRuntimeException(message, ex);
			}

	
			return numCompleted;
		} else {
			try {
				log.warn("Extract job id " + eje.getId() + " failed, retry.");
				RetryExtractJobProcedure retryProcedure = new RetryExtractJobProcedure(
						dataSource);
				return retryProcedure.execute(eje.getId(), muId, reason);
			} catch (DataAccessException ex) {
				String message = "DataAccessException when Retry Extract Job";
				log.error(message, ex);
				throw new AimRuntimeException(message, ex);
			}
		}
	}

	/**
	 * 
	 * @param reason
	 * @return
	 */
	private ExtractResponse createPBExtractJobResult(long jobId,
			AimServiceState reason) {
		ExtractResponse.Builder result = ExtractResponse.newBuilder();
		FeJobPayloadEntity payload = feJobDao.getFeJobPayload(jobId);		
		PBBusinessMessage pbMes = null;
		try {			
			pbMes = PBBusinessMessage.parseFrom(payload.getPayload());
		} catch (InvalidProtocolBufferException e) {
			throw new AimRuntimeException(e);
		}
		
		List<BatchJobInfoEntity> bacthInfo = batchjobDao.getBatchJobInfo(jobId);
		if (bacthInfo.isEmpty()) {		
			throw new DataBaseException(AimError.INTERNAL_ERROR.getErrorCode(), "databese error", String.valueOf(System.currentTimeMillis()), AimError.INTERNAL_ERROR.getUidCode());
		}
		result.setBatchJobId(bacthInfo.get(0).getBatchJobId());
		result.setType(BatchType.EXTRACT);	
		PBResponse.Builder errRes = PBResponse.newBuilder();
		errRes.setErrorMessage(reason.getErrMsg());
		errRes.setStatus(reason.getErrorcode()+ ":" + "faild");
		PBResponseAttribute.Builder pbpa = PBResponseAttribute.newBuilder();
		pbpa.setAttributeName("createdTimestamp");
		pbpa.setAttributeValue(String.valueOf(System.currentTimeMillis()));
		errRes.addResponseAttributes(0, pbpa);	
		pbMes.toBuilder().setResponse(errRes);			
		result.addBusinessMessage(pbMes.toByteString());		
		return result.build();	
	}

	/**
	 * 
	 * @param jobId
	 * @param muId
	 * @param result
	 * @param failed
	 * @return
	 * @throws SQLException
	 * @throws IOException
	 */
	public int completeExtractJob(long jobId, long muId,
			PBMuExtractJobResultItem result, boolean failed)
			throws SQLException, IOException {
		PBBusinessMessage pbMsg = PBBusinessMessage.parseFrom(result.getResult());	
		if (failed) {
			try {
				FailExtractJobProcedure failProcedure = new FailExtractJobProcedure(dataSource);						
				PBBusinessMessage errResult = PBBusinessMessage.parseFrom(result.getResult());
				AimServiceState aimServiceState = new AimServiceState();
				if (errResult.hasResponse() && errResult.getResponse().hasErrorMessage()) {
					aimServiceState.setErrMsg(errResult.getResponse().getErrorMessage());
				} else {
					aimServiceState.setErrMsg("error");
				}
				if (errResult.hasResponse() && errResult.getResponse().hasStatus()) {
					aimServiceState.setErrorcode(errResult.getResponse().getStatus());
				} else {
					aimServiceState.setErrorcode("1");
				}
				if (errResult.hasResponse() && errResult.getResponse().getResponseAttributesCount() > 0) {
					errResult.getResponse().getResponseAttributesList().forEach(attr -> {
						if (attr.getAttributeName().equals("createdTimestamp")) {
							aimServiceState.setFailureTime(attr.getAttributeValue());
						}
					});
				} else {
					aimServiceState.setFailureTime(String.valueOf(System.currentTimeMillis()));
				}					
				int numCompleted = failProcedure.execute(jobId, muId,aimServiceState,result.toByteArray());						
				return numCompleted;
			} catch (Exception ex) {
				String message = "DataAccessException when Failing Extract Job";
				log.error(message, ex);
				throw new AimRuntimeException(message, ex);
			}
		} else {
			int numCompleted = 0;
			try {
				if (pbMsg.hasDataBlock() && pbMsg.getDataBlock().hasTemplateInfo()) {
					PBTemplateInfo template = pbMsg.getDataBlock().getTemplateInfo();
					FinishExtractJobProcedure finishProcedure = new FinishExtractJobProcedure(dataSource);
					numCompleted = finishProcedure.execute(muId, jobId , template.getData().toByteArray(), "UID", template.getData().toByteArray());					
				}
				return numCompleted;
			} catch (Exception ex) {
				String message = "DataAccessException when Finish Extract Job";
				log.error(message, ex);
				throw new AimRuntimeException(message, ex);
			}
		}	
	}
}
