package jp.co.nec.aim.mm.exception;

/**
 * AimErrorInfoException
 * 
 * @author liuyq
 * 
 */
public abstract class AimErrorInfoException extends RuntimeException {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -388536371154568684L;
	private String description; // error description
	private String errorCode; // error code
	private String time; // error epochTime
	private String uidCode;

	/**
	 * AimErrorInfoException
	 * 
	 * @param errorCode
	 *            errorCode
	 * @param description
	 *            error description
	 * @param epochTime
	 *            error epochTime
	 */
	public AimErrorInfoException(String errorCode, String description,
			String time, String uidCode) {
		super(description);
		this.errorCode = errorCode;
		this.description = description;
		this.setTime(time);
		this.uidCode = uidCode;
	}

	public AimErrorInfoException(Throwable ex) {
		super(ex);
	}

	public AimErrorInfoException(String detail, Throwable ex) {
		super(detail, ex);
	}

	public String getErrorCode() {
		return errorCode;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getUidCode() {
		return uidCode;
	}

	public void setUidCode(String uidCode) {
		this.uidCode = uidCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}	
}
