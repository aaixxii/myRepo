package jp.co.nec.aim.mm.validator;

import static jp.co.nec.aim.mm.constants.AimError.ENROLL_BATCH_TYPE_MISS_MATCH;
import static jp.co.nec.aim.mm.constants.AimError.PROTOBUF_ERROR;
import static jp.co.nec.aim.mm.constants.MMConfigProperty.DEFAULT_MAX_CANDIDATES;

import java.util.Objects;

import javax.persistence.EntityManager;
import javax.sql.DataSource;

import org.apache.commons.lang3.StringUtils;

import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;

import jp.co.nec.aim.helper.TemplateHeaderHelper;
import jp.co.nec.aim.message.proto.BatchTypeProto.BatchType;
import jp.co.nec.aim.message.proto.BusinessMessage.E_REQUESET_TYPE;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBiometricElement;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBiometricsData;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBusinessMessage;
import jp.co.nec.aim.message.proto.BusinessMessage.PBRequest;
import jp.co.nec.aim.message.proto.BusinessMessage.PBTemplateInfo;
import jp.co.nec.aim.message.proto.InquiryService.IdentifyRequest;
import jp.co.nec.aim.message.proto.SyncService.SyncRequest;
import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.dao.DateDao;
import jp.co.nec.aim.mm.dao.PersonBiometricDao;
import jp.co.nec.aim.mm.dao.SystemConfigDao;
import jp.co.nec.aim.mm.entities.PersonBiometricEntity;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.exception.ArgumentException;
import jp.co.nec.aim.mm.exception.ExceptionHelper;

/**
 * Validate the Accept protoBuffer Object from client
 * 
 * @author liuyq
 * 
 */
public final class AcceptorValidator {	
	
	/** SystemConfig DAO **/
	private SystemConfigDao sysConfigDao;
	private PersonBiometricDao bioDao;		
	/** ExceptionHelper instance **/
	private ExceptionHelper exception;
	

	/**
	 * AcceptorValidator constructor
	 * 
	 * @param EntityManager
	 */
	public AcceptorValidator(EntityManager em, DataSource dataSource) {		
		this.bioDao = new PersonBiometricDao(em);
		this.exception = new ExceptionHelper(new DateDao(dataSource));
		this.sysConfigDao = new SystemConfigDao(em);
	}	
	
	/**
	 * check the inquiry instance PBInquiryJobRequest, if any argument logic
	 * exception occurred, throw the argument exception, servLet will response
	 * the aim error code and message to client.
	 * 
	 * @param request
	 *            PBInquiryJobRequest instance
	 * @return PBInquiryJobRequest.Builder Builder instance
	 */
	public PBBusinessMessage checkInquiryJobRequest(
			final IdentifyRequest request) {
		PBBusinessMessage.Builder newPBMsg = PBBusinessMessage.newBuilder();
		PBRequest.Builder newPbReq = PBRequest.newBuilder();
		BatchType batchType = request.getType();
		if (batchType.ordinal() != 1) {
			exception.throwArgException(AimError.INQ_BATCH_TYPE_MISS_MATCH);
		}		
		PBBusinessMessage pbMes = null;
		try {
			pbMes = PBBusinessMessage.parseFrom(request.getBusinessMessageList().get(0).toByteArray());
		} catch (InvalidProtocolBufferException e1) {			
			exception.throwArgException(PROTOBUF_ERROR);
		}		
		
		E_REQUESET_TYPE reqType = pbMes.getRequest().getRequestType();
		if (!((reqType.ordinal() == 3 || reqType.ordinal() ==4))){
			exception.throwArgException(AimError.INQ_E_REQUESET_TYPE_MISS); 
		}
		
		newPbReq.setRequestType(reqType);
		newPbReq.setRequestId(pbMes.getRequest().getRequestId());
		
		PBBiometricsData.Builder bioData = PBBiometricsData.newBuilder();
		PBBiometricElement.Builder bioElement = PBBiometricElement.newBuilder();
		PBTemplateInfo.Builder template = PBTemplateInfo.newBuilder();
		
		if (pbMes.getRequest().getBiometricsData().hasDataFormat()) {
			bioData.setDataFormat(pbMes.getRequest().getBiometricsData().getDataFormat());
		}
		
		if (reqType.ordinal() == 4) { //refId
			try {
				if (StringUtils.isBlank(pbMes.getRequest().getBiometricsData().getBiometricElement().getTemplateInfo().getReferenceId())) {
					exception.throwArgException(AimError.INQ_REQUST_REF_ID_NOT_FOUND);
				}
			} catch (Exception e) {
				exception.throwArgException(AimError.INQ_REQUST_REF_ID_NOT_FOUND);
			}
			
			try {
				String refernceId = pbMes.getRequest().getBiometricsData().getBiometricElement().getTemplateInfo().getReferenceId();
				// FeJobQueueEntity feEntity = feJobDao.getExResult(refernceId).get(0);
				//byte [] result = feEntity.getResult();	
				PersonBiometricEntity bioEvntify = bioDao.getBioDataByExternalId(refernceId);
				 byte[] tempalteData = TemplateHeaderHelper.prependHeader(bioEvntify.getBiometricsId(), bioEvntify.getBiometricData(), refernceId, 0);
				 template.setReferenceId(refernceId);
				template.setData(ByteString.copyFrom(tempalteData));			
				
			} catch (Exception e1) {
				throw new AimRuntimeException(e1.getMessage(),e1.getCause());
			}			
			
		}
		
		if (reqType.ordinal() == 3) { //by data
			try {
				if (Objects.isNull(pbMes.getRequest().getBiometricsData().getBiometricElement().getTemplateInfo().getData())){
					exception.throwArgException(AimError.INQ_REQUST_DATA_NOT_FOUND);
				}
			} catch (Exception e) {
				exception.throwArgException(AimError.INQ_REQUST_DATA_NOT_FOUND);
			}	
			
			byte[] templateData = pbMes.getRequest().getBiometricsData().getBiometricElement().getTemplateInfo().getData().toByteArray();
			if (pbMes.getRequest().hasEnrollmentId()) {
				String enrollId = pbMes.getRequest().getEnrollmentId();
				PersonBiometricEntity bioEvntify = bioDao.getBioDataByExternalId(enrollId);
				 byte[] tempalteDataWithHead = TemplateHeaderHelper.prependHeader(bioEvntify.getBiometricsId(), templateData, enrollId, 0);
				 template.setData(ByteString.copyFrom(tempalteDataWithHead));
			} else {
				long emptyBioId = 0l;
				String extId = "000000000000000000000000000000000000";
				 byte[] tempalteDataWithEmptyHead = TemplateHeaderHelper.prependHeader(emptyBioId, templateData, extId, 0);
				template.setData(ByteString.copyFrom(tempalteDataWithEmptyHead));	
			}						
		}
	
		bioElement.setTemplateInfo(template.build());
		bioData.setBiometricElement(bioElement.build());
		newPbReq.setBiometricsData(bioData.build());
		
		try {
			if (pbMes.getRequest().hasMaxResults() && pbMes.getRequest().getMaxResults() >= 1) {
				newPbReq.setMaxResults(pbMes.getRequest().getMaxResults()); 
			} else if (pbMes.getRequest().hasMaxResults() && pbMes.getRequest().getMaxResults() == -1) {
				int sysMaxCandidate = sysConfigDao
						.getMMPropertyInt(DEFAULT_MAX_CANDIDATES);
				newPbReq.setMaxResults(sysMaxCandidate);
			} else {
				exception.throwArgException(AimError.INQ_REQUST_MAX_RESULTS_NOT_FOUND);
			}
			
		} catch (Exception e) {
			exception.throwArgException(AimError.PROTOBUF_ERROR);
		}
		
		if (pbMes.getRequest().hasTargetFpir()) {
			newPbReq.setTargetFpir(pbMes.getRequest().getTargetFpir());
		} else {
			exception.throwArgException(AimError.INQ_REQUST_TARGET_FPIR_NOT_FOUND);
		}
		if (pbMes.getRequest().hasRequestParameters()) {
			newPbReq.setRequestParameters(pbMes.getRequest().getRequestParameters());
		}		
		newPBMsg.setRequest(newPbReq.build());	
		return newPBMsg.build();
	}
	


	/**
	 * check the PBSyncJobRequest instance
	 * 
	 * @param request
	 * @return is check passed
	 * @throws ArgumentException
	 *             SERVLET will receive this exception and response bad request
	 */
	public PBBusinessMessage checkSyncJobRequest(
			final SyncRequest request) throws ArgumentException {			
		
		BatchType syncType = request.getType();		
		if (!((syncType.ordinal() == 0) || (syncType.ordinal() == 2))) {
			exception.throwArgException(ENROLL_BATCH_TYPE_MISS_MATCH); 
		}
		
		PBBusinessMessage pbm = null;
		try {
			pbm = PBBusinessMessage.parseFrom(request.getBusinessMessage(0));
		} catch (InvalidProtocolBufferException e1) {
			exception.throwArgException(PROTOBUF_ERROR);
		}	
		
		if (pbm.getRequest().getEnrollmentId().length() != 36) {
			exception.throwArgException(AimError.EXTRACT_REQUESET_ENROLLMENTID_SIZE_MISS);
		}
		
		PBRequest syncReq = pbm.getRequest();
		E_REQUESET_TYPE insertType = syncReq.getRequestType();	
		
		if (!((insertType.ordinal() == 1 || insertType.ordinal() == 2 || insertType.ordinal() == 12))) {
			exception.throwArgException(AimError.ENROLL_E_REQUESET_TYPE_MISS); 
		}
		
		if (insertType.ordinal() == 1 ) {
			if (syncReq.getRequestType() != E_REQUESET_TYPE.INSERT_REFID_DEFAULT) {
				exception.throwArgException(AimError.ENROLL_E_REQUESET_TYPE_MISS);
			}	
		}
		
		if (insertType.ordinal() == 2 ) {
			if (syncReq.getRequestType() != E_REQUESET_TYPE.INSERT_REFURL_DEFAULT) {
				exception.throwArgException(AimError.ENROLL_E_REQUESET_TYPE_MISS);
			}
			
				if (StringUtils.isBlank(syncReq.getBiometricsData().getBiometricElement().getFilePath())) {
					exception.throwArgException(AimError.ENROLL_REQUST_DATA_NOT_FOUND);
				}						
					
		}	
		
		if (insertType.ordinal() == 12 ) {
			if (syncReq.getRequestType() != E_REQUESET_TYPE.DELETE_REFID) {
				exception.throwArgException(AimError.ENROLL_E_REQUESET_TYPE_MISS );
			}
			try {
				if (StringUtils.isBlank(syncReq.getEnrollmentId())) {
					exception.throwArgException(AimError.ENROLL_REQUST_REF_ID_NOT_FOUND );
				}						
			} catch (Exception e) {
				exception.throwArgException(AimError.ENROLL_REQUST_REF_ID_NOT_FOUND ); 
			}			
		}
		return pbm;
	}
}
