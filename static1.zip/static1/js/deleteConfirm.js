function deleteConfirm(){
    var result = confirm("削除するとデータは元に戻せません。\r\n本当に削除してよろしいですか？");
    if (result) {
        return location.href='02-001_契約先検索画面.html';
    }
}
