package jp.co.nec.aim.mm.common;

public enum SequenceIdType {
	BATCHJOB_ID(0),
	ENROLL_ID(1),
	INQUIRY_ID(2),
	EXTEACT_ID(3),
	MU_ID(4);	
	
	private long val;
	
	private  SequenceIdType(long val) {
		this.val = val;		
	}
	
	public long getVal() {
		return val;
	}

}
