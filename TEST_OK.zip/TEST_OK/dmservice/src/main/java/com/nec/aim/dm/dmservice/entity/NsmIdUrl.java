package com.nec.aim.dm.dmservice.entity;

import lombok.Data;

@Data
public class NsmIdUrl {
	Integer storageId;
	String basUrl;
}
