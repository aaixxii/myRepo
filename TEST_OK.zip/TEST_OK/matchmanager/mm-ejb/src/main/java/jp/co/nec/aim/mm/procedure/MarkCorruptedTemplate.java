package jp.co.nec.aim.mm.procedure;

import java.util.List;
import java.util.stream.Collectors;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

/**
 * MarkCorruptedTemplate
 * 
 * @author liuyq
 * 
 */
public class MarkCorruptedTemplate {	
	private static String SQL = "UPDATE PERSON_BIOMETRICS SET CORRUPTED_FLAG = 1 WHERE CORRUPTED_FLAG = 0 AND BIOMETRICS_ID IN (";	

	private JdbcTemplate jdbcTemplate;

	private List<Long> bioIds;

	public MarkCorruptedTemplate(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);		
	}

	public int execute(List<Long> bioIds) {		
		String bioStr = bioIds.stream().map( one -> String.valueOf(one)).collect(Collectors.joining(","));
		SQL = SQL + bioStr + ")";
		SQL = String.format(SQL);
		return jdbcTemplate.update(SQL);
	}

	/**
	 * BioIdArray
	 * 
	 * @author liuyq
	 * 
	 */

	public void setBioIds(List<Long> bioIds) {
		this.bioIds = bioIds;
	}

	public List<Long> getBioIds() {
		return bioIds;
	}
}
