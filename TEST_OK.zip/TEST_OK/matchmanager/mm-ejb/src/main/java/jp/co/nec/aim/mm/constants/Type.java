package jp.co.nec.aim.mm.constants;

/**
 * Message type
 */
public enum Type {
	INFORMATION("0"), WARNING("1"), OTHER("2"), IMPORTANT("3"), RFU_4("4"), ALARM(
			"5"), RFU_6("6"), RFU_7("7"), ERROR("8"), EMERGENCY("9");
	private String errorCode; // error code

	private Type(String errorCode) {
		this.setErrorCode(errorCode);

	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
}
