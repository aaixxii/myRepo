package jp.co.nec.aim.mm.logger;

/**
 * DuplicateMessageFilter checks duplicate message.<br/>
 * It refers to ch.qos.logback.classic.turbo.DuplicateMessageFilter.<br/>
 * Message cashe is cleared every period(millisec).
 * 
 * @author kurosu
 * 
 */
public class DuplicateMessageFilter {
	private static final int DEFAULT_CACHE_SIZE = 100;
	/**
	 * The default period. Every 10000 msec, cahche will be cleared.
	 */
	private static final int DEFAULT_PERIOD = 10000;
	/**
	 * The default number of allows repetitions.
	 */
	private static final int DEFAULT_ALLOWED_REPETITIONS = 5;

	private long startTimeMillis = 0L;
	private int allowedRepetitions;
	private long period;
	private int cacheSize = DEFAULT_CACHE_SIZE;

	private LRUMessageCache msgCache;

	public DuplicateMessageFilter() {
		this(DEFAULT_ALLOWED_REPETITIONS, DEFAULT_PERIOD);
	}

	/**
	 * Constructor to specify allowedRepetitions and period.
	 * 
	 * @param allowedRepetitions
	 *            - allow duplicate message allowedRepetitions times.
	 * @param period
	 *            - message cache will be cleared every period millisec.
	 */
	public DuplicateMessageFilter(int allowedRepetitions, long period) {
		this.allowedRepetitions = allowedRepetitions;
		this.period = period;
		msgCache = new LRUMessageCache(cacheSize);
	}

	/**
	 * Judge messais is duplicate or not.
	 * 
	 * @param message
	 *            - String messsage
	 * @return - true:message is duplicate false:message is not duplicate
	 */
	public synchronized boolean isDuplicate(String message) {
		if (startTimeMillis == 0L) {
			// set startTimeMillis for the first time
			startTimeMillis = System.currentTimeMillis();
		}
		long interval = System.currentTimeMillis() - startTimeMillis;
		if (period <= interval) {
			msgCache.clear();
			startTimeMillis = System.currentTimeMillis();
		}

		int count = msgCache.getMessageCountAndThenIncrement(message);
		if (count <= allowedRepetitions) {
			return false;
		} else {
			return true;
		}
	}

	/**
	 * SingletonHolder
	 * 
	 * @author liuyq
	 * 
	 */
	static class SingletonHolder {
		public static final DuplicateMessageFilter FILTER = new DuplicateMessageFilter();
	}

	public static DuplicateMessageFilter getInstance() {
		return SingletonHolder.FILTER;
	}

}
