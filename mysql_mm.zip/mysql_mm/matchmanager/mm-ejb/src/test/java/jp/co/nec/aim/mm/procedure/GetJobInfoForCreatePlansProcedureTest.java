package jp.co.nec.aim.mm.procedure;

import java.sql.SQLException;
import java.util.Collections;
import java.util.List;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.aim.mm.identify.planner.JobInfoFromDB;
import jp.co.nec.aim.mm.identify.planner.JobInfoFromDBComparator;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class GetJobInfoForCreatePlansProcedureTest extends
		AbstractTransactionalJUnit4SpringContextTests {
	@PersistenceContext(unitName = "aim-db")
	protected EntityManager entityManager;
	@Resource
	protected DataSource dataSource;
	@Resource
	protected JdbcTemplate jdbcTemplate;
	private GetJobInfoForCreatePlansProcedure identifyPlannerDao;

	@Before
	public void setUp() throws Exception {
		identifyPlannerDao = new GetJobInfoForCreatePlansProcedure(dataSource);
		jdbcTemplate.execute("delete from JOB_QUEUE");
		jdbcTemplate.execute("delete from SEGMENT_DEFRAGMENTATION");
		jdbcTemplate.execute("commit");
	}

	@After
	public void tearDown() throws Exception {
		identifyPlannerDao = null;
		jdbcTemplate.execute("delete from JOB_QUEUE");
		jdbcTemplate.execute("DELETE from SEGMENT_DEFRAGMENTATION");
		jdbcTemplate.execute("commit");
	}

	@Test
	public void testGetJobInfoForCreatePlansProcedure() {
		String jobQueueSql = "insert into JOB_QUEUE(JOB_ID,PRIORITY,JOB_STATE, SUBMISSION_TS, CALLBACK_STYLE,  FAILURE_COUNT,  REMAIN_JOBS,  FAMILY_ID)"
				+ " values(?,1,0,3000,0,0,0,?)";
		String fusionJobSql = "insert into FUSION_JOBS(FUSION_JOB_ID,FUNCTION_ID,JOB_ID, SEARCH_REQUEST_INDEX) values(?,?,?,?)";
		String contaiJobSql = "insert into CONTAINER_JOBS(CONTAINER_JOB_ID,CONTAINER_ID,FUSION_JOB_ID,JOB_STATE) values(?,?,?,0)";
		String defragBeanSql = "insert into SEGMENT_DEFRAGMENTATION(CONTAINER_ID,START_TS, END_TS) values(5,2000,3000)";

		Long[] jobIds = { 1000L, 1001L, 1002L };
		int[] familyIds = { 1, 2, 1 };
		int[] functionIds = { 1, 2, 1 };
		long[][] fusionJobIds = new long[jobIds.length][2];
		long[][] containerJobIds = new long[jobIds.length][2];
		int[][] searchIndexs = new int[jobIds.length][2];
		int[][] containerIds = new int[jobIds.length][2];

		long baseFusionJobId = 2000l;
		long containerJobId = 5000l;
		int searchIndex = 0;
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 2; j++) {
				fusionJobIds[i][j] = baseFusionJobId++;
				containerJobIds[i][j] = containerJobId++;
				searchIndexs[i][j] = searchIndex++;
				if (i == 0 && j == 0 || i == 0 && j == 1) {
					containerIds[i][j] = 1;
				}
				if (i == 1 && j == 0 || i == 1 && j == 1) {
					containerIds[i][j] = 2;
				}
				if (i == 2 && j == 0 || i == 2 && j == 1) {
					containerIds[i][j] = 1;
				}

			}
		}
		for (int i = 0; i < jobIds.length; i++) {
			jdbcTemplate.update(jobQueueSql, new Object[] { jobIds[i],
					new Long(familyIds[i]) });
		}
		for (int i = 0; i < fusionJobIds.length; i++) {
			for (int j = 0; j < fusionJobIds[0].length; j++) {
				jdbcTemplate.update(fusionJobSql, new Object[] {
						new Long(fusionJobIds[i][j]),
						new Integer(functionIds[i]), new Long(jobIds[i]),
						new Integer(searchIndexs[i][j]) });
			}
		}

		for (int i = 0; i < containerJobIds.length; i++) {
			for (int j = 0; j < containerJobIds[0].length; j++) {
				jdbcTemplate.update(contaiJobSql, new Object[] {
						new Long(containerJobIds[i][j]),
						new Integer(containerIds[i][j]),
						new Long(fusionJobIds[i][j]) });
			}
		}
		jdbcTemplate.update(defragBeanSql);
		jdbcTemplate.update("commit");

		try {
			List<JobInfoFromDB> results = null;
			try {
				results = identifyPlannerDao.getJobInfoFromDB(jobIds);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Collections.sort(results, new JobInfoFromDBComparator());
			long resultsContainerJobId = 5000l;
			Assert.assertNotNull(results);
			Assert.assertEquals(6, results.size());
			for (int i = 0; i < results.size(); i++) {
				if (results.get(i).getTopJobId() == 1000L) {
					Assert.assertEquals(1, results.get(i).getFunctionId()
							.intValue());
					Assert.assertEquals(1, results.get(i).getContainerId()
							.intValue());
					Assert.assertEquals(resultsContainerJobId++, results.get(i)
							.getContainerJobId().longValue());
				}
				if (results.get(i).getTopJobId() == 1001L) {
					Assert.assertEquals(2, results.get(i).getFunctionId()
							.intValue());
					Assert.assertEquals(2, results.get(i).getContainerId()
							.intValue());
					Assert.assertEquals(resultsContainerJobId++, results.get(i)
							.getContainerJobId().longValue());
				}

				if (results.get(i).getTopJobId() == 1002L) {
					Assert.assertEquals(1, results.get(i).getFunctionId()
							.intValue());
					Assert.assertEquals(1, results.get(i).getContainerId()
							.intValue());
					Assert.assertEquals(resultsContainerJobId++, results.get(i)
							.getContainerJobId().longValue());
				}
			}

		} catch (DataAccessException e) {

			e.printStackTrace();
		}
	}

	@Test
	public void testGetJobInfoForCreatePlans_results_zero() {
		Long[] jobIds = { 1000L };
		try {
			List<JobInfoFromDB> results = null;
			try {
				results = identifyPlannerDao.getJobInfoFromDB(jobIds);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Assert.assertTrue(results.size() == 0);

		} catch (DataAccessException e) {
			e.printStackTrace();
		}
	}

}
