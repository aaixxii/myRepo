package jp.co.nec.aim.mm.dao;

import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import javax.sql.DataSource;

import jp.co.nec.aim.mm.entities.FeJobQueueEntity;
import jp.co.nec.aim.mm.entities.FeLotJobEntity;
import jp.co.nec.aim.mm.entities.MuExtractLoadEntity;
import jp.co.nec.aim.mm.extract.planner.FeProcedureResults;
import jp.co.nec.aim.mm.extract.planner.MuRemainLots;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class FEPlannerDAOImplTest extends
		AbstractTransactionalJUnit4SpringContextTests {

	@PersistenceContext(unitName = "aim-db")
	protected EntityManager entityManager;

	@Resource(mappedName = "java:jboss/MySqlDS")
	protected DataSource dataSource;
	@Resource
	protected JdbcTemplate jdbcTemplate;

	private FEPlannerDAO fEPlannerDAO;

	@Before
	public void setUp() throws Exception {
		fEPlannerDAO = new FEPlannerDAOImpl(dataSource, entityManager);
		jdbcTemplate.execute("delete from mu_eligible_functions");
		jdbcTemplate.execute("delete from SYSTEM_CONFIG");
		jdbcTemplate.execute("delete from system_init");
		jdbcTemplate.execute("delete from fe_lot_jobs");
		jdbcTemplate.execute("delete from mu_extract_load");
		jdbcTemplate.execute("delete from fe_job_queue");
		jdbcTemplate.execute("delete from match_units");
		jdbcTemplate.execute("commit");
	}

	@After
	public void tearDown() throws Exception {
		fEPlannerDAO = new FEPlannerDAOImpl(dataSource, entityManager);
		jdbcTemplate.execute("delete from mu_eligible_functions");
		jdbcTemplate.execute("delete from SYSTEM_CONFIG");
		jdbcTemplate.execute("delete from system_init");
		jdbcTemplate.execute("delete from fe_lot_jobs");
		jdbcTemplate.execute("delete from mu_extract_load");
		jdbcTemplate.execute("delete from fe_job_queue");
		jdbcTemplate.execute("delete from match_units");
		jdbcTemplate.execute("commit");
	}

	@Test
	public void testProcessOneFeMatchUnit_normal() {
		int maxMulots = 12;
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		String extratLoadSql = "INSERT INTO MU_EXTRACT_LOAD (MU_ID, PRESSURE, UPDATE_TS)  VALUES(?,?,?)";
		String eligibleFunctionsSql = "INSERT INTO MU_ELIGIBLE_FUNCTIONS (MU_ID,FUNCTION_ID) VALUES(?,?)";

		int[] muIds = { 1000, 1001, 1002, 1003, 1004 };
		Integer muCpu = 4;
		String[] muStautus = { "WORKING", "EXIT", "WORKING", "WORKING",
				"WORKING" };
		int[] muCpus = { 4, 8, 4, 4, 4 };
		int[] muPressure = { 4, 5, 6, 7, 8 };
		int[] muFunctionId = { 17, 17, 17, 17, 17 };
		long epochTime = System.currentTimeMillis();
		for (int i = 0; i < 5; i++) {
			jdbcTemplate.update(muSql, new Object[] { new Integer(muIds[i]),
					String.valueOf((muIds[i])), muStautus[i],
					new Integer(muCpus[i]) });
			jdbcTemplate.update(extratLoadSql, new Object[] {
					new Integer(muIds[i]), new Integer(muPressure[i]),
					new Long(epochTime) });
			jdbcTemplate.update(eligibleFunctionsSql, new Object[] {
					new Integer(muIds[i]), new Integer(muFunctionId[i]) });
		}

		long assignedTS = System.currentTimeMillis();
		Long[] feJobIds = { 3000L, 3001L, 3002L, 3003L, 3004L };
		Integer[] priotity = { 2, 2, 2, 3, 2 };
		Integer[] states = { 0, 0, 0, 0, 0 };
		Integer[] failureCount = { 0, 1, 2, 2, 1 };

		String feJobSql = "insert into fe_job_queue(job_id,function_id,PRIORITY,job_state,failure_count,submission_ts,CALLBACK_STYLE)"
				+ " values(?,17,?,?,?,?,0)";
		for (int i = 0; i < feJobIds.length; i++) {
			jdbcTemplate.update(feJobSql, new Object[] { feJobIds[i],
					priotity[i], states[i], failureCount[i],
					new Long(assignedTS) });
		}

		String topJobtimeOutValueSql = " SELECT top_level_job_timeouts"
				+ " FROM function_types " + " WHERE function_id = 17"
				+ "AND queue_type = 1";
		Long topJobtimeOutValue = jdbcTemplate.queryForObject(
				topJobtimeOutValueSql, Long.class);
		topJobtimeOutValue = topJobtimeOutValue * muCpu;
		jdbcTemplate.execute("commit");
		Long selectedMuId = 1000L;
		FeProcedureResults feResults;
		try {
			feResults = fEPlannerDAO.processOneFeMatchUnit(maxMulots);
			Long lotJobId = feResults.getFeLotJobId();
			Assert.assertTrue(lotJobId.longValue() > 0);
			FeLotJobEntity feLotJob = entityManager.find(FeLotJobEntity.class,
					lotJobId);
			Assert.assertNotNull(topJobtimeOutValue);
			Assert.assertEquals(topJobtimeOutValue.longValue(),
					feLotJob.getTimeouts());
			Assert.assertEquals(selectedMuId.intValue(), feLotJob.getMuId());
			String muExLoadSql = "from MuExtractLoadEntity ml where ml.muId =:muid";
			Query q = entityManager.createQuery(muExLoadSql);
			q.setParameter("muid", selectedMuId);
			MuExtractLoadEntity muLoad = (MuExtractLoadEntity) q
					.getSingleResult();
			Assert.assertNotNull(muLoad);
			Assert.assertTrue((muLoad.getPressure() >= 1L));
			String feJobQueueMuIdSql = "select mu_id from fe_job_queue where lot_job_id= ?";
			List<Map<String, Object>> muIdLsit = jdbcTemplate.queryForList(
					feJobQueueMuIdSql, lotJobId);
			Iterator<Map<String, Object>> it = muIdLsit.iterator();
			while (it.hasNext()) {
				Assert.assertEquals(selectedMuId.toString(),
						it.next().get("mu_id").toString());
			}

		} catch (DataAccessException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testProcessOneFeMatchUnit_feJob1_proority_selected() {
		int maxMulots = 12;
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		String extratLoadSql = "INSERT INTO MU_EXTRACT_LOAD (MU_ID, PRESSURE, UPDATE_TS)  VALUES(?,?,?)";
		String eligibleFunctionsSql = "INSERT INTO MU_ELIGIBLE_FUNCTIONS (MU_ID,FUNCTION_ID) VALUES(?,?)";

		int[] muIds = { 1000, 1001, 1002, 1003, 1004 };

		String[] muStautus = { "WORKING", "WORKING", "WORKING", "WORKING",
				"WORKING" };
		int[] muCpus = { 4, 8, 4, 4, 4 };
		int[] muPressure = { 4, 5, 6, 7, 8 };
		int[] muFunctionId = { 17, 17, 17, 17, 17 };
		Long[] feJobIds = { 3000L, 3001L, 3002L, 3003L, 3004L };
		Integer[] priotity = { 1, 1, 1, 1, 1 };
		Integer[] states = { 0, 0, 0, 0, 0 };
		Integer[] failureCount = { 1, 1, 2, 2, 1 };
		long epochTime = System.currentTimeMillis();
		long assignedTS = System.currentTimeMillis();

		for (int i = 0; i < 5; i++) {
			jdbcTemplate.update(muSql, new Object[] { new Integer(muIds[i]),
					String.valueOf((muIds[i])), muStautus[i],
					new Integer(muCpus[i]) });
			jdbcTemplate.update(extratLoadSql, new Object[] {
					new Integer(muIds[i]), new Integer(muPressure[i]),
					new Long(epochTime) });
			jdbcTemplate.update(eligibleFunctionsSql, new Object[] {
					new Integer(muIds[i]), new Integer(muFunctionId[i]) });
		}

		String feJobSql = "insert into fe_job_queue(job_id,function_id,PRIORITY,job_state,failure_count,submission_ts,CALLBACK_STYLE)"
				+ " values(?,17,?,?,?,?,0)";
		for (int i = 0; i < feJobIds.length; i++) {
			jdbcTemplate.update(feJobSql, new Object[] { feJobIds[i],
					priotity[i], states[i], failureCount[i],
					new Long(assignedTS) });
		}

		String topJobtimeOutValueSql = " SELECT top_level_job_timeouts"
				+ " FROM function_types " + " WHERE function_id = 17"
				+ "AND queue_type = 1";
		Long topJobtimeOutValue = jdbcTemplate.queryForObject(
				topJobtimeOutValueSql, Long.class);
		topJobtimeOutValue = topJobtimeOutValue * 1;
		jdbcTemplate.execute("commit");
		Long selectedMuId = 1000L;
		FeProcedureResults feResults;
		try {
			feResults = fEPlannerDAO.processOneFeMatchUnit(maxMulots);
			Long lotJobId = feResults.getFeLotJobId();
			Assert.assertTrue(lotJobId.longValue() > 0);
			FeLotJobEntity feLotJob = entityManager.find(FeLotJobEntity.class,
					lotJobId);
			Assert.assertNotNull(topJobtimeOutValue);
			Assert.assertEquals(topJobtimeOutValue.longValue(),
					feLotJob.getTimeouts());
			Assert.assertEquals(selectedMuId.intValue(), feLotJob.getMuId());
			String muExLoadSql = "from MuExtractLoadEntity ml where ml.muId =:muid";
			Query q = entityManager.createQuery(muExLoadSql);
			q.setParameter("muid", selectedMuId);
			MuExtractLoadEntity muLoad = (MuExtractLoadEntity) q
					.getSingleResult();
			Assert.assertNotNull(muLoad);
			Assert.assertTrue((muLoad.getPressure() >= 1L));
			String feJobQueueMuIdSql = "select mu_id from fe_job_queue where lot_job_id= ?";
			List<Map<String, Object>> muIdLsit = jdbcTemplate.queryForList(
					feJobQueueMuIdSql, lotJobId);
			Iterator<Map<String, Object>> it = muIdLsit.iterator();
			while (it.hasNext()) {
				Assert.assertEquals(selectedMuId.toString(),
						it.next().get("mu_id").toString());
			}
		} catch (DataAccessException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testProcessOneFeMatchUnit_second_maxFailureCount_selected() {
		int maxMulots = 12;
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		String extratLoadSql = "INSERT INTO MU_EXTRACT_LOAD (MU_ID, PRESSURE, UPDATE_TS)  VALUES(?,?,?)";
		String eligibleFunctionsSql = "INSERT INTO MU_ELIGIBLE_FUNCTIONS (MU_ID,FUNCTION_ID) VALUES(?,?)";

		int[] muIds = { 1000, 1001, 1002, 1003, 1004 };
		Integer muCpu = 4;
		String[] muStautus = { "WORKING", "WORKING", "WORKING", "WORKING",
				"WORKING" };
		int[] muCpus = { 4, 8, 4, 4, 4 };
		int[] muPressure = { 5, 5, 5, 5, 5 };
		int[] muFunctionId = { 17, 17, 17, 17, 17 };
		Long[] feJobIds = { 3000L, 3001L, 3002L, 3003L, 3004L };
		Integer[] priotity = { 2, 2, 2, 2, 2 };
		Integer[] states = { 0, 0, 0, 0, 0 };
		Integer[] failureCount = { 3, 1, 2, 2, 1 };
		long epochTime = System.currentTimeMillis();
		long assignedTS = System.currentTimeMillis();

		for (int i = 0; i < 5; i++) {
			jdbcTemplate.update(muSql, new Object[] { new Integer(muIds[i]),
					String.valueOf((muIds[i])), muStautus[i],
					new Integer(muCpus[i]) });
			jdbcTemplate.update(extratLoadSql, new Object[] {
					new Integer(muIds[i]), new Integer(muPressure[i]),
					new Long(epochTime) });
			jdbcTemplate.update(eligibleFunctionsSql, new Object[] {
					new Integer(muIds[i]), new Integer(muFunctionId[i]) });
		}

		String feJobSql = "insert into fe_job_queue(job_id,function_id,PRIORITY,job_state,failure_count,submission_ts,CALLBACK_STYLE)"
				+ " values(?,17,?,?,?,?,0)";
		for (int i = 0; i < feJobIds.length; i++) {
			jdbcTemplate.update(feJobSql, new Object[] { feJobIds[i],
					priotity[i], states[i], failureCount[i],
					new Long(assignedTS) });
		}

		String topJobtimeOutValueSql = " SELECT top_level_job_timeouts"
				+ " FROM function_types " + " WHERE function_id = 17"
				+ "AND queue_type = 1";
		Long topJobtimeOutValue = jdbcTemplate.queryForObject(
				topJobtimeOutValueSql, Long.class);
		topJobtimeOutValue = topJobtimeOutValue * muCpu;
		jdbcTemplate.execute("commit");
		Long selectedMuId = 1000L;
		FeProcedureResults feResults;
		try {
			feResults = fEPlannerDAO.processOneFeMatchUnit(maxMulots);
			Long lotJobId = feResults.getFeLotJobId();
			Assert.assertTrue(lotJobId.longValue() > 0);
			FeLotJobEntity feLotJob = entityManager.find(FeLotJobEntity.class,
					lotJobId);
			Assert.assertNotNull(topJobtimeOutValue);
			Assert.assertEquals(topJobtimeOutValue.longValue(),
					feLotJob.getTimeouts());
			Assert.assertEquals(selectedMuId.intValue(), feLotJob.getMuId());
			String muExLoadSql = "from MuExtractLoadEntity ml where ml.muId =:muid";
			Query q = entityManager.createQuery(muExLoadSql);
			q.setParameter("muid", selectedMuId);
			MuExtractLoadEntity muLoad = (MuExtractLoadEntity) q
					.getSingleResult();
			Assert.assertNotNull(muLoad);
			Assert.assertTrue((muLoad.getPressure() >= 1L));
			String feJobQueueMuIdSql = "select mu_id from fe_job_queue where lot_job_id= ?";
			List<Map<String, Object>> muIdLsit = jdbcTemplate.queryForList(
					feJobQueueMuIdSql, lotJobId);
			Iterator<Map<String, Object>> it = muIdLsit.iterator();
			while (it.hasNext()) {
				Assert.assertEquals(selectedMuId.toString(),
						it.next().get("mu_id").toString());
			}
		} catch (DataAccessException e) {
			e.printStackTrace();
		}

	}

	@Test
	public void testProcessOneFeMatchUnit_num_feJob_selected() {
		int maxMulots = 12;
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		String extratLoadSql = "INSERT INTO MU_EXTRACT_LOAD (MU_ID, PRESSURE, UPDATE_TS)  VALUES(?,?,?)";
		String eligibleFunctionsSql = "INSERT INTO MU_ELIGIBLE_FUNCTIONS (MU_ID,FUNCTION_ID) VALUES(?,?)";

		int[] muIds = { 1000, 1001, 1002, 1003, 1004 };
		Integer muCpu = 4;
		String[] muStautus = { "WORKING", "WORKING", "WORKING", "WORKING",
				"WORKING" };
		int[] muCpus = { 4, 8, 4, 4, 4 };
		int[] muPressure = { 4, 5, 6, 7, 8 };
		int[] muFunctionId = { 17, 17, 17, 17, 17 };
		Long[] feJobIds = { 3000L, 3001L, 3002L, 3003L, 3004L };
		Integer[] priotity = { 2, 2, 2, 2, 2 };
		Integer[] states = { 0, 0, 0, 0, 0 };
		Integer[] failureCount = { 1, 1, 1, 1, 1 };
		long epochTime = System.currentTimeMillis();
		long assignedTS = System.currentTimeMillis();

		for (int i = 0; i < 5; i++) {
			jdbcTemplate.update(muSql, new Object[] { new Integer(muIds[i]),
					String.valueOf((muIds[i])), muStautus[i],
					new Integer(muCpus[i]) });
			jdbcTemplate.update(extratLoadSql, new Object[] {
					new Integer(muIds[i]), new Integer(muPressure[i]),
					new Long(epochTime) });
			jdbcTemplate.update(eligibleFunctionsSql, new Object[] {
					new Integer(muIds[i]), new Integer(muFunctionId[i]) });
		}

		String feJobSql = "insert into fe_job_queue(job_id,function_id,PRIORITY,job_state,failure_count,submission_ts,CALLBACK_STYLE)"
				+ " values(?,17,?,?,?,?,0)";
		for (int i = 0; i < feJobIds.length; i++) {
			jdbcTemplate.update(feJobSql, new Object[] { feJobIds[i],
					priotity[i], states[i], failureCount[i],
					new Long(assignedTS) });
		}

		String topJobtimeOutValueSql = " SELECT top_level_job_timeouts"
				+ " FROM function_types " + " WHERE function_id = 17"
				+ "AND queue_type = 1";
		Long topJobtimeOutValue = jdbcTemplate.queryForObject(
				topJobtimeOutValueSql, Long.class);
		topJobtimeOutValue = topJobtimeOutValue * muCpu;
		jdbcTemplate.execute("commit");
		Long selectedMuId = 1000L;
		FeProcedureResults feResults;
		try {
			feResults = fEPlannerDAO.processOneFeMatchUnit(maxMulots);
			Long lotJobId = feResults.getFeLotJobId();
			Assert.assertTrue(lotJobId.longValue() > 0);
			FeLotJobEntity feLotJob = entityManager.find(FeLotJobEntity.class,
					lotJobId);
			Assert.assertNotNull(topJobtimeOutValue);
			Assert.assertEquals(topJobtimeOutValue.longValue(),
					feLotJob.getTimeouts());
			Assert.assertEquals(selectedMuId.intValue(), feLotJob.getMuId());
			String muExLoadSql = "from MuExtractLoadEntity ml where ml.muId =:muid";
			Query q = entityManager.createQuery(muExLoadSql);
			q.setParameter("muid", selectedMuId);
			MuExtractLoadEntity muLoad = (MuExtractLoadEntity) q
					.getSingleResult();
			Assert.assertNotNull(muLoad);
			Assert.assertTrue((muLoad.getPressure() >= 1L));
			String feJobQueueMuIdSql = "select mu_id from fe_job_queue where lot_job_id= ?";
			List<Map<String, Object>> muIdLsit = jdbcTemplate.queryForList(
					feJobQueueMuIdSql, lotJobId);
			Iterator<Map<String, Object>> it = muIdLsit.iterator();
			while (it.hasNext()) {
				Assert.assertEquals(selectedMuId.toString(),
						it.next().get("mu_id").toString());
			}
		} catch (DataAccessException e) {
			e.printStackTrace();
		}

	}

	@Test
	public void testProcessOneFeMatchUnit_all_feJob_no_state1() {
		int maxMulots = 12;
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		String extratLoadSql = "INSERT INTO MU_EXTRACT_LOAD (MU_ID, PRESSURE, UPDATE_TS)  VALUES(?,?,?)";
		String eligibleFunctionsSql = "INSERT INTO MU_ELIGIBLE_FUNCTIONS (MU_ID,FUNCTION_ID) VALUES(?,?)";

		int[] muIds = { 1000, 1001, 1002, 1003, 1004 };
		Integer muCpu = 4;
		String[] muStautus = { "WORKING", "WORKING", "WORKING", "WORKING",
				"WORKING" };
		int[] muCpus = { 4, 8, 4, 4, 4 };
		int[] muPressure = { 5, 5, 5, 5, 5 };
		int[] muFunctionId = { 17, 17, 17, 17, 17 };
		Long[] feJobIds = { 3000L, 3001L, 3002L, 3003L, 3004L };
		Integer[] priotity = { 2, 2, 2, 2, 2 };
		Integer[] states = { 1, 1, 1, 1, 1 };
		Integer[] failureCount = { 3, 1, 2, 2, 1 };
		long epochTime = System.currentTimeMillis();
		long assignedTS = System.currentTimeMillis();

		for (int i = 0; i < 5; i++) {
			jdbcTemplate.update(muSql, new Object[] { new Integer(muIds[i]),
					String.valueOf((muIds[i])), muStautus[i],
					new Integer(muCpus[i]) });
			jdbcTemplate.update(extratLoadSql, new Object[] {
					new Integer(muIds[i]), new Integer(muPressure[i]),
					new Long(epochTime) });
			jdbcTemplate.update(eligibleFunctionsSql, new Object[] {
					new Integer(muIds[i]), new Integer(muFunctionId[i]) });
		}

		String feJobSql = "insert into fe_job_queue(job_id,function_id,PRIORITY,job_state,failure_count,submission_ts,CALLBACK_STYLE)"
				+ " values(?,17,?,?,?,?,0)";
		for (int i = 0; i < feJobIds.length; i++) {
			jdbcTemplate.update(feJobSql, new Object[] { feJobIds[i],
					priotity[i], states[i], failureCount[i],
					new Long(assignedTS) });
		}

		String topJobtimeOutValueSql = " SELECT top_level_job_timeouts"
				+ " FROM function_types " + " WHERE function_id = 17"
				+ "AND queue_type = 1";
		Long topJobtimeOutValue = jdbcTemplate.queryForObject(
				topJobtimeOutValueSql, Long.class);
		topJobtimeOutValue = topJobtimeOutValue * muCpu;
		jdbcTemplate.execute("commit");
		FeProcedureResults feResults;
		try {
			feResults = fEPlannerDAO.processOneFeMatchUnit(maxMulots);
			Assert.assertNull(feResults);
		} catch (DataAccessException e) {
			e.printStackTrace();
		}

	}

	@Test
	public void testProcessOneFeMatchUnit_feJob1_proority_selected_one_only() {
		int maxMulots = 12;
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		String extratLoadSql = "INSERT INTO MU_EXTRACT_LOAD (MU_ID, PRESSURE, UPDATE_TS)  VALUES(?,?,?)";
		String eligibleFunctionsSql = "INSERT INTO MU_ELIGIBLE_FUNCTIONS (MU_ID,FUNCTION_ID) VALUES(?,?)";

		int[] muIds = { 1000, 1001, 1002, 1003, 1004 };
		String[] muStautus = { "WORKING", "WORKING", "WORKING", "WORKING",
				"WORKING" };
		int[] muCpus = { 4, 8, 4, 4, 4 };
		int[] muPressure = { 4, 5, 6, 7, 8 };
		int[] muFunctionId = { 17, 17, 17, 17, 17 };
		Long[] feJobIds = { 3000L, 3001L, 3002L, 3003L, 3004L };
		Integer[] priotity = { 1, 2, 2, 2, 2 };
		Integer[] states = { 0, 0, 0, 0, 0 };
		Integer[] failureCount = { 3, 1, 2, 2, 1 };
		long epochTime = System.currentTimeMillis();
		long assignedTS = System.currentTimeMillis();

		for (int i = 0; i < 5; i++) {
			jdbcTemplate.update(muSql, new Object[] { new Integer(muIds[i]),
					String.valueOf((muIds[i])), muStautus[i],
					new Integer(muCpus[i]) });
			jdbcTemplate.update(extratLoadSql, new Object[] {
					new Integer(muIds[i]), new Integer(muPressure[i]),
					new Long(epochTime) });
			jdbcTemplate.update(eligibleFunctionsSql, new Object[] {
					new Integer(muIds[i]), new Integer(muFunctionId[i]) });
		}

		String feJobSql = "insert into fe_job_queue(job_id,function_id,PRIORITY,job_state,failure_count,submission_ts,CALLBACK_STYLE)"
				+ " values(?,17,?,?,?,?,0)";
		for (int i = 0; i < feJobIds.length; i++) {
			jdbcTemplate.update(feJobSql, new Object[] { feJobIds[i],
					priotity[i], states[i], failureCount[i],
					new Long(assignedTS) });
		}

		String topJobtimeOutValueSql = " SELECT top_level_job_timeouts"
				+ " FROM function_types " + " WHERE function_id = 17"
				+ "AND queue_type = 1";
		Long topJobtimeOutValue = jdbcTemplate.queryForObject(
				topJobtimeOutValueSql, Long.class);
		topJobtimeOutValue = topJobtimeOutValue * 1;
		jdbcTemplate.execute("commit");
		Long selectedMuId = 1000L;
		FeProcedureResults feResults;
		try {
			feResults = fEPlannerDAO.processOneFeMatchUnit(maxMulots);
			Long lotJobId = feResults.getFeLotJobId();
			Assert.assertTrue(lotJobId.longValue() > 0);
			FeLotJobEntity feLotJob = entityManager.find(FeLotJobEntity.class,
					lotJobId);
			Assert.assertNotNull(topJobtimeOutValue);
			Assert.assertEquals(topJobtimeOutValue.longValue(),
					feLotJob.getTimeouts());
			Assert.assertEquals(selectedMuId.intValue(), feLotJob.getMuId());
			String muExLoadSql = "from MuExtractLoadEntity ml where ml.muId =:muid";
			Query q = entityManager.createQuery(muExLoadSql);
			q.setParameter("muid", selectedMuId);
			MuExtractLoadEntity muLoad = (MuExtractLoadEntity) q
					.getSingleResult();
			Assert.assertNotNull(muLoad);
			Assert.assertTrue((muLoad.getPressure() >= 1L));
			String feJobQueueMuIdSql = "select mu_id from fe_job_queue where lot_job_id= ?";
			List<Map<String, Object>> muIdLsit = jdbcTemplate.queryForList(
					feJobQueueMuIdSql, lotJobId);
			Iterator<Map<String, Object>> it = muIdLsit.iterator();
			while (it.hasNext()) {
				Assert.assertEquals(selectedMuId.toString(),
						it.next().get("mu_id").toString());
			}
		} catch (DataAccessException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testGetMaxMuLots_normal() {
		String selectSql = " SELECT key_value FROM system_init "
				+ " WHERE key_name = 'NUM_OF_MAX_FE_LOT'";
		String insertSql = "insert into system_init (init_id, key_name, key_value) values "
				+ " (system_init_SEQ.nextval,'NUM_OF_MAX_FE_LOT','5')";
		jdbcTemplate.update(insertSql);
		jdbcTemplate.execute("commit");
		Integer exptected = Integer.valueOf(jdbcTemplate.queryForObject(
				selectSql, String.class));
		Integer realResut;
		realResut = fEPlannerDAO.getMaxMuLots();
		Assert.assertEquals(exptected.intValue(), realResut.intValue());
	}

	@Test
	public void testGetMaxMuLots_null() {
		Integer realResut;
		realResut = fEPlannerDAO.getMaxMuLots();
		Assert.assertEquals(-1, realResut.intValue());
	}

	@Test
	public void testGetfirstMuRemainLots_min_pressure_selected() {
		int maxMulots = 12;
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		String extratLoadSql = "INSERT INTO MU_EXTRACT_LOAD (MU_ID, PRESSURE, UPDATE_TS)  VALUES(?,?,?)";
		String eligibleFunctionsSql = "INSERT INTO MU_ELIGIBLE_FUNCTIONS (MU_ID,FUNCTION_ID) VALUES(?,?)";
		int[] muIds = { 1000, 1001, 1002, 1003, 1004 };
		String[] muStautus = { "WORKING", "EXIT", "WORKING", "WORKING",
				"WORKING" };
		int[] muCpus = { 4, 8, 4, 4, 4 };
		int[] muPressure = { 4, 5, 6, 7, 8 };
		int[] muFunctionId = { 17, 17, 17, 17, 17 };
		long epochTime = System.currentTimeMillis();
		for (int i = 0; i < 5; i++) {
			jdbcTemplate.update(muSql, new Object[] { new Integer(muIds[i]),
					String.valueOf((muIds[i])), muStautus[i],
					new Integer(muCpus[i]) });
			jdbcTemplate.update(extratLoadSql, new Object[] {
					new Integer(muIds[i]), new Integer(muPressure[i]),
					new Long(epochTime) });
			jdbcTemplate.update(eligibleFunctionsSql, new Object[] {
					new Integer(muIds[i]), new Integer(muFunctionId[i]) });
			jdbcTemplate.execute("commit");

		}
		MuRemainLots firstMuRemainLots = null;
		try {
			firstMuRemainLots = fEPlannerDAO.getfirstMuRemainLots(maxMulots);
		} catch (DataAccessException e) {
			e.printStackTrace();
		}
		Assert.assertNotNull(firstMuRemainLots);
		Assert.assertEquals(1000, firstMuRemainLots.getMuId().intValue());
	}
	
	@Test
	public void testGetfirstMuRemainLots_num_exratctor_zero() {
		int maxMulots = 12;
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		String extratLoadSql = "INSERT INTO MU_EXTRACT_LOAD (MU_ID, PRESSURE, UPDATE_TS)  VALUES(?,?,?)";
		String eligibleFunctionsSql = "INSERT INTO MU_ELIGIBLE_FUNCTIONS (MU_ID,FUNCTION_ID) VALUES(?,?)";
		int[] muIds = { 1000, 1001, 1002, 1003, 1004 };
		String[] muStautus = { "WORKING", "EXIT", "WORKING", "WORKING",
				"WORKING" };
		int[] muCpus = { 0, 0, 0, 0, 0 };
		int[] muPressure = { 4, 5, 6, 7, 8 };
		int[] muFunctionId = { 17, 17, 17, 17, 17 };
		long epochTime = System.currentTimeMillis();
		for (int i = 0; i < 5; i++) {
			jdbcTemplate.update(muSql, new Object[] { new Integer(muIds[i]),
					String.valueOf((muIds[i])), muStautus[i],
					new Integer(muCpus[i]) });
			jdbcTemplate.update(extratLoadSql, new Object[] {
					new Integer(muIds[i]), new Integer(muPressure[i]),
					new Long(epochTime) });
			jdbcTemplate.update(eligibleFunctionsSql, new Object[] {
					new Integer(muIds[i]), new Integer(muFunctionId[i]) });
			jdbcTemplate.execute("commit");

		}
		MuRemainLots firstMuRemainLots = null;
		try {
			firstMuRemainLots = fEPlannerDAO.getfirstMuRemainLots(maxMulots);
		} catch (DataAccessException e) {
			e.printStackTrace();
		}
		Assert.assertNull(firstMuRemainLots);
		
	}


	@Test
	public void testGetfirstMuRemainLots__exit_not_select() {
		int maxMulots = 12;
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		String extratLoadSql = "INSERT INTO MU_EXTRACT_LOAD (MU_ID, PRESSURE, UPDATE_TS)  VALUES(?,?,?)";
		String eligibleFunctionsSql = "INSERT INTO MU_ELIGIBLE_FUNCTIONS (MU_ID,FUNCTION_ID) VALUES(?,?)";
		int[] muIds = { 1000, 1001, 1002, 1003, 1004 };
		String[] muStautus = { "WORKING", "EXIT", "WORKING", "WORKING", "EXIT" };
		int[] muCpus = { 4, 8, 4, 4, 4 };
		int[] muPressure = { 4, 5, 6, 7, 8 };
		int[] muFunctionId = { 17, 17, 17, 17, 17 };
		long epochTime = System.currentTimeMillis();
		for (int i = 0; i < 5; i++) {
			jdbcTemplate.update(muSql, new Object[] { new Integer(muIds[i]),
					String.valueOf((muIds[i])), muStautus[i],
					new Integer(muCpus[i]) });
			jdbcTemplate.update(extratLoadSql, new Object[] {
					new Integer(muIds[i]), new Integer(muPressure[i]),
					new Long(epochTime) });
			jdbcTemplate.update(eligibleFunctionsSql, new Object[] {
					new Integer(muIds[i]), new Integer(muFunctionId[i]) });
			jdbcTemplate.execute("commit");

		}
		MuRemainLots firstMuRemainLots = null;
		try {
			firstMuRemainLots = fEPlannerDAO.getfirstMuRemainLots(maxMulots);
		} catch (DataAccessException e) {
			e.printStackTrace();
		}
		Assert.assertNotNull(firstMuRemainLots);
		Assert.assertEquals(1000, firstMuRemainLots.getMuId().intValue());
		Assert.assertNotEquals(1004, firstMuRemainLots.getMuId().intValue());
		Assert.assertNotEquals(1001, firstMuRemainLots.getMuId().intValue());
	}

	@Test
	public void testGetfirstMuRemainLots_max_pressure_function17_olny_selected() {
		int maxMulots = 12;
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		String extratLoadSql = "INSERT INTO MU_EXTRACT_LOAD (MU_ID, PRESSURE, UPDATE_TS)  VALUES(?,?,?)";
		String eligibleFunctionsSql = "INSERT INTO MU_ELIGIBLE_FUNCTIONS (MU_ID,FUNCTION_ID) VALUES(?,?)";
		int[] muIds = { 1000, 1001, 1002, 1003, 1004 };
		String[] muStautus = { "WORKING", "EXIT", "WORKING", "WORKING", "EXIT" };
		int[] muCpus = { 4, 8, 4, 4, 4 };
		int[] muPressure = { 4, 5, 6, 7, 8 };
		int[] muFunctionId = { 17, 17, 17, 18, 18 };
		long epochTime = System.currentTimeMillis();
		for (int i = 0; i < 5; i++) {
			jdbcTemplate.update(muSql, new Object[] { new Integer(muIds[i]),
					String.valueOf((muIds[i])), muStautus[i],
					new Integer(muCpus[i]) });
			jdbcTemplate.update(extratLoadSql, new Object[] {
					new Integer(muIds[i]), new Integer(muPressure[i]),
					new Long(epochTime) });
			jdbcTemplate.update(eligibleFunctionsSql, new Object[] {
					new Integer(muIds[i]), new Integer(muFunctionId[i]) });
			jdbcTemplate.execute("commit");

		}
		MuRemainLots firstMuRemainLots = null;
		try {
			firstMuRemainLots = fEPlannerDAO.getfirstMuRemainLots(maxMulots);
		} catch (DataAccessException e) {
			e.printStackTrace();
		}
		Assert.assertNotNull(firstMuRemainLots);
		Assert.assertEquals(1000, firstMuRemainLots.getMuId().intValue());
		Assert.assertNotEquals(1001, firstMuRemainLots.getMuId().intValue());
		Assert.assertNotEquals(1003, firstMuRemainLots.getMuId().intValue());
		Assert.assertNotEquals(1004, firstMuRemainLots.getMuId().intValue());
	}

	@Test
	public void testGetfirstMuRemainLots_minUpdateTs_selected() {
		int maxMulots = 12;
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		String extratLoadSql = "INSERT INTO MU_EXTRACT_LOAD (MU_ID, PRESSURE, UPDATE_TS)  VALUES(?,?,?)";
		String eligibleFunctionsSql = "INSERT INTO MU_ELIGIBLE_FUNCTIONS (MU_ID,FUNCTION_ID) VALUES(?,?)";
		int[] muIds = { 1000, 1001, 1002, 1003, 1004 };
		String[] muStautus = { "WORKING", "EXIT", "WORKING", "WORKING",
				"WORKING" };
		int[] muCpus = { 4, 8, 4, 4, 4 };
		int[] muPressure = { 5, 5, 5, 5, 5 };
		int[] muFunctionId = { 17, 17, 17, 17, 17 };
		long epochTime = System.currentTimeMillis();
		long[] updateTs = { epochTime - 1000, epochTime - 2000,
				epochTime - 3000, epochTime - 4000, epochTime - 5000 };
		for (int i = 0; i < 5; i++) {
			jdbcTemplate.update(muSql, new Object[] { new Integer(muIds[i]),
					String.valueOf((muIds[i])), muStautus[i],
					new Integer(muCpus[i]) });
			jdbcTemplate.update(extratLoadSql, new Object[] {
					new Integer(muIds[i]), new Integer(muPressure[i]),
					new Long(updateTs[i]) });
			jdbcTemplate.update(eligibleFunctionsSql, new Object[] {
					new Integer(muIds[i]), new Integer(muFunctionId[i]) });
			jdbcTemplate.execute("commit");

		}
		MuRemainLots firstMuRemainLots = null;
		try {
			firstMuRemainLots = fEPlannerDAO.getfirstMuRemainLots(maxMulots);
		} catch (DataAccessException e) {
			e.printStackTrace();
		}
		Assert.assertNotNull(firstMuRemainLots);
		Assert.assertEquals(1004, firstMuRemainLots.getMuId().intValue());
	}

	@Test
	public void testGetfirstMuRemainLots_results_null() {
		int maxMulots = 5;
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		String extratLoadSql = "INSERT INTO MU_EXTRACT_LOAD (MU_ID, PRESSURE, UPDATE_TS)  VALUES(?,?,?)";
		String eligibleFunctionsSql = "INSERT INTO MU_ELIGIBLE_FUNCTIONS (MU_ID,FUNCTION_ID) VALUES(?,?)";
		int[] muIds = { 1000, 1001, 1002, 1003, 1004 };
		String[] muStautus = { "EXIT", "EXIT", "EXIT", "WORKING", "WORKING" };
		int[] muCpus = { 4, 8, 4, 4, 4 };
		int[] muPressure = { 1, 2, 3, 4, 5 };
		int[] muFunctionId = { 17, 17, 17, 18, 18 };
		long epochTime = System.currentTimeMillis();
		long[] updateTs = { epochTime - 1000, epochTime - 2000,
				epochTime - 3000, epochTime - 4000, epochTime - 5000 };
		for (int i = 0; i < 5; i++) {
			jdbcTemplate.update(muSql, new Object[] { new Integer(muIds[i]),
					String.valueOf((muIds[i])), muStautus[i],
					new Integer(muCpus[i]) });
			jdbcTemplate.update(extratLoadSql, new Object[] {
					new Integer(muIds[i]), new Integer(muPressure[i]),
					new Long(updateTs[i]) });
			jdbcTemplate.update(eligibleFunctionsSql, new Object[] {
					new Integer(muIds[i]), new Integer(muFunctionId[i]) });
			jdbcTemplate.execute("commit");
		}

		MuRemainLots firstMuRemainLots = null;
		try {
			firstMuRemainLots = fEPlannerDAO.getfirstMuRemainLots(maxMulots);
		} catch (DataAccessException e) {
			e.printStackTrace();
		}
		Assert.assertNull(firstMuRemainLots);
	}

	@Test
	public void testGetfirstMuRemainLots_zeroRemainLots_not_selected() {
		int maxMulots = 5;
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		String extratLoadSql = "INSERT INTO MU_EXTRACT_LOAD (MU_ID, PRESSURE, UPDATE_TS)  VALUES(?,?,?)";
		String eligibleFunctionsSql = "INSERT INTO MU_ELIGIBLE_FUNCTIONS (MU_ID,FUNCTION_ID) VALUES(?,?)";
		int[] muIds = { 1000, 1001, 1002, 1003, 1004 };
		String[] muStautus = { "WORKING", "EXIT", "WORKING", "WORKING",
				"WORKING" };
		int[] muCpus = { 4, 8, 4, 4, 4 };
		int[] muPressure = { 1, 2, 3, 4, 5 };
		int[] muFunctionId = { 17, 17, 17, 17, 17 };
		long epochTime = System.currentTimeMillis();
		long[] updateTs = { epochTime - 1000, epochTime - 2000,
				epochTime - 3000, epochTime - 4000, epochTime - 5000 };
		for (int i = 0; i < 5; i++) {
			jdbcTemplate.update(muSql, new Object[] { new Integer(muIds[i]),
					String.valueOf((muIds[i])), muStautus[i],
					new Integer(muCpus[i]) });
			jdbcTemplate.update(extratLoadSql, new Object[] {
					new Integer(muIds[i]), new Integer(muPressure[i]),
					new Long(updateTs[i]) });
			jdbcTemplate.update(eligibleFunctionsSql, new Object[] {
					new Integer(muIds[i]), new Integer(muFunctionId[i]) });
			jdbcTemplate.execute("commit");

		}
		MuRemainLots firstMuRemainLots = null;
		try {
			firstMuRemainLots = fEPlannerDAO.getfirstMuRemainLots(maxMulots);
		} catch (DataAccessException e) {
			e.printStackTrace();
		}
		Assert.assertNotNull(firstMuRemainLots);
		Assert.assertNotEquals(1004, firstMuRemainLots.getMuId().intValue());
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testProcessOneMuList_normal() {
		Long muId = 1000L;
		Integer muCpu = 4;
		MuRemainLots muRemainLot = new MuRemainLots();
		muRemainLot.setMuId(muId);
		muRemainLot.setNumOfExtractor(muCpu);
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		jdbcTemplate.update(muSql, new Object[] { muId, String.valueOf((muId)),
				"WORKING", new Integer(muCpu) });

		long assignedTS = System.currentTimeMillis();
		Long[] feJobIds = { 3000L, 3001L, 3002L, 3003L, 3004L };

		Integer[] priotity = { 2, 2, 2, 3, 2 };
		Integer[] states = { 0, 0, 0, 0, 0 };
		Integer[] failureCount = { 0, 1, 2, 2, 1 };

		String feJobSql = "insert into fe_job_queue(job_id,mu_id,function_id,PRIORITY,job_state,failure_count,submission_ts,CALLBACK_STYLE)"
				+ " values(?,?,17,?,?,?,?,0)";
		for (int i = 0; i < feJobIds.length; i++) {
			jdbcTemplate.update(feJobSql, new Object[] { feJobIds[i], muId,
					priotity[i], states[i], failureCount[i],
					new Long(assignedTS) });
		}

		String topJobtimeOutValueSql = " SELECT top_level_job_timeouts"
				+ " FROM function_types " + " WHERE function_id = 17"
				+ "AND queue_type = 1";
		Long topJobtimeOutValue = jdbcTemplate.queryForObject(
				topJobtimeOutValueSql, Long.class);
		topJobtimeOutValue = topJobtimeOutValue * muCpu;
		String muExtractLoadInsSqL = "insert into mu_extract_load(mu_id,pressure,update_ts)values(?,0,1000)";
		jdbcTemplate.update(muExtractLoadInsSqL, new Object[] { muId });

		jdbcTemplate.execute("commit");
		Long lotJobId = null;

		try {
			lotJobId = fEPlannerDAO.processOneMuLot(muRemainLot);
		} catch (DataAccessException e) {
			e.printStackTrace();
		}
		Assert.assertTrue(lotJobId.longValue() > 0);
		FeLotJobEntity feLotJob = entityManager.find(FeLotJobEntity.class,
				lotJobId);
		Assert.assertNotNull(topJobtimeOutValue);
		Assert.assertEquals(topJobtimeOutValue.longValue(),
				feLotJob.getTimeouts());
		Assert.assertEquals(muId.intValue(), feLotJob.getMuId());
		String muExLoadSql = "from MuExtractLoadEntity ml where ml.muId =:muid";
		Query q = entityManager.createQuery(muExLoadSql);
		q.setParameter("muid", muId.longValue());
		MuExtractLoadEntity muLoad = (MuExtractLoadEntity) q.getSingleResult();
		Assert.assertNotNull(muLoad);
		Assert.assertTrue((muLoad.getPressure() >= 1L));
		Assert.assertTrue((muLoad.getUpdateTs() != null));
		String seleFeQSql = "from FeJobQueueEntity fq where fq.lotJobId=:felotJobId";
		Query query = entityManager.createQuery(seleFeQSql);
		query.setParameter("felotJobId", lotJobId.longValue());
		List<FeJobQueueEntity> fqJobs = query.getResultList();
		Assert.assertEquals(4, fqJobs.size());
		for (int i = 0; i < fqJobs.size(); i++) {
			Assert.assertEquals(muId.intValue(), fqJobs.get(i).getMuId()
					.intValue());
			Assert.assertEquals("WORKING", fqJobs.get(i).getStatus().toString());
			Assert.assertNotNull(fqJobs.get(i).getAssignedTs());
		}
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testProcessOneMuList_feJob1_proority_selected() {
		Long muId = 1000L;
		Integer muCpu = 4;
		MuRemainLots muRemainLot = new MuRemainLots();
		muRemainLot.setMuId(muId);
		muRemainLot.setNumOfExtractor(muCpu);
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		jdbcTemplate.update(muSql, new Object[] { muId, String.valueOf((muId)),
				"WORKING", new Integer(muCpu) });

		long assignedTS = System.currentTimeMillis();
		Long[] feJobIds = { 3000L, 3001L, 3002L, 3003L, 3004L };

		Integer[] priotity = { 1, 2, 2, 3, 2 };
		Integer[] states = { 0, 0, 0, 0, 0 };
		Integer[] failureCount = { 0, 1, 2, 2, 1 };

		String feJobSql = "insert into fe_job_queue(job_id,mu_id,function_id,PRIORITY,job_state,failure_count,submission_ts,CALLBACK_STYLE)"
				+ " values(?,?,17,?,?,?,?,0)";
		for (int i = 0; i < feJobIds.length; i++) {
			jdbcTemplate.update(feJobSql, new Object[] { feJobIds[i], muId,
					priotity[i], states[i], failureCount[i],
					new Long(assignedTS) });
		}

		String topJobtimeOutValueSql = " SELECT top_level_job_timeouts"
				+ " FROM function_types " + " WHERE function_id = 17"
				+ "AND queue_type = 1";
		Long topJobtimeOutValue = jdbcTemplate.queryForObject(
				topJobtimeOutValueSql, Long.class);
		topJobtimeOutValue = topJobtimeOutValue * 1;
		String muExtractLoadInsSqL = "insert into mu_extract_load(mu_id,pressure,update_ts)values(?,0,1000)";
		jdbcTemplate.update(muExtractLoadInsSqL, new Object[] { muId });

		jdbcTemplate.execute("commit");
		Long lotJobId = null;

		try {
			lotJobId = fEPlannerDAO.processOneMuLot(muRemainLot);
		} catch (DataAccessException e) {
			e.printStackTrace();
		}
		Assert.assertTrue(lotJobId.longValue() > 0);
		FeLotJobEntity feLotJob = entityManager.find(FeLotJobEntity.class,
				lotJobId);
		Assert.assertNotNull(topJobtimeOutValue);
		Assert.assertEquals(topJobtimeOutValue.longValue(),
				feLotJob.getTimeouts());
		Assert.assertEquals(muId.intValue(), feLotJob.getMuId());
		String muExLoadSql = "from MuExtractLoadEntity ml where ml.muId =:muid";
		Query q = entityManager.createQuery(muExLoadSql);
		q.setParameter("muid", muId.longValue());
		MuExtractLoadEntity muLoad = (MuExtractLoadEntity) q.getSingleResult();
		Assert.assertNotNull(muLoad);
		Assert.assertTrue((muLoad.getPressure() >= 1L));
		Assert.assertTrue((muLoad.getUpdateTs() != null));
		String seleFeQSql = "from FeJobQueueEntity fq where fq.lotJobId=:felotJobId";
		Query query = entityManager.createQuery(seleFeQSql);
		query.setParameter("felotJobId", lotJobId.longValue());
		List<FeJobQueueEntity> fqJobs = query.getResultList();
		Assert.assertEquals(1, fqJobs.size());
		for (int i = 0; i < fqJobs.size(); i++) {
			Assert.assertEquals(muId.intValue(), fqJobs.get(i).getMuId()
					.intValue());
			Assert.assertEquals("WORKING", fqJobs.get(i).getStatus().toString());
			Assert.assertNotNull(fqJobs.get(i).getAssignedTs());
			Assert.assertEquals(1, fqJobs.get(i).getPriority());
		}
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testProcessOneMuList_second_maxFailureCount_selected() {
		Long muId = 1000L;
		Integer muCpu = 2;
		MuRemainLots muRemainLot = new MuRemainLots();
		muRemainLot.setMuId(muId);
		muRemainLot.setNumOfExtractor(muCpu);
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		jdbcTemplate.update(muSql, new Object[] { muId, String.valueOf((muId)),
				"WORKING", new Integer(muCpu) });

		long assignedTS = System.currentTimeMillis();
		Long[] feJobIds = { 3000L, 3001L, 3002L, 3003L, 3004L };

		Integer[] priotity = { 2, 2, 2, 2, 2 };
		Integer[] states = { 0, 0, 0, 0, 0 };
		Integer[] failureCount = { 0, 1, 3, 4, 5 };

		String feJobSql = "insert into fe_job_queue(job_id,mu_id,function_id,PRIORITY,job_state,failure_count,submission_ts,CALLBACK_STYLE)"
				+ " values(?,?,17,?,?,?,?,0)";
		for (int i = 0; i < feJobIds.length; i++) {
			jdbcTemplate.update(feJobSql, new Object[] { feJobIds[i], muId,
					priotity[i], states[i], failureCount[i],
					new Long(assignedTS) });
		}

		String topJobtimeOutValueSql = " SELECT top_level_job_timeouts"
				+ " FROM function_types " + " WHERE function_id = 17"
				+ "AND queue_type = 1";
		Long topJobtimeOutValue = jdbcTemplate.queryForObject(
				topJobtimeOutValueSql, Long.class);
		topJobtimeOutValue = topJobtimeOutValue * muCpu;
		String muExtractLoadInsSqL = "insert into mu_extract_load(mu_id,pressure,update_ts)values(?,0,1000)";
		jdbcTemplate.update(muExtractLoadInsSqL, new Object[] { muId });
		jdbcTemplate.execute("commit");
		Long lotJobId = null;

		try {
			lotJobId = fEPlannerDAO.processOneMuLot(muRemainLot);
		} catch (DataAccessException e) {
			e.printStackTrace();
		}
		Assert.assertTrue(lotJobId.longValue() > 0);
		FeLotJobEntity feLotJob = entityManager.find(FeLotJobEntity.class,
				lotJobId);
		Assert.assertNotNull(topJobtimeOutValue);
		Assert.assertEquals(topJobtimeOutValue.longValue(),
				feLotJob.getTimeouts());
		Assert.assertEquals(muId.intValue(), feLotJob.getMuId());
		String muExLoadSql = "from MuExtractLoadEntity ml where ml.muId =:muid";
		Query q = entityManager.createQuery(muExLoadSql);
		q.setParameter("muid", muId.longValue());
		MuExtractLoadEntity muLoad = (MuExtractLoadEntity) q.getSingleResult();
		Assert.assertNotNull(muLoad);
		Assert.assertTrue((muLoad.getPressure() >= 1L));
		Assert.assertTrue((muLoad.getUpdateTs() != null));
		String seleFeQSql = "from FeJobQueueEntity fq where fq.lotJobId=:felotJobId";
		Query query = entityManager.createQuery(seleFeQSql);
		query.setParameter("felotJobId", lotJobId.longValue());
		List<FeJobQueueEntity> fqJobs = query.getResultList();
		Assert.assertEquals(2, fqJobs.size());

		Assert.assertEquals(muId.intValue(), fqJobs.get(0).getMuId().intValue());
		Assert.assertEquals("WORKING", fqJobs.get(0).getStatus().toString());
		Assert.assertNotNull(fqJobs.get(0).getAssignedTs());
		Assert.assertEquals(2, fqJobs.get(0).getPriority());

		Assert.assertEquals(muId.intValue(), fqJobs.get(0).getMuId().intValue());
		Assert.assertEquals("WORKING", fqJobs.get(0).getStatus().toString());
		Assert.assertNotNull(fqJobs.get(1).getAssignedTs());
		Assert.assertEquals(2, fqJobs.get(1).getPriority());
		Assert.assertEquals(5, fqJobs.get(1).getFailureCount().intValue());

	}

	@Test
	public void testProcessOneMuList_no_feJob_selected() {
		Long muId = 1000L;
		Integer muCpu = 4;
		MuRemainLots muRemainLot = new MuRemainLots();
		muRemainLot.setMuId(muId);
		muRemainLot.setNumOfExtractor(muCpu);
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		jdbcTemplate.update(muSql, new Object[] { muId, String.valueOf((muId)),
				"WORKING", new Integer(muCpu) });

		long assignedTS = System.currentTimeMillis();
		Long[] feJobIds = { 3000L, 3001L, 3002L, 3003L, 3004L };

		Integer[] priotity = { 2, 2, 2, 3, 2 };
		Integer[] states = { 2, 2, 2, 1, 1 };
		Integer[] failureCount = { 0, 1, 2, 2, 1 };

		String feJobSql = "insert into fe_job_queue(job_id,mu_id,function_id,PRIORITY,job_state,failure_count,submission_ts,CALLBACK_STYLE)"
				+ " values(?,?,17,?,?,?,?,0)";
		for (int i = 0; i < feJobIds.length; i++) {
			jdbcTemplate.update(feJobSql, new Object[] { feJobIds[i], muId,
					priotity[i], states[i], failureCount[i],
					new Long(assignedTS) });
		}

		String topJobtimeOutValueSql = " SELECT top_level_job_timeouts"
				+ " FROM function_types " + " WHERE function_id = 17"
				+ "AND queue_type = 1";
		Long topJobtimeOutValue = jdbcTemplate.queryForObject(
				topJobtimeOutValueSql, Long.class);
		topJobtimeOutValue = topJobtimeOutValue * muCpu;
		String muExtractLoadInsSqL = "insert into mu_extract_load(mu_id,pressure,update_ts)values(?,0,1000)";
		jdbcTemplate.update(muExtractLoadInsSqL, new Object[] { muId });
		jdbcTemplate.execute("commit");
		try {
			Long lotJobId = fEPlannerDAO.processOneMuLot(muRemainLot);
			Assert.assertNull(lotJobId);
		} catch (DataAccessException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testProcessOneMuList_all_feJob_no_state0() {
		Long muId = 1000L;
		Integer muCpu = 1;
		MuRemainLots muRemainLot = new MuRemainLots();
		muRemainLot.setMuId(muId);
		muRemainLot.setNumOfExtractor(muCpu);
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		jdbcTemplate.update(muSql, new Object[] { muId, String.valueOf((muId)),
				"WORKING", new Integer(muCpu) });

		long assignedTS = System.currentTimeMillis();
		Long[] feJobIds = { 3000L, 3001L, 3002L, 3003L, 3004L };

		Integer[] priotity = { 2, 2, 2, 3, 2 };
		Integer[] states = { 2, 2, 2, 1, 1 };
		Integer[] failureCount = { 0, 1, 2, 2, 1 };

		String feJobSql = "insert into fe_job_queue(job_id,mu_id,function_id,PRIORITY,job_state,failure_count,submission_ts,CALLBACK_STYLE)"
				+ " values(?,?,17,?,?,?,?,0)";
		for (int i = 0; i < feJobIds.length; i++) {
			jdbcTemplate.update(feJobSql, new Object[] { feJobIds[i], muId,
					priotity[i], states[i], failureCount[i],
					new Long(assignedTS) });
		}

		String topJobtimeOutValueSql = " SELECT top_level_job_timeouts"
				+ " FROM function_types " + " WHERE function_id = 17"
				+ "AND queue_type = 1";
		Long topJobtimeOutValue = jdbcTemplate.queryForObject(
				topJobtimeOutValueSql, Long.class);
		topJobtimeOutValue = topJobtimeOutValue * muCpu;
		String muExtractLoadInsSqL = "insert into mu_extract_load(mu_id,pressure,update_ts)values(?,0,1000)";
		jdbcTemplate.update(muExtractLoadInsSqL, new Object[] { muId });
		jdbcTemplate.execute("commit");
		try {
			Long lotJobId = fEPlannerDAO.processOneMuLot(muRemainLot);
			Assert.assertNull(lotJobId);
		} catch (DataAccessException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testSetPressureToMaxLot() {
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID,CONTACT_URL, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(1,'1','http//www.jp.co.nec.com','WORKING',5)";
		jdbcTemplate.execute(muSql);
		String insertMuExtractLoadSql = "insert into mu_extract_load(mu_id,pressure,update_ts) values(1,15,3000)";
		jdbcTemplate.execute(insertMuExtractLoadSql);
		jdbcTemplate.execute("commit");
		try {
			fEPlannerDAO.setPressureToMaxLot(1L, 10L);
		} catch (PersistenceException | SQLException e) {
			e.printStackTrace();
		}
		String selectPressureSql = "select pressure from mu_extract_load where mu_id = 1";
		Long results = jdbcTemplate.queryForObject(selectPressureSql,
				Long.class);
		Assert.assertEquals(10l, results.longValue());
	}

	@Test
	public void testGetCurretMuLots() {
		long muId = 1000l;
		long pressue = 8l;
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,'WORKING',4)";
		String extratLoadSql = "INSERT INTO MU_EXTRACT_LOAD (MU_ID, PRESSURE, UPDATE_TS)  VALUES(?,?,1000)";
		jdbcTemplate.update(muSql,
				new Object[] { new Long(muId), String.valueOf(muId) });
		jdbcTemplate.update(extratLoadSql, new Object[] { new Long(muId),
				new Long(pressue) });
		try {
			long result = fEPlannerDAO.getCurretMuLots(muId);
			Assert.assertEquals(pressue, result);
		} catch (DataAccessException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testLockAndGetfirstMuRemainLots_null() {
		int maxMulots = 12;
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		String extratLoadSql = "INSERT INTO MU_EXTRACT_LOAD (MU_ID, PRESSURE, UPDATE_TS)  VALUES(?,?,?)";
		String eligibleFunctionsSql = "INSERT INTO MU_ELIGIBLE_FUNCTIONS (MU_ID,FUNCTION_ID) VALUES(?,?)";
		int[] muIds = { 1000, 1001, 1002, 1003, 1004 };
		String[] muStautus = { "EXIT", "EXIT", "EXIT", "EXIT", "EXIT" };
		int[] muCpus = { 4, 8, 4, 4, 4 };
		int[] muPressure = { 4, 5, 6, 7, 8 };
		int[] muFunctionId = { 17, 17, 17, 17, 17 };
		long epochTime = System.currentTimeMillis();
		for (int i = 0; i < 5; i++) {
			jdbcTemplate.update(muSql, new Object[] { new Integer(muIds[i]),
					String.valueOf((muIds[i])), muStautus[i],
					new Integer(muCpus[i]) });
			jdbcTemplate.update(extratLoadSql, new Object[] {
					new Integer(muIds[i]), new Integer(muPressure[i]),
					new Long(epochTime) });
			jdbcTemplate.update(eligibleFunctionsSql, new Object[] {
					new Integer(muIds[i]), new Integer(muFunctionId[i]) });
			jdbcTemplate.execute("commit");

		}
		MuRemainLots firstMuRemainLots = null;
		try {
			firstMuRemainLots = fEPlannerDAO
					.lockAndGetfirstMuRemainLots(maxMulots);
		} catch (DataAccessException e) {
			e.printStackTrace();
		}
		Assert.assertNull(firstMuRemainLots);
	}

	@Test
	public void testLockAndGetfirstMuRemainLots() {
		int maxMulots = 12;
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		String extratLoadSql = "INSERT INTO MU_EXTRACT_LOAD (MU_ID, PRESSURE, UPDATE_TS)  VALUES(?,?,?)";
		String eligibleFunctionsSql = "INSERT INTO MU_ELIGIBLE_FUNCTIONS (MU_ID,FUNCTION_ID) VALUES(?,?)";
		int[] muIds = { 1000, 1001, 1002, 1003, 1004 };
		String[] muStautus = { "WORKING", "EXIT", "WORKING", "WORKING",
				"WORKING" };
		int[] muCpus = { 4, 8, 4, 4, 4 };
		int[] muPressure = { 4, 5, 6, 7, 8 };
		int[] muFunctionId = { 17, 17, 17, 17, 17 };
		long epochTime = System.currentTimeMillis();
		for (int i = 0; i < 5; i++) {
			jdbcTemplate.update(muSql, new Object[] { new Integer(muIds[i]),
					String.valueOf((muIds[i])), muStautus[i],
					new Integer(muCpus[i]) });
			jdbcTemplate.update(extratLoadSql, new Object[] {
					new Integer(muIds[i]), new Integer(muPressure[i]),
					new Long(epochTime) });
			jdbcTemplate.update(eligibleFunctionsSql, new Object[] {
					new Integer(muIds[i]), new Integer(muFunctionId[i]) });
			jdbcTemplate.execute("commit");

		}
		MuRemainLots firstMuRemainLots = null;
		try {
			firstMuRemainLots = fEPlannerDAO
					.lockAndGetfirstMuRemainLots(maxMulots);
		} catch (DataAccessException e) {
			e.printStackTrace();
		}
		Assert.assertNotNull(firstMuRemainLots);
		Assert.assertEquals(1000, firstMuRemainLots.getMuId().intValue());
	}

	@Test
	public void testDeleteFeLotJob() {
		String feJobSql = "insert into fe_job_queue(job_id,function_id,PRIORITY,job_state,failure_count,submission_ts,CALLBACK_STYLE)"
				+ " values(100,17,1,0,0,3000,0)";
		jdbcTemplate.update(feJobSql);
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(1,'1','queued',4)";
		jdbcTemplate.update(muSql);
		String extratLoadSql = "INSERT INTO MU_EXTRACT_LOAD (MU_ID, PRESSURE, UPDATE_TS)  VALUES(1,3,1000)";
		jdbcTemplate.update(extratLoadSql);
		String feLotJobdSql = "INSERT INTO fe_lot_jobs (LOT_JOB_ID,MU_ID, ASSIGNED_TS, TIMEOUTS)  VALUES(200,1,1000,0)";
		jdbcTemplate.update(feLotJobdSql);
		jdbcTemplate.execute("commit");
		fEPlannerDAO.deleteFeLotJob(new Long(200));
		Integer result = fEPlannerDAO.getFeLotJobCount(new Long(200));
		Assert.assertEquals(null, result);
	}

	@Test
	public void testRollbackFeLotJobRelated() {
		Long[] feJobIds = { 300L, 301L, 302L };
		Long feLotJobId = 200L;
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(1,'1','queued',4)";
		jdbcTemplate.update(muSql);
		String feLotJobdSql = "INSERT INTO fe_lot_jobs (LOT_JOB_ID,MU_ID, ASSIGNED_TS, TIMEOUTS)  VALUES(200,1,1000,0)";
		jdbcTemplate.update(feLotJobdSql);
		String feJobSql = "insert into fe_job_queue(job_id,lot_job_id,function_id,PRIORITY,job_state,failure_count,submission_ts,CALLBACK_STYLE)"
				+ " values(?,?,17,1,0,0,3000,0)";
		for (int i = 0; i < feJobIds.length; i++) {
			jdbcTemplate.update(feJobSql, new Object[] { feJobIds[i],
					feLotJobId });
		}

		String extratLoadSql = "INSERT INTO MU_EXTRACT_LOAD (MU_ID, PRESSURE, UPDATE_TS)  VALUES(1,1,1000)";
		jdbcTemplate.update(extratLoadSql);
		jdbcTemplate.execute("commit");
		fEPlannerDAO.rollbackFeLotJobRelated(new Long(200), new Long(1l));
		Integer result = fEPlannerDAO.getFeLotJobCount(new Long(200));
		Assert.assertEquals(null, result);

		String querySql = "select pressure from  mu_extract_load ml where ml.mu_id = ?";
		int newPressure = jdbcTemplate.queryForObject(querySql,
				new Object[] { new Integer(1) }, Integer.class);
		Assert.assertEquals(0, newPressure);

		String selFeJobSql = "select fq.lot_job_id,fq.mu_id,fq.assigned_ts from fe_job_queue fq where fq.lot_job_id = ?";
		List<Map<String, Object>> results = jdbcTemplate.queryForList(
				selFeJobSql, new Object[] { feLotJobId });
		for (int i = 0; i < results.size(); i++) {
			Assert.assertEquals(null, results.get(i).get("lot_job_id"));
			Assert.assertEquals(null, results.get(i).get("mu_id"));
			Assert.assertEquals(null, results.get(i).get("assigned_ts"));
		}

	}

	@Test
	public void testRollbackMuExtractLoad() {
		String feJobSql = "insert into fe_job_queue(job_id,function_id,PRIORITY,job_state,failure_count,submission_ts,CALLBACK_STYLE)"
				+ " values(100,17,1,0,0,3000,0)";
		jdbcTemplate.update(feJobSql);
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(1,'1','queued',4)";
		jdbcTemplate.update(muSql);
		String extratLoadSql = "INSERT INTO MU_EXTRACT_LOAD (MU_ID, PRESSURE, UPDATE_TS)  VALUES(1,3,1000)";
		jdbcTemplate.update(extratLoadSql);
		String feLotJobdSql = "INSERT INTO fe_lot_jobs (LOT_JOB_ID,MU_ID, ASSIGNED_TS, TIMEOUTS)  VALUES(200,1,1000,0)";
		jdbcTemplate.update(feLotJobdSql);
		jdbcTemplate.execute("commit");
		fEPlannerDAO.rollbackMuExtractLoad(new Long(1l));
		String querySql = "select pressure from  mu_extract_load ml where ml.mu_id = ?";
		int newPressure = jdbcTemplate.queryForObject(querySql,
				new Object[] { new Integer(1) }, Integer.class);
		Assert.assertEquals(3 - 1, newPressure);
	}

	@Test
	public void testRollbackMuExtractLoad_minus() {
		String feJobSql = "insert into fe_job_queue(job_id,function_id,PRIORITY,job_state,failure_count,submission_ts,CALLBACK_STYLE)"
				+ " values(100,17,1,0,0,3000,0)";
		jdbcTemplate.update(feJobSql);
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(1,'1','queued',4)";
		jdbcTemplate.update(muSql);
		String extratLoadSql = "INSERT INTO MU_EXTRACT_LOAD (MU_ID, PRESSURE, UPDATE_TS)  VALUES(1,0,1000)";
		jdbcTemplate.update(extratLoadSql);
		String feLotJobdSql = "INSERT INTO fe_lot_jobs (LOT_JOB_ID,MU_ID, ASSIGNED_TS, TIMEOUTS)  VALUES(200,1,1000,0)";
		jdbcTemplate.update(feLotJobdSql);
		jdbcTemplate.execute("commit");
		fEPlannerDAO.rollbackMuExtractLoad(new Long(1L));
		String querySql = "select pressure from  mu_extract_load ml where ml.mu_id = ?";
		int newPressure = jdbcTemplate.queryForObject(querySql,
				new Object[] { new Integer(1) }, Integer.class);
		Assert.assertEquals(0, newPressure);
	}

	@Test
	public void testRollbackFeJobQueue_zero() {
		String feJobSql = "insert into fe_job_queue(job_id,function_id,PRIORITY,job_state,failure_count,submission_ts,CALLBACK_STYLE)"
				+ " values(100,17,1,0,0,3000,0)";
		jdbcTemplate.update(feJobSql);
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(1,'1','queued',4)";
		jdbcTemplate.update(muSql);
		String extratLoadSql = "INSERT INTO MU_EXTRACT_LOAD (MU_ID, PRESSURE, UPDATE_TS)  VALUES(1,1,1000)";
		jdbcTemplate.update(extratLoadSql);
		String feLotJobdSql = "INSERT INTO fe_lot_jobs (LOT_JOB_ID,MU_ID, ASSIGNED_TS, TIMEOUTS)  VALUES(200,1,1000,0)";
		jdbcTemplate.update(feLotJobdSql);
		jdbcTemplate.execute("commit");
		fEPlannerDAO.rollbackMuExtractLoad(new Long(1l));
		String querySql = "select pressure from  mu_extract_load ml where ml.mu_id = ?";
		int newPressure = jdbcTemplate.queryForObject(querySql,
				new Object[] { new Integer(1) }, Integer.class);
		Assert.assertEquals(0, newPressure);
	}

	@Test
	public void testRollbackFeJobQueue() {
		Long[] feJobIds = { 300L, 301L, 302L };
		Long feLotJobId = 200L;
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(1,'1','queued',4)";
		jdbcTemplate.update(muSql);
		String feLotJobdSql = "INSERT INTO fe_lot_jobs (LOT_JOB_ID,MU_ID, ASSIGNED_TS, TIMEOUTS)  VALUES(200,1,1000,0)";
		jdbcTemplate.update(feLotJobdSql);
		String feJobSql = "insert into fe_job_queue(job_id,lot_job_id,function_id,PRIORITY,job_state,failure_count,submission_ts,CALLBACK_STYLE)"
				+ " values(?,?,17,1,0,0,3000,0)";
		for (int i = 0; i < feJobIds.length; i++) {
			jdbcTemplate.update(feJobSql, new Object[] { feJobIds[i],
					feLotJobId });
		}

		String extratLoadSql = "INSERT INTO MU_EXTRACT_LOAD (MU_ID, PRESSURE, UPDATE_TS)  VALUES(1,1,1000)";
		jdbcTemplate.update(extratLoadSql);
		jdbcTemplate.execute("commit");
		fEPlannerDAO.rollbackFeJobQueue(feLotJobId);
		String selFeJobSql = "select fq.lot_job_id,fq.mu_id,fq.assigned_ts from fe_job_queue fq where fq.lot_job_id = ?";
		List<Map<String, Object>> results = jdbcTemplate.queryForList(
				selFeJobSql, new Object[] { feLotJobId });
		for (int i = 0; i < results.size(); i++) {
			Assert.assertEquals(null, results.get(i).get("lot_job_id"));
			Assert.assertEquals(null, results.get(i).get("mu_id"));
			Assert.assertEquals(null, results.get(i).get("assigned_ts"));
		}
	}

}
