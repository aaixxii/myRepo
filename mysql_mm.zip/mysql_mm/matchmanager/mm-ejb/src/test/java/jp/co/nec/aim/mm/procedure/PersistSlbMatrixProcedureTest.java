package jp.co.nec.aim.mm.procedure;

import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.sql.DataSource;
import javax.transaction.Transactional;

import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.loadbalancer.SlbMatrix;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.google.common.collect.Lists;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class PersistSlbMatrixProcedureTest {
	@Resource
	private DataSource ds;
	private PersistSlbMatrixProcedure persistSlbMatrixProcedure;
	@Resource
	private JdbcTemplate jdbcTemplate;

	@Before
	public void setUp() throws Exception {
		persistSlbMatrixProcedure = new PersistSlbMatrixProcedure(ds);
		jdbcTemplate.update("delete from  SEGMENTS");
		jdbcTemplate.update("delete from  DM_SEGMENTS");
		jdbcTemplate.update("delete from MU_SEGMENTS");
		jdbcTemplate.update("delete from  MATCH_UNITS");
		jdbcTemplate.update("delete from  DATA_MANAGERS");
		jdbcTemplate.update("commit");
	}

	@After
	public void tearDown() throws Exception {
		persistSlbMatrixProcedure = new PersistSlbMatrixProcedure(ds);
		jdbcTemplate.update("delete from  SEGMENTS");
		jdbcTemplate.update("delete from  DM_SEGMENTS");
		jdbcTemplate.update("delete from MU_SEGMENTS");
		jdbcTemplate.update("delete from  MATCH_UNITS");
		jdbcTemplate.update("delete from  DATA_MANAGERS");
		jdbcTemplate.update("commit");
	}
	
	@Test
	public void listToString() {
		List< SlbMatrix> matrixList = new ArrayList<>();
		SlbMatrix sx = new SlbMatrix();
		sx.setUnitId(199L);
		sx.setSegId(100L);
		matrixList.add(sx);
		SlbMatrix sx1 = new SlbMatrix();
		sx1.setUnitId(198L);
		sx1.setSegId(100L);
		matrixList.add(sx1);
		SlbMatrix sx2 = new SlbMatrix();
		sx2.setUnitId(197L);
		sx2.setSegId(1000L);
		matrixList.add(sx2);
		
		StringBuilder sb = new StringBuilder();
		matrixList.forEach(one -> {			
			sb.append(one.getUnitId());
			sb.append(":");
			sb.append(one.getSegId());
			sb.append(",");			
		});	
		String strMatrix = sb.toString();
		strMatrix = strMatrix.substring(0, strMatrix.length() -1);
		System.out.print(strMatrix);		
	}

	@Test
	public void testExecuteMU() {
		jdbcTemplate
				.update("INSERT INTO MATCH_UNITS(MU_ID, UNIQUE_ID, STATE, NUMBER_OF_MATCHERS,REPORTED_PERFORMANCE_FACTOR)VALUES(1,1,1,1,1)");
		jdbcTemplate
				.update("insert into SEGMENTS(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(1,1,1,1,26,1,1,1,26)");
		jdbcTemplate
				.update("insert into SEGMENTS(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(2,1,1,1,26,1,1,1,26)");
		jdbcTemplate
				.update("insert into SEGMENTS(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(3,1,1,1,26,1,1,1,26)");
		jdbcTemplate
				.update("insert into SEGMENTS(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(4,2,1,1,26,1,1,1,26)");
		jdbcTemplate.update("insert into MU_SEGMENTS values(1,1,0)");
		jdbcTemplate.update("insert into MU_SEGMENTS values(1,3,0)");
		jdbcTemplate.update("insert into MU_SEGMENTS values(1,4,0)");
		jdbcTemplate.update("commit");
		List<SlbMatrix> slbMatrixs = Lists.newArrayList();
		SlbMatrix slbMatrix = new SlbMatrix();
		slbMatrix.setSegId(1l);
		slbMatrix.setUnitId(1l);
		SlbMatrix slbMatrix1 = new SlbMatrix();
		slbMatrix1.setSegId(2l);
		slbMatrix1.setUnitId(1l);
		slbMatrixs.add(slbMatrix);
		slbMatrixs.add(slbMatrix1);
		persistSlbMatrixProcedure.setContainerId(1);
		persistSlbMatrixProcedure.setUnitType(3);
		persistSlbMatrixProcedure.getMatrixs().addAll(slbMatrixs);
		persistSlbMatrixProcedure.execute();
		jdbcTemplate.update("commit");
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from MU_SEGMENTS");
		Assert.assertEquals(3, list.size());
		List<Integer> list2 = Lists.newArrayList();
		list2.add(1);
		list2.add(3);
		list2.add(4);
		Assert.assertTrue(list2.contains(Integer.parseInt(list.get(0)
				.get("SEGMENT_ID").toString())));
		Assert.assertTrue(list2.contains(Integer.parseInt(list.get(1)
				.get("SEGMENT_ID").toString())));
		Assert.assertTrue(list2.contains(Integer.parseInt(list.get(2)
				.get("SEGMENT_ID").toString())));

	}

	@Test
	public void testExecuteDM() {
		jdbcTemplate
				.update("INSERT INTO DATA_MANAGERS (DM_ID, UNIQUE_ID, STATE)VALUES(1,1,1)");
		jdbcTemplate
				.update("insert into SEGMENTS(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(1,1,1,1,26,1,1,1,26)");
		jdbcTemplate
				.update("insert into SEGMENTS(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(2,1,1,1,26,1,1,1,26)");
		jdbcTemplate
				.update("insert into SEGMENTS(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(3,1,1,1,26,1,1,1,26)");
		jdbcTemplate.update("insert into DM_SEGMENTS values(1,1,0)");
		jdbcTemplate.update("insert into DM_SEGMENTS values(1,3,0)");
		jdbcTemplate.update("commit");
		List<SlbMatrix> slbMatrixs = Lists.newArrayList();
		SlbMatrix slbMatrix = new SlbMatrix();
		slbMatrix.setSegId(1l);
		slbMatrix.setUnitId(1l);
		SlbMatrix slbMatrix1 = new SlbMatrix();
		slbMatrix1.setSegId(2l);
		slbMatrix1.setUnitId(1l);
		slbMatrixs.add(slbMatrix);
		slbMatrixs.add(slbMatrix1);
		persistSlbMatrixProcedure.setContainerId(1);
		persistSlbMatrixProcedure.setUnitType(1);
		persistSlbMatrixProcedure.getMatrixs().addAll(slbMatrixs);
		persistSlbMatrixProcedure.execute();
		jdbcTemplate.update("commit");
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from DM_SEGMENTS");
		Assert.assertEquals(2, list.size());
		List<Integer> list2 = Lists.newArrayList();
		list2.add(1);
		list2.add(3);
		Assert.assertTrue(list2.contains(Integer.parseInt(list.get(0)
				.get("SEGMENT_ID").toString())));
		Assert.assertTrue(list2.contains(Integer.parseInt(list.get(1)
				.get("SEGMENT_ID").toString())));

	}

	@Test
	public void testExecuteNOmatrixs() {
		jdbcTemplate
				.update("INSERT INTO DATA_MANAGERS (DM_ID, UNIQUE_ID, STATE)VALUES(1,1,1)");
		jdbcTemplate
				.update("insert into SEGMENTS(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(1,1,1,1,26,1,1,1,26)");
		jdbcTemplate
				.update("insert into SEGMENTS(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(2,1,1,1,26,1,1,1,26)");
		jdbcTemplate
				.update("insert into SEGMENTS(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(3,1,1,1,26,1,1,1,26)");
		jdbcTemplate.update("insert into DM_SEGMENTS values(1,1,0)");
		jdbcTemplate.update("insert into DM_SEGMENTS values(1,3,0)");
		jdbcTemplate.update("commit");
		List<SlbMatrix> slbMatrixs = Lists.newArrayList();
		persistSlbMatrixProcedure.setContainerId(1);
		persistSlbMatrixProcedure.setUnitType(1);
		persistSlbMatrixProcedure.getMatrixs().addAll(slbMatrixs);
		try {
			persistSlbMatrixProcedure.execute();
		} catch (Exception e) {
			Assert.assertTrue(e instanceof AimRuntimeException);
			Assert.assertEquals("SLB matrixs is null or empty"
					+ " when call PersistSlbMatrixProcedure", e.getMessage());
			return;
		}
		fail();
	}

}
