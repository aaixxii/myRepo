package jp.co.nec.aim.mm.procedure;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.sql.DataSource;
import javax.transaction.Transactional;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class CreateContainerJobProcedureTest {
	@Resource
	private DataSource dataSource;

	@Resource
	private JdbcTemplate jdbcTemplate;

	private CreateContainerJobProcedure createContainerJobProcedure;

	@Before
	public void setUp() throws Exception {
		createContainerJobProcedure = new CreateContainerJobProcedure(
				dataSource);
		jdbcTemplate.update("delete from JOB_QUEUE ");
		jdbcTemplate.update("delete from FUSION_JOBS");
		jdbcTemplate.update("delete from SEGMENTS");
		jdbcTemplate.update("delete from CONTAINER_JOBS ");
		jdbcTemplate
				.update("insert into JOB_QUEUE(JOB_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_URL,CALLBACK_STYLE,TIMEOUTS,FAILURE_COUNT,REMAIN_JOBS,FAMILY_ID)values(1,1,1,123,'11111',0,10,0,0,1)");
		jdbcTemplate.update("commit");
	}

	@After
	public void tearDown() throws Exception {
		jdbcTemplate.update("delete from JOB_QUEUE");
		jdbcTemplate.update("delete from FUSION_JOBS");
		jdbcTemplate.update("delete from SEGMENTS");
		jdbcTemplate.update("delete from CONTAINER_JOBS");
		jdbcTemplate.update("commit");
	}

	@Test
	public void testExcute() {
		jdbcTemplate
				.update("insert into SEGMENTS (SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(1,1,1,1,83,1,1,1,83)");
		byte[] inquiryJobData = { 1, 2, 3 };		
		List<Integer> containerIds = new ArrayList<Integer>();
		containerIds.add(1);
		createContainerJobProcedure.setContainerIds(containerIds);
		
		createContainerJobProcedure.setInquiryJobData(inquiryJobData);
		createContainerJobProcedure.setJobId(new Long(1));
		createContainerJobProcedure.setSearchRequestIndex(1);
		createContainerJobProcedure.setFunctionId(1);
		createContainerJobProcedure.execute();

		List<Map<String, Object>> listContainerJobs = jdbcTemplate
				.queryForList("select * from CONTAINER_JOBS");
		Assert.assertEquals(1, listContainerJobs.size());
		Map<String, Object> mapContainerJobs = listContainerJobs.get(0);
		Assert.assertEquals(1, Integer.parseInt(mapContainerJobs.get(
				"CONTAINER_ID").toString()));
		List<Map<String, Object>> listFusionJobs = jdbcTemplate
				.queryForList("select * from FUSION_JOBS");
		Assert.assertEquals(1, listFusionJobs.size());
		Map<String, Object> mapFusionJobs = listFusionJobs.get(0);
		Assert.assertEquals(1,
				Integer.parseInt(mapFusionJobs.get("FUNCTION_ID").toString()));
		byte[] bytes = (byte[]) mapFusionJobs.get("INQUIRY_JOB_DATA");
		Assert.assertEquals(3, bytes.length);
		int index = 0;
		for (byte data : bytes) {
			Assert.assertEquals(inquiryJobData[index++], data);
		}
		Assert.assertEquals(new Integer(0),
				createContainerJobProcedure.getEmptyJob());

	}

	@Test
	public void testExcuteContainerIds() {
		jdbcTemplate
				.update("insert into SEGMENTS(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(1,1,1,1,83,1,1,1,83)");
		jdbcTemplate
				.update("insert into SEGMENTS(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(2,2,1,1,83,1,1,1,83)");
		byte[] inquiryJobData = { 1, 2, 3 };
		List<Integer> containerIds = new ArrayList<Integer>();
		containerIds.add(1);
		containerIds.add(2);
		createContainerJobProcedure.setContainerIds(containerIds);
		//String result = containerIds.stream().map(one -> String.valueOf(one)).collect(Collectors.joining(","));
		createContainerJobProcedure.setContainerIds(containerIds);
		createContainerJobProcedure.setInquiryJobData(inquiryJobData);
		createContainerJobProcedure.setJobId(new Long(1));
		createContainerJobProcedure.setSearchRequestIndex(1);
		createContainerJobProcedure.setFunctionId(1);
		createContainerJobProcedure.execute();

		List<Map<String, Object>> listContainerJobs = jdbcTemplate
				.queryForList("select * from CONTAINER_JOBS");
		Assert.assertEquals(2, listContainerJobs.size());
		Map<String, Object> mapContainerJobs = listContainerJobs.get(0);
		 Assert.assertEquals(1,
		 Integer.parseInt(mapContainerJobs.get("CONTAINER_ID").toString()));

		List<Map<String, Object>> listFusionJobs = jdbcTemplate
				.queryForList("select * from FUSION_JOBS");
		Assert.assertEquals(1, listFusionJobs.size());
		Map<String, Object> mapFusionJobs = listFusionJobs.get(0);
		Assert.assertEquals(1,
				Integer.parseInt(mapFusionJobs.get("FUNCTION_ID").toString()));
		byte[] bytes = (byte[]) mapFusionJobs.get("INQUIRY_JOB_DATA");
		Assert.assertEquals(3, bytes.length);
		int index = 0;
		for (byte data : bytes) {
			Assert.assertEquals(inquiryJobData[index++], data);
		}
		Assert.assertEquals(new Integer(0),
				createContainerJobProcedure.getEmptyJob());

	}

}
