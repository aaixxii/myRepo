package jp.co.nec.aim.mm.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the PERSON_BIOMETRICS database table.
 * 
 */
@Entity
@Table(name = "PERSON_BIOMETRICS")
@NamedQuery(name = "PersonBiometricEntity.findAll", query = "SELECT p FROM PersonBiometricEntity p")
public class PersonBiometricEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "BIOMETRICS_ID")
	private long biometricsId;

	@Lob
	@Column(name = "BIOMETRIC_DATA")
	private byte[] biometricData;

	@Column(name = "BIOMETRIC_DATA_LEN")
	private long biometricDataLen;

	@Column(name = "CONTAINER_ID")
	private long containerId;

	@Column(name = "CORRUPTED_FLAG")
	private long corruptedFlag;

	@Column(name = "EVENT_ID")
	private long eventId;

	@Column(name = "EXTERNAL_ID")
	private String externalId;

	@Column(name = "REGISTED_TS")
	private long registedTs;

	public PersonBiometricEntity() {
	}

	public long getBiometricsId() {
		return this.biometricsId;
	}

	public void setBiometricsId(long biometricsId) {
		this.biometricsId = biometricsId;
	}

	public byte[] getBiometricData() {
		return this.biometricData;
	}

	public void setBiometricData(byte[] biometricData) {
		this.biometricData = biometricData;
	}

	public long getBiometricDataLen() {
		return this.biometricDataLen;
	}

	public void setBiometricDataLen(long biometricDataLen) {
		this.biometricDataLen = biometricDataLen;
	}

	public long getContainerId() {
		return this.containerId;
	}

	public void setContainerId(long containerId) {
		this.containerId = containerId;
	}

	public long getCorruptedFlag() {
		return this.corruptedFlag;
	}

	public void setCorruptedFlag(long corruptedFlag) {
		this.corruptedFlag = corruptedFlag;
	}

	public long getEventId() {
		return this.eventId;
	}

	public void setEventId(long eventId) {
		this.eventId = eventId;
	}

	public String getExternalId() {
		return this.externalId;
	}

	public void setExternalId(String externalId) {
		this.externalId = externalId;
	}

	public long getRegistedTs() {
		return this.registedTs;
	}

	public void setRegistedTs(long registedTs) {
		this.registedTs = registedTs;
	}

}