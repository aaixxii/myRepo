package jp.co.nec.aim.mm.procedure;

import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import jp.co.nec.aim.mm.logger.PerformanceLogger;
import jp.co.nec.aim.mm.util.StopWatch;

import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.jdbc.support.nativejdbc.CommonsDbcpNativeJdbcExtractor;

/**
 * Sub class of Spring StoredProcedure to call
 * MATCH_MANAGER_API.garbage_seg_change_log()
 * 
 * @author jinxl
 * 
 */
public class GarbageSegChangeLogProcedure extends StoredProcedure {
	private static final String SQL = "garbage_seg_change_log";

	public GarbageSegChangeLogProcedure(DataSource dataSource) {
		setDataSource(dataSource);
		setSql(SQL);
		getJdbcTemplate().setNativeJdbcExtractor(
				new CommonsDbcpNativeJdbcExtractor());
		declareParameter(new SqlOutParameter("r_delete_count", Types.BIGINT));
		compile();
	}

	/**
	 * Delete rows of SGMENT_CHANGE_LOG with default param.
	 * 
	 * @return actual number of deleted rows
	 */
	public long execute() {
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();

		Map<String, Long> map = new HashMap<String, Long>();
		long count = ((Long) execute(map).get("r_delete_count")).longValue();

		stopWatch.stop();
		PerformanceLogger.log(getClass().getSimpleName(), "execute",
				stopWatch.elapsedTime());

		return count;
	}

}
