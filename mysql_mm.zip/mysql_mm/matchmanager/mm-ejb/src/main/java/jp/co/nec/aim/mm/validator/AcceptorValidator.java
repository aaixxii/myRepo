package jp.co.nec.aim.mm.validator;

import static jp.co.nec.aim.mm.constants.AimError.INQ_BINARY_FORMATTYPE;
import static jp.co.nec.aim.mm.constants.AimError.INQ_COMBINE_OF_KEY;
import static jp.co.nec.aim.mm.constants.AimError.INQ_FUSION_LIST;
import static jp.co.nec.aim.mm.constants.AimError.INQ_GET_TEMPLATE;
import static jp.co.nec.aim.mm.constants.AimError.INQ_KEY_INDEXER;
import static jp.co.nec.aim.mm.constants.AimError.INQ_KEY_JOBID;
import static jp.co.nec.aim.mm.constants.AimError.INQ_TEMPLATE_KEY;
import static jp.co.nec.aim.mm.constants.AimError.INQ_TEM_TEMREF;
import static jp.co.nec.aim.mm.constants.AimError.SYNC_BINARY_FORMATTYPE;
import static jp.co.nec.aim.mm.constants.AimError.SYNC_DEL_INDEXER;
import static jp.co.nec.aim.mm.constants.AimError.SYNC_FORMATTYPE;
import static jp.co.nec.aim.mm.constants.AimError.SYNC_FUNCTIONTYPE;
import static jp.co.nec.aim.mm.constants.AimError.SYNC_GET_TEMPLATE;
import static jp.co.nec.aim.mm.constants.AimError.SYNC_INDEXER;
import static jp.co.nec.aim.mm.constants.AimError.SYNC_IN_INSERT_PAYLOAD;
import static jp.co.nec.aim.mm.constants.AimError.SYNC_KEY_INDEXER;
import static jp.co.nec.aim.mm.constants.AimError.SYNC_KEY_JOBID;
import static jp.co.nec.aim.mm.constants.AimError.SYNC_SCOPE;
import static jp.co.nec.aim.mm.constants.AimError.SYNC_TEM_DATA_EMPTY;
import static jp.co.nec.aim.mm.constants.AimError.SYNC_TEM_TEMREF;

import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.sql.DataSource;

import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerPrintType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerSetType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.TemplateFormatType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBInquiryScopeOptions;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplate;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplateData;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplateIndexer;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplateReference;
import jp.co.nec.aim.message.proto.ExtractService.PBExtractJobRequest;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.InquiryFunctionType;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBFusionJobInput;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryFusionWeight;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryJobInfo;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryOptions;
import jp.co.nec.aim.message.proto.InquiryService.PBInquiryJobRequest;
import jp.co.nec.aim.message.proto.SyncEnumTypes.SyncFunctionType;
import jp.co.nec.aim.message.proto.SyncService.PBSyncJobRequest;
import jp.co.nec.aim.message.proto.SyncService.PBSyncJobRequest.PBSyncDeletePayload;
import jp.co.nec.aim.message.proto.SyncService.PBSyncJobRequest.PBSyncInsertPayload;
import jp.co.nec.aim.mm.acceptor.script.ScriptManager;
import jp.co.nec.aim.mm.acceptor.script.ScriptManager.ScriptFunction;
import jp.co.nec.aim.mm.acceptor.script.SearchKey;
import jp.co.nec.aim.mm.acceptor.script.SearchValue;
import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.constants.MMConfigProperty;
import jp.co.nec.aim.mm.dao.DateDao;
import jp.co.nec.aim.mm.dao.FEJobDao;
import jp.co.nec.aim.mm.dao.ServiceLayoutDao;
import jp.co.nec.aim.mm.dao.SystemConfigDao;
import jp.co.nec.aim.mm.entities.FeResultEntity;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.exception.ArgumentException;
import jp.co.nec.aim.mm.exception.ExceptionHelper;
import jp.co.nec.aim.mm.util.CollectionsUtil;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.google.protobuf.ByteString;

/**
 * Validate the Accept protoBuffer Object from client
 * 
 * @author liuyq
 * 
 */
public final class AcceptorValidator {

	/** log instance **/
	private static Logger log = LoggerFactory
			.getLogger(AcceptorValidator.class);

	/** Extract job DAO **/
	private FEJobDao feJobDao;
	/** SystemConfig DAO **/
	private SystemConfigDao confDao;
	/** ServiceLayout DAO **/
	private ServiceLayoutDao layoutDao;
	/** ExceptionHelper instance **/
	private ExceptionHelper exception;
	private ScriptManager scManager;

	/**
	 * AcceptorValidator constructor
	 * 
	 * @param EntityManager
	 */
	public AcceptorValidator(EntityManager em, DataSource dataSource) {
		this.feJobDao = new FEJobDao(em);
		this.confDao = new SystemConfigDao(em);
		this.layoutDao = new ServiceLayoutDao(em);
		this.exception = new ExceptionHelper(new DateDao(dataSource));
		this.scManager = ScriptManager.getInstance();
	}

	/**
	 * check the inquiry instance PBInquiryJobRequest, if any argument logic
	 * exception occurred, throw the argument exception, servLet will response
	 * the aim error code and message to client.
	 * 
	 * @param request
	 *            PBInquiryJobRequest instance
	 * @return PBInquiryJobRequest.Builder Builder instance
	 */
	public PBInquiryJobRequest.Builder checkInquiryJobRequest(
			final PBInquiryJobRequest request) {
		final PBInquiryJobInfo jobInfo = request.getJobInfo();
		final InquiryFunctionType function = jobInfo.getFunction();

		// validate the jobInfo
		validateJobInfo(jobInfo);

		// check keyedTemplateData is not empty
		final List<PBFusionJobInput> l = request.getFusionJobInputList();
		if (CollectionsUtil.isEmpty(l)) {
			exception.throwArgException(INQ_FUSION_LIST);
		}

		// check each KeyedTemplate and keyedReference
		// and convert into new PBFusionJobInput list
		final List<PBFusionJobInput> reGenerate = checkFJobInputsList(function,
				l, false);

		// check the PBKeyedTemplateData list containers invalid function
		checkFunction(reGenerate, function);

		// rebuild the instance PBInquiryJobRequest.Builder
		PBInquiryJobRequest.Builder reBuilder = PBInquiryJobRequest
				.newBuilder().addAllFusionJobInput(reGenerate);
		PBInquiryJobInfo.Builder builder = reBuilder.getJobInfoBuilder()
				.setFunction(jobInfo.getFunction());
		if (jobInfo.hasCallBackUrl()) {
			builder.setCallBackUrl(jobInfo.getCallBackUrl());
		}

		if (jobInfo.hasPriority()) {
			builder.setPriority(jobInfo.getPriority());
		}

		if (jobInfo.hasMaxCandidate()) {
			builder.setMaxCandidate(jobInfo.getMaxCandidate());
		}
		if (jobInfo.hasDynThreshHitThreshold()) {
			builder.setDynThreshHitThreshold(jobInfo.getDynThreshHitThreshold());
		}

		if (jobInfo.hasDynThreshPercentagePoint()) {
			builder.setDynThreshPercentagePoint(jobInfo
					.getDynThreshPercentagePoint());
		}

		return reBuilder;
	}

	/**
	 * check the PBSyncJobRequest instance
	 * 
	 * @param request
	 * @return is check passed
	 * @throws ArgumentException
	 *             SERVLET will receive this exception and response bad request
	 */
	public PBSyncJobRequest.Builder checkSyncJobRequest(
			final PBSyncJobRequest request) throws ArgumentException {
		PBSyncJobRequest.Builder builder = PBSyncJobRequest.newBuilder();
		builder.setFunction(request.getFunction()); // required
		builder.setExternalId(request.getExternalId()); // required
		builder.setEventId(request.hasEventId() ? request.getEventId() : 0); // optional

		final PBSyncInsertPayload insertPayload = request.getInsertPayload(); // optional
		final PBSyncDeletePayload delPayload = request.getDeletePayload(); // optional

		final SyncFunctionType type = request.getFunction();
		switch (type) {
		case INSERT:
			// check the request and return the list
			List<PBKeyedTemplateData> insertDatas = checkInsertRequest(request);
			// mapping to new request
			mapToNewRequest(builder, insertPayload, insertDatas);
			break;
		case DELETE:
			checkDelRequest(request);
			if (request.hasDeletePayload()) {
				builder.setDeletePayload(delPayload);
			}
			break;
		case UPDATE:
			List<PBKeyedTemplateData> updateDatas = checkInsertRequest(request);
			checkDelRequest(request);
			// mapping to new request
			mapToNewRequest(builder, insertPayload, updateDatas);
			if (request.hasDeletePayload()) {
				builder.setDeletePayload(delPayload);
			}
			break;
		default:
			exception.throwArgException(SYNC_FUNCTIONTYPE);
		}
		return builder;
	}

	/**
	 * checkPBExtractJobRequest
	 * 
	 * @param request
	 *            PBExtractJobRequest instance
	 */
	public void checkPBExtractJobRequest(final PBExtractJobRequest request) {
		if (request.hasPriority()) {
			validate(request.getPriority()); // validate the priority
		}
	}

	/**
	 * checkFusionWeight
	 * 
	 * @param function
	 *            InquiryFunctionType instance
	 * @param iOptions
	 *            PBInquiryOptions instance
	 */
	private void checkFusionWeight(
			final Set<PBInquiryFusionWeight> defaultfWeights,
			final PBInquiryOptions iOptions) {
		final List<PBInquiryFusionWeight> weights = iOptions
				.getFusionWeightList();
		List<FingerSetType> setTypes = Lists.newArrayList();

		// weights is form client request
		for (PBInquiryFusionWeight weight : weights) {
			FingerSetType setType = weight.getInquirySet();

			boolean isMatch = false;
			for (PBInquiryFusionWeight defaultfWeight : defaultfWeights) {
				if (setType == defaultfWeight.getInquirySet()) {
					isMatch = true;
					break;
				}
			}

			if (!isMatch) {
				exception.throwArgException(AimError.INQ_FUSION_WEIGHT);
			}
			setTypes.add(setType);

		}

		// FusionWeight could not be duplicate
		if (setTypes.size() != Sets.newHashSet(setTypes).size()) {
			exception.throwArgException(AimError.INQ_FUSION_WEIGHT_DUPLICATE);
		}
	}

	/**
	 * Check each PBKeyedTemplateData template key is valid or not
	 * 
	 * @param l
	 *            PBKeyedTemplateData list
	 * @param function
	 *            the instance of InquiryFunctionType
	 */
	private void checkFunction(final List<PBFusionJobInput> l,
			final InquiryFunctionType function) {
		final List<TemplateFormatType> types = Lists.newArrayList();
		switch (function) {
		case TI:
			types.add(TemplateFormatType.TEMPLATE_TI);
			break;
		case TIM:
			types.add(TemplateFormatType.TEMPLATE_TIM);
			break;
		case TLI:
			types.add(TemplateFormatType.TEMPLATE_TLI);
			types.add(TemplateFormatType.TEMPLATE_TLIS);
			break;
		case TLIM:
			types.add(TemplateFormatType.TEMPLATE_TLIM);
			break;
		case TLIX:
			types.add(TemplateFormatType.TEMPLATE_TLIX);
			break;
		case LI:
			types.add(TemplateFormatType.TEMPLATE_LI);
			types.add(TemplateFormatType.TEMPLATE_LIS);
			break;
		case LIM:
			types.add(TemplateFormatType.TEMPLATE_LIM);
			break;
		case LIX:
			types.add(TemplateFormatType.TEMPLATE_LIX);
			break;
		case LLI:
			types.add(TemplateFormatType.TEMPLATE_LLI);
			types.add(TemplateFormatType.TEMPLATE_LLIS);
			break;
		case LLIM:
			types.add(TemplateFormatType.TEMPLATE_LLIM);
			break;
		case LLIX:
			types.add(TemplateFormatType.TEMPLATE_LLIX);
			break;
		case LIP:
			types.add(TemplateFormatType.TEMPLATE_LIP);
			break;
		case TLIP:
			types.add(TemplateFormatType.TEMPLATE_TLIP);
			break;
		case LLIP:
			types.add(TemplateFormatType.TEMPLATE_LLIP);
			break;
		case FI:
			types.add(TemplateFormatType.TEMPLATE_FI);
			break;
		case II:
			types.add(TemplateFormatType.TEMPLATE_II);
			break;
		default:
			exception.throwArgException(AimError.INQ_FUNCTION_TYPE);
		}

		CheckTemplateKey(l, function,
				types.toArray(new TemplateFormatType[] {}));
	}

	/**
	 * Check the TemplateKey is matched
	 * 
	 * @param l
	 *            list of PBKeyedTemplateData
	 * @param function
	 *            instance of InquiryFunctionType
	 * @param types
	 *            array of TemplateFormatType
	 */
	private void CheckTemplateKey(final List<PBFusionJobInput> l,
			final InquiryFunctionType function, final TemplateFormatType[] types) {
		for (final PBFusionJobInput fJobInput : l) {
			PBKeyedTemplateData templateData = fJobInput.getKeyedTemplateData();
			final PBKeyedTemplate template = templateData.getKeyedTemplate();
			boolean isMatch = false;
			for (final TemplateFormatType type : types) {
				if (template.getKey() == type) {
					isMatch = true;
					break;
				}
			}
			if (!isMatch) {
				exception.throwArgException(INQ_TEMPLATE_KEY, new Object[] {
						function.name(), template.getKey().name() });
			}
		}
	}

	/**
	 * checkFingerPrintType
	 * 
	 * @param function
	 *            the instance of InquiryFunctionType
	 * @param fInput
	 *            the instance of PBFusionJobInput.Builder
	 */
	private void checkFingerPrintType(final InquiryFunctionType function,
			final PBFusionJobInput.Builder fInput) {

		// Check target file side(in PBInquiryScopeOptions)
		switch (function) {
		case TI:
		case TIM:
		case LI:
		case LIM:
			// targetFingerPrint must exist!!
			if (!fInput.hasScopes()) {
				exception.throwArgException(AimError.INQ_SCOPE_FINGERPRINTTYPE);
			}

			// PrintTypes must be specified
			List<FingerPrintType> printTypes = fInput.getScopes()
					.getTargetFingerPrintList();
			if (CollectionsUtil.isEmpty(printTypes)) {
				exception.throwArgException(AimError.INQ_SCOPE_FINGERPRINTTYPE);
			}

			// PrintTypes could not be duplicate
			if (printTypes.size() != Sets.newTreeSet(printTypes).size()) {
				exception.throwArgException(AimError.INQ_SCOPE_FINGERPRINTTYPE);
			}

			break;
		default:
			if (log.isDebugEnabled()) {
				log.debug("targetFingerPrint can not be specified..");
			}

			if (fInput.hasScopes()) {
				List<FingerPrintType> types = fInput.getScopes()
						.getTargetFingerPrintList();
				if (CollectionsUtil.isNotEmpty(types)) {
					exception
							.throwArgException(AimError.INQ_SCOPE_FINGERPRINTTYPE);
				}
			}
			break;
		}

		// Scopes could not be duplicate in all function case..
		if (fInput.hasScopes()) {
			PBInquiryScopeOptions scopeOptions = fInput.getScopes();
			if (scopeOptions.getScopeCount() > 0) {
				List<Integer> scopes = scopeOptions.getScopeList();
				if (scopes.size() != Sets.newTreeSet(scopes).size()) {
					exception
							.throwArgException(AimError.INQ_SCOPEOPTIONS_SCOPE);
				}
			}
		}

		// Check search side(in PBKeyedTemplateIndexer)
		// KeyedTemplate must exist after converted
		PBKeyedTemplate template = fInput.getKeyedTemplateData()
				.getKeyedTemplate();
		switch (function) {
		case TI:
		case TIM:
		case TLI:
		case TLIM:
			if (!template.hasIndexer()) {
				exception
						.throwArgException(AimError.INQ_INDEXR_FINGERPRINTTYPE);
			}
			PBKeyedTemplateIndexer indexer = template.getIndexer();
			if (!indexer.hasFingerPrintType()) {
				exception
						.throwArgException(AimError.INQ_INDEXR_FINGERPRINTTYPE);
			}
			break;
		default:
			if (template.hasIndexer()) {
				exception
						.throwArgException(AimError.INQ_INDEXR_FINGERPRINTTYPE);
			}
			break;
		}
	}

	/**
	 * validate commonOptions which is a parameter of WebMethod.
	 * 
	 * Validate values is in SYSTEM_CONFIG table.
	 * 
	 * @param options
	 */
	public void validate(Integer priority) {
		if (!validate(
				priority,//
				confDao.getMMPropertyInt(MMConfigProperty.SEARCH_LIMITS_PRIORITY_MIN), //
				confDao.getMMPropertyInt(MMConfigProperty.SEARCH_LIMITS_PRIORITY_MAX),
				"priority")) {
			exception.throwArgException(AimError.EXTRACT_PRIORITY_OUT_RANGE);
		}
	}

	/**
	 * validateJobInfo
	 * 
	 * @param jobInfo
	 *            the instance of PBInquiryJobInfo
	 */
	private void validateJobInfo(PBInquiryJobInfo jobInfo) {
		if (jobInfo.hasPriority())
			if (!validate(
					jobInfo.getPriority(),//
					confDao.getMMPropertyInt(MMConfigProperty.SEARCH_LIMITS_PRIORITY_MIN), //
					confDao.getMMPropertyInt(MMConfigProperty.SEARCH_LIMITS_PRIORITY_MAX),
					"priority")) {
				exception.throwArgException(AimError.PRIORITY_OUT_RANGE);
			}

		if (jobInfo.hasMaxCandidate())
			if (!validate(
					jobInfo.getMaxCandidate(),//
					confDao.getMMPropertyInt(MMConfigProperty.MAX_MIN_CANDIDATES), //
					confDao.getMMPropertyInt(MMConfigProperty.MAX_MAX_CANDIDATES),
					"maxCandidates")) {
				exception.throwArgException(AimError.MAXCANDIDATES_OUT_RANGE);
			}

		if (jobInfo.hasDynThreshPercentagePoint())
			if (!validate(
					jobInfo.getDynThreshPercentagePoint(),//
					confDao.getMMPropertyDouble(MMConfigProperty.DYNAMIC_THRESHOLD_LIMITS_PERCENTAGE_POINT_MIN), //
					confDao.getMMPropertyDouble(MMConfigProperty.DYNAMIC_THRESHOLD_LIMITS_PERCENTAGE_POINT_MAX),
					"dynThreshPercentagePoint")) {
				exception.throwArgException(AimError.DYPOINT_OUT_RANGE);
			}
		if (jobInfo.hasDynThreshHitThreshold())
			if (!validate(
					jobInfo.getDynThreshHitThreshold(),//
					confDao.getMMPropertyInt(MMConfigProperty.DYNAMIC_THRESHOLD_LIMITS_HIT_THRESHOLD_MIN), //
					confDao.getMMPropertyInt(MMConfigProperty.DYNAMIC_THRESHOLD_LIMITS_HIT_THRESHOLD_MAX),
					"dynThreshHitThreshold")) {
				exception.throwArgException(AimError.DYHIT_OUT_RANGE);
			}
	}

	/**
	 * validate commonOptions which is a parameter of WebMethod.
	 * 
	 * Validate values is in SYSTEM_CONFIG table.
	 * 
	 * @param options
	 */
	public void validateMinScore(PBInquiryOptions iOptions) {
		if (iOptions.hasMinScore())
			if (!validate(
					iOptions.getMinScore(),//
					confDao.getMMPropertyInt(//
					MMConfigProperty.SEARCH_LIMITS_MIN_SCORE_MIN), //
					confDao.getMMPropertyInt(MMConfigProperty.SEARCH_LIMITS_MIN_SCORE_MAX),
					"minScore")) {
				exception.throwArgException(AimError.MINSCORE_OUT_RANGE);
			}
	}

	/**
	 * Check function type is delete.
	 * 
	 * check the PBSyncJobRequest
	 * 
	 * @param request
	 *            PBSyncJobRequest instance
	 */
	private void checkDelRequest(final PBSyncJobRequest request) {
		if (request.hasDeletePayload()) {
			PBSyncDeletePayload delPayload = request.getDeletePayload();
			List<Integer> scopes = delPayload.getScopesList();
			List<PBKeyedTemplate> templates = delPayload.getKeyedTemplateList();
			if (CollectionsUtil.isEmpty(scopes)
					&& CollectionsUtil.isEmpty(templates)) {
				log.warn("Both scopes and keyedTemplate are not "
						+ "specified when deletePayload is not null, may use default scope. ");
			}

			// scope in PBSyncDeletePayload can not be duplicate
			if (scopes.size() != Sets.newTreeSet(scopes).size()) {
				exception.throwArgException(AimError.SYNC_OPEOPTIONS_SCOPE);
			}

			if (CollectionsUtil.isNotEmpty(templates)) {
				List<SyncKey> syncKeys = Lists.newArrayList();
				for (final PBKeyedTemplate data : templates) {
					if (!data.hasKey()) {
						exception.throwArgException(SYNC_FORMATTYPE);
					}
					PBKeyedTemplateData newData = PBKeyedTemplateData
							.newBuilder().setKeyedTemplate(data).build();
					getSyncKey(newData, syncKeys);
					// check Deletion PayLoad Index
					checkDelPayloadIndex(data);
				}
				if (syncKeys.size() != Sets.newHashSet(syncKeys).size()) {
					exception
							.throwArgException(AimError.SYNC_KEYTEMPLATE_DUPLICATE);
				}
			}
		}

	}

	/**
	 * check Deletion PayLoad Index
	 * 
	 * @param data
	 *            the instance of PBKeyedTemplate
	 */
	private void checkDelPayloadIndex(final PBKeyedTemplate data) {
		final TemplateFormatType key = data.getKey();

		if (data.hasIndexer()) {
			PBKeyedTemplateIndexer indexer = data.getIndexer();
			if (!indexer.hasPosition() && !indexer.hasFingerPrintType()
					&& !indexer.hasIndex()) {
				exception.throwArgException(SYNC_INDEXER);
			}

			switch (key) {
			case TEMPLATE_RDBLX:
			case TEMPLATE_PDB:
			case TEMPLATE_FDB:
			case TEMPLATE_LDB:
			case TEMPLATE_IDB:
			case TEMPLATE_PLDB:
			case TEMPLATE_LDBS:
			case TEMPLATE_LDBM:
			case TEMPLATE_LDBX:
				if (indexer.hasFingerPrintType()) {
					exception.throwArgException(SYNC_DEL_INDEXER);
				}
				break;
			default:
				break;
			}
		}
	}

	/**
	 * check function type is delete.
	 * 
	 * check the insertPayload
	 * 
	 * @param insertPayload
	 */
	private List<PBKeyedTemplateData> checkInsertRequest(
			final PBSyncJobRequest request) {
		// insert payLoad is null when function is insert
		if (!request.hasInsertPayload()) {
			exception.throwArgException(SYNC_IN_INSERT_PAYLOAD);
		}

		final PBSyncInsertPayload insertPayload = request.getInsertPayload();
		// check scope is correct or not
		if (insertPayload.hasScope()) {
			int scope = insertPayload.getScope();
			if (scope <= 0) {
				exception.throwArgException(SYNC_SCOPE);
			}
		}

		// KeyedTemplateDataList is null or empty
		List<PBKeyedTemplateData> l = insertPayload.getKeyedTemplateDataList();
		if (CollectionsUtil.isEmpty(l)) {
			exception.throwArgException(SYNC_TEM_DATA_EMPTY);
		}
		List<SyncKey> insertKeys = Lists.newArrayList();
		return checkTemplateDataList(l, insertKeys, true);
	}

	/**
	 * check TemplateDataList
	 * 
	 * @param l
	 *            PBKeyedTemplateData list
	 * @param isSync
	 *            caller is from the sync service
	 * @return new created PBKeyedTemplateData list
	 */
	private List<PBKeyedTemplateData> checkTemplateDataList(
			List<PBKeyedTemplateData> l, List<SyncKey> syncKeys, boolean isSync) {
		final List<PBKeyedTemplateData> reGenerate = Lists.newArrayList();
		// loop each PBKeyedTemplateData and check
		for (final PBKeyedTemplateData data : l) {
			// ///////////////////////////////////////////////////////////
			// ///////////////////PBKeyedTemplateData/////////////////////
			// ///////////////////////////////////////////////////////////
			// check PBKeyedTemplate and PBKeyedTemplateReference
			PBKeyedTemplateData newData = checkTemplateData(isSync, data);
			getSyncKey(newData, syncKeys);
			reGenerate.add(newData);

		}
		if (syncKeys.size() != Sets.newHashSet(syncKeys).size()) {
			exception.throwArgException(AimError.SYNC_KEYTEMPLATE_DUPLICATE);
		}
		return reGenerate;
	}

	/**
	 * getSyncKey
	 * 
	 * @param data
	 *            the read only instance
	 */

	private void getSyncKey(PBKeyedTemplateData newData,
			List<SyncKey> insertKeys) {
		if (newData.hasKeyedTemplate()) {
			SyncKey insertKey = new SyncKey();
			PBKeyedTemplate template = newData.getKeyedTemplate();
			if (template.hasKey()) {
				insertKey.setKey(template.getKey());
			}
			if (template.hasIndexer()) {
				PBKeyedTemplateIndexer indexer = template.getIndexer();
				if (indexer.hasFingerPrintType()) {
					insertKey
							.setIndexer(indexer.getFingerPrintType().ordinal());
				} else if (indexer.hasPosition()) {
					insertKey.setIndexer(indexer.getPosition().ordinal());
				} else if (indexer.hasIndex()) {
					insertKey.setIndexer(indexer.getIndex());
				}
			}
			insertKeys.add(insertKey);
		}

	}

	/**
	 * checkTemplateData
	 * 
	 * @param isSync
	 *            is from sync service
	 * @param data
	 *            the read only instance
	 * @return the instance of PBKeyedTemplateData
	 */
	private PBKeyedTemplateData checkTemplateData(final boolean isSync,
			final PBKeyedTemplateData data) {
		// Both PBKeyedTemplate and PBKeyedTemplateReference
		// both not specified
		if (!data.hasKeyedTemplate() && !data.hasKeyedReferenece()) {
			exception.throwArgException(isSync ? SYNC_TEM_TEMREF
					: INQ_TEM_TEMREF);
		}

		final PBKeyedTemplate template = data.getKeyedTemplate();
		final PBKeyedTemplateReference reference = data.getKeyedReferenece();

		// PBKeyedTemplate element is specified
		if (data.hasKeyedTemplate()) {
			// template binary is null or empty and key is null
			if (!template.hasTemplateBinary() || !template.hasKey()) {
				exception.throwArgException(isSync ? SYNC_BINARY_FORMATTYPE
						: INQ_BINARY_FORMATTYPE);
			}
			if (template.hasKey()) {
				checkKeyIndexer(template.getKey(), template.getIndexer(),
						isSync, false);
			}

			return data;

			// reGenerate.add(data);
		} else if (!data.hasKeyedTemplate() && data.hasKeyedReferenece()) { // PBKeyedTemplateReference
																			// specified
			// job and key is not valid
			if (reference.hasJobId() && reference.hasKey()) {
				if (reference.getJobId() < 0) {
					exception.throwArgException(isSync ? SYNC_KEY_JOBID
							: INQ_KEY_JOBID);
				}
			}

			int templateIndex = 0; // default template index
			if (reference.hasKey()) {
				templateIndex = checkKeyIndexer(reference.getKey(),
						reference.getIndexer(), isSync, true);
			}

			final long jobId = reference.getJobId();
			final TemplateFormatType key = reference.getKey();

			// get extract result by jobId, template_key, template_index
			byte[] bytes = checkFeResult(jobId, key, templateIndex, isSync);
			// regenerate the KeyedTemplate due to INQUIRY_JOB_DATA must
			// contain template binary
			PBKeyedTemplate.Builder tBuilder = PBKeyedTemplate.newBuilder()
					.setKey(key).setTemplateBinary(ByteString.copyFrom(bytes));
			if (reference.hasIndexer()
					&& reference.getKey() != TemplateFormatType.TEMPLATE_FI) {
				tBuilder.setIndexer(reference.getIndexer());
			}
			return PBKeyedTemplateData.newBuilder().setKeyedTemplate(tBuilder)
					.build();
		} else {
			throw new IllegalArgumentException("UnReached here!!");
		}
	}

	/**
	 * check the list of FJobInputs
	 * 
	 * @param function
	 *            the instance of InquiryFunctionType
	 * @param fInputs
	 *            the list of PBFusionJobInput
	 * @param isSync
	 *            is this method from syncRequest
	 * @return the list of PBFusionJobInput
	 */
	private List<PBFusionJobInput> checkFJobInputsList(
			final InquiryFunctionType function, List<PBFusionJobInput> fInputs,
			boolean isSync) {
		final ScriptFunction sFunction = ScriptFunction
				.valueOf(function.name());
		final List<PBFusionJobInput> reGenerate = Lists.newArrayList();

		// if memory exist, skip..
		// otherwise fetch from database
		addInquiryScript(function);

		int minScore = confDao
				.getMMPropertyInt(MMConfigProperty.DEFAULT_MIN_SCORE);

		// searchKeys is used for check duplication of
		// (key + indexer->fingerPrintType)
		List<SearchKey> searchKeys = Lists.newArrayList();
		// loop each PBKeyedTemplateData and check
		for (final PBFusionJobInput fInput : fInputs) {
			// ///////////////////////////////////////////////////////////
			// ///////////////////PBKeyedTemplateData/////////////////////
			// ///////////////////////////////////////////////////////////
			// check PBKeyedTemplate and PBKeyedTemplateReference
			final PBKeyedTemplateData data = fInput.getKeyedTemplateData();
			PBKeyedTemplateData modifyData = checkTemplateData(isSync, data);

			// ///////////////////////////////////////////////////////////
			// ////////////////Parameter Combination/////////////////////
			// ///////////////////////////////////////////////////////////
			if (log.isDebugEnabled()) {
				log.debug("Ready to check Parameter Combination..");
			}
			Set<PBInquiryFusionWeight> defaultfWeights = checkParaCombination(
					sFunction, fInput, modifyData, searchKeys);

			// ///////////////////////////////////////////////////////////
			// /////////////////////FusionWeight//////////////////////////
			// ///////////////////////////////////////////////////////////
			// check the fusion weight is match
			// the default Standard fusion weight
			if (fInput.hasInquiryOptions()) {
				PBInquiryOptions iOptions = fInput.getInquiryOptions();
				validateMinScore(iOptions);
				if (log.isDebugEnabled()) {
					log.debug("Ready to check FusionWeights..");
				}
				checkFusionWeight(defaultfWeights, iOptions);
			} else {
				log.warn("InquiryOptions was not specified..");
			}

			// Regenerate the PBFusionJobInput instance
			PBFusionJobInput.Builder b = PBFusionJobInput.newBuilder();
			b.setKeyedTemplateData(modifyData);
			if (fInput.hasScopes()) {
				b.setScopes(fInput.getScopes());
			}

			if (fInput.hasInquiryOptions()) {
				b.setInquiryOptions(fInput.getInquiryOptions());
				if (!b.getInquiryOptions().hasMinScore()) {
					b.getInquiryOptionsBuilder().setMinScore(minScore);
				}
			} else {
				b.setInquiryOptions(PBInquiryOptions.newBuilder().setMinScore(
						minScore));
			}

			// ///////////////////////////////////////////////////////////
			// ///////////////////FingerPrintType////////////////////////
			// ///////////////////////////////////////////////////////////
			if (log.isDebugEnabled()) {
				log.debug("Ready to check FingerPrintType..");
			}
			checkFingerPrintType(function, b);

			// add into list
			reGenerate.add(b.build());
		}

		// Check the combination of TemplateFormatType + FingerPrintType is
		// duplication, if Search side FingerPrintType is not specified,
		// considering as null, continue to check the relationship
		if (searchKeys.size() != Sets.newHashSet(searchKeys).size()) {
			exception.throwArgException(AimError.INQ_KEY_PRINTTYPE_DUPLICATE);
		}

		return reGenerate;
	}

	/**
	 * scriptManager already exist specified function <br>
	 * it means that already has this function in memory <br>
	 * so skip to fetch from database, otherwise must fetch it <br>
	 * from database and cache into memory..
	 * 
	 * @param function
	 */
	private void addInquiryScript(final InquiryFunctionType function) {
		// convert InquiryFunctionType into ScriptFunction
		final ScriptFunction f = ScriptFunction.valueOf(function.name());
		if (f == null) {
			throw new AimRuntimeException(
					"error occurred when convert to ScriptFunction,"
							+ " InquiryFunctionType: " + function.name());
		}

		// thread safe must be considering,
		// if MUTLIP-THREAD reached, one thread
		// add script XML is allowed..
		// synchronized by ScriptFunction instance
		synchronized (f) {
			// if scriptManager already exist specified function
			// it means that already has this function in memory
			// so skip to fetch from database, otherwise must fetch it
			// from database and cache into memory..
			if (!scManager.isExistFunction(f)) {
				String scriptXml = layoutDao.findScriptXmlByName(f.name());
				scManager.addScriptXml(f, scriptXml);
			}
		}
	}

	/**
	 * check Parameter Combination
	 * 
	 * @param sFunction
	 *            the instance of ScriptFunction
	 * @param fInput
	 *            the instance of PBFusionJobInput
	 * @param modifyData
	 *            the instance of PBKeyedTemplateData
	 * @return the set of PBInquiryFusionWeight
	 */
	private Set<PBInquiryFusionWeight> checkParaCombination(
			final ScriptFunction sFunction, final PBFusionJobInput fInput,
			PBKeyedTemplateData modifyData, List<SearchKey> searchKeys) {
		PBKeyedTemplate template = modifyData.getKeyedTemplate();
		TemplateFormatType formatType = template.getKey();
		// Confirm search side FingerPrintType
		FingerPrintType sFinPrint = scManager.confirmSPrintType(template);
		// Confirm file side FingerPrintType
		List<FingerPrintType> fFinPrints = scManager.confirmFPrintType(fInput
				.getScopes());

		// Collect the PBInquiryFusionWeight
		Set<PBInquiryFusionWeight> defaultfWeights = Sets.newHashSet();
		// loop file side finger print side
		for (final FingerPrintType fFinPrint : fFinPrints) {
			final SearchKey key = new SearchKey(sFunction, formatType,
					sFinPrint, fFinPrint);
			final SearchValue value = scManager.getBySearchKey(key);
			if (value == null) {
				exception.throwArgException(INQ_COMBINE_OF_KEY, key.toString());
			}

			// default Standard fusion weight with specified searchKey
			defaultfWeights.addAll(value.getFwList());
		}

		// add into the list of searchKey
		searchKeys.add(new SearchKey(template.getKey(), sFinPrint));

		return defaultfWeights;
	}

	/**
	 * check the relationship of Key and Indexer <br>
	 * position exist -> RDBLS, RDBL, RDBLM, PDB <br>
	 * fingerPrintType -> RDBT, RDBTM <br>
	 * index -> FDB
	 * 
	 * @param key
	 *            the instance of TemplateFormatType
	 * @param indexer
	 *            the instance of PBKeyedTemplateIndexer
	 */
	private int checkKeyIndexer(final TemplateFormatType key,
			final PBKeyedTemplateIndexer indexer, boolean isSync,
			boolean isReference) {
		int templateIndex = 0; // default template Index
		switch (key) {
		case TEMPLATE_RDBLS:
		case TEMPLATE_RDBL:
		case TEMPLATE_RDBLM:
		case TEMPLATE_PDB:
			// RDBLS RDBL RDBLM PDB must own the position
			if (!indexer.hasPosition()) {
				exception.throwArgException(isSync ? SYNC_KEY_INDEXER
						: INQ_KEY_INDEXER);
			}
			templateIndex = indexer.getPosition().getNumber();
			break;
		case TEMPLATE_TI:
		case TEMPLATE_TIM:
		case TEMPLATE_RDBT:
		case TEMPLATE_RDBTM:
		case TEMPLATE_TLI:
		case TEMPLATE_TLIS:
		case TEMPLATE_TLIM:
			// RDBT RDBTM must own the FingerPrintType
			if (!indexer.hasFingerPrintType()) {
				exception.throwArgException(isSync ? SYNC_KEY_INDEXER
						: INQ_KEY_INDEXER);
			}
			templateIndex = indexer.getFingerPrintType().getNumber();
			break;
		case TEMPLATE_FDB:
			// FDB must own the index
			if (!indexer.hasIndex()) {
				exception.throwArgException(isSync ? SYNC_KEY_INDEXER
						: INQ_KEY_INDEXER);
			}
			templateIndex = indexer.getIndex();
			break;
		case TEMPLATE_FI:
			if (isReference) {
				// indexer must specified when FI keyedReference
				if (!indexer.hasIndex()) {
					exception.throwArgException(isSync ? SYNC_KEY_INDEXER
							: INQ_KEY_INDEXER);
				}
				templateIndex = indexer.getIndex();
			} else {
				// indexer must not specified when FI keyedTemplate
				if (indexer.hasIndex()) {
					exception.throwArgException(isSync ? SYNC_KEY_INDEXER
							: INQ_KEY_INDEXER);
				}
			}
			break;
		default:
			if (indexer.hasIndex()) {
				exception.throwArgException(isSync ? SYNC_KEY_INDEXER
						: INQ_KEY_INDEXER);
			}
			break;
		}
		return templateIndex;
	}

	/**
	 * When min > value or max < value, return no pass
	 * 
	 * If value is not set, this case is normal.
	 * 
	 * @param value
	 * @param min
	 * @param max
	 * @param name
	 */
	private boolean validate(Float value, double min, double max, String name) {
		if (value == null) {
			return true;
		}
		if (value.doubleValue() < min || max < value.doubleValue()) {
			return false;
		}
		return true;
	}

	/**
	 * When min > value or max < value, return no pass
	 * 
	 * If value is not set, this case is normal.
	 * 
	 * @param value
	 * @param min
	 * @param max
	 * @param name
	 *            just using for exception message
	 */
	private boolean validate(Integer value, int min, int max, String name) {
		if (value == null) {
			return true;
		}
		if (value.intValue() < min || max < value.intValue()) {
			return false;
		}
		return true;
	}

	/**
	 * check the extract job result is exist
	 * 
	 * @param jobId
	 *            the extract job id
	 * @param key
	 *            the extract template key
	 */
	private byte[] checkFeResult(long jobId, TemplateFormatType key, int index,
			boolean isSync) {
		FeResultEntity result = null;
		try {
			result = feJobDao.getFeResult(jobId, key.name(), index);
		} catch (NoResultException e) {
			exception.throwArgException(isSync ? SYNC_GET_TEMPLATE
					: INQ_GET_TEMPLATE);
		}

		if (result == null) {
			exception.throwArgException(isSync ? SYNC_GET_TEMPLATE
					: INQ_GET_TEMPLATE);
		}

		byte[] bytes = result.getResultData();
		if (bytes == null || bytes.length == 0) {
			exception.throwArgException(isSync ? SYNC_GET_TEMPLATE
					: INQ_GET_TEMPLATE);
		}
		return bytes;

	}

	/**
	 * map To NewRequest
	 * 
	 * @param builder
	 *            PBSyncJobRequest Builder
	 * @param insertPayload
	 *            PBSyncInsertPayload instance
	 * @param insertDatas
	 *            PBKeyedTemplateData list
	 */
	private void mapToNewRequest(PBSyncJobRequest.Builder builder,
			final PBSyncInsertPayload insertPayload,
			List<PBKeyedTemplateData> insertDatas) {
		PBSyncInsertPayload.Builder newPayload = PBSyncInsertPayload
				.newBuilder();
		if (insertPayload.hasScope()) {
			newPayload.setScope(insertPayload.getScope());
		}
		builder.setInsertPayload(newPayload
				.addAllKeyedTemplateData(insertDatas));
	}

	static class SyncKey {
		private TemplateFormatType key;
		private Integer indexer;

		public TemplateFormatType getKey() {
			return key;
		}

		public void setKey(TemplateFormatType key) {
			this.key = key;
		}

		public Integer getIndexer() {
			return indexer;
		}

		public void setIndexer(Integer indexer) {
			this.indexer = indexer;
		}

		@Override
		public int hashCode() {
			return HashCodeBuilder.reflectionHashCode(this, false);
		}

		@Override
		public boolean equals(Object obj) {
			return EqualsBuilder.reflectionEquals(this, obj, false);
		}

	}

}
