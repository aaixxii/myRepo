package jp.co.nec.aim.mm.aggregator;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Asynchronous;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.aim.convert.ConvertException;
import jp.co.nec.aim.convert.WebServiceClassConvert;
import jp.co.nec.aim.message.proto.AIMMessages.PBInquiryCandidateInternal;
import jp.co.nec.aim.message.proto.AIMMessages.PBInquiryJobResultInternal;
import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryCandidate;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryCandidateTemplate;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryResultStatistics;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryResultStatisticsAMR;
import jp.co.nec.aim.message.proto.InquiryService.PBInquiryJobResult;
import jp.co.nec.aim.mm.constants.CallbackStyle;
import jp.co.nec.aim.mm.constants.ConfigProperties;
import jp.co.nec.aim.mm.constants.ConfigPropertyNames;
import jp.co.nec.aim.mm.constants.FunctionFamily;
import jp.co.nec.aim.mm.constants.JobCallbackSender;
import jp.co.nec.aim.mm.constants.JobState;
import jp.co.nec.aim.mm.constants.MMConfigProperty;
import jp.co.nec.aim.mm.dao.AggregatorDao;
import jp.co.nec.aim.mm.dao.InquiryJobDao;
import jp.co.nec.aim.mm.dao.SystemConfigDao;
import jp.co.nec.aim.mm.entities.JobQueueEntity;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.jaxb.SearchJobResult;
import jp.co.nec.aim.mm.jms.JmsSender;
import jp.co.nec.aim.mm.jms.NotifierEnum;
import jp.co.nec.aim.mm.logger.JobDoneLogger;
import jp.co.nec.aim.mm.logger.PerformanceLogger;
import jp.co.nec.aim.mm.procedure.ContainerJobResult;
import jp.co.nec.aim.mm.result.DynamicThresholdParams;
import jp.co.nec.aim.mm.result.HitMarking;
import jp.co.nec.aim.mm.util.CollectionsUtil;
import jp.co.nec.aim.mm.util.JAXBHelper;
import jp.co.nec.aim.mm.util.StopWatch;
import jp.co.nec.aim.mm.util.TimeHelper;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.protobuf.InvalidProtocolBufferException;

/**
 * 
 * @author jinxl
 * 
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class Aggregator {

	private static Logger log = LoggerFactory.getLogger(Aggregator.class);

	@PersistenceContext(unitName = "aim-db")
	private EntityManager manager;

	@Resource(mappedName = "java:jboss/MySqlDS")
	private DataSource ds;
	private InquiryJobDao inquiryJobDao;
	private AggregatorDao aggregatorDao;
	private SystemConfigDao systemConfigDao;

	/** the common of Class Converter **/
	private WebServiceClassConvert webConvert;

	private final static String L_SUCCESS_PROCESS = "p_success_refcursor";

	@PostConstruct
	public void init() {
		inquiryJobDao = new InquiryJobDao(manager);
		aggregatorDao = new AggregatorDao(ds);
		systemConfigDao = new SystemConfigDao(manager);
		webConvert = new WebServiceClassConvert();
	}
	
	/**
	 * Aggregation main flow control
	 * 
	 * @param topJobId
	 */
	@Asynchronous	
	public void doAggregation(long jobId) {
		long threadId = Thread.currentThread().getId();
		boolean isSuccess = true;
		try {
			doAggregationCore(jobId);
		} catch (Throwable e) {
			isSuccess = false;
			String errMessg = String
					.format("Any exception occured during aggregation. jobId=%d threadId=%d",
							jobId, threadId);
			log.error(errMessg, e);
			throw new AimRuntimeException(e);
		} finally {
			if (isSuccess) {
				log.info(
						"Finished aggregation thread. jobId={} threadId={}",
					jobId, threadId);
			} else {
				log.warn(
						"Finished aggregation thread with unexpected exception. jobId={} threadId={}",
						jobId, threadId);
			}
		}
	}

	/**
	 * doAggregation
	 * 
	 * @param topLevelJobId
	 */
	public void doAggregationCore(long topLevelJobId) {
		long threadId = Thread.currentThread().getId();
		log.info("prepare aggregation top job(Id={}) results....",
				topLevelJobId);

		StopWatch stopWatch = new StopWatch();
		stopWatch.start();

		PBInquiryJobResult.Builder inquiryJobResult = PBInquiryJobResult
				.newBuilder()
				.setJobId(topLevelJobId)
				.setStatistics(
						PBInquiryResultStatistics.newBuilder().setAmr(
								PBInquiryResultStatisticsAMR.newBuilder()
										.setMatchCount(0).setReadCount(0)));

		JobQueueEntity jobQueue = null;
		if (log.isDebugEnabled()) {
			log.debug(
					"Fetch JOB_QUEUE record for aggregation. jobId={} threadId={}",
					topLevelJobId, threadId);
		}
		try {
			/* check topJob is or not exist */
			jobQueue = inquiryJobDao.getTopLevelJob(topLevelJobId);
			if (jobQueue == null) {
				log.warn(
						"Job {} queued for aggregation not found, skip aggaregation!",
						topLevelJobId);
				return;
			}

			if (jobQueue.getJobState().equals(JobState.DONE)) {
				log.warn("Job {} already be DONE, skip to aggregation.",
						topLevelJobId);
				return;
			}
		} catch (Exception ex) {
			String errMessg = String
					.format("An error occoured during find JOB_QUEUE record for aggregation. jobId=%d threadId=%d",
							topLevelJobId, threadId);
			throw new AimRuntimeException(errMessg, ex);
		}

		PBInquiryJobResultInternal.Builder inquiryJobResInternal = PBInquiryJobResultInternal
				.newBuilder();

		boolean bState = getAllContainerJobs(topLevelJobId,
				inquiryJobResInternal);

		if (bState) {
			/* CandidateList is empty */						
			if (inquiryJobResInternal.hasCandidateList()
					|| CollectionsUtil.isNotEmpty(inquiryJobResInternal
							.getCandidateList().getCandidateList())) {	
				if (log.isDebugEnabled()) {
					log.debug("Last merging. jobId={}, threadId={}.",
						topLevelJobId, threadId);
				}
				List<PBInquiryCandidate> inquiryCandidateList = merge(
						inquiryJobResInternal.getCandidateList()
								.getCandidateList(),
						jobQueue.getMaxCandidates(), topLevelJobId);
				inquiryJobResult.getCandidateListBuilder().addAllCandidate(
						inquiryCandidateList);
				if (inquiryJobResInternal.hasStatistics()) {
					inquiryJobResult.setStatistics(inquiryJobResInternal
							.getStatistics());
				}
				inquiryJobResult.setServiceState(inquiryJobResInternal
						.getServiceState());
				FunctionFamily family = FunctionFamily.fromVal(jobQueue
						.getFamilyId());
				markHits(family, inquiryJobResult, jobQueue);
			}
		} else {
			/* PBInquiryJobResultInternal convert to PBInquiryJobResult */
			inquiryJobResult.setServiceState(inquiryJobResInternal
					.getServiceState());
			if (inquiryJobResInternal.hasStatistics()) {
				inquiryJobResult.setStatistics(inquiryJobResInternal
						.getStatistics());
			}
			log.warn("No CandidateList found in search job results, "
							+ "skip aggregation and callback to client. jobId={} threadId={}",
					topLevelJobId, threadId);
		}

		doAfterMergeProcess(inquiryJobResult.build(), jobQueue);

		stopWatch.stop();
		PerformanceLogger.log(getClass().getSimpleName(), "doAggregationCore",
				stopWatch.elapsedTime());
		return;
	}

	/**
	 * merge
	 * 
	 * @param candidateList
	 * @param maxCandidates
	 * @return
	 */
	private List<PBInquiryCandidate> merge(			
			List<PBInquiryCandidateInternal> candidateList,
			Integer maxCandidates, long jobId) {
		long threadId = Thread.currentThread().getId();
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		/* Constructs an empty HashMap */
		Map<Integer, List<PBInquiryCandidateInternal>> map = Maps.newHashMap();
		if (log.isDebugEnabled()) {
			log.debug(
					"Separate candiate list by searchRequestIndex. jobId={} threadId={}",
					jobId, threadId);
		}

		/* loop: toBeMergedCandidates */
		for (PBInquiryCandidateInternal candidate : candidateList) {
			if (CollectionsUtil.isEmpty(candidate.getCandidateTemplateList())) {
				throw new AimRuntimeException(
						"CandidateTemplate list is null or count is zero. jobId="
								+ jobId + " threadId=" + threadId);
			}
			PBInquiryCandidateTemplate candidateTemplate = CollectionsUtil
					.getFirst(candidate.getCandidateTemplateList());

			int requestIndex = candidateTemplate.getInquiryRequestIndex();
			/*
			 * if this map contains a mapping for the specified
			 * key:inquiryRequestIndex
			 */
			if (!map.containsKey(requestIndex)) {
				List<PBInquiryCandidateInternal> list = Lists.newArrayList();
				map.put(requestIndex, list);
			}
			map.get(requestIndex).add(candidate);
		}
		stopWatch.stop();
		if (log.isDebugEnabled()) {
			log.debug(
					"Separated candidate list by searchRequestIndex({}), took {}"
					+ " ms. jobId={} threadId={}", map.size(),
					stopWatch.elapsedTime(), jobId, threadId);
		}
		/* Constructs an empty ArrayList */
		List<PBInquiryCandidateInternal> candidateMergeList = Lists
				.newArrayList();
		Set<Integer> intSet = map.keySet();

		if (log.isDebugEnabled()) {
			log.debug(
					"Merge candidate results per searchRequestIndex. jobId={} threadId={}.",
					jobId, threadId);
		}
		for (Integer set : intSet) {
			/* merge candidates between search request index */					
			findSameKeyAndHighMerge(map.get(set));
			/* After sorted, add to Candidatelist */
			candidateMergeList.addAll(map.get(set));
		}
		if (log.isDebugEnabled()) {
			log.debug(
					"End merge candidates between search request index. Merged candidate size is {}."
							+ " jobId={} threadId={}",
					candidateMergeList.size(), jobId, threadId);
		}

		if (log.isDebugEnabled()) {
			log.debug(
					"Merge candidates between consolidate key... jobId={} threadId={}",
					jobId, threadId);
		}

		int maxCandidate = maxCandidates == null ? systemConfigDao
				.getMMPropertyInt(MMConfigProperty.DEFAULT_MAX_CANDIDATES)
				: maxCandidates.intValue();

		/* merge candidates between consolidate key */
		List<PBInquiryCandidateInternal> candidatelistResult = findSameKeyAndSumMerge(
				maxCandidate, candidateMergeList);

		if (log.isDebugEnabled()) {
			log.debug(
					"End merge candidates between search consolidate key. Merged candidate size is {}."
							+ " jobId={} threadId={}",
					candidateMergeList.size(), jobId, threadId);
		}

		/* convert PBInquiryCandidateInternal into PBInquiryCandidate */
		if (log.isDebugEnabled()) {
			log.debug("Convert catdidate. jobId={} threadId={}.", jobId,
					threadId);
		}
		List<PBInquiryCandidate> result = convertToPBInquiryCandidate(
				candidatelistResult, jobId);
		return result;
	}

	/**
	 * convertToPBInquiryCandidate
	 * 
	 * @param candidateList
	 * @return
	 */
	private List<PBInquiryCandidate> convertToPBInquiryCandidate(
			List<PBInquiryCandidateInternal> candidateList, long jobId) {
		long threadId = Thread.currentThread().getId();
		if (log.isDebugEnabled()) {
			log.debug(
					"Converting internal candidates into client candidates... jobId={} threadId={}",
					jobId, threadId);
		}
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		List<PBInquiryCandidate> list = Lists.newArrayList();

		for (PBInquiryCandidateInternal candidate : candidateList) {
			PBInquiryCandidate.Builder builder = PBInquiryCandidate
					.newBuilder();
			builder.setExternalId(candidate.getExternalId());
			builder.setFusionScore(candidate.getFusionScore());
			builder.setHitFlag(false);
			builder.addAllCandidateTemplate(candidate
					.getCandidateTemplateList());
			list.add(builder.build());
		}
		stopWatch.stop();
		if (log.isDebugEnabled()) {
			log.debug(
					"End converting internal candidates into client candidates. It took {}"
							+ " ms. jobId={} threadId={}",
					stopWatch.elapsedTime(), jobId, threadId);
		}
		return list;
	}

	/**
	 * findSameKeyAndHighMerge
	 * 
	 * @param candidateList
	 */
	private void findSameKeyAndHighMerge(
			List<PBInquiryCandidateInternal> candidateList) {
		
		if (log.isDebugEnabled()) {
			log.debug("Lookup same key in candiate list and high merge it into one....");
		}

		/* candidateList.size is 0 or 1 */
		if (candidateList.size() <= 1) {
			log.debug("There is only 0 or 1 candidate in CandidateList."
					+ " It's unnecessary to merge. Skip findSameKeyAndHighMerge process.");
			return;
		}

		StopWatch stopWatch = new StopWatch();
		stopWatch.start();

		int position = 0;
		boolean isdelete = false;

		List<PBInquiryCandidateTemplate> templateList = Lists.newArrayList();
		Collections.sort(candidateList, new CandidateComparator());
		List<PBInquiryCandidateInternal> candidateTempList = Lists
				.newArrayList();
		for (position = candidateList.size() - 1; position >= 1; position--)
			if (candidateList
					.get(position)
					.getConsolidateKey()
					.equals(candidateList.get(position - 1).getConsolidateKey())) {
				templateList.addAll(candidateList.get(position)
						.getCandidateTemplateList());
				candidateList.remove(position);
				isdelete = true;
			} else {
				if (isdelete) {
					candidateTempList.add(candidateList.get(position)
							.toBuilder().addAllCandidateTemplate(templateList)
							.build());
					templateList.clear();
					isdelete = false;
				} else {
					candidateTempList.add(candidateList.get(position));
				}

				if (position - 1 == 0) {
					candidateTempList.add(candidateList.get(position - 1));
				}
			}

		if (templateList.size() > 0) {
			candidateTempList.add(candidateList.get(position).toBuilder()
					.addAllCandidateTemplate(templateList).build());
		}
		candidateList.clear();
		candidateList.addAll(candidateTempList);
		Collections.sort(candidateList, new CandidateComparator());
		stopWatch.stop();
		if (log.isDebugEnabled()) {
			log.debug("End lookup same key in candidate list .used time: {}",
					stopWatch.elapsedTime());
		}
	}

	/**
	 * findSameKeyAndSumMerge
	 * 
	 * @param maxCandiate
	 * @param candidateList
	 * @return
	 */
	private List<PBInquiryCandidateInternal> findSameKeyAndSumMerge(
			int maxCandiate, List<PBInquiryCandidateInternal> candidateList) {
		if (log.isDebugEnabled()) {
			log.debug("Lookup same key in candiate list and sum merge it into one....");
		}
		int sum = 0;
		Map<String, PBInquiryCandidateInternal.Builder> scorelist = Maps
				.newHashMap();
		for (PBInquiryCandidateInternal candidate : candidateList) {
			String consolidatekey = candidate.getConsolidateKey();
			if (scorelist.containsKey(consolidatekey)) {
				PBInquiryCandidateInternal.Builder inquiryCandidateInternal = scorelist
						.get(consolidatekey);
				inquiryCandidateInternal.addAllCandidateTemplate(candidate
						.getCandidateTemplateList());
				sum = inquiryCandidateInternal.build().getFusionScore()
						+ candidate.getFusionScore();
				if (sum > 9999) {
					sum = 9999;
				}
				inquiryCandidateInternal.setFusionScore(sum);
				sum = 0;
			} else {
				PBInquiryCandidateInternal.Builder inquiryCandidateInternal = candidate
						.toBuilder();
				scorelist.put(consolidatekey, inquiryCandidateInternal);
			}
		}

		if (log.isDebugEnabled()) {
			log.debug("End lookup same key in candidate list .");
		}
		List<PBInquiryCandidateInternal> candidateMergeList = Lists
				.newArrayList();
		Set<String> intSet = scorelist.keySet();
		for (String set : intSet) {
			candidateMergeList.add(scorelist.get(set).build());
		}

		Collections.sort(candidateMergeList, new CandidateComparatorMerge());

		int maxListSize = maxCandiate >= candidateMergeList.size() ? candidateMergeList
				.size() : maxCandiate;
		List<PBInquiryCandidateInternal> subCandidatelist = candidateMergeList
				.subList(0, maxListSize);// from Index:0 to
											// Index:maxListSize - 1
		return subCandidatelist;
	}

	/**
	 * notifyCallbacker
	 * 
	 * @param jobId
	 * @param style
	 * @param callbackUrl
	 * @param inquiryJobResult
	 */
	private void notifyCallbacker(long jobId, CallbackStyle style,
			String callbackUrl, PBInquiryJobResult inquiryJobResult) {
		boolean callbacksEnabled = systemConfigDao
				.getMMPropertyBool(MMConfigProperty.HTTP_CALLBACKS_ENABLED);
		if (callbacksEnabled) {
			if (StringUtils.isNoneBlank(callbackUrl)) {

				String finalURL = JobCallbackSender.generateURL(callbackUrl,
						jobId);

				if (style.equals(CallbackStyle.XML)) {
					try {
						// protobuf to xml
						SearchJobResult searchJobResult = webConvert
								.toSearchJobResult(inquiryJobResult);

						JAXBHelper jaxbHelper = new JAXBHelper();
						String resultXml = jaxbHelper.marshal(searchJobResult);
						// Send SearchJobResult to url
						JmsSender.getInstance().sendToAsynchQueue(
								NotifierEnum.Aggregator, finalURL,
								resultXml.getBytes(), false);
					} catch (ConvertException e) {
						log.error(
								"ConvertException occurred "
										+ "when PBInquiryJobResult convert to SearchJobResult.Cannot Send Msg to Client.",
								e.getMessage());
						throw new AimRuntimeException(
								"ConvertException occurred "
										+ " when PBInquiryJobResult convert to SearchJobResult.",
								e);
					}
				} else if (style.equals(CallbackStyle.PROTOBUF)) {
					// Send PBInquiryJobResult to url
					JmsSender.getInstance().sendToAsynchQueue(
							NotifierEnum.Aggregator, finalURL,
							inquiryJobResult.toByteArray(), true);
				}
			} else {
				log.warn("job queue's callbackUrl is null or blank."
						+ "cannot post message to callbackUrl.");
			}
		} else {
			log.warn("BEHAVIOR.SEND_HTTP_CALLBACKS in SYSTEM_CONFIG is false."
					+ " It's not necessary to post message to callbackUrl.");					
		}
	}

	/**
	 * getAllContainerJobs
	 * 
	 * @param topJobId
	 * @param inquiryJobResultInternal
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private boolean getAllContainerJobs(long topJobId,
			PBInquiryJobResultInternal.Builder inquiryJobResultInternal) {
		if (log.isDebugEnabled()) {
			log.debug("getAllContainerJobs start... jobId={}", topJobId);
		}

		TimeHelper th = new TimeHelper("getAllContainerJobs");
		th.t();

		/* get all Container Job INFO */
		List<byte[]> objs = aggregatorDao.getAllContainerJobs(topJobId);
		if (CollectionsUtil.isEmpty(objs)) {
			inquiryJobResultInternal.getServiceStateBuilder().setState(
					ServiceStateType.SERVICE_STATE_SUCCESS);
			log.warn("ContainerJob data in topLevelJobId="
					+ topJobId
					+ " is incorrect! It's no containerJobResult and failureReason!");

			return false;
		}

		List<ContainerJobResult> jobResults = objs.stream().map(ContainerJobResult::new).collect((Collectors.toList()));		

		if (CollectionsUtil.isEmpty(jobResults)) {
			inquiryJobResultInternal.getServiceStateBuilder().setState(
					ServiceStateType.SERVICE_STATE_SUCCESS);
			log.warn("ContainerJob data in topLevelJobId="
					+ topJobId
					+ " is incorrect! It's no containerJobResult and failureReason!");

			return false;
		}

		List<PBInquiryJobResultInternal> inquiryList = Lists.newArrayList();

		boolean bUpdate = getJobResultState(jobResults,
				inquiryJobResultInternal, inquiryList);

		// container job with failure information(has error)
		if (!bUpdate) {
			log.warn(
					"ContainerJob data in topLevelJobId="
							+ topJobId
							+ " is incorrect! There is {} in all containerJob result!",
					inquiryJobResultInternal.getServiceState().getState()
							.toString());
			return false;
		}

		List<PBInquiryCandidateInternal> candidateList = Lists.newArrayList();
		// container job done successfully(without error)
		for (PBInquiryJobResultInternal resultlist : inquiryList) {

			if (!resultlist.hasStatistics()) {
				if (log.isDebugEnabled()) {
					log.debug(
							"Statistics of InquiryJobResultInternal is null. jobId={}",
							topJobId);
				}
				continue;
			}

			// get original Arm
			PBInquiryResultStatisticsAMR origAmr = inquiryJobResultInternal
					.getStatistics().getAmr();
			// get superimposed Arm
			PBInquiryResultStatisticsAMR superAmr = resultlist.getStatistics()
					.getAmr();
			long sumMatchCount = origAmr.getMatchCount()
					+ superAmr.getMatchCount();
			long sumReadCount = origAmr.getReadCount()
					+ superAmr.getReadCount();

			inquiryJobResultInternal.getStatisticsBuilder().getAmrBuilder()
					.setMatchCount(sumMatchCount).setReadCount(sumReadCount);

			if (!resultlist.hasCandidateList()) {
				log.warn(
						"ContainerJob result's candiateList is null or empty. topLevelJobId={}",
						topJobId);
				continue;
			}

			List<PBInquiryCandidateInternal> internalCandidates = resultlist
					.getCandidateList().getCandidateList();

			if (CollectionsUtil.isEmpty(internalCandidates)) {
				log.warn(
						"ContainerJob result PBInquiryCandidateListInternal's List is empty. topLevelJobId={}",
						topJobId);
				continue;
			}

			candidateList.addAll(internalCandidates);
		}

		inquiryJobResultInternal.getServiceStateBuilder().setState(
				ServiceStateType.SERVICE_STATE_SUCCESS);
		if (!CollectionsUtil.isEmpty(candidateList)) {
			inquiryJobResultInternal.getCandidateListBuilder().addAllCandidate(
					candidateList);
		} else {
			inquiryJobResultInternal.getServiceStateBuilder().setState(
					ServiceStateType.SERVICE_STATE_SUCCESS);
			log.info("ContainerJob data in topLevelJobId=" + topJobId
					+ " is incorrect! it's no candidatelist!");
			return false;
		}

		th.t();
		if (log.isDebugEnabled()) {
			log.debug(th.message());
			log.debug("getAllContainerJobs end. rtn=true. jobId={}", topJobId);
		}
		return true;
	}

	private boolean getJobResultState(List<ContainerJobResult> jobResults,
			PBInquiryJobResultInternal.Builder inquiryJobResultInternal,
			List<PBInquiryJobResultInternal> inquiryList) {
		boolean existsRollbackState = false;
		for (ContainerJobResult containJob : jobResults) {
			PBInquiryJobResultInternal jobResultInternal;
			try {
				if (null == containJob.getContainerJobsResult()) {
					continue;
				}
				jobResultInternal = PBInquiryJobResultInternal
						.parseFrom(containJob.getContainerJobsResult());
				PBServiceState serviceState = jobResultInternal
						.getServiceState();
				inquiryList.add(jobResultInternal);

				if (serviceState.getState().equals(
						ServiceStateType.SERVICE_STATE_ERROR)) {
					inquiryJobResultInternal.setServiceState(serviceState);
					return false;

				} else if (serviceState.getState().equals(
						ServiceStateType.SERVICE_STATE_ROLLBACK)) {
					inquiryJobResultInternal.setServiceState(serviceState);
					existsRollbackState = true;
				}

			} catch (InvalidProtocolBufferException e) {
				throw new AimRuntimeException(
						"InvalidProtocolBufferException occurred "
								+ "when parseFrom PBInquiryJobResultInternal instance",
						e);
			}
		}
		if (existsRollbackState) {
			return false;
		}
		return true;
	}

	/**
	 * 
	 * @param family
	 * @param searchJobResult
	 * @param jobQueue
	 */
	private void markHits(FunctionFamily family,
			PBInquiryJobResult.Builder searchJobResult, JobQueueEntity jobQueue) {
		long threadId = Thread.currentThread().getId();
		if (log.isDebugEnabled()) {
			log.debug("Start marking hit flag. jobId={}, threadId={}.",
					jobQueue.getJobId(), threadId);
		}
		TimeHelper th = new TimeHelper("markHits");
		th.t();
		DynamicThresholdParams params = new DynamicThresholdParams(family,
				jobQueue.getPercentagePoint().doubleValue(), jobQueue
						.getHitThreshold().intValue());
		try {
			HitMarking.markHits(searchJobResult, params);
		} catch (AimRuntimeException e) {
			log.error(
					"Exception occurred during hit-or-no-hit (asterisk) marking logic, ignoring..."
							+ " jobId={} threadId={}", jobQueue.getJobId(),
					threadId, e);
		} finally {
			th.t();
			if (log.isDebugEnabled()) {
				log.debug(th.message());
				log.debug("End marking hit flag... jobId={} threadId={}",
						jobQueue.getJobId(), threadId);
			}
		}
	}

	private void doAfterMergeProcess(PBInquiryJobResult pBInquiryJobResult,
			JobQueueEntity jobQueue) {
		long threadId = Thread.currentThread().getId();
		if (log.isDebugEnabled()) {
			log.debug("doAfterMergeProcess start... jobId={} threadId={}",
					jobQueue.getJobId(), threadId);
		}

		TimeHelper th = new TimeHelper("doAfterMergeProcess");
		th.t();

		byte[] inquiryJobResult = pBInquiryJobResult.toByteArray();

		if (log.isDebugEnabled()) {
			log.debug(
					"Setting final results to JOB_QUEUE record.. jobId={} threadId={}",
					jobQueue.getJobId(), threadId);
		}
		boolean bState = pBInquiryJobResult.getServiceState().getState()
				.equals(ServiceStateType.SERVICE_STATE_SUCCESS) ? true : false;

		aggregatorDao.callCompleteTopLevelJob(jobQueue.getJobId(),
				inquiryJobResult, !bState);

		manager.refresh(jobQueue);

		JobDoneLogger jobDoneLogger = new JobDoneLogger(ds);
		jobDoneLogger.info(jobQueue, pBInquiryJobResult,
				inquiryJobDao.findMinFunctionId(jobQueue.getJobId()));

		th.t();
		notifyCallbacker(jobQueue.getJobId(), jobQueue.getCallbackStyle(),
				jobQueue.getCallbackUrl(), pBInquiryJobResult);

		if (ConfigProperties.getInstance().isPropertyValue(
				ConfigPropertyNames.IS_PURGE_CONTAINER_JOBS)
				&& bState) {
			inquiryJobDao.clearAllContainerJob(jobQueue.getJobId());
		}

		/* send Jms to IdentifyPlanner */
		JmsSender.getInstance().sendToInquiryJobPlanner(
				NotifierEnum.Aggregator, "send Msg to IdentifyPlanner");
		th.t();

		if (log.isDebugEnabled()) {
			log.debug(th.message());
			log.debug("doAfterMergeProcess end... jobId={} threadId={}",
					jobQueue.getJobId(), threadId);
		}
	}

}

class CandidateComparator implements Comparator<PBInquiryCandidateInternal> {

	@Override
	public int compare(PBInquiryCandidateInternal o1,
			PBInquiryCandidateInternal o2) {
		int first = o1.getConsolidateKey().compareTo(o2.getConsolidateKey());
		int second = first == 0 ? Integer.valueOf(o2.getFusionScore())
				.compareTo(Integer.valueOf(o1.getFusionScore())) : first;
		return second;
	}
}

class CandidateComparatorMerge implements
		Comparator<PBInquiryCandidateInternal> {
	@Override
	public int compare(PBInquiryCandidateInternal o1,
			PBInquiryCandidateInternal o2) {
		int first = Integer.valueOf(o2.getFusionScore()).compareTo(
				Integer.valueOf(o1.getFusionScore()));
		int second = first == 0 ? o1.getExternalId().compareTo(
				o2.getExternalId()) : first;
		return second;
	}
}

class CandidateMergeComparator implements Comparator<PBInquiryCandidate> {
	@Override
	public int compare(PBInquiryCandidate o1, PBInquiryCandidate o2) {
		int first = Integer.valueOf(o2.getFusionScore()).compareTo(
				Integer.valueOf(o1.getFusionScore()));
		int second = first == 0 ? o1.getExternalId().compareTo(
				o2.getExternalId()) : first;
		return second;
	}
}