package jp.co.nec.aim.mm.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The persistent class for the MU_JOB_EXECUTE_PLANS database table.
 * 
 */
@Entity
@Table(name = "MU_JOB_EXECUTE_PLANS")
public class ExecutePlanEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "PLAN_ID")
	private long planId;

	@Column(name = "CONTAINER_ID")
	private int containerId;

	@Column(name = "FUNCTION_ID")
	private int functionId;

	@Column(name = "JOB_ID")
	private long jobId;

	@Column(name = "\"PLAN\"")
	private String plan;

	@Column(name = "PLANED_COUNT")
	private int planedCount;

	@Column(name = "PLANED_TS")
	private long planedTs;

	public ExecutePlanEntity() {
	}

	public long getPlanId() {
		return this.planId;
	}

	public void setPlanId(long planId) {
		this.planId = planId;
	}

	public int getContainerId() {
		return this.containerId;
	}

	public void setContainerId(int containerId) {
		this.containerId = containerId;
	}

	public int getFunctionId() {
		return this.functionId;
	}

	public void setFunctionId(int functionId) {
		this.functionId = functionId;
	}

	public long getJobId() {
		return this.jobId;
	}

	public void setJobId(long jobId) {
		this.jobId = jobId;
	}

	public String getPlan() {
		return this.plan;
	}

	public void setPlan(String plan) {
		this.plan = plan;
	}

	public int getPlanedCount() {
		return this.planedCount;
	}

	public void setPlanedCount(int planedCount) {
		this.planedCount = planedCount;
	}

	public long getPlanedTs() {
		return this.planedTs;
	}

	public void setPlanedTs(long planedTs) {
		this.planedTs = planedTs;
	}

}