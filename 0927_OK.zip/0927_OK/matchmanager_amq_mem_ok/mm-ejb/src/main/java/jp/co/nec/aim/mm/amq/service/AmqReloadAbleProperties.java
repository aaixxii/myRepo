package jp.co.nec.aim.mm.amq.service;
import java.io.File;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.configuration.reloading.FileChangedReloadingStrategy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AmqReloadAbleProperties {
	private static Logger logger = LoggerFactory.getLogger(AmqReloadAbleProperties.class);
	private static final String PROPERTIES_FILE = "aim.mq.properties";
	private static final AmqReloadAbleProperties instance = new AmqReloadAbleProperties();	
	private static PropertiesConfiguration propsConfig;	
	
	public AmqReloadAbleProperties() {	
		//loadAmqConfig();		
	}

	public static AmqReloadAbleProperties getInstance() {	
		return instance;
	}

	public  void loadAmqConfig()  {
		String homePath = System.getProperty("jboss.home.dir");
		homePath =  homePath.endsWith(File.separator) ? File.separator :  homePath + File.separator;
		System.out.print("jboss home:" + homePath);
		String 	amqProtortiesPath = homePath + File.separator + "modules" + File.separator 
				+ "aim" + File.separator + "mm" + File.separator + "configuration" + File.separator + "main" + File.separator + PROPERTIES_FILE;
  	    System.out.print("amqProtortiesPath:" + amqProtortiesPath );		
	
		propsConfig = new PropertiesConfiguration();
		propsConfig.setEncoding("UTF-8");
		try {
			propsConfig.load(amqProtortiesPath);
		} catch (ConfigurationException e) {
			logger.warn("Can't load aim.mq.properties file!");
		}		
		propsConfig.setAutoSave(true);		
		propsConfig.setReloadingStrategy(new FileChangedReloadingStrategy());
	}	

	public String getPropertyValue(String name) {
		return  propsConfig.getString(name);
	}

	/**
	 * return boolean value.
	 * 
	 * If key is not found in the property, this method return false.
	 * 
	 * @param name
	 * @return
	 */
	public boolean isPropertyValue(String name) {
		String value = getPropertyValue(name);
		return Boolean.valueOf(value);
	}
}
