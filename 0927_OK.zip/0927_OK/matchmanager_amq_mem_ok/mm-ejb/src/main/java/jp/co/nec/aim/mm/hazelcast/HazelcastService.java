
package jp.co.nec.aim.mm.hazelcast;

import static jp.co.nec.aim.mm.constants.Constants.extJobResultMapName;
import static jp.co.nec.aim.mm.constants.Constants.extLockMapName;
import static jp.co.nec.aim.mm.constants.Constants.hazelcastConfigPath;
import static jp.co.nec.aim.mm.constants.Constants.mmSyncMapName;

import java.io.IOException;
import java.util.Optional;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hazelcast.config.ClasspathXmlConfig;
import com.hazelcast.config.Config;
import com.hazelcast.core.Hazelcast;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.map.IMap;

import jp.co.nec.aim.message.proto.AIMMessages.PBMuExtractJobResultItem;
import jp.co.nec.aim.mm.acceptor.service.AimInquiryRemote;
import jp.co.nec.aim.mm.acceptor.service.AimSyncRemote;
import jp.co.nec.aim.mm.acceptor.service.RemoteJobItem;
import jp.co.nec.aim.mm.amq.service.AmqServiceManager;
import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.constants.UidRequestType;
import jp.co.nec.aim.mm.sessionbeans.pojo.AimManager;
import jp.co.nec.aim.mm.sessionbeans.pojo.UidAimAmqResponse;
import jp.co.nec.aim.mm.util.XmlUtil;

public class HazelcastService {
	private static Logger logger = LoggerFactory.getLogger(HazelcastService.class);
	private HazelcastInstance hInstance;
	// private ITopic<String> uidTopic;	

	private static HazelcastService INSTANCE = new HazelcastService();
	
	public static HazelcastService getInstance() {
		return INSTANCE;
	}

	public HazelcastService() {
	}

	public void init() {
		String hazecastConfigPath = AimManager.getValueFromUidMMSettingMap(hazelcastConfigPath);
		Config config = new ClasspathXmlConfig(hazecastConfigPath);
		// NetworkConfig netConfig = config.getNetworkConfig();
		hInstance = Hazelcast.newHazelcastInstance(config);
		// hInstance.getMap(extJobResultMapName);
		// hInstance.getMap(extLockMapName);
		logger.info("HazelcastService started!");
		// uidTopic = instance.getTopic("UidNotifyTopic");
	}

	public void saveRemoteJobInfo(Long jobId, RemoteJobItem syncJobItem) {
		IMap<Long, RemoteJobItem> mmSyncMap = hInstance.getMap(mmSyncMapName);	
		mmSyncMap.lock(jobId);
		try {
			mmSyncMap.put(jobId, syncJobItem);
		} finally {
			mmSyncMap.unlock(jobId);
		}
		
	}

	public RemoteJobItem getRemoteJobInfo(Long jobId) {
		IMap<Long, RemoteJobItem> mmSyncMap = hInstance.getMap(mmSyncMapName);
		RemoteJobItem remoteJobInfo = null;
		mmSyncMap.lock(jobId);
		try {
			remoteJobInfo = mmSyncMap.get(jobId);
		} finally {
			mmSyncMap.unlock(jobId);
		}		
		return remoteJobInfo;
	}

	public String getSyncMMUrl(Long jobId) {
		IMap<Long, RemoteJobItem> mmSyncMap = hInstance.getMap(mmSyncMapName);
		RemoteJobItem syncJobInfo = mmSyncMap.get(jobId);
		return syncJobInfo.getMmUrl();
	}

	public void saveToExtractLockQueue(String key, Long obj) {
		IMap<String, Long> extLockMap = hInstance.getMap(extLockMapName);
		extLockMap.put(key, obj);
		logger.info("extLockMap size= {}", extLockMap.size());
	}

	public void saveToExtractJobResutQueue(String key, PBMuExtractJobResultItem oneFejobResut) {
		IMap<String, PBMuExtractJobResultItem> extractJobResutMap = hInstance.getMap(extJobResultMapName);
		extractJobResutMap.put(key, oneFejobResut);
		logger.info("extractJobResutMap size= {}", extractJobResutMap.size());
		IMap<String, Long> extLockMap = hInstance.getMap(extLockMapName);
		logger.info("extLockMap size= {}", extLockMap.size());
		// String mmUrl = getSyncMMUrl(Long.valueOf(key));
		RemoteJobItem remoteJobInfo = getRemoteJobInfo(Long.valueOf(key));
		if (remoteJobInfo.getUidRequestType().equals(UidRequestType.Insert)) {
			try {
				callRemoteSyncService(remoteJobInfo);
			} catch (NamingException e) {
				logger.error(e.getMessage(), e);
				AimError aimError = AimError.INTERNAL_ERROR;
				UidAimAmqResponse response = new UidAimAmqResponse();
				String xmlRes = null;
				try {
					xmlRes = XmlUtil.dom4jCreateFaildXml(remoteJobInfo.getRequestId(), aimError.getErrorCode());
				} catch (IOException e1) {
					logger.error(e.getMessage(), e);
					xmlRes = "Create response xml faild";
				}	
				response.setRequestId(remoteJobInfo.getRequestId());
				response.setRequestType(UidRequestType.Insert.name());
				response.setXmlResult(xmlRes);
				AmqServiceManager.getInstance().addToAmqQueue(response);
			}
		} else if (remoteJobInfo.getUidRequestType().equals(UidRequestType.Identify)) {
			try {
				callRemoteInquiryService(remoteJobInfo);
			} catch (NamingException e) {
				logger.error(e.getMessage(), e);
				logger.error(e.getMessage(), e);
				AimError aimError = AimError.INTERNAL_ERROR;
				UidAimAmqResponse response = new UidAimAmqResponse();
				String xmlRes = null;
				try {
					xmlRes = XmlUtil.dom4jCreateFaildXml(remoteJobInfo.getRequestId(), aimError.getErrorCode());
				} catch (IOException e1) {
					logger.error(e.getMessage(), e);
					xmlRes = "Create response xml faild";
				}	
				response.setRequestId(remoteJobInfo.getRequestId());
				response.setRequestType(UidRequestType.Identify.name());
				response.setXmlResult(xmlRes);				
				AmqServiceManager.getInstance().addToAmqQueue(response);
			}
		}	
	}	


	public PBMuExtractJobResultItem getExtractJobResult(String feJobId) {
		IMap<String, PBMuExtractJobResultItem> extractJobResutMap = hInstance.getMap(extJobResultMapName);
		logger.info("extractJobResutMap size= {}", extractJobResutMap.size());
		return Optional.of(extractJobResutMap.get(feJobId)).orElse(null);
	}

	public void finishExtractJob(String extJobId) {
		//IMap<String, Long> extractLockQueue = hInstance.getMap(extLockMapName);
		IMap<String, PBMuExtractJobResultItem> extractJobResutQueue = hInstance.getMap(extJobResultMapName);
		try {
			//extractLockQueue.remove(extJobId);
			extractJobResutQueue.remove(extJobId);
		} catch (Exception e) {
			logger.warn("Object associated with key:{} may be removed!", extJobId);
		}
	}

	public void shutdown() {
		hInstance.shutdown();
	}

	public void callRemoteSyncService(RemoteJobItem syncJobInfo) throws javax.naming.NamingException {
		String mmUrl = getSyncMMUrl(Long.valueOf(syncJobInfo.getFeJobId()));
		Properties jndiProperties = new Properties();
		jndiProperties.put(Context.INITIAL_CONTEXT_FACTORY, "org.jboss.naming.remote.client.InitialContextFactory");
		jndiProperties.put(Context.URL_PKG_PREFIXES, "org.jboss.ejb.client.naming");
		jndiProperties.put(Context.PROVIDER_URL, "http-remoting://" + mmUrl);
		jndiProperties.put("jboss.naming.client.ejb.context", true);
		Context jndiContext = new InitialContext(jndiProperties);
		AimSyncRemote syncRemote = (AimSyncRemote) jndiContext
				.lookup("/matchmanager/mm-ejb/AimSyncRemoteService!jp.co.nec.aim.mm.acceptor.service.AimSyncRemote");
		syncRemote.getExtResAndDoSync(syncJobInfo);
		jndiContext.close();
	}
	
	public void callRemoteInquiryService(RemoteJobItem inquiryJobInfo) throws javax.naming.NamingException {
		String mmUrl = getSyncMMUrl(Long.valueOf(inquiryJobInfo.getFeJobId()));
		Properties jndiProperties = new Properties();
		jndiProperties.put(Context.INITIAL_CONTEXT_FACTORY, "org.wildfly.naming.client.WildFlyInitialContextFactory");
		jndiProperties.put(Context.URL_PKG_PREFIXES, "org.jboss.ejb.client.naming");
		// jndiProperties.put(Context.PROVIDER_URL, "http-remoting://127.0.0.1:8080");
		jndiProperties.put(Context.PROVIDER_URL, "http-remoting://" + mmUrl);
		jndiProperties.put("jboss.naming.client.ejb.context", true);
		Context jndiContext = new InitialContext(jndiProperties);
		AimInquiryRemote inqRemote = (AimInquiryRemote) jndiContext
				.lookup("/matchmanager/mm-ejb/AimInquiryRemoveService!jp.co.nec.aim.mm.acceptor.service.AimInquiryRemote");
		inqRemote.getExtResAndDoInquriy(inquiryJobInfo);
		jndiContext.close();
	}

}
