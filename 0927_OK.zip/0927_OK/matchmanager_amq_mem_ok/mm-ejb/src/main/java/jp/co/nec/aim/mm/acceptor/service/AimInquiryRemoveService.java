package jp.co.nec.aim.mm.acceptor.service;
import java.util.List;
import java.util.Optional;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Lists;

import jp.co.nec.aim.message.proto.AIMMessages.PBMuExtractJobResultItem;
import jp.co.nec.aim.mm.acceptor.AimInquiryRequest;
import jp.co.nec.aim.mm.acceptor.CommonOptions;
import jp.co.nec.aim.mm.acceptor.Inquiry;
import jp.co.nec.aim.mm.hazelcast.HazelcastService;

@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class AimInquiryRemoveService implements AimInquiryRemote {
	
	private static Logger log = LoggerFactory.getLogger(AimInquiryRemoveService.class);
	
	@PersistenceContext(unitName = "aim-db")
	private EntityManager manager;
	
	@EJB
	private Inquiry inquiry;
	
	
	
	public AimInquiryRemoveService() {
		// zero-arg ctor for container.
	}

	@PostConstruct
	public void init() {		
	}
	
	@Override
	public void getExtResAndDoInquriy(RemoteJobItem inqJobInfo) {
		Long feJobId = inqJobInfo.getFeJobId();
		String requestId = inqJobInfo.getRequestId();		
		String inqRequest = inqJobInfo.getRequst();
		Optional<PBMuExtractJobResultItem> onejobResult = Optional.ofNullable(HazelcastService.getInstance().getExtractJobResult(feJobId.toString()));
		if (onejobResult.isPresent()) {
			log.info("Get PBMuExtractJobResultItem for identify feJobId({}) result success", feJobId);
		} else {
			log.warn("Got empty PBMuExtractJobResultItem, key={}", feJobId);		
		}	
		HazelcastService.getInstance().finishExtractJob(feJobId.toString());
		byte[] templateData = onejobResult.get().getBisonTemplate().toByteArray();
		if (templateData != null && templateData.length > 1) {			
			AimInquiryRequest aimInquiryRequest = new AimInquiryRequest("MI", Integer.valueOf(1), requestId, inqRequest, templateData);
			final List<AimInquiryRequest> aimRequestList = Lists.newArrayList();
			aimRequestList.add(aimInquiryRequest);
			final CommonOptions options = new CommonOptions();
			options.setFromServlet(inqJobInfo.getIsFromServlet().booleanValue());
			options.setFunctioName("MI");
			options.setMaxCandidates(Integer.valueOf(inqJobInfo.getMaxResults()));
			inquiry.inquiry(aimRequestList, requestId, options);		
		}
	}
}
