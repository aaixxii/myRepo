package jp.co.nec.lsm.event.enroll.notifier;

import jp.co.nec.lsm.event.enroll.EnrollAbstractEvent;
import jp.co.nec.lsm.event.enroll.common.EventEnrollRuntimeException;
import jp.co.nec.lsm.event.sender.EventSender;
import jp.co.nec.lsm.event.sender.EventSenderJMSLocalImpl;
import jp.co.nec.lsm.tm.common.constants.JNDIConstants;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author liuyq <br>
 */
public class EnrollNotifier {

	private static Logger log = LoggerFactory.getLogger(EnrollNotifier.class);

	/**
	 * constructor
	 */
	public EnrollNotifier() {
	}

	public void sendEvent(EnrollAbstractEvent event) {
		printLogMessage("start public function eventNotify.");

		EventSender eventSender = null;

		switch (event.getEnrollReceiver()) {

		case TemplateManagerBean:
			eventSender = EventSenderJMSLocalImpl
					.getInstance(JNDIConstants.TEMPLATE_MANAGER_QUEUE);
			break;
		case EnrollSegmentSyncService:
			eventSender = EventSenderJMSLocalImpl
					.getInstance(JNDIConstants.ENROLL_SYNC_SEGMENT_QUEUE);
			break;
		case EnrollResponseService:
		case EnrollJobPollTimerStarterBean:
		case EnrollMFEPollTimerStarterBean:
		case EnrollBatchJobGetterTimerStartBean:
		case EnrollHeartbeatStarterBean:
			eventSender = EventSenderJMSLocalImpl
					.getInstance(JNDIConstants.ENROLL_QUEUE);
			break;
		default:
			throw new EventEnrollRuntimeException("the event is not support..");
		}
		printLogMessage("Send event to " + event.getEnrollReceiver().toString());

		synchronized (eventSender) {
			eventSender.convertAndSend(event);
		}
		printLogMessage("end public function eventNotify.");

	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @param objects
	 */
	private static void printLogMessage(String logMessage, Object... objects) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage, objects);
		}
	}
}
