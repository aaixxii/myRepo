package jp.co.nec.lsm.event;

import java.io.Serializable;

/**
 * @author jimy <br>
 *         interface Event
 */
public interface Event extends Serializable {
	/**
	 * get event batch job id
	 * 
	 * @return batch job id
	 */
	public long getBatchJobId();

	/**
	 * get output trace message <br>
	 * from -> Notifier <br>
	 * to -> Receiver <br>
	 * 
	 * @return track message
	 */
	public String[] getTraceMessage();

	/**
	 * get JMS message selector
	 * 
	 * @return JMS selector
	 */
	public abstract String getMessageSelector();

}
