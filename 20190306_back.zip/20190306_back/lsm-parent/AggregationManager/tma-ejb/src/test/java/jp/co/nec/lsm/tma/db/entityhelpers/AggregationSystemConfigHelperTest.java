package jp.co.nec.lsm.tma.db.entityhelpers;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.io.InputStream;
import java.util.EnumSet;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.lsm.tm.common.constants.ConfigProperty;
import jp.co.nec.lsm.tm.common.constants.SystemConfigNamespace;
import jp.co.nec.lsm.tm.db.common.entityhelpers.SystemConfigHelper;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class AggregationSystemConfigHelperTest {

	@PersistenceContext(unitName = "tma-unit")
	private EntityManager entityManager;
	private Properties properties = new Properties();
	private JdbcTemplate jdbcTemplate;
	@Resource
	private DataSource dataSource;

	@Before
	public void setUp() {
		jdbcTemplate = new JdbcTemplate(dataSource);
		try {
			InputStream is = ConfigProperty.class.getClassLoader()
					.getResourceAsStream(
							SystemConfigNamespace.TM
									.getDefaultPropertiesFilename());
			properties.load(is);
			is.close();
		} catch (IOException e) {
			fail(e.getMessage());
		}
	}

	/**
	 * Check whether key-values in default.tmi.properties are existed in
	 * SYSTEM_CONFIG table.
	 */
	@Test
	public void testWriteAllMissingProperties() {
		jdbcTemplate.execute("delete from SYSTEM_CONFIG");

		SystemConfigHelper helper = new SystemConfigHelper();
		helper.writeAllMissingProperties(dataSource);
		Set<Entry<Object, Object>> entrySet = properties.entrySet();
		for (Entry<Object, Object> e : entrySet) {
			String key = (String) e.getKey();
			String value = properties.getProperty(key);
			assertEquals(value, helper.getTMProperty(key));
		}
	}

	/**
	 * Get MM Property test
	 */
	@Test
	public void testGetMMProperty() {
		jdbcTemplate.execute("delete from SYSTEM_CONFIG");
		SystemConfigHelper helper = new SystemConfigHelper();
		helper.writeAllMissingProperties(dataSource);
		Set<Entry<Object, Object>> entrySet = properties.entrySet();

		for (Entry<Object, Object> e : entrySet) {
			String key = (String) e.getKey();
			for (ConfigProperty mm : EnumSet.allOf(ConfigProperty.class)) {
				if (mm.getName().equals(key)) {
					assertEquals(properties.getProperty(key), helper
							.getTMProperty(mm));
				}
			}
		}
	}

	/**
	 * MMConfigProperty must have same number of member as properties
	 */
	@Test
	public void testMMPConfigPropertySize() {
		assertEquals(properties.size(), EnumSet.allOf(ConfigProperty.class)
				.size());
	}

}
