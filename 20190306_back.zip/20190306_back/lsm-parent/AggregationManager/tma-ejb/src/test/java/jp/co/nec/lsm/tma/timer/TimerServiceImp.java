package jp.co.nec.lsm.tma.timer;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import javax.ejb.EJBException;
import javax.ejb.NoMoreTimeoutsException;
import javax.ejb.NoSuchObjectLocalException;
import javax.ejb.ScheduleExpression;
import javax.ejb.Timer;
import javax.ejb.TimerConfig;
import javax.ejb.TimerHandle;
import javax.ejb.TimerService;

public class TimerServiceImp implements TimerService{

	@Override
	public Timer createCalendarTimer(ScheduleExpression schedule)
			throws IllegalArgumentException, IllegalStateException,
			EJBException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Timer createCalendarTimer(ScheduleExpression schedule,
			TimerConfig timerConfig) throws IllegalArgumentException,
			IllegalStateException, EJBException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Timer createIntervalTimer(Date initialExpiration,
			long intervalDuration, TimerConfig timerConfig)
			throws IllegalArgumentException, IllegalStateException,
			EJBException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Timer createIntervalTimer(long initialDuration,
			long intervalDuration, TimerConfig timerConfig)
			throws IllegalArgumentException, IllegalStateException,
			EJBException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Timer createSingleActionTimer(Date expiration,
			TimerConfig timerConfig) throws IllegalArgumentException,
			IllegalStateException, EJBException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Timer createSingleActionTimer(long duration, TimerConfig timerConfig)
			throws IllegalArgumentException, IllegalStateException,
			EJBException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Timer createTimer(long duration, Serializable info)
			throws IllegalArgumentException, IllegalStateException,
			EJBException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Timer createTimer(long initialDuration, long intervalDuration,
			Serializable info) throws IllegalArgumentException,
			IllegalStateException, EJBException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Timer createTimer(Date expiration, Serializable info)
			throws IllegalArgumentException, IllegalStateException,
			EJBException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Timer createTimer(Date initialExpiration, long intervalDuration,
			Serializable info) throws IllegalArgumentException,
			IllegalStateException, EJBException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Collection<Timer> getTimers() throws IllegalStateException,
			EJBException {
		// TODO Auto-generated method stub
		List<Timer> timers = new ArrayList<Timer>();
		timers.add(new TestTimer());
		return timers;
	}

	class TestTimer implements Timer{

		@Override
		public void cancel() throws IllegalStateException,
				NoSuchObjectLocalException, EJBException {
			// TODO Auto-generated method stub
			
		}

		@Override
		public TimerHandle getHandle() throws IllegalStateException,
				NoSuchObjectLocalException, EJBException {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public Serializable getInfo() throws IllegalStateException,
				NoSuchObjectLocalException, EJBException {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public Date getNextTimeout() throws IllegalStateException,
				NoMoreTimeoutsException, NoSuchObjectLocalException,
				EJBException {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public ScheduleExpression getSchedule() throws IllegalStateException,
				NoSuchObjectLocalException, EJBException {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public long getTimeRemaining() throws IllegalStateException,
				NoMoreTimeoutsException, NoSuchObjectLocalException,
				EJBException {
			// TODO Auto-generated method stub
			return 0;
		}

		@Override
		public boolean isCalendarTimer() throws IllegalStateException,
				NoSuchObjectLocalException, EJBException {
			// TODO Auto-generated method stub
			return false;
		}

		@Override
		public boolean isPersistent() throws IllegalStateException,
				NoSuchObjectLocalException, EJBException {
			// TODO Auto-generated method stub
			return false;
		}
		
	}

    @Override
    public Collection<Timer> getAllTimers() throws IllegalStateException, EJBException {
        // TODO Auto-generated method stub
        return null;
    }
}
