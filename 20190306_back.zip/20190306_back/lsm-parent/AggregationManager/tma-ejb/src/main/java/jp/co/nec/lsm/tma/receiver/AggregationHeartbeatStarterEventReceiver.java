package jp.co.nec.lsm.tma.receiver;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.jms.MessageListener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.lsm.event.Event;
import jp.co.nec.lsm.event.identify.IdentifyStartHeartbeatTimerEvent;
import jp.co.nec.lsm.event.receiver.AbstractEventReceiver;
import jp.co.nec.lsm.tm.common.constants.JNDIConstants;
import jp.co.nec.lsm.tm.common.util.ServiceLocator;
import jp.co.nec.lsm.tma.timer.AggregationHeartbeatStarterBean;

@MessageDriven(activationConfig = {
		@ActivationConfigProperty(propertyName = "acknowledgeMode", propertyValue = "Auto-acknowledge"),
		@ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Queue"),
		@ActivationConfigProperty(propertyName = "destination", propertyValue = JNDIConstants.AGGREGATION_QUEUE),
		@ActivationConfigProperty(propertyName = "messageSelector", propertyValue = "messageReceiver = 'AggregationHeartbeatStarterBean'") })
public class AggregationHeartbeatStarterEventReceiver extends
		AbstractEventReceiver implements MessageListener {

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(AggregationHeartbeatStarterEventReceiver.class);

	@Override
	protected void dispatchEvent(Event event) {
		// look up the service session bean
		if (!(event instanceof IdentifyStartHeartbeatTimerEvent)) {
			log.error("event is not a IdentifyStartHeartbeatTimerEvent instance.");
			return;
		}

		String jndiName = JNDIConstants.TMA_HEARTBEAT_START_BEAN;				
				
		AggregationHeartbeatStarterBean timerService = ServiceLocator
				.getLookUpJndiObject(jndiName,
						AggregationHeartbeatStarterBean.class);
		IdentifyStartHeartbeatTimerEvent timeEvent = (IdentifyStartHeartbeatTimerEvent)event;
		int pollDuraton = timeEvent.getPollDuraton();
		// do service session bean
		timerService.startTimer(pollDuraton);
	}

}
