package jp.co.nec.lsm.tme.sessionbeans.api;

import javax.ejb.Local;

/**
 * @author mozj <br>
 * 
 */
@Local
public interface EnrollDeadLevelQueueServiceLocal {
	/**
	 * receive the event from dead letter queue <br>
	 * (while segment sync service retry over limit)
	 * 
	 * @param batchJobId
	 */
	public void receiveEventFromDLQ(long batchJobId, boolean isEnrollJob);
}
