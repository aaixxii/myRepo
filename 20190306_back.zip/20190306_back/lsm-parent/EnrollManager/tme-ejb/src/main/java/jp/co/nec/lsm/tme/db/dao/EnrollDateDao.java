package jp.co.nec.lsm.tme.db.dao;

import java.util.Date;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.sql.DataSource;

import jp.co.nec.lsm.tm.db.common.entityhelpers.DateHelper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author liuj <br>
 * 
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class EnrollDateDao  {
	@Resource(mappedName = "java:jboss/OracleDS")
	protected DataSource dataSource;

	private DateHelper dateHelper;

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(EnrollDateDao.class);

	@PostConstruct
	public void init() {
		dateHelper = new DateHelper(dataSource);
		printLogMessage("EnrollDateDao init");

	}

	
	public Date getDatabaseDate() {
		printLogMessage("start function getDatabaseDate to get Database Date.");
		return dateHelper.getDatabaseDate();
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}
}
