package jp.co.nec.lsm.tme.service.sessionbean;

import javax.ejb.Local;

/**
 * @author liuj
 */
@Local
public interface EnrollSystemDownManagerLocal {
	/**
	 * TME shutdown process.
	 */
	public void shutdown();
}
