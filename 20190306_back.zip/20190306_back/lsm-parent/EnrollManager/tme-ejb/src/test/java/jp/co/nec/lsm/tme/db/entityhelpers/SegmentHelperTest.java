package jp.co.nec.lsm.tme.db.entityhelpers;

import static org.junit.Assert.assertEquals;

import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.lsm.tm.db.common.entities.SegmentEntity;
import jp.co.nec.lsm.tm.db.common.entityhelpers.SegmentHelper;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
@Ignore
public class SegmentHelperTest {
	@PersistenceContext(unitName = "tme-ngi")
	protected EntityManager entityManager;
	@Resource
	protected DataSource dataSource;
	@Resource
	protected JdbcTemplate jdbcTemplate;

	/**
	 * 
	 * Test Case<br/>
	 * Test [testgetAllSegmentsInfo]<br/>
	 * 1 - prepare Segments For test<br/>
	 * 2 - call getAllSegmentsInfo, to get all Segments information<br/>
	 * 3 - assert concerning information<br/>
	 */
	@Test
	public void testgetAllSegmentsInfo() {
		// 1 - prepare Segments For test
		prepareSegments();
		SegmentHelper segmentHelper = new SegmentHelper(entityManager);
		// 2 - call getAllSegmentsInfo, to get all Segments information
		List<SegmentEntity> segmentEntityList = segmentHelper
				.getAllSegmentsInfo();
		//3 - assert concerning information
		assertEquals(23, segmentEntityList.size());
	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testgetLastSegmentEntity]<br/>
	 * 1 - prepare Segments For test<br/>
	 * 2 - call getLastSegmentEntity, to get last Segment information<br/>
	 * 3 - assert concerning information<br/>
	 */
	@Test
	public void testgetLastSegmentEntity() {
		//1 - prepare Segments For test
		prepareSegments();
		SegmentHelper segmentHelper = new SegmentHelper(entityManager);
		
		//2 - call getLastSegmentEntity, to get last Segment information
		SegmentEntity segmentEntity = segmentHelper.getLastSegmentEntity();
		
		//3 - assert concerning information
		assertEquals(25, segmentEntity.getSegmentId());
	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testgetSegmentEntity]<br/>
	 * 1 - prepare Segments For test<br/>
	 * 2 - call getSegmentEntity, to get last getSegmentEntity information<br/>
	 * 3 - assert concerning information<br/>
	 */
	@Test
	public void testgetSegmentEntity() {
		
		//1 - prepare Segments For test
		prepareSegments();
		
		SegmentHelper segmentHelper = new SegmentHelper(entityManager);
		long segmentId = 17;
		
		//2 - call getSegmentEntity, to get last getSegmentEntity information
		SegmentEntity segmentEntity = segmentHelper.getSegmentEntity(segmentId);
		
		//3 - assert concerning information
		assertEquals(17, segmentEntity.getSegmentId());
	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testgetSegmentEntity]<br/>
	 * 1 - prepare Segments For test<br/>
	 * 2 - call getSegmentEntity, to get last getSegmentEntity information<br/>
	 * 3 - prepare segmentEntity for test<br/>
	 * 4 - call mergeSegment, to update getSegmentEntity information<br/>
	 * 5 - assert concerning information<br/>
	 */
	@Test
	public void testmergeSegment() {
		// 1 - prepare Segments For test
		prepareSegments();
		SegmentHelper segmentHelper = new SegmentHelper(entityManager);
		long segmentId = 18;
		//2 - call getSegmentEntity, to get last getSegmentEntity information
		SegmentEntity segmentEntity = segmentHelper.getSegmentEntity(segmentId);
		
		//3 - prepare segmentEntity for test
		segmentEntity.setVersion(32);
		segmentEntity.setBioIdEnd(89L);
		segmentEntity.setBioIdStart(43L);
		segmentEntity.setRecordCount(54);
		segmentEntity.setGeneration(56);
		segmentEntity.setBinaryLengthCompacted(342L);
		segmentEntity.setBinaryLengthUncompacted(328748L);
		SegmentEntity segmentEntity1 = segmentEntity;
		
		//4 - call mergeSegment, to update getSegmentEntity information
		segmentHelper.mergeSegment(segmentEntity1);
		//2 - call getSegmentEntity, to get last getSegmentEntity information
		SegmentEntity segmentEntity2 = segmentHelper
				.getSegmentEntity(segmentId);
		//5 - assert concerning information
		assertEquals(32, segmentEntity2.getVersion());
		assertEquals(89L, segmentEntity2.getBioIdEnd());
		assertEquals(43L, segmentEntity2.getBioIdStart());
		assertEquals(54, segmentEntity2.getRecordCount());
		assertEquals(56, segmentEntity2.getGeneration());
		assertEquals(342L, segmentEntity2.getBinaryLengthCompacted());
		assertEquals(328748L, segmentEntity2.getBinaryLengthUncompacted());

	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testgetSegmentEntity]<br/>
	 * 1 - prepare Segments/persistSegments For test<br/>
	 * 2 - call persistSegments, insert EnrollSegmentEntity into database<br/>
	 * 3 - call getAllSegmentsInfo,to get data<br/>
	 * 4 - assert concerning information<br/>
	 */
	@Test
	public void testpersistSegments() {
		
		//1 - prepare Segments/persistSegments For test
		prepareSegments();
		SegmentHelper segmentHelper = new SegmentHelper(entityManager);
		List<SegmentEntity> segmentEntityList = preparepersistSegments();
		
		//2 - call persistSegments, insert EnrollSegmentEntity into database
		segmentHelper.persistSegments(segmentEntityList);
		
		//3 - call getAllSegmentsInfo,to get data
		List<SegmentEntity> segmentEntityList1 = segmentHelper
				.getAllSegmentsInfo();
		
		//4 - assert concerning information
		assertEquals(58, segmentEntityList1.size());
	}

	/**
	 * prepare persistSegments for testig
	 * 
	 * @return
	 */
	private List<SegmentEntity> preparepersistSegments() {
		// prepareSegments();
		List<SegmentEntity> segmentList = new ArrayList<SegmentEntity>();
		for (long id = 26; id <= 60; id++) {
			SegmentEntity segmentEntity = new SegmentEntity();
			// segmentEntity.setSegmentId(id);
			segmentEntity.setVersion(32 + (int) id);
			segmentEntity.setBioIdEnd(89L + id);
			segmentEntity.setBioIdStart(43L + id);
			segmentEntity.setRecordCount(54 + (int) id);
			segmentEntity.setGeneration(56 + (int) id);
			segmentEntity.setBinaryLengthCompacted(342L + id);
			segmentEntity.setBinaryLengthUncompacted(328748L + id);
			segmentList.add(segmentEntity);
		}
		return segmentList;
	}

	/**
	 * Set WORKING MUs(MU_ID=1,2,5), SEGMENTS(ID=1,2,5) to BIN_ID=1,5.
	 * 
	 */
	private void prepareSegments() {
		jdbcTemplate.execute("delete FROM segments");
		String segmentsSql = "insert into segments (SEGMENT_ID,BIO_ID_START,BIO_ID_END,"
				+ "BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,GENERATION,BINARY_LENGTH_UNCOMPACTED)"
				+ " values(:SEGMENT_ID,  :BIO_ID_START,:BIO_ID_END,"
				+ ":BINARY_LENGTH_COMPACTED, :RECORD_COUNT, :VERSION, :GENERATION, :BINARY_LENGTH_UNCOMPACTED)";
		{
			// insert into segments, SEGMENT_ID=1
			Map<String, Object> argMap = new HashMap<String, Object>();
			argMap.put("SEGMENT_ID", new Long(1));
			argMap.put("BIO_ID_START", new Long(1));
			argMap.put("BIO_ID_END", new Long(10));
			argMap.put("BINARY_LENGTH_COMPACTED", new Long(10));
			argMap.put("RECORD_COUNT", new Long(10));
			argMap.put("VERSION", new Long(1));
			argMap.put("GENERATION", new Long(1));
			argMap.put("BINARY_LENGTH_UNCOMPACTED", new Long(100));
			jdbcTemplate.update(segmentsSql, argMap);
		}
		{
			// insert into segments, SEGMENT_ID=2
			Map<String, Object> argMap = new HashMap<String, Object>();
			argMap.put("SEGMENT_ID", new Long(2));
			argMap.put("BIO_ID_START", new Long(1));
			argMap.put("BIO_ID_END", new Long(10));
			argMap.put("BINARY_LENGTH_COMPACTED", new Long(10));
			argMap.put("RECORD_COUNT", new Long(10));
			argMap.put("VERSION", new Long(1));
			argMap.put("GENERATION", new Long(1));
			argMap.put("BINARY_LENGTH_UNCOMPACTED", new Long(100));
			jdbcTemplate.update(segmentsSql, argMap);
		}
		{
			Map<String, Object> argMap = new HashMap<String, Object>();
			argMap.put("SEGMENT_ID", new Long(5));
			argMap.put("BIO_ID_START", new Long(1));
			argMap.put("BIO_ID_END", new Long(10));
			argMap.put("BINARY_LENGTH_COMPACTED", new Long(10));
			argMap.put("RECORD_COUNT", new Long(10));
			argMap.put("VERSION", new Long(1));
			argMap.put("GENERATION", new Long(1));
			argMap.put("BINARY_LENGTH_UNCOMPACTED", new Long(100));
			jdbcTemplate.update(segmentsSql, argMap);
		}
		String sql = "insert into segments (SEGMENT_ID,BIO_ID_START,BIO_ID_END,"
				+ "BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,GENERATION,BINARY_LENGTH_UNCOMPACTED)"
				+ " values(?, 1, 10, 10, 10, 1, 1, 100)";
		long max = jdbcTemplate
				.queryForObject("select MAX(SEGMENT_ID) from SEGMENTS", Long.class);
		for (long id = max + 1; id <= 25; id++) {
			jdbcTemplate.update(sql, new Object[] { new Long(id) },
					new int[] { Types.BIGINT });
		}
	}
}