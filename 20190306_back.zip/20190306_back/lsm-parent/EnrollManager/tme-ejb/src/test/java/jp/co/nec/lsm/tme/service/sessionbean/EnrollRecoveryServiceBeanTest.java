package jp.co.nec.lsm.tme.service.sessionbean;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentLinkedQueue;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.sql.DataSource;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.google.protobuf.InvalidProtocolBufferException;

import jp.co.nec.lsm.proto.common.CommonProto.ReturnCode;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollBatchJobQueueEntity;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollBatchJobStatus;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollJobQueueEntity;
import jp.co.nec.lsm.tme.core.jobs.EnrollBatchJobManager;
import jp.co.nec.lsm.tme.core.jobs.LocalEnrollBatchJob;
import jp.co.nec.lsm.tme.core.jobs.LocalExtractJobInfo;
import jp.co.nec.lsm.tme.core.jobs.LocalExtractJobStatus;
import jp.co.nec.lsm.tme.util.TMETestUtil;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class EnrollRecoveryServiceBeanTest {

	@Resource(mappedName = "java:jboss/OracleDS")
	private DataSource dataSource;
	@PersistenceContext(unitName = "tme-ngi")
	private EntityManager manager;
	protected JdbcTemplate jdbcTemplate;

	@Resource
	EnrollRecoveryServiceBean recoveryService;

	/**
	 * initialize
	 */
	@Before
	public void setUp() {
		int i = 0;

		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		ConcurrentLinkedQueue<LocalEnrollBatchJob> enrollLinkQueue = queueManage
				.getEnrollLinkQueue();

		if (!enrollLinkQueue.isEmpty()) {
			for (i = 1; i <= enrollLinkQueue.size(); i++) {
				enrollLinkQueue.poll();
			}
		}

		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	/**
	 * setMockMethod
	 */
	private void setMockMethod() {
		TMETestUtil.setJMSMockMethod();
	}

	/**
	 * @throws InvalidProtocolBufferException
	 * 
	 */
	@Test
	public void testRecoverUnCompletedBatchJob()
			throws InvalidProtocolBufferException {
		// 1 - clear database to avoid disturbing
		jdbcTemplate.execute("delete FROM TRANSACTION_MANAGERS");
		jdbcTemplate.execute("delete FROM SYSTEM_CONFIG");
		jdbcTemplate.execute("delete FROM ENROLL_JOB_QUEUE");
		jdbcTemplate.execute("delete FROM ENROLL_BATCH_JOB_QUEUE");

		// 2 - prepare EnrollBatchJobQueueEntity/EnrollJobQueueEntity For test
		for (int i = 101; i <= 103; i++) {
			EnrollBatchJobQueueEntity batchJob = new EnrollBatchJobQueueEntity();
			batchJob.setBatchjobId(i);
			if (i == 101) {
				batchJob.setBatchjobStatus(EnrollBatchJobStatus.QUEUED
						.getIntValues());
			} else if (i == 102) {
				batchJob.setBatchjobStatus(EnrollBatchJobStatus.REGISTERED
						.getIntValues());
			} else {
				batchJob.setBatchjobStatus(EnrollBatchJobStatus.RETURNED
						.getIntValues());
			}
			batchJob.setSegmentId1st(i);
			batchJob.setVersion1st(i);
			batchJob.setIndexStart1st(i);
			batchJob.setIndexEnd1st(i);

			batchJob.setSegmentId2nd(i + 1);
			batchJob.setVersion2nd(i + 1);
			batchJob.setIndexStart2nd(i + 1);
			batchJob.setIndexEnd2nd(i + 1);

			batchJob.setSegmentId3rd(i + 2);
			batchJob.setVersion3rd(i + 2);
			batchJob.setIndexStart3rd(i + 2);
			batchJob.setIndexEnd3rd(i + 2);

			batchJob.setEnqueueTs(DateUtil.getCurrentDate());

			manager.persist(batchJob);
		}

		for (int j = 101; j <= 103; j++) {
			for (int i = 1; i <= 10; i++) {

				EnrollJobQueueEntity job = new EnrollJobQueueEntity();
				job.setBatchJobId(j);
				job.setJobIndex(i);
				job.setReferenceId("" + (100000 + i));
				job.setRequestId(String.valueOf(i * i));
				if (j == 101) {
					job.setReturnCode(ReturnCode.NotUsed);
				} else {
					job.setReturnCode(ReturnCode.JobSuccess);
				}
				job.setErrorCode(String.format("%03d", j) + "_5_"
						+ String.format("%03d", i));
				job.setErrorMessage(String.format("%03d", j) + "_ErrorMessage_"
						+ String.format("%03d", i));
				job.setRequest(TMETestUtil.preperaResponse(j, i).toByteArray());
				job
						.setResponse(TMETestUtil.preperaResponse(j, i)
								.toByteArray());
				manager.persist(job);

			}
		}

		setMockMethod();

		recoveryService.recoverUnCompletedBatchJob();

		testRecoverUnCompletedEnrollBatchJob();
	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testRecoverUnCompletedEnrollBatchJob]<br/>
	 * 1 - query database to get data<br/>
	 * 2 - assert concerning information<br/>
	 * 
	 * @param queueManage
	 * @throws InvalidProtocolBufferException
	 */
	@SuppressWarnings("unchecked")
	public void testRecoverUnCompletedEnrollBatchJob()
			throws InvalidProtocolBufferException {

		// 1 - query database to get data
		Query query = manager
				.createQuery("FROM EnrollBatchJobQueueEntity WHERE batchjobStatus != :batchjobStatus");
		query.setParameter("batchjobStatus", EnrollBatchJobStatus.RETURNED
				.getIntValues());
		List<EnrollBatchJobQueueEntity> dbEnrollBatchJobs = query
				.getResultList();

		// 2 - assert concerning information
		assertEquals(2, dbEnrollBatchJobs.size());

		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		for (EnrollBatchJobQueueEntity dbBatchJob : dbEnrollBatchJobs) {

			long bid = dbBatchJob.getBatchjobId();
			LocalEnrollBatchJob batchJob = queueManage
					.getEnrollBatchJobById(bid);
			EnrollBatchJobStatus bs = batchJob.getBatchJobStatus();

			if (bid == 101) {
				assertEquals(bs, EnrollBatchJobStatus.QUEUED);
				assertNotNull(batchJob.getEnqueueTS());
			} else if (bid == 102) {
				assertEquals(bs, EnrollBatchJobStatus.SYNCHRONIZED);
				assertNotNull(batchJob.getSyncEndTS());
				assertEquals(10, batchJob.getCompletedExtractJobCount());

				assertEquals(batchJob.getSegmentPosition().get(0)
						.getSegmentId(), dbBatchJob.getSegmentId1st());
				assertEquals(batchJob.getSegmentPosition().get(0).getVersion(),
						dbBatchJob.getVersion1st());
				assertEquals(batchJob.getSegmentPosition().get(0)
						.getIndexStart(), dbBatchJob.getIndexStart1st());
				assertEquals(batchJob.getSegmentPosition().get(0).getIndexEnd()
						.longValue(), dbBatchJob.getIndexEnd1st());

				assertEquals(batchJob.getSegmentPosition().get(1)
						.getSegmentId(), dbBatchJob.getSegmentId2nd());
				assertEquals(batchJob.getSegmentPosition().get(1).getVersion(),
						dbBatchJob.getVersion2nd());
				assertEquals(batchJob.getSegmentPosition().get(1)
						.getIndexStart(), dbBatchJob.getIndexStart2nd());
				assertEquals(batchJob.getSegmentPosition().get(1).getIndexEnd()
						.longValue(), dbBatchJob.getIndexEnd2nd());

				assertEquals(batchJob.getSegmentPosition().get(2)
						.getSegmentId(), dbBatchJob.getSegmentId3rd());
				assertEquals(batchJob.getSegmentPosition().get(2).getVersion(),
						dbBatchJob.getVersion3rd());
				assertEquals(batchJob.getSegmentPosition().get(2)
						.getIndexStart(), dbBatchJob.getIndexStart3rd());
				assertEquals(batchJob.getSegmentPosition().get(2).getIndexEnd()
						.longValue(), dbBatchJob.getIndexEnd3rd());
			} else {
				assertEquals(1, 0);
			}

			Query queryjob = manager
					.createQuery("FROM EnrollJobQueueEntity WHERE batchJobId = :batchJobId");
			queryjob.setParameter("batchJobId", bid);
			List<EnrollJobQueueEntity> dbEnrollBatchJobInfos = queryjob
					.getResultList();

			assertEquals(batchJob.getExtractJobCount(), dbEnrollBatchJobInfos
					.size());

			int count = 0;
			for (int j = 1; j <= batchJob.getExtractJobCount(); j++) {
				LocalExtractJobInfo jobInfo = batchJob.getExtractJobInfo(j);
				for (EnrollJobQueueEntity dbJobInfo : dbEnrollBatchJobInfos) {
					if (jobInfo.getJobId() == dbJobInfo.getJobIndex()) {
						assertEquals(jobInfo.getRequestId(), dbJobInfo
								.getRequestId());
						assertEquals(jobInfo.getReturnCode(), dbJobInfo
								.getReturnCode());
						assertEquals(jobInfo.getReferenceId(), dbJobInfo
								.getReferenceId());
						assertEquals(jobInfo.getErrorCode(), dbJobInfo
								.getErrorCode());
						assertEquals(jobInfo.isReSendable(), dbJobInfo
								.isReSendable());
						assertEquals(jobInfo.getErrorMessage(), dbJobInfo
								.getErrorMessage());
						if (bid == 101) {
							assertTrue(jobInfo
									.isStatus(LocalExtractJobStatus.READY));
						} else if (bid == 102) {
							assertTrue(jobInfo
									.isStatus(LocalExtractJobStatus.DONE));
						}
						assertEquals(jobInfo.getMUId(), 0);
						assertEquals(jobInfo.getFailureCount(), 0);
						assertEquals(jobInfo.getBiometricId(), -1);
						assertEquals(jobInfo.getTemplate(), null);

						byte[] dataReq = jobInfo.getRequest().toByteArray();
						assertTrue(dataReq.length > 0);
						for (int i = 0; i < dataReq.length; i++) {
							assertEquals(dataReq[i], dbJobInfo.getRequest()[i]);
						}

						if (bid == 102) {
							byte[] dataRes = jobInfo.getResponse()
									.toByteArray();
							assertTrue(dataRes.length > 0);
							for (int i = 0; i < dataRes.length; i++) {
								assertEquals(dataRes[i], dbJobInfo
										.getResponse()[i]);
							}
						}

						count++;
						break;
					}
				}
			}
			assertEquals(dbEnrollBatchJobInfos.size(), 10);
			assertEquals(dbEnrollBatchJobInfos.size(), count);
		}

	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testDeleteAllUnReturnedBatchJob]<br/>
	 * 1 - clear ENROLL_BATCH_JOB_QUEUE Table<br/>
	 * 2 - call deleteUnReturnedBatchJobs, delete all BatchJobs those their
	 * status is not equal to Returned<br/>
	 * 3 - assert concerning information<br/>
	 */
	@Test
	public void testDeleteAllUnReturnedBatchJob() {

		// 1 - prepare EnrollBatchJobQueue For test
		jdbcTemplate.execute("delete FROM ENROLL_BATCH_JOB_QUEUE");

		// prepare data in DB for testing
		prepareEnrollBatchJobQueue();

		// 2 - call deleteUnReturnedBatchJobs, delete all BatchJobs those their
		// status is not equal to Returned
		recoveryService.unRecoverBatchJob();

		JdbcTemplate template = new JdbcTemplate(dataSource);
		List<Map<String, Object>> batchJobList = template
				.queryForList("select * from ENROLL_BATCH_JOB_QUEUE");
		// assert concerning information
		assertEquals(2, batchJobList.size());

		// clear ENROLL_BATCH_JOB_QUEUE Table
		jdbcTemplate.execute("delete FROM ENROLL_BATCH_JOB_QUEUE");
	}

	/**
	 * prepare data for testing
	 */
	private void prepareEnrollBatchJobQueue() {
		String EnrollBatchJobQueueSql = "insert into ENROLL_BATCH_JOB_QUEUE ("
				+ "BATCHJOB_ID,BATCHJOB_STATUS,START_TS, ENQUEUE_TS,"
				+ "SEGMENT_ID_1ST, VERSION_1ST, INDEX_START_1ST, INDEX_END_1ST, "
				+ "SEGMENT_ID_2ND, VERSION_2ND, INDEX_START_2ND, INDEX_END_2ND, "
				+ "SEGMENT_ID_3RD, VERSION_3RD, INDEX_START_3RD, INDEX_END_3RD )"
				+ " values(:BATCHJOB_ID,  :BATCHJOB_STATUS, :START_TS, :ENQUEUE_TS,"
				+ "0, 0, 0, 0 , 0, 0, 0, 0, 0, 0, 0, 0)";
		{
			// insert into ENROLL_BATCH_JOB_QUEUE, BATCHJOB_ID=3
			Map<String, Object> argMap = new HashMap<String, Object>();
			argMap.put("BATCHJOB_ID", new Long(3));
			argMap.put("BATCHJOB_STATUS", new Integer(
					EnrollBatchJobStatus.QUEUED.getIntValues()));
			argMap.put("ENQUEUE_TS", DateUtil.getCurrentDate());
			argMap.put("START_TS", DateUtil.getCurrentDate());
			jdbcTemplate.update(EnrollBatchJobQueueSql, argMap);
		}
		{
			// insert into ENROLL_BATCH_JOB_QUEUE, BATCHJOB_ID=12
			Map<String, Object> argMap = new HashMap<String, Object>();
			argMap.put("BATCHJOB_ID", new Long(13));
			argMap.put("BATCHJOB_STATUS", new Integer(
					EnrollBatchJobStatus.SYNCHRONIZED.getIntValues()));
			argMap.put("ENQUEUE_TS", DateUtil.getCurrentDate());
			argMap.put("START_TS", DateUtil.getCurrentDate());
			jdbcTemplate.update(EnrollBatchJobQueueSql, argMap);
		}
		{
			// insert into ENROLL_BATCH_JOB_QUEUE, BATCHJOB_ID=31
			Map<String, Object> argMap = new HashMap<String, Object>();
			argMap.put("BATCHJOB_ID", new Long(31));
			argMap.put("BATCHJOB_STATUS", new Integer(
					EnrollBatchJobStatus.SYNCHRONIZED.getIntValues()));
			argMap.put("ENQUEUE_TS", DateUtil.getCurrentDate());
			argMap.put("START_TS", DateUtil.getCurrentDate());
			jdbcTemplate.update(EnrollBatchJobQueueSql, argMap);
		}
		{
			// insert into ENROLL_BATCH_JOB_QUEUE, BATCHJOB_ID=15
			Map<String, Object> argMap = new HashMap<String, Object>();
			argMap.put("BATCHJOB_ID", new Long(15));
			argMap.put("BATCHJOB_STATUS", new Integer(
					EnrollBatchJobStatus.EXTRACTING.getIntValues()));
			argMap.put("ENQUEUE_TS", DateUtil.getCurrentDate());
			argMap.put("START_TS", DateUtil.getCurrentDate());
			jdbcTemplate.update(EnrollBatchJobQueueSql, argMap);
		}

		{
			// insert into ENROLL_BATCH_JOB_QUEUE, BATCHJOB_ID=15
			Map<String, Object> argMap = new HashMap<String, Object>();
			argMap.put("BATCHJOB_ID", new Long(165));
			argMap.put("BATCHJOB_STATUS", new Integer(
					EnrollBatchJobStatus.RETURNED.getIntValues()));
			argMap.put("ENQUEUE_TS", DateUtil.getCurrentDate());
			argMap.put("START_TS", DateUtil.getCurrentDate());
			jdbcTemplate.update(EnrollBatchJobQueueSql, argMap);
		}

		{
			// insert into ENROLL_BATCH_JOB_QUEUE, BATCHJOB_ID=15
			Map<String, Object> argMap = new HashMap<String, Object>();
			argMap.put("BATCHJOB_ID", new Long(155));
			argMap.put("BATCHJOB_STATUS", new Integer(
					EnrollBatchJobStatus.RETURNED.getIntValues()));
			argMap.put("ENQUEUE_TS", DateUtil.getCurrentDate());
			argMap.put("START_TS", DateUtil.getCurrentDate());
			jdbcTemplate.update(EnrollBatchJobQueueSql, argMap);
		}
	}
}
