package jp.co.nec.lsm.tme.db.entityhelpers;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.lsm.tm.common.communication.SegmentPosition;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollBatchJobQueueEntity;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollBatchJobStatus;
import jp.co.nec.lsm.tm.db.enroll.entityhelpers.EnrollBatchJobQueueHelper;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class EnrollBatchJobQueueHelperTest {
	@PersistenceContext(unitName = "tme-ngi")
	protected EntityManager entityManager;
	@Resource
	protected DataSource dataSource;
	@Resource
	protected JdbcTemplate jdbcTemplate;
	EnrollBatchJobQueueHelper batchJobQueueHelper;

	@Before
	public void setUp() {
		batchJobQueueHelper = new EnrollBatchJobQueueHelper(entityManager);
		// clear ENROLL_BATCH_JOB_QUEUE Table
		clearEnrollBatchJobQueueTable();
	}

	@After
	public void tearDown() {
		// clear ENROLL_BATCH_JOB_QUEUE Table
		clearEnrollBatchJobQueueTable();
	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testpersistBatchJob]<br/>
	 * 1 - clear ENROLL_BATCH_JOB_QUEUE Table<br/>
	 * 2 - prepare BatchJob For test<br/>
	 * 3 - call persistBatchJob, insert BatchJob into database<br/>
	 * 4 - query database to get data<br/>
	 * 5 - assert concerning information<br/>
	 */
	@Test
	public void testpersistBatchJob() {
		long batchjobId = 5;

		String sql = "select * FROM ENROLL_BATCH_JOB_QUEUE where BATCHJOB_ID="
				+ batchjobId;

		int segPos[] = { 0, 0, 0, 0, //
				0, 0, 0, 0, //
				0, 0, 0, 0 //
		};

		// 1 - clear ENROLL_BATCH_JOB_QUEUE Table
		clearEnrollBatchJobQueueTable();

		// 2 - prepare BatchJob For test
		EnrollBatchJobQueueEntity batchJobQueueEntity = prepareEnrollBatchJobQueueEntity(batchjobId);

		// 3 - call persistBatchJob, insert BatchJob into database
		batchJobQueueHelper.persistBatchJob(batchJobQueueEntity);

		// 4 - query database to get data
		JdbcTemplate template = new JdbcTemplate(dataSource);
		template.execute(sql);
		List<Map<String, Object>> list = template.queryForList(sql);

		// 5 - assert concerning information
		assertEquals(1, list.size());
		for (int i = 0; i < list.size(); i++) {
			Map<String, Object> map = list.get(i);

			// assert ENROLL_BATCH_JOB_QUEUE record(EnrollBatchJob)
			assertEquals(batchjobId, Long.parseLong(map.get("BATCHJOB_ID")
					.toString()));
			assertEquals(EnrollBatchJobStatus.EXTRACTING.getIntValues(),
					Integer.parseInt(map.get("BATCHJOB_STATUS").toString()));
			assertNotNull(map.get("ENQUEUE_TS"));
			assertNull(map.get("START_TS"));

			// assert ENROLL_BATCH_JOB_QUEUE record(SegmentPosition)
			assertEnrollBatchJob(map, segPos);
		}

		// clear ENROLL_BATCH_JOB_QUEUE Table
		clearEnrollBatchJobQueueTable();
	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testpersistBatchJobStatus]<br/>
	 * 1 - clear ENROLL_BATCH_JOB_QUEUE Table<br/>
	 * 2 - prepare BatchJob For test<br/>
	 * 3 - call persistBatchJobStatus, change database BatchJobStatus<br/>
	 * 4 - query database to get data<br/>
	 * 5 - assert concerning information<br/>
	 * 6 - prepare SegmentPosition For test<br/>
	 */
	@Test
	public void testpersistBatchJobStatus_NOSegmentPosition() {
		long batchjobId = 3;
		String sql = "select * FROM ENROLL_BATCH_JOB_QUEUE where BATCHJOB_ID="
				+ batchjobId;

		// 1 - prepare EnrollBatchJobQueue For test
		clearEnrollBatchJobQueueTable();

		// 2 - prepare BatchJob For test
		EnrollBatchJobQueueEntity batchJobQueueEntity = prepareEnrollBatchJobQueueEntity(batchjobId);
		batchJobQueueEntity.setBatchjobStatus(EnrollBatchJobStatus.EXTRACTED
				.getIntValues());

		batchJobQueueHelper.persistBatchJob(batchJobQueueEntity);

		// 3 - call persistBatchJobStatus, change database BatchJobStatus
		batchJobQueueHelper.persistBatchJobStatus(batchJobQueueEntity
				.getBatchjobId(), new Date(), EnrollBatchJobStatus
				.getBatchJobStatus(batchJobQueueEntity.getBatchjobStatus()),
				null);
		// 4 - query database to get data
		JdbcTemplate template = new JdbcTemplate(dataSource);
		List<Map<String, Object>> list = template.queryForList(sql);
		// 5 - assert concerning information
		assertEquals(1, list.size());
		for (int i = 1; i <= list.size(); i++) {
			assertEquals(EnrollBatchJobStatus.EXTRACTED.getIntValues(),
					Integer.parseInt(list.get(i - 1).get("BATCHJOB_STATUS")
							.toString()));
		}

		// clear ENROLL_BATCH_JOB_QUEUE Table
		clearEnrollBatchJobQueueTable();
	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testpersistBatchJobStatus]<br/>
	 * 1 - clear ENROLL_BATCH_JOB_QUEUE Table<br/>
	 * 2 - prepare BatchJob For test<br/>
	 * 3 - call persistBatchJobStatus, change database BatchJobStatus<br/>
	 * 4 - query database to get data<br/>
	 * 5 - assert concerning information<br/>
	 * 6 - prepare SegmentPosition For test<br/>
	 */
	@Test
	public void testpersistBatchJobStatus() {
		long batchjobId = 3;
		int segPosArray[] = { 12, 1, 12423, 13557, //
				22, 2, 22423, 23557, //
				32, 3, 32423, 33557 //
		};
		String sql = "select * FROM ENROLL_BATCH_JOB_QUEUE where BATCHJOB_ID="
				+ batchjobId;

		// 1 - prepare EnrollBatchJobQueue For test
		clearEnrollBatchJobQueueTable();

		// 2 - prepare BatchJob For test
		EnrollBatchJobQueueEntity batchJobQueueEntity = prepareEnrollBatchJobQueueEntity(batchjobId);
		batchJobQueueEntity.setBatchjobStatus(EnrollBatchJobStatus.EXTRACTED
				.getIntValues());
		List<SegmentPosition> segPos = prepareSegmentPositionList(segPosArray);

		batchJobQueueHelper.persistBatchJob(batchJobQueueEntity);

		// 3 - call persistBatchJobStatus, change database BatchJobStatus
		batchJobQueueHelper.persistBatchJobStatus(batchJobQueueEntity
				.getBatchjobId(), new Date(), EnrollBatchJobStatus
				.getBatchJobStatus(batchJobQueueEntity.getBatchjobStatus()),
				segPos);

		// 4 - query database to get data
		JdbcTemplate template = new JdbcTemplate(dataSource);
		List<Map<String, Object>> list = template.queryForList(sql);

		// 5 - assert concerning information
		assertEquals(1, list.size());
		for (int i = 0; i < list.size(); i++) {
			Map<String, Object> map = list.get(i);

			// assert ENROLL_BATCH_JOB_QUEUE record(EnrollBatchJob)
			assertEnrollBatchJob(map, batchjobId,
					EnrollBatchJobStatus.EXTRACTED);

			// assert ENROLL_BATCH_JOB_QUEUE record(SegmentPosition)
			assertEnrollBatchJob(map, segPosArray);
		}

		// clear ENROLL_BATCH_JOB_QUEUE Table
		clearEnrollBatchJobQueueTable();
	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testgetAllUnReturnedBatchJob]<br/>
	 * 1 - clear ENROLL_BATCH_JOB_QUEUE Table<br/>
	 * 2 - call getAllUnReturnedBatchJob, get all BatchJobs those their status
	 * is not equal to Returned<br/>
	 * 3 - assert concerning information<br/>
	 */
	@Test
	@Ignore
	public void testgetAllUnReturnedBatchJob() {

		// 1 - prepare EnrollBatchJobQueue For test
		clearEnrollBatchJobQueueTable();

		// prepare data in DB for testing
		prepareEnrollBatchJobQueue();

		// 2 - call getAllUnReturnedBatchJob, get all BatchJobs those their
		// status is not equal to Returned
		List<EnrollBatchJobQueueEntity> batchJobQueueEntityList = batchJobQueueHelper
				.getAllUnReturnedBatchJob();
		// assert concerning information
		assertEquals(4, batchJobQueueEntityList.size());

		// clear ENROLL_BATCH_JOB_QUEUE Table
		clearEnrollBatchJobQueueTable();
	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testDeleteAllUnReturnedBatchJob]<br/>
	 * 1 - clear ENROLL_BATCH_JOB_QUEUE Table<br/>
	 * 2 - call deleteUnReturnedBatchJobs, delete all BatchJobs those their status
	 * is not equal to Returned<br/>
	 * 3 - assert concerning information<br/>
	 */
	@Test
	@Ignore
	public void testDeleteAllUnReturnedBatchJob() {

		// 1 - prepare EnrollBatchJobQueue For test
		clearEnrollBatchJobQueueTable();

		// prepare data in DB for testing
		prepareEnrollBatchJobQueue();

		// 2 - call deleteUnReturnedBatchJobs, delete all BatchJobs those their
		// status is not equal to Returned
		batchJobQueueHelper.deleteUnReturnedBatchJobs();

		JdbcTemplate template = new JdbcTemplate(dataSource);
		List<Map<String, Object>> batchJobList = template
				.queryForList("select * from ENROLL_BATCH_JOB_QUEUE");
		// assert concerning information
		assertEquals(2, batchJobList.size());

		// clear ENROLL_BATCH_JOB_QUEUE Table
		clearEnrollBatchJobQueueTable();
	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testgetBatchJobByStatus]<br/>
	 * 1 - clear ENROLL_BATCH_JOB_QUEUE Table<br/>
	 * 2 - call getBatchJobByStatus, to get concerning BatchJob<br/>
	 * 3 - assert concerning information<br/>
	 */
	@Test
	@Ignore
	public void testGetBatchJobByStatus() {
		// 1 - prepare EnrollBatchJobQueue For test
		clearEnrollBatchJobQueueTable();

		// prepare data in DB for testing
		prepareEnrollBatchJobQueue();

		// 2 - call getBatchJobByStatus, to get concerning BatchJob
		List<EnrollBatchJobQueueEntity> batchJobQueueEntityList = batchJobQueueHelper
				.getBatchJobByStatus(EnrollBatchJobStatus.SYNCHRONIZED);

		// 3 - assert concerning information
		assertEquals(2, batchJobQueueEntityList.size());

		// clear ENROLL_BATCH_JOB_QUEUE Table
		clearEnrollBatchJobQueueTable();
	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testpersistBatchJobStatus]<br/>
	 * 1 - clear ENROLL_BATCH_JOB_QUEUE Table<br/>
	 * 2 - call getBatchJobById, to get BatchJob<br/>
	 * 3 - assert concerning information<br/>
	 */
	@Test
	@Ignore
	public void testGetBatchJobById() {
		// 1 - clear ENROLL_BATCH_JOB_QUEUE Table
		clearEnrollBatchJobQueueTable();

		// prepare data in DB for testing
		prepareEnrollBatchJobQueue();

		// 2 - call getBatchJobById, to get BatchJob
		EnrollBatchJobQueueEntity batchJobQueueEntity = batchJobQueueHelper
				.getBatchJobById(15L);

		// 3 - assert concerning information
		assertEquals(15, batchJobQueueEntity.getBatchjobId());
		assertEquals(EnrollBatchJobStatus.EXTRACTING.getIntValues(),
				batchJobQueueEntity.getBatchjobStatus());

		// clear ENROLL_BATCH_JOB_QUEUE Table
		clearEnrollBatchJobQueueTable();
	}

	/**
	 * prepare Data For TMEEnrollBatchJobQueueHelper
	 */
	private EnrollBatchJobQueueEntity prepareEnrollBatchJobQueueEntity(
			long batchjobId) {
		EnrollBatchJobQueueEntity batchJobQueueEntity = new EnrollBatchJobQueueEntity();
		batchJobQueueEntity.setBatchjobId(batchjobId);
		batchJobQueueEntity.setBatchjobStatus(EnrollBatchJobStatus.EXTRACTING
				.getIntValues());
		batchJobQueueEntity.setEnqueueTs(DateUtil.getCurrentDate());
		return batchJobQueueEntity;
	}

	/**
	 * clear ENROLL_BATCH_JOB_QUEUE Table
	 */
	private void clearEnrollBatchJobQueueTable() {
		jdbcTemplate.execute("delete FROM ENROLL_BATCH_JOB_QUEUE");
	}

	/**
	 * prepare data for testing
	 */
	private void prepareEnrollBatchJobQueue() {
		String EnrollBatchJobQueueSql = "insert into ENROLL_BATCH_JOB_QUEUE ("
				+ "BATCHJOB_ID,BATCHJOB_STATUS,START_TS, ENQUEUE_TS,"
				+ "SEGMENT_ID_1ST, VERSION_1ST, INDEX_START_1ST, INDEX_END_1ST, "
				+ "SEGMENT_ID_2ND, VERSION_2ND, INDEX_START_2ND, INDEX_END_2ND, "
				+ "SEGMENT_ID_3RD, VERSION_3RD, INDEX_START_3RD, INDEX_END_3RD )"
				+ " values(:BATCHJOB_ID,  :BATCHJOB_STATUS, :START_TS, :ENQUEUE_TS,"
				+ "0, 0, 0, 0 , 0, 0, 0, 0, 0, 0, 0, 0)";
		{
			// insert into ENROLL_BATCH_JOB_QUEUE, BATCHJOB_ID=3
			Map<String, Object> argMap = new HashMap<String, Object>();
			argMap.put("BATCHJOB_ID", new Long(3));
			argMap.put("BATCHJOB_STATUS", new Integer(
					EnrollBatchJobStatus.QUEUED.getIntValues()));
			argMap.put("ENQUEUE_TS", DateUtil.getCurrentDate());
			argMap.put("START_TS", DateUtil.getCurrentDate());
			jdbcTemplate.update(EnrollBatchJobQueueSql, argMap);
		}
		{
			// insert into ENROLL_BATCH_JOB_QUEUE, BATCHJOB_ID=12
			Map<String, Object> argMap = new HashMap<String, Object>();
			argMap.put("BATCHJOB_ID", new Long(13));
			argMap.put("BATCHJOB_STATUS", new Integer(
					EnrollBatchJobStatus.SYNCHRONIZED.getIntValues()));
			argMap.put("ENQUEUE_TS", DateUtil.getCurrentDate());
			argMap.put("START_TS", DateUtil.getCurrentDate());
			jdbcTemplate.update(EnrollBatchJobQueueSql, argMap);
		}
		{
			// insert into ENROLL_BATCH_JOB_QUEUE, BATCHJOB_ID=31
			Map<String, Object> argMap = new HashMap<String, Object>();
			argMap.put("BATCHJOB_ID", new Long(31));
			argMap.put("BATCHJOB_STATUS", new Integer(
					EnrollBatchJobStatus.SYNCHRONIZED.getIntValues()));
			argMap.put("ENQUEUE_TS", DateUtil.getCurrentDate());
			argMap.put("START_TS", DateUtil.getCurrentDate());
			jdbcTemplate.update(EnrollBatchJobQueueSql, argMap);
		}
		{
			// insert into ENROLL_BATCH_JOB_QUEUE, BATCHJOB_ID=15
			Map<String, Object> argMap = new HashMap<String, Object>();
			argMap.put("BATCHJOB_ID", new Long(15));
			argMap.put("BATCHJOB_STATUS", new Integer(
					EnrollBatchJobStatus.EXTRACTING.getIntValues()));
			argMap.put("ENQUEUE_TS", DateUtil.getCurrentDate());
			argMap.put("START_TS", DateUtil.getCurrentDate());
			jdbcTemplate.update(EnrollBatchJobQueueSql, argMap);
		}
		
		{
			// insert into ENROLL_BATCH_JOB_QUEUE, BATCHJOB_ID=15
			Map<String, Object> argMap = new HashMap<String, Object>();
			argMap.put("BATCHJOB_ID", new Long(165));
			argMap.put("BATCHJOB_STATUS", new Integer(
					EnrollBatchJobStatus.RETURNED.getIntValues()));
			argMap.put("ENQUEUE_TS", DateUtil.getCurrentDate());
			argMap.put("START_TS", DateUtil.getCurrentDate());
			jdbcTemplate.update(EnrollBatchJobQueueSql, argMap);
		}
		
		{
			// insert into ENROLL_BATCH_JOB_QUEUE, BATCHJOB_ID=15
			Map<String, Object> argMap = new HashMap<String, Object>();
			argMap.put("BATCHJOB_ID", new Long(155));
			argMap.put("BATCHJOB_STATUS", new Integer(
					EnrollBatchJobStatus.RETURNED.getIntValues()));
			argMap.put("ENQUEUE_TS", DateUtil.getCurrentDate());
			argMap.put("START_TS", DateUtil.getCurrentDate());
			jdbcTemplate.update(EnrollBatchJobQueueSql, argMap);
		}
	}

	/**
	 * assert ENROLL_BATCH_JOB_QUEUE record(EnrollBatchJob)
	 * 
	 * @param map
	 * @param batchJobId
	 * @param status
	 */
	private void assertEnrollBatchJob(Map<String, Object> map, long batchJobId,
			EnrollBatchJobStatus status) {
		assertEquals(batchJobId, Long.parseLong(map.get("BATCHJOB_ID")
				.toString()));
		assertEquals(status.getIntValues(), Integer.parseInt(map.get(
				"BATCHJOB_STATUS").toString()));
		assertNotNull(map.get("ENQUEUE_TS"));
		assertNotNull(map.get("START_TS"));
	}

	/**
	 * assert ENROLL_BATCH_JOB_QUEUE record(SegmentPosition)
	 * 
	 * @param map
	 * @param batchJobId
	 * @param status
	 */
	private void assertEnrollBatchJob(Map<String, Object> map, int segPos[]) {
		int i = 0;

		assertEquals(segPos[i++], Integer.parseInt(map.get("SEGMENT_ID_1ST")
				.toString()));
		assertEquals(segPos[i++], Integer.parseInt(map.get("VERSION_1ST")
				.toString()));
		assertEquals(segPos[i++], Integer.parseInt(map.get("INDEX_START_1ST")
				.toString()));
		assertEquals(segPos[i++], Integer.parseInt(map.get("INDEX_END_1ST")
				.toString()));

		assertEquals(segPos[i++], Integer.parseInt(map.get("SEGMENT_ID_2ND")
				.toString()));
		assertEquals(segPos[i++], Integer.parseInt(map.get("VERSION_2ND")
				.toString()));
		assertEquals(segPos[i++], Integer.parseInt(map.get("INDEX_START_2ND")
				.toString()));
		assertEquals(segPos[i++], Integer.parseInt(map.get("INDEX_END_2ND")
				.toString()));

		assertEquals(segPos[i++], Integer.parseInt(map.get("SEGMENT_ID_3RD")
				.toString()));
		assertEquals(segPos[i++], Integer.parseInt(map.get("VERSION_3RD")
				.toString()));
		assertEquals(segPos[i++], Integer.parseInt(map.get("INDEX_START_3RD")
				.toString()));
		assertEquals(segPos[i++], Integer.parseInt(map.get("INDEX_END_3RD")
				.toString()));
	}

	private List<SegmentPosition> prepareSegmentPositionList(int segPosArray[]) {
		int i = 0;
		List<SegmentPosition> segPos = new ArrayList<SegmentPosition>();
		SegmentPosition sp = new SegmentPosition();
		sp.setSegmentId(segPosArray[i++]);
		sp.setVersion(segPosArray[i++]);
		sp.setIndexStart(segPosArray[i++]);
		sp.setIndexEnd(new Long(segPosArray[i++]));
		segPos.add(sp);

		SegmentPosition sp2 = new SegmentPosition();
		sp2.setSegmentId(segPosArray[i++]);
		sp2.setVersion(segPosArray[i++]);
		sp2.setIndexStart(segPosArray[i++]);
		sp2.setIndexEnd(new Long(segPosArray[i++]));
		segPos.add(sp2);

		SegmentPosition sp3 = new SegmentPosition();
		sp3.setSegmentId(segPosArray[i++]);
		sp3.setVersion(segPosArray[i++]);
		sp3.setIndexStart(segPosArray[i++]);
		sp3.setIndexEnd(new Long(segPosArray[i++]));
		segPos.add(sp3);

		return segPos;
	}
}
