package jp.co.nec.aim.license.lmx;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LmxAgentBooter {
	
	private String MAJOR_VER;
	private String PORT;
	private String FEATURE_NAME;
	private static final String COMMAD = "./lmx-agent.sh";
	private static final String WILD_HOME = "jboss.home.dir";
	private static final String AGENT_SUB_PATH = "license/agent";
	
	private static Logger logger = LoggerFactory.getLogger(LmxAgentBooter.class);
	
	public LmxAgentBooter(String majorVer, String port, String featureName) {
		this.MAJOR_VER = majorVer;
		this.PORT = port;
		this.FEATURE_NAME = featureName;		
	}
	
	public void bootLmxAgent() {
		String homeDir = System.getProperty(WILD_HOME);
		homeDir = homeDir.endsWith("/") ? homeDir : homeDir + "/";
		String allAgentPath = homeDir + AGENT_SUB_PATH;
		ProcessBuilder builder = new ProcessBuilder(COMMAD, PORT, MAJOR_VER, FEATURE_NAME);			
		builder.directory(new File(allAgentPath));
		builder.redirectErrorStream(true);
		Process process = null;
		try {
			process = builder.start();
			logger.info("Sucess booted LmxAgent!");
		} catch (IOException ex) {
			logger.error(ex.getMessage(), ex);
			return;
		}
		try (InputStream is = process.getInputStream()) {
			while (0 <= is.read()) {
			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
	}	

}
