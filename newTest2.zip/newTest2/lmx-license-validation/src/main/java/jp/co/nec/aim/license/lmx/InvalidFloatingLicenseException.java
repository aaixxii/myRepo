package jp.co.nec.aim.license.lmx;

public class InvalidFloatingLicenseException extends Exception {
	
	private static final long serialVersionUID = 5405206580880728665L;
	String code = "";
	
	public InvalidFloatingLicenseException() {
	}

	public InvalidFloatingLicenseException(String code, String message) {
		super(message);
		this.code = code;
	}

	public InvalidFloatingLicenseException(String message) {
		super(message);
	}
	
	public String getCode() {
		return code;
	}
}
