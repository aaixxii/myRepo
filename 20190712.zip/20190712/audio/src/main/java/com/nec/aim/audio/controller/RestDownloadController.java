package com.nec.aim.audio.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

import org.springframework.core.io.InputStreamResource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RestDownloadController {

	@GetMapping("/download")
	public ResponseEntity<InputStreamResource> getAudioData(@RequestParam String fileName) throws IOException {
		URL url = Thread.currentThread().getContextClassLoader().getResource("wav/" + fileName);
		File audioFile = new File(url.getPath());
		InputStream in = new FileInputStream(audioFile);
		return ResponseEntity.ok().contentType(MediaType.APPLICATION_OCTET_STREAM).body(new InputStreamResource(in));
	}
	
	@GetMapping("/getWavPath")
	public String getWavFilePath(@RequestParam String fileName) {
		URL url = Thread.currentThread().getContextClassLoader().getResource("wav/" + fileName);
		return url.getPath();
		
	}

}
