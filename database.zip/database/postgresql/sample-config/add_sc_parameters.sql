-- Ignore if scope record already exists 

-- Ignore LOBSTREAM parameters if already exists 
Insert into BIO_PARAMETERS
   (NAME, SCOPE, VALUE, DESCRIPTION, CREATE_DATETIME, 
    CREATEBY)
 Values
   ('LOBSTREAM_RETENTION_HOURS', 'DEFAULT', '2', 'Lob storage retention period', CURRENT_TIMESTAMP, 
    'ADMIN');
Insert into BIO_PARAMETERS
   (NAME, SCOPE, VALUE, DESCRIPTION, CREATE_DATETIME, 
    CREATEBY)
 Values
   ('LOBSTREAM_STORAGE_PATH', 'DEFAULT', '/home/megha/storage/lobstream/data', 'Lob stream storage path', CURRENT_TIMESTAMP, 
    'ADMIN');
	
-- Search Controller Parameters	
Insert into BIO_PARAMETERS
   (NAME, SCOPE, VALUE, DESCRIPTION, CREATE_DATETIME, 
    CREATEBY)
 Values
   ('JOB_TIMEOUT_THREAD_CONCURRENCY', 'DEFAULT', '20', 'Job Timeout thread concurrency', CURRENT_TIMESTAMP, 
    'ADMIN');
Insert into BIO_PARAMETERS
   (NAME, SCOPE, VALUE, DESCRIPTION, CREATE_DATETIME, 
    CREATEBY)
 Values
   ('CALLBACK_THREAD_CONCURRENCY', 'DEFAULT', '20', 'Callback thread concurrency', CURRENT_TIMESTAMP, 
    'ADMIN');
Insert into BIO_PARAMETERS
   (NAME, SCOPE, VALUE, DESCRIPTION, CREATE_DATETIME, 
    CREATEBY)
 Values
   ('MAX_SEARCH_JOB_TIMEOUT_MILLI_FOR_BIN_1', 'DEFAULT', '5000', 'Max search job timeout milliseconds per BIN', CURRENT_TIMESTAMP, 
    'ADMIN');
Insert into BIO_PARAMETERS
   (NAME, SCOPE, VALUE, DESCRIPTION, CREATE_DATETIME, 
    CREATEBY)
 Values
   ('SEARCH_JOB_RETENTION_PERIOD_MILLI', 'DEFAULT', '1800000', 'Search job retention period milliseconds', CURRENT_TIMESTAMP, 
    'ADMIN');

Insert into BIO_PARAMETERS
   (NAME, SCOPE, VALUE, DESCRIPTION, CREATE_DATETIME, 
    CREATEBY)
 Values
   ('SEARCH_BROKER_FAILOVER_DELAY_MILLI', 'DEFAULT', '120000', 'Search Broker failover delay milliseconds', CURRENT_TIMESTAMP, 
    'ADMIN');
Insert into BIO_PARAMETERS
   (NAME, SCOPE, VALUE, DESCRIPTION, CREATE_DATETIME, 
    CREATEBY)
 Values
   ('SEGMENT_VERSION_TARGET_ENABLED_FLAG', 'DEFAULT', 'false', 'Segment version target enabled flag', CURRENT_TIMESTAMP, 
    'ADMIN');
Insert into BIO_PARAMETERS
   (NAME, SCOPE, VALUE, DESCRIPTION, CREATE_DATETIME, 
    CREATEBY)
 Values
   ('SEARCH_NODE_JOB_OVERLOAD_COUNT', 'DEFAULT', '2', 'Max job overload count per search node', CURRENT_TIMESTAMP, 
    'ADMIN');
Insert into BIO_PARAMETERS
   (NAME, SCOPE, VALUE, DESCRIPTION, CREATE_DATETIME, 
    CREATEBY)
 Values
   ('NOTIFY_SEARCH_CALLBACK_IN_WORKER_THREAD_FLAG', 'DEFAULT', 'false', 'Notify callback in worker thread flag', CURRENT_TIMESTAMP, 
    'ADMIN');

Insert into BIO_PARAMETERS
   (NAME, SCOPE, VALUE, DESCRIPTION, CREATE_DATETIME, 
    CREATEBY)
 Values
   ('SEARCH_NODE_PROTOCOL_TYPE', 'DEFAULT', 'ZEROMQ', 'Search node protocol type', CURRENT_TIMESTAMP, 
    'ADMIN');
Insert into BIO_PARAMETERS
   (NAME, SCOPE, VALUE, DESCRIPTION, CREATE_DATETIME, 
    CREATEBY)
 Values
   ('SEARCH_CONTROLLER_HESSIAN_TIMEOUT_MILLI', 'DEFAULT', '120000', 'Search controller hessian timeout milliseconds', CURRENT_TIMESTAMP, 
    'ADMIN');

Insert into BIO_PARAMETERS
   (NAME, SCOPE, VALUE, DESCRIPTION, CREATE_DATETIME, 
    CREATEBY)
 Values
   ('RELEASED_BIOMETRIC_ID_CHECK_DELAY_MILLI', 'DEFAULT', '600000', 'Released biometric id check delay milliseconds', CURRENT_TIMESTAMP, 
    'ADMIN');
Insert into BIO_PARAMETERS
   (NAME, SCOPE, VALUE, DESCRIPTION, CREATE_DATETIME, 
    CREATEBY)
 Values
   ('MAX_PRELOAD_BIOMETRIC_ID_COUNT', 'DEFAULT', '50', 'Max biometric id preload count', CURRENT_TIMESTAMP, 
    'ADMIN');
Insert into BIO_PARAMETERS
   (NAME, SCOPE, VALUE, DESCRIPTION, CREATE_DATETIME, 
    CREATEBY)
 Values
   ('SEGMENT_CHANGESET_WRITER_THREAD_CONCURRENCY', 'DEFAULT', '10', 'Segment change set writer concurrency', CURRENT_TIMESTAMP, 
    'ADMIN');
Insert into BIO_PARAMETERS
   (NAME, SCOPE, VALUE, DESCRIPTION, CREATE_DATETIME, 
    CREATEBY)
 Values
   ('SEGMENT_CHANGE_SET_STORAGE_PATH', 'DEFAULT', '/home/megha/storage/segchangesets/data', 'Segment change set storage path', CURRENT_TIMESTAMP, 
    'ADMIN');

Insert into BIO_PARAMETERS
   (NAME, SCOPE, VALUE, DESCRIPTION, CREATE_DATETIME, 
    CREATEBY)
 Values
   ('FULL_SEGMENT_STORAGE_PATH', 'DEFAULT', '/home/megha/storage/segmentfiles/data', 'Full segment storage path', CURRENT_TIMESTAMP, 
    'ADMIN');	
	
Insert into BIO_PARAMETERS
   (NAME, SCOPE, VALUE, DESCRIPTION, CREATE_DATETIME, 
    CREATEBY)
 Values
   ('SEGMENT_SYNC_REQUEST_TIMEOUT_MILLI', 'DEFAULT', '5000', 'Segment sync request  timeout milliseconds', CURRENT_TIMESTAMP, 
    'ADMIN');
Insert into BIO_PARAMETERS
   (NAME, SCOPE, VALUE, DESCRIPTION, CREATE_DATETIME, 
    CREATEBY)
 Values
   ('SEARCH_BROKER_MANAGER_TASK_SLEEP_INTERVAL_MILLI', 'DEFAULT', '60000', 'Search Broker task sleep interval', CURRENT_TIMESTAMP, 
    'ADMIN');
Insert into BIO_PARAMETERS
   (NAME, SCOPE, VALUE, DESCRIPTION, CREATE_DATETIME, 
    CREATEBY)
 Values
   ('SEARCH_BROKER_HESSIAN_TIMEOUT_MILLI', 'DEFAULT', '120000', 'Search Broker HESSIAN request timeout milliseconds', CURRENT_TIMESTAMP, 
    'ADMIN');
Insert into BIO_PARAMETERS
   (NAME, SCOPE, VALUE, DESCRIPTION, CREATE_DATETIME, 
    CREATEBY)
 Values
   ('IDLE_SERVER_CHECK_DELAY_MILLI', 'DEFAULT', '120000', 'Idle server check delay milliseconds', CURRENT_TIMESTAMP, 
    'ADMIN');

	

Insert into BIO_PARAMETERS
   (NAME, SCOPE, VALUE, DESCRIPTION, CREATE_DATETIME, 
    CREATEBY)
 Values
   ('MAX_SYNC_JOB_TIMEOUT_MILLI', 'DEFAULT', '10000', 'Max Sync Job Timeout Milliseconds', CURRENT_TIMESTAMP, 
    'ADMIN');
Insert into BIO_PARAMETERS
   (NAME, SCOPE, VALUE, DESCRIPTION, CREATE_DATETIME, 
    CREATEBY)
 Values
   ('SYNC_JOB_RETENTION_PERIOD_MILLI', 'DEFAULT', '1800000', 'Sync Job Retention Perion in Milliseconds', CURRENT_TIMESTAMP, 
    'ADMIN');
Insert into BIO_PARAMETERS
   (NAME, SCOPE, VALUE, DESCRIPTION, CREATE_DATETIME, 
    CREATEBY)
 Values
   ('NOTIFY_SYNC_CALLBACK_IN_WORKER_THREAD_FLAG', 'DEFAULT', 'false', 'Flag to indicate weather to execute callback in worker thread or seperate thread', CURRENT_TIMESTAMP, 
    'ADMIN');
Insert into BIO_PARAMETERS
   (NAME, SCOPE, VALUE, DESCRIPTION, CREATE_DATETIME, 
    CREATEBY)
 Values
   ('SYNC_WORKER_THREAD_CONCURRENCY', 'DEFAULT', '50', 'Sync Job worker thread concurrency', CURRENT_TIMESTAMP, 
    'ADMIN');
Insert into BIO_PARAMETERS
   (NAME, SCOPE, VALUE, DESCRIPTION, CREATE_DATETIME, 
    CREATEBY)
 Values
   ('MAX_CONCURRENCY_PER_SEGMENT_WRITER', 'DEFAULT', '5', 'Max coucurrency per segment writer', CURRENT_TIMESTAMP, 
    'ADMIN');

Insert into BIO_PARAMETERS
   (NAME, SCOPE, VALUE, DESCRIPTION, CREATE_DATETIME, 
    CREATEBY)
 Values
   ('CREATE_SEGMENT_FILE_MAX_LOAD_COUNT', 'DEFAULT', '5000', 'Max records to load at a time while building full segment', CURRENT_TIMESTAMP, 
    'ADMIN');
Insert into BIO_PARAMETERS
   (NAME, SCOPE, VALUE, DESCRIPTION, CREATE_DATETIME, 
    CREATEBY)
 Values
   ('SEGMENT_FILE_WRITER_THREAD_CONCURRENCY', 'DEFAULT', '3', 'Max number of segment writers', CURRENT_TIMESTAMP, 
    'ADMIN');
Insert into BIO_PARAMETERS
   (NAME, SCOPE, VALUE, DESCRIPTION, CREATE_DATETIME, 
    CREATEBY)
 Values
   ('LIVE_MATCHER_SEGMENT_VERSION_TTL_SECONDS', 'DEFAULT', '5', 'Segment version number cache time to live, used by SVT', CURRENT_TIMESTAMP, 
    'ADMIN');
Insert into BIO_PARAMETERS
   (NAME, SCOPE, VALUE, DESCRIPTION, CREATE_DATETIME, 
    CREATEBY)
 Values
   ('SEGMENT_CHANGESET_HOUSEKEEPING_ENABLED_FLAG', 'DEFAULT', 'true', 'Flag to enable segment changeset housekeeping', CURRENT_TIMESTAMP, 
    'ADMIN');
Insert into BIO_PARAMETERS
   (NAME, SCOPE, VALUE, DESCRIPTION, CREATE_DATETIME, 
    CREATEBY)
 Values
   ('SEGMENT_CHANGESET_HOUSEKEEPING_INTERVAL_MILLI', 'DEFAULT', '1800000', 'Time interval for segment changeset housekeeping job', CURRENT_TIMESTAMP, 
    'ADMIN');

Insert into BIO_PARAMETERS
   (NAME, SCOPE, VALUE, DESCRIPTION, CREATE_DATETIME, 
    CREATEBY)
 Values
   ('MULTI_SEGMENTS_PER_SEARCH_JOB_FLAG', 'DEFAULT', 'false', 'Flag to include multiple segments in one SN job request', CURRENT_TIMESTAMP, 
    'ADMIN');

-- add parameters for sync segment callback 

Insert into BIO_PARAMETERS
   (NAME, SCOPE, VALUE, DESCRIPTION, CREATE_DATETIME, 
    CREATEBY)
 Values
   ('MAX_SYNC_SEGMENTS_COMPLETED_TIMEOUT_MILLI', 'DEFAULT', '60000', 'used for sync segments callback timeout', CURRENT_TIMESTAMP, 
    'ADMIN'); 

Insert into BIO_PARAMETERS
   (NAME, SCOPE, VALUE, DESCRIPTION, DATATYPE,CREATE_DATETIME, 
    CREATEBY)
 Values
   ('TEMPLATE_STORAGE_TYPE', 'DEFAULT', 'DB', 'same template data to db','STRING', CURRENT_TIMESTAMP, 
    'ADMIN'); 



