-- Configure all the required bins

Insert into BIO_MATCHER_BIN_INFO
   (BIN_ID, TEMPLATE_TYPE, DATA_PRIORITY)
 Values
   (1, 'TEMPLATE_TYPE_1', 1);
-- example to support multiple bins for the same type
Insert into BIO_MATCHER_BIN_INFO
   (BIN_ID, TEMPLATE_TYPE, DATA_PRIORITY)
 Values
   (101, 'TEMPLATE_TYPE_1', 1);
   
Insert into BIO_MATCHER_BIN_INFO
   (BIN_ID, TEMPLATE_TYPE, DATA_PRIORITY)
 Values
   (2, 'TEMPLATE_TYPE_2', 1);

Insert into BIO_MATCHER_BIN_INFO
   (BIN_ID, TEMPLATE_TYPE, DATA_PRIORITY)
 Values
   (102, 'TEMPLATE_TYPE_2', 1);
   
Insert into BIO_MATCHER_BIN_INFO
   (BIN_ID, TEMPLATE_TYPE, DATA_PRIORITY)
 Values
   (3, 'TEMPLATE_TYPE_3', 1);

Insert into BIO_MATCHER_BIN_INFO
   (BIN_ID, TEMPLATE_TYPE, DATA_PRIORITY)
 Values
   (4, 'TEMPLATE_TYPE_4', 1);

Insert into BIO_MATCHER_BIN_INFO
   (BIN_ID, TEMPLATE_TYPE, DATA_PRIORITY)
 Values
   (5, 'TEMPLATE_TYPE_5', 1);

Insert into BIO_MATCHER_BIN_INFO
   (BIN_ID, TEMPLATE_TYPE, DATA_PRIORITY)
 Values
   (103, 'TEMPLATE_TYPE_3', 1);
   
Insert into BIO_MATCHER_BIN_INFO
   (BIN_ID, TEMPLATE_TYPE, DATA_PRIORITY)
 Values
   (11, 'TEMPLATE_TYPE_11', 1);

Insert into BIO_MATCHER_BIN_INFO
   (BIN_ID, TEMPLATE_TYPE, DATA_PRIORITY)
 Values
   (12, 'TEMPLATE_TYPE_12', 1);

Insert into BIO_MATCHER_BIN_INFO
   (BIN_ID, TEMPLATE_TYPE, DATA_PRIORITY)
 Values
   (22, 'TEMPLATE_TYPE_22', 1);

Insert into BIO_MATCHER_BIN_INFO
   (BIN_ID, TEMPLATE_TYPE, DATA_PRIORITY)
 Values
   (31, 'TEMPLATE_TYPE_31', 1);

Insert into BIO_MATCHER_BIN_INFO
   (BIN_ID, TEMPLATE_TYPE, DATA_PRIORITY)
 Values
   (131, 'TEMPLATE_TYPE_31', 1);

Insert into BIO_MATCHER_BIN_INFO
   (BIN_ID, TEMPLATE_TYPE, DATA_PRIORITY)
 Values
   (32, 'TEMPLATE_TYPE_32', 1);

Insert into BIO_MATCHER_BIN_INFO
   (BIN_ID, TEMPLATE_TYPE, DATA_PRIORITY)
 Values
   (33, 'TEMPLATE_TYPE_33', 1);

Insert into BIO_MATCHER_BIN_INFO
   (BIN_ID, TEMPLATE_TYPE, DATA_PRIORITY)
 Values
   (34, 'TEMPLATE_TYPE_34', 1);
   
Insert into BIO_MATCHER_BIN_INFO
   (BIN_ID, TEMPLATE_TYPE, DATA_PRIORITY)
 Values
   (35, 'TEMPLATE_TYPE_35', 1);

Insert into BIO_MATCHER_BIN_INFO
   (BIN_ID, TEMPLATE_TYPE, DATA_PRIORITY)
 Values
   (135, 'TEMPLATE_TYPE_35', 1);
   
Insert into BIO_MATCHER_BIN_INFO
   (BIN_ID, TEMPLATE_TYPE, DATA_PRIORITY)
 Values
   (36, 'TEMPLATE_TYPE_36', 1);
   
Insert into BIO_MATCHER_BIN_INFO
   (BIN_ID, TEMPLATE_TYPE, DATA_PRIORITY)
 Values
   (37, 'TEMPLATE_TYPE_37', 1);

Insert into BIO_MATCHER_BIN_INFO
   (BIN_ID, TEMPLATE_TYPE, DATA_PRIORITY)
 Values
   (38, 'TEMPLATE_TYPE_38', 1);

Insert into BIO_MATCHER_BIN_INFO
   (BIN_ID, TEMPLATE_TYPE, DATA_PRIORITY)
 Values
   (39, 'TEMPLATE_TYPE_39', 1);

Insert into BIO_MATCHER_BIN_INFO
   (BIN_ID, TEMPLATE_TYPE, DATA_PRIORITY)
 Values
   (40, 'TEMPLATE_TYPE_40', 1);

Insert into BIO_MATCHER_BIN_INFO
   (BIN_ID, TEMPLATE_TYPE, DATA_PRIORITY)
 Values
   (41, 'TEMPLATE_TYPE_41', 1);
   
Insert into BIO_MATCHER_BIN_INFO
   (BIN_ID, TEMPLATE_TYPE, DATA_PRIORITY)
 Values
   (42, 'TEMPLATE_TYPE_42', 1);
   
Insert into BIO_MATCHER_BIN_INFO
   (BIN_ID, TEMPLATE_TYPE, DATA_PRIORITY)
 Values
   (43, 'TEMPLATE_TYPE_43', 1);
   
Insert into BIO_MATCHER_BIN_INFO
   (BIN_ID, TEMPLATE_TYPE, DATA_PRIORITY)
 Values
   (44, 'TEMPLATE_TYPE_44', 1);

Insert into BIO_MATCHER_BIN_INFO
   (BIN_ID, TEMPLATE_TYPE, DATA_PRIORITY)
 Values
   (45, 'TEMPLATE_TYPE_45', 1);

Insert into BIO_MATCHER_BIN_INFO
   (BIN_ID, TEMPLATE_TYPE, DATA_PRIORITY)
 Values
   (46, 'TEMPLATE_TYPE_46', 1);

Insert into BIO_MATCHER_BIN_INFO
   (BIN_ID, TEMPLATE_TYPE, DATA_PRIORITY)
 Values
   (47, 'TEMPLATE_TYPE_47', 1);

Insert into BIO_MATCHER_BIN_INFO
   (BIN_ID, TEMPLATE_TYPE, DATA_PRIORITY)
 Values
   (48, 'TEMPLATE_TYPE_48', 1);
   
COMMIT;

-- Add segments for the above bins, as required
-- We prepend the segment ID with the bin ID for easier classification
-- If the system requires more than 9999 segments under a specific bin
-- then for that bin start the segment ID with X00001
Insert into BIO_MATCHER_SEGMENT_INFO
   (SEGMENT_ID, BIN_ID, SEGMENT_VERSION, UPDATE_DATETIME)
 Values
   (10001, 1, -1, CURRENT_TIMESTAMP);

-- Define the size of a segment. This example defines 10000 capsules in segment 10001
Insert into BIO_IDENTIFIER_INFO
   (SEGMENT_ID, BIN_ID, START_BIOMETRIC_ID, END_BIOMETRIC_ID, CURR_BIOMETRIC_ID)
 Values
   (10001, 1, 1000000001, 1000010000, -1);

COMMIT;
