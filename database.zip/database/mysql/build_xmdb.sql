use BIO_MATCHER;

source ./mysql_create_tables.sql

source ./sample-config/add_bin_segments.sql
source ./sample-config/add_ec.sql
source ./sample-config/add_ec_parameters.sql
source ./sample-config/add_en.sql


source ./sample-config/add_sb.sql
source ./sample-config/add_sc.sql
source ./sample-config/add_sc_parameters.sql
source ./sample-config/add_sn.sql

source ./sample-config/add_tvc.sql
source ./sample-config/add_tvn.sql
source ./sample-config/add_vc.sql
source ./sample-config/add_vc_parameters.sql
source ./sample-config/add_vn.sql
source ./sample-config/add_cdb.sql


source ./sample-config/add_groups.sql
source ./sample-config/add_template_definitions.sql
source ./sample-config/add_template_storage.sql






