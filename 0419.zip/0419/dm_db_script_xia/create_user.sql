#create dmdb user

CREATE USER 'xia'@'%' IDENTIFIED BY 'xia@SV99';
GRANT ALL PRIVILEGES ON *.* TO 'xia'@'%' WITH GRANT OPTION;
flush privileges;

