package com.nec.aim.dm.dmservice.dispatch;

import java.sql.Blob;
import java.sql.SQLException;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutionException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nec.aim.dm.dmservice.config.ConfigProperties;
import com.nec.aim.dm.dmservice.entity.Catchup;
import com.nec.aim.dm.dmservice.entity.NodeStorage;
import com.nec.aim.dm.dmservice.entity.SegmentInfo;
import com.nec.aim.dm.dmservice.entity.SegmentLoading;
import com.nec.aim.dm.dmservice.exception.DmServiceException;
import com.nec.aim.dm.dmservice.persistence.CatchupRepository;
import com.nec.aim.dm.dmservice.persistence.DmConfigRepository;
import com.nec.aim.dm.dmservice.persistence.DmInfoRepository;
import com.nec.aim.dm.dmservice.persistence.NodeStorageRepository;
import com.nec.aim.dm.dmservice.persistence.SegmentLoadRepository;
import com.nec.aim.dm.dmservice.persistence.SegmentRepository;
import com.nec.aim.dm.dmservice.post.HttpPoster;

import jp.co.nec.aim.message.proto.AIMEnumTypes.SegmentSyncCommandType;
import jp.co.nec.aim.message.proto.AIMMessages.PBDmSyncRequest;
import jp.co.nec.aim.message.proto.BusinessMessage.PBTemplateInfo;
import lombok.extern.slf4j.Slf4j;


@Service
@Slf4j
public class Dispatcher {
	
	@Autowired
	DmInfoRepository dmInfoRepository;

	@Autowired
	NodeStorageRepository nodeRepository;

	@Autowired
	DmConfigRepository dmConfigRepository;

	@Autowired
	SegmentLoadRepository segmentLoadRepository;

	@Autowired
	SegmentRepository segmentRepository;
	
	@Autowired
	CatchupRepository catchupRepository;
	
	@Autowired
	ConfigProperties config;
	
	@Transactional
	public Boolean handlePostRequest(PBDmSyncRequest dmSegReq) throws SQLException, DmServiceException {		
		String changeType = null;
		Long bioId_start = null;
		Long bioId_end = null;		
		Long segId = null;
		Long segVer = null;	
		try {
			changeType = dmSegReq.getCmd().name().toUpperCase();			
			if (dmSegReq.hasBioIdStart()) {
				bioId_start = Long.valueOf(dmSegReq.getBioIdStart());
			}			
			if (dmSegReq.hasBioIdEnd()) {
				bioId_end = Long.valueOf(dmSegReq.getBioIdEnd());
			}		
						
			segId = Long.valueOf(dmSegReq.getTargetSegment().getId());
			segVer = Long.valueOf(dmSegReq.getTargetSegment().getVersion());
			
		} catch (Exception e) {
			throw new DmServiceException(e);
		}
		
		SegmentInfo segInfo = new SegmentInfo();
		segInfo.setSegmentId(segId);
		segInfo.setVersion(segVer);
		if (bioId_start != null) {
			segInfo.setBioIdStart(bioId_start);			
		}	
		
		if (bioId_end != null) {
			segInfo.setBioIdEnd(bioId_end);			
		}	
		
		int redundancy = dmConfigRepository.getRedundancy();
		List<NodeStorage> activeNodeStorages = nodeRepository.findNeedNodeByRedundancy(redundancy);
		if (activeNodeStorages == null || activeNodeStorages.size() < 1) {
			throw new DmServiceException("No active node storages! skip process and return.");
		}
		
		if (redundancy < 1) {
			throw new DmServiceException("redundancy is less 1! Can't process dm service will return.");
		}
		
		boolean mmReturnValue = true;

		if (changeType.equals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_NEW.name())) { // add segment			
			mmReturnValue = processNewSegment(activeNodeStorages, segInfo, dmSegReq);
		}  else {
			List<NodeStorage> targetNodeStorages = nodeRepository.getNodeStorgeBySegmentId(segInfo.getSegmentId());
			if (changeType.equals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT.name())) { // update template
				mmReturnValue = processTempalteInsert(targetNodeStorages, segInfo, dmSegReq);
			} else if (changeType.equals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_DELETE.name())) { // delete template
				mmReturnValue = processTempalteDelete(activeNodeStorages, segInfo, dmSegReq);
			}
		}		
		return Boolean.valueOf(mmReturnValue);
	}	
	
	private boolean processNewSegment(List<NodeStorage> activeNodeStorages, SegmentInfo segInfo, PBDmSyncRequest dmSegReq) throws SQLException {
		if (segInfo.getBioIdStart() == null || segInfo.getBioIdEnd() == null) {
			throw new DmServiceException("In new segment, bio_id_start and bio_id_end can't be null");
		}
		SegmentLoading segLoading = new SegmentLoading();
		segLoading.setSegmentId(segInfo.getSegmentId());
		segLoading.setLastVersion(0L);
		segInfo.setVersion(0L);		
		boolean mmReturnValue = true;

		segmentRepository.insertSegment(segInfo);
		
		for (int i = 0; i < activeNodeStorages.size(); i++) {
			NodeStorage one = activeNodeStorages.get(i);
			segLoading.setStorage_id(one.getStorageId());
 			segLoading.setStatus(0);			
//			try {				
// 				segmentLoadRepository.insertSegmentLoad(segLoading);
//			} catch (Exception e) {
//				throw new DmServiceException(e);
//			}
			String nodeUrl = dmInfoRepository.getNodeStorageUrl(one.getStorageId());
			nodeUrl = nodeUrl + config.getNsmSyncMethod();
			log.info("post url is {}", nodeUrl);
			Boolean result = HttpPoster.post(nodeUrl, dmSegReq);
			try {
				if (result.booleanValue()) {
					segmentRepository.updateAfterNew(-1, segInfo.getSegmentId());
					//segmentLoadRepository.updateAfterNew(-1, one.getStorageId(), segInfo.getSegmentId());
					segLoading.setLastVersion(-1L);
					segmentLoadRepository.insertSegmentLoad(segLoading);
				} else {
					segmentRepository.updateAfterNew(-9, segInfo.getSegmentId());
					segLoading.setLastVersion(-9L);
					segmentLoadRepository.insertSegmentLoad(segLoading);
					//segmentLoadRepository.updateAfterNew(-9, one.getStorageId(), segInfo.getSegmentId());
					nodeRepository.setSignalMailFlag(one.getStorageId(), one.getDmStorageid());
					catchupRepository.insertForNewSegment(one.getStorageId(), segInfo.getSegmentId(), segInfo.getVersion(), 0);
					
				}
			} catch (Exception e) {				
				throw new DmServiceException(e);
			}
			mmReturnValue = mmReturnValue && result.booleanValue();
		}
		return mmReturnValue;
	}
	
	private boolean processTempalteInsert(List<NodeStorage> targetNodeStorages,SegmentInfo segInfo, PBDmSyncRequest dmSegReq) {			
		String externalId = null;
		byte[] templateData = null;
		if (dmSegReq.hasTemplateData()) {
			PBTemplateInfo tmpData = dmSegReq.getTemplateData();
			if (tmpData.hasReferenceId()) {
				externalId = tmpData.getReferenceId();
			}
			if (tmpData.hasData()) {
				templateData = tmpData.getData().toByteArray();
			}
		}
		
		if (segInfo.getBioIdEnd() == null || externalId == null || templateData == null) {
			throw new DmServiceException("In insert template,  bio_id_end, external id, template data can't be null");
		}
		
		boolean mmReturnValue = true;		
		SegmentLoading segLoading = new SegmentLoading();
		segLoading.setSegmentId(segInfo.getSegmentId());			
		for (int i = 0; i < targetNodeStorages.size(); i++) {
			NodeStorage one = targetNodeStorages.get(i);
			segLoading.setStorage_id(one.getStorageId());
			Boolean result = null;
			boolean mustFaildNodeStorage = false;
			try {
				long nodoSegmentVersion = segmentLoadRepository.getLastVersion(one.getStorageId(), segInfo.getSegmentId());						
				if (segInfo.getVersion() == nodoSegmentVersion + 1) {
					segmentRepository.updateSegment(segInfo);
					String nodeUrl = dmInfoRepository.getNodeStorageUrl(one.getStorageId());
					nodeUrl = nodeUrl + config.getNsmSyncMethod();
					result = HttpPoster.post(nodeUrl, dmSegReq);
					if (result.booleanValue()) {						
						segLoading.setLastVersion(segInfo.getVersion());
						segmentLoadRepository.updateSegmentLoadNoMailFlag(segLoading);
					} else {
						log.warn("Http poster result is false.segmentId={}, semgnetVersion={}", segInfo.getSegmentId(), segInfo.getVersion());
						result = Boolean.FALSE;
						mustFaildNodeStorage = true;
					}
				} else {
					log.warn("segment version({}) +1 in segment_loading table is not equeal the verion from mm, segmentId={}", nodoSegmentVersion, segInfo.getSegmentId());
					result = Boolean.FALSE;
					mustFaildNodeStorage = true;				
				}
			} catch (Exception e) {				
				throw new DmServiceException(e);
			}
			if (mustFaildNodeStorage) {
				nodeRepository.setSignalMailFlag(one.getStorageId(), one.getDmStorageid());
				Catchup cp = new Catchup();
				cp.setBioIdstart(segInfo.getBioIdStart());
				cp.setBioIdEnd(segInfo.getBioIdEnd());
				cp.setChangeType(1);
				cp.setExternalId(externalId);
				cp.setSegmentId(segInfo.getSegmentId());
				cp.setSegmentVersion(segInfo.getVersion());
				cp.setStorageId(one.getStorageId());
				try {
					Blob blob = new javax.sql.rowset.serial.SerialBlob(templateData);
					cp.setTemplateData(blob);					
					catchupRepository.insert(cp);
				} catch (SQLException e) {
					throw new DmServiceException(e);
				}				
			}
			mmReturnValue = mmReturnValue && result.booleanValue();
		}
		return mmReturnValue;
	}
	
	private boolean processTempalteDelete(List<NodeStorage> targetNodeStorages, SegmentInfo segInfo,
			PBDmSyncRequest dmSegReq) {
		String externalId = null;		
		if (dmSegReq.hasTemplateData()) {
			PBTemplateInfo tmpData = dmSegReq.getTemplateData();
			if (tmpData.hasReferenceId()) {
				externalId = tmpData.getReferenceId();
			}		
		}
		if (segInfo.getBioIdEnd() == null || externalId == null) {
			throw new DmServiceException("In delete template,  bio_id_end, external id can't be null");
		}
		
		boolean mmReturnValue = true;
		SegmentLoading segLoading = new SegmentLoading();
		segLoading.setSegmentId(segInfo.getSegmentId());		
		for (int i = 0; i < targetNodeStorages.size(); i++) {
			NodeStorage one = targetNodeStorages.get(i);
			segLoading.setStorage_id(one.getStorageId());
			Boolean result = null;
			boolean mustFaildNodeStorage = false;
			try {
				long nodoSegmentVersion = segmentLoadRepository.getLastVersion(one.getStorageId(),
						segInfo.getSegmentId());
				if (segInfo.getVersion() == nodoSegmentVersion + 1) {
					segmentRepository.updateSegmentAfterDelete(segInfo); //how to do with bio_end
					String nodeUrl = dmInfoRepository.getNodeStorageUrl(one.getStorageId());
					nodeUrl = nodeUrl + config.getNsmSyncMethod();
					result = HttpPoster.post(nodeUrl, dmSegReq);
					if (result.booleanValue()) {
						segLoading.setLastVersion(segInfo.getVersion());										
						segmentLoadRepository.updateAfterDelWithNoMailFlag(segLoading);
					} else {
						log.warn("Http poster result is false.segmentId={}, semgnetVersion={}", segInfo.getSegmentId(), segInfo.getVersion());
						result = Boolean.FALSE;
						mustFaildNodeStorage = true;
					}
				} else {
					result = Boolean.FALSE;
					mustFaildNodeStorage = true;
					log.warn("segment version({}) +1 in segment_loading table is not equeal the verion from mm, segmentId={}", nodoSegmentVersion, segInfo.getSegmentId());
				}

			} catch (Exception e) {
				result = false;
				throw new DmServiceException(e);
			}
			if (mustFaildNodeStorage) {
				nodeRepository.setSignalMailFlag(one.getStorageId(), one.getDmStorageid());
				Catchup cp = new Catchup();
				cp.setBioIdstart(segInfo.getBioIdStart());
				cp.setBioIdEnd(segInfo.getBioIdEnd());
				cp.setChangeType(2);
				cp.setExternalId(externalId);
				cp.setSegmentId(segInfo.getSegmentId());
				cp.setSegmentVersion(segInfo.getVersion());
				cp.setStorageId(one.getStorageId());									
				try {
					catchupRepository.insertForDelete(cp);
				} catch (SQLException e) {
					throw new DmServiceException(e);
				}
			}
			mmReturnValue = mmReturnValue && result.booleanValue();
		}
		return mmReturnValue;
	}

	@Transactional
	public byte[] dispatchGetRequest(Long segId) throws InterruptedException, ExecutionException, SQLException {
		List<NodeStorage> activeList = nodeRepository.findAll();
		if (activeList == null || activeList.size() < 1) {
			throw new DmServiceException("No active dm stroage node for process");
		}
		Collections.shuffle(activeList);
		String nodeUrl = dmInfoRepository.getNodeStorageUrl(activeList.get(0).getStorageId());
		byte[] result = HttpPoster.getSegment(nodeUrl, segId);
		return result;
	}
}
