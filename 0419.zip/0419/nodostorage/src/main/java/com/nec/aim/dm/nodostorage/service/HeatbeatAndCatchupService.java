package com.nec.aim.dm.nodostorage.service;

import java.sql.SQLException;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nec.aim.dm.nodostorage.config.ConfigProperties;

@Service
public class HeatbeatAndCatchupService {
	private static final ScheduledExecutorService statusUpdateScheduler = Executors.newScheduledThreadPool(1);
	private static final ScheduledExecutorService catchUpScheduler = Executors.newScheduledThreadPool(1);

	@Autowired
	DBSerivce dBSerivce;

	@Autowired
	ConfigProperties config;

	@PostConstruct
	public void updateMyInfo() throws SQLException {
		Runnable statusUpdateTask = () -> {
			dBSerivce.doHeatBeat();
		};
		statusUpdateScheduler.scheduleAtFixedRate(statusUpdateTask, 0, config.getHeatbeatInterval(),TimeUnit.MILLISECONDS);
				

		Runnable catchUpTask = () -> {
			dBSerivce.doCatchup();
		};
		catchUpScheduler.scheduleAtFixedRate(catchUpTask, 0, config.getCatchUpInterval(), TimeUnit.MILLISECONDS);
	}

	@PreDestroy
	public void colse() {
		catchUpScheduler.shutdown();
	}
}
