package jp.co.nec.aim.mm.partition;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

import javax.persistence.EntityManager;

import jp.co.nec.aim.mm.constants.JNDIConstants;
import jp.co.nec.aim.mm.dao.SystemInitDao;
import jp.co.nec.aim.mm.sessionbeans.pojo.AimManager;
import jp.co.nec.aim.mm.util.JndiLookup;

public class PartitionUtil {
	
	 private SystemInitDao systemInitDao;	
	
	private static final PartitionUtil INSTANCE = new PartitionUtil();
	
	public static PartitionUtil getInstance() {
		return INSTANCE;
	}
	
	private PartitionUtil() {
		EntityManager entityManager = JndiLookup.lookUp(JNDIConstants.EntityManagerName, EntityManager.class);	
		//DataSource dataSource = JndiLookup.lookUp(JNDIConstants.DataSourceName,DataSource.class);
		systemInitDao = new SystemInitDao(entityManager);
	}	
	
	public  long caculateHashAtThisToday(LocalDate thisDay) {
		//Long saveDays = systemInitDao.getSegChangeLogSaveDays();
		//Long adjust = systemInitDao.getInUsingAdjust();
		Long saveDays = AimManager.getSegChangeSaveDays();
		Long adjust = AimManager.getInUsingAdjust();
		LocalDate epoch = LocalDate.ofEpochDay(0);
		 long epochDays = ChronoUnit.DAYS.between(epoch, thisDay);
		return (epochDays + adjust.longValue()) % (saveDays.longValue());
	}	
	
	public  long caculateNewHashAtThisToday(Long newSaveDays, Long newAdust, LocalDate thisDay) {		
		LocalDate epoch = LocalDate.ofEpochDay(0);
		 long epochDays = ChronoUnit.DAYS.between(epoch, thisDay);
		return (epochDays + newAdust.longValue()) % (newSaveDays.longValue());
	}
	
	public long caculateNewAdjustAtThisDay(Long newN, Long oldSaveDays, LocalDate firstAddDay) {
		//Long oldSaveDays = systemInitDao.getSegChangeLogSaveDays();		
		long firstAddDayHashValue = caculateHashAtThisToday(firstAddDay);		
		LocalDate epoch = LocalDate.ofEpochDay(0);
		long epochDays = ChronoUnit.DAYS.between(epoch, firstAddDay);
		long quotient = epochDays/oldSaveDays;
		long deltaX = oldSaveDays * quotient + firstAddDayHashValue - epochDays;
		long X = (epochDays + deltaX) % oldSaveDays;
		long Y = epochDays % newN;		
		long adjustNew = (X - Y + newN) % newN;			
		return adjustNew;
		//long hashNew = (epochDays + adjustNew) % newN;
	}

}
