package jp.co.nec.aim.mm.exception;

public class UiDaiValidatorException extends AimErrorInfoException {
	
	private static final long serialVersionUID = -3175690673577632831L;

	
	/**
	 * @param errorCode
	 * @param description
	 * @param epochTime
	 * @param uidCode
	 */
	public UiDaiValidatorException(String errorCode, String description,
			String epochTime, String uidCode) {
		super(errorCode, description, epochTime, uidCode);
	}
}
