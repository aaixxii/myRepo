package jp.co.nec.aim.mm.callbakSender;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class AmqExecutorManager {	
	private  static final AmqExecutorManager INSTANCE = new AmqExecutorManager();	
	private final ConcurrentHashMap<String, String> amqMap = new ConcurrentHashMap<>(); //key is MQ_SETTING Id, value=ip:callbackPort(for callback)
	private ExecutorService amqExecutor;
	
	public void putToAmq(String key ,String value) {
		amqMap.putIfAbsent(key, value);
	}
	
	public String getCallbackIpPort(String key) {
		return amqMap.get(key);
	}
	
	
	public AmqExecutorManager() {
		amqExecutor = Executors.newCachedThreadPool();		
	}
	
	public static AmqExecutorManager getInstance() {
		return INSTANCE;
	}
	
	public void commitTask(Runnable task) {
		amqExecutor.submit(task);
	}

	
	public void shutdown () {		
		amqExecutor.shutdown();		
	}
}
