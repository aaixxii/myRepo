/**this is file ObjectUtilTest.java
 * @author xia
   @date 2020/07/21
 */
package jp.co.nec.aim.mm.util;

import java.io.IOException;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import jp.co.nec.aim.mm.constants.UidRequestType;
import jp.co.nec.aim.mm.sessionbeans.pojo.UidAimAmqResponse;

/**
 * @author xia
 *
 */
public class ObjectUtilTest {
	
	@Before
	public void setUp() throws Exception {
	}
	
	@After
	public void tearDown() throws Exception {
	}	
	
	@Test
	public void testSerializeAndDeserializeAmqResults() throws IOException, ClassNotFoundException {
		UidAimAmqResponse uidRespos = new UidAimAmqResponse();
		uidRespos.setRequestId("111122223333");
		uidRespos.setRequestType(UidRequestType.Identify.name());
		uidRespos.setXmlResult(" I am xmlResult");
		uidRespos.setDiagnostics("I am Diagnostics".getBytes());
		byte[] result = ObjectUtil.serializeAmqResults(uidRespos);		
		UidAimAmqResponse uidRes = ObjectUtil.deserializeAmqResults(result);		
		Assert.assertEquals(uidRespos.getRequestId(), uidRes.getRequestId());
		Assert.assertEquals(uidRespos.getRequestType(), uidRes.getRequestType());
		Assert.assertEquals(uidRespos.getXmlResult(), uidRes.getXmlResult());
		Assert.assertEquals(uidRespos.getDiagnostics().length, uidRes.getDiagnostics().length);		
	}

}
