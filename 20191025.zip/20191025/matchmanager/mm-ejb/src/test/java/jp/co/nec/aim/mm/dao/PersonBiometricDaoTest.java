package jp.co.nec.aim.mm.dao;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.aim.mm.entities.PersonBiometricEntity;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class PersonBiometricDaoTest {
	@PersistenceContext(unitName = "aim-db")
	private EntityManager entityManager;
	@Resource
	private DataSource dataSource;
	@Resource
	private JdbcTemplate jdbcTemplate;
	private PersonBiometricDao pbDao;

	@Before
	public void setUp() throws Exception {
		this.pbDao = new PersonBiometricDao(entityManager);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testFindfindPersonBiometric() {
		PersonBiometricEntity pb = new PersonBiometricEntity();	
		pb.setBiometricsId(1);
		pb.setBiometricData("test".getBytes());
		pb.setBiometricDataLen("test".getBytes().length);
		pb.setContainerId(1);
		pb.setExternalId("ext1");
		pb.setRegistedTs(System.currentTimeMillis());
		pb.setCorruptedFlag(3);
		entityManager.persist(pb);	
		PersonBiometricEntity result = pbDao.findPersonBiometric(1);
		Assert.assertEquals(1, result.getBiometricsId());	
	}

	@Test
	public void testDelBioByExternalId() {
		PersonBiometricEntity pb = new PersonBiometricEntity();	
		pb.setBiometricsId(1);
		pb.setBiometricData("test".getBytes());
		pb.setBiometricDataLen("test".getBytes().length);
		pb.setContainerId(1);
		pb.setExternalId("ext1");
		pb.setRegistedTs(System.currentTimeMillis());
		pb.setCorruptedFlag(3);
		entityManager.persist(pb);	
		int count = pbDao.delBioByExternalId("ext1");
		Assert.assertEquals(1, count);		
	}
}
