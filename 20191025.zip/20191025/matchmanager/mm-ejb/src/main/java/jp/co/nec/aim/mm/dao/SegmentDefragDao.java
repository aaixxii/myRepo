package jp.co.nec.aim.mm.dao;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

/**
 * SEGMENT_DEFRAGMENTATION Dao Class
 * 
 * @author mozj
 * 
 */
public class SegmentDefragDao {
	private JdbcTemplate jdbcTemplate;

	public SegmentDefragDao(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	public void initDefragContainerId() {
		int count = jdbcTemplate.queryForObject(
				"select count(CONTAINER_ID) from SEGMENT_DEFRAGMENTATION",
				Integer.class);
		if (count == 0) {
			jdbcTemplate.execute("insert into SEGMENT_DEFRAGMENTATION("
					+ "CONTAINER_ID, START_TS, END_TS) values(-1, 0, 0)");
		} else {
			jdbcTemplate
					.execute("update SEGMENT_DEFRAGMENTATION set CONTAINER_ID = -1");
		}
	}

	public int getDefragContainerId() {
		int containerId = jdbcTemplate.queryForObject(
				"select CONTAINER_ID from SEGMENT_DEFRAGMENTATION",
				Integer.class);
		return containerId;
	}

	public void setDefragContainerId(int containerId) {
		jdbcTemplate
				.update("update SEGMENT_DEFRAGMENTATION set"
						+ " CONTAINER_ID = ?, START_TS = match_manager_api.get_epoch_time_num() ",
						new Integer(containerId));
	}

	// public long getDefragStartTime() {
	// return jdbcTemplate.queryForObject(
	// "select START_TS from SEGMENT_DEFRAGMENTATION", Long.class);
	// }

	public boolean checkTimeOut() {
		if (isTimeout()) {
			setDefragContainerId(-1);
			return true;
		}
		return false;
	}

	private boolean isTimeout() {
		Long count = jdbcTemplate.queryForObject("select count(START_TS)"
				+ " from SEGMENT_DEFRAGMENTATION where START_TS < "
				+ "(select (match_manager_api.get_epoch_time_num() -"
				+ "     to_number(property_value)) from system_config"
				+ " where property_name = 'DEFRAG_TIMEOUT')", Long.class);
		return count.intValue() == 1;
	}
}
