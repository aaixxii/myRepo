package jp.co.nec.aim.mm.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

/**
 * @author mozj
 */
@Entity
@IdClass(jp.co.nec.aim.mm.entities.UnitSegReportPK.class)
public class UnitSegMap {
	private long unitId; // ok
	private long segmentId; // ok

	@Id
	@Column(name = "UNIT_ID")
	public long getUnitId() {
		return unitId;
	}

	public void setUnitId(long unitId) {
		this.unitId = unitId;
	}

	@Id
	@Column(name = "SEGMENT_ID")
	public long getSegmentId() {
		return segmentId;
	}

	public void setSegmentId(long segmentId) {
		this.segmentId = segmentId;
	}

	@Override
	public boolean equals(Object other) {
		if (other instanceof UnitSegMap) {
			UnitSegMap otherMap = (UnitSegMap) other;
			return unitId == otherMap.unitId && segmentId == otherMap.segmentId;
		} else {
			return false;
		}
	}
}
