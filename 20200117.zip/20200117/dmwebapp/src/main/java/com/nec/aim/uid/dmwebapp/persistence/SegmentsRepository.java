package com.nec.aim.uid.dmwebapp.persistence;

import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SegmentsRepository extends CassandraRepository<Segments, Long> {	

}
