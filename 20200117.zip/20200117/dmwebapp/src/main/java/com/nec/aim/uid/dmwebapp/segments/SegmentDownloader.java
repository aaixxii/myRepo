package com.nec.aim.uid.dmwebapp.segments;

import java.sql.Blob;
import java.sql.SQLException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nec.aim.uid.dmwebapp.persistence.Segments;
import com.nec.aim.uid.dmwebapp.persistence.SegmentsRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Scope("prototype")
@Transactional
@Slf4j
public class SegmentDownloader {
	
	@Autowired
	SegmentsRepository segmentsRepository;
	
	public byte[] getSegmentData(long segmentId) {	
		Optional<Segments> SegInfo = segmentsRepository.findById(segmentId);
		byte[] byteData = null;
		if(SegInfo.isPresent()) {
			Blob segBlob = SegInfo.get().getData();
			try {
				 byteData = segBlob.getBytes(0, (int) segBlob.length());
				 log.info("Success get segment({}) data", segmentId);
			} catch (SQLException e) {
				log.error(e.getMessage(), e);
				byteData =  null;
			}
		} else {
			byteData =  null;
		}
		
		return byteData;		
	}	

}
