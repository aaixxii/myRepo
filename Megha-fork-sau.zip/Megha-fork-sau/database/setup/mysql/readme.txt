1. login using root user
2. run mysql_create_tablespace_user.sql
3. login with BIO_MATCHER user;
4. run build_xmdb.sql
