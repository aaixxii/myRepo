spool build_aim.log

WHENEVER OSERROR  EXIT FAILURE;
WHENEVER SQLERROR EXIT SQL.SQLCODE;

prompt
prompt Creating tables ...
prompt

@@./oracle_create_tables.sql

@@./sample-config/add_bin_segments.sql
@@./sample-config/add_ec.sql
@@./sample-config/add_ec_parameters.sql
@@./sample-config/add_en.sql


@@./sample-config/add_sb.sql
@@./sample-config/add_sc.sql
@@./sample-config/add_sc_parameters.sql
@@./sample-config/add_sn.sql

@@./sample-config/add_tvc.sql
@@./sample-config/add_tvn.sql
@@./sample-config/add_vc.sql
@@./sample-config/add_vc_parameters.sql
@@./sample-config/add_vn.sql
@@./sample-config/add_cdb.sql


@@./sample-config/add_groups.sql
@@./sample-config/add_template_definitions.sql
@@./sample-config/add_template_storage.sql






