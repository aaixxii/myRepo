package com.nec.biomatcher.extractor.service.exception;

import com.nec.biomatcher.core.framework.common.exception.CoreException;

/**
 * The Class BioExtractionException.
 */
public class BioExtractionException extends CoreException {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new bio extraction exception.
	 *
	 * @param message
	 *            the message
	 * @param cause
	 *            the cause
	 */
	public BioExtractionException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Instantiates a new bio extraction exception.
	 *
	 * @param errorCode
	 *            the error code
	 * @param message
	 *            the message
	 */
	public BioExtractionException(String errorCode, String message) {
		super(errorCode, message);
	}

	/**
	 * Instantiates a new bio extraction exception.
	 *
	 * @param message
	 *            the message
	 */
	public BioExtractionException(String message) {
		super(message);
	}

	/**
	 * Instantiates a new bio extraction exception.
	 *
	 * @param cause
	 *            the cause
	 */
	public BioExtractionException(Throwable cause) {
		super(cause);
	}
}
