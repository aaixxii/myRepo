package com.nec.biomatcher.comp.config.impl;

import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentSkipListSet;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.google.common.base.Throwables;
import com.google.common.collect.Iterators;
import com.google.common.collect.Sets;
import com.google.common.util.concurrent.AtomicLongMap;
import com.nec.biomatcher.comp.common.locking.BioLockingService;
import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.config.BioMatcherConfigService;
import com.nec.biomatcher.comp.config.dataAccess.BioMatcherConfigDao;
import com.nec.biomatcher.comp.config.exception.BioMatcherConfigServiceException;
import com.nec.biomatcher.comp.entities.dataAccess.BioMatcherBinInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BioMatcherNodeSegmentInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BioMatcherSegmentInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BioServerConnectionInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BioServerGroupInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BioServerInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BiometricIdInfo;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioComponentType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioConnectionType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioProtocolType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioServerState;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioServerType;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateConfig;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateParser;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateUtil;
import com.nec.biomatcher.comp.template.packing.util.TemplateDefinationPatch;
import com.nec.biomatcher.comp.util.ServerConnectionUtil;
import com.nec.biomatcher.core.framework.common.BiKey;
import com.nec.biomatcher.core.framework.common.CommonLogger;
import com.nec.biomatcher.core.framework.common.GsonSerializer;
import com.nec.biomatcher.core.framework.common.HostnameUtil;
import com.nec.biomatcher.core.framework.common.PFLogger;
import com.nec.biomatcher.core.framework.common.StringUtil;
import com.nec.biomatcher.core.framework.common.ValuedHashMap;
import com.nec.biomatcher.core.framework.common.concurrent.ConcurrentValuedHashMap;
import com.nec.biomatcher.core.framework.common.concurrent.CyclicIterator;
import com.nec.biomatcher.core.framework.springSupport.SpringSelfAssignmentMarker;
import com.nec.biomatcher.spec.transfer.model.AlgorithmType;
import com.nec.biomatcher.spec.transfer.model.TemplateType;

/**
 * The Class BioMatcherConfigServiceImpl.
 */
public class BioMatcherConfigServiceImpl implements BioMatcherConfigService, SpringSelfAssignmentMarker {

	/** The Constant logger. */
	private static final Logger logger = Logger.getLogger(BioMatcherConfigServiceImpl.class);

	/** The bio matcher config dao. */
	private BioMatcherConfigDao bioMatcherConfigDao;

	/** The bio locking service. */
	private BioLockingService bioLockingService;

	private BioParameterService bioParameterService;

	/** The _this. */
	private BioMatcherConfigService _this = this;

	@Override
	public List<BioMatcherBinInfo> getMatcherBinInfoList() throws BioMatcherConfigServiceException {
		try {
			return new CopyOnWriteArrayList<>(bioMatcherConfigDao.getAllEntity(BioMatcherBinInfo.class));
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in getMatcherBinInfoList: " + th.getMessage(), th);
		}
	}

	@Override
	public BioMatcherBinInfo getMatcherBinInfo(Integer binId) throws BioMatcherConfigServiceException {
		try {
			return bioMatcherConfigDao.getEntity(BioMatcherBinInfo.class, binId);
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in getMatcherBinInfo: " + th.getMessage(), th);
		}
	}

	@Override
	public BioMatcherBinInfo getMatcherBinInfoForUpdate(Integer binId) throws BioMatcherConfigServiceException {
		try {
			return bioMatcherConfigDao.getEntityForUpdate(BioMatcherBinInfo.class, binId);
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in getMatcherBinInfoForUpdate: " + th.getMessage(), th);
		}
	}

	public List<BioServerGroupInfo> getServerGroupInfoList() throws BioMatcherConfigServiceException {
		try {
			return bioMatcherConfigDao.getAllEntity(BioServerGroupInfo.class);
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in getServerGroupInfoList: " + th.getMessage(), th);
		}
	}

	public BioServerGroupInfo getServerGroupInfo(String groupId) throws BioMatcherConfigServiceException {
		try {
			return bioMatcherConfigDao.getEntity(BioServerGroupInfo.class, groupId);
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in getServerGroupInfo: " + th.getMessage(), th);
		}
	}

	public void saveServerGroupInfo(BioServerGroupInfo bioServerGroupInfo) throws BioMatcherConfigServiceException {
		try {
			bioMatcherConfigDao.saveOrUpdateEntity(bioServerGroupInfo);
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in saveServerGroupInfo: " + th.getMessage(), th);
		}
	}

	public void deleteServerGroupInfo(String groupId) throws BioMatcherConfigServiceException {
		try {
			BioServerGroupInfo bioServerGroupInfo = bioMatcherConfigDao.getEntity(BioServerGroupInfo.class, groupId);
			if (bioServerGroupInfo != null) {
				bioMatcherConfigDao.deleteEntity(bioServerGroupInfo);
			}
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in deleteServerGroupInfo: " + th.getMessage(), th);
		}
	}

	public BioServerInfo getServerInfo(String serverId) throws BioMatcherConfigServiceException {
		try {
			return bioMatcherConfigDao.getEntity(BioServerInfo.class, serverId);
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in getServerInfoList: " + th.getMessage(), th);
		}
	}

	public Map<String, Integer> getServerCapacityGroupMap(String serverId) throws BioMatcherConfigServiceException {
		try {
			BioServerInfo bioServerInfo = _this.getServerInfo(serverId);

			Map<String, Integer> capacityGroupMap = new HashMap<>();
			Map<String, String> serverProperties = bioServerInfo.getServerProperties();
			if (serverProperties != null && !serverProperties.isEmpty()) {
				int totalCapacity = 0;
				for (Entry<String, String> entry : serverProperties.entrySet()) {
					if (entry.getKey().startsWith("capacityGroup.")) {
						String capacityGroupKey = StringUtils
								.trimToNull(StringUtils.substringAfter(entry.getKey(), "capacityGroup."));
						Integer capacity = StringUtil.stringToInt(StringUtils.trim(entry.getValue()));
						if (capacityGroupKey != null && capacity != null) {
							capacityGroupMap.put(capacityGroupKey, capacity);
							totalCapacity += capacity;
						}
					}
				}
				if (bioServerInfo.getMaxJobCount() > totalCapacity && !capacityGroupMap.containsKey("0")) {
					capacityGroupMap.put("0", bioServerInfo.getMaxJobCount() - totalCapacity);
				}
			} else {
				capacityGroupMap.put("0", bioServerInfo.getMaxJobCount());
			}

			return capacityGroupMap;
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException(
					"Error in getServerCapacityGroupMap: serverId: " + serverId + " : " + th.getMessage(), th);
		}
	}

	public void saveServerInfo(BioServerInfo bioServerInfo) throws BioMatcherConfigServiceException {
		try {
			bioServerInfo.setServerId(StringUtils.upperCase(bioServerInfo.getServerId()));

			BioServerInfo currentBioServerInfo = bioMatcherConfigDao.getEntityForUpdate(BioServerInfo.class,
					bioServerInfo.getServerId());
			if (currentBioServerInfo != null) {
				currentBioServerInfo.setComponentType(bioServerInfo.getComponentType());
				currentBioServerInfo.setMaxJobCount(bioServerInfo.getMaxJobCount());
				currentBioServerInfo.setServerGroupId(bioServerInfo.getServerGroupId());
				currentBioServerInfo.setServerHost(bioServerInfo.getServerHost());
				currentBioServerInfo.setServerProperties(bioServerInfo.getServerProperties());
				currentBioServerInfo.setServerState(bioServerInfo.getServerState());
				currentBioServerInfo.setServerType(bioServerInfo.getServerType());
				currentBioServerInfo.setSubSystemGroupId(bioServerInfo.getSubSystemGroupId());
				currentBioServerInfo.setUpdateDateTime(new Date());
				bioMatcherConfigDao.updateEntity(currentBioServerInfo);
			} else {
				bioServerInfo.setCreateDateTime(new Date());
				bioServerInfo.setUpdateDateTime(new Date());

				bioMatcherConfigDao.saveEntity(bioServerInfo);
			}

			createServerConnnections(bioServerInfo.getServerId(), bioServerInfo.getServerHost(),
					bioServerInfo.getComponentType());

		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in saveServerInfo: " + th.getMessage(), th);
		}
	}

	public void deleteServerInfo(String serverId) throws BioMatcherConfigServiceException {
		try {
			BioServerInfo bioServerInfo = bioMatcherConfigDao.getEntity(BioServerInfo.class, serverId);
			if (bioServerInfo != null) {
				bioMatcherConfigDao.deleteEntity(bioServerInfo);
			}
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in deleteServerInfo: " + th.getMessage(), th);
		}
	}

	public List<BioServerInfo> getServerInfoList() throws BioMatcherConfigServiceException {
		try {
			return bioMatcherConfigDao.getAllEntity(BioServerInfo.class);
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in getServerInfoList: " + th.getMessage(), th);
		}
	}

	public List<BioServerInfo> getServerInfoList(BioServerType serverType) throws BioMatcherConfigServiceException {
		try {
			return bioMatcherConfigDao.getEntityListByField(BioServerInfo.class, "serverType", serverType);
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in getServerInfoList: " + th.getMessage(), th);
		}
	}

	public Set<String> getServerHostnameSet(BioServerType serverType) throws BioMatcherConfigServiceException {
		try {
			return _this.getServerInfoList(serverType).stream().map(BioServerInfo::getServerHost)
					.collect(Collectors.toSet());
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in getServerHostnameSet: " + th.getMessage(), th);
		}
	}

	public BioServerInfo getServerInfoByServerType(BioServerType serverType, BioComponentType componentType)
			throws BioMatcherConfigServiceException {
		try {
			return bioMatcherConfigDao.getEntityByFields(BioServerInfo.class, "serverType", serverType, "componentType",
					componentType);
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in getServerInfoByServerType: " + th.getMessage(), th);
		}
	}

	public List<BioServerInfo> getServerInfoListByServerGroup(String serverGroupId)
			throws BioMatcherConfigServiceException {
		try {
			return bioMatcherConfigDao.getEntityListByField(BioServerInfo.class, "serverGroupId", serverGroupId);
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in getServerInfoListByServerGroup: " + th.getMessage(),
					th);
		}
	}

	public List<BioServerInfo> getServerInfoListByServerHost(String serverHost)
			throws BioMatcherConfigServiceException {
		try {
			return bioMatcherConfigDao.getEntityListByField(BioServerInfo.class, "serverHost", serverHost);
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in getServerInfoListByServerHost: " + th.getMessage(),
					th);
		}
	}

	public BioServerInfo getServerInfoByServerHost(String serverHost, BioComponentType componentType)
			throws BioMatcherConfigServiceException {
		try {
			return bioMatcherConfigDao.getEntityByFields(BioServerInfo.class, "serverHost", serverHost, "componentType",
					componentType);
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in getServerInfoByServerHost: " + th.getMessage(), th);
		}
	}

	public BioServerInfo getServerInfoByServerHost(String serverHost, String serverIpAddress,
			BioComponentType componentType) throws BioMatcherConfigServiceException {
		try {
			BioServerInfo bioServerInfo = bioMatcherConfigDao.getEntityByFields(BioServerInfo.class, "serverHost",
					serverIpAddress, "componentType", componentType);
			if (bioServerInfo == null) {
				bioServerInfo = bioMatcherConfigDao.getEntityByFields(BioServerInfo.class, "serverHost", serverHost,
						"componentType", componentType);
			}
			return bioServerInfo;
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in getServerInfoByServerHost for serverHost: "
					+ serverHost + ", serverIpAddress: " + serverIpAddress + " : " + th.getMessage(), th);
		}
	}

	public List<BioServerInfo> getServerInfoListByServerGroup(String serverGroupId, BioComponentType componentType)
			throws BioMatcherConfigServiceException {
		try {
			return bioMatcherConfigDao.getEntityListByFields(BioServerInfo.class, "serverGroupId", serverGroupId,
					"componentType", componentType);
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in getServerInfoListByServerGroup: " + th.getMessage(),
					th);
		}
	}

	public List<BioServerInfo> getServerInfoListByComponentType(BioComponentType componentType)
			throws BioMatcherConfigServiceException {
		try {
			return bioMatcherConfigDao.getEntityListByField(BioServerInfo.class, "componentType", componentType);
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in getServerInfoListByComponentType: " + th.getMessage(),
					th);
		}
	}

	public List<BioServerInfo> getServerInfoListByComponentType(BioComponentType componentType,
			BioServerState serverState) throws BioMatcherConfigServiceException {
		try {
			return bioMatcherConfigDao.getEntityListByFields(BioServerInfo.class, "componentType", componentType,
					"serverState", serverState);
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in getServerInfoListByComponentType: " + th.getMessage(),
					th);
		}
	}

	public List<String> getRemoteServerInfoListBySiteId(String siteId) throws BioMatcherConfigServiceException {
		try {
			List<BioServerInfo> remoteServerInfoList = _this.getServerInfoListByComponentType(BioComponentType.RSC,
					BioServerState.ACTIVE);
			return remoteServerInfoList.stream().filter((p) -> (siteId.equals(p.getServerProperty("SITE_ID", null))))
					.map(BioServerInfo::getServerId).collect(Collectors.toList());
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in getServerInfoListByComponentType: " + th.getMessage(),
					th);
		}
	}

	public void updateServerInfo(BioServerInfo bioServerInfo) throws BioMatcherConfigServiceException {
		try {
			bioServerInfo.setUpdateDateTime(new Date());
			bioMatcherConfigDao.updateEntity(bioServerInfo);
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in updateServerInfo: " + th.getMessage(), th);
		}
	}

	public List<BioServerConnectionInfo> getServerConnectionInfoList() throws BioMatcherConfigServiceException {
		try {
			return bioMatcherConfigDao.getAllEntity(BioServerConnectionInfo.class);
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in getServerConnectionInfoList: " + th.getMessage(), th);
		}
	}

	public BioServerConnectionInfo getServerConnectionInfo(String serverId, BioComponentType componentType,
			BioConnectionType connectionType) throws BioMatcherConfigServiceException {
		try {
			BioServerConnectionInfo connectionInfo = bioMatcherConfigDao.getEntityByFields(
					BioServerConnectionInfo.class, "serverId", StringUtils.upperCase(serverId), "componentType",
					componentType, "connectionType", connectionType);
			return connectionInfo;
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in getServerConnectionInfo: " + th.getMessage(), th);
		}
	}

	public String getServerConnectionUrl(String serverId, BioComponentType componentType,
			BioConnectionType connectionType, BioProtocolType protocolType) throws BioMatcherConfigServiceException {
		try {
			BioServerConnectionInfo connectionInfo = _this.getServerConnectionInfo(serverId, componentType,
					connectionType);
			if (connectionInfo != null && StringUtils.isNotBlank(connectionInfo.getConnectionUrl())) {
				return connectionInfo.getConnectionUrl();
			}
			return null;
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in getServerConnectionUrl: " + th.getMessage(), th);
		}
	}

	public String getServerConnectionUrl(String serverId, BioConnectionType connectionType,
			BioProtocolType protocolType) throws BioMatcherConfigServiceException {
		try {
			BioServerInfo bioServrInfo = _this.getServerInfo(serverId);

			BioServerConnectionInfo connectionInfo = _this.getServerConnectionInfo(serverId,
					bioServrInfo.getComponentType(), connectionType);
			if (connectionInfo != null && StringUtils.isNotBlank(connectionInfo.getConnectionUrl())) {
				return connectionInfo.getConnectionUrl();
			}
			return null;
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException(
					"Error in getServerConnectionUrl: serverId: " + serverId + ", connectionType: " + connectionType
							+ ", protocolType: " + protocolType + " : " + th.getMessage(),
					th);
		}
	}

	public void deleteStaleConnectionSettings() throws BioMatcherConfigServiceException {
		try {
			bioMatcherConfigDao.deleteStaleConnectionSettings();
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in deleteStaleConnectionSettings : " + th.getMessage(),
					th);
		}
	}

	public List<BioMatcherSegmentInfo> getSearchSegmentInfoListByBinId(Integer binId)
			throws BioMatcherConfigServiceException {
		try {
			return bioMatcherConfigDao.getEntityListByField(BioMatcherSegmentInfo.class, "binId", binId);
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in getSearchSegmentInfoListByBinId: " + th.getMessage(),
					th);
		}
	}

	public Map<Integer, BioMatcherSegmentInfo> getSegmentIdMatcherSegmentInfoMap()
			throws BioMatcherConfigServiceException {
		try {
			return Collections.unmodifiableMap(bioMatcherConfigDao.getAllEntity(BioMatcherSegmentInfo.class).stream()
					.collect(Collectors.toMap(v -> v.getSegmentId(), Function.identity())));
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in getSegmentIdMatcherSegmentInfoMap: " + th.getMessage(),
					th);
		}
	}

	public List<BioMatcherNodeSegmentInfo> getAllSearchNodeSegmentInfoList() throws BioMatcherConfigServiceException {
		try {
			return bioMatcherConfigDao.getAllEntity(BioMatcherNodeSegmentInfo.class);
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in getAllSearchNodeSegmentInfoList: " + th.getMessage(),
					th);
		}
	}

	public ConcurrentValuedHashMap<String, List<BioMatcherNodeSegmentInfo>> getSearchNodeIdSearchNodeSegmentInfoListMap()
			throws BioMatcherConfigServiceException {
		try {
			final ConcurrentValuedHashMap<String, List<BioMatcherNodeSegmentInfo>> searchNodeIdSearchNodeSegmentInfoListMap = new ConcurrentValuedHashMap<>(
					searchNodeId -> new ArrayList<>());
			_this.getAllSearchNodeSegmentInfoList().forEach(matcherNodeSegmentInfo -> {
				searchNodeIdSearchNodeSegmentInfoListMap.getValue(matcherNodeSegmentInfo.getMatcherNodeId())
						.add(matcherNodeSegmentInfo);
			});
			return searchNodeIdSearchNodeSegmentInfoListMap;
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException(
					"Error in getSearchNodeIdSearchNodeSegmentInfoListMap: " + th.getMessage(), th);
		}
	}

	public ConcurrentValuedHashMap<Integer, List<BioMatcherNodeSegmentInfo>> getSegmentIdSearchNodeSegmentInfoListMap()
			throws BioMatcherConfigServiceException {
		try {
			final ConcurrentValuedHashMap<Integer, List<BioMatcherNodeSegmentInfo>> segmentIdSearchNodeSegmentInfoListMap = new ConcurrentValuedHashMap<>(
					segmentId -> new ArrayList<>());
			_this.getAllSearchNodeSegmentInfoList().forEach(matcherNodeSegmentInfo -> {
				segmentIdSearchNodeSegmentInfoListMap.getValue(matcherNodeSegmentInfo.getSegmentId())
						.add(matcherNodeSegmentInfo);
			});
			return segmentIdSearchNodeSegmentInfoListMap;
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException(
					"Error in getSegmentIdSearchNodeSegmentInfoListMap: " + th.getMessage(), th);
		}
	}

	public BioMatcherNodeSegmentInfo getSearchNodeSegmentInfo(String searchNodeId, Integer segmentId)
			throws BioMatcherConfigServiceException {
		try {
			return bioMatcherConfigDao.getEntityByFields(BioMatcherNodeSegmentInfo.class, "matcherNodeId", searchNodeId,
					"segmentId", segmentId);
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in getSearchNodeSegmentInfo: " + th.getMessage(), th);
		}
	}

	public Map<Integer, Set<String>> getAssignedSegmentIdSearchNodeIdListMapBySearchBrokerId(String searchBrokerId)
			throws BioMatcherConfigServiceException {
		try {
			Map<Integer, Set<String>> segmentIdSearchNodeIdSetMap = new HashMap<>();

			ConcurrentValuedHashMap<Integer, List<BioMatcherNodeSegmentInfo>> segmentIdSearchNodeSegmentInfoListMap = _this
					.getSegmentIdSearchNodeSegmentInfoListMap();

			if (segmentIdSearchNodeSegmentInfoListMap.size() == 0) {
				return segmentIdSearchNodeIdSetMap;
			}

			BioServerInfo searchBroker = _this.getServerInfo(searchBrokerId);

			if (searchBroker == null || searchBroker.getSubSystemGroupId() == null) {
				return segmentIdSearchNodeIdSetMap;
			}

			Predicate<String> searchNodeGroupPredicate = (String searchNodeId) -> {
				try {
					BioServerInfo bioServerInfo = _this.getServerInfo(searchNodeId);
					if (bioServerInfo != null && BioServerState.ACTIVE.equals(bioServerInfo.getServerState())) {
						return searchBroker.getSubSystemGroupId().equals(bioServerInfo.getServerGroupId());
					}
				} catch (Throwable th) {
					Throwables.propagate(th);
				}
				return false;
			};

			for (Integer segmentId : segmentIdSearchNodeSegmentInfoListMap.keySet()) {
				List<BioMatcherNodeSegmentInfo> searchNodeSegmentInfoList = segmentIdSearchNodeSegmentInfoListMap
						.get(segmentId);
				Set<String> searchNodeIdSet = searchNodeSegmentInfoList.stream()
						.map(BioMatcherNodeSegmentInfo::getMatcherNodeId).filter(searchNodeGroupPredicate)
						.collect(Collectors.toSet());
				segmentIdSearchNodeIdSetMap.put(segmentId, Collections.unmodifiableSet(searchNodeIdSet));
			}

			return segmentIdSearchNodeIdSetMap;

		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException(
					"Error in getAssignedSegmentIdSearchNodeIdListMapBySearchBrokerId: " + th.getMessage(), th);
		}
	}

	public Set<String> getAssignedSearchNodeIdListByBinId(Integer binId) throws BioMatcherConfigServiceException {
		try {
			Set<String> searchNodeIdSet = new HashSet<>();

			List<BioMatcherSegmentInfo> searchSegmentInfoList = _this.getSearchSegmentInfoListByBinId(binId);

			ConcurrentValuedHashMap<Integer, List<BioMatcherNodeSegmentInfo>> segmentIdSearchNodeSegmentInfoListMap = _this
					.getSegmentIdSearchNodeSegmentInfoListMap();
			for (BioMatcherSegmentInfo searchSegmentInfo : searchSegmentInfoList) {
				List<BioMatcherNodeSegmentInfo> searchNodeSegmentInfoList = segmentIdSearchNodeSegmentInfoListMap
						.getValue(searchSegmentInfo.getSegmentId());

				searchNodeSegmentInfoList.forEach((searchNodeSegmentInfo) -> {
					try {
						if (Boolean.TRUE.equals(searchNodeSegmentInfo.getAssignedFlag())) {
							BioServerInfo searchNodeInfo = _this
									.getServerInfo(searchNodeSegmentInfo.getMatcherNodeId());
							if (searchNodeInfo != null
									&& BioServerState.ACTIVE.equals(searchNodeInfo.getServerState())) {
								searchNodeIdSet.add(searchNodeInfo.getServerId());
							}
						}
					} catch (Throwable th) {
						Throwables.propagate(th);
					}
				});
			}

			return searchNodeIdSet;
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException(
					"Error in getAssignedSearchNodeIdListByBinId: " + th.getMessage(), th);
		}
	}

	public Set<String> getAssignedSearchNodeIdListByBinId(Integer binId, String capacityGroupKey)
			throws BioMatcherConfigServiceException {
		try {
			Set<String> searchNodeIdSet = _this.getAssignedSearchNodeIdListByBinId(binId);

			searchNodeIdSet = searchNodeIdSet.stream().filter(searchNodeId -> {
				try {
					Map<String, Integer> serverCapacityGroupMap = _this.getServerCapacityGroupMap(searchNodeId);
					return serverCapacityGroupMap.getOrDefault(capacityGroupKey, 0) > 0;
				} catch (Throwable th) {
					throw Throwables.propagate(th);
				}
			}).collect(Collectors.toSet());

			return Collections.unmodifiableSet(searchNodeIdSet);
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in getAssignedSearchNodeIdListByBinId: binId: " + binId
					+ ", capacityGroupKey: " + capacityGroupKey + " : " + th.getMessage(), th);
		}
	}

	public Set<Integer> getMissingSegmentAssignmentsByBinId(Integer binId, String capacityGroupKey)
			throws BioMatcherConfigServiceException {
		try {
			Set<String> capacityGroupSearchNodeIdSet = _this.getCapacityGroupSearchNodeIdListMap()
					.getValue(capacityGroupKey);

			// Set<Integer> segmentIdSet =
			Map<Integer, Integer> segmentIdBinIdMap = _this.getSegmentIdBinIdMap();

			ConcurrentValuedHashMap<Integer, List<BioMatcherNodeSegmentInfo>> segmentIdSearchNodeSegmentInfoListMap = _this
					.getSegmentIdSearchNodeSegmentInfoListMap();

			Set<Integer> missingSegmentAssignmentsSet = new HashSet<>();

			segmentIdBinIdMap.entrySet().forEach(entry -> {
				if (!binId.equals(entry.getValue())) {
					return;
				}

				List<BioMatcherNodeSegmentInfo> assignedMatcherNodeList = segmentIdSearchNodeSegmentInfoListMap
						.get(entry.getKey());

				if (assignedMatcherNodeList == null || assignedMatcherNodeList.isEmpty()) {
					missingSegmentAssignmentsSet.add(entry.getKey());
				} else {
					boolean hasAnyMatcherNodeAssignedFlag = false;
					for (BioMatcherNodeSegmentInfo matcherNodeSegmentInfo : assignedMatcherNodeList) {
						if (matcherNodeSegmentInfo.getAssignedFlag()
								&& capacityGroupSearchNodeIdSet.contains(matcherNodeSegmentInfo.getMatcherNodeId())) {
							hasAnyMatcherNodeAssignedFlag = true;
							break;
						}
					}

					if (!hasAnyMatcherNodeAssignedFlag) {
						missingSegmentAssignmentsSet.add(entry.getKey());
					}
				}
			});

			return Collections.unmodifiableSet(missingSegmentAssignmentsSet);
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in getMissingSegmentAssignmentsByBinId: binId: " + binId
					+ ", capacityGroupKey: " + capacityGroupKey + " : " + th.getMessage(), th);
		}
	}

	public ConcurrentValuedHashMap<String, Set<String>> getCapacityGroupSearchNodeIdListMap()
			throws BioMatcherConfigServiceException {
		try {
			List<BioServerInfo> serverInfoList = _this.getServerInfoListByComponentType(BioComponentType.SN,
					BioServerState.ACTIVE);

			ConcurrentValuedHashMap<String, Set<String>> capacityGroupSearchNodeIdListMap = new ConcurrentValuedHashMap<>(
					capacityGroupId -> new HashSet<>());

			for (BioServerInfo serverInfo : serverInfoList) {
				Map<String, Integer> serverCapacityGroupMap = _this.getServerCapacityGroupMap(serverInfo.getServerId());
				if (!serverCapacityGroupMap.isEmpty()) {
					for (Entry<String, Integer> entry : serverCapacityGroupMap.entrySet()) {
						if (entry.getValue() != null && entry.getValue() > 0) {
							capacityGroupSearchNodeIdListMap.getValue(entry.getKey()).add(serverInfo.getServerId());
						}
					}
				}

			}

			return capacityGroupSearchNodeIdListMap;
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException(
					"Error in getCapacityGroupSearchNodeIdListMap: " + th.getMessage(), th);
		}
	}

	public Set<String> getAssignedSearchNodeIdCapacityGroupIdKeyList() throws BioMatcherConfigServiceException {
		try {
			ConcurrentSkipListSet<String> searchNodeIdCapacityGroupIdKeySet = new ConcurrentSkipListSet<>();

			Set<String> assignedSearchNodeIdSet = _this.getAssignedSearchNodeIdList();
			ConcurrentValuedHashMap<String, Set<String>> capacityGroupSearchNodeIdListMap = _this
					.getCapacityGroupSearchNodeIdListMap();
			capacityGroupSearchNodeIdListMap.forEach((capacityGroupId, snIdSet) -> {
				if (snIdSet != null) {
					for (String searchNodeId : snIdSet) {
						if (assignedSearchNodeIdSet.contains(searchNodeId)) {
							searchNodeIdCapacityGroupIdKeySet.add(searchNodeId + "|" + capacityGroupId);
						}
					}
				}
			});

			return searchNodeIdCapacityGroupIdKeySet;
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException(
					"Error in getAssignedSearchNodeIdCapacityGroupIdKeyList: " + th.getMessage(), th);
		}
	}

	public Set<String> getAssignedSearchNodeIdListByBinId(Collection<Integer> binIdList)
			throws BioMatcherConfigServiceException {
		final Set<String> searchNodeIdSet = new HashSet<>();

		binIdList.forEach(binId -> {
			try {
				searchNodeIdSet.addAll(_this.getAssignedSearchNodeIdListByBinId(binId));
			} catch (Throwable th) {
				Throwables.propagate(th);
			}
		});

		return searchNodeIdSet;
	}

	public Set<String> getAssignedSearchNodeIdListBySegmentId(Integer segmentId)
			throws BioMatcherConfigServiceException {
		try {
			List<BioMatcherNodeSegmentInfo> searchNodeSegmentInfoList = _this.getAllSearchNodeSegmentInfoList();

			Set<String> searchNodeIdSet = searchNodeSegmentInfoList.stream()
					.filter((p) -> (p.getSegmentId().equals(segmentId) && Boolean.TRUE.equals(p.getAssignedFlag())))
					.map(BioMatcherNodeSegmentInfo::getMatcherNodeId).collect(Collectors.toSet());

			return searchNodeIdSet;
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException(
					"Error in getAssignedSearchNodeIdListBySegmentId: " + th.getMessage(), th);
		}
	}

	public Set<String> getAssignedSearchNodeIdList() throws BioMatcherConfigServiceException {
		try {
			List<BioMatcherNodeSegmentInfo> searchNodeSegmentInfoList = _this.getAllSearchNodeSegmentInfoList();

			Set<String> searchNodeIdSet = searchNodeSegmentInfoList.stream()
					.filter((p) -> Boolean.TRUE.equals(p.getAssignedFlag()))
					.map(BioMatcherNodeSegmentInfo::getMatcherNodeId).collect(Collectors.toSet());

			return Collections.unmodifiableSet(searchNodeIdSet);
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in getAssignedSearchNodeIdList: " + th.getMessage(), th);
		}
	}

	public Set<Integer> getAssignedSegmentIdList() throws BioMatcherConfigServiceException {
		try {
			List<BioMatcherNodeSegmentInfo> searchNodeSegmentInfoList = _this.getAllSearchNodeSegmentInfoList();

			Set<Integer> segmentIdSet = searchNodeSegmentInfoList.stream()
					.filter((p) -> Boolean.TRUE.equals(p.getAssignedFlag()))
					.map(BioMatcherNodeSegmentInfo::getSegmentId).collect(Collectors.toSet());

			return segmentIdSet;
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in getAssignedSegmentIdList: " + th.getMessage(), th);
		}
	}

	public Map<Integer, BiometricIdInfo> getSegmentIdBiometricIdInfoMap() throws BioMatcherConfigServiceException {
		try {
			Map<Integer, BiometricIdInfo> segmentIdBiometricIdInfoMap = new HashMap<>();
			_this.getBiometricIdInfoList().stream().forEach(biometricIdInfo -> {
				segmentIdBiometricIdInfoMap.put(biometricIdInfo.getSegmentId(), biometricIdInfo);
			});
			return segmentIdBiometricIdInfoMap;
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in getSegmentIdBiometricIdInfoMap: " + th.getMessage(),
					th);
		}
	}

	public List<BiometricIdInfo> getBiometricIdInfoListByBinId(Integer binId) throws BioMatcherConfigServiceException {
		try {
			return bioMatcherConfigDao.getEntityListByField(BiometricIdInfo.class, "binId", binId);
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in getBiometricIdInfo: " + th.getMessage(), th);
		}
	}

	public List<BiometricIdInfo> getBiometricIdInfoList() throws BioMatcherConfigServiceException {
		try {
			return bioMatcherConfigDao.getAllEntity(BiometricIdInfo.class);
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in getBiometricIdInfoList: " + th.getMessage(), th);
		}
	}

	public Iterator<Integer> getCyclicSegmentIdListByBinId(Integer binId) throws BioMatcherConfigServiceException {
		try {
			final Comparator<BiometricIdInfo> segmentComparator = (BiometricIdInfo segment1,
					BiometricIdInfo segment2) -> {
				if (segment1 == segment2) {
					return 0;
				}

				if (segment1 == null) {
					return 1;
				} else if (segment2 == null) {
					return -1;
				}

				int segmentIdCompVal = segment1.getSegmentId().compareTo(segment2.getSegmentId());

				if (segmentIdCompVal == 0) {
					return 0;
				}

				int compValue = Long.compare(segment1.getAvailableBiometricIdCount(),
						segment2.getAvailableBiometricIdCount());
				if (compValue == 0) {
					compValue = segmentIdCompVal;
				}

				return compValue;
			};

			List<Integer> segmentIdList = bioMatcherConfigDao
					.getEntityListByField(BiometricIdInfo.class, "binId", binId).stream().sorted(segmentComparator)
					.map(BiometricIdInfo::getSegmentId).collect(Collectors.toList());

			return new CyclicIterator<>(segmentIdList);
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException(
					"Error in getCyclicSegmentIdListByBinId: binId: " + binId + " : " + th.getMessage(), th);
		}
	}

	public TreeSet<Integer> getOrderedSegmentIdSetByBinId(Integer binId) throws BioMatcherConfigServiceException {
		try {
			List<BiometricIdInfo> biometricIdInfoList = bioMatcherConfigDao.getEntityListByField(BiometricIdInfo.class,
					"binId", binId);
			final Map<Integer, BiometricIdInfo> biometricIdInfoMap = biometricIdInfoList.stream()
					.collect(Collectors.toMap(BiometricIdInfo::getSegmentId, Function.identity()));

			Comparator<Integer> segmentIdComparator = (Integer segmentId1, Integer segmentId2) -> {
				if (segmentId1 == segmentId2) {
					return 0;
				}

				if (segmentId1 == null) {
					return 1;
				} else if (segmentId2 == null) {
					return -1;
				} else if (segmentId1.equals(segmentId2)) {
					return 0;
				}

				BiometricIdInfo seg1BiometricIdInfo = biometricIdInfoMap.get(segmentId1);
				BiometricIdInfo seg2BiometricIdInfo = biometricIdInfoMap.get(segmentId2);

				if (seg1BiometricIdInfo == null) {
					return 1;
				} else if (seg2BiometricIdInfo == null) {
					return -1;
				}

				int compValue = Long.compare(seg1BiometricIdInfo.getAvailableBiometricIdCount(),
						seg2BiometricIdInfo.getAvailableBiometricIdCount());
				if (compValue == 0) {
					compValue = Integer.compare(segmentId1, segmentId2);
				}

				return compValue;
			};

			TreeSet<Integer> segmentIdSet = new TreeSet<>(segmentIdComparator);
			segmentIdSet.addAll(biometricIdInfoMap.keySet());

			return segmentIdSet;
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException(
					"Error in getConcurrentSegmentIdSetByBinId: binId: " + binId + " : " + th.getMessage(), th);
		}
	}

	public Map<Integer, Integer> getSegmentIdBinIdMap() throws BioMatcherConfigServiceException {
		try {
			return Collections.unmodifiableMap(_this.getBiometricIdInfoList().stream()
					.collect(Collectors.toMap(BiometricIdInfo::getSegmentId, BiometricIdInfo::getBinId)));
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in getSegmentIdBinIdMap: " + th.getMessage(), th);
		}
	}

	public Set<Integer> getAssignedSegmentIdListBySearchNodeId(String searchNodeId)
			throws BioMatcherConfigServiceException {
		try {
			Set<Integer> segmentIdSet = new HashSet<>();

			List<BioMatcherNodeSegmentInfo> matcherNodeSegmentInfoList = _this
					.getSearchNodeIdSearchNodeSegmentInfoListMap().getValue(searchNodeId);
			matcherNodeSegmentInfoList.forEach(matcherNodeSegmentInfo -> {
				if (Boolean.TRUE.equals(matcherNodeSegmentInfo.getAssignedFlag())) {
					segmentIdSet.add(matcherNodeSegmentInfo.getSegmentId());
				}
			});

			return Collections.unmodifiableSet(segmentIdSet);
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException(
					"Error in getAssignedSegmentIdListBySearchBrokerId: " + th.getMessage(), th);
		}
	}

	public ConcurrentValuedHashMap<String, List<Integer>> getSortedSearchNodeIdSegmentIdListMap()
			throws BioMatcherConfigServiceException {
		try {

			ConcurrentValuedHashMap<String, List<Integer>> searchNodeIdSegmentIdSetMap = new ConcurrentValuedHashMap<>(
					searchNodeId -> new ArrayList<>());
			ConcurrentValuedHashMap<Integer, Set<String>> segmentIdSearchNodeIdSetMap = new ConcurrentValuedHashMap<>(
					segmentId -> new HashSet<>());

			Map<String, List<BioMatcherNodeSegmentInfo>> searchNodeIdSearchNodeSegmentInfoListMap = _this
					.getSearchNodeIdSearchNodeSegmentInfoListMap();
			for (String searchNodeId : searchNodeIdSearchNodeSegmentInfoListMap.keySet()) {
				List<BioMatcherNodeSegmentInfo> matcherNodeSegmentInfoList = searchNodeIdSearchNodeSegmentInfoListMap
						.get(searchNodeId);
				if (matcherNodeSegmentInfoList != null) {
					matcherNodeSegmentInfoList.forEach(matcherNodeSegmentInfo -> {
						if (Boolean.TRUE.equals(matcherNodeSegmentInfo.getAssignedFlag())) {
							searchNodeIdSegmentIdSetMap.getValue(searchNodeId)
									.add(matcherNodeSegmentInfo.getSegmentId());
							segmentIdSearchNodeIdSetMap.getValue(matcherNodeSegmentInfo.getSegmentId())
									.add(searchNodeId);
						}
					});
				}
			}

			Comparator<Integer> comparator = new Comparator<Integer>() {
				@Override
				public int compare(Integer segmentId1, Integer segmentId2) {
					int segmentIdCompareValue = Integer.compare(segmentId1, segmentId2);
					if (segmentIdCompareValue == 0) {
						return 0;
					}

					int segmentId1SnCount = segmentIdSearchNodeIdSetMap.getValue(segmentId1).size();
					int segmentId2SnCount = segmentIdSearchNodeIdSetMap.getValue(segmentId2).size();

					return (segmentId1SnCount < segmentId2SnCount) ? -1
							: ((segmentId1SnCount == segmentId2SnCount) ? segmentIdCompareValue : 1);
				}
			};

			ConcurrentValuedHashMap<String, List<Integer>> searchNodeIdSegmentIdListMap = new ConcurrentValuedHashMap<>(
					searchNodeId -> new ArrayList<>());

			for (String searchNodeId : searchNodeIdSegmentIdSetMap.keySet()) {
				searchNodeIdSegmentIdListMap.getValue(searchNodeId)
						.addAll(searchNodeIdSegmentIdSetMap.getValue(searchNodeId));
				Collections.sort(searchNodeIdSegmentIdListMap.getValue(searchNodeId), comparator);
			}

			return searchNodeIdSegmentIdListMap;
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException(
					"Error in getAssignedSegmentIdListBySearchBrokerId: " + th.getMessage(), th);
		}
	}

	public ValuedHashMap<String, Set<Integer>> getAssignedSearchNodeIdBinIdSetMap()
			throws BioMatcherConfigServiceException {
		try {
			ValuedHashMap<String, Set<Integer>> searchNodeIdBinIdSetMap = new ValuedHashMap<>(
					searchNodeId -> new HashSet<>());

			Map<Integer, Integer> segmentIdBinIdMap = _this.getSegmentIdBinIdMap();

			List<BioServerInfo> serverInfoList = _this.getServerInfoListByComponentType(BioComponentType.SN,
					BioServerState.ACTIVE);

			for (BioServerInfo searchNodeInfo : serverInfoList) {
				Set<Integer> segmentIdSet = _this.getAssignedSegmentIdListBySearchNodeId(searchNodeInfo.getServerId());
				segmentIdSet.forEach(segmentId -> {
					Integer binId = segmentIdBinIdMap.get(segmentId);
					searchNodeIdBinIdSetMap.getValue(searchNodeInfo.getServerId()).add(binId);
				});
			}

			return searchNodeIdBinIdSetMap;
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException(
					"Error in getAssignedSearchNodeIdBinIdSetMap: " + th.getMessage(), th);
		}
	}

	public Set<Integer> getAssignedSegmentIdListBySearchBrokerId(String searchBrokerId)
			throws BioMatcherConfigServiceException {
		try {
			Set<Integer> segmentIdSet = new HashSet<>();
			BioServerInfo searchBrokerInfo = _this.getServerInfo(searchBrokerId);
			if (StringUtils.isBlank(searchBrokerInfo.getSubSystemGroupId())) {
				return segmentIdSet;
			}

			ConcurrentValuedHashMap<String, List<BioMatcherNodeSegmentInfo>> searchNodeIdSearchNodeSegmentInfoListMap = _this
					.getSearchNodeIdSearchNodeSegmentInfoListMap();
			List<BioServerInfo> searchNodeList = _this
					.getServerInfoListByServerGroup(searchBrokerInfo.getSubSystemGroupId(), BioComponentType.SN);
			for (BioServerInfo searchNodeInfo : searchNodeList) {
				List<BioMatcherNodeSegmentInfo> matcherNodeSegmentInfoList = searchNodeIdSearchNodeSegmentInfoListMap
						.getValue(searchNodeInfo.getServerId());
				matcherNodeSegmentInfoList
						.forEach(matcherNodeSegmentInfo -> segmentIdSet.add(matcherNodeSegmentInfo.getSegmentId()));
			}

			return segmentIdSet;
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException(
					"Error in getAssignedSegmentIdListBySearchBrokerId: " + th.getMessage(), th);
		}
	}

	public Set<Integer> getAssignedBinIdListBySearchBrokerId(String searchBrokerId)
			throws BioMatcherConfigServiceException {
		try {
			final Set<Integer> segmentIdSet = _this.getAssignedSegmentIdListBySearchBrokerId(searchBrokerId);
			final Map<Integer, BioMatcherSegmentInfo> segmentIdMatcherSegmentInfoMap = _this
					.getSegmentIdMatcherSegmentInfoMap();
			final Set<Integer> binIdSet = new HashSet<>();

			segmentIdSet.forEach((segmentId) -> {
				try {
					BioMatcherSegmentInfo bioMatcherSegmentInfo = segmentIdMatcherSegmentInfoMap.get(segmentId);
					if (bioMatcherSegmentInfo != null) {
						binIdSet.add(bioMatcherSegmentInfo.getBinId());
					}
				} catch (Throwable th) {
					Throwables.propagate(th);
				}
			});

			return binIdSet;
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException(
					"Error in getAssignedBinIdListBySearchBrokerId: " + th.getMessage(), th);
		}
	}

	public Set<String> getAssignedSearchNodeIdListBySearchBrokerId(String searchBrokerId)
			throws BioMatcherConfigServiceException {
		try {
			Set<String> searchNodeIdSet = new HashSet<>();
			BioServerInfo searchBrokerInfo = _this.getServerInfo(searchBrokerId);
			if (StringUtils.isBlank(searchBrokerInfo.getSubSystemGroupId())) {
				return searchNodeIdSet;
			}

			List<BioServerInfo> searchNodeList = _this
					.getServerInfoListByServerGroup(searchBrokerInfo.getSubSystemGroupId(), BioComponentType.SN);
			for (BioServerInfo searchNodeInfo : searchNodeList) {
				searchNodeIdSet.add(searchNodeInfo.getServerId());
			}

			return searchNodeIdSet;
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException(
					"Error in getAssignedSearchNodeIdListBySearchBrokerId for searchBrokerId: " + searchBrokerId
							+ ", : " + th.getMessage(),
					th);
		}
	}

	public String getAssignedSearchBrokerIdBySearchNodeGroupId(String searchNodeGroupId)
			throws BioMatcherConfigServiceException {
		try {
			List<BioServerInfo> searchBrokerList = _this.getServerInfoListByComponentType(BioComponentType.SB);

			for (BioServerInfo searchBrokerInfo : searchBrokerList) {
				if (!BioServerState.ACTIVE.equals(searchBrokerInfo.getServerState())
						|| StringUtils.isBlank(searchBrokerInfo.getSubSystemGroupId())) {
					continue;
				}

				if (searchBrokerInfo.getSubSystemGroupId().equals(searchNodeGroupId)) {
					return searchBrokerInfo.getServerId();
				}
			}

			logger.warn("Cannot find active searchBroker by searchNodeGroupId: " + searchNodeGroupId);

			return null;
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException(
					"Error in getAssignedSearchBrokerIdBySearchNodeGroupId searchNodeGroupId: " + searchNodeGroupId
							+ " : " + th.getMessage(),
					th);
		}
	}

	public Map<String, String> getSearchNodeIdSearchBrokerIdMap() throws BioMatcherConfigServiceException {
		try {
			Map<String, String> searchNodeIdSearchBrokerIdMap = new HashMap<>();

			List<BioServerInfo> searchBrokerList = _this.getServerInfoListByComponentType(BioComponentType.SB);
			for (BioServerInfo searchBrokerInfo : searchBrokerList) {
				if (!BioServerState.ACTIVE.equals(searchBrokerInfo.getServerState())
						|| StringUtils.isBlank(searchBrokerInfo.getSubSystemGroupId())) {
					continue;
				}

				List<BioServerInfo> searchNodeList = _this
						.getServerInfoListByServerGroup(searchBrokerInfo.getSubSystemGroupId(), BioComponentType.SN);
				for (BioServerInfo searchNodeInfo : searchNodeList) {
					searchNodeIdSearchBrokerIdMap.put(searchNodeInfo.getServerId(), searchBrokerInfo.getServerId());
				}
			}

			return searchNodeIdSearchBrokerIdMap;
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in getSearchNodeIdSearchBrokerIdMap : " + th.getMessage(),
					th);
		}
	}

	public Map<Integer, String> getSegmentIdTemplateTypeMap() throws BioMatcherConfigServiceException {
		try {
			Map<Integer, String> segmentIdTemplateTypeMap = new HashMap<>();

			Map<Integer, Integer> segmentIdBinIdMap = _this.getSegmentIdBinIdMap();

			for (Integer segmentId : segmentIdBinIdMap.keySet()) {
				Integer binId = segmentIdBinIdMap.get(segmentId);
				BioMatcherBinInfo bioMatcherBinInfo = _this.getMatcherBinInfo(binId);
				segmentIdTemplateTypeMap.put(segmentId, bioMatcherBinInfo.getTemplateType());
			}

			return segmentIdTemplateTypeMap;
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in getSegmentIdTemplateTypeMap : " + th.getMessage(), th);
		}
	}

	public void createServerConnnections(String serverId, String serverHost, BioComponentType componentType)
			throws BioMatcherConfigServiceException {
		try {
			bioLockingService.acquireTransactionLock(serverId);

			List<BioServerConnectionInfo> connectonList = ServerConnectionUtil.buildConnectionList(serverId, serverHost,
					componentType);

			Set<String> serverHostnameIpAddressList = HostnameUtil.getHostnameIpAddressList(serverHost);

			for (BioServerConnectionInfo connectionInfo : connectonList) {
				BioServerConnectionInfo currConnectionInfo = _this.getServerConnectionInfo(serverId, componentType,
						connectionInfo.getConnectionType());
				try {
					if (currConnectionInfo == null) {
						bioMatcherConfigDao.saveEntity(connectionInfo);
						bioMatcherConfigDao.flush();
					} else {
						URI uri = new URI(currConnectionInfo.getConnectionUrl());
						// !"*".equals(uri.getHost()) &&
						if (!serverHost.equals(uri.getHost()) && !serverHostnameIpAddressList.contains(uri.getHost())) {
							String newConnectionUrl = currConnectionInfo.getConnectionUrl().replace(uri.getHost(),
									serverHost);
							CommonLogger.CONFIG_LOG
									.info("In createServerConnnections before updating connection: currConnectionInfo: "
											+ GsonSerializer.toJson(currConnectionInfo) + ", newConnectionUrl: "
											+ newConnectionUrl);

							currConnectionInfo.setConnectionUrl(newConnectionUrl);
							bioMatcherConfigDao.saveOrUpdateEntity(currConnectionInfo);
							bioMatcherConfigDao.flush();
						}
					}
				} catch (Throwable th) {
					logger.error("Error in createServerConnnections: currConnectionInfo: "
							+ GsonSerializer.toJson(currConnectionInfo) + ", connectionInfo: "
							+ GsonSerializer.toJson(connectionInfo));
					throw new BioMatcherConfigServiceException("Error in createServerConnnections: " + th.getMessage(),
							th);
				}
			}
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in createServerConnnections: " + th.getMessage(), th);
		}
	}

	public void saveServerConnectionInfo(BioServerConnectionInfo bioServerConnectionInfo)
			throws BioMatcherConfigServiceException {
		try {
			bioServerConnectionInfo.setServerId(StringUtils.upperCase(bioServerConnectionInfo.getServerId()));

			BioServerConnectionInfo currentBioServerConnectionInfo = getServerConnectionInfo(
					bioServerConnectionInfo.getServerId(), bioServerConnectionInfo.getComponentType(),
					bioServerConnectionInfo.getConnectionType());
			if (currentBioServerConnectionInfo != null) {
				currentBioServerConnectionInfo.setProtocolType(bioServerConnectionInfo.getProtocolType());
				currentBioServerConnectionInfo
						.setConnectionProperties(bioServerConnectionInfo.getConnectionProperties());
				currentBioServerConnectionInfo.setConnectionUrl(bioServerConnectionInfo.getConnectionUrl());
				bioMatcherConfigDao.saveOrUpdateEntity(currentBioServerConnectionInfo);
			} else {
				bioMatcherConfigDao.saveEntity(bioServerConnectionInfo);
			}
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in saveServerConnectionInfo: " + th.getMessage(), th);
		}
	}

	public void deleteServerConnectionInfo(String serverId, BioComponentType componentType,
			BioConnectionType connectionType) throws BioMatcherConfigServiceException {
		try {
			bioMatcherConfigDao.deleteServerConnectionInfo(serverId, componentType, connectionType);
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in deleteServerConnectionInfo: " + th.getMessage(), th);
		}
	}

	public void saveMatcherBinInfo(BioMatcherBinInfo bioMatcherBinInfo) throws BioMatcherConfigServiceException {
		try {
			bioMatcherConfigDao.saveOrUpdateEntity(bioMatcherBinInfo);
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in saveMatcherBinInfo: " + th.getMessage(), th);
		}
	}

	public void deleteMatcherBinInfo(Integer binId) throws BioMatcherConfigServiceException {
		try {
			BioMatcherBinInfo bioMatcherBinInfo = bioMatcherConfigDao.getEntity(BioMatcherBinInfo.class, binId);
			if (bioMatcherBinInfo != null) {
				bioMatcherConfigDao.deleteEntity(bioMatcherBinInfo);
			}
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in deleteMatcherBinInfo: " + th.getMessage(), th);
		}
	}

	public void saveMatcherSegmentInfo(BioMatcherSegmentInfo bioMatcherSegmentInfo)
			throws BioMatcherConfigServiceException {
		try {
			if (bioMatcherSegmentInfo.getSegmentVersion() == null) {
				bioMatcherSegmentInfo.setSegmentVersion(-1L);
			}

			BioMatcherSegmentInfo currBioMatcherSegmentInfo = bioMatcherConfigDao.getEntity(BioMatcherSegmentInfo.class,
					bioMatcherSegmentInfo.getSegmentId());
			if (currBioMatcherSegmentInfo == null) {
				bioMatcherSegmentInfo.setUpdateDateTime(new Date());
				bioMatcherConfigDao.saveEntity(bioMatcherSegmentInfo);
			} else {
				currBioMatcherSegmentInfo.setBinId(bioMatcherSegmentInfo.getBinId());
				currBioMatcherSegmentInfo.setUpdateDateTime(new Date());
				bioMatcherConfigDao.updateEntity(currBioMatcherSegmentInfo);
			}
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in saveMatcherSegmentInfo: " + th.getMessage(), th);
		}
	}

	public void saveMatcherSegmentInfo(Integer segmentId, Integer binId, Long startBiometricId, Long endBiometricId,
			String assignedSearchNodes) throws BioMatcherConfigServiceException {
		logger.info("In saveMatcherSegmentInfo: segmentId: " + segmentId + ", binId: " + binId + ", startBiometricId: "
				+ startBiometricId + ", endBiometricId: " + endBiometricId + ", assignedSearchNodes: "
				+ assignedSearchNodes);
		try {
			BioMatcherSegmentInfo currBioMatcherSegmentInfo = bioMatcherConfigDao.getEntity(BioMatcherSegmentInfo.class,
					segmentId);
			if (currBioMatcherSegmentInfo == null) {
				if (binId == null) {
					throw new BioMatcherConfigServiceException("binId is not set");
				}

				currBioMatcherSegmentInfo = new BioMatcherSegmentInfo();
				currBioMatcherSegmentInfo.setBinId(binId);
				currBioMatcherSegmentInfo.setSegmentId(segmentId);
				currBioMatcherSegmentInfo.setSegmentVersion(-1L);
				currBioMatcherSegmentInfo.setUpdateDateTime(new Date());
				bioMatcherConfigDao.saveEntity(currBioMatcherSegmentInfo);
			}

			BiometricIdInfo biometricIdInfo = bioMatcherConfigDao.getEntityForUpdate(BiometricIdInfo.class, segmentId);
			if (biometricIdInfo == null) {
				biometricIdInfo = new BiometricIdInfo();
				biometricIdInfo.setBinId(binId);
				biometricIdInfo.setSegmentId(segmentId);
				biometricIdInfo.setCurrentBiometricId(-1L);
				biometricIdInfo.setStartBiometricId(startBiometricId);
				biometricIdInfo.setEndBiometricId(endBiometricId);
				bioMatcherConfigDao.saveEntity(biometricIdInfo);
			} else if ((!biometricIdInfo.getStartBiometricId().equals(startBiometricId))
					|| (!biometricIdInfo.getEndBiometricId().equals(endBiometricId))) {
				biometricIdInfo.setStartBiometricId(startBiometricId);
				biometricIdInfo.setEndBiometricId(endBiometricId);
				bioMatcherConfigDao.updateEntity(biometricIdInfo);
			}

			Set<String> currentAssignedSearchNodes = _this.getAssignedSearchNodeIdListBySegmentId(segmentId);

			if (StringUtils.isNotBlank(assignedSearchNodes)) {
				List<String> assignedSearchNodesList = StringUtil.stringToList(assignedSearchNodes, ",");

				for (String newSearchNodeId : assignedSearchNodesList) {
					if (!currentAssignedSearchNodes.contains(newSearchNodeId)) {
						saveMatcherNodeSegmentInfo(newSearchNodeId, segmentId, true, null);
					}
				}

				for (String currentAssignedSearchNode : currentAssignedSearchNodes) {
					if (!assignedSearchNodes.contains(currentAssignedSearchNode)) {
						saveMatcherNodeSegmentInfo(currentAssignedSearchNode, segmentId, false, null);
					}
				}
			} else {
				for (String currentAssignedSearchNode : currentAssignedSearchNodes) {
					saveMatcherNodeSegmentInfo(currentAssignedSearchNode, segmentId, false, null);
				}
			}
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in saveMatcherSegmentInfo: " + th.getMessage(), th);
		}
	}

	public void autoCreateAndAssignSegments(Integer binId, Long totalRecords, Long maxRecordsPerSegment,
			Integer snRamSize, Integer segmentRedundancy, String assignedSearchNodes[])
			throws BioMatcherConfigServiceException {
		logger.info("In autoCreateAndAssignSegments: binId: " + binId + ", totalRecords: " + totalRecords
				+ ", maxRecordsPerSegment: " + maxRecordsPerSegment + ", snRamSize: " + snRamSize
				+ ", segmentRedundancy: " + segmentRedundancy + ", assignedSearchNodes: "
				+ StringUtils.join(assignedSearchNodes, ","));
		PFLogger.start();
		try {

			Map<TemplateType, MeghaTemplateParser> meghaTemplateParserMap = _this
					.getTemplateTypeMeghaTemplateParserMap();

			Map<Integer, Integer> segmentIdBinIdMap = _this.getSegmentIdBinIdMap();

			BioMatcherBinInfo bioMatcherBinInfo = _this.getMatcherBinInfo(binId);
			TemplateType templateType = TemplateType.valueOf(bioMatcherBinInfo.getTemplateType());
			int templateSize = meghaTemplateParserMap.get(templateType).getTemplateDataSize();
			long segmentSize = 32L + (Math.min(maxRecordsPerSegment, totalRecords) * templateSize);

			// AtomicLongMap<String> snAvailableRamSizeMap =
			// AtomicLongMap.create();
			ValuedHashMap<String, Set<String>> snGroupSearchNodeIdSetMap = new ValuedHashMap<>(
					searchNodeGroupId -> new HashSet<String>());
			ValuedHashMap<String, AtomicLongMap<String>> snGroupSnAvailableRamSizeMap = new ValuedHashMap<>(
					searchNodeGroupId -> AtomicLongMap.create());
			for (String searchNodeId : assignedSearchNodes) {
				BioServerInfo bioServerInfo = _this.getServerInfo(searchNodeId);
				if (bioServerInfo == null) {
					logger.warn("Cannot find search node with searchNodeId: " + searchNodeId);
					continue;
				}

				if (StringUtils.isBlank(bioServerInfo.getServerGroupId())) {
					throw new BioMatcherConfigServiceException(
							"Server Node Group Id is not set for Search Node: " + searchNodeId);
				}
				snGroupSearchNodeIdSetMap.getValue(bioServerInfo.getServerGroupId()).add(searchNodeId);

				snGroupSnAvailableRamSizeMap.getValue(bioServerInfo.getServerGroupId()).put(searchNodeId,
						1024L * 1024L * 1024L * snRamSize);
			}

			ConcurrentValuedHashMap<String, List<BioMatcherNodeSegmentInfo>> searchNodeIdSearchNodeSegmentInfoListMap = _this
					.getSearchNodeIdSearchNodeSegmentInfoListMap();

			for (String snGroupId : snGroupSearchNodeIdSetMap.keySet()) {
				Set<String> subAssignedSearchNodes = snGroupSearchNodeIdSetMap.getValue(snGroupId);
				AtomicLongMap<String> snAvailableRamSizeMap = snGroupSnAvailableRamSizeMap.getValue(snGroupId);
				for (String searchNodeId : subAssignedSearchNodes) {
					List<BioMatcherNodeSegmentInfo> searchNodeSegmentInfoList = searchNodeIdSearchNodeSegmentInfoListMap
							.getValue(searchNodeId);
					for (BioMatcherNodeSegmentInfo bioMatcherNodeSegmentInfo : searchNodeSegmentInfoList) {
						if (Boolean.TRUE.equals(bioMatcherNodeSegmentInfo.getAssignedFlag())) {
							Integer segmentBinId = segmentIdBinIdMap.get(bioMatcherNodeSegmentInfo.getSegmentId());
							BioMatcherBinInfo segmentMatcherBinInfo = _this.getMatcherBinInfo(segmentBinId);
							TemplateType segmentTemplateType = TemplateType
									.valueOf(segmentMatcherBinInfo.getTemplateType());
							int segmentTemplateSize = meghaTemplateParserMap.get(segmentTemplateType)
									.getTemplateDataSize();
							long matcherNodeSegmentSize = 32L + (maxRecordsPerSegment * segmentTemplateSize);
							long currAvailableRamSize = snAvailableRamSizeMap.addAndGet(searchNodeId,
									-matcherNodeSegmentSize);
							if (currAvailableRamSize <= segmentSize) {
								snAvailableRamSizeMap.remove(searchNodeId);
							}
						}
					}
				}
			}

			for (String snGroupId : snGroupSearchNodeIdSetMap.keySet()) {
				Set<String> subAssignedSearchNodes = snGroupSearchNodeIdSetMap.getValue(snGroupId);
				AtomicLongMap<String> snAvailableRamSizeMap = snGroupSnAvailableRamSizeMap.getValue(snGroupId);
				for (String searchNodeId : subAssignedSearchNodes) {
					List<BioMatcherNodeSegmentInfo> searchNodeSegmentInfoList = searchNodeIdSearchNodeSegmentInfoListMap
							.getValue(searchNodeId);
					for (BioMatcherNodeSegmentInfo bioMatcherNodeSegmentInfo : searchNodeSegmentInfoList) {
						if (Boolean.TRUE.equals(bioMatcherNodeSegmentInfo.getAssignedFlag())) {
							Integer segmentBinId = segmentIdBinIdMap.get(bioMatcherNodeSegmentInfo.getSegmentId());
							BioMatcherBinInfo segmentMatcherBinInfo = _this.getMatcherBinInfo(segmentBinId);
							TemplateType segmentTemplateType = TemplateType
									.valueOf(segmentMatcherBinInfo.getTemplateType());
							int segmentTemplateSize = meghaTemplateParserMap.get(segmentTemplateType)
									.getTemplateDataSize();
							long matcherNodeSegmentSize = 32L + (maxRecordsPerSegment * segmentTemplateSize);
							long currAvailableRamSize = snAvailableRamSizeMap.addAndGet(searchNodeId,
									-matcherNodeSegmentSize);
							if (currAvailableRamSize <= segmentSize) {
								snAvailableRamSizeMap.remove(searchNodeId);
							}
						}
					}
				}
			}

			long totalRamSizeRequirement = (totalRecords * templateSize)
					+ (Math.abs(Math.floorDiv(totalRecords, maxRecordsPerSegment)) * 32L);
			for (String snGroupId : snGroupSnAvailableRamSizeMap.keySet()) {
				AtomicLongMap<String> snAvailableRamSizeMap = snGroupSnAvailableRamSizeMap.getValue(snGroupId);
				if (totalRamSizeRequirement > snAvailableRamSizeMap.sum()) {
					throw new BioMatcherConfigServiceException("Total available ram size: "
							+ snAvailableRamSizeMap.sum() + " is not sufficent to assign totalRamSizeRequirement: "
							+ totalRamSizeRequirement + " for Search Node Group: " + snGroupId);
				}
			}

			Comparator<BiKey<String, Long>> entryComparator = (entry1, entry2) -> {
				if (entry1 == entry2) {
					return 0;
				}

				if (entry1 == null) {
					return 1;
				} else if (entry2 == null) {
					return -1;
				} else if (entry1.a.equals(entry2.a)) {
					return 0;
				}

				int compValue = Long.compare(entry2.b, entry1.b);
				if (compValue == 0) {
					compValue = entry1.a.compareTo(entry2.a);
				}
				return compValue;
			};

			List<BiometricIdInfo> biometricIdInfoList = bioMatcherConfigDao.getAllEntity(BiometricIdInfo.class);
			long maxBiometricId = 0;
			int maxSegmentId = 0;
			for (BiometricIdInfo biometricIdInfo : biometricIdInfoList) {
				maxBiometricId = Math.max(maxBiometricId, biometricIdInfo.getEndBiometricId());
				maxSegmentId = Math.max(maxSegmentId, biometricIdInfo.getSegmentId());
			}

			List<BioMatcherSegmentInfo> newBioMatcherSegmentInfoList = new ArrayList<>();
			List<BiometricIdInfo> newBiometricIdInfoList = new ArrayList<>();
			List<BioMatcherNodeSegmentInfo> newBioMatcherNodeSegmentInfoList = new ArrayList<>();
			long startBiometricId = maxBiometricId;
			long endBiometricId = maxBiometricId;
			Integer segmentId = maxSegmentId;
			while (totalRecords > 0) {
				segmentId++;

				BioMatcherSegmentInfo bioMatcherSegmentInfo = new BioMatcherSegmentInfo();
				bioMatcherSegmentInfo.setBinId(binId);
				bioMatcherSegmentInfo.setSegmentId(segmentId);
				bioMatcherSegmentInfo.setSegmentVersion(-1L);
				bioMatcherSegmentInfo.setUpdateDateTime(new Date());
				newBioMatcherSegmentInfoList.add(bioMatcherSegmentInfo);

				startBiometricId = endBiometricId + 1;
				endBiometricId = startBiometricId + Math.min(maxRecordsPerSegment, totalRecords) - 1;

				totalRecords = totalRecords - Math.min(maxRecordsPerSegment, totalRecords);

				BiometricIdInfo biometricIdInfo = new BiometricIdInfo();
				biometricIdInfo.setBinId(binId);
				biometricIdInfo.setSegmentId(segmentId);
				biometricIdInfo.setStartBiometricId(startBiometricId);
				biometricIdInfo.setEndBiometricId(endBiometricId);
				biometricIdInfo.setCurrentBiometricId(-1L);
				newBiometricIdInfoList.add(biometricIdInfo);

				long currSegmentSize = ((endBiometricId - startBiometricId + 1) * templateSize) + 32L;

				for (String snGroupId : snGroupSearchNodeIdSetMap.keySet()) {
					AtomicLongMap<String> snAvailableRamSizeMap = snGroupSnAvailableRamSizeMap.getValue(snGroupId);

					ValuedHashMap<String, Set<Integer>> snAssignedSegmentIdSetMap = new ValuedHashMap<>(
							searchNodeId -> new HashSet<Integer>());

					TreeSet<BiKey<String, Long>> snAvailableRamSizeSet = new TreeSet<>(entryComparator);
					for (Entry<String, Long> entry : snAvailableRamSizeMap.asMap().entrySet()) {
						snAvailableRamSizeSet.add(new BiKey<String, Long>(entry.getKey(), entry.getValue()));
					}
					Iterator<BiKey<String, Long>> cyclicSnAvailableRamSizeIterator = Iterators
							.cycle(snAvailableRamSizeSet);

					for (int i = 0; i <= segmentRedundancy; i++) {
						// find sn with max ram size which doesnot have this
						// segment
						boolean assignedFlag = false;
						BiKey<String, Long> first = null;
						while (cyclicSnAvailableRamSizeIterator.hasNext()) {
							BiKey<String, Long> entry = cyclicSnAvailableRamSizeIterator.next();
							if (first == null) {
								first = entry;
							} else if (first == entry) {
								break;
							}

							if (entry.b > 0) {
								if (!snAssignedSegmentIdSetMap.getValue(entry.a).contains(segmentId)) {
									snAssignedSegmentIdSetMap.getValue(entry.a).add(segmentId);
									entry.b = entry.b - currSegmentSize;
									snAvailableRamSizeMap.addAndGet(entry.a, -currSegmentSize);
									assignedFlag = true;

									BioMatcherNodeSegmentInfo bioMatcherNodeSegmentInfo = new BioMatcherNodeSegmentInfo();
									bioMatcherNodeSegmentInfo.setAssignedFlag(true);
									bioMatcherNodeSegmentInfo.setMatcherNodeId(entry.a);
									bioMatcherNodeSegmentInfo.setSegmentId(segmentId);
									bioMatcherNodeSegmentInfo.setSegmentVersion(-1L);
									bioMatcherNodeSegmentInfo.setUpdateDateTime(new Date());

									newBioMatcherNodeSegmentInfoList.add(bioMatcherNodeSegmentInfo);

									break;
								}
							}
						}

						if (!assignedFlag) {
							throw new BioMatcherConfigServiceException(
									"Unable to assign segment with size: " + currSegmentSize
											+ " due to ram size fragmentation for Search Node Group: " + snGroupId);
						}
					}
				}
			}

			logger.info("In autoCreateAndAssignSegments newBioMatcherSegmentInfoListSize: "
					+ newBioMatcherSegmentInfoList.size());
			for (BioMatcherSegmentInfo bioMatcherSegmentInfo : newBioMatcherSegmentInfoList) {
				bioMatcherConfigDao.saveEntity(bioMatcherSegmentInfo);
			}

			logger.info("In autoCreateAndAssignSegments newBiometricIdInfoListSize: " + newBiometricIdInfoList.size());
			for (BiometricIdInfo biometricIdInfo : newBiometricIdInfoList) {
				bioMatcherConfigDao.saveEntity(biometricIdInfo);
			}

			logger.info("In autoCreateAndAssignSegments newBioMatcherNodeSegmentInfoListSize: "
					+ newBioMatcherNodeSegmentInfoList.size());
			for (BioMatcherNodeSegmentInfo bioMatcherNodeSegmentInfo : newBioMatcherNodeSegmentInfoList) {
				bioMatcherConfigDao.saveEntity(bioMatcherNodeSegmentInfo);
			}
		} catch (Throwable th) {
			logger.error("Error in autoCreateAndAssignSegments binId: " + binId + ", totalRecords: " + totalRecords
					+ ", maxRecordsPerSegment: " + maxRecordsPerSegment + ", snRamSize: " + snRamSize
					+ ", segmentRedundancy: " + segmentRedundancy + ", assignedSearchNodes: "
					+ StringUtils.join(assignedSearchNodes, ",") + " : " + th.getMessage(), th);
		} finally {
			PFLogger.end("binId: " + binId + ", totalRecords: " + totalRecords + ", maxRecordsPerSegment: "
					+ maxRecordsPerSegment + ", snRamSize: " + snRamSize + ", segmentRedundancy: " + segmentRedundancy
					+ ", assignedSearchNodes: " + StringUtils.join(assignedSearchNodes, ","));
		}
	}

	public BioMatcherSegmentInfo deleteMatcherSegmentInfo(Integer segmentId) throws BioMatcherConfigServiceException {
		try {
			BioMatcherSegmentInfo bioMatcherSegmentInfo = bioMatcherConfigDao.getEntity(BioMatcherSegmentInfo.class,
					segmentId);
			if (bioMatcherSegmentInfo != null) {
				bioMatcherConfigDao.deleteEntity(bioMatcherSegmentInfo);
			}
			return bioMatcherSegmentInfo;
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in deleteMatcherSegmentInfo: " + th.getMessage(), th);
		}
	}

	public void saveMatcherNodeSegmentInfo(String searchNodeId, Integer segmentId, boolean assignedFlag,
			Long segmentVersion) throws BioMatcherConfigServiceException {
		logger.info("In saveMatcherNodeSegmentInfo: searchNodeId: " + searchNodeId + ", segmentId: " + segmentId
				+ ", assignedFlag: " + assignedFlag + ", segmentVersion: " + segmentVersion);
		try {
			BioMatcherNodeSegmentInfo bioMatcherNodeSegmentInfo = _this.getSearchNodeSegmentInfo(searchNodeId,
					segmentId);
			if (bioMatcherNodeSegmentInfo == null) {
				if (assignedFlag) {
					bioMatcherNodeSegmentInfo = new BioMatcherNodeSegmentInfo();
					bioMatcherNodeSegmentInfo.setAssignedFlag(assignedFlag);
					bioMatcherNodeSegmentInfo.setMatcherNodeId(searchNodeId);
					bioMatcherNodeSegmentInfo.setSegmentId(segmentId);
					bioMatcherNodeSegmentInfo.setSegmentVersion(segmentVersion == null ? -1L : segmentVersion);
					bioMatcherNodeSegmentInfo.setUpdateDateTime(new Date());
					bioMatcherConfigDao.saveEntity(bioMatcherNodeSegmentInfo);
				}
			} else {
				if (bioMatcherNodeSegmentInfo.getAssignedFlag().booleanValue() != assignedFlag
						|| segmentVersion != null) {
					bioMatcherNodeSegmentInfo.setAssignedFlag(assignedFlag);
					bioMatcherNodeSegmentInfo.setUpdateDateTime(new Date());

					if (segmentVersion != null) {
						bioMatcherNodeSegmentInfo.setSegmentVersion(segmentVersion);
					}

					bioMatcherConfigDao.updateEntity(bioMatcherNodeSegmentInfo);
				}
			}
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in saveMatcherSegmentInfo: " + th.getMessage(), th);
		}
	}

	public MeghaTemplateConfig getMeghaTemplateConfig() throws BioMatcherConfigServiceException {
		try {
			int userFlagByteCount = _this.getUserFlagByteCount();
			Map<String, Integer> featureTypeFeatureSizeMap = _this.getFeatureDataSizeMap();

			MeghaTemplateConfig meghaTemplateConfig = new MeghaTemplateConfig(userFlagByteCount,
					featureTypeFeatureSizeMap, getTemplateTypeMaxEventCountMap());

			CommonLogger.CONFIG_LOG.info("In getMeghaTemplateConfig: meghaTemplateConfig: "
					+ GsonSerializer.toPrettyJsonLog(meghaTemplateConfig));

			return meghaTemplateConfig;
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in getMeghaTemplateConfig : " + th.getMessage(), th);
		}
	}

	public Map<TemplateType, MeghaTemplateParser> getTemplateTypeMeghaTemplateParserMap()
			throws BioMatcherConfigServiceException {
		try {
			MeghaTemplateConfig meghaTemplateConfig = _this.getMeghaTemplateConfig();

			Map<TemplateType, MeghaTemplateParser> templateTypeMeghaTemplateParserMap = new HashMap<>();

			for (TemplateType templateType : meghaTemplateConfig.getTemplateTypeMaxEventCountMap().keySet()) {
				try {
					MeghaTemplateParser meghaTemplateParser = new MeghaTemplateParser(templateType,
							meghaTemplateConfig);
					templateTypeMeghaTemplateParserMap.put(templateType, meghaTemplateParser);
				} catch (Throwable th) {
					CommonLogger.CONFIG_LOG
							.error("In getMeghaTemplateParserMap: Error building MeghaTemplateParser for templateType: "
									+ templateType + " : " + th.getMessage(), th);
				}
			}

			CommonLogger.CONFIG_LOG
					.info("In getTemplateTypeMeghaTemplateParserMap: templateTypeMeghaTemplateParserMap: "
							+ GsonSerializer.toPrettyJsonLog(templateTypeMeghaTemplateParserMap.values()));

			return Collections.unmodifiableMap(templateTypeMeghaTemplateParserMap);
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException(
					"Error in getTemplateTypeMeghaTemplateParserMap : " + th.getMessage(), th);
		}
	}

	public Map<Integer, MeghaTemplateParser> getBinIdMeghaTemplateParserMap() throws BioMatcherConfigServiceException {
		try {
			Map<Integer, MeghaTemplateParser> binIdMeghaTemplateParserMap = new HashMap<>();

			List<BioMatcherBinInfo> matcherBinInfoList = _this.getMatcherBinInfoList();
			Map<TemplateType, MeghaTemplateParser> meghaTemplateParserMap = _this
					.getTemplateTypeMeghaTemplateParserMap();

			for (BioMatcherBinInfo matcherBinInfo : matcherBinInfoList) {
				try {
					TemplateType templateType = TemplateType.valueOf(matcherBinInfo.getTemplateType());
					MeghaTemplateParser meghaTemplateParser = meghaTemplateParserMap.get(templateType);
					if (meghaTemplateParser != null) {
						binIdMeghaTemplateParserMap.put(matcherBinInfo.getBinId(), meghaTemplateParser);
					} else {
						CommonLogger.CONFIG_LOG
								.error("In getBinIdMeghaTemplateParserMap: Unable to get MeghaTemplateParser for templateType: "
										+ matcherBinInfo.getTemplateType() + ", binId: " + matcherBinInfo.getBinId());
					}
				} catch (Throwable th) {
					CommonLogger.CONFIG_LOG
							.error("In getBinIdMeghaTemplateParserMap: Error getting MeghaTemplateParser for binId: "
									+ matcherBinInfo.getBinId() + ", templateType: " + matcherBinInfo.getTemplateType()
									+ " : " + th.getMessage(), th);
				}
			}

			return binIdMeghaTemplateParserMap;
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in getBinIdMeghaTemplateParserMap : " + th.getMessage(),
					th);
		}
	}

	public Map<Integer, Integer> getBinIdMaxEventCountMap() throws BioMatcherConfigServiceException {
		try {
			Map<Integer, Integer> binIdMaxEventCountMap = new HashMap<>();

			List<BioMatcherBinInfo> matcherBinInfoList = _this.getMatcherBinInfoList();
			MeghaTemplateConfig meghaTemplateConfig = _this.getMeghaTemplateConfig();

			for (BioMatcherBinInfo bioMatcherBinInfo : matcherBinInfoList) {
				try {
					TemplateType templateType = TemplateType.getByName(bioMatcherBinInfo.getTemplateType());
					if (templateType == null) {
						CommonLogger.CONFIG_LOG
								.error("In getBinIdMaxEventCountMap: Unable to get templateTypeCode for templateTypeKey: "
										+ bioMatcherBinInfo.getTemplateType() + ", binId: "
										+ bioMatcherBinInfo.getBinId());
					} else {
						int maxEventCount = meghaTemplateConfig.getMaxEventCount(templateType);
						binIdMaxEventCountMap.put(bioMatcherBinInfo.getBinId(), maxEventCount);
					}
				} catch (Throwable th) {
					CommonLogger.CONFIG_LOG
							.error("In getBinIdMaxEventCountMap: Unable to get templateTypeCode for templateTypeKey: "
									+ bioMatcherBinInfo.getTemplateType() + ", binId: " + bioMatcherBinInfo.getBinId()
									+ " : " + th.getMessage(), th);
				}
			}

			return Collections.unmodifiableMap(binIdMaxEventCountMap);
		} catch (BioMatcherConfigServiceException ex) {
			throw ex;
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in getBinIdMaxEventCountMap : " + th.getMessage(), th);
		}
	}

	public Map<Integer, Integer> getBinIdTemplateTypeCodeMap() throws BioMatcherConfigServiceException {
		try {
			Map<Integer, Integer> binIdTemplateTypeCodeMap = new HashMap<>();

			List<BioMatcherBinInfo> matcherBinInfoList = _this.getMatcherBinInfoList();

			for (BioMatcherBinInfo bioMatcherBinInfo : matcherBinInfoList) {
				Integer templateTypeCode = TemplateType.getTemplateTypeCodeByName(bioMatcherBinInfo.getTemplateType());
				if (templateTypeCode == null) {
					CommonLogger.CONFIG_LOG
							.error("In getBinIdTemplateTypeCodeMap: Unable to get templateTypeCode for templateTypeKey: "
									+ bioMatcherBinInfo.getTemplateType() + ", binId: " + bioMatcherBinInfo.getBinId());
				} else {
					binIdTemplateTypeCodeMap.put(bioMatcherBinInfo.getBinId(), templateTypeCode);
				}
			}

			return Collections.unmodifiableMap(binIdTemplateTypeCodeMap);
		} catch (BioMatcherConfigServiceException ex) {
			throw ex;
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in getBinIdTemplateTypeCodeMap : " + th.getMessage(), th);
		}
	}

	public Map<TemplateType, Set<AlgorithmType>> getTemplateTypeAlgorithmTypesMap()
			throws BioMatcherConfigServiceException {
		try {
			Map<TemplateType, Set<AlgorithmType>> templateTypeAlgorithmTypesMap = new HashMap<>();

			for (TemplateType templateType : TemplateType.values()) {
				try {
					templateTypeAlgorithmTypesMap.put(templateType, MeghaTemplateUtil.getAlgorithmTypes(templateType));
				} catch (Throwable th) {
					CommonLogger.CONFIG_LOG
							.error("In getTemplateTypeAlgorithmTypesMap: Unable to get algorithm types for templateType: "
									+ templateType.name() + " : " + th.getMessage(), th);
				}
			}

			return templateTypeAlgorithmTypesMap;
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in getTemplateTypeAlgorithmTypesMap : " + th.getMessage(),
					th);
		}
	}

	public int getUserFlagByteCount() throws BioMatcherConfigServiceException {
		try {
			int userFlagByteCount = bioParameterService.getParameterValue("USER_FLAG_BYTE_COUNT", "DEFAULT",128);
			CommonLogger.CONFIG_LOG.info("In getUserFlagByteCount: userFlagByteCount: " + userFlagByteCount);
			return userFlagByteCount;
		} catch (Throwable th) {
			// throw new BioMatcherConfigServiceException("Error in
			// getUserFlagByteCount : " + th.getMessage(), th);
			logger.warn(th.getMessage());
			return 8;
		}
	}

	public Map<String, Integer> getFeatureDataSizeMap() throws BioMatcherConfigServiceException {
		try {
			Map<String, String> featureDataSizeStrMap = bioParameterService.getPropertyMap("FEATURE_DATA_SIZE_MAP",
					"DEFAULT");
			HashMap<String, Integer> featureDataSizeMap = new HashMap<>();
			for (Entry<String, String> entry : featureDataSizeStrMap.entrySet()) {
				Integer featureDataSize = StringUtil.stringToInt(entry.getValue());
				if (featureDataSize == null) {
					CommonLogger.CONFIG_LOG
							.error("In getFeatureDataSizeMap: Invalid feature data size configured for featureDataType: "
									+ entry.getKey());
				}
				featureDataSizeMap.put(entry.getKey().toUpperCase(), featureDataSize);
			}
			return Collections.unmodifiableMap(featureDataSizeMap);
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in getFeatureDataSizeMap : " + th.getMessage(), th);
		}
	}

	public Map<TemplateType, Integer> getTemplateTypeMaxEventCountMap() throws BioMatcherConfigServiceException {
		try {
			Map<String, String> templateTypeMaxEventCountStrMap = bioParameterService
					.getPropertyMap("TEMPLATE_TYPE_MAX_EVENT_COUNT_MAP", "DEFAULT");

			HashMap<TemplateType, Integer> templateTypeMaxEventCountMap = new HashMap<>();

			for (TemplateType templateType : TemplateType.values()) {
				String maxEventCountStrValue = templateTypeMaxEventCountStrMap.get(templateType.name());
				Integer maxEventCount = StringUtil.stringToInt(maxEventCountStrValue);
				if (maxEventCount == null) {
					CommonLogger.CONFIG_LOG
							.error("In getTemplateTypeMaxEventCountMap: Invalid max event count configured for templateType: "
									+ templateType.name() + ", maxEventCount: " + maxEventCountStrValue
									+ ", will use default value 1");
					maxEventCount = 1;
				}
				templateTypeMaxEventCountMap.put(templateType, maxEventCount);
			}

			CommonLogger.CONFIG_LOG.info("In getTemplateTypeMaxEventCountMap: templateTypeMaxEventCountMap: "
					+ GsonSerializer.toPrettyJsonLog(templateTypeMaxEventCountMap));

			return Collections.unmodifiableMap(templateTypeMaxEventCountMap);
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in getTemplateTypeMaxEventCountMap : " + th.getMessage(),
					th);
		}
	}

	public Map<String, Integer> getFunctionCapacityMap() throws BioMatcherConfigServiceException {
		try {
			Map<String, String> functionCapacityStrMap = bioParameterService
					.getPropertyMap("MATCHER_FUNCTION_CAPACITY_MAP", "DEFAULT");
			HashMap<String, Integer> functionCapacityMap = new HashMap<>();
			for (Entry<String, String> entry : functionCapacityStrMap.entrySet()) {
				functionCapacityMap.put(entry.getKey().toUpperCase(), StringUtil.stringToInt(entry.getValue(), 50));
			}
			return Collections.unmodifiableMap(functionCapacityMap);
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in getFunctionCapacityMap : " + th.getMessage(), th);
		}
	}

	public Map<String, Integer> getSearchFunctionMaxMultiSegmentJobCountMap() throws BioMatcherConfigServiceException {
		try {
			Map<String, String> functionCapacityStrMap = bioParameterService
					.getPropertyMap("SEARCH_FUNCTION_MAX_MULTI_SEGMENT_JOB_COUNT_MAP", "DEFAULT");
			HashMap<String, Integer> searchFunctionMaxMultiSegmentJobCountMap = new HashMap<>();
			for (Entry<String, String> entry : functionCapacityStrMap.entrySet()) {
				searchFunctionMaxMultiSegmentJobCountMap.put(entry.getKey().toUpperCase(),
						StringUtil.stringToInt(entry.getValue(), 1));
			}
			return Collections.unmodifiableMap(searchFunctionMaxMultiSegmentJobCountMap);
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException(
					"Error in getSearchFunctionMaxMultiSegmentJobCountMap : " + th.getMessage(), th);
		}
	}

	public Map<String, Float> getSearchNodeFunctionCapacityOverloadFactorMap() throws BioMatcherConfigServiceException {
		try {
			Map<String, String> searchNodeFunctionCapacityOverloadFactorStrMap = bioParameterService
					.getPropertyMap("SEARCH_NODE_FUNCTION_CAPACITY_OVERLOAD_FACTOR_MAP", "DEFAULT");
			HashMap<String, Float> searchNodeFunctionCapacityOverloadFactorMap = new HashMap<>();
			for (Entry<String, String> entry : searchNodeFunctionCapacityOverloadFactorStrMap.entrySet()) {
				searchNodeFunctionCapacityOverloadFactorMap.put(entry.getKey().toUpperCase(),
						StringUtil.stringToFloat(entry.getValue(), 1.3f));
			}
			return Collections.unmodifiableMap(searchNodeFunctionCapacityOverloadFactorMap);
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException(
					"Error in getSearchNodeFunctionCapacityOverloadFactorMap : " + th.getMessage(), th);
		}
	}

	private void saveMatcherFunctionCapacityMap() throws BioMatcherConfigServiceException {
		try {
			Set<String> keysToBeRemoved = Sets.newHashSet("ENROLL");

			Map<String, String> propertyMap = new HashMap<>();
			propertyMap.put("EXTRACT", "50");
			propertyMap.put("VERIFY", "100");
			propertyMap.put("FI", "100");
			propertyMap.put("II", "100");
			propertyMap.put("TI", "100");
			propertyMap.put("TLI", "20");
			propertyMap.put("LI", "20");
			propertyMap.put("LLI", "20");
			propertyMap.put("LIP", "20");
			propertyMap.put("LLIP", "20");
			propertyMap.put("TLIP", "20");
			bioParameterService.mergePropertyMap("MATCHER_FUNCTION_CAPACITY_MAP", "DEFAULT", propertyMap,
					keysToBeRemoved, "FunctionId and Max job count map");
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in saveMatcherFunctionCapacityMap : " + th.getMessage(),
					th);
		}
	}

	private void saveSearchFunctionMaxMultiSegmentJobCountMap() throws BioMatcherConfigServiceException {
		try {

			bioParameterService.deleteParameterLike("MULTI_SEGMENTS_PER_SEARCH_JOB", "DEFAULT");
			bioParameterService.deleteParameterLike("MAX_MULTI_SEGMENTS_PER_SEARCH_JOB", "DEFAULT");

			Map<String, String> currentPropertyMap = bioParameterService
					.getPropertyMap("SEARCH_FUNCTION_MAX_MULTI_SEGMENT_JOB_COUNT_MAP", "DEFAULT");

			Set<String> keysToBeRemoved = Sets.newHashSet("FI", "II", "TI", "TLI", "LI", "LLI", "LIP", "LLIP", "TLIP");

			Map<String, String> propertyMap = new HashMap<>();
			propertyMap.put("FI~0", currentPropertyMap.getOrDefault("FI", "1"));
			propertyMap.put("II~0", currentPropertyMap.getOrDefault("II", "1"));
			propertyMap.put("TI~0", currentPropertyMap.getOrDefault("TI", "1"));
			propertyMap.put("TLI~0", currentPropertyMap.getOrDefault("TLI", "1"));
			propertyMap.put("LI~0", currentPropertyMap.getOrDefault("LI", "1"));
			propertyMap.put("LLI~0", currentPropertyMap.getOrDefault("LLI", "1"));
			propertyMap.put("LIP~0", currentPropertyMap.getOrDefault("LIP", "1"));
			propertyMap.put("LLIP~0", currentPropertyMap.getOrDefault("LLIP", "1"));
			propertyMap.put("TLIP~0", currentPropertyMap.getOrDefault("TLIP", "1"));
			bioParameterService.mergePropertyMap("SEARCH_FUNCTION_MAX_MULTI_SEGMENT_JOB_COUNT_MAP", "DEFAULT",
					propertyMap, keysToBeRemoved,
					"Max multi segment job count map, Key format is FunctionId~CapacityGroupKey");
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException(
					"Error in saveSearchFunctionMaxMultiSegmentJobCountMap : " + th.getMessage(), th);
		}
	}

	private void saveSearchNodeFunctionCapacityOverloadFactorMap() throws BioMatcherConfigServiceException {
		try {
			String searchNodeJobOverloadFactor = bioParameterService
					.getParameterValue("SEARCH_NODE_JOB_OVERLOAD_FACTOR_0", "DEFAULT");
			if (StringUtils.isBlank(searchNodeJobOverloadFactor)) {
				searchNodeJobOverloadFactor = "1.3";
			} else {
				bioParameterService.deleteParameterLike("SEARCH_NODE_JOB_OVERLOAD_FACTOR", "DEFAULT");
			}

			Map<String, String> propertyMap = new HashMap<>();
			propertyMap.put("0", searchNodeJobOverloadFactor);
			propertyMap.put("FI~0", searchNodeJobOverloadFactor);
			propertyMap.put("II~0", searchNodeJobOverloadFactor);
			propertyMap.put("TI~0", searchNodeJobOverloadFactor);
			propertyMap.put("TLI~0", searchNodeJobOverloadFactor);
			propertyMap.put("LI~0", searchNodeJobOverloadFactor);
			propertyMap.put("LLI~0", searchNodeJobOverloadFactor);
			propertyMap.put("LIP~0", searchNodeJobOverloadFactor);
			propertyMap.put("LLIP~0", searchNodeJobOverloadFactor);
			propertyMap.put("TLIP~0", searchNodeJobOverloadFactor);
			bioParameterService.mergePropertyMap("SEARCH_NODE_FUNCTION_CAPACITY_OVERLOAD_FACTOR_MAP", "DEFAULT",
					propertyMap, Collections.emptySet(),
					"Search node job overload factor map, Key format is FunctionId~CapacityGroupKey");
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException(
					"Error in saveSearchNodeFunctionCapacityOverloadFactorMap : " + th.getMessage(), th);
		}
	}

	private void saveDefaultFeatureDataSizeMap() throws BioMatcherConfigServiceException {
		try {
			Map<String, String> propertyMap = new HashMap<>();
			propertyMap.put("FACE_NEC_S17_FEATURE_DATA_SIZE", "2544");
			propertyMap.put("FACE_NEC_S18_FEATURE_DATA_SIZE", "3072");
			propertyMap.put("FACE_NEC_NFV2_FEATURE_DATA_SIZE", "2620");
			propertyMap.put("FACE_NEC_NFG2_FEATURE_DATA_SIZE", "2620");
			propertyMap.put("FACE_NEC_NFV3_FEATURE_DATA_SIZE", "2152"); 

			propertyMap.put("IRIS_NEC_FEATURE_DATA_SIZE", "1760");
			propertyMap.put("IRIS_DELTA_ID_FEATURE_DATA_SIZE", "2048");
			propertyMap.put("IRIS_DELTA_ID_DESERIALIZED_FEATURE_DATA_SIZE", "3200");
			propertyMap.put("FINGER_RDBL_SDBL_FEATURE_DATA_SIZE", "4096");
			propertyMap.put("LATENT_FINGER_LDB_FEATURE_DATA_SIZE", "4096");

			propertyMap.put("FINGER_CMLAF_FEATURE_DATA_SIZE", "16000");
			propertyMap.put("FINGER_CML_FEATURE_DATA_SIZE", "25500");
			propertyMap.put("FINGER_LFML_FEATURE_DATA_SIZE", "4928");

			propertyMap.put("LATENT_FINGER_LFML_FEATURE_DATA_SIZE", "27648");
			propertyMap.put("PALM_PC3_FULL_FEATURE_DATA_SIZE", "74752");
			propertyMap.put("PALM_PC3_FRONT_FEATURE_DATA_SIZE", "51200");
			propertyMap.put("PALM_PC3_LEGACY_FEATURE_DATA_SIZE", "20480");
			propertyMap.put("PALM_PC3_WRITERS_FEATURE_DATA_SIZE", "20480");
			propertyMap.put("LATENT_PALM_PC3_FEATURE_DATA_SIZE", "4096");

			propertyMap.put("PALM_LFML_FULL_FEATURE_DATA_SIZE", "62000");
			propertyMap.put("PALM_LFML_SPLIT_FEATURE_DATA_SIZE", "60000");
			propertyMap.put("PALM_LFML_LEGACY_FEATURE_DATA_SIZE", "30720");
			propertyMap.put("PALM_LFML_WRITERS_FEATURE_DATA_SIZE", "35500");
			propertyMap.put("LATENT_PALM_LFML_FEATURE_DATA_SIZE", "195000");

			bioParameterService.mergePropertyMap("FEATURE_DATA_SIZE_MAP", "DEFAULT", propertyMap,
					Collections.emptySet(), "Feature data size map");
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in saveDefaultFeatureDataSizeMap : " + th.getMessage(),
					th);
		}
	}

	//

	private void saveDefaultTemplateTypeMaxEventCountMap() throws BioMatcherConfigServiceException {
		try {

			Map<String, String> propertyMap = Arrays.stream(TemplateType.values())
					.collect(Collectors.toMap(TemplateType::name, (p) -> "1"));

			bioParameterService.mergePropertyMap("TEMPLATE_TYPE_MAX_EVENT_COUNT_MAP", "DEFAULT", propertyMap,
					Collections.emptySet(), "Template type max event count map");
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException(
					"Error in saveDefaultTemplateTypeMaxEventCountMap : " + th.getMessage(), th);
		}
	}

	public void clearCache() {
		logger.info("In BioMatcherConfigServiceImpl.clearCache");
	}

	public void setBioMatcherConfigDao(BioMatcherConfigDao bioMatcherConfigDao) {
		this.bioMatcherConfigDao = bioMatcherConfigDao;
	}

	public void setBioLockingService(BioLockingService bioLockingService) {
		this.bioLockingService = bioLockingService;
	}

	@Override
	public void assignSelf(Object self) throws Exception {
		logger.info("In BioMatcherConfigServiceImpl.assignSelf");
		_this = (BioMatcherConfigService) self;

		TemplateDefinationPatch templateDefinationPatch = new TemplateDefinationPatch();
		templateDefinationPatch.transformTemplateDefination(bioParameterService);

		getUserFlagByteCount();

		saveDefaultTemplateTypeMaxEventCountMap();

		saveMatcherFunctionCapacityMap();

		saveSearchFunctionMaxMultiSegmentJobCountMap();

		saveSearchNodeFunctionCapacityOverloadFactorMap();

		saveDefaultFeatureDataSizeMap();
	}

	public void setBioParameterService(BioParameterService bioParameterService) {
		this.bioParameterService = bioParameterService;
	}

	public List<BioServerInfo> getServerInfoListByServerType(BioServerType serverType, BioComponentType componentType)
			throws BioMatcherConfigServiceException {
		try {
			return bioMatcherConfigDao.getEntityListByFields(BioServerInfo.class, "serverType", serverType,
					"componentType", componentType);
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in getServerInfoByServerType: " + th.getMessage(), th);
		}
	}

	public Map<Integer, Integer> getBinIdTemplateDataSizeMap() throws BioMatcherConfigServiceException {
		try {
			Map<Integer, Integer> binIdTemplateDataSizeMap = new HashMap<>();

			MeghaTemplateConfig meghaTemplateConfig = _this.getMeghaTemplateConfig();
			Map<Integer, Integer> binIdMaxEventCountMap = _this.getBinIdMaxEventCountMap();
			List<BioMatcherBinInfo> matcherBinInfoList = _this.getMatcherBinInfoList();
			for (BioMatcherBinInfo bioMatcherBinInfo : matcherBinInfoList) {
				try {
					TemplateType templateType = TemplateType.getByName(bioMatcherBinInfo.getTemplateType());
					if (templateType == null) {
						CommonLogger.CONFIG_LOG.error("In getBinIdTemplateDataSizeMap: Invalid templateType("
								+ bioMatcherBinInfo.getTemplateType() + ") configured for binId: "
								+ bioMatcherBinInfo.getBinId());
						continue;
					}
					Integer maxEventCount = binIdMaxEventCountMap.getOrDefault(bioMatcherBinInfo.getBinId(), 1);

					int templateDataSize = MeghaTemplateUtil.getTemplateSize(templateType, maxEventCount,
							meghaTemplateConfig);

					binIdTemplateDataSizeMap.put(bioMatcherBinInfo.getBinId(), templateDataSize);
				} catch (Throwable th) {
					CommonLogger.CONFIG_LOG.error("In getBinIdTemplateDataSizeMap: for binId: "
							+ bioMatcherBinInfo.getBinId() + ", templateType: " + bioMatcherBinInfo.getTemplateType()
							+ " : " + th.getMessage(), th);
				}
			}

			CommonLogger.CONFIG_LOG.info("In getBinIdTemplateDataSizeMap: binIdTemplateDataSizeMap: "
					+ GsonSerializer.toPrettyJsonLog(binIdTemplateDataSizeMap));

			return Collections.unmodifiableMap(binIdTemplateDataSizeMap);
		} catch (Throwable th) {
			throw new BioMatcherConfigServiceException("Error in getBinIdTemplateDataSizeMap : " + th.getMessage(), th);
		}
	}

}
