package com.nec.biomatcher.comp.cluster;

import java.net.InetSocketAddress;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

import com.hazelcast.config.Config;
import com.hazelcast.config.JoinConfig;
import com.hazelcast.config.NetworkConfig;
import com.hazelcast.config.TcpIpConfig;
import com.hazelcast.core.Hazelcast;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.core.ITopic;
import com.hazelcast.core.MemberAttributeEvent;
import com.hazelcast.core.MembershipEvent;
import com.hazelcast.core.MembershipListener;
import com.hazelcast.core.Message;
import com.hazelcast.core.MessageListener;
import com.nec.biomatcher.comp.cluster.handlers.SystemHandlers;
import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.config.BioMatcherConfigService;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioServerType;
import com.nec.biomatcher.core.framework.common.HostnameUtil;
import com.nec.biomatcher.core.framework.common.exception.CoreException;

public class HazelcastAdminCluster implements MembershipListener, DisposableBean, InitializingBean {
	private static final Logger logger = Logger.getLogger(HazelcastAdminCluster.class);

	private BioParameterService bioParameterService;
	private BioMatcherConfigService bioMatcherConfigService;

	private HazelcastInstance hazelcastInstance;

	private static AtomicInteger initializationCount = new AtomicInteger();
	private static final ConcurrentHashMap<String, ClusterEventHandler> eventTypeHandlerMap = new ConcurrentHashMap<>();

	private ITopic<ClusterEvent> clusterEventTopic = null;

	private String currentServerHost = HostnameUtil.getHostname();

	private ClusterInstance clusterInstance;

	public static void registerClusterEventHandler(String eventType, ClusterEventHandler clusterEventHandler) {
		eventTypeHandlerMap.put(eventType, clusterEventHandler);
	}

	private void buildAdminCluster() throws Exception {
		logger.info("In buildAdminCluster");
		try {
			Set<String> serverHostSet = bioMatcherConfigService.getServerHostnameSet(BioServerType.MANAGER);

			final Set<String> currentHostnameIpAddressList = HostnameUtil.getHostnameIpAddressList();

			for (String serverHost : serverHostSet) {
				if (currentHostnameIpAddressList.contains(serverHost)) {
					currentServerHost = serverHost;
				}
			}

			int adminClusterPort = bioParameterService.getParameterValue("ADMIN_CLUSTER_PORT", "DEFAULT", 5050);

			String clusterInstanceId = "MEGHA_ADMIN_CLUSTER";

			HazelcastInstance currentHazelcastInstance = Hazelcast.getHazelcastInstanceByName(clusterInstanceId);
			if (currentHazelcastInstance != null) {
				currentHazelcastInstance.shutdown();
			}

			Config config = new Config(clusterInstanceId);
			config.getGroupConfig().setName(clusterInstanceId).setPassword("nec");

			config.setProperty("hazelcast.shutdownhook.enabled", "true");

			NetworkConfig network = config.getNetworkConfig();

			network.setPort(adminClusterPort);
			network.setPortAutoIncrement(false);
			network.setReuseAddress(true);

			// TODO: Need to check weather we need to set it
			// network.setPublicAddress(publicAddress);

			network.setPublicAddress(currentServerHost);

			JoinConfig join = network.getJoin();
			join.getMulticastConfig().setEnabled(false);
			TcpIpConfig tcpIpConfig = join.getTcpIpConfig();

			Set<String> addedServerHostSet = new HashSet<>();

			for (String serverHost : serverHostSet) {
				if (addedServerHostSet.contains(serverHost)) {
					continue;
				}
				addedServerHostSet.add(serverHost);

				String ipAddress = HostnameUtil.getIpAddress(serverHost);
				logger.info("Adding serverHost: " + serverHost + " with ipAddress: " + ipAddress + " to Admin Cluster");

				tcpIpConfig.addMember(ipAddress);
			}

			tcpIpConfig.setEnabled(true);

			network.getInterfaces().setEnabled(true).addInterface("*.*.*.*");

			hazelcastInstance = Hazelcast.getOrCreateHazelcastInstance(config);

			clusterInstance = new ClusterInstance(hazelcastInstance);

			logger.info("Admin cluster current members: " + hazelcastInstance.getCluster().getMembers().size());

			hazelcastInstance.getCluster().addMembershipListener(this);

			clusterEventTopic = hazelcastInstance.getTopic("AdminClusterEventTopic");

			clusterEventTopic.addMessageListener(new MessageListener<ClusterEvent>() {
				@Override
				public void onMessage(Message<ClusterEvent> message) {
					ClusterEvent clusterEvent = message.getMessageObject();
					if (clusterEvent == null) {
						logger.error("Error in AdminCluster: clusterEvent is null for message from: "
								+ message.getPublishingMember().getSocketAddress().toString());
						return;
					}
					if (StringUtils.isNotBlank(clusterEvent.getTargetServerHostname())
							&& !currentHostnameIpAddressList.contains(clusterEvent.getTargetServerHostname())) {
						logger.debug("Ignoring the clusterEvent as it is ment for other TargetServerHostname: "
								+ clusterEvent.getTargetServerHostname());
						return;
					}

					handleClusterEvent(message.getMessageObject());
				}
			});

			logger.info("In buildAdminCluster: hazelcastInstance created successfully for currentServerHost: "
					+ currentServerHost);
		} catch (Throwable th) {
			logger.error("Error in buildAdminCluster : " + th.getMessage(), th);
			throw new CoreException("Error in buildAdminCluster : " + th.getMessage(), th);
		}
	}

	public void notifyClusterEvent(ClusterEvent clusterEvent) {
		clusterEventTopic.publish(clusterEvent);
	}

	private void handleClusterEvent(ClusterEvent clusterEvent) {
		try {
			ClusterEventHandler clusterEventHandler = eventTypeHandlerMap.get(clusterEvent.getEventType());
			if (clusterEventHandler == null) {
				logger.error("In AdminCluster: clusterEventHandler is not configured for eventType: "
						+ clusterEvent.getEventType());
				return;
			}

			clusterEventHandler.handleEvent(clusterEvent);
		} catch (Throwable th) {
			logger.error("Error handeling clusterEvent from eventSource: " + clusterEvent.getEventSource()
					+ ", eventType: " + clusterEvent.getEventType() + " : " + th.getMessage(), th);
		}
	}

	@Override
	public void memberAdded(MembershipEvent membershipEvent) {
		InetSocketAddress socketAddress = membershipEvent.getMember().getSocketAddress();
		logger.info("In memberAdded: " + membershipEvent.getEventType() + ", SocketAddress: "
				+ membershipEvent.getMember().getSocketAddress() + ", memberHostname: " + socketAddress.getHostName()
				+ ", memberIpAddress: " + socketAddress.getAddress().getHostAddress());
	}

	@Override
	public void memberRemoved(MembershipEvent membershipEvent) {
		InetSocketAddress socketAddress = membershipEvent.getMember().getSocketAddress();
		logger.info("In memberRemoved: " + membershipEvent.getEventType() + ", SocketAddress: "
				+ membershipEvent.getMember().getSocketAddress() + ", memberHostname: " + socketAddress.getHostName()
				+ ", memberIpAddress: " + socketAddress.getAddress().getHostAddress());
	}

	@Override
	public void memberAttributeChanged(MemberAttributeEvent memberAttributeEvent) {
		logger.info("In memberAttributeChanged: " + memberAttributeEvent.getEventType() + ", SocketAddress: "
				+ memberAttributeEvent.getMember().getSocketAddress() + ", key: " + memberAttributeEvent.getKey()
				+ ", value: " + memberAttributeEvent.getValue());
	}

	@Override
	public void destroy() throws Exception {
		logger.info("In HazelcastAdminCluster.destroy");

		initializationCount.set(0);

		if (hazelcastInstance != null) {
			logger.info("In HazelcastAdminCluster.destroy before shutting down hazelcastInstance");
			hazelcastInstance.shutdown();
			hazelcastInstance = null;
			logger.info("In HazelcastAdminCluster.destroy after shutting down hazelcastInstance");
		}
	}

	@Override
	protected void finalize() throws Throwable {
		try {
			destroy();
		} finally {
			super.finalize();
		}
	}

	public HazelcastInstance getHazelcastInstance() {
		return hazelcastInstance;
	}

	public void setBioParameterService(BioParameterService bioParameterService) {
		this.bioParameterService = bioParameterService;
	}

	public void setBioMatcherConfigService(BioMatcherConfigService bioMatcherConfigService) {
		this.bioMatcherConfigService = bioMatcherConfigService;
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		logger.info("In HazelcastAdminCluster.afterPropertiesSet");
		synchronized (HazelcastAdminCluster.class) {
			if (initializationCount.get() > 0) {
				return;
			}

			initializationCount.incrementAndGet();

			SystemHandlers.registerDefaultHandlers();

			buildAdminCluster();
		}
	}

	public ClusterInstance getClusterInstance() {
		return clusterInstance;
	}

}
