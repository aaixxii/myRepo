package com.nec.biomatcher.comp.matcher.node;

import java.util.Base64;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import org.apache.log4j.Logger;

import com.google.common.util.concurrent.AtomicLongMap;
import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.config.BioMatcherConfigService;
import com.nec.biomatcher.comp.entities.dataAccess.BioServerInfo;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioConnectionType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioProtocolType;
import com.nec.biomatcher.comp.matcher.node.exception.BioMatcherNodeClientException;
import com.nec.biomatcher.comp.metrics.MetricsUtil;
import com.nec.biomatcher.comp.zmq.ZmqSendReceiveConnection;
import com.nec.biomatcher.core.framework.common.CommonLogger;
import com.nec.megha.proto.mgmt.CapacityProto.Capacity;

public class MatcherNodeStatusCheckHelper {
	private static final Logger logger = Logger.getLogger(MatcherNodeStatusCheckHelper.class);

	private static final AtomicLongMap<String> lastServerConnectionTimestampMap = AtomicLongMap.create();

	private static final ConcurrentHashMap<String, ReadWriteLock> idleCheckLockMap = new ConcurrentHashMap<>();
	private static final ConcurrentHashMap<String, ReadWriteLock> statusCheckLockMap = new ConcurrentHashMap<>();
	private static final ConcurrentHashMap<String, Boolean> matcherNodeStatusMap = new ConcurrentHashMap<>();

	/** The bio matcher config service. */
	private BioMatcherConfigService bioMatcherConfigService;

	/** The bio parameter service. */
	private BioParameterService bioParameterService;

	public void notifyOffline(String serverId) {
		matcherNodeStatusMap.put(serverId, false);
	}

	public void notifyLastServerConnection(String serverId) {
		lastServerConnectionTimestampMap.put(serverId, System.currentTimeMillis());
	}

	/**
	 * Checks the server state, if its idle
	 * 
	 * @param serverId
	 * @param timeoutMilli
	 * @return returns cached server state
	 */
	public boolean checkIdleServer(String serverId) {
		long idleServerCheckDelayMilli = bioParameterService.getParameterValue("IDLE_SERVER_CHECK_DELAY_MILLI",
				"DEFAULT", TimeUnit.MINUTES.toMillis(2));
		long previousServerConnectionMilli = lastServerConnectionTimestampMap.get(serverId);
		boolean isOnline = matcherNodeStatusMap.getOrDefault(serverId, false);
		if (!isOnline || idleServerCheckDelayMilli < (System.currentTimeMillis() - previousServerConnectionMilli)) {
			ReadWriteLock rwLock = getIdleCheckLock(serverId);
			if (rwLock.writeLock().tryLock()) {
				try {
					isOnline = matcherNodeStatusMap.getOrDefault(serverId, false);
					if (!isOnline || idleServerCheckDelayMilli < (System.currentTimeMillis()
							- lastServerConnectionTimestampMap.get(serverId))) {
						logger.info(
								"Performing sendServerCapacity due to exceeded idleServerCheckDelayMilli for serverId: "
										+ serverId);
						isOnline = sendServerCapacity(serverId);
						CommonLogger.STATUS_LOG.info("In MatcherNodeStatusCheckHelper.checkIdleServer: serverId: "
								+ serverId + " is " + (isOnline ? "online" : "offline")
								+ ", previousConnectionTimestampMilli: " + previousServerConnectionMilli
								+ ", currentTimestampMilli: " + System.currentTimeMillis());
						return isOnline;
					}
				} finally {
					rwLock.writeLock().unlock();
				}
			} else {
				rwLock.readLock().lock();
				try {
					return matcherNodeStatusMap.getOrDefault(serverId, false);
				} finally {
					rwLock.readLock().unlock();
				}
			}
		}

		return matcherNodeStatusMap.getOrDefault(serverId, false);
	}

	public boolean sendServerCapacity(String serverId) {
		ReadWriteLock rwLock = getStatusCheckLock(serverId);
		if (rwLock.writeLock().tryLock()) {
			boolean successFlag = false;
			try {
				successFlag = sendServerCapacityInternal(serverId);

				return successFlag;
			} finally {
				matcherNodeStatusMap.put(serverId, successFlag);
				rwLock.writeLock().unlock();
			}
		} else {
			rwLock.readLock().lock();
			try {
				return matcherNodeStatusMap.getOrDefault(serverId, false);
			} finally {
				rwLock.readLock().unlock();
			}
		}
	}

	public boolean sendServerCapacityInternal(String serverId) {
		boolean successFlag = false;
		long serverCapacityCheckTimeoutMilli = TimeUnit.SECONDS.toMillis(1);

		boolean isFirstCheck = false;
		Boolean previousStatus = matcherNodeStatusMap.get(serverId);
		if (previousStatus == null) {
			previousStatus = false;
			isFirstCheck = true;
		}

		long startTimestampMilli = System.currentTimeMillis();
		try {
			BioServerInfo bioServerInfo = bioMatcherConfigService.getServerInfo(serverId);

			serverCapacityCheckTimeoutMilli = bioParameterService.getParameterValue(
					bioServerInfo.getComponentType().name() + "_SEND_SERVER_CAPACITY_TIMEOUT_MILLI", "DEFAULT",
					serverCapacityCheckTimeoutMilli);

			MetricsUtil.meter(bioServerInfo.getComponentType(), serverId, "STATUS_CHECK");

			MetricsUtil.setCounterValue(bioServerInfo.getComponentType(), serverId, "CONFIG_CAPACITY",
					bioServerInfo.getMaxJobCount());

			if (bioServerInfo.getMaxJobCount() <= 0) {
				logger.info("In sendServerCapacityInternal: Treating matcher node as offline for serverId: " + serverId
						+ ", MaxJobCount: " + bioServerInfo.getMaxJobCount());
				successFlag = false;
				return successFlag;
			}

			Capacity capacityRequest = buildCapacityProto(bioServerInfo.getMaxJobCount(), serverId);

			String connectionUrl = bioMatcherConfigService.getServerConnectionUrl(serverId,
					bioServerInfo.getComponentType(), BioConnectionType.ADMIN, BioProtocolType.ZEROMQ);

			byte[] responsePayload = ZmqSendReceiveConnection.sendReceiveMessage(serverId, connectionUrl,
					capacityRequest.toByteArray(), serverCapacityCheckTimeoutMilli);

			Capacity capacityResponse = null;
			try {
				capacityResponse = Capacity.parseFrom(responsePayload);

				if (CommonLogger.PAYLOAD_LOG.isDebugEnabled()) {
					CommonLogger.PAYLOAD_LOG.debug("In sendServerCapacityInternal: serverId: " + serverId
							+ ", componentType: " + bioServerInfo.getComponentType().name() + ", capacityRequest: "
							+ capacityRequest.toString() + ": capacityResponse: " + capacityResponse.toString());
				}
			} catch (Throwable th) {
				th = new BioMatcherNodeClientException(
						"Error parsing Capacity response from serverId: " + serverId + " : " + th.getMessage(), th);
				CommonLogger.PAYLOAD_LOG.error(
						"Response parsing error for serverId: " + serverId + ", componentType: "
								+ bioServerInfo.getComponentType().name() + ", errorMsg: " + th.getMessage()
								+ ", responsePayload: [" + Base64.getEncoder().encodeToString(responsePayload) + "]",
						th);
				throw th;
			}

			MetricsUtil.setCounterValue(bioServerInfo.getComponentType(), serverId, "ACTUAL_CAPACITY",
					capacityResponse.getCapacity());

			if (capacityResponse.getCapacity() == 0
					|| capacityResponse.getCapacity() != bioServerInfo.getMaxJobCount().intValue()) {
				CommonLogger.CONFIG_LOG.warn("Capacity mismatch between serverId: " + serverId + ", componentType: "
						+ bioServerInfo.getComponentType().name() + " and configuration : configuredMaxJobCount: "
						+ bioServerInfo.getMaxJobCount() + ", capacityResponse: " + capacityResponse.getCapacity());
			} else {
				CommonLogger.CONFIG_LOG.info("In sendServerCapacityInternal for serverId: " + serverId
						+ ", componentType: " + bioServerInfo.getComponentType().name() + ", configuredMaxJobCount: "
						+ bioServerInfo.getMaxJobCount() + ", capacityResponse: " + capacityResponse.getCapacity());
			}

			successFlag = capacityResponse.getCapacity() > 0;
		} catch (Throwable th) {
			if (isFirstCheck || previousStatus.booleanValue() == true || logger.isDebugEnabled()) {
				logger.error("Error in sendServerCapacityInternal: serverId: " + serverId
						+ ", serverCapacityCheckTimeoutMilli: " + serverCapacityCheckTimeoutMilli + " : "
						+ th.getMessage(), th);
			}
		} finally {
			lastServerConnectionTimestampMap.put(serverId, System.currentTimeMillis());

			long timeTakenMilli = System.currentTimeMillis() - startTimestampMilli;

			if (isFirstCheck || previousStatus.booleanValue() == true || logger.isDebugEnabled()) {
				CommonLogger.PERF_LOG.info("In sendServerCapacityInternal: TimeTakenMilli: " + timeTakenMilli
						+ ", serverId: " + serverId + ", serverCapacityCheckTimeoutMilli: "
						+ serverCapacityCheckTimeoutMilli + ", successFlag: " + successFlag);
			}
		}

		return successFlag;
	}

	public static final Capacity buildCapacityProto(int maxJobCount, String serverId) {
		Capacity.Builder builder = Capacity.newBuilder();
		builder.setCapacity(maxJobCount);
		builder.setInstanceId(serverId);
		Capacity capacity = builder.build();
		return capacity;
	}

	private ReadWriteLock getIdleCheckLock(String serverId) {
		ReadWriteLock rwLock = idleCheckLockMap.get(serverId);
		if (rwLock == null) {
			rwLock = idleCheckLockMap.computeIfAbsent(serverId, (newServerId) -> new ReentrantReadWriteLock());
		}
		return rwLock;
	}

	private ReadWriteLock getStatusCheckLock(String serverId) {
		ReadWriteLock rwLock = statusCheckLockMap.get(serverId);
		if (rwLock == null) {
			rwLock = statusCheckLockMap.computeIfAbsent(serverId, (newServerId) -> new ReentrantReadWriteLock());
		}
		return rwLock;
	}

	public void setBioMatcherConfigService(BioMatcherConfigService bioMatcherConfigService) {
		this.bioMatcherConfigService = bioMatcherConfigService;
	}

	public void setBioParameterService(BioParameterService bioParameterService) {
		this.bioParameterService = bioParameterService;
	}
}
