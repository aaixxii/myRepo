package com.nec.biomatcher.comp.common.query;

import com.nec.biomatcher.comp.common.query.criteria.CriteriaDto;

/**
 * This criteria dto is used internally to hold transformed criteria from field
 * values to UserTypes.
 *
 * @author Mahesh
 */
public class UserTypeCriteria extends CriteriaDto {

	/** The main criteria. */
	private CriteriaDto mainCriteria;

	/** The value. */
	private Object value;

	/**
	 * Instantiates a new user type criteria.
	 */
	public UserTypeCriteria() {

	}

	/**
	 * Instantiates a new user type criteria.
	 *
	 * @param value
	 *            the value
	 * @param mainCriteria
	 *            the main criteria
	 */
	public UserTypeCriteria(Object value, CriteriaDto mainCriteria) {
		this.value = value;
		this.mainCriteria = mainCriteria;
	}

	/**
	 * Gets the main criteria.
	 *
	 * @return the mainCriteria
	 */
	public CriteriaDto getMainCriteria() {
		return mainCriteria;
	}

	/**
	 * Sets the main criteria.
	 *
	 * @param mainCriteria
	 *            the mainCriteria to set
	 */
	public void setMainCriteria(CriteriaDto mainCriteria) {
		this.mainCriteria = mainCriteria;
	}

	/**
	 * Gets the value.
	 *
	 * @return the value
	 */
	public Object getValue() {
		return value;
	}

	/**
	 * Sets the value.
	 *
	 * @param value
	 *            the value to set
	 */
	public void setValue(Object value) {
		this.value = value;
	}
}
