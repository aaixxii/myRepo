package com.nec.biomatcher.comp.common.sequence.dataAccess.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.LockOptions;
import org.hibernate.Query;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import com.nec.biomatcher.comp.common.sequence.dataAccess.BioSequenceGeneratorDao;
import com.nec.biomatcher.comp.common.sequence.dataAccess.BioSequenceNumber;
import com.nec.biomatcher.core.framework.common.pagination.PageRequest;
import com.nec.biomatcher.core.framework.common.pagination.PageResult;
import com.nec.biomatcher.core.framework.dataAccess.AbstractHibernateDao;
import com.nec.biomatcher.core.framework.dataAccess.DaoException;

/**
 * The Class BioSequenceGeneratorHibernateImpl.
 */
public class BioSequenceGeneratorHibernateImpl extends AbstractHibernateDao implements BioSequenceGeneratorDao {

	@Override
	public void create(BioSequenceNumber sequenceNumber) throws DaoException {
		try {
			this.saveOrUpdateEntity(sequenceNumber);
		} catch (HibernateException e) {
			throw new DaoException(e);
		}
	}

	@Override
	public void delete(BioSequenceNumber sequenceNumber) throws DaoException {
		try {
			this.deleteEntity(sequenceNumber);
		} catch (HibernateException e) {
			throw new DaoException(e);
		}
	}

	@Override
	public BioSequenceNumber getSeqenceNumber(String name, String group) throws DaoException {
		try {
			DetachedCriteria criteria = DetachedCriteria.forClass(BioSequenceNumber.class)
					.add(Restrictions.eq("name", name)).add(Restrictions.eq("group", group));
			BioSequenceNumber sequenceNumber = getEntity(criteria);

			return sequenceNumber;
		} catch (HibernateException e) {
			throw new DaoException(e);
		}
	}

	public BioSequenceNumber getSeqenceNumberForUpdate(String name, String group) throws DaoException {
		try {
			Query query = this.currentSession()
					.createQuery("from BioSequenceNumber where name = :name and group = :group")
					.setParameter("name", name).setParameter("group", group).setLockOptions(LockOptions.UPGRADE);

			return (BioSequenceNumber) query.uniqueResult();
		} catch (HibernateException e) {
			throw new DaoException(e);
		}
	}

	@Override
	public void update(BioSequenceNumber sequenceNumber) throws DaoException {
		try {
			this.updateEntity(sequenceNumber);
		} catch (HibernateException e) {
			throw new DaoException(e);
		}
	}

	@Override
	public PageResult<BioSequenceNumber> getAllSeqences(PageRequest pageRequest) throws DaoException {
		Long count = 0L;
		PageResult<BioSequenceNumber> pageResult = null;
		try {
			Criteria criteria = this.currentSession().createCriteria(BioSequenceNumber.class);
			if (pageRequest.isCalculateRecordCount()) {
				count = (Long) criteria.setProjection(Projections.rowCount()).uniqueResult();
				if (count == null)
					count = 0L;
			}

			criteria = this.currentSession().createCriteria(BioSequenceNumber.class);

			criteria.addOrder(Order.asc("name")).list();
			List<BioSequenceNumber> resultList = (List<BioSequenceNumber>) criteria
					.setFirstResult(pageRequest.getFirstRowIndex()).setMaxResults(pageRequest.getMaxRecords()).list();

			pageResult = new PageResult();
			pageResult.setResultList(resultList);
			pageResult.setTotalRecords((Integer) count.intValue());

			return pageResult;
		} catch (HibernateException e) {
			throw new DaoException(e);
		}
	}
}
