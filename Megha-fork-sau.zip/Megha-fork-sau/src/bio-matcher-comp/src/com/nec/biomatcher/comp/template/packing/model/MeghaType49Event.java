package com.nec.biomatcher.comp.template.packing.model;

import java.io.PrintStream;
import java.util.Set;

import com.google.common.collect.Sets;
import com.nec.biomatcher.comp.template.packing.exception.MeghaTemplateException;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateConfig;
import com.nec.biomatcher.spec.transfer.model.AlgorithmType;

public class MeghaType49Event extends MeghaEvent {
	public static final int MAX_PALM_PART_COUNT = 17;

	public void print(PrintStream printStream) {
		printStream.printf("Not supported");
	}

	public static int getEventDataSize(MeghaTemplateConfig meghaTemplateConfig) throws MeghaTemplateException {
		return 0;
	}

	public static final Set<AlgorithmType> getAlgorithmTypes() {
		return Sets.newHashSet(AlgorithmType.FINGER_ELFT);
	}

	@Override
	public byte[] pack(MeghaTemplateConfig meghaTemplateConfig) throws MeghaTemplateException {
		throw new MeghaTemplateException("Packing is not supported for templateType 49");
	}

	@Override
	public void unpack(byte[] eventData, MeghaTemplateConfig meghaTemplateConfig) throws MeghaTemplateException {
		throw new MeghaTemplateException("Unpacking is not supported for templateType 49");
	}
}
