package com.nec.biomatcher.comp.lobstream.dataAccess.impl;

import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.FlushMode;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import com.nec.biomatcher.comp.lobstream.dataAccess.BioLobDataInfo;
import com.nec.biomatcher.comp.lobstream.dataAccess.LobStrorageDao;
import com.nec.biomatcher.core.framework.dataAccess.AbstractHibernateDao;
import com.nec.biomatcher.core.framework.dataAccess.DaoException;
import com.nec.biomatcher.core.framework.dataAccess.HibernateDaoException;

public class LobStorageHibernateImpl extends AbstractHibernateDao implements LobStrorageDao {
	private static final Logger logger = Logger.getLogger(LobStorageHibernateImpl.class);

	@Override
	public int deleteBioLobDataInfo(String lobId) throws DaoException {
	    String hql = "delete from BioLobDataInfo where lobId=:lobId";
	    Session mySession = this.getHibernateTemplate().getSessionFactory().openSession();
		try {
			mySession.beginTransaction();
			int deleteCount = mySession.createQuery(hql).setString("lobId", lobId).setFlushMode(FlushMode.COMMIT)
					.executeUpdate();
			mySession.getTransaction().commit();
			logger.info("LobStorageHibernateImpl.deleteBioLobDataInfo(String lobId) successed");
			return deleteCount;
		} catch (Throwable th) {
			throw new HibernateDaoException(th);
		} finally {
			mySession.close();
		}
	}
	
	@Override
	public boolean deleteLob(String lobId, String lobType) throws DaoException {
	    String hql = "delete from BioLobDataInfo where lobId=:lobId and lobType=:lobType";
	    Session mySession = this.getHibernateTemplate().getSessionFactory().openSession();
        try {        	
			mySession.beginTransaction();
            int deleteCount = mySession.createQuery(hql)
                .setString("lobId", lobId)
                .setString("lobType", lobType)
                .setFlushMode(FlushMode.COMMIT)
                .executeUpdate();
            mySession.getTransaction().commit();
            if (deleteCount > 0) {
                return true;
            }
            logger.info("LobStorageHibernateImpl.deleteLob(String lobId, String lobType) successed");
        } catch (Throwable th) {
            throw new HibernateDaoException(th);           
        } finally {
        	mySession.close();
        }
        return false;
	    
	}

    @Override
    public int deleteLobDataBeforeDate(Date date) throws DaoException {
       // String hql = "delete from BioLobDataInfo where lobId=:lobId and lobType=:lobType and createDateTime<=:deletDate";
        String hql = "delete from BioLobDataInfo where createDateTime<=:deletDate";
        Session mySession = this.getHibernateTemplate().getSessionFactory().openSession();
        try {        	
			mySession.beginTransaction();
            int deleteCount = mySession.createQuery(hql)               
                .setDate("deletDate", date)
                .setFlushMode(FlushMode.COMMIT)
                .executeUpdate();
            mySession.getTransaction().commit();  
            logger.info("LobStorageHibernateImpl.deleteLobDataBeforeDate(Date date) successed");
           return deleteCount;           
        } catch (Throwable th) {
            throw new HibernateDaoException(th);
        }  finally {
			mySession.close();
		}     
    }

	@SuppressWarnings("unchecked")
	@Override
	public List<BioLobDataInfo> getLobDataBeforeDate(Date date) throws DaoException {
		Session mySession = this.getHibernateTemplate().getSessionFactory().openSession();
		try {			
			mySession.beginTransaction();
			Criteria criteria = 
					mySession
					.createCriteria(BioLobDataInfo.class)
					.add(Restrictions.le("createDateTime", date));
		 criteria.setMaxResults(5000).setFlushMode(FlushMode.COMMIT);
		 List<BioLobDataInfo> results = (List<BioLobDataInfo>) criteria.list();
		 mySession.getTransaction().commit();
		 logger.info("LobStorageHibernateImpl.getLobDataBeforeDate(Date date) successed");
		 return results;			
		} catch (Throwable th) {
			throw new HibernateDaoException(th);
		} finally {
			mySession.close();
		}
	}

	@Override
	public void createLob(BioLobDataInfo bioLobInfo) throws DaoException {
		Session mySession = this.getHibernateTemplate().getSessionFactory().openSession();
		try {			
			//Session mySession = this.currentSession();			
			mySession.beginTransaction();
			mySession.save(bioLobInfo);
			mySession.getTransaction().commit();
			logger.info("LobStorageHibernateImpl.createLob(BioLobDataInfo bioLobInfo) successed");
		}  catch (Throwable th) {
			throw new HibernateDaoException(th);
		} finally {
			mySession.close();
		}			
	}

	@Override
	public byte[] getLobData(String lobId, String lobType) throws DaoException {
		Session mySession = this.getHibernateTemplate().getSessionFactory().openSession();
		try {
			mySession.beginTransaction();
			Criteria criteria = mySession.createCriteria(BioLobDataInfo.class);
			criteria.add(Restrictions.eq("lobId", lobId)).add(Restrictions.eq("lobType", lobType));
			criteria.setFlushMode(FlushMode.COMMIT);
			BioLobDataInfo bioLobInfo = (BioLobDataInfo) criteria.uniqueResult();
			mySession.getTransaction().commit();
			if (bioLobInfo != null && bioLobInfo.getLobData() != null) {				
				return bioLobInfo.getLobData();
			} else {
				return null;
			}
		} catch (Throwable th) {
			throw new HibernateDaoException(th);
		} finally {
			mySession.close();
		}
	}

	@Override
	@SuppressWarnings("unchecked")
	public boolean checkLobExists(String lobId, String lobType) throws DaoException {	   
	   Session mySession = this.getHibernateTemplate().getSessionFactory().openSession();	   
		try {
			mySession.beginTransaction();
			Criteria criteria = mySession.createCriteria(BioLobDataInfo.class);
			criteria.add(Restrictions.eq("lobId",lobId))
			.add(Restrictions.eq("lobType",lobType));
			criteria.setFlushMode(FlushMode.COMMIT);			
			List<BioLobDataInfo> result = criteria.list();			
			mySession.getTransaction().commit();			
			return result.size() > 0 ? true : false;			
		} catch (Throwable th) {
			throw new HibernateDaoException(th);
		} finally {
			mySession.close();
		}
	}		
}
