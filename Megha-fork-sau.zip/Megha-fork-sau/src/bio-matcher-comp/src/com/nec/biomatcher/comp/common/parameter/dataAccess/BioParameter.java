package com.nec.biomatcher.comp.common.parameter.dataAccess;

import java.util.Date;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import com.nec.biomatcher.core.framework.dataAccess.Dbo;

/**
 * The Class BioParameter.
 */
public class BioParameter implements Dbo {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The name. */
	private String name;

	/** The scope. */
	private String scope;

	/** The description. */
	private String description;

	/** The value. */
	private String value;

	/** The data type. */
	private String dataType;

	/** The create date time. */
	private Date createDateTime;

	/** The update date time. */
	private Date updateDateTime;

	/** The created by. */
	private String createdBy;

	/** The updated by. */
	private String updatedBy;

	public BioParameter() {

	}

	public BioParameter(String name, String scope, String dataType, String description, String value) {
		this.name = name;
		this.scope = scope;
		this.dataType = dataType;
		this.description = description;
		this.value = value;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getScope() {
		return scope;
	}

	public void setScope(String scope) {
		this.scope = scope;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public Date getCreateDateTime() {
		return createDateTime;
	}

	public void setCreateDateTime(Date createDateTime) {
		this.createDateTime = createDateTime;
	}

	public Date getUpdateDateTime() {
		return updateDateTime;
	}

	public void setUpdateDateTime(Date updateDateTime) {
		this.updateDateTime = updateDateTime;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	@Override
	public boolean equals(Object obj) {
		if (!(obj instanceof BioParameter)) {
			return false;
		} else if (this == obj) {
			return true;
		}

		BioParameter other = (BioParameter) obj;

		return new EqualsBuilder().append(getName(), other.getName()).append(getScope(), other.getScope()).isEquals();
	}

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(getName()).append(getScope()).toHashCode();
	}
}
