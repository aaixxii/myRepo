package com.nec.biomatcher.comp.entities.dataAccess;

import java.util.Date;

import com.nec.biomatcher.core.framework.dataAccess.Dbo;

public class BioMatcherNodeSegmentInfo implements Dbo {
	private static final long serialVersionUID = 1L;

	private String matcherNodeId;

	private Integer segmentId;

	private Long segmentVersion;

	private Date updateDateTime;

	private Boolean assignedFlag = Boolean.TRUE;

	public Integer getSegmentId() {
		return segmentId;
	}

	public void setSegmentId(Integer segmentId) {
		this.segmentId = segmentId;
	}

	public Long getSegmentVersion() {
		return segmentVersion;
	}

	public void setSegmentVersion(Long segmentVersion) {
		this.segmentVersion = segmentVersion;
	}

	public Date getUpdateDateTime() {
		return updateDateTime;
	}

	public void setUpdateDateTime(Date updateDateTime) {
		this.updateDateTime = updateDateTime;
	}

	public Boolean getAssignedFlag() {
		return assignedFlag;
	}

	public void setAssignedFlag(Boolean assignedFlag) {
		this.assignedFlag = assignedFlag;
	}

	public String getMatcherNodeId() {
		return matcherNodeId;
	}

	public void setMatcherNodeId(String matcherNodeId) {
		this.matcherNodeId = matcherNodeId;
	}
}
