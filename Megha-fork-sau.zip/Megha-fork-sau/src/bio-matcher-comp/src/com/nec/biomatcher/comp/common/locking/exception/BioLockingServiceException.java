package com.nec.biomatcher.comp.common.locking.exception;

import com.nec.biomatcher.core.framework.common.exception.CoreException;

/**
 * The Class LockingServiceException.
 *
 * @author Mahesh
 * @version 1.0
 * @since 22 June 2012
 */
public class BioLockingServiceException extends CoreException {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * The Constructor.
	 *
	 * @param message
	 *            the message
	 */
	public BioLockingServiceException(String message) {
		super(message);
	}

	/**
	 * The Constructor.
	 *
	 * @param message
	 *            the message
	 * @param cause
	 *            the cause
	 */
	public BioLockingServiceException(String message, Throwable cause) {
		super(message, cause);
	}
}
