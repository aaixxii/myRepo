package com.nec.biomatcher.comp.cluster.handlers;

import com.nec.biomatcher.comp.cluster.ClusterEventHandler;
import com.nec.biomatcher.comp.cluster.HazelcastAdminCluster;
import com.nec.biomatcher.core.framework.cache.SpringCacheManager;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;

public class SystemHandlers {
    public static void registerDefaultHandlers() {
        HazelcastAdminCluster.registerClusterEventHandler("CLEAR_CACHE", buildClearCacheEventHandler());
    }

    private static ClusterEventHandler buildClearCacheEventHandler() {
        ClusterEventHandler clusterEventHandler = (clusterEvent) -> {
            SpringCacheManager cacheManager = (SpringCacheManager) SpringServiceManager.getBean("methodCacheManager");
            cacheManager.removeAll();
        };

        return clusterEventHandler;
    }
}
