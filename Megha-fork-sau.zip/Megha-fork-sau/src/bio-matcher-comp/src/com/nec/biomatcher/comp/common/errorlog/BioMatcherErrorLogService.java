package com.nec.biomatcher.comp.common.errorlog;

import com.nec.biomatcher.comp.common.errorlog.exception.BioMatcherErrorLogException;
import com.nec.biomatcher.comp.manager.exception.BioMatchManagerException;

public interface BioMatcherErrorLogService {
	/**
	 * Creates the matcher error log.
	 *
	 * @param errorSource
	 *            the error source
	 * @param errorMessage
	 *            the error message
	 * @param exceptionDetail
	 *            the exception detail
	 * @param referenceKey1
	 *            the reference key1
	 * @param referenceKey2
	 *            the reference key2
	 * @return the string
	 * @throws BioMatchManagerException
	 *             the bio match manager exception
	 */
	public String createMatcherErrorLog(String errorSource, String errorCode, String errorMessage,
			String exceptionDetail, String referenceKey1, String referenceKey2) throws BioMatcherErrorLogException;

}
