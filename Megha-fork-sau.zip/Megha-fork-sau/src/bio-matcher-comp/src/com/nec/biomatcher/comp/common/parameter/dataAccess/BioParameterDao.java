package com.nec.biomatcher.comp.common.parameter.dataAccess;

import java.util.List;

import com.nec.biomatcher.core.framework.common.pagination.PageRequest;
import com.nec.biomatcher.core.framework.common.pagination.PageResult;
import com.nec.biomatcher.core.framework.dataAccess.DaoException;
import com.nec.biomatcher.core.framework.dataAccess.HibernateDao;

/**
 * The Interface BioParameterDao.
 */
public interface BioParameterDao extends HibernateDao {

	public List<BioParameterScope> getAllParameterScopes() throws DaoException;

	public List<BioParameter> getParametersLike(String parameterName, String scope) throws DaoException;

	public List<BioParameter> getAllParameters(boolean includeVariableScope) throws DaoException;

	public PageResult<BioParameter> getAllParameters(PageRequest pageRequest) throws DaoException;
}
