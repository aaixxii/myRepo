package com.nec.biomatcher.comp.template.storage.dataAccess;

import java.util.Date;

import com.nec.biomatcher.core.framework.dataAccess.Dbo;

public class BioTemplateDataInfo implements Dbo {
	private static final long serialVersionUID = 1L;

	private String templateDataId;
	private byte[] templateData;
	private Date createDateTime;
	private Date updateDateTime;

	public String getTemplateDataId() {
		return templateDataId;
	}

	public void setTemplateDataId(String templateDataId) {
		this.templateDataId = templateDataId;
	}

	public byte[] getTemplateData() {
		return templateData;
	}

	public void setTemplateData(byte[] templateData) {
		this.templateData = templateData;
	}

	public Date getCreateDateTime() {
		return createDateTime;
	}

	public void setCreateDateTime(Date createDateTime) {
		this.createDateTime = createDateTime;
	}

	public Date getUpdateDateTime() {
		return updateDateTime;
	}

	public void setUpdateDateTime(Date updateDateTime) {
		this.updateDateTime = updateDateTime;
	}
}
