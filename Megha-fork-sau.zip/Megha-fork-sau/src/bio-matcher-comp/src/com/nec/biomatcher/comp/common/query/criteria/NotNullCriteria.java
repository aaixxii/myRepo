package com.nec.biomatcher.comp.common.query.criteria;

/**
 * Criteria for specifying not null condition.
 *
 * @author Mahesh
 */
public class NotNullCriteria extends CriteriaDto {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

}
