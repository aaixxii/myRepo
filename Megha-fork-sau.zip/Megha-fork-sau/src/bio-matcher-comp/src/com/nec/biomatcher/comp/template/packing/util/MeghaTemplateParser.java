package com.nec.biomatcher.comp.template.packing.util;

import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang.StringUtils;

import com.google.common.collect.HashMultimap;
import com.google.common.collect.SetMultimap;
import com.nec.biomatcher.comp.template.packing.model.MeghaEventHeader;
import com.nec.biomatcher.comp.template.packing.model.MeghaTemplateHeader;
import com.nec.biomatcher.core.framework.common.HoldFlagUtil;
import com.nec.biomatcher.spec.transfer.model.TemplateType;

public class MeghaTemplateParser {
	private static final Logger logger = Logger.getLogger(MeghaTemplateParser.class.getName());

	private final TemplateType templateType;
	private final transient MeghaTemplateConfig meghaTemplateConfig;
	private final Map<String, OffsetInfo> templateHeaderFieldOffsetInfoMap;
	private final Map<String, OffsetInfo> eventHeaderFieldOffsetInfoMap;
	private final int maxEventCount;
	private final int templateHeaderSize;
	private final int templateDataSize;
	private final int eventDataSize;
	private final int eventSectionStartPosition;

	private final transient OffsetInfo SANITY_OFFSET_INFO;
	private final transient OffsetInfo TEMPLATE_TYPE_OFFSET_INFO;
	private final transient OffsetInfo CONTROL_FLAG_OFFSET_INFO;
	private final transient OffsetInfo MAX_EVENT_COUNT_OFFSET_INFO;
	private final transient OffsetInfo BIOMETRIC_ID_OFFSET_INFO;
	private final transient OffsetInfo EXTERNAL_ID_OFFSET_INFO;
	private final transient OffsetInfo EVENT_HOLD_FLAG_OFFSET_INFO;
	private final transient OffsetInfo GENDER_FLAG_OFFSET_INFO;
	private final transient OffsetInfo YOB_OFFSET_INFO;
	private final transient OffsetInfo RACE_OFFSET_INFO;
	private final transient OffsetInfo USER_FLAGS_OFFSET_INFO;
	private final transient OffsetInfo REGION_FLAGS_OFFSET_INFO;

	private final transient OffsetInfo EVENT_ID_OFFSET_INFO;
	private final transient OffsetInfo ALG_TYPE_OFFSET_INFO;
	private final transient OffsetInfo FE_TYPE_OFFSET_INFO;

	private final transient byte[] EMPTY_EVENT_DATA;

	public MeghaTemplateParser(TemplateType templateType, MeghaTemplateConfig meghaTemplateConfig) throws Exception {
		this.templateType = templateType;
		this.meghaTemplateConfig = meghaTemplateConfig;
		this.templateHeaderFieldOffsetInfoMap = MeghaTemplateHeader
				.getTemplateHeaderFieldOffsetInfoMap(meghaTemplateConfig.getUserFlagByteCount());
		this.eventHeaderFieldOffsetInfoMap = MeghaEventHeader.getEventHeaderFieldOffsetInfoMap();
		this.maxEventCount = meghaTemplateConfig.getMaxEventCount(templateType);
		this.templateHeaderSize = MeghaTemplateUtil.getTemplateHeaderSize(meghaTemplateConfig.getUserFlagByteCount());
		this.templateDataSize = MeghaTemplateUtil.getTemplateSize(templateType, meghaTemplateConfig);
		this.eventDataSize = MeghaTemplateUtil.getEventSize(templateType, meghaTemplateConfig);
		this.eventSectionStartPosition = templateHeaderSize;

		SANITY_OFFSET_INFO = templateHeaderFieldOffsetInfoMap.get("sanity");
		TEMPLATE_TYPE_OFFSET_INFO = templateHeaderFieldOffsetInfoMap.get("templateTypeCode");
		CONTROL_FLAG_OFFSET_INFO = templateHeaderFieldOffsetInfoMap.get("controlFlag");
		MAX_EVENT_COUNT_OFFSET_INFO = templateHeaderFieldOffsetInfoMap.get("maxEventCount");
		BIOMETRIC_ID_OFFSET_INFO = templateHeaderFieldOffsetInfoMap.get("biometricId");
		EXTERNAL_ID_OFFSET_INFO = templateHeaderFieldOffsetInfoMap.get("externalId");
		EVENT_HOLD_FLAG_OFFSET_INFO = templateHeaderFieldOffsetInfoMap.get("eventHoldFlag");
		GENDER_FLAG_OFFSET_INFO = templateHeaderFieldOffsetInfoMap.get("gender");
		YOB_OFFSET_INFO = templateHeaderFieldOffsetInfoMap.get("yob");
		RACE_OFFSET_INFO = templateHeaderFieldOffsetInfoMap.get("race");
		USER_FLAGS_OFFSET_INFO = templateHeaderFieldOffsetInfoMap.get("userFlags");
		REGION_FLAGS_OFFSET_INFO = templateHeaderFieldOffsetInfoMap.get("regionFlags");

		EVENT_ID_OFFSET_INFO = eventHeaderFieldOffsetInfoMap.get("eventId");
		ALG_TYPE_OFFSET_INFO = eventHeaderFieldOffsetInfoMap.get("algType");
		FE_TYPE_OFFSET_INFO = eventHeaderFieldOffsetInfoMap.get("feType");

		EMPTY_EVENT_DATA = new byte[eventDataSize];
	}

	public final void updateSanity(ByteBuffer templateBuffer) {
		byte templateData[] = templateBuffer.array();
		templateData[SANITY_OFFSET_INFO.START_POSITION] = 0;
		templateData[SANITY_OFFSET_INFO.START_POSITION] = MeghaTemplateUtil.calculateChecksum(templateData);
	}

	public final int getTemplateTypeCode(byte templateData[]) {
		return templateData[TEMPLATE_TYPE_OFFSET_INFO.START_POSITION];
	}

	public final void setTemplateTypeCode(byte templateTypeCode, ByteBuffer templateBuffer) {
		templateBuffer.position(TEMPLATE_TYPE_OFFSET_INFO.START_POSITION);
		templateBuffer.put(templateTypeCode);
	}

	public final void updateTemplateTypeCode(ByteBuffer templateBuffer) {
		templateBuffer.position(TEMPLATE_TYPE_OFFSET_INFO.START_POSITION);
		templateBuffer.put((byte) templateType.getTemplateTypeCode());
	}

	public final int getMaxEventCount(byte templateData[]) {
		return templateData[MAX_EVENT_COUNT_OFFSET_INFO.START_POSITION];
	}

	public final void updateMaxEventCount(ByteBuffer templateBuffer) {
		templateBuffer.position(MAX_EVENT_COUNT_OFFSET_INFO.START_POSITION);
		templateBuffer.put((byte) maxEventCount);
	}

	public int getTemplateDataSize() {
		return templateDataSize;
	}

	public final void setMaxEventCount(byte maxEventCount, ByteBuffer templateBuffer) {
		templateBuffer.position(MAX_EVENT_COUNT_OFFSET_INFO.START_POSITION);
		templateBuffer.put(maxEventCount);
	}

	public final void updateMaxEventCount(int maxEventCount, ByteBuffer templateBuffer) {
		templateBuffer.position(MAX_EVENT_COUNT_OFFSET_INFO.START_POSITION);
		templateBuffer.put((byte) maxEventCount);
	}

	public final void copyTemplateHeaderFields(Set<String> fieldIdSet, ByteBuffer srcTemplateBuffer,
			ByteBuffer targetTemplateBuffer) {
		if (getTemplateTypeCode(srcTemplateBuffer.array()) != getTemplateTypeCode(targetTemplateBuffer.array())) {
			throw new RuntimeException("TemplateTypeCode does not match, srcTemplateTypeCode: "
					+ getTemplateTypeCode(srcTemplateBuffer.array()) + ", targetTemplateTypeCode: "
					+ getTemplateTypeCode(targetTemplateBuffer.array()));
		}

		Map<String, OffsetInfo> fieldOffsetMap = templateHeaderFieldOffsetInfoMap;

		// Since we are using buffer.limit we need to call buffer.clear

		for (String fieldId : fieldIdSet) {
			srcTemplateBuffer.clear();
			targetTemplateBuffer.clear();

			OffsetInfo offsetInfo = fieldOffsetMap.get(fieldId);

			srcTemplateBuffer.position(offsetInfo.START_POSITION);
			srcTemplateBuffer.limit(offsetInfo.START_POSITION + offsetInfo.SIZE);

			targetTemplateBuffer.position(offsetInfo.START_POSITION);
			targetTemplateBuffer.put(srcTemplateBuffer);
		}

		srcTemplateBuffer.clear();
		targetTemplateBuffer.clear();
	}

	public final void setBiometricId(long biometricId, ByteBuffer templateBuffer) {
		templateBuffer.position(BIOMETRIC_ID_OFFSET_INFO.START_POSITION);
		templateBuffer.putLong(biometricId);
	}

	public final long getBiometricId(ByteBuffer templateBuffer) {
		templateBuffer.position(BIOMETRIC_ID_OFFSET_INFO.START_POSITION);
		return templateBuffer.getLong();
	}

	public final void setExternalId(String externalId, ByteBuffer templateBuffer) {
		templateBuffer.position(EXTERNAL_ID_OFFSET_INFO.START_POSITION);
		MeghaTemplateUtil.setStringData(externalId, EXTERNAL_ID_OFFSET_INFO.SIZE, templateBuffer);
	}

	public String getExternalId(final ByteBuffer templateBuffer) {
		templateBuffer.position(EXTERNAL_ID_OFFSET_INFO.START_POSITION);
		return MeghaTemplateUtil.getStringData(EXTERNAL_ID_OFFSET_INFO.SIZE, templateBuffer);
	}

	public Integer getNextFreeEventSlotIndex(final int maxEventCount, ByteBuffer templateBuffer) {
		// Event hold flag size is hard coded to 8 bytes, i.e. long
		templateBuffer.order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);
		templateBuffer.position(EVENT_HOLD_FLAG_OFFSET_INFO.START_POSITION);

		long holdFlag = templateBuffer.getLong();

		return HoldFlagUtil.getFirstFreeSlotIndex(holdFlag, maxEventCount);
	}

	public Integer getNextFreeEventSlotIndex(ByteBuffer templateBuffer) {
		// Event hold flag size is hard coded to 8 bytes, i.e. long
		templateBuffer.order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);
		templateBuffer.position(EVENT_HOLD_FLAG_OFFSET_INFO.START_POSITION);

		long holdFlag = templateBuffer.getLong();

		return HoldFlagUtil.getFirstFreeSlotIndex(holdFlag, maxEventCount);
	}

	public List<Integer> getUsedEventSlotIndexList(final int maxEventCount, ByteBuffer templateBuffer) {
		// Event hold flag size is hard coded to 8 bytes, i.e. long
		templateBuffer.order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);
		templateBuffer.position(EVENT_HOLD_FLAG_OFFSET_INFO.START_POSITION);

		long holdFlag = templateBuffer.getLong();

		return HoldFlagUtil.getHoldFlagIndexList(holdFlag, maxEventCount);
	}

	public List<Integer> getUsedEventSlotIndexList(ByteBuffer templateBuffer) {
		// Event hold flag size is hard coded to 8 bytes, i.e. long
		templateBuffer.order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);
		templateBuffer.position(EVENT_HOLD_FLAG_OFFSET_INFO.START_POSITION);

		long holdFlag = templateBuffer.getLong();

		return HoldFlagUtil.getHoldFlagIndexList(holdFlag, maxEventCount);
	}

	public final void updateEventId(String eventId, final int maxEventCount, final ByteBuffer templateBuffer)
			throws Exception {
		if (eventId == null) {
			eventId = "";
		}

		templateBuffer.order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);
		templateBuffer.position(EVENT_HOLD_FLAG_OFFSET_INFO.START_POSITION);

		long holdFlag = templateBuffer.getLong();

		List<Integer> holdFlagIndexList = HoldFlagUtil.getHoldFlagIndexList(holdFlag, maxEventCount);

		for (Integer eventIndex : holdFlagIndexList) {
			ByteBuffer eventBuffer = getEventDataBuffer(eventIndex, templateBuffer);
			eventBuffer.position(EVENT_ID_OFFSET_INFO.START_POSITION);
			MeghaTemplateUtil.setStringData(eventId, EVENT_ID_OFFSET_INFO.SIZE, eventBuffer);
		}
	}

	public final void updateEventId(String eventId, final ByteBuffer templateBuffer) throws Exception {
		if (eventId == null) {
			eventId = "";
		}

		templateBuffer.order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);
		templateBuffer.position(EVENT_HOLD_FLAG_OFFSET_INFO.START_POSITION);

		long holdFlag = templateBuffer.getLong();

		List<Integer> holdFlagIndexList = HoldFlagUtil.getHoldFlagIndexList(holdFlag, maxEventCount);

		for (Integer eventIndex : holdFlagIndexList) {
			ByteBuffer eventBuffer = getEventDataBuffer(eventIndex, templateBuffer);
			eventBuffer.position(EVENT_ID_OFFSET_INFO.START_POSITION);
			MeghaTemplateUtil.setStringData(eventId, EVENT_ID_OFFSET_INFO.SIZE, eventBuffer);
		}
	}

	public String getEventId(final int eventIndex, final ByteBuffer templateBuffer) {
		templateBuffer.order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);

		int eventIdPosition = eventSectionStartPosition + (eventIndex * eventDataSize)
				+ EVENT_ID_OFFSET_INFO.START_POSITION;
		try {
			templateBuffer.position(eventIdPosition);
			return MeghaTemplateUtil.getStringData(EVENT_ID_OFFSET_INFO.SIZE, templateBuffer);
		} catch (RuntimeException ex) {
			logger.log(Level.SEVERE,
					"Error in getEventId: eventIndex: " + eventIndex + ", eventIdPosition: " + eventIdPosition
							+ ", templateBufferCapacity: " + templateBuffer.capacity() + ", templateBufferLimit: "
							+ templateBuffer.limit() + " : " + ex.getMessage(),
					ex);
			throw ex;
		}
	}

	public EventKey getEventKey(final int eventIndex, final ByteBuffer templateBuffer) {
		int eventDataStartPosition = eventSectionStartPosition + (eventIndex * eventDataSize);
		try {
			templateBuffer.order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);

			EventKey eventKey = new EventKey();

			templateBuffer.position(eventDataStartPosition + EVENT_ID_OFFSET_INFO.START_POSITION);
			eventKey.setEventId(MeghaTemplateUtil.getStringData(EVENT_ID_OFFSET_INFO.SIZE, templateBuffer));

			templateBuffer.position(eventDataStartPosition + ALG_TYPE_OFFSET_INFO.START_POSITION);
			eventKey.setAlgorithmTypeCode(templateBuffer.get());

			templateBuffer.position(eventDataStartPosition + FE_TYPE_OFFSET_INFO.START_POSITION);
			eventKey.setFeTypeCode(templateBuffer.get());

			return eventKey;
		} catch (RuntimeException ex) {
			logger.log(Level.SEVERE,
					"Error in getEventKey: eventIndex: " + eventIndex + ", eventDataStartPosition: "
							+ eventDataStartPosition + ", templateBufferCapacity: " + templateBuffer.capacity()
							+ ", templateBufferLimit: " + templateBuffer.limit() + " : " + ex.getMessage(),
					ex);
			throw ex;
		}
	}

	public final ByteBuffer getEventDataBuffer(final int eventIndex, final ByteBuffer templateBuffer) {
		templateBuffer.clear();

		try {
			int startPosition = eventSectionStartPosition + (eventIndex * eventDataSize);

			templateBuffer.position(startPosition);
			templateBuffer.limit(startPosition + eventDataSize);

			ByteBuffer eventDataBuffer = templateBuffer.slice().order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);
			return eventDataBuffer;
		} catch (Throwable th) {
			logger.log(Level.SEVERE, "Error in getEventDataBuffer: eventIndex: " + eventIndex + " : " + th.getMessage(),
					th);
			throw th instanceof RuntimeException ? (RuntimeException) th : new RuntimeException(th);
		} finally {
			templateBuffer.clear();
		}
	}

	public final byte[] getEventData(String eventId, Integer algorithmTypeCode, Integer feTypeCode,
			final int maxEventCount, final ByteBuffer templateBuffer) {
		if (eventId == null) {
			eventId = "";
		}

		Map<EventKey, ByteBuffer> eventKeyEventBufferMap = getEventKeyEventBufferMap(maxEventCount, templateBuffer);
		for (Entry<EventKey, ByteBuffer> eventKeyEventBufferEntry : eventKeyEventBufferMap.entrySet()) {
			EventKey eventKey = eventKeyEventBufferEntry.getKey();
			ByteBuffer eventBuffer = eventKeyEventBufferEntry.getValue();

			if (StringUtils.equals(eventKey.getEventId(), eventId)) {
				if (algorithmTypeCode == null || algorithmTypeCode.byteValue() == eventKey.getAlgorithmTypeCode()) {
					if (feTypeCode == null || feTypeCode.byteValue() == eventKey.getFeTypeCode()) {
						byte[] eventData = new byte[eventDataSize];
						eventBuffer.position(0);
						eventBuffer.get(eventData);
						return eventData;
					}
				}
			}
		}
		return null;
	}

	public final Map<EventKey, ByteBuffer> getEventKeyEventBufferMap(final int maxEventCount,
			final ByteBuffer templateBuffer) {
		Map<EventKey, ByteBuffer> eventKeyEventBufferMap = new HashMap<>();

		templateBuffer.order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);

		templateBuffer.position(EVENT_HOLD_FLAG_OFFSET_INFO.START_POSITION);

		long holdFlag = templateBuffer.getLong();

		List<Integer> holdFlagIndexList = HoldFlagUtil.getHoldFlagIndexList(holdFlag, maxEventCount);

		for (Integer eventIndex : holdFlagIndexList) {
			ByteBuffer eventBuffer = getEventDataBuffer(eventIndex, templateBuffer);

			EventKey eventKey = new EventKey();

			eventBuffer.position(EVENT_ID_OFFSET_INFO.START_POSITION);
			eventKey.setEventId(MeghaTemplateUtil.getStringData(EVENT_ID_OFFSET_INFO.SIZE, eventBuffer));

			eventBuffer.position(ALG_TYPE_OFFSET_INFO.START_POSITION);
			eventKey.setAlgorithmTypeCode(eventBuffer.get());

			eventBuffer.position(FE_TYPE_OFFSET_INFO.START_POSITION);
			eventKey.setFeTypeCode(eventBuffer.get());

			eventBuffer.position(0);
			eventKeyEventBufferMap.put(eventKey, eventBuffer);
		}
		return eventKeyEventBufferMap;
	}

	public final Map<EventKey, ByteBuffer> getEventKeyEventBufferMap(final ByteBuffer templateBuffer) {
		Map<EventKey, ByteBuffer> eventKeyEventBufferMap = new HashMap<>();

		templateBuffer.order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);

		templateBuffer.position(EVENT_HOLD_FLAG_OFFSET_INFO.START_POSITION);

		long holdFlag = templateBuffer.getLong();

		List<Integer> holdFlagIndexList = HoldFlagUtil.getHoldFlagIndexList(holdFlag, maxEventCount);

		for (Integer eventIndex : holdFlagIndexList) {
			ByteBuffer eventBuffer = getEventDataBuffer(eventIndex, templateBuffer);

			EventKey eventKey = new EventKey();

			eventBuffer.position(EVENT_ID_OFFSET_INFO.START_POSITION);
			eventKey.setEventId(MeghaTemplateUtil.getStringData(EVENT_ID_OFFSET_INFO.SIZE, eventBuffer));

			eventBuffer.position(ALG_TYPE_OFFSET_INFO.START_POSITION);
			eventKey.setAlgorithmTypeCode(eventBuffer.get());

			eventBuffer.position(FE_TYPE_OFFSET_INFO.START_POSITION);
			eventKey.setFeTypeCode(eventBuffer.get());

			eventBuffer.position(0);
			eventKeyEventBufferMap.put(eventKey, eventBuffer);
		}
		return eventKeyEventBufferMap;
	}

	public final Map<EventKey, Integer> getEventKeyIndexMap(final int maxEventCount, final ByteBuffer templateBuffer) {
		templateBuffer.order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);

		templateBuffer.position(EVENT_HOLD_FLAG_OFFSET_INFO.START_POSITION);

		long holdFlag = templateBuffer.getLong();

		List<Integer> holdFlagIndexList = HoldFlagUtil.getHoldFlagIndexList(holdFlag, maxEventCount);

		final Map<EventKey, Integer> eventKeyIndexMap = new HashMap<>();

		for (Integer eventIndex : holdFlagIndexList) {
			EventKey eventKey = getEventKey(eventIndex, templateBuffer);
			eventKeyIndexMap.put(eventKey, eventIndex);
		}
		return eventKeyIndexMap;
	}

	public final Map<EventKey, Integer> getEventKeyIndexMap(final ByteBuffer templateBuffer) {
		templateBuffer.order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);

		templateBuffer.position(EVENT_HOLD_FLAG_OFFSET_INFO.START_POSITION);

		long holdFlag = templateBuffer.getLong();

		List<Integer> holdFlagIndexList = HoldFlagUtil.getHoldFlagIndexList(holdFlag, maxEventCount);

		final Map<EventKey, Integer> eventKeyIndexMap = new HashMap<>();

		for (Integer eventIndex : holdFlagIndexList) {
			EventKey eventKey = getEventKey(eventIndex, templateBuffer);
			eventKeyIndexMap.put(eventKey, eventIndex);
		}
		return eventKeyIndexMap;
	}

	public final void setEventDataAtIndex(final int eventIndex, final int maxEventCount, final ByteBuffer eventBuffer,
			final ByteBuffer templateBuffer) {
		eventBuffer.position(0);
		eventBuffer.limit(eventDataSize);

		templateBuffer.position(eventSectionStartPosition + (eventIndex * eventDataSize));
		templateBuffer.put(eventBuffer);

		setHoldFlag(eventIndex, true, maxEventCount, templateBuffer);
	}

	public final void setEventDataAtIndex(final int eventIndex, final ByteBuffer eventBuffer,
			final ByteBuffer templateBuffer) {
		eventBuffer.position(0);
		eventBuffer.limit(eventDataSize);

		templateBuffer.position(eventSectionStartPosition + (eventIndex * eventDataSize));
		templateBuffer.put(eventBuffer);

		setHoldFlag(eventIndex, true, templateBuffer);
	}

	public final boolean deleteEventDataByEventId(String eventId, final int maxEventCount,
			final ByteBuffer templateBuffer) {
		if (eventId == null) {
			eventId = "";
		}
		SetMultimap<String, Integer> eventIdIndexMap = getEventIdIndexMap(maxEventCount, templateBuffer);
		Set<Integer> eventIndexList = eventIdIndexMap.get(eventId);

		boolean isModified = false;

		for (Integer eventIndex : eventIndexList) {
			isModified = true;
			deleteEventDataByIndex(eventIndex, maxEventCount, templateBuffer);
		}

		return isModified;
	}

	public final boolean deleteEventDataByEventId(String eventId, final ByteBuffer templateBuffer) {
		if (eventId == null) {
			eventId = "";
		}
		SetMultimap<String, Integer> eventIdIndexMap = getEventIdIndexMap(templateBuffer);
		Set<Integer> eventIndexList = eventIdIndexMap.get(eventId);

		boolean isModified = false;

		for (Integer eventIndex : eventIndexList) {
			isModified = true;
			deleteEventDataByIndex(eventIndex, templateBuffer);
		}

		return isModified;
	}

	public final void deleteEventDataByIndex(int eventIndex, final int maxEventCount, final ByteBuffer templateBuffer) {
		templateBuffer.position(eventSectionStartPosition + (eventIndex * eventDataSize));
		templateBuffer.put(EMPTY_EVENT_DATA);
		setHoldFlag(eventIndex, false, maxEventCount, templateBuffer);
	}

	public final void deleteEventDataByIndex(int eventIndex, final ByteBuffer templateBuffer) {
		templateBuffer.position(eventSectionStartPosition + (eventIndex * eventDataSize));
		templateBuffer.put(EMPTY_EVENT_DATA);
		setHoldFlag(eventIndex, false, templateBuffer);
	}

	public void setHoldFlag(final int eventIndex, final boolean flag, final ByteBuffer templateBuffer) {
		if (eventIndex >= (EVENT_HOLD_FLAG_OFFSET_INFO.SIZE * 8)) {
			throw new RuntimeException("eventIndex: " + eventIndex + " cannot fit into holdflag size: "
					+ EVENT_HOLD_FLAG_OFFSET_INFO.SIZE);
		}

		if (eventIndex >= maxEventCount) {
			throw new RuntimeException(
					"eventIndex: " + eventIndex + " should be less than totalEventCount: " + maxEventCount);
		}

		templateBuffer.order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);
		templateBuffer.position(EVENT_HOLD_FLAG_OFFSET_INFO.START_POSITION);

		long holdFlag = templateBuffer.getLong();

		holdFlag = HoldFlagUtil.setHoldFlag(holdFlag, eventIndex, flag);

		templateBuffer.position(EVENT_HOLD_FLAG_OFFSET_INFO.START_POSITION);
		templateBuffer.putLong(holdFlag);
	}

	public void setHoldFlag(final int eventIndex, final boolean flag, final int maxEventCount,
			final ByteBuffer templateBuffer) {
		if (eventIndex >= (EVENT_HOLD_FLAG_OFFSET_INFO.SIZE * 8)) {
			throw new RuntimeException("eventIndex: " + eventIndex + " cannot fit into holdflag size: "
					+ EVENT_HOLD_FLAG_OFFSET_INFO.SIZE);
		}

		if (eventIndex >= maxEventCount) {
			throw new RuntimeException(
					"eventIndex: " + eventIndex + " should be less than totalEventCount: " + maxEventCount);
		}

		templateBuffer.order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);
		templateBuffer.position(EVENT_HOLD_FLAG_OFFSET_INFO.START_POSITION);

		long holdFlag = templateBuffer.getLong();

		holdFlag = HoldFlagUtil.setHoldFlag(holdFlag, eventIndex, flag);

		templateBuffer.position(EVENT_HOLD_FLAG_OFFSET_INFO.START_POSITION);
		templateBuffer.putLong(holdFlag);
	}

	public final ByteBuffer validateAndPadTemplateData(byte templateData[]) throws Exception {
		int inputTemplateTypeCode = getTemplateTypeCode(templateData);
		if (templateType.getTemplateTypeCode() != inputTemplateTypeCode) {
			throw new Exception("TemplateTypeCode mismatch, inputTemplateTypeCode: " + inputTemplateTypeCode
					+ ", requiredTemplateTypeCode: " + templateType.getTemplateTypeCode());
		}

		if (templateData.length > templateDataSize) {
			throw new Exception("Input template data size should be : " + templateDataSize + " but it is : "
					+ templateData.length + ", templateTypeCode: " + templateType.getTemplateTypeCode());
		}

		if (templateData.length < templateDataSize) {
			// Resize the input template
			if ((templateDataSize - templateData.length) % eventDataSize != 0) {
				throw new Exception("Input template data size should be : " + templateDataSize + " but it is : "
						+ templateData.length + ", templateTypeCode: " + templateType.getTemplateTypeCode()
						+ ", difference is not divisable by eventDataSize: " + eventDataSize);
			}

			templateData = Arrays.copyOf(templateData, templateDataSize);
		}

		return ByteBuffer.wrap(templateData).order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);
	}

	public final ByteBuffer validateAndPadTemplateData(byte templateData[], int templateDataSize) throws Exception {
		int inputTemplateTypeCode = getTemplateTypeCode(templateData);
		if (templateType.getTemplateTypeCode() != inputTemplateTypeCode) {
			throw new Exception("TemplateTypeCode mismatch, inputTemplateTypeCode: " + inputTemplateTypeCode
					+ ", requiredTemplateTypeCode: " + templateType.getTemplateTypeCode());
		}

		if (templateData.length > templateDataSize) {
			throw new Exception("Input template data size should be : " + templateDataSize + " but it is : "
					+ templateData.length + ", templateTypeCode: " + templateType.getTemplateTypeCode());
		}

		if (templateData.length < templateDataSize) {
			// Resize the input template
			if ((templateDataSize - templateData.length) % eventDataSize != 0) {
				throw new Exception("Input template data size should be : " + templateDataSize + " but it is : "
						+ templateData.length + ", templateTypeCode: " + templateType.getTemplateTypeCode()
						+ ", difference is not divisable by eventDataSize: " + eventDataSize);
			}

			templateData = Arrays.copyOf(templateData, templateDataSize);
		}

		return ByteBuffer.wrap(templateData).order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);
	}

	public final void validateSearchTemplateData(byte templateData[]) throws Exception {
		if (templateData == null || templateData.length < templateHeaderSize) {
			throw new Exception("Input template data size is invalid: size: "
					+ (templateData == null ? -1 : templateData.length) + ", templateTypeCode: "
					+ templateType.getTemplateTypeCode() + ", templateHeaderSize: " + templateHeaderSize);
		}

		int inputTemplateTypeCode = getTemplateTypeCode(templateData);
		if (templateType.getTemplateTypeCode() != inputTemplateTypeCode) {
			throw new Exception("TemplateTypeCode mismatch, inputTemplateTypeCode: " + inputTemplateTypeCode
					+ ", requiredTemplateTypeCode: " + templateType.getTemplateTypeCode());
		}

		int maxEventCount = getMaxEventCount(templateData);
		if (maxEventCount <= 0) {
			throw new Exception("Max event count in input template data is not set or invalid, maxEventCount: "
					+ maxEventCount + " for templateTypeCode: " + templateType.getTemplateTypeCode()
					+ ", templateDataSize: " + templateData.length);
		}

		int requiredTemplateSize = templateHeaderSize + (maxEventCount * eventDataSize);
		if (requiredTemplateSize != templateData.length) {
			throw new Exception("Input template data size should be : " + requiredTemplateSize + " but it is : "
					+ templateData.length + ", templateTypeCode: " + templateType.getTemplateTypeCode()
					+ ", maxEventCount: " + maxEventCount + ", templateHeaderSize: " + templateHeaderSize
					+ ", eventDataSize: " + eventDataSize);
		}
	}

	public final SetMultimap<String, Integer> getEventIdIndexMap(final int maxEventCount,
			final ByteBuffer templateBuffer) {
		templateBuffer.order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);

		templateBuffer.position(EVENT_HOLD_FLAG_OFFSET_INFO.START_POSITION);

		long holdFlag = templateBuffer.getLong();

		List<Integer> holdFlagIndexList = HoldFlagUtil.getHoldFlagIndexList(holdFlag, maxEventCount);

		SetMultimap<String, Integer> eventIdIndexMap = HashMultimap.create();

		for (Integer eventIndex : holdFlagIndexList) {
			String eventId = getEventId(eventIndex, templateBuffer);
			eventIdIndexMap.put(eventId, eventIndex);
		}

		return eventIdIndexMap;
	}

	public final SetMultimap<String, Integer> getEventIdIndexMap(final ByteBuffer templateBuffer) {
		templateBuffer.order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);

		templateBuffer.position(EVENT_HOLD_FLAG_OFFSET_INFO.START_POSITION);

		long holdFlag = templateBuffer.getLong();

		List<Integer> holdFlagIndexList = HoldFlagUtil.getHoldFlagIndexList(holdFlag, maxEventCount);

		SetMultimap<String, Integer> eventIdIndexMap = HashMultimap.create();

		for (Integer eventIndex : holdFlagIndexList) {
			String eventId = getEventId(eventIndex, templateBuffer);
			eventIdIndexMap.put(eventId, eventIndex);
		}

		return eventIdIndexMap;
	}

	public int getMaxEventCount() {
		return maxEventCount;
	}

	public int getTemplateHeaderSize() {
		return templateHeaderSize;
	}

	public int getEventDataSize() {
		return eventDataSize;
	}

	public MeghaTemplateConfig getMeghaTemplateConfig() {
		return meghaTemplateConfig;
	}

	public OffsetInfo getUserFlagsOffsetInfo() {
		return USER_FLAGS_OFFSET_INFO;
	}

	public TemplateType getTemplateType() {
		return templateType;
	}

}
