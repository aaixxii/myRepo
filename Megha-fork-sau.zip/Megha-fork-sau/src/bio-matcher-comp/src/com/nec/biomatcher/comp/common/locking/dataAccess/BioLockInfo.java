package com.nec.biomatcher.comp.common.locking.dataAccess;

import com.nec.biomatcher.core.framework.dataAccess.Dbo;

/**
 * Database entity for LockInfo.
 *
 * @author Mahesh
 * @version 1.0
 * @since 22 June 2012
 */
public class BioLockInfo implements Dbo {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The lock key. */
	private String lockKey;

	/** The lock host. */
	private String lockHost;

	/** The lock acquire milli. */
	private Long lockAcquireMilli;

	/** The lock timeout milli. */
	private Long lockTimeoutMilli;

	/**
	 * Gets the lock key.
	 *
	 * @return the lock key
	 */
	public String getLockKey() {
		return lockKey;
	}

	/**
	 * Sets the lock key.
	 *
	 * @param lockKey
	 *            the new lock key
	 */
	public void setLockKey(String lockKey) {
		this.lockKey = lockKey;
	}

	/**
	 * Gets the lock host.
	 *
	 * @return the lock host
	 */
	public String getLockHost() {
		return lockHost;
	}

	/**
	 * Sets the lock host.
	 *
	 * @param lockHost
	 *            the new lock host
	 */
	public void setLockHost(String lockHost) {
		this.lockHost = lockHost;
	}

	/**
	 * Gets the lock acquire milli.
	 *
	 * @return the lock acquire milli
	 */
	public Long getLockAcquireMilli() {
		return lockAcquireMilli;
	}

	/**
	 * Sets the lock acquire milli.
	 *
	 * @param lockAcquireMilli
	 *            the new lock acquire milli
	 */
	public void setLockAcquireMilli(Long lockAcquireMilli) {
		this.lockAcquireMilli = lockAcquireMilli;
	}

	/**
	 * Gets the lock timeout milli.
	 *
	 * @return the lock timeout milli
	 */
	public Long getLockTimeoutMilli() {
		return lockTimeoutMilli;
	}

	/**
	 * Sets the lock timeout milli.
	 *
	 * @param lockTimeoutMilli
	 *            the new lock timeout milli
	 */
	public void setLockTimeoutMilli(Long lockTimeoutMilli) {
		this.lockTimeoutMilli = lockTimeoutMilli;
	}
}
