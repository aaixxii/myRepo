package com.nec.biomatcher.comp.template.packing.model;

import java.io.PrintStream;
import java.nio.ByteBuffer;
import java.util.Set;

import com.google.common.collect.Sets;
import com.nec.biomatcher.comp.template.packing.exception.MeghaTemplateException;
import com.nec.biomatcher.comp.template.packing.util.MeghaEventDataSizeBuilder;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateConfig;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateUtil;
import com.nec.biomatcher.spec.transfer.model.AlgorithmType;

public class MeghaType1Event extends MeghaEvent {
	private byte pad;
	private byte quality;
	private byte faceFeatureData[];

	public void print(PrintStream printStream) {
		if (eventHeader != null) {
			eventHeader.print(printStream);
		}

		printStream.printf("%-20s - %s\n", "quality", quality);
		printStream.printf("%-20s - %s\n", "faceFeatureData", faceFeatureData != null);
	}

	public static int getEventDataSize(MeghaTemplateConfig meghaTemplateConfig) throws MeghaTemplateException {
		return new MeghaEventDataSizeBuilder(meghaTemplateConfig).pad(1).quality(1)
				.featureData(1, "FACE_NEC_S17_FEATURE_DATA_SIZE").build();
	}

	public static final Set<AlgorithmType> getAlgorithmTypes() {
		return Sets.newHashSet(AlgorithmType.FACE_NEC_S17);
	}

	@Override
	public byte[] pack(MeghaTemplateConfig meghaTemplateConfig) throws MeghaTemplateException {
		if (faceFeatureData == null) {
			throw new MeghaTemplateException("Invalid faceFeatureData is not set");
		}

		if (eventHeader == null) {
			eventHeader = new MeghaEventHeader();
		}

		eventHeader.setAlgType(AlgorithmType.FACE_NEC_S17.getValue().byteValue());

		byte[] eventData = new byte[getEventDataSize(meghaTemplateConfig)];
		ByteBuffer eventDataBuf = ByteBuffer.wrap(eventData).order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);
		eventDataBuf.put(eventHeader.pack());
		eventDataBuf.put(pad);
		eventDataBuf.put(quality);

		if (faceFeatureData.length != meghaTemplateConfig.getFeatureSize("FACE_NEC_S17_FEATURE_DATA_SIZE")) {
			throw new MeghaTemplateException("Invalid faceFeatureData length, actual: " + faceFeatureData.length
					+ ", expected: " + meghaTemplateConfig.getFeatureSize("FACE_NEC_S17_FEATURE_DATA_SIZE"));
		}

		eventDataBuf.put(faceFeatureData);
		return eventData;
	}

	@Override
	public void unpack(byte[] eventData, MeghaTemplateConfig meghaTemplateConfig) throws MeghaTemplateException {
		ByteBuffer eventDataBuf = ByteBuffer.wrap(eventData).order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);
		eventHeader = new MeghaEventHeader();
		eventHeader.unpack(eventDataBuf);
		pad = eventDataBuf.get();
		quality = eventDataBuf.get();
		faceFeatureData = new byte[meghaTemplateConfig.getFeatureSize("FACE_NEC_S17_FEATURE_DATA_SIZE")];
		eventDataBuf.get(faceFeatureData);
	}

	public byte getQuality() {
		return quality;
	}

	public void setQuality(byte quality) {
		this.quality = quality;
	}

	public byte[] getFaceFeatureData() {
		return faceFeatureData;
	}

	public void setFaceFeatureData(byte[] faceFeatureData) {
		this.faceFeatureData = faceFeatureData;
	}

}
