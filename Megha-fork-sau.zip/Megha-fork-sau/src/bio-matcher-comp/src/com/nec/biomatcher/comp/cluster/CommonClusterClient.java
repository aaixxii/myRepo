package com.nec.biomatcher.comp.cluster;

import java.net.URI;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.hazelcast.client.HazelcastClient;
import com.hazelcast.client.config.ClientConfig;
import com.hazelcast.client.config.ClientNetworkConfig;
import com.hazelcast.core.HazelcastInstance;
import com.nec.biomatcher.comp.config.BioMatcherConfigService;
import com.nec.biomatcher.comp.entities.dataAccess.BioServerInfo;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioComponentType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioConnectionType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioProtocolType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioServerState;

public class CommonClusterClient {
    private static final Logger logger = Logger.getLogger(CommonClusterClient.class);

    private static final ConcurrentHashMap<BioComponentType, CommonClusterClient> clusterClientMap = new ConcurrentHashMap<>();

    private ReadWriteLock cleintReadWriteLock = new ReentrantReadWriteLock();
    private Lock readLock = cleintReadWriteLock.readLock();
    private Lock writeLock = cleintReadWriteLock.writeLock();

    private BioComponentType bioComponentType;
    private BioMatcherConfigService bioMatcherConfigService;
    /** The hazelcast instance. */
    private HazelcastInstance hazelcastInstance;

    private CommonClusterClient(BioComponentType bioComponentType, BioMatcherConfigService bioMatcherConfigService) throws Exception {
        this.bioComponentType = bioComponentType;
        this.bioMatcherConfigService = bioMatcherConfigService;

        if (bioComponentType != BioComponentType.EC && bioComponentType != BioComponentType.VC && bioComponentType != BioComponentType.SC && bioComponentType != BioComponentType.TVC) {
            throw new IllegalArgumentException("Cluster client can be created for controller components only, bioComponentType: " + bioComponentType.name());
        }

        connect();
    }

    public static final CommonClusterClient getInstance(BioComponentType bioComponentType, BioMatcherConfigService bioMatcherConfigService) throws Exception {
        CommonClusterClient commonClusterClient = clusterClientMap.get(bioComponentType);
        if (commonClusterClient == null) {
            synchronized (CommonClusterClient.class) {
                commonClusterClient = clusterClientMap.get(bioComponentType);
                if (commonClusterClient == null) {
                    commonClusterClient = new CommonClusterClient(bioComponentType, bioMatcherConfigService);
                    clusterClientMap.put(bioComponentType, commonClusterClient);
                }
            }
        }
        return commonClusterClient;
    }

    public boolean connect() throws Exception {
        if (hazelcastInstance != null) {
            return true;
        }

        writeLock.lock();
        try {
            if (hazelcastInstance != null) {
                return true;
            }
            List<BioServerInfo> controllerList = bioMatcherConfigService.getServerInfoListByComponentType(bioComponentType, BioServerState.ACTIVE);
            if (controllerList.size() == 0) {
                logger.warn("No controllers configured for client to connect for bioComponentType: " + bioComponentType);
                return false;
            }

            String clusterInstanceId = bioComponentType.name() + "_ControllerCluster";

            ClientConfig clientConfig = new ClientConfig();
            clientConfig.getGroupConfig().setName(clusterInstanceId).setPassword("nec");

            clientConfig.setProperty("hazelcast.shutdownhook.enabled", "true");

            ClientNetworkConfig clientNetworkConfig = clientConfig.getNetworkConfig();
            clientNetworkConfig.setConnectionAttemptLimit(0);
            clientNetworkConfig.setConnectionAttemptPeriod(10000); // 10 seconds

            int memberCount = 0;
            for (BioServerInfo controller : controllerList) {
                if (!BioServerState.ACTIVE.equals(controller.getServerState())) {
                    logger.warn("Search controller state is not active for serverId : " + controller.getServerId());
                    continue;
                }

                String connectionUrl = bioMatcherConfigService.getServerConnectionUrl(controller.getServerId(), BioComponentType.SC, BioConnectionType.CLUSTER, BioProtocolType.HAZELCAST);
                if (StringUtils.isBlank(connectionUrl)) {
                    throw new IllegalArgumentException("Search controller connection url is not configured for serverId: " + controller.getServerId() + ", BioComponentType: " + BioComponentType.SC + ", connectionType: " + BioConnectionType.CLUSTER + ", protocolType: " + BioProtocolType.HAZELCAST);
                }

                URI clusterMemberUri = new URI(connectionUrl);

                if (clusterMemberUri.getHost() == null || clusterMemberUri.getPort() == 0) {
                    throw new IllegalArgumentException("Host and port for Match controller is not properly configured serverId: " + controller.getServerId() + ", BioComponentType: " + BioComponentType.SC + ", connectionType: " + BioConnectionType.CLUSTER + ", protocolType: " + BioProtocolType.HAZELCAST + ", connectionUrl: " + connectionUrl);
                }

                logger.info("After parsing match controller connectionUrl: " + connectionUrl + ", host: " + clusterMemberUri.getHost() + ", port: " + clusterMemberUri.getPort());

                clientNetworkConfig.addAddress(clusterMemberUri.getHost() + ":" + clusterMemberUri.getPort());
                memberCount++;
            }

            if (memberCount == 0) {
                logger.warn("No valid cluster members configured for client to connect for bioComponentType: " + bioComponentType);
                return false;
            }

            hazelcastInstance = HazelcastClient.newHazelcastClient(clientConfig);

            logger.info("Cluster client created successfully for bioComponentType: " + bioComponentType);

            return true;
        } finally {
            writeLock.unlock();
        }
    }

    public HazelcastInstance getHazelcastInstance() {
        return hazelcastInstance;
    }
}
