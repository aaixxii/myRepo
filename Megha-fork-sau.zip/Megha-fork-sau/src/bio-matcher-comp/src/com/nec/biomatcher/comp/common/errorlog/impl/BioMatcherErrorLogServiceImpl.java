package com.nec.biomatcher.comp.common.errorlog.impl;

import java.util.Date;
import java.util.UUID;

import org.apache.commons.lang.StringUtils;

import com.nec.biomatcher.comp.common.errorlog.BioMatcherErrorLogService;
import com.nec.biomatcher.comp.common.errorlog.dataAccess.BioMatcherErrorLogDao;
import com.nec.biomatcher.comp.common.errorlog.dataAccess.BioMatcherErrorLogInfo;
import com.nec.biomatcher.comp.common.errorlog.exception.BioMatcherErrorLogException;
import com.nec.biomatcher.core.framework.common.HostnameUtil;

public class BioMatcherErrorLogServiceImpl implements BioMatcherErrorLogService {
	private BioMatcherErrorLogDao bioMatcherErrorLogDao;

	@Override
	public String createMatcherErrorLog(String errorSource, String errorCode, String errorMessage,
			String exceptionDetail, String referenceKey1, String referenceKey2) throws BioMatcherErrorLogException {
		try {
			BioMatcherErrorLogInfo bioMatcherErrorLogInfo = new BioMatcherErrorLogInfo();
			bioMatcherErrorLogInfo.setErrorLogId(UUID.randomUUID().toString());
			bioMatcherErrorLogInfo.setErrorHost(HostnameUtil.getHostname());
			bioMatcherErrorLogInfo.setErrorSource(errorSource);
			bioMatcherErrorLogInfo.setErrorCode(errorCode);
			bioMatcherErrorLogInfo.setErrorMessage(StringUtils.substring(errorMessage, 0, 300));
			bioMatcherErrorLogInfo.setExceptionDetail(exceptionDetail);
			bioMatcherErrorLogInfo.setReferenceKey1(referenceKey1);
			bioMatcherErrorLogInfo.setReferenceKey2(referenceKey2);
			bioMatcherErrorLogInfo.setCreateDateTime(new Date());

			bioMatcherErrorLogDao.saveEntity(bioMatcherErrorLogInfo);

			return bioMatcherErrorLogInfo.getErrorLogId();
		} catch (Throwable th) {
			throw new BioMatcherErrorLogException(th.getMessage(), th);
		}
	}

	public void setBioMatcherErrorLogDao(BioMatcherErrorLogDao bioMatcherErrorLogDao) {
		this.bioMatcherErrorLogDao = bioMatcherErrorLogDao;
	}

}
