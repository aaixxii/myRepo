package com.nec.biomatcher.comp.template.packing.model;

import java.io.PrintStream;

public class MeghaPalmPartInfo {
	private byte partNumber;
	private byte quality;
	private byte[] featureData;

	public MeghaPalmPartInfo() {

	}

	public void print(PrintStream printStream) {
		printStream.printf("%-20s - %s\n", "partNumber", partNumber);
		printStream.printf("%-20s - %s\n", "quality", quality);
		printStream.printf("%-20s - %s\n", "featureData", featureData != null);
	}

	public MeghaPalmPartInfo(byte partNumber, Integer quality, byte[] featureData) {
		this.partNumber = partNumber;
		this.featureData = featureData;
		if (quality != null) {
			this.quality = quality.byteValue();
		}
	}

	public byte getQuality() {
		return quality;
	}

	public void setQuality(byte quality) {
		this.quality = quality;
	}

	public byte[] getFeatureData() {
		return featureData;
	}

	public void setFeatureData(byte[] featureData) {
		this.featureData = featureData;
	}

	public byte getPartNumber() {
		return partNumber;
	}

	public void setPartNumber(byte partNumber) {
		this.partNumber = partNumber;
	}
}
