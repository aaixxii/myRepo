package com.nec.biomatcher.comp.template.storage.impl;

import java.util.Arrays;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.InitializingBean;

import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.template.storage.TemplateDataService;
import com.nec.biomatcher.comp.template.storage.exception.TemplateDataNotFoundException;
import com.nec.biomatcher.comp.template.storage.exception.TemplateDataServiceException;
import com.nec.biomatcher.comp.template.storage.util.TemplateStorageType;
import com.nec.biomatcher.comp.util.ValueChangeNotification;
import com.nec.biomatcher.core.framework.common.CommonLogger;

public class TemplateDataDelegateServiceImpl implements TemplateDataService, InitializingBean {
	private static final Logger logger = Logger.getLogger(TemplateDataDelegateServiceImpl.class);

	private BioParameterService bioParameterService;
	private TemplateDataService templateDataFileService;
	private TemplateDataService templateDataDbService;
	private TemplateDataService templateDataFileToDbService;
	private TemplateDataService templateDataCassandraService;

	private TemplateDataService templateDataDelegateService;

	private TemplateStorageType templateStorageType = TemplateStorageType.DB;

	public String saveTemplateData(Integer binId, Long biometricId, byte[] templateData)
			throws TemplateDataServiceException {
		return templateDataDelegateService.saveTemplateData(binId, biometricId, templateData);
	}

	public void updateTemplateData(String templateDataKey, byte[] templateData) throws TemplateDataServiceException {
		templateDataDelegateService.updateTemplateData(templateDataKey, templateData);
	}

	public void deleteTemplateData(String templateDataKey) throws TemplateDataServiceException {
		templateDataDelegateService.deleteTemplateData(templateDataKey);
	}

	public byte[] getTemplateData(String templateDataKey)
			throws TemplateDataServiceException, TemplateDataNotFoundException {
		return templateDataDelegateService.getTemplateData(templateDataKey);
	}

	private void setTemplateStorageType(String templateStorageTypeValue) {
		logger.info("In TemplateDataDelegateServiceImpl.setTemplateStorageType: templateStorageTypeValue: "
				+ templateStorageTypeValue);
		try {
			templateStorageType = TemplateStorageType.valueOf(templateStorageTypeValue);
		} catch (Throwable th) {
			CommonLogger.CONFIG_LOG.error("Error converting templateStorageTypeValue(" + templateStorageTypeValue
					+ ") to valid TemplateStorageType {" + Arrays.asList(TemplateStorageType.values()) + "}");
			templateStorageType = TemplateStorageType.DB;
		}

		CommonLogger.CONFIG_LOG.info("In setTemplateStorageType: " + templateStorageType);

		switch (templateStorageType) {
		case DB:
			templateDataDelegateService = templateDataDbService;
			break;
		case FILE:
			templateDataDelegateService = templateDataFileService;
			break;
		case FILE_TO_DB:
			templateDataDelegateService = templateDataFileToDbService;
			break;
		case CASSANDRA:
			templateDataDelegateService = templateDataCassandraService;
			break;
		default:
			throw new RuntimeException(new TemplateDataServiceException(
					"TemplateStorageType: " + templateStorageType + " is not supported"));
		}
	}

	public void setBioParameterService(BioParameterService bioParameterService) {
		this.bioParameterService = bioParameterService;
	}

	public void setTemplateDataFileService(TemplateDataService templateDataFileService) {
		this.templateDataFileService = templateDataFileService;
	}

	public void setTemplateDataDbService(TemplateDataService templateDataDbService) {
		this.templateDataDbService = templateDataDbService;
	}

	public void setTemplateDataFileToDbService(TemplateDataService templateDataFileToDbService) {
		this.templateDataFileToDbService = templateDataFileToDbService;
	}

	public void setTemplateDataCassandraService(TemplateDataService templateDataCassandraService) {
		this.templateDataCassandraService = templateDataCassandraService;
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		logger.info("In TemplateDataDelegateServiceImpl.afterPropertiesSet");
		ValueChangeNotification<String> templateStorageTypeVCN = BioParameterService.getValueChangeNotification(
				bioParameterService, "TEMPLATE_STORAGE_TYPE", "DEFAULT", "DB", value -> setTemplateStorageType(value));
		templateStorageTypeVCN.checkAndNotify();
		CommonLogger.CONFIG_LOG.info(
				"In TemplateDataDelegateServiceImpl.afterPropertiesSet: templateStorageType: " + templateStorageType);
	}

}
