package com.nec.biomatcher.comp.common.errorlog.exception;

import com.nec.biomatcher.core.framework.common.exception.CoreException;

public class BioMatcherErrorLogException extends CoreException {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * The Constructor.
	 *
	 * @param message
	 *            the message
	 */
	public BioMatcherErrorLogException(String message) {
		super(message);
	}

	/**
	 * The Constructor.
	 *
	 * @param message
	 *            the message
	 * @param cause
	 *            the cause
	 */
	public BioMatcherErrorLogException(String message, Throwable cause) {
		super(message, cause);
	}

}
