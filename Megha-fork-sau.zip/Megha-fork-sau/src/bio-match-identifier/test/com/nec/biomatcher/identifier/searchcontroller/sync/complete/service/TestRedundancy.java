package com.nec.biomatcher.identifier.searchcontroller.sync.complete.service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Predicate;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class TestRedundancy {
	ConcurrentHashMap<StrictSyncCallbackKey, List<SyncSnSegVerInfo>> strictSyncCallbackMap = new ConcurrentHashMap<>();

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	private void createStrcitMap1() {
		StrictSyncCallbackKey key = new StrictSyncCallbackKey("SC-JOB1", "142028975", "1927258727",
				"http://127.0.0.1:8888");
		List<SyncSnSegVerInfo> seg9VerInfos = new ArrayList<>();
		SyncSnSegVerInfo sn1 = new SyncSnSegVerInfo();
		sn1.setBinId(Integer.valueOf(35));
		sn1.setSegmentId(Integer.valueOf(9));
		sn1.setSnNodeId("SN001");
		sn1.setSegmentVersion(1000L);
		sn1.setIsSyncCompelted(Boolean.FALSE);
		seg9VerInfos.add(sn1);
		strictSyncCallbackMap.put(key, seg9VerInfos);
	}

	private void checkCanCallback1() {
		if (strictSyncCallbackMap.isEmpty()) {

			return;
		}
		Predicate<SyncSnSegVerInfo> predicate = info -> info.getIsSyncCompelted() == Boolean.TRUE;
		strictSyncCallbackMap.entrySet().stream().forEach(e -> {
			long redundancy = e.getValue().stream().count();
			Assert.assertEquals(redundancy, 1);
			if (e.getValue().stream().filter(predicate).count() >= redundancy) {
				System.out.println("Find sync semgnet completed key, syncJobId:" + e.getKey().getSyncJobId());

			}
		});
	}

	@Test
	public void test1() {
		createStrcitMap1();
		checkCanCallback1();

	}

	private void createStrcitMap2() {
		strictSyncCallbackMap.clear();
		StrictSyncCallbackKey key = new StrictSyncCallbackKey("SC-JOB1", "142028975", "1927258727",
				"http://127.0.0.1:8888");
		List<SyncSnSegVerInfo> segVerInfos = new ArrayList<>();
		SyncSnSegVerInfo sn1 = new SyncSnSegVerInfo();
		sn1.setBinId(Integer.valueOf(35));
		sn1.setSegmentId(Integer.valueOf(9));
		sn1.setSnNodeId("SN001");
		sn1.setSegmentVersion(1000L);
		sn1.setIsSyncCompelted(Boolean.FALSE);
		segVerInfos.add(sn1);

		SyncSnSegVerInfo sn2 = new SyncSnSegVerInfo();
		sn2.setBinId(Integer.valueOf(35));
		sn2.setSegmentId(Integer.valueOf(10));
		sn2.setSnNodeId("SN002");
		sn2.setSegmentVersion(1001L);
		sn2.setIsSyncCompelted(Boolean.FALSE);
		segVerInfos.add(sn2);
		strictSyncCallbackMap.put(key, segVerInfos);
	}

	private void checkCanCallback2() {
		if (strictSyncCallbackMap.isEmpty()) {

			return;
		}
		Predicate<SyncSnSegVerInfo> predicate = info -> info.getIsSyncCompelted() == Boolean.TRUE;
		strictSyncCallbackMap.entrySet().stream().forEach(e -> {
			long redundancy = e.getValue().stream().count();
			Assert.assertEquals(redundancy, 2);
			if (e.getValue().stream().filter(predicate).count() >= redundancy) {
				System.out.println("Find sync semgnet completed key, syncJobId:" + e.getKey().getSyncJobId());
			}
		});
	}

	@Test
	public void test2() {
		createStrcitMap2();
		checkCanCallback2();
	}

	private void createStrcitMap3() {
		strictSyncCallbackMap.clear();
		StrictSyncCallbackKey key = new StrictSyncCallbackKey("SC-JOB1", "142028975", "1927258727",
				"http://127.0.0.1:8888");
		List<SyncSnSegVerInfo> segVerInfos1 = new ArrayList<>();
		SyncSnSegVerInfo sn1 = new SyncSnSegVerInfo();
		sn1.setBinId(Integer.valueOf(35));
		sn1.setSegmentId(Integer.valueOf(9));
		sn1.setSnNodeId("SN001");
		sn1.setSegmentVersion(1000L);
		sn1.setIsSyncCompelted(Boolean.FALSE);
		segVerInfos1.add(sn1);
		strictSyncCallbackMap.put(key, segVerInfos1);

		StrictSyncCallbackKey key2 = new StrictSyncCallbackKey("SC-JOB2", "142028976", "1927258728",
				"http://127.0.0.1:8888");
		List<SyncSnSegVerInfo> segVerInfos2 = new ArrayList<>();
		SyncSnSegVerInfo sn2 = new SyncSnSegVerInfo();
		sn2.setBinId(Integer.valueOf(35));
		sn2.setSegmentId(Integer.valueOf(10));
		sn2.setSnNodeId("SN002");
		sn2.setSegmentVersion(1001L);
		sn2.setIsSyncCompelted(Boolean.FALSE);
		segVerInfos2.add(sn2);
		strictSyncCallbackMap.put(key2, segVerInfos2);
	}

	private void checkCanCallback3() {
		if (strictSyncCallbackMap.isEmpty()) {
			return;
		}
		Predicate<SyncSnSegVerInfo> predicate = info -> info.getIsSyncCompelted() == Boolean.TRUE;
		strictSyncCallbackMap.entrySet().stream().forEach(e -> {
			long redundancy = e.getValue().stream().count();
			Assert.assertEquals(redundancy, 1);
			System.out.println("Called one!checkCanCallback3");
			if (e.getValue().stream().filter(predicate).count() >= redundancy) {
				System.out.println("Find sync semgnet completed key, syncJobId:" + e.getKey().getSyncJobId());
			}
		});
	}

	@Test
	public void test3() {
		createStrcitMap3();
		checkCanCallback3();
	}

}
