package com.nec.biomatcher.identifier.searchcontroller.tasks;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.remoting.RemoteConnectFailureException;

import com.google.common.util.concurrent.RateLimiter;
import com.google.common.util.concurrent.Uninterruptibles;
import com.hazelcast.core.ILock;
import com.nec.biomatcher.comp.bioevent.BiometricEventService;
import com.nec.biomatcher.comp.bioevent.exception.BiometricEventServiceException;
import com.nec.biomatcher.comp.cluster.ClusterInstance;
import com.nec.biomatcher.comp.cluster.ClusterInstanceRegistry;
import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.config.BioMatcherConfigService;
import com.nec.biomatcher.comp.config.exception.BioMatcherConfigServiceException;
import com.nec.biomatcher.comp.entities.dataAccess.BioMatcherBinInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BioMatcherSegmentInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BioRemoteSiteSyncInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BioServerInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BiometricEventInfo;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioComponentType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioServerState;
import com.nec.biomatcher.comp.manager.BioMatchManagerService;
import com.nec.biomatcher.comp.manager.exception.BioMatchManagerException;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateParser;
import com.nec.biomatcher.comp.template.storage.TemplateDataService;
import com.nec.biomatcher.comp.template.storage.exception.TemplateStorageServiceException;
import com.nec.biomatcher.core.framework.common.BiKey;
import com.nec.biomatcher.core.framework.common.ShutdownHook;
import com.nec.biomatcher.core.framework.common.concurrent.ConcurrentSetProcessor;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;
import com.nec.biomatcher.identifier.searchcontroller.util.RemoteSiteSyncServiceClient;
import com.nec.biomatcher.spec.transfer.biometrics.BiometricEventSyncTypeDto;
import com.nec.biomatcher.spec.transfer.biometrics.DeleteBiometricEventDto;
import com.nec.biomatcher.spec.transfer.biometrics.InsertBiometricEventDto;
import com.nec.biomatcher.spec.transfer.event.BiometricEventPhase;
import com.nec.biomatcher.spec.transfer.event.BiometricEventStatus;
import com.nec.biomatcher.spec.transfer.model.InsertTemplateInfo;

public class SyncEventsToRemoteSiteTask implements Runnable {

	private static final Logger logger = Logger.getLogger(SyncEventsToRemoteSiteTask.class);

	private BiometricEventService biometricEventService;

	private BioMatcherConfigService bioMatcherConfigService;

	private BioMatchManagerService bioMatchManagerService;

	private TemplateDataService templateDataService;

	private BioParameterService bioParameterService;

	private ConcurrentSetProcessor<String> remoteSiteEventSyncSiteIdProcesseor = new ConcurrentSetProcessor<>(
			"RemoteSiteEventSyncSiteIdProcesseor", (remoteSiteId) -> performRemoteSiteSync(remoteSiteId), () -> 2);

	private RateLimiter siteIdRateLimiter = RateLimiter.create(1);

	private boolean isInitialized = false;

	private ClusterInstance clusterInstance;

	public SyncEventsToRemoteSiteTask() {

	}

	@Override
	public void run() {
		logger.info("In SyncEventsToRemoteSiteTask.run");
		try {
			if (!isInitialized) {
				init();
			}

			while (!ShutdownHook.isShutdownFlag) {
				Set<String> workingSiteIdSet = new HashSet<>();

				try {
					remoteSiteEventSyncSiteIdProcesseor.waitForFreeSlot();

					boolean remoteSiteEventSyncEnabledFlag = bioParameterService
							.getParameterValue("REMOTE_SITE_SYNC_ENABLED_FLAG", "DEFAULT", true);

					double remoteEventSyncRatePerSecond = bioParameterService
							.getParameterValue("REMOTE_SITE_SYNC_RATE_PER_SECOND", "DEFAULT", 0.25);

					String localSiteId = bioParameterService.getParameterValue("LOCAL_SITE_ID", "DEFAULT", "DEFAULT");

					if (StringUtils.isBlank(localSiteId) || StringUtils.equals(localSiteId, "DEFAULT")
							|| !remoteSiteEventSyncEnabledFlag) {
						Uninterruptibles.sleepUninterruptibly(1, TimeUnit.MINUTES);
						continue;
					}

					RateLimiter rateLimiter = getRateLimiter(remoteEventSyncRatePerSecond);

					rateLimiter.acquire();

					List<BioServerInfo> remoteSiteServerInfoList = bioMatcherConfigService
							.getServerInfoListByComponentType(BioComponentType.RSC, BioServerState.ACTIVE);
					if (remoteSiteServerInfoList == null || remoteSiteServerInfoList.size() == 0) {
						Uninterruptibles.sleepUninterruptibly(1, TimeUnit.MINUTES);
						continue;
					}

					workingSiteIdSet.clear();

					remoteSiteServerInfoList.forEach(remoteSiteServerInfo -> {
						String remoteSiteId = remoteSiteServerInfo.getServerProperty("SITE_ID", null);
						if (remoteSiteId != null && remoteSiteId.trim().length() > 0) {
							workingSiteIdSet.add(remoteSiteId.trim());
						} else {
							logger.trace(
									"'SITE_ID' property is not set for serverId : " + remoteSiteServerInfo.getServerId()
											+ ", componentType: " + remoteSiteServerInfo.getComponentType().name());
						}
					});

					if (workingSiteIdSet.size() == 0) {
						Uninterruptibles.sleepUninterruptibly(1, TimeUnit.MINUTES);
						continue;
					}

					for (String remoteSiteId : workingSiteIdSet) {
						remoteSiteEventSyncSiteIdProcesseor.add(remoteSiteId.trim());
					}
				} catch (Throwable th) {
					logger.error("Error during SyncEventsToRemoteSiteTask.run loop: " + th.getMessage(), th);
					Uninterruptibles.sleepUninterruptibly(500, TimeUnit.MILLISECONDS);
				}
			}
		} catch (Throwable th) {
			logger.error("Error in SyncEventsToRemoteSiteTask: " + th.getMessage(), th);
		}
	}

	public void performRemoteSiteSync(String remoteSiteId) {
		logger.debug("In performRemoteSiteSync for remoteSiteId: " + remoteSiteId);

		try {
			if (!isInitialized) {
				init();
			}

			if (clusterInstance == null) {
				clusterInstance = ClusterInstanceRegistry.getClusterInstance(BioComponentType.SC);
			}

			ILock lock = clusterInstance.getLock("RemoteSiteEventSyncLock_" + remoteSiteId);

			boolean acquiredFlag = lock.tryLock();
			if (!acquiredFlag) {
				return;
			}

			try {
				String localSiteId = bioParameterService.getParameterValue("LOCAL_SITE_ID", "DEFAULT", "DEFAULT");

				int maxRecordsToLoad = bioParameterService.getParameterValue("MAX_SEGMENT_CHANGES_TO_LOAD_PER_REQUEST",
						"DEFAULT", 300);

				for (BioMatcherBinInfo bioMatcherBinInfo : bioMatcherConfigService.getMatcherBinInfoList()) {
					try {
						List<BioMatcherSegmentInfo> bioMatcherSegmentInfoList = bioMatchManagerService
								.getMatcherSegmentInfoListByBinId(bioMatcherBinInfo.getBinId());

						performRemoteSiteSync(localSiteId, remoteSiteId, bioMatcherBinInfo.getBinId(),
								BiometricEventStatus.DELETED, maxRecordsToLoad, bioMatcherSegmentInfoList);

						performRemoteSiteSync(localSiteId, remoteSiteId, bioMatcherBinInfo.getBinId(),
								BiometricEventStatus.ACTIVE, maxRecordsToLoad, bioMatcherSegmentInfoList);
					} catch (RemoteConnectFailureException ex) {
						throw ex;
					} catch (Throwable th) {
						logger.error(
								"Error in performRemoteSiteSync during syncRemoteBiometricEvents : " + th.getMessage(),
								th);
					}
				}

			} finally {
				lock.unlock();
			}
		} catch (Throwable th) {
			logger.error("Error in assignEventDataVersion for remoteSiteId: " + remoteSiteId + " : " + th.getMessage(),
					th);
		}
	}

	private void performRemoteSiteSync(String localSiteId, String remoteSiteId, Integer binId,
			BiometricEventStatus biometricEventStatus, int maxRecordsToSync,
			List<BioMatcherSegmentInfo> bioMatcherSegmentInfoList) throws Exception {
		try {
			List<String> remoteSiteServerInfoList = bioMatcherConfigService
					.getRemoteServerInfoListBySiteId(remoteSiteId);

			List<BiometricEventSyncTypeDto> biometricEventSyncTypeDtoList = new ArrayList<>();
			Map<Integer, Long> loadedSegmentVersionMap = new HashMap<>();

			for (BioMatcherSegmentInfo bioMatcherSegmentInfo : bioMatcherSegmentInfoList) {
				if (bioMatcherSegmentInfo.getSegmentVersion() <= 0L) {
					continue;
				}

				BiKey<Long, List<BiometricEventSyncTypeDto>> loadedEventListKey = buildBiometricEventSyncList(
						localSiteId, remoteSiteId, biometricEventStatus, bioMatcherSegmentInfo,
						maxRecordsToSync - biometricEventSyncTypeDtoList.size());
				if (loadedEventListKey == null || loadedEventListKey.getA() == null) {
					continue;
				}

				loadedSegmentVersionMap.put(bioMatcherSegmentInfo.getSegmentId(), loadedEventListKey.getA());
				biometricEventSyncTypeDtoList.addAll(loadedEventListKey.getB());

				if (biometricEventSyncTypeDtoList.size() >= maxRecordsToSync) {
					try {
						RemoteSiteSyncServiceClient.syncRemoteBiometricEvents(remoteSiteServerInfoList, localSiteId,
								remoteSiteId, biometricEventSyncTypeDtoList);
						bioMatchManagerService.updateRemoteSiteSyncSegmentVersion(remoteSiteId, loadedSegmentVersionMap,
								biometricEventStatus);
						loadedSegmentVersionMap.clear();
						biometricEventSyncTypeDtoList.clear();
					} catch (RemoteConnectFailureException ex) {
						throw ex;
					} catch (Throwable th) {
						logger.error(
								"Error in performRemoteSiteSync during syncRemoteBiometricEvents for biometricEventSyncTypeDtoListSize : "
										+ biometricEventSyncTypeDtoList.size() + " : " + th.getMessage(),
								th);
						throw th;
					}
				}
			}

			if (biometricEventSyncTypeDtoList.size() > 0) {
				try {
					RemoteSiteSyncServiceClient.syncRemoteBiometricEvents(remoteSiteServerInfoList, localSiteId,
							remoteSiteId, biometricEventSyncTypeDtoList);
					bioMatchManagerService.updateRemoteSiteSyncSegmentVersion(remoteSiteId, loadedSegmentVersionMap,
							biometricEventStatus);
					loadedSegmentVersionMap.clear();
					biometricEventSyncTypeDtoList.clear();
				} catch (RemoteConnectFailureException ex) {
					throw ex;
				} catch (Throwable th) {
					logger.error(
							"Error in performRemoteSiteSync during syncRemoteBiometricEvents for biometricEventSyncTypeDtoListSize : "
									+ biometricEventSyncTypeDtoList.size() + " : " + th.getMessage(),
							th);
					throw th;
				}
			}
		} catch (RemoteConnectFailureException ex) {
			throw ex;
		} catch (Throwable th) {
			logger.error("Error in performRemoteSiteSync during syncRemoteBiometricEvents : " + th.getMessage(), th);
		}

	}

	private BiKey<Long, List<BiometricEventSyncTypeDto>> buildBiometricEventSyncList(String localSiteId,
			String remoteSiteId, BiometricEventStatus biometricEventStatus, BioMatcherSegmentInfo bioMatcherSegmentInfo,
			int maxRecords) throws BioMatchManagerException, BiometricEventServiceException,
			BioMatcherConfigServiceException, TemplateStorageServiceException {
		MeghaTemplateParser meghaTemplateParser = bioMatcherConfigService.getBinIdMeghaTemplateParserMap()
				.get(bioMatcherSegmentInfo.getBinId());

		int templateDataSize = meghaTemplateParser.getTemplateDataSize();

		BioRemoteSiteSyncInfo bioRemoteSiteSyncInfo = bioMatchManagerService.getRemoteSiteSyncInfo(remoteSiteId,
				bioMatcherSegmentInfo.getSegmentId());

		long lastSyncSegmentVersion = (BiometricEventStatus.ACTIVE.equals(biometricEventStatus))
				? bioRemoteSiteSyncInfo.getInsertSegmentVersion() : bioRemoteSiteSyncInfo.getDeleteSegmentVersion();

		if (lastSyncSegmentVersion > 0 && bioMatcherSegmentInfo.getSegmentVersion() < lastSyncSegmentVersion) {
			// Someone manually updated the bioMatcherSegmentVersion
			logger.warn(
					"In lastSyncSegmentVersion: " + lastSyncSegmentVersion + " is greater than matcherSegmentVersion: "
							+ bioMatcherSegmentInfo.getSegmentVersion() + ", segmentId: "
							+ bioMatcherSegmentInfo.getSegmentId() + ", biometricEventStatus: " + biometricEventStatus);
			bioMatchManagerService.updateRemoteSiteSyncSegmentVersion(remoteSiteId,
					bioMatcherSegmentInfo.getSegmentId(), -1L, biometricEventStatus);
			lastSyncSegmentVersion = -1L;
		}

		if (lastSyncSegmentVersion >= bioMatcherSegmentInfo.getSegmentVersion()) {
			return null;
		}

		List<BiometricEventInfo> biometricEventInfoList = biometricEventService
				.getBiometricEventInfoListBySegmentIdForRemoteSync(bioMatcherSegmentInfo.getSegmentId(),
						lastSyncSegmentVersion, localSiteId, biometricEventStatus, maxRecords);
		if (biometricEventInfoList == null || biometricEventInfoList.size() == 0) {
			return null;
		}

		List<BiometricEventSyncTypeDto> biometricEventSyncTypeDtoList = new ArrayList<BiometricEventSyncTypeDto>();
		Long maxSegmentVersion = -1L;

		for (BiometricEventInfo biometricEventInfo : biometricEventInfoList) {
			maxSegmentVersion = Math.max(maxSegmentVersion, biometricEventInfo.getDataVersion());

			if (BiometricEventStatus.ACTIVE.equals(biometricEventStatus)
					&& BiometricEventStatus.ACTIVE.equals(biometricEventInfo.getStatus())
					&& (BiometricEventPhase.PENDING_SYNC.equals(biometricEventInfo.getPhase())
							|| BiometricEventPhase.SYNC_COMPLETED.equals(biometricEventInfo.getPhase()))) {
				// Suppressing the below errors otherwise cannot move forward
				try {
					byte[] templateDataBuff = templateDataService
							.getTemplateData(biometricEventInfo.getTemplateDataKey());
					if (templateDataBuff == null) {
						throw new Exception("templateDataBuff is null");
					}
					if (templateDataBuff.length != templateDataSize) {
						throw new Exception("templateDataBuff size mismatch,  templateDataBuffSize: "
								+ templateDataBuff.length + ", templateDataSize: " + templateDataSize);
					}

					InsertTemplateInfo insertTemplateInfo = new InsertTemplateInfo();
					insertTemplateInfo.setBinId(biometricEventInfo.getBinId());
					insertTemplateInfo.setTemplateType(
							"TEMPLATE_TYPE_" + meghaTemplateParser.getTemplateType().getTemplateTypeCode());
					insertTemplateInfo.setTemplateData(templateDataBuff);

					InsertBiometricEventDto insertBiometricEventDto = new InsertBiometricEventDto();
					insertBiometricEventDto.setExternalId(biometricEventInfo.getExternalId());
					insertBiometricEventDto.setEventId(biometricEventInfo.getEventId());
					insertBiometricEventDto.getInsertTemplateInfoList().add(insertTemplateInfo);
					insertBiometricEventDto.setUpdateFlag(true);

					biometricEventSyncTypeDtoList.add(insertBiometricEventDto);

				} catch (Throwable th) {
					logger.error(
							"Error detected in buildBiometricEventSyncList during getTemplateData for biometricId : "
									+ biometricEventInfo.getBiometricId() + ", templateDataKey: "
									+ biometricEventInfo.getTemplateDataKey() + " : " + th.getMessage(),
							th);
				}
			} else if (BiometricEventStatus.DELETED.equals(biometricEventStatus)
					&& BiometricEventStatus.DELETED.equals(biometricEventInfo.getStatus())) {
				DeleteBiometricEventDto deleteBiometricEventDto = new DeleteBiometricEventDto();
				deleteBiometricEventDto.setExternalId(biometricEventInfo.getExternalId());
				deleteBiometricEventDto.setEventId(biometricEventInfo.getEventId());
				deleteBiometricEventDto.getBinIdSet().add(biometricEventInfo.getBinId());
				biometricEventSyncTypeDtoList.add(deleteBiometricEventDto);
			}
		}

		return new BiKey<>(maxSegmentVersion, biometricEventSyncTypeDtoList);
	}

	private final RateLimiter getRateLimiter(double remoteSiteSyncRatePerSecond) {
		if (siteIdRateLimiter.getRate() != remoteSiteSyncRatePerSecond) {
			siteIdRateLimiter.setRate(remoteSiteSyncRatePerSecond);
		}

		return siteIdRateLimiter;
	}

	/**
	 * Inits the.
	 */
	private final void init() {
		biometricEventService = SpringServiceManager.getBean("biometricEventService");
		bioMatcherConfigService = SpringServiceManager.getBean("bioMatcherConfigService");
		bioMatchManagerService = SpringServiceManager.getBean("bioMatchManagerService");
		templateDataService = SpringServiceManager.getBean("templateDataService");
		bioParameterService = SpringServiceManager.getBean("bioParameterService");

		isInitialized = true;
	}

}
