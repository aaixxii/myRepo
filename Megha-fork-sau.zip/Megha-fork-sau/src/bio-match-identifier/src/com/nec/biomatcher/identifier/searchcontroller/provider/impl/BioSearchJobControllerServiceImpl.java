package com.nec.biomatcher.identifier.searchcontroller.provider.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.apache.log4j.Logger;
import org.apache.log4j.NDC;
import org.springframework.beans.factory.InitializingBean;

import com.nec.biomatcher.comp.bioevent.BiometricEventService;
import com.nec.biomatcher.comp.entities.dataAccess.BiometricEventInfo;
import com.nec.biomatcher.comp.util.JobIdGenerator;
import com.nec.biomatcher.core.framework.common.BiKey;
import com.nec.biomatcher.core.framework.common.HostnameUtil;
import com.nec.biomatcher.identifier.searchcontroller.manager.BioSearchControllerManager;
import com.nec.biomatcher.identifier.searchcontroller.queueing.SearchJobQueueHelper;
import com.nec.biomatcher.identifier.util.SearchJobPayloadCache;
import com.nec.biomatcher.spec.services.BioSearchJobControllerService;
import com.nec.biomatcher.spec.services.exception.BioSearchJobControllerServiceException;
import com.nec.biomatcher.spec.transfer.biometrics.BiometricEventSyncTypeDto;
import com.nec.biomatcher.spec.transfer.event.BiometricEventStatusInfoDto;
import com.nec.biomatcher.spec.transfer.job.extract.ExtractJobResultDto;
import com.nec.biomatcher.spec.transfer.job.payload.BioMatcherJobRequestPayload;
import com.nec.biomatcher.spec.transfer.job.search.SearchJobRequestDto;
import com.nec.biomatcher.spec.transfer.job.search.SearchJobResultDto;
import com.nec.biomatcher.spec.transfer.job.sync.SyncJobRequestDto;
import com.nec.biomatcher.spec.transfer.job.sync.SyncJobResultDto;
import com.nec.biomatcher.spec.transfer.model.BioJobStatus;

/**
 * The Class BioSearchJobControllerServiceImpl.
 */
public class BioSearchJobControllerServiceImpl implements BioSearchJobControllerService, InitializingBean {

	/** The Constant logger. */
	private static final Logger logger = Logger.getLogger(BioSearchJobControllerServiceImpl.class);

	/** The biometric event service. */
	private BiometricEventService biometricEventService;

	/** The bio search controller manager. */
	private BioSearchControllerManager bioSearchControllerManager;

	/** The search job queue helper. */
	private SearchJobQueueHelper searchJobQueueHelper;

	private JobIdGenerator jobIdGenerator;

	/** The search controller id. */
	private String searchControllerId;

	public String submitSyncJob(SyncJobRequestDto syncJobRequestDto) throws BioSearchJobControllerServiceException {
		if (searchControllerId == null) {
			throw new BioSearchJobControllerServiceException("Search controller is not configured on hostname: "
					+ HostnameUtil.getHostname() + ", ipAddress: " + HostnameUtil.getIpAddress());
		}

		String searchJobId = jobIdGenerator.nextId(searchControllerId);

		NDC.clear();
		NDC.push("SY_JOBID#" + searchJobId);

		try {
			searchJobQueueHelper.submitSyncJob(searchJobId, syncJobRequestDto);

			return searchJobId;
		} catch (Throwable th) {
			throw new BioSearchJobControllerServiceException("Error in submitSyncJob: " + th.getMessage(), th);
		} finally {
			NDC.clear();
		}
	}

	@Override
	public BiometricEventStatusInfoDto getBiometricEventStatusInfo(Long biometricId)
			throws BioSearchJobControllerServiceException {
		try {
			BiometricEventInfo biometricEventInfo = biometricEventService.getBiometricEventInfo(biometricId);

			BiometricEventStatusInfoDto biometricEventStatusInfoDto = toBiometricEventStatusInfoDto(biometricEventInfo);

			return biometricEventStatusInfoDto;
		} catch (Throwable th) {
			throw new BioSearchJobControllerServiceException("Error in getBiometricEventStatusInfo: " + th.getMessage(),
					th);
		}
	}

	@Override
	public List<BiometricEventStatusInfoDto> getBiometricEventStatusInfoList(String externalId, String eventId,
			Integer binId) throws BioSearchJobControllerServiceException {
		try {
			List<BiometricEventInfo> biometricEventInfoList = biometricEventService
					.getBiometricEventInfoListByExternalId(externalId, eventId, binId);

			return biometricEventInfoList.stream().map(p -> toBiometricEventStatusInfoDto(p))
					.collect(Collectors.toList());
		} catch (Throwable th) {
			throw new BioSearchJobControllerServiceException(
					"Error in getBiometricEventStatusInfoList: " + th.getMessage(), th);
		}
	}

	public String submitSearchJob(SearchJobRequestDto jobRequestDto) throws BioSearchJobControllerServiceException {
		if (searchControllerId == null) {
			throw new BioSearchJobControllerServiceException("Search controller is not configured on hostname: "
					+ HostnameUtil.getHostname() + ", ipAddress: " + HostnameUtil.getIpAddress());
		}

		String searchJobId = jobIdGenerator.nextId(searchControllerId);

		NDC.clear();
		NDC.push("SC_JOBID#" + searchJobId);

		try {
			searchJobQueueHelper.submitSearchJob(searchJobId, jobRequestDto);

			return searchJobId;
		} catch (Throwable th) {
			throw new BioSearchJobControllerServiceException("Error in submitSearchJob: " + th.getMessage(), th);
		} finally {
			NDC.clear();
		}
	}

	public void notifySearchJobExtractionCompleted(String searchJobId, ExtractJobResultDto extractionResult)
			throws BioSearchJobControllerServiceException {
		NDC.clear();
		NDC.push("SC_JOBID#" + searchJobId);

		try {
			searchJobQueueHelper.notifySearchJobExtractionCompleted(searchJobId, extractionResult);
		} catch (Throwable th) {
			throw new BioSearchJobControllerServiceException(
					"Error in notifySearchJobExtractionCompleted: " + th.getMessage(), th);
		} finally {
			NDC.clear();
		}
	}

	public BioJobStatus getSearchJobStatus(String searchJobId) throws BioSearchJobControllerServiceException {
		NDC.clear();
		NDC.push("SC_JOBID#" + searchJobId);

		try {
			return searchJobQueueHelper.getSearchJobStatus(searchJobId);
		} catch (Throwable th) {
			throw new BioSearchJobControllerServiceException(th.getMessage(), th);
		} finally {
			NDC.clear();
		}
	}

	public SearchJobRequestDto getSearchJobRequest(String searchJobId) throws BioSearchJobControllerServiceException {
		NDC.clear();
		NDC.push("SC_JOBID#" + searchJobId);

		try {
			BiKey<BioMatcherJobRequestPayload, Throwable> payloadKey = SearchJobPayloadCache
					.getSearchJobRequestPayload(searchJobId);

			if (payloadKey.getB() != null) {
				throw payloadKey.getB();
			}

			return payloadKey.getA().getSearchJobRequest();
		} catch (Throwable th) {
			throw new BioSearchJobControllerServiceException(th.getMessage(), th);
		} finally {
			NDC.clear();
		}
	}

	public SearchJobResultDto getSearchJobResult(String searchJobId) throws BioSearchJobControllerServiceException {
		NDC.clear();
		NDC.push("SC_JOBID#" + searchJobId);

		try {
			return searchJobQueueHelper.getSearchJobResult(searchJobId);
		} catch (Throwable th) {
			throw new BioSearchJobControllerServiceException(th.getMessage(), th);
		} finally {
			NDC.clear();
		}
	}

	public void deleteSearchJob(String searchJobId) throws BioSearchJobControllerServiceException {
		if (searchControllerId == null) {
			throw new BioSearchJobControllerServiceException("Search controller is not configured on hostname: "
					+ HostnameUtil.getHostname() + ", ipAddress: " + HostnameUtil.getIpAddress());
		}

		NDC.clear();
		NDC.push("SC_JOBID#" + searchJobId);

		try {
			searchJobQueueHelper.deleteSearchJob(searchJobId);
		} catch (Throwable th) {
			throw new BioSearchJobControllerServiceException(th.getMessage(), th);
		} finally {
			NDC.clear();
		}
	}

	public BioJobStatus getSyncJobStatus(String syncJobId) throws BioSearchJobControllerServiceException {
		NDC.clear();
		NDC.push("SY_JOBID#" + syncJobId);

		try {
			return searchJobQueueHelper.getSyncJobStatus(syncJobId);
		} catch (Throwable th) {
			throw new BioSearchJobControllerServiceException(th.getMessage(), th);
		} finally {
			NDC.clear();
		}
	}

	public SyncJobResultDto getSyncJobResult(String syncJobId) throws BioSearchJobControllerServiceException {
		NDC.clear();
		NDC.push("SY_JOBID#" + syncJobId);

		try {
			return searchJobQueueHelper.getSyncJobResult(syncJobId);
		} catch (Throwable th) {
			throw new BioSearchJobControllerServiceException(th.getMessage(), th);
		} finally {
			NDC.clear();
		}
	}

	public void deleteSyncJob(String syncJobId) throws BioSearchJobControllerServiceException {
		if (searchControllerId == null) {
			throw new BioSearchJobControllerServiceException("Search controller is not configured on hostname: "
					+ HostnameUtil.getHostname() + ", ipAddress: " + HostnameUtil.getIpAddress());
		}

		NDC.clear();
		NDC.push("SY_JOBID#" + syncJobId);

		try {
			searchJobQueueHelper.deleteSyncJob(syncJobId);
		} catch (Throwable th) {
			throw new BioSearchJobControllerServiceException(th.getMessage(), th);
		} finally {
			NDC.clear();
		}
	}

	public void notifySyncJobExtractionCompleted(String syncJobId, ExtractJobResultDto extractionResult)
			throws BioSearchJobControllerServiceException {
		NDC.clear();
		NDC.push("SY_JOBID#" + syncJobId);

		try {
			searchJobQueueHelper.notifySyncJobExtractionCompleted(syncJobId, extractionResult);
		} catch (Throwable th) {
			throw new BioSearchJobControllerServiceException(
					"Error in notifySyncJobExtractionCompleted: " + th.getMessage(), th);
		} finally {
			NDC.clear();
		}
	}

	public void syncRemoteBiometricEvents(String sourceSiteId, String targetSiteId,
			List<BiometricEventSyncTypeDto> biometricEventSyncList) throws BioSearchJobControllerServiceException {
		NDC.clear();
		NDC.push("SOURCE_SITE_ID#" + sourceSiteId);
		try {
			searchJobQueueHelper.syncRemoteBiometricEvents(sourceSiteId, targetSiteId, biometricEventSyncList);
		} catch (Throwable th) {
			throw new BioSearchJobControllerServiceException("Error in syncRemoteBiometricEvents: sourceSiteId: "
					+ sourceSiteId + ", targetSiteId: " + targetSiteId + " : " + th.getMessage(), th);
		} finally {
			NDC.clear();
		}
	}

	/**
	 * To biometric event status info dto.
	 *
	 * @param biometricEventInfo
	 *            the biometric event info
	 * @return the biometric event status info dto
	 */
	private BiometricEventStatusInfoDto toBiometricEventStatusInfoDto(BiometricEventInfo biometricEventInfo) {
		if (biometricEventInfo == null) {
			return null;
		}

		BiometricEventStatusInfoDto biometricEventStatusInfoDto = new BiometricEventStatusInfoDto();
		biometricEventStatusInfoDto.setBiometricId(biometricEventInfo.getBiometricId());
		biometricEventStatusInfoDto.setBinId(biometricEventInfo.getBinId());
		biometricEventStatusInfoDto.setExternalId(biometricEventInfo.getExternalId());
		biometricEventStatusInfoDto.setEventId(biometricEventInfo.getEventId());
		biometricEventStatusInfoDto.setStatus(biometricEventInfo.getStatus());
		biometricEventStatusInfoDto.setPhase(biometricEventInfo.getPhase());
		biometricEventStatusInfoDto.setErrorDateTime(biometricEventInfo.getErrorDateTime());

		return biometricEventStatusInfoDto;
	}

	public void setBiometricEventService(BiometricEventService biometricEventService) {
		this.biometricEventService = biometricEventService;
	}

	public void setBioSearchControllerManager(BioSearchControllerManager bioSearchControllerManager) {
		this.bioSearchControllerManager = bioSearchControllerManager;
	}

	public void setSearchJobQueueHelper(SearchJobQueueHelper searchJobQueueHelper) {
		this.searchJobQueueHelper = searchJobQueueHelper;
	}

	public void setJobIdGenerator(JobIdGenerator jobIdGenerator) {
		this.jobIdGenerator = jobIdGenerator;
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		searchControllerId = bioSearchControllerManager.getSearchControllerId();
		logger.info(
				"In BioSearchJobControllerServiceImpl.afterPropertiesSet: searchControllerId: " + searchControllerId);
	}

}
