package com.nec.biomatcher.identifier.searchbroker.manager.impl;

import java.io.File;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.function.Function;
import java.util.function.Supplier;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.InitializingBean;

import com.google.common.util.concurrent.Striped;
import com.hazelcast.core.IAtomicLong;
import com.hazelcast.core.IQueue;
import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.config.BioMatcherConfigService;
import com.nec.biomatcher.comp.config.exception.BioMatcherConfigServiceException;
import com.nec.biomatcher.comp.entities.dataAccess.BioServerInfo;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioComponentType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioServerState;
import com.nec.biomatcher.comp.manager.BioMatchManagerService;
import com.nec.biomatcher.comp.matcher.node.MatcherNodeStatusCheckHelper;
import com.nec.biomatcher.comp.metrics.MetricsUtil;
import com.nec.biomatcher.comp.util.LocalServerComponents;
import com.nec.biomatcher.comp.util.ServerStatusMonitor;
import com.nec.biomatcher.core.framework.common.CommonLogger;
import com.nec.biomatcher.core.framework.common.HostnameUtil;
import com.nec.biomatcher.core.framework.common.Memonizer;
import com.nec.biomatcher.core.framework.common.StringUtil;
import com.nec.biomatcher.core.framework.common.concurrent.BooleanLatch;
import com.nec.biomatcher.core.framework.common.concurrent.CommonTaskScheduler;
import com.nec.biomatcher.core.framework.common.concurrent.ConcurrentValuedHashMap;
import com.nec.biomatcher.core.framework.common.concurrent.DynamicSemaphore;
import com.nec.biomatcher.identifier.searchbroker.manager.BioSearchBrokerManager;
import com.nec.biomatcher.identifier.searchbroker.tasks.NotifySyncCompletedTask;
import com.nec.biomatcher.identifier.searchbroker.tasks.SearchBrokerManagerTask;
import com.nec.biomatcher.identifier.searchbroker.tasks.SearchNodeDataDistributionTask;
import com.nec.biomatcher.identifier.searchbroker.tasks.SegmentChangeSetHouseKeepingTask;
import com.nec.biomatcher.identifier.searchbroker.tasks.UpdateCentralSegmentVersionMapCache;
import com.nec.biomatcher.identifier.searchbroker.util.SearchBrokerClusterClient;
import com.nec.biomatcher.identifier.searchbroker.util.SegmentChangeSetReader;
import com.nec.biomatcher.spec.transfer.datadistribution.SegmentReportDto;
import com.nec.biomatcher.spec.transfer.datadistribution.SegmentSyncResponseDto;

/**
 * The Class BioSearchBrokerManagerImpl.
 */
public class BioSearchBrokerManagerImpl implements BioSearchBrokerManager, InitializingBean {

	/** The Constant logger. */
	private static final Logger logger = Logger.getLogger(BioSearchBrokerManagerImpl.class);

	/** The search broker connected flag. */
	private static BooleanLatch searchBrokerConnectedFlag = BooleanLatch.getInstance("SearchBrokerConnectedFlag",
			false);

	/** The search broker enabled flag. */
	private static BooleanLatch searchBrokerEnabledFlag = BooleanLatch.getInstance("SearchBrokerEnabledFlag", false);

	/** The online search node id list. */
	private static CopyOnWriteArraySet<String> onlineSearchNodeIdList = new CopyOnWriteArraySet<String>();

	/** The offline search node id list. */
	private static CopyOnWriteArraySet<String> offlineSearchNodeIdList = new CopyOnWriteArraySet<String>();

	/** The Get search node segment version map. */
	private static Function<String, ConcurrentHashMap<Integer, SegmentReportDto>> GetSearchNodeSegmentVersionMap = buildGetSearchNodeSegmentVersionMap();

	/** The notify sync completed queue. */
	private static LinkedBlockingDeque<SegmentSyncResponseDto> notifySyncCompletedQueue = new LinkedBlockingDeque<SegmentSyncResponseDto>();

	/** The search node data distribution task map. */
	private static ConcurrentHashMap<String, SearchNodeDataDistributionTask> searchNodeDataDistributionTaskMap = new ConcurrentHashMap<>();

	private static ConcurrentValuedHashMap<String, BooleanLatch> searchNodeOnlineStatusMap = new ConcurrentValuedHashMap<>(
			(searchNodeId) -> BooleanLatch.getInstance("SearchNodeOnlineFlag_" + searchNodeId));

	/** The striped lock. */
	protected final Striped<ReadWriteLock> stripedLock = Striped.lazyWeakReadWriteLock(100);

	/** The search broker id. */
	private String searchBrokerId;

	/** The bio matcher config service. */
	private BioMatcherConfigService bioMatcherConfigService;

	/** The bio parameter service. */
	private BioParameterService bioParameterService;

	/** The bio match manager service. */
	private BioMatchManagerService bioMatchManagerService;

	private MatcherNodeStatusCheckHelper matcherNodeStatusCheckHelper;

	private SegmentChangeSetReader segmentChangeSetReader;

	/** The search broker cluster client. */
	private SearchBrokerClusterClient searchBrokerClusterClient;

	private DynamicSemaphore snSyncConcurrencySemaphore;

	/** The initialization count. */
	private static AtomicInteger initializationCount = new AtomicInteger();

	public String getSearchBrokerId() {
		return searchBrokerId;
	}

	public IQueue<byte[]> getSearchNodeGroupJobQueue(String searchNodeGroupId) {
		return searchBrokerClusterClient.getSearchNodeGroupJobQueue(searchNodeGroupId);
	}

	public int addSearchNodeLoad(String searchNodeId, int loadValue) {
		return searchBrokerClusterClient.addSearchNodeLoad(searchNodeId, loadValue);
	}

	public CopyOnWriteArraySet<String> getOnlineSearchNodeIdList() {
		return onlineSearchNodeIdList;
	}

	public CopyOnWriteArraySet<String> getOfflineSearchNodeIdList() {
		return offlineSearchNodeIdList;
	}

	public BooleanLatch getSearchNodeOnlineFlag(String searchNodeId) {
		return searchNodeOnlineStatusMap.getValue(searchNodeId);
	}

	public ConcurrentValuedHashMap<String, BooleanLatch> getSearchNodeOnlineStatusMap() {
		return searchNodeOnlineStatusMap;
	}

	public ConcurrentHashMap<Integer, SegmentReportDto> getSearchNodeSegmentVersionMap(String searchNodeId) {
		return GetSearchNodeSegmentVersionMap.apply(searchNodeId);
	}

	public BooleanLatch getSearchBrokerEnabledFlag() {
		return searchBrokerEnabledFlag;
	}

	public BooleanLatch getSearchBrokerConnectedFlag() {
		return searchBrokerConnectedFlag;
	}

	public SearchBrokerClusterClient getSearchBrokerClusterClient() {
		return searchBrokerClusterClient;
	}

	public LinkedBlockingDeque<SegmentSyncResponseDto> getNotifySyncCompletedQueue() {
		return notifySyncCompletedQueue;
	}

	public void notifySearchNodeSegmentVersionToController(String searchNodeId,
			Map<Integer, Long> searchNodeSegmentVersionMap) {
		try {
			String searchNodeSyncVersionRecord = searchNodeId + ":"
					+ StringUtil.mapToString(searchNodeSegmentVersionMap, "=", ",");
			searchBrokerClusterClient.getNotifySearchNodeSegmentVersionToControllerTopic()
					.publish(searchNodeSyncVersionRecord);
		} catch (Throwable th) {
			logger.error("Error in notifySearchNodeSegmentVersionToController: " + th.getMessage(), th);
		}
	}

	public void notifySearchNodeOnline(String searchNodeId) {
		ServerStatusMonitor.notifyOnline(BioComponentType.SN, searchNodeId);

		try {
			IAtomicLong onlineFlagRef = searchBrokerClusterClient.getSearchNodeOnlineFlagRef(searchNodeId);
			if (onlineFlagRef.get() != 1L) {
				onlineFlagRef.set(1);
			}
		} catch (Throwable th) {
			logger.error("Error setting the onlineFlagRef for searchNodeId: " + searchNodeId);
		}

		BooleanLatch matcherNodeOnlineFlag = searchNodeOnlineStatusMap.getValue(searchNodeId);
		if (!matcherNodeOnlineFlag.getFlag()) {
			offlineSearchNodeIdList.remove(searchNodeId);
			onlineSearchNodeIdList.add(searchNodeId);
			matcherNodeOnlineFlag.setFlag(true);
		}
	}

	public void notifySearchNodeOffline(String searchNodeId) {
		try {
			ServerStatusMonitor.notifyOffline(BioComponentType.SN, searchNodeId);

			try {
				IAtomicLong onlineFlagRef = searchBrokerClusterClient.getSearchNodeOnlineFlagRef(searchNodeId);
				if (onlineFlagRef.get() != 0) {
					onlineFlagRef.set(0);
				}
			} catch (Throwable th) {
				logger.error("Error setting the onlineFlagRef for searchNodeId: " + searchNodeId);
			}

			BooleanLatch matcherNodeOnlineFlag = searchNodeOnlineStatusMap.getValue(searchNodeId);
			if (matcherNodeOnlineFlag.getFlag()) {
				onlineSearchNodeIdList.remove(searchNodeId);
				offlineSearchNodeIdList.add(searchNodeId);
				matcherNodeOnlineFlag.setFlag(false);
			}

			getSearchNodeSegmentVersionMap(searchNodeId).clear();
		} catch (Throwable th) {
			logger.error("Error in notifySearchNodeOffline: " + th.getMessage(), th);
		}
	}

	/**
	 * Builds the get search node segment version map.
	 *
	 * @return the function
	 */
	private static Function<String, ConcurrentHashMap<Integer, SegmentReportDto>> buildGetSearchNodeSegmentVersionMap() {
		return Memonizer.memonize(searchNodeId -> {
			return new ConcurrentHashMap<Integer, SegmentReportDto>();
		});
	}

	public void setBioMatcherConfigService(BioMatcherConfigService bioMatcherConfigService) {
		this.bioMatcherConfigService = bioMatcherConfigService;
	}

	public void startSearchNodeDataDistributionTasks() throws Exception {
		BioServerInfo currentSearchBroker = bioMatcherConfigService.getServerInfo(searchBrokerId);
		if (!BioServerState.ACTIVE.equals(currentSearchBroker.getServerState())) {
			logger.warn("currentSearchBroker :" + searchBrokerId + " is not active");
			return;
		}

		if (StringUtils.isBlank(currentSearchBroker.getSubSystemGroupId())) {
			throw new IllegalArgumentException("Subsystem groupId is not set for currentSearchBroker: "
					+ currentSearchBroker.getSubSystemGroupId());
		}

		if (snSyncConcurrencySemaphore == null) {
			Supplier<Integer> snSyncConcurrencySupplier = BioParameterService
					.getIntSupplier("SN_SYNC_CONCURRENCY_COUNT", "DEFAULT", 3);
			snSyncConcurrencySemaphore = DynamicSemaphore.getInstance("SN_SYNC_CONCURRENCY_SEMAPHORE",
					snSyncConcurrencySupplier);
		}

		Set<String> currentStartedTaskSet = new HashSet<>(searchNodeDataDistributionTaskMap.keySet());

		List<BioServerInfo> searchNodeList = bioMatcherConfigService
				.getServerInfoListByServerGroup(currentSearchBroker.getSubSystemGroupId(), BioComponentType.SN);

		for (BioServerInfo serverInfo : searchNodeList) {
			if (BioServerState.DISABLED.equals(serverInfo.getServerState())) {
				continue;
			}

			searchNodeDataDistributionTaskMap.compute(serverInfo.getServerId(), (serverId, currDistributionTask) -> {
				if (currDistributionTask == null) {
					SearchNodeDataDistributionTask task = new SearchNodeDataDistributionTask(serverId,
							snSyncConcurrencySemaphore);
					CommonTaskScheduler.scheduleWithFixedDelay(task, 10, 10, TimeUnit.SECONDS);
					return task;
				}
				return currDistributionTask;
			});

			currentStartedTaskSet.remove(serverInfo.getServerId());
		}

		// Stop all additional tasks
		if (currentStartedTaskSet.size() > 0) {
			for (String searchNodeId : currentStartedTaskSet) {
				SearchNodeDataDistributionTask task = searchNodeDataDistributionTaskMap.remove(searchNodeId);
				if (task != null) {
					CommonLogger.STATUS_LOG
							.warn("Before stopping SearchNodeDataDistributionTask for searchNodeId: " + searchNodeId);
					task.stop();
					CommonTaskScheduler.cancelTask(task, true);
				}
			}
		}
	}

	public void stopSearchNodeDataDistributionTasks() throws Exception {

		if (searchNodeDataDistributionTaskMap.size() == 0) {
			return;
		}

		for (String searchNodeId : searchNodeDataDistributionTaskMap.keySet()) {
			SearchNodeDataDistributionTask task = searchNodeDataDistributionTaskMap.get(searchNodeId);
			if (task != null) {
				CommonLogger.STATUS_LOG
						.warn("Before stopping SearchNodeDataDistributionTask for searchNodeId: " + searchNodeId);
				task.stop();
				CommonTaskScheduler.cancelTask(task, true);
				searchNodeDataDistributionTaskMap.remove(searchNodeId);
			}
		}
	}

	public boolean checkSearchNodeConnection(String searchNodeId, boolean firstRunFlag) {
		boolean connectFlag = false;
		Lock lock = stripedLock.get(searchNodeId).writeLock();
		lock.lock();
		try {
			connectFlag = matcherNodeStatusCheckHelper.sendServerCapacity(searchNodeId);

			if (connectFlag) {
				notifySearchNodeOnline(searchNodeId);
			} else if (firstRunFlag) {
				notifySearchNodeOffline(searchNodeId);
			}
		} catch (Throwable th) {
			logger.error("Error in checkSearchNodeConnection: offline searchNodeId: " + searchNodeId + " : "
					+ th.getMessage(), th);
		} finally {
			lock.unlock();

			logger.info("In checkSearchNodeConnection finally : searchNodeId: " + searchNodeId + ", connectFlag: "
					+ connectFlag);
		}
		return connectFlag;
	}

	/**
	 * Creates the default search broker settings.
	 *
	 * @param searchBrokerId
	 *            the search broker id
	 * @throws BioMatcherConfigServiceException
	 *             the bio matcher config service exception
	 */
	public void createDefaultSearchBrokerSettings(String searchBrokerId) throws BioMatcherConfigServiceException {
		BioServerInfo searchBroker = bioMatcherConfigService.getServerInfo(searchBrokerId);

		bioMatcherConfigService.createServerConnnections(searchBroker.getServerId(), searchBroker.getServerHost(),
				searchBroker.getComponentType());

		List<BioServerInfo> searchNodeList = bioMatcherConfigService
				.getServerInfoListByServerGroup(searchBroker.getSubSystemGroupId(), BioComponentType.SN);
		for (BioServerInfo searchNodeInfo : searchNodeList) {
			createDefaultSearchNodeSettings(searchNodeInfo.getServerId());
		}
	}

	/**
	 * Creates the default search node settings.
	 *
	 * @param searchNodeId
	 *            the search node id
	 * @throws BioMatcherConfigServiceException
	 *             the bio matcher config service exception
	 */
	public void createDefaultSearchNodeSettings(String searchNodeId) throws BioMatcherConfigServiceException {
		BioServerInfo searchNode = bioMatcherConfigService.getServerInfo(searchNodeId);

		bioMatcherConfigService.createServerConnnections(searchNode.getServerId(), searchNode.getServerHost(),
				searchNode.getComponentType());
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		logger.info("In BioClusteredExtractionControllerImpl: afterPropertiesSet : ipaddress: "
				+ HostnameUtil.getIpAddress() + ", hostname: " + HostnameUtil.getHostname() + ", initializationCount: "
				+ initializationCount.get());

		synchronized (BioSearchBrokerManagerImpl.class) {
			if (initializationCount.get() > 0) {
				return;
			}

			initializationCount.incrementAndGet();

			BioServerInfo currentSearchBroker = bioMatcherConfigService.getServerInfoByServerHost(
					HostnameUtil.getHostname(), HostnameUtil.getIpAddress(), BioComponentType.SB);
            if (currentSearchBroker == null) {
                currentSearchBroker = bioMatcherConfigService.getServerInfoByServerHost(HostnameUtil.LOCAL_HOSTNAME, HostnameUtil.LOCAL_IPADDRESS, BioComponentType.SB);
                if (currentSearchBroker == null) {
                    logger.warn("Search Broker is not configured for ipAddress : " + HostnameUtil.getIpAddress() + " or hostname: " + HostnameUtil.getHostname());
                    return;
                }
            }			
	

			searchBrokerId = currentSearchBroker.getServerId();

			LocalServerComponents.setSearchBrokerId(searchBrokerId);

			logger.info("In afterPropertiesSet : searchBrokerId: " + searchBrokerId);

			Supplier<Integer> snSyncConcurrencySupplier = BioParameterService
					.getIntSupplier("SN_SYNC_CONCURRENCY_COUNT", "DEFAULT", 3);
			snSyncConcurrencySemaphore = DynamicSemaphore.getInstance("SN_SYNC_CONCURRENCY_SEMAPHORE",
					snSyncConcurrencySupplier);

			createDefaultSearchBrokerSettings(searchBrokerId);

			searchBrokerClusterClient = new SearchBrokerClusterClient(searchBrokerId);
			searchBrokerClusterClient.setBioMatcherConfigService(bioMatcherConfigService);
			searchBrokerClusterClient.setSegmentChangeSetReader(segmentChangeSetReader);
			searchBrokerClusterClient.setBioSearchBrokerManager(this);

			CommonTaskScheduler.scheduleWithFixedDelay(new SearchBrokerManagerTask(), 30, 30, TimeUnit.SECONDS);

			CommonTaskScheduler.scheduleWithFixedDelay(new NotifySyncCompletedTask(), 30, 30, TimeUnit.SECONDS);

			CommonTaskScheduler.scheduleWithFixedDelay(new UpdateCentralSegmentVersionMapCache(), 30, 30,
					TimeUnit.SECONDS);

			bioParameterService.deleteParameter("SEARCH_BROKER_MAX_SEARCH_JOB_PAYLOAD_CACHE_COUNT", "DEFAULT");
			bioParameterService.deleteParameter("SEARCH_BROKER_SEARCH_JOB_PAYLOAD_CACHE_EXPIRY_MILLI", "DEFAULT");

			CommonTaskScheduler.scheduleWithFixedDelay(new SegmentChangeSetHouseKeepingTask(), 1, 1, TimeUnit.MINUTES);

			String path = bioParameterService.getParameterValue("SEGMENT_CHANGE_SET_STORAGE_PATH", "DEFAULT",
					new File(System.getProperty("user.home"), "storage/segchangesets/data/").getAbsolutePath());

			MetricsUtil.registerGauge(BioComponentType.SB, searchBrokerId, "ONLINE_SEARCH_NODE_COUNT", () -> {
				return onlineSearchNodeIdList.size();
			});

			MetricsUtil.registerGauge(BioComponentType.SB, searchBrokerId, "OFFLINE_SEARCH_NODE_COUNT", () -> {
				return offlineSearchNodeIdList.size();
			});
		}
	}

	public void setBioParameterService(BioParameterService bioParameterService) {
		this.bioParameterService = bioParameterService;
	}

	public void setBioMatchManagerService(BioMatchManagerService bioMatchManagerService) {
		this.bioMatchManagerService = bioMatchManagerService;
	}

	public void setSegmentChangeSetReader(SegmentChangeSetReader segmentChangeSetReader) {
		this.segmentChangeSetReader = segmentChangeSetReader;
	}

	public void setMatcherNodeStatusCheckHelper(MatcherNodeStatusCheckHelper matcherNodeStatusCheckHelper) {
		this.matcherNodeStatusCheckHelper = matcherNodeStatusCheckHelper;
	}

}
