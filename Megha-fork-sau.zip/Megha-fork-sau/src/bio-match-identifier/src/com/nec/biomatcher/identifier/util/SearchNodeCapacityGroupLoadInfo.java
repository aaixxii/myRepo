package com.nec.biomatcher.identifier.util;

import java.util.Comparator;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentSkipListSet;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.google.common.util.concurrent.Uninterruptibles;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.core.IAtomicLong;
import com.hazelcast.core.ILock;
import com.hazelcast.core.ISet;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioComponentType;
import com.nec.biomatcher.comp.metrics.MetricsUtil;
import com.nec.biomatcher.comp.util.LocalServerComponents;
import com.nec.biomatcher.core.framework.common.CommonLogger;
import com.nec.biomatcher.core.framework.common.ShutdownHook;
import com.nec.biomatcher.core.framework.common.concurrent.CommonTaskScheduler;
import com.nec.biomatcher.core.framework.common.concurrent.ConcurrentReader;
import com.nec.biomatcher.core.framework.common.concurrent.DynamicSemaphore;
import com.nec.biomatcher.identifier.searchcontroller.util.ScSearchJobInfo;

public class SearchNodeCapacityGroupLoadInfo implements Comparable<SearchNodeCapacityGroupLoadInfo> {
	private static final Logger logger = Logger.getLogger(SearchNodeCapacityGroupLoadInfo.class);

	private static final AtomicInteger indexCounter = new AtomicInteger();
	private static final ConcurrentHashMap<Integer, SearchNodeCapacityGroupLoadInfo> instanceMap = new ConcurrentHashMap<>();
	private static final ConcurrentSkipListSet<Integer> modifiedIndexQueue = new ConcurrentSkipListSet<>();
	private static final Semaphore waitSemaphore = new Semaphore(0);
	private static final ForkJoinPool forkJoinPool = new ForkJoinPool(50);
	private static final LoadingCache<String, Integer> currentLoadCache = CacheBuilder.newBuilder().maximumSize(0)
			.expireAfterAccess(2, TimeUnit.MILLISECONDS).concurrencyLevel(200)
			.build(new CacheLoader<String, Integer>() {
				@Override
				public Integer load(String key) throws Exception {
					// TODO Auto-generated method stub
					return null;
				}
			});

	private static final AsyncFlusherThread ASYNC_FLUSHER_THREAD = new AsyncFlusherThread();

	static {
		CommonTaskScheduler.scheduleWithFixedDelay(ASYNC_FLUSHER_THREAD, 10, 10, TimeUnit.MILLISECONDS);
	}

	/** The search node id. */
	public final String searchNodeId;

	public final String capacityGroupId;

	/** The current load. */
	private final IAtomicLong snCurrentLoad;

	private final IAtomicLong scSnCurrentLoad;

	private final IAtomicLong snOnlineFlag;

	public String snGroupId;

	public int searchNodeCapacity;

	public float searchNodeJobOverloadFactor = 1;

	public int calculatedCapacity;

	private boolean searchJobSlotAcquireLockFlag = false;

	private final Semaphore lazySlotReleaseSemaphore = new Semaphore(0);

	private final Integer instanceIndex;

	private final ConcurrentReader<Integer> snCurrentLoadReader;

	private final ConcurrentReader<Integer> scSnCurrentLoadReader;

	private final ConcurrentReader<Boolean> snOnlineFlagReader;

	private final ILock jobAssignmentLock;

	private final ReadWriteLock rwLock = new ReentrantReadWriteLock(true);
	private final Lock readLock = rwLock.readLock();
	private final Lock writeLock = rwLock.writeLock();
	private volatile long slotCounterAutoCorrectionTimestampMilli = System.currentTimeMillis();
	private volatile long lastSlotAcquireTimestampMilli;
	private volatile long lastSlotReleaseTimestampMilli;
	private int clusterMemberCount = 1;
	private final HazelcastInstance hazelcastInstance;

	public SearchNodeCapacityGroupLoadInfo(HazelcastInstance hazelcastInstance, String searchControllerId,
			String searchNodeId, String capacityGroupId) {
		this.hazelcastInstance = hazelcastInstance;
		this.searchNodeId = searchNodeId;
		this.capacityGroupId = StringUtils.isBlank(capacityGroupId) ? "0" : capacityGroupId;
		this.snCurrentLoad = hazelcastInstance.getAtomicLong("SN_LOAD_" + searchNodeId + "_" + this.capacityGroupId);
		this.scSnCurrentLoad = hazelcastInstance
				.getAtomicLong("SC_SN_LOAD_" + searchControllerId + "_" + searchNodeId + "_" + this.capacityGroupId);
		this.snOnlineFlag = hazelcastInstance.getAtomicLong("SEARCH_NODE_ONLINE_FLAG_" + searchNodeId);
		this.jobAssignmentLock = hazelcastInstance
				.getLock("SEARCH_JOB_ASSIGNMENT_LOCK_" + searchNodeId + "_" + this.capacityGroupId);

		ISet<String> snCapacityGroupKeySet = hazelcastInstance.getSet("SN_CAPACITY_GROUP_KEY_SET");
		snCapacityGroupKeySet.add(searchNodeId + "|" + this.capacityGroupId);

		this.snCurrentLoadReader = new ConcurrentReader<>(() -> (int) snCurrentLoad.get());

		this.scSnCurrentLoadReader = new ConcurrentReader<>(() -> (int) scSnCurrentLoad.get());

		this.snOnlineFlagReader = new ConcurrentReader<>(() -> (snOnlineFlag.get() == 1));

		this.clusterMemberCount = Math.max(1, hazelcastInstance.getCluster().getMembers().size());

		instanceIndex = indexCounter.accumulateAndGet(1, (currVal, newVal) -> currVal + newVal);

		instanceMap.put(instanceIndex, this);

		if (searchControllerId != null && searchControllerId.equals(LocalServerComponents.getSearchControllerId())) {
			releaseScCurrentLoad();
		}

		MetricsUtil.registerGauge(BioComponentType.SN, searchNodeId, "ACTIVE_JOB_COUNT_" + this.capacityGroupId, () -> {
			return this.snCurrentLoad.get();
		});

		MetricsUtil.registerGauge(BioComponentType.SN, searchNodeId, "SC_SN_ACTIVE_JOB_COUNT_" + this.capacityGroupId,
				() -> {
					return this.scSnCurrentLoad.get();
				});

		CommonLogger.STATUS_LOG.info("In SearchNodeCapacityGroupLoadInfo(): instanceIndex: " + instanceIndex
				+ ", searchNodeId: " + searchNodeId + ", capacityGroupId: " + capacityGroupId + ", snCurrentLoad: "
				+ snCurrentLoad.get() + ", scSnCurrentLoad: " + scSnCurrentLoad.get() + ", snOnlineFlag: "
				+ snOnlineFlag.get() + ", clusterMemberCount: " + clusterMemberCount);
	}

	public void updateParameters(String snGroupId, int searchNodeCapacity, float searchNodeJobOverloadFactor) {
		this.snGroupId = snGroupId;
		this.searchNodeCapacity = searchNodeCapacity;
		this.searchNodeJobOverloadFactor = searchNodeJobOverloadFactor;
		this.calculatedCapacity = (int) Math.ceil(searchNodeCapacity * searchNodeJobOverloadFactor);
		this.clusterMemberCount = Math.max(1, hazelcastInstance.getCluster().getMembers().size());
	}

	public final boolean isSnOnline() {
		// return snOnlineFlag.get() == 1;
		return snOnlineFlagReader.get();
	}

	public final void releaseSlot() {
		lazySlotReleaseSemaphore.release();
		if (modifiedIndexQueue.add(instanceIndex)) {
			waitSemaphore.release();
		}
		lastSlotReleaseTimestampMilli = System.currentTimeMillis();
	}

	public final void releaseSlots(int slots) {
		lazySlotReleaseSemaphore.release(slots);
		if (modifiedIndexQueue.add(instanceIndex)) {
			waitSemaphore.release();
		}
		lastSlotReleaseTimestampMilli = System.currentTimeMillis();
	}

	public final int tryAcquireSlotsForAssignment(int maxSlotsToAcquire, AtomicBoolean isFairAssignmentRequiredFlag,
			DynamicSemaphore acquireSlotConcurrencySemaphore) {
		long startTimestampMilli = System.currentTimeMillis();

		int acquiredSlots = 0;
		int tempScSnCurrentLoad = 0;
		try {
			while (acquiredSlots < maxSlotsToAcquire && lazySlotReleaseSemaphore.tryAcquire()) {
				acquiredSlots++;
			}

			if (acquiredSlots == maxSlotsToAcquire) {
				tempScSnCurrentLoad = (int) scSnCurrentLoad.get();
				return acquiredSlots;
			}

			if (acquireSlotConcurrencySemaphore != null) {
				acquireSlotConcurrencySemaphore.acquireUninterruptibly();
			}

			try {
				Lock lock = searchJobSlotAcquireLockFlag ? jobAssignmentLock : writeLock;
				lock.lock();
				try {
					int availableSlots = Math.min(calculatedCapacity - (int) snCurrentLoad.get(),
							maxSlotsToAcquire - acquiredSlots);
					if (availableSlots <= 0) {
						return acquiredSlots;
					}

					tempScSnCurrentLoad = (int) scSnCurrentLoad.addAndGet(availableSlots);
					snCurrentLoad.addAndGet(availableSlots);

					acquiredSlots += availableSlots;

					return acquiredSlots;
				} finally {
					lock.unlock();
				}
			} finally {
				if (acquireSlotConcurrencySemaphore != null) {
					acquireSlotConcurrencySemaphore.release();
				}
			}
		} finally {
			if (acquiredSlots > 0) {
				lastSlotAcquireTimestampMilli = System.currentTimeMillis();

				if (acquiredSlots < maxSlotsToAcquire && clusterMemberCount > 1
						&& tempScSnCurrentLoad > (Math.max(1, calculatedCapacity / clusterMemberCount))) {
					isFairAssignmentRequiredFlag.set(true);
				}
			}

			if (logger.isDebugEnabled()) {
				logger.debug("In tryAcquireSlotForAssignment: TimeTakenMilli: "
						+ (System.currentTimeMillis() - startTimestampMilli) + " for searchNodeId: " + searchNodeId
						+ ", capacityGroupId: " + capacityGroupId + ", acquiredSlots: " + acquiredSlots
						+ ", scSnCurrentLoad: " + scSnCurrentLoad.get() + ", snCurrentLoad: " + snCurrentLoad.get());
			}
		}
	}

	public final void releaseSlotAssignment() {
		scSnCurrentLoad.decrementAndGet();
		snCurrentLoad.decrementAndGet();
		lastSlotReleaseTimestampMilli = System.currentTimeMillis();
	}

	public synchronized final void releaseScCurrentLoad() {
		while (scSnCurrentLoad.get() > 0) {
			scSnCurrentLoad.decrementAndGet();
			snCurrentLoad.decrementAndGet();
			lastSlotReleaseTimestampMilli = System.currentTimeMillis();
		}
		lazySlotReleaseSemaphore.drainPermits();
	}

	private final void flushLazySlotReleaseSemaphore() {
		if (lazySlotReleaseSemaphore.availablePermits() == 0) {
			return;
		}

		writeLock.lock();
		try {
			int currentValue = lazySlotReleaseSemaphore.drainPermits();
			if (currentValue == 0) {
				return;
			}
			boolean scSnCurrentLoadUpdatedFlag = false;
			boolean snCurrentLoadUpdatedFlag = false;
			try {
				long scSnCurrentLoadValue = scSnCurrentLoad.addAndGet(-currentValue);
				scSnCurrentLoadUpdatedFlag = true;

				long snCurrentLoadValue = snCurrentLoad.addAndGet(-currentValue);
				snCurrentLoadUpdatedFlag = true;

				if (logger.isDebugEnabled()) {
					logger.debug("In flushLazySlotReleaseSemaphore: searchNodeId: " + searchNodeId
							+ ", capacityGroupId: " + capacityGroupId + ", releasedPermitCount: " + currentValue
							+ ", scSnCurrentLoad: " + scSnCurrentLoadValue + ", snCurrentLoad: " + snCurrentLoadValue
							+ ", calculatedCapacity: " + calculatedCapacity);
				}
			} catch (Throwable th) {
				CommonLogger.APP_LOG.error(
						"Error in SearchNodeCapacityGroupLoadInfo.flushLazySlotReleaseSemaphore: " + th.getMessage(),
						th);
				lazySlotReleaseSemaphore.release(currentValue);
				lazySlotReleaseSemaphore.availablePermits();
				if (scSnCurrentLoadUpdatedFlag) {
					try {
						scSnCurrentLoad.addAndGet(currentValue);
					} catch (Throwable th1) {
					}
				}

				if (snCurrentLoadUpdatedFlag) {
					try {
						snCurrentLoad.addAndGet(currentValue);
					} catch (Throwable th1) {
					}
				}
			}
		} finally {
			writeLock.unlock();
		}

	}

	public void setSearchJobSlotAcquireLockFlag(boolean lockDuringSearchJobAssignmentFlag) {
		this.searchJobSlotAcquireLockFlag = lockDuringSearchJobAssignmentFlag;
	}

	public final int getScCurrentLoad() {
		return (int) scSnCurrentLoad.get();
	}

	public final int getScCurrentLoadFromReader() {
		return (int) scSnCurrentLoadReader.get();
	}

	public final int getCurrentLoadFromReader() {
		return (int) snCurrentLoadReader.get();
	}

	public final int getActualFreeSlots() {
		return searchNodeCapacity - (int) snCurrentLoadReader.get();
	}

	public final int getActualFreeSlotsForAssignment() {
		readLock.lock();
		try {
			return searchNodeCapacity - (int) snCurrentLoadReader.get();
		} finally {
			readLock.unlock();
		}
	}

	public final int getCalculatedFreeSlots() {
		return calculatedCapacity - (int) snCurrentLoadReader.get();
	}

	public final int getCalculatedFreeSlotsForAssignment() {
		readLock.lock();
		try {
			return calculatedCapacity - (int) snCurrentLoadReader.get();
		} finally {
			readLock.unlock();
		}
	}

	public boolean autoCorrectSearchNodeSegmentJobCounter(ConcurrentHashMap<String, ScSearchJobInfo> searchJobInfoMap) {
		if ((System.currentTimeMillis() - slotCounterAutoCorrectionTimestampMilli) < TimeUnit.SECONDS.toMillis(30)) {
			return false;
		}

		writeLock.lock();
		try {
			if ((System.currentTimeMillis() - slotCounterAutoCorrectionTimestampMilli) < TimeUnit.SECONDS
					.toMillis(30)) {
				return false;
			}

			try {
				if (lastSlotAcquireTimestampMilli > slotCounterAutoCorrectionTimestampMilli
						|| lastSlotReleaseTimestampMilli > slotCounterAutoCorrectionTimestampMilli) {
					return false;
				}

				long startTimestampMilli = System.currentTimeMillis();

				int currentSegmentJobCount = searchJobInfoMap.values().stream()
						.mapToInt(scSearchJobInfo -> capacityGroupId.equals(scSearchJobInfo.capacityGroupKey)
								? scSearchJobInfo.calculateCurrentPendingSegmentJobsBySearchNodeId(searchNodeId) : 0)
						.sum();

				int slotsToRelease = ((int) scSnCurrentLoad.get()) - lazySlotReleaseSemaphore.availablePermits()
						- currentSegmentJobCount;
				if (slotsToRelease > 0) {
					if (lastSlotAcquireTimestampMilli < startTimestampMilli
							&& lastSlotReleaseTimestampMilli < startTimestampMilli) {
						lazySlotReleaseSemaphore.release(slotsToRelease);
						flushLazySlotReleaseSemaphore();
						CommonLogger.STATUS_LOG
								.info("In autoCorrectSearchNodeSegmentJobCounter after releasing slots for searchNodeId: "
										+ searchNodeId + ", capacityGroupKey: " + capacityGroupId
										+ ", scSnCurrentLoad: " + scSnCurrentLoad.get() + ", snCurrentLoad: "
										+ snCurrentLoad.get() + ", releasedSlotCount: " + slotsToRelease
										+ ", lastSlotAcquireTimestampMilli: " + lastSlotAcquireTimestampMilli
										+ ", lastSlotReleaseTimestampMilli: " + lastSlotReleaseTimestampMilli);
						return true;
					}
				}
			} finally {
				slotCounterAutoCorrectionTimestampMilli = System.currentTimeMillis();
			}
		} finally {
			writeLock.unlock();
		}

		return false;
	}

	@Override
	public final boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof SearchNodeCapacityGroupLoadInfo)) {
			return false;
		}

		SearchNodeCapacityGroupLoadInfo other = (SearchNodeCapacityGroupLoadInfo) obj;

		return searchNodeId.equals(other.searchNodeId) && capacityGroupId.equals(other.capacityGroupId);
	}

	@Override
	public final int hashCode() {
		return (searchNodeId + "_" + capacityGroupId).hashCode();
	}

	@Override
	public final int compareTo(SearchNodeCapacityGroupLoadInfo o) {
		if (this == o) {
			return 0;
		}

		return loadComparator.compare(this, o);
	}

	/** The Constant loadComparator. */
	public static final Comparator<SearchNodeCapacityGroupLoadInfo> loadComparator = new Comparator<SearchNodeCapacityGroupLoadInfo>() {
		@Override
		public int compare(SearchNodeCapacityGroupLoadInfo o1, SearchNodeCapacityGroupLoadInfo o2) {
			if (o1 == o2) {
				return 0;
			} else if (o1 == null) {
				return 1;
			} else if (o2 == null) {
				return -1;
			}

			if (o1.instanceIndex.intValue() == o2.instanceIndex.intValue()) {
				return 0;
			}

			int comp = Integer.compare(o2.getCalculatedFreeSlots(), o1.getCalculatedFreeSlots());
			if (comp == 0) {
				return o1.searchNodeId.compareTo(o2.searchNodeId);
			} else {
				return comp;
			}
		}
	};

	public String getSnGroupId() {
		return snGroupId;
	}

	public void setSnGroupId(String snGroupId) {
		this.snGroupId = snGroupId;
	}

	public int getSearchNodeCapacity() {
		return searchNodeCapacity;
	}

	private static final class AsyncFlusherThread implements Runnable {

		public AsyncFlusherThread() {

		}

		public void run() {
			CommonLogger.STATUS_LOG.info("SearchNodeCapacityGroupLoadInfo.AsyncFlusherThread: started");
			while (!ShutdownHook.isShutdownFlag) {

				try {
					waitSemaphore.acquireUninterruptibly();
					waitSemaphore.drainPermits();

					forkJoinPool.execute(() -> modifiedIndexQueue.parallelStream().forEach(instanceIndex -> {
						try {
							if (modifiedIndexQueue.remove(instanceIndex)) {
								instanceMap.get(instanceIndex).flushLazySlotReleaseSemaphore();
							}
						} catch (Throwable th) {
							CommonLogger.APP_LOG.error(
									"Error in SearchNodeCapacityGroupLoadInfo.AsyncFlusherThread: " + th.getMessage(),
									th);
						}
					}));
				} catch (Throwable th) {
					CommonLogger.APP_LOG.error(
							"Error in SearchNodeCapacityGroupLoadInfo.AsyncFlusherThread: " + th.getMessage(), th);
					Uninterruptibles.sleepUninterruptibly(10, TimeUnit.MILLISECONDS);
				}
			}
			CommonLogger.STATUS_LOG.warn("Exiting SearchNodeCapacityGroupLoadInfo.AsyncFlusherThread: isShutdownFlag: "
					+ ShutdownHook.isShutdownFlag);
		}
	}

}
