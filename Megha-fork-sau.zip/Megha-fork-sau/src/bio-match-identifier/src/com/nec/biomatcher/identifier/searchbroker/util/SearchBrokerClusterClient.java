package com.nec.biomatcher.identifier.searchbroker.util;

import java.net.URI;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.hazelcast.client.HazelcastClient;
import com.hazelcast.client.config.ClientConfig;
import com.hazelcast.client.config.ClientNetworkConfig;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.core.IAtomicLong;
import com.hazelcast.core.IQueue;
import com.hazelcast.core.ITopic;
import com.hazelcast.core.LifecycleEvent;
import com.hazelcast.core.LifecycleEvent.LifecycleState;
import com.hazelcast.core.LifecycleListener;
import com.hazelcast.core.Message;
import com.nec.biomatcher.comp.cluster.ClusterInstanceRegistry;
import com.nec.biomatcher.comp.config.BioMatcherConfigService;
import com.nec.biomatcher.comp.config.exception.BioMatcherConfigServiceException;
import com.nec.biomatcher.comp.entities.dataAccess.BioServerInfo;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioComponentType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioConnectionType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioProtocolType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioServerState;
import com.nec.biomatcher.identifier.searchbroker.manager.BioSearchBrokerManager;

/**
 * The Class SearchBrokerClusterClient.
 */
public class SearchBrokerClusterClient implements LifecycleListener {

	/** The Constant logger. */
	private static final Logger logger = Logger.getLogger(SearchBrokerClusterClient.class);

	/** The cleint read write lock. */
	private ReadWriteLock cleintReadWriteLock = new ReentrantReadWriteLock();

	/** The read lock. */
	private Lock readLock = cleintReadWriteLock.readLock();

	/** The write lock. */
	private Lock writeLock = cleintReadWriteLock.writeLock();

	// private BooleanLatch searchBrokerEnabledFlag =
	// BooleanLatch.getInstance("SearchBrokerEnabledFlag", false);

	/** The hazelcast instance. */
	private HazelcastInstance hazelcastInstance;

	/** The notify segment changes to search broker topic. */
	private ITopic<String> notifySegmentChangesToSearchBrokerTopic;

	/** The registered segment data changes listener id. */
	private String registeredSegmentDataChangesListenerId;

	private ITopic<String> notifyOfflineSearchNodeTopic;

	private String registeredOfflineSearchNodeListenerId;

	/** The bio matcher config service. */
	private BioMatcherConfigService bioMatcherConfigService;

	/** The bio search broker manager. */
	private BioSearchBrokerManager bioSearchBrokerManager;

	private SegmentChangeSetReader segmentChangeSetReader;

	/** The search broker id. */
	private String searchBrokerId;

	/**
	 * Instantiates a new search broker cluster client.
	 *
	 * @param searchBrokerId
	 *            the search broker id
	 */
	public SearchBrokerClusterClient(String searchBrokerId) {
		this.searchBrokerId = searchBrokerId;
	}

	/**
	 * Connect.
	 *
	 * @throws Exception
	 *             the exception
	 */
	public void connect() throws Exception {
		if (hazelcastInstance != null) {
			return;
		}

		writeLock.lock();
		try {
			if (hazelcastInstance != null) {
				return;
			}
			List<BioServerInfo> searchControllerList = bioMatcherConfigService
					.getServerInfoListByComponentType(BioComponentType.SC, BioServerState.ACTIVE);
			if (searchControllerList.size() == 0) {
				logger.warn("No Match controllers configured for client to connect");
				return;
			}

			String clusterInstanceId = BioComponentType.SC.name() + "_ControllerCluster";

			ClientConfig clientConfig = new ClientConfig();
			clientConfig.setInstanceName("SB_" + searchBrokerId);
			clientConfig.getGroupConfig().setName(clusterInstanceId).setPassword("nec");

			clientConfig.setProperty("hazelcast.shutdownhook.enabled", "true");

			ClientNetworkConfig clientNetworkConfig = clientConfig.getNetworkConfig();
			clientNetworkConfig.setConnectionAttemptLimit(0);
			clientNetworkConfig.setConnectionAttemptPeriod(10000); // 10 seconds

			for (BioServerInfo searchController : searchControllerList) {
				if (!BioServerState.ACTIVE.equals(searchController.getServerState())) {
					logger.warn(
							"Search controller state is not active for serverId : " + searchController.getServerId());
					continue;
				}

				createDefaultSearchControllerSettings(searchController.getServerId());

				String connectionUrl = bioMatcherConfigService.getServerConnectionUrl(searchController.getServerId(),
						BioComponentType.SC, BioConnectionType.CLUSTER, BioProtocolType.HAZELCAST);
				if (StringUtils.isBlank(connectionUrl)) {
					throw new IllegalArgumentException(
							"Search controller connection url is not configured for serverId: "
									+ searchController.getServerId() + ", BioComponentType: " + BioComponentType.SC
									+ ", connectionType: " + BioConnectionType.CLUSTER + ", protocolType: "
									+ BioProtocolType.HAZELCAST);
				}

				URI clusterMemberUri = new URI(connectionUrl);

				if (clusterMemberUri.getHost() == null || clusterMemberUri.getPort() == 0) {
					throw new IllegalArgumentException(
							"Host and port for Match controller is not properly configured serverId: "
									+ searchController.getServerId() + ", BioComponentType: " + BioComponentType.SC
									+ ", connectionType: " + BioConnectionType.CLUSTER + ", protocolType: "
									+ BioProtocolType.HAZELCAST + ", connectionUrl: " + connectionUrl);
				}

				logger.info("After parsing match controller connectionUrl: " + connectionUrl + ", host: "
						+ clusterMemberUri.getHost() + ", port: " + clusterMemberUri.getPort());

				clientNetworkConfig.addAddress(clusterMemberUri.getHost() + ":" + clusterMemberUri.getPort());
			}

			hazelcastInstance = HazelcastClient.newHazelcastClient(clientConfig);

			ClusterInstanceRegistry.register(BioComponentType.SB, hazelcastInstance);

			hazelcastInstance.getLifecycleService().addLifecycleListener(this);

			notifySegmentChangesToSearchBrokerTopic = hazelcastInstance
					.getTopic("NotifySegmentChangesToSearchBrokerTopic");

			registeredSegmentDataChangesListenerId = notifySegmentChangesToSearchBrokerTopic
					.addMessageListener(new SegmentDataChangesListener(searchBrokerId));

			notifyOfflineSearchNodeTopic = hazelcastInstance.getTopic("NotifyOfflineSearchNodeTopic");

			registeredOfflineSearchNodeListenerId = notifyOfflineSearchNodeTopic
					.addMessageListener((Message<String> message) -> {
						String offlineSearchNodeId = message.getMessageObject();

						if (bioSearchBrokerManager.getOnlineSearchNodeIdList().contains(offlineSearchNodeId)) {
							bioSearchBrokerManager.notifySearchNodeOffline(offlineSearchNodeId);
						}
					});

			notifyConnected();

			logger.info("Search Broker Cluster client created successfully");
		} finally {
			writeLock.unlock();
		}
	}

	/**
	 * Creates the default search controller settings.
	 *
	 * @param searchControllerId
	 *            the search controller id
	 * @throws BioMatcherConfigServiceException
	 *             the bio matcher config service exception
	 */
	private void createDefaultSearchControllerSettings(String searchControllerId)
			throws BioMatcherConfigServiceException {
		BioServerInfo searchController = bioMatcherConfigService.getServerInfo(searchControllerId);

		bioMatcherConfigService.createServerConnnections(searchController.getServerId(),
				searchController.getServerHost(), searchController.getComponentType());
	}

	/**
	 * Notified after connecting to Cluster Server.
	 */
	private void notifyConnected() {
		logger.info("In SearchBrokerClusterClient.notifyConnected : searchBrokerId: " + searchBrokerId);

		segmentChangeSetReader.reloadCentralSegmentVersionMap(searchBrokerId);

		bioSearchBrokerManager.getSearchBrokerConnectedFlag().setFlag(true);
	}

	/**
	 * Notified if disconnected from Cluster Server.
	 */
	private void notifyDisconnected() {
		logger.info("In SearchBrokerClusterClient.notifyDisconnected : searchBrokerId: " + searchBrokerId);

		bioSearchBrokerManager.getSearchBrokerConnectedFlag().setFlag(false);
	}

	@Override
	public void stateChanged(LifecycleEvent event) {
		logger.info("In SearchBrokerClusterClient: received LifecycleEvent: " + event.getState());

		if (LifecycleState.CLIENT_CONNECTED.equals(event.getState())) {
			notifyConnected();
		} else if (LifecycleState.CLIENT_DISCONNECTED.equals(event.getState())) {
			notifyDisconnected();
		}
	}

	public ITopic<String> getNotifySearchNodeSegmentVersionToControllerTopic() {
		return hazelcastInstance.getTopic("NotifySearchNodeSegmentVersionToControllerTopic");
	}

	public IQueue<byte[]> getSearchNodeGroupJobQueue(String searchNodeGroupId) {
		return hazelcastInstance.getQueue("SearchNodeGroupJobQueue_" + searchNodeGroupId);
	}

	public ITopic<String> getNotifyStrictSyncCompleteTopic() {
		return hazelcastInstance.getTopic("NotifyStrictSyncCompleteTopic");
	}

	/**
	 * Sets the search node online flag.
	 *
	 * @param searchNodeId
	 *            the search node id
	 * @param flag
	 *            the flag
	 */
	public void setSearchNodeOnlineFlag(String searchNodeId, boolean flag) {
		IAtomicLong onlineFlagRef = hazelcastInstance.getAtomicLong("SEARCH_NODE_ONLINE_FLAG_" + searchNodeId);
		onlineFlagRef.set(flag ? 1 : 0);
	}

	public boolean isSearchNodeOnline(String searchNodeId) {
		IAtomicLong onlineFlagRef = hazelcastInstance.getAtomicLong("SEARCH_NODE_ONLINE_FLAG_" + searchNodeId);

		return onlineFlagRef.get() == 1L;
	}

	public IAtomicLong getSearchNodeOnlineFlagRef(String searchNodeId) {
		IAtomicLong onlineFlagRef = hazelcastInstance.getAtomicLong("SEARCH_NODE_ONLINE_FLAG_" + searchNodeId);
		return onlineFlagRef;
	}

	/**
	 * Adds the search node load.
	 *
	 * @param searchNodeId
	 *            the search node id
	 * @param loadValue
	 *            the load value
	 * @return the int
	 */
	public int addSearchNodeLoad(String searchNodeId, int loadValue) {
		IAtomicLong load = hazelcastInstance.getAtomicLong("SEARCH_NODE_LOAD_COUNT_" + searchNodeId);
		return (int) load.addAndGet(loadValue);
	}

	public void setBioMatcherConfigService(BioMatcherConfigService bioMatcherConfigService) {
		this.bioMatcherConfigService = bioMatcherConfigService;
	}

	public void setBioSearchBrokerManager(BioSearchBrokerManager bioSearchBrokerManager) {
		this.bioSearchBrokerManager = bioSearchBrokerManager;
	}

	public void setSegmentChangeSetReader(SegmentChangeSetReader segmentChangeSetReader) {
		this.segmentChangeSetReader = segmentChangeSetReader;
	}

}
