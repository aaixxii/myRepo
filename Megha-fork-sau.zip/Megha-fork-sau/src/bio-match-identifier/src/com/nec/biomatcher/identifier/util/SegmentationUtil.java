package com.nec.biomatcher.identifier.util;

import java.io.ByteArrayOutputStream;
import java.io.DataOutput;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FilterOutputStream;
import java.lang.reflect.Type;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.function.Function;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;

import com.google.common.base.Throwables;
import com.google.common.collect.Range;
import com.google.common.collect.RangeSet;
import com.google.common.collect.Sets;
import com.google.common.io.LittleEndianDataOutputStream;
import com.google.gson.ExclusionStrategy;
import com.google.gson.FieldAttributes;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.config.BioMatcherConfigService;
import com.nec.biomatcher.comp.entities.dataAccess.BioMatcherSegmentInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BiometricEventInfo;
import com.nec.biomatcher.comp.manager.BioMatchManagerService;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateParser;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateUtil;
import com.nec.biomatcher.comp.template.storage.TemplateDataService;
import com.nec.biomatcher.core.framework.common.FileUtils;
import com.nec.biomatcher.core.framework.common.GsonSerializer;
import com.nec.biomatcher.core.framework.common.PFLogger;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;
import com.nec.biomatcher.spec.transfer.datadistribution.SearchBrokerSegmentNotificationDto;
import com.nec.biomatcher.spec.transfer.event.BiometricEventPhase;
import com.nec.biomatcher.spec.transfer.event.BiometricEventStatus;
import com.nec.biomatcher.spec.transfer.model.KeyValuePair;
import com.nec.biomatcher.spec.transfer.model.RangeDto;

/**
 * The Class SegmentationUtil.
 */
public class SegmentationUtil {

	/** The Constant logger. */
	private static final Logger logger = Logger.getLogger(SegmentationUtil.class);

	public static final Type GSON_SEG_CHANGESET_INDEX_TYPE = new TypeToken<List<BiometricEventInfo>>() {
	}.getType();
	public static final Set<String> SEG_CHANGESET_REQUIRED_FIELDS = Sets.newHashSet("biometricId", "status", "phase",
			"templateDataKey", "dataVersion");
	public static final Gson SEG_CHANGESET_GSON_SERIALIZER = new GsonBuilder()
			.setExclusionStrategies(new SegmentChangesetGsonExclusionStrategy()).create();
	public static final Function<Integer, Path> GET_SEGMENT_FILE_PATH_FUNCTION = buildGetSegmentFilePathFunction();

	private static String SEGMENT_CHANGE_SET_DEFAULT_STORAGE_PATH = null;

	private static BioParameterService bioParameterService;

	private static BioMatcherConfigService bioMatcherConfigService;

	private static TemplateDataService templateDataService;

	public static final class SegmentChangeSetConstants {
		public static final int HEADER_SEGMENT_ID_POS = 0;
		public static final int HEADER_TEMPLATE_TYPE_POS = HEADER_SEGMENT_ID_POS + Integer.BYTES;
		public static final int HEADER_START_SEGMENT_VERSION_POS = HEADER_TEMPLATE_TYPE_POS + Integer.BYTES;
		public static final int HEADER_END_SEGMENT_VERSION_POS = HEADER_START_SEGMENT_VERSION_POS + Long.BYTES;
		public static final int HEADER_RECORD_COUNT_POS = HEADER_END_SEGMENT_VERSION_POS + Long.BYTES;
		public static final int HEADER_CHANGESET_CONTENT_SIZE_POS = HEADER_RECORD_COUNT_POS + Integer.BYTES;
		public static final int SEGMENT_CHANGESET_CONTENT_POS = HEADER_CHANGESET_CONTENT_SIZE_POS + Integer.BYTES;

		public static final byte[] EMPTY_HEADER_BYTES = new byte[SEGMENT_CHANGESET_CONTENT_POS];
	}

	public static final class SegmentFileHeaderConstants {
		public static final int HEADER_TEMPLATE_TYPE_CODE_POS = 0;
		public static final int HEADER_START_BIOMETRIC_ID_POS = HEADER_TEMPLATE_TYPE_CODE_POS + Integer.BYTES;
		public static final int HEADER_END_BIOMETRIC_ID_POS = HEADER_START_BIOMETRIC_ID_POS + Long.BYTES;
		public static final int HEADER_SEGMENT_VERSION_ID_POS = HEADER_END_BIOMETRIC_ID_POS + Long.BYTES;
		public static final int HEADER_MAX_EVENT_COUNT_POS = HEADER_SEGMENT_VERSION_ID_POS + Long.BYTES;
		public static final int HEADER_PAD3_POS = HEADER_MAX_EVENT_COUNT_POS + Byte.BYTES;
		public static final int HEADER_SIZE = HEADER_PAD3_POS + 3;

		public static final byte[] EMPTY_HEADER_BYTES = new byte[HEADER_SIZE];
	}

	public static final Path getSegmentChangeSetFolderPath(Integer binId, Integer segmentId) {
		try {
			if (SEGMENT_CHANGE_SET_DEFAULT_STORAGE_PATH == null) {
				synchronized (SegmentationUtil.class) {
					if (SEGMENT_CHANGE_SET_DEFAULT_STORAGE_PATH == null) {
						SEGMENT_CHANGE_SET_DEFAULT_STORAGE_PATH = new File(System.getProperty("user.home"),
								"storage/segchangesets/data/").getAbsolutePath();
					}
				}
			}

			String path = getBioParameterService().getParameterValue("SEGMENT_CHANGE_SET_STORAGE_PATH", "DEFAULT",
					SEGMENT_CHANGE_SET_DEFAULT_STORAGE_PATH);

			Path segChangeSetFolderPath = Paths.get(path, binId.toString(), segmentId.toString());

			return segChangeSetFolderPath;
		} catch (Throwable th) {
			throw Throwables.propagate(th);
		}
	}

	public static final Path getSegmentChangeSetCurrentHourPath(Integer binId, Integer segmentId, Integer currentHour) {
		try {
			Path segChangeSetFolderPath = getSegmentChangeSetFolderPath(binId, segmentId);

			Path segChangeSetCurrentHourFolderPath = Paths.get(segChangeSetFolderPath.toString(),
					String.valueOf(currentHour));

			return segChangeSetCurrentHourFolderPath;
		} catch (Throwable th) {
			throw Throwables.propagate(th);
		}
	}

	public static final Path getSearchBrokerNotificationFolderPath(Integer binId, Integer segmentId) {
		try {
			Path path = getSegmentChangeSetFolderPath(binId, segmentId);

			path = Paths.get(path.toString(), "sb_sync_notifications");

			return path;
		} catch (Throwable th) {
			throw Throwables.propagate(th);
		}
	}

	private static final class SegmentChangesetGsonExclusionStrategy implements ExclusionStrategy {
		public boolean shouldSkipField(FieldAttributes f) {
			if (f.getDeclaringClass() == BiometricEventInfo.class) {
				return !SEG_CHANGESET_REQUIRED_FIELDS.contains(f.getName());
			}
			return false;
		}

		public boolean shouldSkipClass(Class<?> clazz) {
			return false;
		}
	};

	public static final Path getSegmentChangeSetFilePath(Integer binId, Integer segmentId, long segmentVersion,
			Integer currentHour, String ext) {

		Path segChangeSetFolderPath = getSegmentChangeSetCurrentHourPath(binId, segmentId, currentHour);

		segmentVersion = Math.max(1, segmentVersion);

		Path segChangeSetFilePath = Paths.get(segChangeSetFolderPath.toString(),
				segmentId + "_" + segmentVersion + "." + ext);

		return segChangeSetFilePath;
	}

	public static final void saveSegmentCanngeSetIndexFile(Integer binId, Integer segmentId,
			long firstAssignedEventDataVersion, List<BiometricEventInfo> biometricEventInfoList) {
		if (biometricEventInfoList == null) {
			return;
		}
		Path segChangeSetIndexFilePath = null;
		try {
			SegmentChangeSetIndexInfo segmentChangeSetIndexInfo = new SegmentChangeSetIndexInfo(biometricEventInfoList);
			String json = GsonSerializer.toJson(segmentChangeSetIndexInfo);
			if (json != null) {
				segChangeSetIndexFilePath = getSegmentChangeSetFilePath(binId, segmentId, firstAssignedEventDataVersion,
						Calendar.getInstance().get(Calendar.HOUR_OF_DAY), "idx");
				FileUtils.saveFile(segChangeSetIndexFilePath, json.getBytes(StandardCharsets.UTF_8));
			}
		} catch (Throwable th) {
			logger.error(
					"Error in saveSegmentCanngeSetIndexFile: binId: " + binId + ", segmentId: " + segmentId
							+ ", firstAssignedEventDataVersion: " + firstAssignedEventDataVersion
							+ ", segChangeSetIndexFilePath: " + segChangeSetIndexFilePath + " : " + th.getMessage(),
					th);
		}
	}

	public static KeyValuePair<Path, byte[]> saveSegmentChangeSetFile(final Integer binId, final Integer segmentId,
			final Long lastSyncSegmentVersion, final List<BiometricEventInfo> biometricEventInfoList,
			final List<Long> errorDataVersionIdList, MeghaTemplateParser meghaTemplateParser) {
		final int templateSize = meghaTemplateParser.getTemplateDataSize();
		final int templateTypeCode = meghaTemplateParser.getTemplateType().getTemplateTypeCode();

		int recordCount = 0;
		long startSegmentVersion = Long.MAX_VALUE;
		long endSegmentVersion = Long.MIN_VALUE;
		int maxBufferSize = biometricEventInfoList.size() * templateSize;

		Path segChangeSetFilePath = null;

		ByteArrayOutputStream baos = new ByteArrayOutputStream(maxBufferSize);
		FilterOutputStream fos = MeghaTemplateUtil.DEFAULT_BYTE_ORDER == ByteOrder.BIG_ENDIAN
				? new DataOutputStream(baos) : new LittleEndianDataOutputStream(baos);
		DataOutput output = (DataOutput) fos;

		int segmentChangeSetDataSize = 0;

		PFLogger.start();
		try {
			TemplateDataService templateDataService = getTemplateDataService();

			output.write(SegmentChangeSetConstants.EMPTY_HEADER_BYTES);

			for (BiometricEventInfo biometricEventInfo : biometricEventInfoList) {
				if (biometricEventInfo.getBiometricId() <= 0) {
					continue;
				}

				byte[] templateDataBuff = null;

				if (BiometricEventStatus.ACTIVE.equals(biometricEventInfo.getStatus())
						&& (BiometricEventPhase.PENDING_SYNC.equals(biometricEventInfo.getPhase())
								|| BiometricEventPhase.SYNC_COMPLETED.equals(biometricEventInfo.getPhase()))) {
					// Suppressing the below errors otherwise cannot move
					// forward
					try {
						templateDataBuff = templateDataService.getTemplateData(biometricEventInfo.getTemplateDataKey());
						if (templateDataBuff == null) {
							throw new Exception("templateDataBuff is null");
						} else if (templateDataBuff.length != templateSize) {
							throw new Exception("templateDataBuff size mismatch,  templateDataBuffSize: "
									+ templateDataBuff.length + ", templateSize: " + templateSize);
						} else if (templateDataBuff[1] != (byte) templateTypeCode) {
							throw new Exception("templateTypeCode mismatch,  templateDataTemplateTypeCode: "
									+ templateDataBuff[1] + ", templateDefTemplateTypeCode: " + templateTypeCode);
						} else {
							Long templateBiometricId = meghaTemplateParser.getBiometricId(
									ByteBuffer.wrap(templateDataBuff).order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER));
							if (!biometricEventInfo.getBiometricId().equals(templateBiometricId)) {
								throw new Exception("biometricId mismatch,  templateDataBiometricId: "
										+ templateBiometricId + ", biometricEventBiometricId: "
										+ biometricEventInfo.getBiometricId());
							}
						}
					} catch (Throwable th) {
						templateDataBuff = null;
						errorDataVersionIdList.add(biometricEventInfo.getDataVersion());
						logger.error(
								"Error detected in getCachedSegmentChangesAfter during getTemplateData for biometricId : "
										+ biometricEventInfo.getBiometricId() + ", templateDataKey: "
										+ biometricEventInfo.getTemplateDataKey() + " : " + th.getMessage(),
								th);
					}
				}

				if (templateDataBuff != null) {
					output.writeLong(biometricEventInfo.getDataVersion());
					output.writeByte(0);
					output.writeLong(biometricEventInfo.getBiometricId());
					output.write(templateDataBuff);
				} else {
					output.writeLong(biometricEventInfo.getDataVersion());
					output.writeByte(1);
					output.writeLong(biometricEventInfo.getBiometricId());
				}

				startSegmentVersion = Math.min(startSegmentVersion, biometricEventInfo.getDataVersion());
				endSegmentVersion = Math.max(endSegmentVersion, biometricEventInfo.getDataVersion());

				recordCount++;
			}
			fos.close();
			baos.close();

			if (recordCount > 0) {
				byte segmentChangeSetData[] = baos.toByteArray();
				ByteBuffer changeSetBuffer = ByteBuffer.wrap(segmentChangeSetData)
						.order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);
				changeSetBuffer.position(0);

				changeSetBuffer.putInt(segmentId);
				changeSetBuffer.putInt(templateTypeCode);
				changeSetBuffer.putLong(startSegmentVersion);
				changeSetBuffer.putLong(endSegmentVersion);
				changeSetBuffer.putInt(recordCount);
				changeSetBuffer
						.putInt(segmentChangeSetData.length - SegmentChangeSetConstants.EMPTY_HEADER_BYTES.length);

				segChangeSetFilePath = SegmentationUtil.getSegmentChangeSetFilePath(binId, segmentId,
						lastSyncSegmentVersion + 1, Calendar.getInstance().get(Calendar.HOUR_OF_DAY), "dat");

				FileUtils.saveFile(segChangeSetFilePath, segmentChangeSetData);

				segmentChangeSetDataSize = segmentChangeSetData.length;

				return new KeyValuePair<>(segChangeSetFilePath, segmentChangeSetData);
			}
		} catch (Throwable th) {
			logger.error("Error in createSegmentChangeSetFile: for segmentId : " + segmentId + ", segmentVersion: "
					+ ", recordCount: " + recordCount + ", startSegmentVersion: " + startSegmentVersion
					+ ", endSegmentVersion: " + endSegmentVersion + " : " + th.getMessage(), th);
		} finally {
			PFLogger.end("After creating segment changeset file for segmentId : " + segmentId
					+ ", lastSyncSegmentVersion: " + lastSyncSegmentVersion + ", recordCount: " + recordCount
					+ ", startSegmentVersion: " + startSegmentVersion + ", endSegmentVersion: " + endSegmentVersion
					+ ", segChangeSetFilePath: " + segChangeSetFilePath + ", segmentChangeSetDataSize: "
					+ segmentChangeSetDataSize);
			IOUtils.closeQuietly(fos);
			IOUtils.closeQuietly(baos);
		}

		return null;
	}

	public static final void saveNotificationsFromSearchBroker(Integer binId, Integer segmentId,
			RangeSet<Long> segmentVersionRangeSet, List<Long> corruptedSegmentVersionIdSet) {
		try {
			SearchBrokerSegmentNotificationDto notificationDto = new SearchBrokerSegmentNotificationDto();

			if (corruptedSegmentVersionIdSet != null && corruptedSegmentVersionIdSet.size() > 0) {
				notificationDto.setSegmentId(segmentId);
				notificationDto.setCorruptedDataVersionIdList(corruptedSegmentVersionIdSet);
			}

			if (segmentVersionRangeSet != null && !segmentVersionRangeSet.isEmpty()) {
				List<RangeDto> rangeDtoList = new ArrayList<>();

				for (Range<Long> segmentVersionRange : segmentVersionRangeSet.asRanges()) {
					if (segmentVersionRange.hasLowerBound() == false || segmentVersionRange.hasUpperBound() == false) {
						continue;
					}

					// When getting range with discreat longs, upperbound value
					// is returned with upperbound+1, so we need to decrement it
					// while using it
					rangeDtoList.add(
							new RangeDto(segmentVersionRange.lowerEndpoint(), segmentVersionRange.upperEndpoint() - 1));
				}

				if (rangeDtoList.size() > 0) {
					notificationDto.setSegmentId(segmentId);
					notificationDto.setSyncCompletedVersionIdRangeList(rangeDtoList);
				}
			}

			if (notificationDto.getSegmentId() == null) {
				return;
			}

			String json = GsonSerializer.toJson(notificationDto);
			if (json != null) {
				Path path = getSearchBrokerNotificationFolderPath(binId, segmentId);
				path = Paths.get(path.toString(), UUID.randomUUID().toString() + ".dat");
				FileUtils.saveFile(path, json.getBytes(StandardCharsets.UTF_8));
			}
		} catch (Throwable th) {
			logger.error("Error in saveNotificationsFromSearchBroker: binId: " + binId + ", segmentId: " + segmentId
					+ " : " + th.getMessage(), th);
		}
	}

	public static final SearchBrokerSegmentNotificationDto getSearchBrokerSegmentNotification(
			Path searchBrokerSegmentNotificationFilePath) {
		String json = null;
		try {
			if (Files.isReadable(searchBrokerSegmentNotificationFilePath)) {
				byte data[] = Files.readAllBytes(searchBrokerSegmentNotificationFilePath);
				json = new String(data, StandardCharsets.UTF_8);
				SearchBrokerSegmentNotificationDto notificationDto = GsonSerializer.fromJson(json,
						SearchBrokerSegmentNotificationDto.class);
				return notificationDto;
			}
		} catch (Throwable th) {
			try {
				long retentionTimeStampMilli = System.currentTimeMillis() - 1000;
				if (Files.getLastModifiedTime(searchBrokerSegmentNotificationFilePath)
						.toMillis() < retentionTimeStampMilli) {
					logger.error(
							"Error in getSearchBrokerSegmentNotification: searchBrokerSegmentNotificationFilePath: "
									+ searchBrokerSegmentNotificationFilePath + ", json: " + json + " : "
									+ th.getMessage(),
							th);
					FileUtils.deleteFileQuietly(searchBrokerSegmentNotificationFilePath);
				}
			} catch (Throwable th1) {
				FileUtils.deleteFileQuietly(searchBrokerSegmentNotificationFilePath);
			}
		}
		return null;
	}

	private static final Function<Integer, Path> buildGetSegmentFilePathFunction() {
		Function<Integer, Path> getSegmentFilePathFunction = (segmentId) -> {
			try {
				BioParameterService bioParameterService = SpringServiceManager.getBean("bioParameterService");
				BioMatchManagerService bioMatchManagerService = SpringServiceManager.getBean("bioMatchManagerService");

				BioMatcherSegmentInfo bioMatcherSegmentInfo = bioMatchManagerService.getMatcherSegmentInfo(segmentId);
				if (bioMatcherSegmentInfo == null) {
					logger.error("Invalid segmentId specified, BioMatcherSegmentInfo is not configured for segmentId: "
							+ segmentId);
					throw new RuntimeException(
							"Invalid segmentId specified, BioMatcherSegmentInfo not configured for segmentId: "
									+ segmentId);
				}

				String segmentStorageBasePath = bioParameterService.getParameterValue("FULL_SEGMENT_STORAGE_PATH",
						"DEFAULT",
						new File(System.getProperty("user.home"), "storage/segmentfiles/data/").getAbsolutePath());
				Path targetSegmentFilePath = Paths.get(segmentStorageBasePath,
						bioMatcherSegmentInfo.getBinId().toString(), segmentId.toString());

				return targetSegmentFilePath;
			} catch (Throwable th) {
				logger.error("In getSegmentFilePathFunction: segmentId: " + segmentId + " : " + th.getMessage(), th);
				throw Throwables.propagate(th);
			}
		};

		return getSegmentFilePathFunction; // Memonizer.memonize(getSegmentFilePathFunction);
	}

	private static final BioParameterService getBioParameterService() {
		if (bioParameterService == null) {
			bioParameterService = SpringServiceManager.getBean("bioParameterService");
		}
		return bioParameterService;
	}

	private static final TemplateDataService getTemplateDataService() {
		if (templateDataService == null) {
			templateDataService = SpringServiceManager.getBean("templateDataService");
		}
		return templateDataService;
	}

	private static final BioMatcherConfigService getBioMatcherConfigService() {
		if (bioMatcherConfigService == null) {
			bioMatcherConfigService = SpringServiceManager.getBean("bioMatcherConfigService");
		}
		return bioMatcherConfigService;
	}

}
