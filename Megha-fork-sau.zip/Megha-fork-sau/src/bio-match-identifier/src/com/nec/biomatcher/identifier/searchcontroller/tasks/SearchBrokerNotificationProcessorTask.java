package com.nec.biomatcher.identifier.searchcontroller.tasks;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.DelayQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Stream;

import org.apache.log4j.Logger;

import com.google.common.collect.DiscreteDomain;
import com.google.common.collect.Lists;
import com.google.common.collect.Range;
import com.google.common.collect.RangeSet;
import com.google.common.collect.TreeRangeSet;
import com.google.common.util.concurrent.Uninterruptibles;
import com.hazelcast.core.IAtomicLong;
import com.hazelcast.core.ILock;
import com.nec.biomatcher.comp.bioevent.BiometricEventService;
import com.nec.biomatcher.comp.cluster.ClusterInstance;
import com.nec.biomatcher.comp.cluster.ClusterInstanceRegistry;
import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.config.BioMatcherConfigService;
import com.nec.biomatcher.comp.entities.dataAccess.BiometricEventInfo;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioComponentType;
import com.nec.biomatcher.comp.manager.BioMatchManagerService;
import com.nec.biomatcher.core.framework.common.DelayedItem;
import com.nec.biomatcher.core.framework.common.FileUtils;
import com.nec.biomatcher.core.framework.common.PFLogger;
import com.nec.biomatcher.core.framework.common.ShutdownHook;
import com.nec.biomatcher.core.framework.common.concurrent.ConcurrentSetProcessor;
import com.nec.biomatcher.core.framework.common.concurrent.ConcurrentValuedHashMap;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;
import com.nec.biomatcher.identifier.searchcontroller.manager.BioSearchControllerManager;
import com.nec.biomatcher.identifier.util.SegmentationUtil;
import com.nec.biomatcher.spec.transfer.datadistribution.SearchBrokerSegmentNotificationDto;
import com.nec.biomatcher.spec.transfer.event.BiometricEventPhase;
import com.nec.biomatcher.spec.transfer.model.RangeDto;

public class SearchBrokerNotificationProcessorTask implements Runnable {

	/** The Constant logger. */
	private static final Logger logger = Logger.getLogger(SearchBrokerNotificationProcessorTask.class);

	/** The bio search controller manager. */
	private BioSearchControllerManager bioSearchControllerManager;

	private BiometricEventService biometricEventService;

	private BioMatcherConfigService bioMatcherConfigService;

	private BioParameterService bioParameterService;

	private BioMatchManagerService bioMatchManagerService;

	private ConcurrentSetProcessor<Integer> searchBrokerNotificationProcessor;

	private DelayQueue<DelayedItem<Integer>> segmentIdQueueForSearchBrokerNotification = new DelayQueue<>();

	private ConcurrentValuedHashMap<Integer, RangeSet<Long>> segmentIdSyncCompletedDataVersionRangeSet = new ConcurrentValuedHashMap<>(
			segmentId -> TreeRangeSet.create());

	private ClusterInstance clusterInstance;

	/** The is initialized. */
	private boolean isInitialized = false;

	private static final ConcurrentValuedHashMap<Integer, Long> previousSyncCompletedMatcherNodeSegVersionMap = new ConcurrentValuedHashMap<>(
			segmentId -> -1L);

	/**
	 * Instantiates a new segment change set writer task.
	 */
	public SearchBrokerNotificationProcessorTask() {
	}

	@Override
	public void run() {
		logger.info("In SearchBrokerNotificationProcessorTask.run");
		try {
			if (!isInitialized) {
				init();
			}

			boolean isFirstRunFlag = true;

			while (!ShutdownHook.isShutdownFlag) {
				try {
					if (isFirstRunFlag) {
						searchBrokerNotificationProcessor
								.addAll(bioMatcherConfigService.getSegmentIdBiometricIdInfoMap().keySet());
						isFirstRunFlag = false;
						continue;
					}

					DelayedItem<Integer> segmentIdDelayItem = segmentIdQueueForSearchBrokerNotification.take();
					searchBrokerNotificationProcessor.add(segmentIdDelayItem.getItem());
				} catch (Throwable th) {
					logger.error("Error during SearchBrokerNotificationProcessorTask.run: " + th.getMessage(), th);
					Uninterruptibles.sleepUninterruptibly(500, TimeUnit.MILLISECONDS);
				}
			}
		} catch (Throwable th) {
			logger.error("Error in SearchBrokerNotificationProcessorTask: " + th.getMessage(), th);
		}
	}

	public void processSearchBrokerNotifications(final Integer segmentId) {
		logger.debug("In processSearchBrokerNotifications for segmentId: " + segmentId);
		boolean ignoreSegmentFlag = false;
		long segmentIdDelayItemMilli = TimeUnit.MINUTES.toMillis(3);
		try {
			if (!isInitialized) {
				init();
			}

			if (clusterInstance == null) {
				clusterInstance = ClusterInstanceRegistry.getClusterInstance(BioComponentType.SC);
			}

			boolean isConversionMode = bioParameterService.getParameterValue("SC_CONVERSION_MODE_FLAG", "DEFAULT",
					false);

			segmentIdDelayItemMilli = bioParameterService.getParameterValue(
					"SEARCH_BROKER_NOTIFICATION_PROCESSOR_DELAY_MILLI", "DEFAULT", segmentIdDelayItemMilli);

			segmentIdQueueForSearchBrokerNotification.removeIf(delayItem -> segmentId.equals(delayItem.getItem()));

			ILock lock = clusterInstance.getLock("ProcessSearchBrokerNotificationsLock_" + segmentId);

			boolean acquiredFlag = lock.tryLock();
			if (!acquiredFlag) {
				return;
			}

			try {
				final Integer binId = bioMatcherConfigService.getSegmentIdBinIdMap().get(segmentId);
				if (binId == null) {
					logger.error("Cannot find binId for segmentId: " + segmentId);
					ignoreSegmentFlag = true;
					return;
				}

				Path notificationFolderPath = SegmentationUtil.getSearchBrokerNotificationFolderPath(binId, segmentId);
				if (notificationFolderPath != null && Files.isDirectory(notificationFolderPath)) {
					try (Stream<Path> notificationFilePathStream = Files.list(notificationFolderPath)) {

						final RangeSet<Long> completedDataVersionRangeSet = segmentIdSyncCompletedDataVersionRangeSet
								.getValue(segmentId);
						final TreeSet<Long> corruptedDataVersionIdSet = new TreeSet<>();
						final RangeSet<Long> segmentVersionRangeSet = TreeRangeSet.create();
						final AtomicBoolean hasNotificationData = new AtomicBoolean(false);
						final List<Path> loadedNotificationPathList = new ArrayList<>();

						notificationFilePathStream.forEach((notificationFilePath) -> {
							try {
								SearchBrokerSegmentNotificationDto notificationDto = SegmentationUtil
										.getSearchBrokerSegmentNotification(notificationFilePath);
								if (notificationDto != null) {
									if (notificationDto.hasCorruptedDataVersionIdList()) {
										corruptedDataVersionIdSet
												.addAll(notificationDto.getCorruptedDataVersionIdList());
										hasNotificationData.set(true);
									}

									if (notificationDto.hasSyncCompletedVersionIdRangeList()) {
										List<RangeDto> syncCompletedVersionIdRangeList = notificationDto
												.getSyncCompletedVersionIdRangeList();

										for (RangeDto rangeDto : syncCompletedVersionIdRangeList) {
											Range<Long> newRange = Range
													.closed(rangeDto.getLowerBound(), rangeDto.getUpperBound())
													.canonical(DiscreteDomain.longs());

											if (!completedDataVersionRangeSet.encloses(newRange)) {
												segmentVersionRangeSet.add(newRange);
												hasNotificationData.set(true);
											} else {
												logger.trace("Sync status is already updated for segmentId: "
														+ notificationDto.getSegmentId()
														+ ", dataVersionRange[startDataVersionId: "
														+ newRange.lowerEndpoint() + ":"
														+ (newRange.upperEndpoint() - 1) + "]");
											}
										}
									}
									loadedNotificationPathList.add(notificationFilePath);
								}
							} catch (Throwable th) {
								logger.error("Error in SearchBrokerNotificationProcessorTask: notificationFilePath: "
										+ notificationFilePath + " : " + th.getMessage(), th);
							}
						});

						if (hasNotificationData.get()) {
							biometricEventService.notifySyncCompleted(segmentId, segmentVersionRangeSet,
									corruptedDataVersionIdSet);
							// updateBiometricEventSyncStatus(segmentId,
							// segmentVersionRangeSet,
							// corruptedDataVersionIdSet);

							segmentVersionRangeSet.asRanges().forEach(range -> completedDataVersionRangeSet.add(range));

							Set<Range<Long>> rangeSet = completedDataVersionRangeSet.asRanges();
							int rangeSetSize = rangeSet.size();
							if (rangeSetSize > 1000) {
								RangeSet<Long> rangesToBeRemoved = TreeRangeSet.create();
								for (Range<Long> range : rangeSet) {
									rangesToBeRemoved.add(range);
									rangeSetSize--;
									if (rangeSetSize <= 500) {
										break;
									}
								}
								completedDataVersionRangeSet.removeAll(rangesToBeRemoved);
							}

						}

						loadedNotificationPathList
								.forEach(notificationFilePath -> FileUtils.deleteFileQuietly(notificationFilePath));
					} catch (Throwable th) {
						logger.error("Error in processSearchBrokerNotifications for segmentId: " + segmentId
								+ ", notificationFolderPath: " + notificationFolderPath + " : " + th.getMessage(), th);
					}
				}

				if (!isConversionMode) {
					IAtomicLong checkTimestamp = clusterInstance
							.getAtomicLong("CheckAndResetPendingSyncEventDataVersionTimestamp_" + segmentId);
					if ((checkTimestamp.get() + TimeUnit.MINUTES.toMillis(3)) < System.currentTimeMillis()) {
						Long latestMatcherNodeSegmentVersionId = bioMatchManagerService
								.getMaxMatcherNodeSegmentVersion(segmentId);
						if (latestMatcherNodeSegmentVersionId != null) {
							AtomicBoolean notifySyncCompletedFlag = new AtomicBoolean(false);
							long previousSyncCompletedMatcherNodeSegVersion = previousSyncCompletedMatcherNodeSegVersionMap
									.getValue(segmentId);

							biometricEventService.checkAndResetPendingSyncEventDataVersion(segmentId,
									latestMatcherNodeSegmentVersionId, notifySyncCompletedFlag,
									previousSyncCompletedMatcherNodeSegVersion);
							checkTimestamp.set(System.currentTimeMillis());

							if (notifySyncCompletedFlag.get()) {
								previousSyncCompletedMatcherNodeSegVersionMap.put(segmentId,
										latestMatcherNodeSegmentVersionId);
							}
						} else {
							logger.debug(
									"In processSearchBrokerNotifications: latestMatcherNodeSegmentVersionId is null for segmentId: "
											+ segmentId);
						}
					}
				}

			} finally {
				lock.unlock();
			}
		} catch (Throwable th) {
			logger.error(
					"Error in processSearchBrokerNotifications for segmentId: " + segmentId + " : " + th.getMessage(),
					th);
		} finally {
			if (!ignoreSegmentFlag) {
				segmentIdQueueForSearchBrokerNotification.add(new DelayedItem<>(segmentId, segmentIdDelayItemMilli));
			}
		}
	}

	private void updateBiometricEventSyncStatus(Integer segmentId, RangeSet<Long> segmentVersionRangeSet,
			Set<Long> corruptedSegmentVersionIdList) throws Exception {
		/**
		 * Bulk updates are causing errors in MYSQL database eventhough its
		 * working fine in Oracle, So updating each record eventough its slow
		 * process.
		 */

		if (corruptedSegmentVersionIdList != null && corruptedSegmentVersionIdList.size() > 0) {
			List<List<Long>> corruptedSegmentVersionIdPartList = Lists
					.partition(new ArrayList<>(corruptedSegmentVersionIdList), 1000);
			for (List<Long> corruptedSegmentVersionIdPart : corruptedSegmentVersionIdPartList) {
				if (corruptedSegmentVersionIdPart.size() > 0) {
					PFLogger.start();
					int totalRecordsProcessed = 0;
					try {
						List<BiometricEventInfo> biometricEventInfoList = biometricEventService
								.getBiometricEventInfoListBySegmentIdVersionList(segmentId,
										corruptedSegmentVersionIdPart, BiometricEventPhase.PENDING_SYNC);
						for (BiometricEventInfo biometricEventInfo : biometricEventInfoList) {
							biometricEventService.notifySyncCompleted(biometricEventInfo.getBiometricId(),
									biometricEventInfo.getDataVersion(), BiometricEventPhase.PENDING_SYNC,
									BiometricEventPhase.SYNC_ERROR);
							totalRecordsProcessed++;
						}
					} finally {
						PFLogger.end(" After updating for segmentId: " + segmentId + ", corruptedSegmentVersionIdSize: "
								+ corruptedSegmentVersionIdPart.size() + ", newPhase: "
								+ BiometricEventPhase.SYNC_ERROR.name() + ", totalRecordsProcessed: "
								+ totalRecordsProcessed);
					}
				}
			}
		}

		if (segmentVersionRangeSet != null) {
			for (Range<Long> segmentVersionRange : segmentVersionRangeSet.asRanges()) {
				if (segmentVersionRange.hasLowerBound() == false || segmentVersionRange.hasUpperBound() == false) {
					continue;
				}
				long startDataVersion = segmentVersionRange.lowerEndpoint();

				// When getting range with discreet longs, upperbound value is
				// returned with upperbound+1, so we need to decrement it while
				// using it
				long endDataVersion = segmentVersionRange.upperEndpoint() - 1;

				if (startDataVersion <= endDataVersion) {
					List<BiometricEventInfo> biometricEventInfoList = null;
					do {
						PFLogger.start();
						int totalRecordsProcessed = 0;
						try {
							// Returned list is ordered by dataVersion
							biometricEventInfoList = biometricEventService
									.getBiometricEventInfoListBySegmentIdVersionRange(segmentId, startDataVersion,
											endDataVersion, BiometricEventPhase.PENDING_SYNC, 1000);
							for (BiometricEventInfo biometricEventInfo : biometricEventInfoList) {
								biometricEventService.notifySyncCompleted(biometricEventInfo.getBiometricId(),
										biometricEventInfo.getDataVersion(), BiometricEventPhase.PENDING_SYNC,
										BiometricEventPhase.SYNC_COMPLETED);
								totalRecordsProcessed++;
								startDataVersion = biometricEventInfo.getDataVersion();
							}
						} finally {
							PFLogger.end(" After updating for segmentId: " + segmentId + ", startDataVersion: "
									+ startDataVersion + ", endDataVersion: " + endDataVersion + ", newPhase: "
									+ BiometricEventPhase.SYNC_COMPLETED.name() + ", totalRecordsProcessed: "
									+ totalRecordsProcessed);
						}
					} while (!biometricEventInfoList.isEmpty());
				}
			}
		}
	}

	/**
	 * Inits the.
	 */
	private final void init() {
		bioSearchControllerManager = SpringServiceManager.getBean("bioSearchControllerManager");
		biometricEventService = SpringServiceManager.getBean("biometricEventService");
		bioMatcherConfigService = SpringServiceManager.getBean("bioMatcherConfigService");
		bioParameterService = SpringServiceManager.getBean("bioParameterService");
		bioMatchManagerService = SpringServiceManager.getBean("bioMatchManagerService");

		searchBrokerNotificationProcessor = bioSearchControllerManager.getSearchBrokerNotificationProcessor();

		isInitialized = true;
	}

}
