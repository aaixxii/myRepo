package com.nec.biomatcher.identifier.searchcontroller.sync.complete.service;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.nec.biomatcher.comp.callback.CallbackService;
import com.nec.biomatcher.comp.inmemory.InMemoryManager;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;
import com.nec.biomatcher.identifier.util.JaxBUtil;
import com.nec.biomatcher.spec.transfer.job.sync.SyncJobResultDto;

/**
 * 
 * @author 000001A006PBP<br/>
 *         StrictSegmentSyncCallbackTask do callback when sync segment is
 *         completed.
 *
 */
public class StrictSegmentSyncCallbackTask implements Runnable {

	private StrictSyncCallbackKey strictkey;
	private SyncJobResultDto response;

	private CallbackService httpCallbackService;
	private CallbackService zmqCallbackService;
	private static final Logger logger = Logger.getLogger(StrictSegmentSyncCallbackTask.class);

	public StrictSegmentSyncCallbackTask(StrictSyncCallbackKey strictKey, SyncJobResultDto response) {
		this.strictkey = strictKey;
		this.response = response;
		init();
	}

	private void init() {
		httpCallbackService = SpringServiceManager.getBean("httpCallbackService");
		zmqCallbackService = SpringServiceManager.getBean("zmqCallbackService");
	}

	@Override
	public void run() {
		strictSynJobCompeletedCallback();
	}

	/**
	 * do callback when sync segment is completed
	 */
	private void strictSynJobCompeletedCallback() {
		String syncJobId = strictkey.getSyncJobId();
		String callbackUrl = strictkey.getCallbackUrl();
		if (StringUtils.isBlank(callbackUrl)) {
			return;
		}
		logger.info("Strict sync job callbacker, callback to " + callbackUrl + "for syncJob:" + syncJobId);
		try {
			JaxBUtil<SyncJobResultDto> jaxb = new JaxBUtil<SyncJobResultDto>();
			String message = jaxb.marshal(SyncJobResultDto.class, response);
			if (callbackUrl.startsWith("http")) {
				httpCallbackService.postCallback(callbackUrl, response == null ? null : message);
			} else {
				zmqCallbackService.postCallback(callbackUrl, response == null ? null : message);
			}
			jaxb = null;
			InMemoryManager.removeFromTimeoutQueue(strictkey.getSyncJobId());
			logger.info("Success send strict sync job callback data to " + callbackUrl + "for syncJob:" + syncJobId);
		} catch (Exception e) {
			String errMsg = "Error during strict sync callback for syncJobId: " + syncJobId + ", callbackUrl: "
					+ callbackUrl;
			logger.error(errMsg, e);
		}

	}

	public void setHttpCallbackService(CallbackService httpCallbackService) {
		this.httpCallbackService = httpCallbackService;
	}

	public void setZmqCallbackService(CallbackService zmqCallbackService) {
		this.zmqCallbackService = zmqCallbackService;
	}

}
