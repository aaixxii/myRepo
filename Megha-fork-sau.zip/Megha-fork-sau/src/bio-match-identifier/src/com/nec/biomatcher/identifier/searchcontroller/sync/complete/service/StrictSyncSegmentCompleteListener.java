package com.nec.biomatcher.identifier.searchcontroller.sync.complete.service;

import org.apache.log4j.Logger;

import com.hazelcast.core.Message;
import com.hazelcast.core.MessageListener;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;

/**
 * 
 * @author 000001A006PBP<br/>
 *         StrictSyncSegmentCompleteListener receive message which segment
 *         report from SN.
 */
public class StrictSyncSegmentCompleteListener implements MessageListener<String> {
	private StrictSegmentSyncCallbackService strictCallbackService;

	public StrictSyncSegmentCompleteListener() {
	}

	private static final Logger logger = Logger.getLogger(StrictSyncSegmentCompleteListener.class);

	@Override
	public void onMessage(Message<String> meg) {
		logger.info("Got message from topic: NotifyStrictSyncCompleteTopic");
		String message = meg.getMessageObject();
		getStrictSegmentSyncCallbackService().updateSnSegmentReportMegToMemory(message);
	}

	public void setStrictSegmentSyncCallbackService(StrictSegmentSyncCallbackService callbackService) {
		this.strictCallbackService = callbackService;
	}

	private StrictSegmentSyncCallbackService getStrictSegmentSyncCallbackService() {
		if (strictCallbackService == null) {
			strictCallbackService = SpringServiceManager.getBean("strictSegmentSyncCallbackService");
		}
		return strictCallbackService;
	}

}
