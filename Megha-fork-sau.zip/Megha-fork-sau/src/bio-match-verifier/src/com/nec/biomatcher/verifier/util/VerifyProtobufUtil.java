package com.nec.biomatcher.verifier.util;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;

import com.google.common.collect.HashMultimap;
import com.google.common.collect.Multimap;
import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;
import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.common.parameter.exception.BioParameterServiceException;
import com.nec.biomatcher.comp.util.CommonProtobufUtil;
import com.nec.biomatcher.spec.transfer.job.verify.MinutiaPairDto;
import com.nec.biomatcher.spec.transfer.job.verify.VerifyBiometricData;
import com.nec.biomatcher.spec.transfer.job.verify.VerifyCandidateResult;
import com.nec.biomatcher.spec.transfer.job.verify.VerifyJobRequestDto;
import com.nec.biomatcher.spec.transfer.job.verify.VerifyJobResultDto;
import com.nec.biomatcher.spec.transfer.job.verify.VerifyModalScore;
import com.nec.biomatcher.spec.transfer.job.verify.VerifyRawScoreDto;
import com.nec.biomatcher.spec.transfer.model.AlgorithmType;
import com.nec.biomatcher.spec.transfer.model.ErrorMessageDto;
import com.nec.biomatcher.spec.transfer.model.ExtractInputParameter;
import com.nec.biomatcher.spec.transfer.model.FaceExtractInputImage;
import com.nec.biomatcher.spec.transfer.model.FeatureData;
import com.nec.biomatcher.spec.transfer.model.FeatureExtractInputImage;
import com.nec.biomatcher.spec.transfer.model.FingerExtractInputImage;
import com.nec.biomatcher.spec.transfer.model.Image;
import com.nec.biomatcher.spec.transfer.model.ImagePosition;
import com.nec.biomatcher.spec.transfer.model.IrisExtractInputImage;
import com.nec.biomatcher.spec.transfer.model.LfmlData;
import com.nec.biomatcher.spec.transfer.model.MatchInputParameter;
import com.nec.biomatcher.spec.transfer.model.Minutia;
import com.nec.biomatcher.spec.transfer.model.MinutiaData;
import com.nec.biomatcher.spec.transfer.model.Modality;
import com.nec.biomatcher.spec.transfer.model.MultiModalExtractInputImage;
import com.nec.biomatcher.spec.transfer.model.PalmExtractInputImage;
import com.nec.biomatcher.spec.transfer.model.PointDto;
import com.nec.biomatcher.spec.transfer.model.ProbeInfoDto;
import com.nec.biomatcher.spec.transfer.model.TemplateInfo;
import com.nec.megha.proto.common.CommonProto.KeyValue;
import com.nec.megha.proto.common.CommonProto.KeyValueGroup;
import com.nec.megha.proto.common.CommonProto.KeyValueGroupHolder;
import com.nec.megha.proto.common.CommonProto.SubType;
import com.nec.megha.proto.verify.VerifyRequestProto.BiometricData;
import com.nec.megha.proto.verify.VerifyRequestProto.BiometricPackage;
import com.nec.megha.proto.verify.VerifyRequestProto.VerifyFeatureData;
import com.nec.megha.proto.verify.VerifyRequestProto.VerifyImageData;
import com.nec.megha.proto.verify.VerifyRequestProto.VerifyRequest;
import com.nec.megha.proto.verify.VerifyResponseProto.MatchedAreaCenter;
import com.nec.megha.proto.verify.VerifyResponseProto.MinutiaPair;
import com.nec.megha.proto.verify.VerifyResponseProto.RawScore;
import com.nec.megha.proto.verify.VerifyResponseProto.VerifyResponse;
import com.nec.megha.proto.verify.VerifyResponseProto.VerifyResponse.Candidate;
import com.nec.megha.proto.verify.VerifyResponseProto.VerifyResponse.ProbeInfo;

/**
 * The Class VerifyProtobufUtil.
 */
public class VerifyProtobufUtil {

	/**
	 * To protobuf.
	 *
	 * @param jobId
	 *            the job id
	 * @param request
	 *            the request
	 * @param bioParameterService
	 *            the bio parameter service
	 * @return the byte[]
	 * @throws BioParameterServiceException
	 *             the bio parameter service exception
	 */

	public static VerifyRequest toProtobuf(String jobId, VerifyJobRequestDto request, String verifyCallbackUrl,
			BioParameterService bioParameterService) throws BioParameterServiceException {
		VerifyRequest.Builder verifyRequestBuilder = VerifyRequest.newBuilder();

		verifyRequestBuilder.setMsgId(jobId);

		verifyRequestBuilder.setResponseEndpoint(verifyCallbackUrl);

		if (request.getJobMode() != null) {
			verifyRequestBuilder.setMode(request.getJobMode());
		}

		//Set<AlgorithmType> algorithmTypeSet = new HashSet<>();
		final List<AlgorithmType> algorithmTypeSet = new CopyOnWriteArrayList<>();

		//Map<AlgorithmType, ExtractInputParameter> algorithmTypeExtractInputParameterMap = new HashMap<>();
		final Multimap<AlgorithmType, ExtractInputParameter> algorithmTypeExtractInputParameterMap =  HashMultimap.<AlgorithmType, ExtractInputParameter>create();

		KeyValueGroupHolder.Builder keyValueGroupHolderBuilder = KeyValueGroupHolder.newBuilder();

		verifyRequestBuilder.setProbe(buildClientBiometricPackage(request.getProbeBiomericData(),
				algorithmTypeExtractInputParameterMap, bioParameterService));

		for (VerifyBiometricData galleryBiomericData : request.getGalleryBiomericDataList()) {
			verifyRequestBuilder.addGallery(buildClientBiometricPackage(galleryBiomericData,
					algorithmTypeExtractInputParameterMap, bioParameterService));
		}

		//algorithmTypeSet.addAll(algorithmTypeExtractInputParameterMap.keySet());
	     if (algorithmTypeExtractInputParameterMap.keys().size() > 1) {
             algorithmTypeSet.clear();
             algorithmTypeSet.addAll(algorithmTypeExtractInputParameterMap.keys());
         }  

		Map<AlgorithmType, MatchInputParameter> algorithmTypeMatchInputParameterMap = null;

		if (request.hasMatchInputParameterList()) {
			algorithmTypeMatchInputParameterMap = request.getMatchInputParameterList().stream()
					.collect(Collectors.toMap(MatchInputParameter::getAlgorithmType, Function.identity(),
							(oldValue, newValue) -> newValue));
			algorithmTypeSet.addAll(algorithmTypeMatchInputParameterMap.keySet());
		} else {
			algorithmTypeMatchInputParameterMap = new HashMap<>();
		}

		algorithmTypeSet.addAll(algorithmTypeMatchInputParameterMap.keySet());

		for (AlgorithmType algorithmType : algorithmTypeSet) {
			Map<String, String> matchInputParameterMap = CommonProtobufUtil.buildMatchInputParameterMap(
					algorithmTypeMatchInputParameterMap.get(algorithmType), algorithmType, bioParameterService);

			KeyValueGroup.Builder matchParamsKeyValueGroupBuilder = KeyValueGroup.newBuilder();
			matchParamsKeyValueGroupBuilder.setGroupName("MATCH_PARAM_" + algorithmType.name());

			for (Entry<String, String> entry : matchInputParameterMap.entrySet()) {
				KeyValue.Builder keyValueBuilder = KeyValue.newBuilder();
				keyValueBuilder.setKey(entry.getKey());
				keyValueBuilder.setValue(entry.getValue());
				matchParamsKeyValueGroupBuilder.addKv(keyValueBuilder.build());
			}

			keyValueGroupHolderBuilder.addParamGroup(matchParamsKeyValueGroupBuilder.build());

			Map<String, String> extractInputParameterMap = CommonProtobufUtil.buildExtractInputParameterMap(
					algorithmTypeExtractInputParameterMap.get(algorithmType), algorithmType, bioParameterService);

			KeyValueGroup.Builder extractParamsKeyValueGroupBuilder = KeyValueGroup.newBuilder();

			switch (algorithmType) {
			case FACE_NEC_S17:
			case FACE_NEC_S18:
			case FACE_NEC_NFV2:
			case FACE_NEC_NFG2:
			case FACE_NEC_NFV3:
			case IRIS_NEC:
			case IRIS_DELTA_ID:
				extractParamsKeyValueGroupBuilder.setGroupName("DETECTION_PARAM_" + algorithmType.name());
				break;

            case FINGER_CMLAF:
            case FINGER_PC3R:
            case FINGER_LFML:
            case FINGER_ELFT:
            case FINGER_ELFML:
            case FINGER_CML:
                extractParamsKeyValueGroupBuilder.setGroupName("EXTRACTION_PARAM_FINGER");
                break;
                
            case FINGER_PC2:
            case FINGER_FMP5:
            case FINGER_FIS:
                extractParamsKeyValueGroupBuilder.setGroupName("EXTRACTION_PARAM_FINGER");
                extractParamsKeyValueGroupBuilder.setAlgType(CommonProtobufUtil.getClientAlgorithmType(algorithmType));
                break;  
                
			case PALM_PC3R:
			case PALM_LFML:
				extractParamsKeyValueGroupBuilder.setGroupName("EXTRACTION_PARAM_PALM");
				break;
			default:
			}

			for (Entry<String, String> entry : extractInputParameterMap.entrySet()) {
				KeyValue.Builder keyValueBuilder = KeyValue.newBuilder();
				keyValueBuilder.setKey(entry.getKey());
				keyValueBuilder.setValue(entry.getValue());
				extractParamsKeyValueGroupBuilder.addKv(keyValueBuilder.build());
			}

			keyValueGroupHolderBuilder.addParamGroup(extractParamsKeyValueGroupBuilder.build());
		}

		verifyRequestBuilder.setKvGroupHolder(keyValueGroupHolderBuilder.build());

		VerifyRequest verifyRequest = verifyRequestBuilder.build();

		return verifyRequest;
	}

	/**
	 * Builds the client biometric package.
	 *
	 * @param biometricData
	 *            the biometric data
	 * @param algorithmTypeExtractInputParameterMap
	 *            the algorithm type extract input parameter map
	 * @param bioParameterService
	 *            the bio parameter service
	 * @return the biometric package
	 * @throws BioParameterServiceException
	 *             the bio parameter service exception
	 */
	private static BiometricPackage buildClientBiometricPackage(VerifyBiometricData biometricData,
	    Multimap<AlgorithmType, ExtractInputParameter> algorithmTypeExtractInputParameterMap,
			BioParameterService bioParameterService) throws BioParameterServiceException {
		BiometricPackage.Builder biometricPackageBuilder = BiometricPackage.newBuilder();
		biometricPackageBuilder.setCandidateId(biometricData.getCandidateId());

		BiometricData.Builder biometricDataBuilder = BiometricData.newBuilder();

		if (CollectionUtils.isEmpty(biometricData.getImageList())
				&& CollectionUtils.isEmpty(biometricData.getFeatureDataList())
				&& CollectionUtils.isEmpty(biometricData.getTemplateInfoList())) {
			throw new IllegalArgumentException("None of the images, templates and feature data are set");
		}

		if (CollectionUtils.isNotEmpty(biometricData.getImageList())) {
			for (FeatureExtractInputImage featureExtractInputImage : biometricData.getImageList()) {
				if (featureExtractInputImage.getExtractInputImage() instanceof PalmExtractInputImage) {
					PalmExtractInputImage palmExtractInputImage = (PalmExtractInputImage) featureExtractInputImage
							.getExtractInputImage();
					for (Image image : palmExtractInputImage.getImages()) {
						SubType imagePosition = SubType.SUB_TYPE_UNKNOWN;
						if (image.getPosition() != null) {
							imagePosition = CommonProtobufUtil.getClientSubType(image.getPosition().getPosition());
						}
						VerifyImageData verifyImageData = buildVerifyImageData(image, Modality.PALM, imagePosition,
								featureExtractInputImage.getAlgorithmTypes());
						biometricDataBuilder.addImage(verifyImageData);
					}
					if (palmExtractInputImage.hasExtractionParameters()) {
						for (ExtractInputParameter extractInputParameter : palmExtractInputImage
								.getExtractionParameters()) {
							algorithmTypeExtractInputParameterMap.put(extractInputParameter.getAlgorithmType(),
									extractInputParameter);
						}
					}
				} else if (featureExtractInputImage.getExtractInputImage() instanceof FaceExtractInputImage) {
					FaceExtractInputImage faceInputImage = (FaceExtractInputImage) featureExtractInputImage
							.getExtractInputImage();

					VerifyImageData verifyImageData = buildVerifyImageData(faceInputImage.getFaceImage(), Modality.FACE,
							SubType.SUB_TYPE_FACE, featureExtractInputImage.getAlgorithmTypes());
					biometricDataBuilder.addImage(verifyImageData);

					if (faceInputImage.hasExtractionParameters()) {
						for (ExtractInputParameter extractInputParameter : faceInputImage.getExtractionParameters()) {
							algorithmTypeExtractInputParameterMap.put(extractInputParameter.getAlgorithmType(),
									extractInputParameter);
						}
					}
				} else if (featureExtractInputImage.getExtractInputImage() instanceof IrisExtractInputImage) {
					IrisExtractInputImage irisInputImage = (IrisExtractInputImage) featureExtractInputImage
							.getExtractInputImage();

					if (irisInputImage.getLeftEyeImage() != null) {
						VerifyImageData verifyImageData = buildVerifyImageData(irisInputImage.getLeftEyeImage(),
								Modality.IRIS, SubType.SUB_TYPE_IRIS_LEFT,
								featureExtractInputImage.getAlgorithmTypes());
						biometricDataBuilder.addImage(verifyImageData);
					}

					if (irisInputImage.getRightEyeImage() != null) {
						VerifyImageData verifyImageData = buildVerifyImageData(irisInputImage.getRightEyeImage(),
								Modality.IRIS, SubType.SUB_TYPE_IRIS_RIGHT,
								featureExtractInputImage.getAlgorithmTypes());
						biometricDataBuilder.addImage(verifyImageData);
					}

					if (irisInputImage.hasExtractionParameters()) {
						for (ExtractInputParameter extractInputParameter : irisInputImage.getExtractionParameters()) {
							algorithmTypeExtractInputParameterMap.put(extractInputParameter.getAlgorithmType(),
									extractInputParameter);
						}
					}
				} else if (featureExtractInputImage.getExtractInputImage() instanceof FingerExtractInputImage) {
					FingerExtractInputImage tenprintFingerInputImage = (FingerExtractInputImage) featureExtractInputImage
							.getExtractInputImage();

					for (Image image : tenprintFingerInputImage.getImages()) {
						SubType imagePosition = SubType.SUB_TYPE_UNKNOWN;
						if (image.getPosition() != null) {
							imagePosition = CommonProtobufUtil.getClientSubType(image.getPosition().getPosition());
						}
						VerifyImageData verifyImageData = buildVerifyImageData(image, Modality.FINGER, imagePosition,
								featureExtractInputImage.getAlgorithmTypes());
						biometricDataBuilder.addImage(verifyImageData);
					}

					if (tenprintFingerInputImage.hasExtractionParameters()) {
						for (ExtractInputParameter extractInputParameter : tenprintFingerInputImage
								.getExtractionParameters()) {
							algorithmTypeExtractInputParameterMap.put(extractInputParameter.getAlgorithmType(),
									extractInputParameter);
						}
					}
				} else if (featureExtractInputImage.getExtractInputImage() instanceof MultiModalExtractInputImage) {
					MultiModalExtractInputImage multiModalExtractInputImage = (MultiModalExtractInputImage) featureExtractInputImage
							.getExtractInputImage();

					FaceExtractInputImage faceInputImage = multiModalExtractInputImage.getFaceExtractInputImage();

					if (faceInputImage != null) {

						VerifyImageData verifyImageData = buildVerifyImageData(faceInputImage.getFaceImage(),
								Modality.FACE, SubType.SUB_TYPE_FACE, featureExtractInputImage.getAlgorithmTypes());
						biometricDataBuilder.addImage(verifyImageData);

						if (faceInputImage.hasExtractionParameters()) {
							for (ExtractInputParameter extractInputParameter : faceInputImage
									.getExtractionParameters()) {
								algorithmTypeExtractInputParameterMap.put(extractInputParameter.getAlgorithmType(),
										extractInputParameter);
							}
						}
					}

					IrisExtractInputImage irisInputImage = multiModalExtractInputImage.getIrisExtractInputImage();

					if (irisInputImage != null) {
						if (irisInputImage.getLeftEyeImage() != null) {
							VerifyImageData verifyImageData = buildVerifyImageData(irisInputImage.getLeftEyeImage(),
									Modality.IRIS, SubType.SUB_TYPE_IRIS_LEFT,
									featureExtractInputImage.getAlgorithmTypes());
							biometricDataBuilder.addImage(verifyImageData);
						}

						if (irisInputImage.getRightEyeImage() != null) {
							VerifyImageData verifyImageData = buildVerifyImageData(irisInputImage.getRightEyeImage(),
									Modality.IRIS, SubType.SUB_TYPE_IRIS_RIGHT,
									featureExtractInputImage.getAlgorithmTypes());
							biometricDataBuilder.addImage(verifyImageData);
						}

						if (irisInputImage.hasExtractionParameters()) {
							for (ExtractInputParameter extractInputParameter : irisInputImage
									.getExtractionParameters()) {
								algorithmTypeExtractInputParameterMap.put(extractInputParameter.getAlgorithmType(),
										extractInputParameter);
							}
						}
					}
					PalmExtractInputImage palmExtractInputImage = multiModalExtractInputImage
							.getPalmExtractInputImage();
					if (palmExtractInputImage != null) {
						for (Image image : palmExtractInputImage.getImages()) {
							SubType imagePosition = SubType.SUB_TYPE_UNKNOWN;
							if (image.getPosition() != null) {
								imagePosition = CommonProtobufUtil.getClientSubType(image.getPosition().getPosition());
							}
							VerifyImageData verifyImageData = buildVerifyImageData(image, Modality.PALM, imagePosition,
									featureExtractInputImage.getAlgorithmTypes());
							biometricDataBuilder.addImage(verifyImageData);
						}
						if (palmExtractInputImage.hasExtractionParameters()) {
							for (ExtractInputParameter extractInputParameter : palmExtractInputImage
									.getExtractionParameters()) {
								algorithmTypeExtractInputParameterMap.put(extractInputParameter.getAlgorithmType(),
										extractInputParameter);
							}
						}
					}

					FingerExtractInputImage fingerExtractInputImage = multiModalExtractInputImage
							.getFingerExtractInputImage();
					if (fingerExtractInputImage != null) {
						for (Image image : fingerExtractInputImage.getImages()) {
							SubType imagePosition = SubType.SUB_TYPE_UNKNOWN;
							if (image.getPosition() != null) {
								imagePosition = CommonProtobufUtil.getClientSubType(image.getPosition().getPosition());
							}
							VerifyImageData verifyImageData = buildVerifyImageData(image, Modality.FINGER,
									imagePosition, featureExtractInputImage.getAlgorithmTypes());
							biometricDataBuilder.addImage(verifyImageData);
						}

						if (fingerExtractInputImage.hasExtractionParameters()) {
							for (ExtractInputParameter extractInputParameter : fingerExtractInputImage
									.getExtractionParameters()) {
								algorithmTypeExtractInputParameterMap.put(extractInputParameter.getAlgorithmType(),
										extractInputParameter);
							}
						}
					}
				}
			}
		}

		if (biometricData.hasFeatureDataList()) {
			for (FeatureData verifyFeatureData : biometricData.getFeatureDataList()) {
				VerifyFeatureData.Builder featureBuilder = VerifyFeatureData.newBuilder();
				featureBuilder.setData(ByteString.copyFrom(verifyFeatureData.getData()));

				featureBuilder
						.setAlgType(CommonProtobufUtil.getClientAlgorithmType(verifyFeatureData.getAlgorithmType()));
				featureBuilder.setSubType(verifyFeatureData.getPosition() == null ? SubType.SUB_TYPE_UNKNOWN
						: CommonProtobufUtil.getClientSubType(verifyFeatureData.getPosition().getPosition()));
				featureBuilder.setModality(
						CommonProtobufUtil.getClientModality(featureBuilder.getSubType(), featureBuilder.getAlgType()));
				featureBuilder.setQuality(0); // TODO: Fix , need to figure out
												// from where quality needs to
												// be passed
				biometricDataBuilder.addFeature(featureBuilder.build());
			}
		}

		if (biometricData.hasTemplateInfoList()) {
			for (TemplateInfo templateInfo : biometricData.getTemplateInfoList()) {
				biometricDataBuilder.addCapsule(ByteString.copyFrom(templateInfo.getTemplateData()));
			}
		}

		biometricPackageBuilder.setBiometricData(biometricDataBuilder.build());

		return biometricPackageBuilder.build();
	}

	/**
	 * Builds the verify image data.
	 *
	 * @param image
	 *            the image
	 * @param modality
	 *            the modality
	 * @param subType
	 *            the sub type
	 * @param algorithmTypes
	 *            the algorithm types
	 * @return the verify image data
	 */
	private static VerifyImageData buildVerifyImageData(Image image, Modality modality, SubType subType,
			List<AlgorithmType> algorithmTypes) {
		com.nec.megha.proto.verify.VerifyRequestProto.VerifyImageData.Builder verifyImageDataBuilder = com.nec.megha.proto.verify.VerifyRequestProto.VerifyImageData
				.newBuilder();

		if (CollectionUtils.isEmpty(algorithmTypes)) {
			throw new IllegalArgumentException("Extract algorithm types are not set for ExtractInputImage");
		}

		for (AlgorithmType algorithmType : algorithmTypes) {
			verifyImageDataBuilder.addAlgType(CommonProtobufUtil.getClientAlgorithmType(algorithmType));
		}

		verifyImageDataBuilder.setImageData(CommonProtobufUtil.buildImageData(image, modality, subType));

		return verifyImageDataBuilder.build();
	}

	/**
	 * Gets the verify job result.
	 *
	 * @param verifyResponse
	 *            the verify response
	 * @return the verify job result
	 * @throws InvalidProtocolBufferException
	 *             the invalid protocol buffer exception
	 */
	public static VerifyJobResultDto getVerifyJobResult(VerifyResponse verifyResponse)
			throws InvalidProtocolBufferException {
		VerifyJobResultDto jobResultDto = new VerifyJobResultDto();

		if (verifyResponse.hasMsgId()) {
			jobResultDto.setJobId(verifyResponse.getMsgId());
		}

		if (verifyResponse.hasMode()) {
			jobResultDto.setJobMode(verifyResponse.getMode());
		}

		if (verifyResponse.getCandidateCount() > 0) {
			for (Candidate candidate : verifyResponse.getCandidateList()) {
				VerifyCandidateResult candidateResult = new VerifyCandidateResult();
				candidateResult.setCandidateId(candidate.getCandidateId());

				if (candidate.getRawScoreCount() > 0 && !candidate.hasDoNotReturnRawScore()) {
					// Build Modality Score map
					Map<Modality, List<RawScore>> modalityRawScoreListMap = new HashMap<>();
					for (RawScore rawScore : candidate.getRawScoreList()) {
						Modality modality = CommonProtobufUtil.getModality(rawScore.getTargetSubType(),
								rawScore.getAlgType());
						List<RawScore> rawScoreList = modalityRawScoreListMap.get(modality);
						if (rawScoreList == null) {
							rawScoreList = new ArrayList<>();
							modalityRawScoreListMap.put(modality, rawScoreList);
						}
						rawScoreList.add(rawScore);
					}

					double fusionScore = 0;

					for (Modality modality : modalityRawScoreListMap.keySet()) {
						VerifyModalScore verifyModalScore = new VerifyModalScore();
						verifyModalScore.setModal(modality);
						double compositeScore = 0;
						for (RawScore rawScore : modalityRawScoreListMap.get(modality)) {
							AlgorithmType algorithmType = CommonProtobufUtil.getAlgorithmType(rawScore.getAlgType());
							VerifyRawScoreDto verifyRawScoreDto = new VerifyRawScoreDto(algorithmType,
									rawScore.getScore(), rawScore.getQuality());

							if (rawScore.hasTargetSubType()) {
								ImagePosition targetPosition = CommonProtobufUtil
										.getImagePosition(rawScore.getTargetSubType());
								verifyRawScoreDto.setPosition(targetPosition);
							}

							if (rawScore.hasProbeSubType()) {
								ImagePosition proboPosition = CommonProtobufUtil
										.getImagePosition(rawScore.getProbeSubType());
								verifyRawScoreDto.setProbePosition(proboPosition);
							}

							compositeScore = Math.max(compositeScore, rawScore.getScore());

							if (rawScore.hasProbeMinutiaDataIndex()) {
								verifyRawScoreDto.setProbeMinutiaDataIndex(rawScore.getProbeMinutiaDataIndex());
							}

							if (rawScore.hasTargetMinutiaDataIndex()) {
								verifyRawScoreDto.setTargetMinutiaDataIndex(rawScore.getTargetMinutiaDataIndex());
							}

							if (rawScore.hasProbeMatchedAreaCenter()) {
								MatchedAreaCenter protboCenter = rawScore.getProbeMatchedAreaCenter();
								PointDto protboPointDto = new PointDto(protboCenter.getX(), protboCenter.getY());
								verifyRawScoreDto.setProbeMatchedAreaCenter(protboPointDto);
							}

							if (rawScore.hasTargetMatchedAreaCenter()) {
								MatchedAreaCenter targetCenter = rawScore.getTargetMatchedAreaCenter();
								PointDto targetPointDto = new PointDto(targetCenter.getX(), targetCenter.getY());
								verifyRawScoreDto.setTargetMatchedAreaCenter(targetPointDto);
							}

							if (rawScore.getMinutiaPairCount() > 0) {
								List<MinutiaPair> minutiaPairList = rawScore.getMinutiaPairList();
								for (MinutiaPair mp : minutiaPairList) {
									MinutiaPairDto mpDto = new MinutiaPairDto();
									if (mp.hasProbeDirection())
										mpDto.setProbe_direction(mp.getProbeDirection());

									if (mp.hasProbeX())
										mpDto.setProbe_x(mp.getProbeX());

									if (mp.hasProbeY())
										mpDto.setProbe_y(mp.getProbeY());

									mpDto.setSimilitude(mp.getSimilitude());

									if (mp.hasTargetDirection())
										mpDto.setTarget_direction(mp.getTargetDirection());

									if (mp.hasTargetX())
										mpDto.setTarget_x(mp.getTargetX());

									if (mp.hasTargetY())
										mpDto.setTarget_y(mp.getTargetY());

									if (mp.hasProbeMinutiaNumber()) {
										mpDto.setProbeMinutiaNumber(mp.getProbeMinutiaNumber());
									}

									if (mp.hasTargetMinutiaNumber()) {
										mpDto.setTargetMinutiaNumber(mp.getTargetMinutiaNumber());
									}
									verifyRawScoreDto.getMinutiaPairList().add(mpDto);
								}
							}
							verifyModalScore.getRawScoreList().add(verifyRawScoreDto);
						}

						verifyModalScore.setCompositeScore(compositeScore);

						candidateResult.getModalScoreList().add(verifyModalScore);

						fusionScore = Math.max(fusionScore, compositeScore);
					}

					candidateResult.setFusionScore(fusionScore);
				} else {
					candidateResult.setFusionScore(0.0d);
					candidateResult.setSuccess(false);
					VerifyModalScore verifyModalScore = new VerifyModalScore();
					verifyModalScore.setCompositeScore(0.0d);
					if (candidate.hasDoNotReturnRawScore()) {
						Modality modality = CommonProtobufUtil.getModality(
								candidate.getRawScoreList().get(0).getTargetSubType(),
								candidate.getRawScoreList().get(0).getAlgType());
						verifyModalScore.setModal(modality);
						candidateResult.getModalScoreList().add(verifyModalScore);
					}					
				}
				jobResultDto.getCandidateResultList().add(candidateResult);
			}
		}

		if (verifyResponse.getProbeInfoCount() > 0) {
			for (ProbeInfo probeInfo : verifyResponse.getProbeInfoList()) {
				ProbeInfoDto probeInfoDto = new ProbeInfoDto();
				probeInfoDto.setAlgorithmType(CommonProtobufUtil.getAlgorithmType(probeInfo.getAlgType()));
				probeInfoDto.setPosition(CommonProtobufUtil.getImagePosition(probeInfo.getSubType()));
				probeInfoDto.setQuality(probeInfo.getQuality());
				jobResultDto.getProbeInfoList().add(probeInfoDto);
			}
		} else {
			List<ProbeInfoDto> probeInfoList = new ArrayList<>();
			ProbeInfoDto probeInfoDto = new ProbeInfoDto();
			probeInfoDto.setPosition(CommonProtobufUtil.getImagePosition(SubType.SUB_TYPE_UNKNOWN));
			probeInfoDto.setQuality(0);
			probeInfoList.add(probeInfoDto);
			jobResultDto.getProbeInfoList().add(probeInfoDto);
		}

		com.nec.megha.proto.common.CommonProto.FeatureData verifyFeature = verifyResponse.getFeature();
		if (verifyFeature != null) {
			AtomicBoolean isupdate = new AtomicBoolean(Boolean.FALSE);

			FeatureData featureData = new FeatureData();
			if (verifyFeature.hasAlgType()) {
				featureData.setAlgorithmType(AlgorithmType.enumOf(verifyFeature.getAlgType().getNumber()));
				isupdate.set(Boolean.TRUE);
			}
			if (verifyFeature.hasData()) {
				featureData.setData(verifyFeature.getData().toByteArray());
				isupdate.set(Boolean.TRUE);
			}
			if (verifyFeature.hasFeType()) {
				featureData.setFeType(verifyFeature.getFeType());
				isupdate.set(Boolean.TRUE);
			}

			if (verifyFeature.getMinutiaDataCount() > 0) {
				for (com.nec.megha.proto.common.CommonProto.MinutiaData md : verifyFeature.getMinutiaDataList()) {
					MinutiaData minutiaDataDto = new MinutiaData();
					Minutia minutiaDto = new Minutia();
					minutiaDto.setAlgorithmType(AlgorithmType.enumOf(md.getMinutia().getAlgType().getNumber()));
					if (md.getMinutia().hasData()) {
						minutiaDto.setData(md.getMinutia().getData().toByteArray());
					}

					if (md.getMinutia().hasMinutiaCount()) {
						minutiaDto.setMinutiaCount(Integer.valueOf(md.getMinutia().getMinutiaCount()));
					}
					if (md.getMinutia().hasQuality()) {
						minutiaDto.setQuality(Integer.valueOf(md.getMinutia().getQuality()));
					}
					if (md.getMinutia().hasQualityCode()) {
						minutiaDto.setQualityCode(md.getMinutia().getQualityCode());
					}					
					minutiaDataDto.setMinutia(minutiaDto);
					minutiaDataDto.setIndex(md.getIndex());
					featureData.getMinutiaDataList().add(minutiaDataDto);
				}
				isupdate.set(Boolean.TRUE);
			}
			
			if (verifyFeature.getLfmlDataCount() > 0) {
				for (com.nec.megha.proto.common.CommonProto.LfmlData lfm : verifyFeature.getLfmlDataList()) {
					LfmlData lfmlDataDto = new LfmlData();
					lfmlDataDto.setIndex(lfm.getIndex());
					com.nec.biomatcher.spec.transfer.model.Skeleton skeleton = new com.nec.biomatcher.spec.transfer.model.Skeleton();
                    skeleton.setAlgorithmType(AlgorithmType.enumOf(lfm.getSkeleton().getAlgType().getNumber()));
                    if (lfm.getSkeleton().hasData()) {
						skeleton.setData(lfm.getSkeleton().getData().toByteArray());
					}

                    lfmlDataDto.setSkeleton(skeleton);                    
					if (lfm.hasMinutia()) {
						Minutia minutiaDto = new Minutia();
						minutiaDto.setAlgorithmType(AlgorithmType.enumOf(lfm.getMinutia().getAlgType().getNumber()));
						minutiaDto.setData(lfm.getMinutia().getData().toByteArray());
						if (lfm.getMinutia().hasMinutiaCount()) {
							minutiaDto.setMinutiaCount(Integer.valueOf(lfm.getMinutia().getMinutiaCount()));
						}
						if (lfm.getMinutia().hasQuality()) {
							minutiaDto.setQuality(Integer.valueOf(lfm.getMinutia().getQuality()));
						}
						if (lfm.getMinutia().hasQualityCode()) {
							minutiaDto.setQualityCode(lfm.getMinutia().getQualityCode());
						}
						lfmlDataDto.setMinutia(minutiaDto);						
					}								
					featureData.getLfmlDataList().add(lfmlDataDto);
				}
				isupdate.set(Boolean.TRUE);
			}

			if (verifyFeature.hasKvGroupHolder()) {
				KeyValueGroupHolder keyValueGroupHolder = verifyFeature.getKvGroupHolder();
				if (keyValueGroupHolder.getParamGroupCount() > 0) {
					for (KeyValueGroup keyValueGroup : keyValueGroupHolder.getParamGroupList()) {
						featureData.getKeyValueGroupList().add(CommonProtobufUtil.buildKeyValueGroup(keyValueGroup));
					}
				}
				isupdate.set(Boolean.TRUE);
			}
			if (isupdate.get()) {
				jobResultDto.setFeatureData(featureData);
			}
		}

		if (verifyResponse.hasStatus() && !verifyResponse.getStatus().getSuccess()) {
			Date now = new Date();
			if (verifyResponse.getStatus().getErrorCount() > 0) {
				for (com.nec.megha.proto.common.CommonProto.Error error : verifyResponse.getStatus().getErrorList()) {
					jobResultDto.getErrorList()
							.add(new ErrorMessageDto(String.valueOf(error.getCode()), error.getMsg(), null, now));
					while (error.hasInner()) {
						error = error.getInner();
						jobResultDto.getErrorList()
								.add(new ErrorMessageDto(String.valueOf(error.getCode()), error.getMsg(), null, now));
					}
				}
			} else {
				jobResultDto.getErrorList()
						.add(new ErrorMessageDto("VC004", "Verify response status success flag is false", null, now));
			}
		}

		return jobResultDto;
	}

}
