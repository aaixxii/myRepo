package jp.co.nec.aim.mm.segment.sync;

import static org.junit.Assert.fail;

import java.util.List;
import java.util.Set;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;
import javax.transaction.Transactional;

import jp.co.nec.aim.dm.message.proto.AimDmMessages.SegmentSyncCommandType;
import jp.co.nec.aim.message.proto.AIMEnumTypes.ComponentType;
import jp.co.nec.aim.message.proto.AIMEnumTypes.SegmentAssignedStateType;
import jp.co.nec.aim.message.proto.AIMMessages.PBSegmentSyncInfo;
import jp.co.nec.aim.mm.exception.AimRuntimeException;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.google.protobuf.ByteString;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class SegUpdatesManagerTest {
	@Resource
	private DataSource dataSource;

	@Resource
	private JdbcTemplate jdbcTemplate;

	private SegUpdatesManager segUpManager;

	@PersistenceContext(unitName = "AIMDB")
	private EntityManager entityManager;

	@Before
	public void setUp() throws Exception {
		segUpManager = new SegUpdatesManager(entityManager, dataSource);
		jdbcTemplate.update("delete from dm_segments");		
		jdbcTemplate.update("delete from mu_segments");
		jdbcTemplate.update("delete from match_units");
		jdbcTemplate.update("delete from person_biometrics");
		jdbcTemplate.update("delete from segments");
		jdbcTemplate.update("delete from segment_change_log");
		jdbcTemplate.update("delete from fe_job_queue");
		jdbcTemplate.update("delete from fe_results");
		jdbcTemplate.update("commit");
	}

	@After
	public void tearDown() throws Exception {
		jdbcTemplate.update("delete from dm_segments");		
		jdbcTemplate.update("delete from mu_segments");
		jdbcTemplate.update("delete from match_units");
		jdbcTemplate.update("delete from person_biometrics");
		jdbcTemplate.update("delete from segments");
		jdbcTemplate.update("delete from segment_change_log");
		jdbcTemplate.update("delete from fe_job_queue");
		jdbcTemplate.update("delete from fe_results");
		jdbcTemplate.update("commit");
	}

	@Test
	public void testGetSegmentUpdates_typeIsNull() {
		Set<Long> set = Sets.newTreeSet();
		set.add(1l);
		try {
			segUpManager.getSegmentUpdates(null, 1l, null, set);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof IllegalArgumentException);
			Assert.assertEquals(e.getMessage(), "ComponentType is null..");
			return;
		}
		fail();

	}

	@Test
	public void testGetSegmentUpdates_typeIsMU_SegDiffIsNull() {
		Set<Long> set = Sets.newTreeSet();
		set.add(1l);

		PBSegmentSyncInfo segInfo = segUpManager.getSegmentUpdates(
				ComponentType.MATCH_UNIT, 1l, null, set);
		Assert.assertNull(segInfo);

	}

	@Test
	public void testGetSegmentUpdates_typeIsMU_OneDiffRecord() {
		jdbcTemplate
				.update("insert into match_units(MU_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','WORKING')");
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(1,1,0,1,26,1,1,1,26)");
		jdbcTemplate
				.update("insert into mu_segments(MU_ID,SEGMENT_ID,RANK)values(1,1,1)");
		byte[] bytes = { 1, 2, 3 };
		Set<Long> set = Sets.newTreeSet();
		set.add(1l);
		List<SegSyncInfos> syncInfos = Lists.newArrayList();
		SegSyncInfos syncInfo = new SegSyncInfos(1L, 1L,1L, true, SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT);
				
		syncInfos.add(syncInfo);
		PBSegmentSyncInfo segInfo = segUpManager.getSegmentUpdates(
				ComponentType.MATCH_UNIT, 1l, syncInfos, set);
		Assert.assertEquals(1, segInfo.getId());
		Assert.assertEquals(SegmentAssignedStateType.SEGMENT_ASSIGNED,
				segInfo.getAssignedState());
		Assert.assertEquals(1, segInfo.getSyncItem().getCatUpInfo()
				.getCatchUpItemsCount());
		Assert.assertEquals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT,
				segInfo.getSyncItem().getCatUpInfo().getCatchUpItems(0)
						.getCommand());
		Assert.assertEquals(1, segInfo.getSyncItem().getCatUpInfo()
				.getCatchUpItems(0).getVersion());
		Assert.assertEquals(ByteString.copyFrom(bytes), segInfo.getSyncItem()
				.getCatUpInfo().getCatchUpItems(0).getBinaryTemplate());

	}

	@Test
	public void testGetSegmentUpdates_typeIsMU_OneDiffRecord_Delete() {
		jdbcTemplate
				.update("insert into match_units(MU_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','WORKING')");
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(1,1,0,1,26,1,1,1,26)");
		jdbcTemplate
				.update("insert into mu_segments(MU_ID,SEGMENT_ID,RANK)values(1,1,1)");
		Set<Long> set = Sets.newTreeSet();
		set.add(1l);
		List<SegSyncInfos> syncInfos = Lists.newArrayList();
		SegSyncInfos syncInfo = new SegSyncInfos(1l, 1l, 1l,
				SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_DELETE);
		syncInfos.add(syncInfo);
		PBSegmentSyncInfo segInfo = segUpManager.getSegmentUpdates(
				ComponentType.MATCH_UNIT, 1l, syncInfos, set);
		Assert.assertEquals(1, segInfo.getId());
		Assert.assertEquals(SegmentAssignedStateType.SEGMENT_ASSIGNED,
				segInfo.getAssignedState());
		Assert.assertEquals(1, segInfo.getSyncItem().getCatUpInfo()
				.getCatchUpItemsCount());
		Assert.assertEquals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_DELETE,
				segInfo.getSyncItem().getCatUpInfo().getCatchUpItems(0)
						.getCommand());
		Assert.assertEquals(1, segInfo.getSyncItem().getCatUpInfo()
				.getCatchUpItems(0).getVersion());
		Assert.assertEquals(1, segInfo.getSyncItem().getCatUpInfo()
				.getCatchUpItems(0).getBiometricsId());

	}

	@Test
	public void testGetSegmentUpdates_typeIsDM_SegDiffIsNull() {
		Set<Long> set = Sets.newTreeSet();
		set.add(1l);

		PBSegmentSyncInfo segInfo = segUpManager.getSegmentUpdates(
				ComponentType.DATA_MANAGER, 1l, null, set);
		Assert.assertNull(segInfo);

	}

	@Test
	public void testGetSegmentUpdates_typeIsDM_OneDiffRecord() {
		jdbcTemplate
				.update("insert into data_managers(DM_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','WORKING')");
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(1,1,0,1,26,1,1,1,26)");
		jdbcTemplate
				.update("insert into dm_segments(DM_ID,SEGMENT_ID,RANK)values(1,1,1)");
		byte[] bytes = { 1, 2, 3 };
		Set<Long> set = Sets.newTreeSet();
		set.add(1l);
		List<SegSyncInfos> syncInfos = Lists.newArrayList();
		SegSyncInfos syncInfo = new SegSyncInfos(1L, 1L,1L, true,SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT);
		syncInfo.setTemplateData(bytes);		
		syncInfos.add(syncInfo);
		PBSegmentSyncInfo segInfo = segUpManager.getSegmentUpdates(
				ComponentType.DATA_MANAGER, 1l, syncInfos, set);
		Assert.assertEquals(1, segInfo.getId());
		Assert.assertEquals(SegmentAssignedStateType.SEGMENT_ASSIGNED,
				segInfo.getAssignedState());
		Assert.assertEquals(1, segInfo.getSyncItem().getCatUpInfo()
				.getCatchUpItemsCount());
		Assert.assertEquals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT,
				segInfo.getSyncItem().getCatUpInfo().getCatchUpItems(0)
						.getCommand());
		Assert.assertEquals(1, segInfo.getSyncItem().getCatUpInfo()
				.getCatchUpItems(0).getVersion());
		Assert.assertEquals(ByteString.copyFrom(bytes), segInfo.getSyncItem()
				.getCatUpInfo().getCatchUpItems(0).getBinaryTemplate());

	}

	@Test
	public void testGetSegmentUpdates_typeIsDM_OneDiffRecord_Delete() {
		jdbcTemplate
				.update("insert into data_managers(DM_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','WORKING')");
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(1,1,0,1,26,1,1,1,26)");
		jdbcTemplate
				.update("insert into dm_segments(DM_ID,SEGMENT_ID,RANK)values(1,1,1)");
		Set<Long> set = Sets.newTreeSet();
		set.add(1l);
		List<SegSyncInfos> syncInfos = Lists.newArrayList();
		SegSyncInfos syncInfo = new SegSyncInfos(1l, 1l, 1l,
				SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_DELETE);
		syncInfos.add(syncInfo);
		PBSegmentSyncInfo segInfo = segUpManager.getSegmentUpdates(
				ComponentType.DATA_MANAGER, 1l, syncInfos, set);
		Assert.assertEquals(1, segInfo.getId());
		Assert.assertEquals(SegmentAssignedStateType.SEGMENT_ASSIGNED,
				segInfo.getAssignedState());
		Assert.assertEquals(1, segInfo.getSyncItem().getCatUpInfo()
				.getCatchUpItemsCount());
		Assert.assertEquals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_DELETE,
				segInfo.getSyncItem().getCatUpInfo().getCatchUpItems(0)
						.getCommand());
		Assert.assertEquals(1, segInfo.getSyncItem().getCatUpInfo()
				.getCatchUpItems(0).getVersion());
		Assert.assertEquals(1, segInfo.getSyncItem().getCatUpInfo()
				.getCatchUpItems(0).getBiometricsId());
	}

	@Test
	public void testGetSegmentUpdates_typeIsDM_OneDiffRecord_SEGMENT_DEFUNCT() {
		jdbcTemplate
				.update("insert into data_managers(DM_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','WORKING')");
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(1,1,0,1,26,1,1,1,26)");
		/*
		 * jdbcTemplate
		 * .update("insert into dm_segments(DM_ID,SEGMENT_ID,RANK)values(1,1,1)"
		 * );
		 */
		Set<Long> set = Sets.newTreeSet();
		set.add(1l);
		List<SegSyncInfos> syncInfos = Lists.newArrayList();
		SegSyncInfos syncInfo = new SegSyncInfos(1L, 1L,1L, SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT);
		
		syncInfos.add(syncInfo);
		PBSegmentSyncInfo segInfo = segUpManager.getSegmentUpdates(
				ComponentType.DATA_MANAGER, 1l, syncInfos, set);
		Assert.assertEquals(1, segInfo.getId());
		Assert.assertEquals(SegmentAssignedStateType.SEGMENT_UNASSIGNED,
				segInfo.getAssignedState());
		Assert.assertEquals(1, segInfo.getSyncItem().getCatUpInfo()
				.getCatchUpItemsCount());
		Assert.assertEquals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_DELETE,
				segInfo.getSyncItem().getCatUpInfo().getCatchUpItems(0)
						.getCommand());
		Assert.assertEquals(1, segInfo.getSyncItem().getCatUpInfo()
				.getCatchUpItems(0).getVersion());
		Assert.assertEquals(1, segInfo.getSyncItem().getCatUpInfo()
				.getCatchUpItems(0).getBiometricsId());
	}

	@Test
	public void testGetMuSegUpdates_NoMuFound() {
		try {
			segUpManager.getMuSegUpdates(1);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof AimRuntimeException);
			Assert.assertEquals(e.getMessage(),
					"Can not found Match Unit with id:1");
			return;
		}
		fail();
	}

	@Test
	public void testGetMuSegUpdates() {
		jdbcTemplate
				.update("insert into match_units(MU_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','WORKING')");
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(1,1,0,1,26,1,1,1,26)");
		jdbcTemplate
				.update("insert into mu_segments(MU_ID,SEGMENT_ID,RANK)values(1,1,1)");
		List<PBSegmentSyncInfo> segSyncInfos = segUpManager.getMuSegUpdates(1);
		segSyncInfos.get(0);
		Assert.assertEquals(1, segSyncInfos.size());
		Assert.assertEquals(1, segSyncInfos.get(0).getId());
		Assert.assertEquals(SegmentAssignedStateType.SEGMENT_ASSIGNED,
				segSyncInfos.get(0).getAssignedState());
		Assert.assertTrue(segSyncInfos.get(0).getSyncItem().hasDownload());
		Assert.assertFalse(segSyncInfos.get(0).getSyncItem().hasCatUpInfo());
	}

	@Test
	public void testGetMuSegUpdates_UNASSIGNED() {
		jdbcTemplate
				.update("insert into match_units(MU_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','WORKING')");
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(1,1,0,1,26,1,1,1,26)");
		jdbcTemplate
				.update("insert into mu_seg_reports(MU_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION)values(1,1,1,1)");
		List<PBSegmentSyncInfo> segSyncInfos = segUpManager.getMuSegUpdates(1);
		Assert.assertEquals(1, segSyncInfos.size());
		Assert.assertEquals(1, segSyncInfos.get(0).getId());
		Assert.assertEquals(SegmentAssignedStateType.SEGMENT_UNASSIGNED,
				segSyncInfos.get(0).getAssignedState());
		Assert.assertFalse(segSyncInfos.get(0).getSyncItem().hasDownload());
		Assert.assertFalse(segSyncInfos.get(0).getSyncItem().hasCatUpInfo());
	}

	@Test
	public void testGetMuSegUpdates_NoCI() {
		jdbcTemplate
				.update("insert into match_units(MU_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','WORKING')");
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(1,1,0,1,26,1,2,2,26)");
		jdbcTemplate
				.update("insert into mu_seg_reports(MU_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION)values(1,1,1,1)");
		List<PBSegmentSyncInfo> segSyncInfos = segUpManager.getMuSegUpdates(1);
		Assert.assertEquals(0, segSyncInfos.size());
	}

	@Test
	public void testGetMuSegUpdates_UNASSIGNED_HasCI() {
		jdbcTemplate
				.update("insert into match_units(MU_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','WORKING')");
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(1,1,0,1,26,1,2,2,26)");
		jdbcTemplate
				.update("insert into mu_seg_reports(MU_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION)values(1,1,1,1)");
		jdbcTemplate
				.update("insert into segment_change_log (SEGMENT_CHANGE_ID,BIOMETRICS_ID,SEGMENT_ID,SEGMENT_VERSION,CHANGE_TYPE) values(1,1,1,2,1)");
		List<PBSegmentSyncInfo> segSyncInfos = segUpManager.getMuSegUpdates(1);
		Assert.assertEquals(1, segSyncInfos.size());
		Assert.assertEquals(1, segSyncInfos.get(0).getId());
		Assert.assertEquals(SegmentAssignedStateType.SEGMENT_UNASSIGNED,
				segSyncInfos.get(0).getAssignedState());
		Assert.assertEquals(1, segSyncInfos.get(0).getSyncItem().getCatUpInfo()
				.getCatchUpItemsCount());
		Assert.assertEquals(1, segSyncInfos.get(0).getSyncItem().getCatUpInfo()
				.getCatchUpItems(0).getBiometricsId());
		Assert.assertEquals(2, segSyncInfos.get(0).getSyncItem().getCatUpInfo()
				.getCatchUpItems(0).getVersion());
		Assert.assertEquals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_DELETE,
				segSyncInfos.get(0).getSyncItem().getCatUpInfo()
						.getCatchUpItems(0).getCommand());
	}

	@Test
	public void testGetMuSegUpdates_UNASSIGNED_TwoRec() {
		jdbcTemplate
				.update("insert into match_units(MU_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','WORKING')");
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(1,1,0,1,26,1,3,3,26)");
		jdbcTemplate
				.update("insert into mu_seg_reports(MU_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION)values(1,1,1,1)");
		jdbcTemplate
				.update("insert into segment_change_log (SEGMENT_CHANGE_ID,BIOMETRICS_ID,SEGMENT_ID,SEGMENT_VERSION,CHANGE_TYPE) values(1,1,1,2,1)");
		jdbcTemplate
				.update("insert into segment_change_log (SEGMENT_CHANGE_ID,BIOMETRICS_ID,SEGMENT_ID,SEGMENT_VERSION,CHANGE_TYPE) values(2,1,1,3,0)");
		List<PBSegmentSyncInfo> segSyncInfos = segUpManager.getMuSegUpdates(1);
		Assert.assertEquals(1, segSyncInfos.size());
		Assert.assertEquals(1, segSyncInfos.get(0).getId());
		Assert.assertEquals(SegmentAssignedStateType.SEGMENT_UNASSIGNED,
				segSyncInfos.get(0).getAssignedState());
		Assert.assertEquals(2, segSyncInfos.get(0).getSyncItem().getCatUpInfo()
				.getCatchUpItemsCount());
		Assert.assertEquals(1, segSyncInfos.get(0).getSyncItem().getCatUpInfo()
				.getCatchUpItems(0).getBiometricsId());
		Assert.assertEquals(2, segSyncInfos.get(0).getSyncItem().getCatUpInfo()
				.getCatchUpItems(0).getVersion());
		Assert.assertEquals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_DELETE,
				segSyncInfos.get(0).getSyncItem().getCatUpInfo()
						.getCatchUpItems(0).getCommand());

		Assert.assertEquals(1, segSyncInfos.get(0).getId());
		Assert.assertEquals(SegmentAssignedStateType.SEGMENT_UNASSIGNED,
				segSyncInfos.get(0).getAssignedState());
		Assert.assertEquals(0, segSyncInfos.get(0).getSyncItem().getCatUpInfo()
				.getCatchUpItems(1).getBiometricsId());
		Assert.assertEquals(3, segSyncInfos.get(0).getSyncItem().getCatUpInfo()
				.getCatchUpItems(1).getVersion());
		Assert.assertEquals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT,
				segSyncInfos.get(0).getSyncItem().getCatUpInfo()
						.getCatchUpItems(1).getCommand());
	}

	@Test
	public void testGetDmSegUpdates_NoDmFound() {
		try {
			segUpManager.getDmSegUpdates(1);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof AimRuntimeException);
			Assert.assertEquals(e.getMessage(),
					"Can not found data manager with id:1");
			return;
		}
		fail();
	}

	@Test
	public void testGetDmSegUpdates() {
		jdbcTemplate
				.update("insert into data_managers(DM_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','WORKING')");
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(1,1,0,1,26,1,1,1,26)");
		jdbcTemplate
				.update("insert into dm_segments(DM_ID,SEGMENT_ID,RANK)values(1,1,1)");
		List<PBSegmentSyncInfo> segSyncInfos = segUpManager.getDmSegUpdates(1);
		segSyncInfos.get(0);
		Assert.assertEquals(1, segSyncInfos.size());
		Assert.assertEquals(1, segSyncInfos.get(0).getId());
		Assert.assertEquals(SegmentAssignedStateType.SEGMENT_ASSIGNED,
				segSyncInfos.get(0).getAssignedState());
		Assert.assertTrue(segSyncInfos.get(0).getSyncItem().hasDownload());
		Assert.assertFalse(segSyncInfos.get(0).getSyncItem().hasCatUpInfo());
	}

	@Test
	public void testGetDmSegUpdates_UNASSIGNED() {
		jdbcTemplate
				.update("insert into data_managers(DM_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','WORKING')");
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(1,1,0,1,26,1,1,1,26)");
		jdbcTemplate
				.update("insert into dm_seg_reports(DM_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION)values(1,1,1,1)");
		List<PBSegmentSyncInfo> segSyncInfos = segUpManager.getDmSegUpdates(1);
		Assert.assertEquals(1, segSyncInfos.size());
		Assert.assertEquals(1, segSyncInfos.get(0).getId());
		Assert.assertEquals(SegmentAssignedStateType.SEGMENT_UNASSIGNED,
				segSyncInfos.get(0).getAssignedState());
		Assert.assertFalse(segSyncInfos.get(0).getSyncItem().hasDownload());
		Assert.assertFalse(segSyncInfos.get(0).getSyncItem().hasCatUpInfo());
	}

	@Test
	public void testGetDmSegUpdates_NoCI() {
		jdbcTemplate
				.update("insert into data_managers(DM_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','WORKING')");
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(1,1,0,1,26,1,2,2,26)");
		jdbcTemplate
				.update("insert into dm_seg_reports(DM_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION)values(1,1,1,1)");
		List<PBSegmentSyncInfo> segSyncInfos = segUpManager.getDmSegUpdates(1);
		Assert.assertEquals(0, segSyncInfos.size());
	}

	@Test
	public void testGetDmSegUpdates_UNASSIGNED_HasCI() {
		jdbcTemplate
				.update("insert into data_managers(DM_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','WORKING')");
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(1,1,0,1,26,1,2,2,26)");
		jdbcTemplate
				.update("insert into dm_seg_reports(DM_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION)values(1,1,1,1)");
		jdbcTemplate
				.update("insert into segment_change_log (SEGMENT_CHANGE_ID,BIOMETRICS_ID,SEGMENT_ID,SEGMENT_VERSION,CHANGE_TYPE) values(1,1,1,2,1)");
		List<PBSegmentSyncInfo> segSyncInfos = segUpManager.getDmSegUpdates(1);
		Assert.assertEquals(1, segSyncInfos.size());
		Assert.assertEquals(1, segSyncInfos.get(0).getId());
		Assert.assertEquals(SegmentAssignedStateType.SEGMENT_UNASSIGNED,
				segSyncInfos.get(0).getAssignedState());
		Assert.assertEquals(1, segSyncInfos.get(0).getSyncItem().getCatUpInfo()
				.getCatchUpItemsCount());
		Assert.assertEquals(1, segSyncInfos.get(0).getSyncItem().getCatUpInfo()
				.getCatchUpItems(0).getBiometricsId());
		Assert.assertEquals(2, segSyncInfos.get(0).getSyncItem().getCatUpInfo()
				.getCatchUpItems(0).getVersion());
		Assert.assertEquals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_DELETE,
				segSyncInfos.get(0).getSyncItem().getCatUpInfo()
						.getCatchUpItems(0).getCommand());
	}

	@Test
	public void testGetDmSegUpdates_UNASSIGNED_TwoRec() {
		jdbcTemplate
				.update("insert into data_managers(DM_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','WORKING')");
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(1,1,0,1,26,1,3,3,26)");
		jdbcTemplate
				.update("insert into dm_seg_reports(DM_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION)values(1,1,1,1)");
		jdbcTemplate
				.update("insert into segment_change_log (SEGMENT_CHANGE_ID,BIOMETRICS_ID,SEGMENT_ID,SEGMENT_VERSION,CHANGE_TYPE) values(1,1,1,2,1)");
		jdbcTemplate
				.update("insert into segment_change_log (SEGMENT_CHANGE_ID,BIOMETRICS_ID,SEGMENT_ID,SEGMENT_VERSION,CHANGE_TYPE) values(2,1,1,3,0)");
		List<PBSegmentSyncInfo> segSyncInfos = segUpManager.getDmSegUpdates(1);
		Assert.assertEquals(1, segSyncInfos.size());
		Assert.assertEquals(1, segSyncInfos.get(0).getId());
		Assert.assertEquals(SegmentAssignedStateType.SEGMENT_UNASSIGNED,
				segSyncInfos.get(0).getAssignedState());
		Assert.assertEquals(2, segSyncInfos.get(0).getSyncItem().getCatUpInfo()
				.getCatchUpItemsCount());
		Assert.assertEquals(1, segSyncInfos.get(0).getSyncItem().getCatUpInfo()
				.getCatchUpItems(0).getBiometricsId());
		Assert.assertEquals(2, segSyncInfos.get(0).getSyncItem().getCatUpInfo()
				.getCatchUpItems(0).getVersion());
		Assert.assertEquals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_DELETE,
				segSyncInfos.get(0).getSyncItem().getCatUpInfo()
						.getCatchUpItems(0).getCommand());

		Assert.assertEquals(1, segSyncInfos.get(0).getId());
		Assert.assertEquals(SegmentAssignedStateType.SEGMENT_UNASSIGNED,
				segSyncInfos.get(0).getAssignedState());
		Assert.assertEquals(0, segSyncInfos.get(0).getSyncItem().getCatUpInfo()
				.getCatchUpItems(1).getBiometricsId());
		Assert.assertEquals(3, segSyncInfos.get(0).getSyncItem().getCatUpInfo()
				.getCatchUpItems(1).getVersion());
		Assert.assertEquals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT,
				segSyncInfos.get(0).getSyncItem().getCatUpInfo()
						.getCatchUpItems(1).getCommand());
	}

	@Test
	public void testGetMUSegUpdates_UNASSIGNED_SegDiffThanMax() {
		jdbcTemplate
				.update("insert into match_units(MU_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','WORKING')");
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(1,1,0,1,26,1,2003,2003,26)");
		jdbcTemplate
				.update("insert into mu_seg_reports(MU_ID,SEGMENT_ID,STATUS,SEGMENT_QUEUED_VERSION)values(1,1,1,1)");
		jdbcTemplate
				.update("insert into segment_change_log (SEGMENT_CHANGE_ID,BIOMETRICS_ID,SEGMENT_ID,SEGMENT_VERSION,CHANGE_TYPE) values(1,1,1,2,1)");
		jdbcTemplate
				.update("insert into segment_change_log (SEGMENT_CHANGE_ID,BIOMETRICS_ID,SEGMENT_ID,SEGMENT_VERSION,CHANGE_TYPE) values(2,1,1,3,0)");
		List<PBSegmentSyncInfo> segSyncInfos = segUpManager.getMuSegUpdates(1);
		Assert.assertEquals(1, segSyncInfos.size());
		Assert.assertEquals(1, segSyncInfos.get(0).getId());
		Assert.assertEquals(SegmentAssignedStateType.SEGMENT_UNASSIGNED,
				segSyncInfos.get(0).getAssignedState());
		Assert.assertTrue(segSyncInfos.get(0).getSyncItem().hasDownload());

	}

}
