package jp.co.nec.aim.mm.identify.planner;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.Set;

import jp.co.nec.aim.mm.dao.DateDao;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.logger.PerformanceLogger;
import jp.co.nec.aim.mm.util.StopWatch;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

/**
 * 
 * @author xiazp
 * 
 */
public class MuExcutionPlanCreator {
	private static final Logger logger = LoggerFactory
			.getLogger(MuExcutionPlanCreator.class);
	private List<MuCpuAndPressure> muCpuAndPressures;
	private List<MuSegmentMap> muSegMaps;
	private static final Random sRandom = new Random(System.currentTimeMillis());
	private static String slash = "/";
	private static String comma = ",";
	private static String semicolon = ":";
	private static int notAssigned = -9;
	private static String space = " ";
	AdjustMuAblistyFactorPropertyUtil util = new AdjustMuAblistyFactorPropertyUtil();
	private DateDao dateDao;

	/**
	 * 
	 * @param planMap
	 * @param muCpuAndPressure
	 */
	public MuExcutionPlanCreator(List<MuSegmentMap> muSegMapList,
			List<MuCpuAndPressure> muCpuPressureList, DateDao dateDao) {
		this.muSegMaps = muSegMapList;
		this.muCpuAndPressures = muCpuPressureList;
		this.dateDao = dateDao;
	}

	public MuExcutionPlanCreator(DateDao dateDao) {
		this.dateDao = dateDao;
	}

	/**
	 * 
	 * @return
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public String createMuPlans() {
		logger.info("MuExcutionPlanCreator prepare to creating mu excutiong plans...");
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		if (muSegMaps == null || muCpuAndPressures == null
				|| muSegMaps.size() < 1 || muCpuAndPressures.size() < 1) {
			logger.warn("parameter is incorect! return!");
			return null;
		}
		Set<Integer> muIdSet = new HashSet<Integer>();
		Set<Long> segIdSet = new HashSet<Long>();
		for (MuSegmentMap mp : muSegMaps) {
			if (mp.getMuId() != null) {
				muIdSet.add(mp.getMuId());
			}
			if (mp.getSegmentId() != null) {
				segIdSet.add(mp.getSegmentId());
			}
		}
		List<Integer> muIds = new ArrayList(muIdSet);
		Collections.sort(muIds);
		List<Long> segIds = new ArrayList(segIdSet);
		Map<Integer, Integer> muIdIndexMap = Maps.newHashMap();
		Map<Long, Integer> segIdIndexMap = Maps.newHashMap();

		for (int i = 0; i < muIds.size(); i++) {
			muIdIndexMap.put(muIds.get(i), i);
		}
		for (int i = 0; i < segIds.size(); i++) {
			segIdIndexMap.put(segIds.get(i), i);
		}
		boolean[][] muSegmentMatrix = map2Matrix(muSegMaps, muIds, segIds,
				muIdIndexMap, segIdIndexMap);
		int[] assignedMus = new int[muIds.size() + segIds.size()];

		if (destributeWithAbility(muSegmentMatrix, muIdSet.size(),
				segIdSet.size(), assignedMus)) {
			boolean[][] newMuSegMatrix = new boolean[muIds.size()][segIds
					.size()];
			for (int mu = 0; mu < muIds.size(); mu++) {
				for (int seg = 0; seg < segIds.size(); seg++) {
					if ((assignedMus[seg] != notAssigned)
							&& assignedMus[seg] == mu) {
						newMuSegMatrix[mu][seg] = true;
					} else {
						newMuSegMatrix[mu][seg] = false;
					}
				}
			}

			if (logger.isDebugEnabled()) {
				String maxtrixString = printMartix(newMuSegMatrix);
				logger.debug(maxtrixString);
			}

			Map<Integer, List<MuSegmentMap>> planMaps = new HashMap<Integer, List<MuSegmentMap>>();
			for (MuSegmentMap one : muSegMaps) {
				int muIndex = muIdIndexMap.get(one.getMuId());
				int segIndex = segIdIndexMap.get(one.getSegmentId());
				if (newMuSegMatrix[muIndex][segIndex] == true) {
					List<MuSegmentMap> oneMuSegMaps = planMaps.get(one
							.getMuId());
					if (oneMuSegMaps == null) {
						oneMuSegMaps = Lists.newArrayList();
						planMaps.put(one.getMuId(), oneMuSegMaps);
					}
					oneMuSegMaps.add(one);
				}
			}

			logger.info("createMuPlans success finished");
			stopWatch.stop();
			PerformanceLogger.log(getClass().getSimpleName(), "createMuPlans",
					stopWatch.elapsedTime());
			return builderPlanString(planMaps);
		} else {
			logger.warn("MuExcutionPlanCreator created an empty plans!");
			return null;
		}
	}

	/**
	 * 
	 * @param toBeBiuld
	 * @return
	 */
	private String builderPlanString(Map<Integer, List<MuSegmentMap>> toBeBiuld) {
		StringBuilder sb = new StringBuilder();
		Iterator<Entry<Integer, List<MuSegmentMap>>> it = toBeBiuld.entrySet()
				.iterator();
		int size = toBeBiuld.size();
		int current = 0;
		while (it.hasNext()) {
			Entry<Integer, List<MuSegmentMap>> tmp = it.next();
			if (current == 0) {
				sb.append(tmp.getKey());
				sb.append(comma);
			} else {
				sb.append(slash);
				sb.append(tmp.getKey());
				sb.append(comma);
			}
			List<MuSegmentMap> segList = tmp.getValue();
			int index = 0;
			for (MuSegmentMap map : segList) {
				if (current == size - 1 && index == segList.size() - 1) {
					sb.append(map.getSegmentId());
					sb.append(semicolon);
					sb.append(map.getSegmentVersion());
				} else {
					sb.append(map.getSegmentId());
					sb.append(semicolon);
					sb.append(map.getSegmentVersion());
					sb.append(comma);
				}
				index++;
			}
			current++;
		}
		if (sb.toString().endsWith(comma)) {
			int last = sb.length();
			sb.deleteCharAt(last - 1);
		}
		return sb.toString();
	}

	/**
	 * 
	 * @param muSegmaps
	 * @param muIds
	 * @param segIds
	 * @return
	 */
	private boolean[][] map2Matrix(List<MuSegmentMap> muSegmaps,
			List<Integer> muIds, List<Long> segIds,
			Map<Integer, Integer> muIdIndexMap, Map<Long, Integer> segIdIndexMap) {
		StopWatch sw = new StopWatch();
		sw.start();
		if (muSegmaps == null || muSegmaps.size() == 0 || muIds == null
				|| muIds.size() == 0 || segIds == null || segIds.size() == 0) {
			throw new IllegalArgumentException(
					"There are wrong in parameters(muSegmaps,muIds,segIds");
		}
		boolean[][] matrix = new boolean[muIds.size()][segIds.size()];
		for (MuSegmentMap muSegMap : muSegmaps) {
			int muIndex = muIdIndexMap.get(muSegMap.getMuId());
			int segIndex = segIdIndexMap.get(muSegMap.getSegmentId());
			if (muIndex != -1 && segIndex != -1) {
				matrix[muIndex][segIndex] = true;
			}
		}
		sw.stop();
		PerformanceLogger.log(getClass().getSimpleName(), "map2Matrix",
				sw.elapsedTime());
		return matrix;
	}

	/**
	 * 
	 * @param correctFactor
	 * @param muCount
	 */
	private void calculateCorrectFactor(double[] correctFactor) {
		double average;
		double deviation;
		int sum = 0;
		int sumSquare = 0;
		// int delayedMus = 0;
		int muCount = correctFactor.length;
		long now = dateDao.getCurrentTimeMS();
		long[] muReportTs = new long[muCount];
		int[] muDivations = new int[muCount];
		Map<String, Double> factors = util.getAllValues();
		if (factors == null || factors.size() == 0) {
			String error = "factors that readed from mu.ablity.properties is incorrect!";
			throw new AimRuntimeException(error);
		}
		util = null;
		for (int i = 0; i < muCount; i++) {
			if (muCpuAndPressures.get(i).getPressure() < 0) {
				muReportTs[i] = 0;
			} else {
				sum += (muReportTs[i] = muCpuAndPressures.get(i).getPressure()
						+ (now - muCpuAndPressures.get(i).getReportTs()) / 1000);
			}
		}
		average = sum / muCount;
		for (int i = 0; i < muCount; i++) {
			if (muReportTs[i] >= 0) {
				sumSquare += ((muReportTs[i] - average) * (muReportTs[i] - average));
			}
		}

		deviation = Math.pow(sumSquare / muCount, 0.5);
		if (deviation < 2) {
			deviation = 2;
		}
		for (int i = 0; i < muCount; i++) {
			if (muReportTs[i] < 0) {
				muDivations[i] = -2;
			} else {
				muDivations[i] = (int) ((muReportTs[i] - average) / deviation);
			}
			if (muDivations[i] < -4) {
				muDivations[i] = -4;
			}
			if (muDivations[i] > 4) {
				muDivations[i] = 4;
			}
			switch (muDivations[i]) {
			case -4:
			case -3:
			case -2:
				correctFactor[i] = factors.get("MINUS2");
				break;
			case -1:
				correctFactor[i] = factors.get("MINUS1");
				break;
			case 0:
				correctFactor[i] = factors.get("ZERO");
				break;
			case 1:
				correctFactor[i] = factors.get("PLUS1");
				break;
			case 2:
				correctFactor[i] = factors.get("PLUS2");
				break;
			case 3:
				correctFactor[i] = factors.get("PLUS3");
				break;
			case 4:
				correctFactor[i] = factors.get("PLUS4");
			}
		}
	}

	/**
	 * 
	 * @param ruoundTable
	 * @param muCount
	 * @param segCount
	 * @return
	 */
	private int[] reOrderMUByAbility(int muCount, int segCount) {
		double[] correctFactorNew = new double[muCount];
		double[] ability = new double[muCount];
		double abliSum = 0;
		double abliMin = 0;
		double abliMax = 0;
		int roomSize = Math.max(muCount, segCount);
		int[] muRate = new int[muCount];
		for (int i = 0; i < muCount; i++) {
			correctFactorNew[i] = 1;
		}
		calculateCorrectFactor(correctFactorNew);
		for (int i = 0; i < muCount; i++) {
			ability[i] = correctFactorNew[i]
					* muCpuAndPressures.get(i).getAbility();
			abliSum += ability[i];
		}
		abliMin = ability[0];
		abliMax = ability[0];
		for (int i = 0; i < muCount; i++) {
			abliMin = abliMin > ability[i] ? ability[i] : abliMin;
			abliMax = abliMax < ability[i] ? ability[i] : abliMax;
		}
		int sum = 0;
		for (int i = 0; i < muCount; i++) {
			muRate[i] = (int) (ability[i] * roomSize / abliSum + 0.5);
			if (muRate[i] < 1) {
				muRate[i] = 1;
			}
			sum += muRate[i];
		}
		roomSize = sum;
		int[] room = new int[roomSize];
		int[] roundTable = new int[roomSize];
		int roomNo = 0;
		int j = 0;
		for (int i = 0; i < muCount; i++) {
			for (j = 0; j < muRate[i]; j++) {
				room[roomNo + j] = i;
			}
			roomNo += j;
		}
		int pickedMu;
		for (int i = 0; i < roomSize; i++) {
			pickedMu = sRandom.nextInt(roomSize - i);
			roundTable[i] = room[pickedMu];
			room[pickedMu] = room[roomSize - i - 1];
		}
		return roundTable;
	}

	/**
	 * 
	 * @param bestOrderSegments
	 * @param segCount
	 * @return
	 */
	private void reOrderSegment(int bestOrderSegments[]) {
		int segCount = bestOrderSegments.length;
		int[] segmentList = new int[segCount];
		for (int i = 0; i < segCount; i++) {
			segmentList[i] = i;
		}
		int pickedSegment = -1;
		for (int i = 0; i < segCount; i++) {
			pickedSegment = sRandom.nextInt(segCount - i);
			bestOrderSegments[i] = segmentList[pickedSegment];
			segmentList[pickedSegment] = segmentList[segCount - i - 1];
		}
	}

	/**
	 * 
	 * @param msMatrix
	 * @param assignedMu
	 * @return
	 */
	private boolean destributeWithAbility(boolean[][] msMatrix,
			int realMuCount, int realSegCount, int[] assignedMu) {
		logger.info("prepare assign segments to mus...");
		int assignedCount = 0;
		boolean success = false;
		int[] segmentBestOrder = new int[realSegCount];
		int vStart = 0;
		for (int i = 0; i < assignedMu.length; i++) {
			assignedMu[i] = notAssigned;
		}
		reOrderSegment(segmentBestOrder);
		int[] roundTable = reOrderMUByAbility(realMuCount, realSegCount);
		int muNum = 0;
		int segNum = 0;
		int circle = 0;
		for (circle = 0; circle < realSegCount; circle++) {
			for (int indexMu = 0; indexMu < roundTable.length; indexMu++) {
				muNum = roundTable[indexMu];
				for (int indexSeg = vStart; indexSeg < realSegCount; indexSeg++) {
					segNum = segmentBestOrder[indexSeg];
					if (assignedMu[segNum] == notAssigned
							&& msMatrix[muNum][segNum] == true) {
						assignedMu[segNum] = muNum;
						for (int vCount = vStart; vCount < realSegCount; vCount++) {
							if (assignedMu[segmentBestOrder[vCount]] == notAssigned) {
								vStart = vCount;
								break;
							}
						}
						assignedCount++;
						if (assignedCount == realSegCount) {
							success = true;
							break;
						}
						break;
					}
				}
				if (success) {
					break;
				}
			}
			if (success) {
				break;
			}
		}

		if (circle > 1) {
			logger.warn(
					"May be have some wrong! the circle is bigger than 2:{}",
					circle + 1);
		}
		if (assignedCount < realSegCount) {
			String warning = "Can't complete assing semgents to mus. assinged count = "
					+ assignedCount + " while real semgents = " + realSegCount;
			logger.warn(warning);
			success = false;
		}
		if (success) {
			logger.info(
					"success to assigned segments(SegmentCount = {}) to mus(muCount = {}).",
					realSegCount, realMuCount);
		}
		return success;
	}

	public String printMartix(boolean[][] matrix) {
		int rows = matrix.length;
		int cols = matrix[0].length;
		StringBuilder sb = new StringBuilder();
		sb.append("\n");
		sb.append("Print Matrix:");
		sb.append("\n");
		sb.append(String.format("%2s", space));

		for (int i = 0; i < cols; i++) {
			sb.append(String.format("%6d", i));
		}
		sb.append("\n");
		for (int i = 0; i < rows; i++) {
			sb.append(String.format("%2d", i));
			for (int j = 0; j < cols; j++) {
				if (matrix[i][j] == true) {
					sb.append(String.format("%6s", "X"));
				} else {
					sb.append(String.format("%6s", space));
				}
			}
			sb.append("\n");
		}
		return sb.toString();
	}

}
