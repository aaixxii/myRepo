package jp.co.nec.aim.mm.procedure;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import oracle.jdbc.OracleConnection;

import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.AbstractSqlTypeValue;
import org.springframework.jdbc.core.support.SqlLobValue;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.jdbc.support.nativejdbc.CommonsDbcpNativeJdbcExtractor;

import com.google.common.collect.Maps;

/**
 * CreateContainerJobProcedure
 * 
 * @author liuyq
 * 
 */
public class CreateContainerJobProcedure extends StoredProcedure {
	private static final String SQL = "create_container_job";

	private Long jobId; // top level job id
	private Integer searchRequestIndex; // search request index
	private Integer functionId; // function id
	private String inquiryRequestXml;
	private byte[] inquiryProbeData; // inquiry job data
	private Integer containerId; // list of container id
	private Map<String, Object> resultMap; // result map

	/**
	 * CreateContainerJobProcedure
	 * 
	 * @param dataSource
	 *            the instance of DataSource
	 */
	public CreateContainerJobProcedure(DataSource dataSource) {
		setDataSource(dataSource);
		setSql(SQL);
		declareParameter(new SqlParameter("p_job_id", Types.BIGINT));
		declareParameter(new SqlParameter("p_search_request_index", Types.BIGINT));				
		declareParameter(new SqlParameter("p_function_id", Types.BIGINT));
		declareParameter(new SqlParameter("p_inquiry_requist_xml", Types.VARCHAR));
		declareParameter(new SqlParameter("p_inquiry_probo_data", Types.BLOB));
		declareParameter(new SqlParameter("p_container_id", Types.INTEGER));				
		
		declareParameter(new SqlOutParameter("p_empty_job", Types.INTEGER));
		declareParameter(new SqlOutParameter("p_remain_job", Types.INTEGER));
		declareParameter(new SqlOutParameter("l_fusion_job_id", Types.BIGINT));
		compile();
	}

	/**
	 * execute the Procedure create_container_job
	 */
	public void execute() {
		Map<String, Object> map = Maps.newHashMap();
		map.put("p_job_id", getJobId());
		map.put("p_search_request_index", getSearchRequestIndex());
		map.put("p_function_id", getFunctionId());
		map.put("p_inquiry_requist_xml", getInquiryRequestXml());
		map.put("p_inquiry_probo_data",  new SqlLobValue(getInquiryProbeData()));
		map.put("p_container_id", getContainerId());
		resultMap = execute(map);
		System.out.print(resultMap.size());
	}

	public Long getFusionJobId() {
		return (Long) resultMap.get("l_fusion_job_id");
	}

	public Integer getEmptyJob() {
		return (Integer) resultMap.get("p_empty_job");
	}

	public Integer getRemainJob() {
		return (Integer) resultMap.get("p_remain_job");
	}

	public Long getJobId() {
		return jobId;
	}

	public void setJobId(Long jobId) {
		this.jobId = jobId;
	}

	public Integer getSearchRequestIndex() {
		return searchRequestIndex;
	}

	public void setSearchRequestIndex(Integer searchRequestIndex) {
		this.searchRequestIndex = searchRequestIndex;
	}

	public Integer getFunctionId() {
		return functionId;
	}

	public void setFunctionId(Integer functionId) {
		this.functionId = functionId;
	}

	public String getInquiryRequestXml() {
		return inquiryRequestXml;
	}

	public void setInquiryRequestXml(String inquiryRequestXml) {
		this.inquiryRequestXml = inquiryRequestXml;
	}

	public byte[] getInquiryProbeData() {
		return inquiryProbeData;
	}

	public void setInquiryProbeData(byte[] inquiryProbeData) {
		this.inquiryProbeData = inquiryProbeData;
	}

	public Integer getContainerId() {
		return containerId;
	}

	public void setContainerId(Integer containerId) {
		this.containerId = containerId;
	}	
}
