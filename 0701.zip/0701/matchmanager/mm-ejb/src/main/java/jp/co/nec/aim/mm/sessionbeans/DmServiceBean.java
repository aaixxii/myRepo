package jp.co.nec.aim.mm.sessionbeans;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.sql.DataSource;

import jp.co.nec.aim.mm.dao.DmTemplateDao;

@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class DmServiceBean {
	
	@Resource(mappedName = "java:jboss/MySqlDS")
	private DataSource dataSource;
	private DmTemplateDao dmo;

	public DmServiceBean() {
		// zero-arg ctor for container.
	}

	@PostConstruct
	public void init() {
		dmo = new DmTemplateDao(dataSource);
	}

	public String getSegIdBioIdByRefId(String refId) {
		return dmo.getBioIdByRefId(refId);
	}
}
