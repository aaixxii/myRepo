package jp.co.nec.aim.mm.procedure;

import java.sql.Array;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Struct;
import java.sql.Types;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.loadbalancer.SlbMatrix;
import jp.co.nec.aim.mm.util.CollectionsUtil;
import oracle.jdbc.OracleConnection;
import oracle.sql.NUMBER;

import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.AbstractSqlTypeValue;
import org.springframework.jdbc.object.StoredProcedure;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

/**
 * Persist the SLB executed Matrix result into DM_SEG or MU_SEG
 * 
 * @author liuyq
 * 
 */
public class PersistSlbMatrixProcedure extends StoredProcedure {

	/** SQL **/
	private static final String SQL = "persist_slb_matrix";
	private List<SlbMatrix> matrixs = Lists.newArrayList(); // input
															// parameter
	private int unitType; // unit type include (DM and MU)
	private long containerId; // container id

	private static final String SLBMATRIX_TABLE_TYPE = "SLBMATRIX_TABLE_TYPE";
	private static final String SLBMATRIX_OBJECT = "SLBMATRIX";

	/**
	 * PersistSlbMatrixProcedure constructor
	 * 
	 * @param dataSource
	 *            DataSource instance
	 */
	public PersistSlbMatrixProcedure(DataSource dataSource) {
		setDataSource(dataSource);
		setSql(SQL);
		declareParameter(new SqlParameter("p_slb_matrix", Types.ARRAY,
				SLBMATRIX_TABLE_TYPE));
		declareParameter(new SqlParameter("p_container_id", Types.INTEGER));
		declareParameter(new SqlParameter("p_component_type", Types.INTEGER));
		compile();
	}

	public void execute() {
		if (CollectionsUtil.isEmpty(matrixs)) {
			throw new AimRuntimeException("SLB matrixs is null or empty"
					+ " when call PersistSlbMatrixProcedure");
		}

		final Map<String, Object> map = Maps.newHashMap();
		map.put("p_slb_matrix", new AbstractSqlTypeValue() {
			public Object createTypeValue(Connection con, int sqlType,
					String typeName) throws SQLException {
				return createSlbMatrixType(con);
			}
		});
		map.put("p_container_id", getContainerId());
		map.put("p_component_type", getUnitType());

		execute(map);
	}

	/**
	 * getMatrixs
	 * 
	 * @return SlbMatrix list
	 */
	public List<SlbMatrix> getMatrixs() {
		return matrixs;
	}

	/**
	 * create SLBMATRIX_TABLE_TYPE for MATCH_MANAGER_API.PERSIST_SLB_MATRIX
	 * 
	 * @param con
	 *            the instance of Connection
	 * @return
	 * @throws SQLException
	 */
	private Array createSlbMatrixType(Connection con) throws SQLException {
		OracleConnection oraConn = con.unwrap(OracleConnection.class);
		List<Struct> structs = Lists.newArrayList();
		for (SlbMatrix matrix : matrixs) {
			NUMBER unitNumber = oraConn.createNUMBER(matrix.getUnitId());
			NUMBER segNumber = oraConn.createNUMBER(matrix.getSegId());

			Struct struct = oraConn.createStruct(SLBMATRIX_OBJECT,
					new Object[] { unitNumber, segNumber });
			structs.add(struct);
		}
		return oraConn.createARRAY(SLBMATRIX_TABLE_TYPE, structs.toArray());
	}

	public int getUnitType() {
		return unitType;
	}

	public void setUnitType(int unitType) {
		this.unitType = unitType;
	}

	public long getContainerId() {
		return containerId;
	}

	public void setContainerId(long containerId) {
		this.containerId = containerId;
	}
}
