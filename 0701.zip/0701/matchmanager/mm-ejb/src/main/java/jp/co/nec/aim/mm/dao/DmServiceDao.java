package jp.co.nec.aim.mm.dao;

import java.util.List;

import javax.persistence.EntityManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.aim.mm.entities.DmServiceEntity;

public class DmServiceDao {

	/** log instance **/
	private static final Logger log = LoggerFactory.getLogger(DmServiceDao.class);
	private EntityManager em;

	public DmServiceDao(EntityManager em) {
		this.em = em;
	}	

	
	public DmServiceEntity findDM(String id) {
		return em.find(DmServiceEntity.class, id);
	}	
	
	public List<DmServiceEntity> findAllDmService() {
		String allSql = "select e from DmServiceEntity e";		 
		List<DmServiceEntity> result = em.createQuery(allSql, DmServiceEntity.class).getResultList();
		return result;
	}
}
