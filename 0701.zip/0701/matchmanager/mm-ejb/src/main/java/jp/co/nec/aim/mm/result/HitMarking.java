package jp.co.nec.aim.mm.result;



import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.aim.uid.jaxb.Response;

public class HitMarking {
	private static Logger log = LoggerFactory.getLogger(HitMarking.class);

	public static void markHits(Response finalResults,
			DynamicThresholdParams params) {
		int iCandidateCount = finalResults.getCandidateList().getCount();
				
		if (0 < iCandidateCount) {
			DynamicThresholdNew dynth = new DynamicThresholdNew(
					iCandidateCount, params);
			for (int i = 0; i < iCandidateCount; ++i) {
				// set each score
				dynth.dynthScoreList.dynthRecords[i].fusionScore = finalResults
						.getCandidateList().getCandidate().get(i).getScaledScore();
			}

			// perform decision method
			dynth.perform();

			// mark the hits.
//			for (int i = 0; i < iCandidateCount; ++i) {
//				if (dynth.dynthScoreList.dynthRecords[i].hitFlag == 1) {
//					finalResults.getCandidateList().isMore();	//no hit element						
//				}
//			}
		} else {
			log.debug("No candidates found for job " + finalResults.getRequestId()
					+ ", skipping dynamic thresholding logic.");
		}
	}
}
