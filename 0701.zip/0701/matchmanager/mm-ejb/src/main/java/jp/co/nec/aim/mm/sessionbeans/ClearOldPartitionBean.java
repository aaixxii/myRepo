package jp.co.nec.aim.mm.sessionbeans;

import java.time.LocalDate;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.aim.mm.dao.PartitionDao;
import jp.co.nec.aim.mm.dao.SystemInitDao;
import jp.co.nec.aim.mm.partition.PartitionUtil;

@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class ClearOldPartitionBean {
    
    private static final Logger logger = LoggerFactory.getLogger(ClearOldPartitionBean.class);
	
	private PartitionDao partitionDao;
	 private SystemInitDao systemInitDao;
	
	public ClearOldPartitionBean(DataSource dataSource, EntityManager entityManager) {
		systemInitDao = new SystemInitDao(entityManager);	
		partitionDao = new PartitionDao(dataSource);		
	}
	
	public void execute()  {
		Long saveDays = systemInitDao.getSegChangeLogSaveDays();
		LocalDate now = LocalDate.now();
		LocalDate deleteDay = now.minusDays(saveDays);	
//		if (skipDays.contains(deleteDay)) {
//			return;
//		}	
		long todayHashValue = PartitionUtil.getInstance().caculateHashAtThisToday(deleteDay);
		partitionDao.clearPartitionData(todayHashValue);
		logger.info("Success clear partition(p_no={}) for day({}) ", todayHashValue, deleteDay);
	}
}
