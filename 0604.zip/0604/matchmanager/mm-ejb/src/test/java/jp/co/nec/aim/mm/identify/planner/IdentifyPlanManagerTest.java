package jp.co.nec.aim.mm.identify.planner;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.sql.DataSource;

import jp.co.nec.aim.mm.dao.IdentifyPlannerDao;
import jp.co.nec.aim.mm.dao.IdentifyPlannerDaoImpl;
import jp.co.nec.aim.mm.entities.JobQueueEntity;
import jp.co.nec.aim.mm.notifier.IdentifyPlanCreatedNotifer;
import mockit.Mock;
import mockit.MockUp;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Maps;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
@TransactionConfiguration(transactionManager = "transactionManager")
public class IdentifyPlanManagerTest extends
		AbstractTransactionalJUnit4SpringContextTests {
	private static final String PROPERTY_FILE_NAME = "mu.ablity.properties";
	@PersistenceContext(unitName = "aim-db")
	private EntityManager entityManager;
	@Resource(mappedName = "java:jboss/MySqlDS")
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;
	@EJB
	IdentifyPlanManager identifyPlanManager;
	private IdentifyPlannerDao identifyPlannerDao;

	private Map<Integer, Integer> jobLimitMap = Maps.newHashMap();
	private static PrintStream bk_out = System.out;
	private static PrintStream bk_err = System.err;

	@Before
	public void setUp() throws Exception {
		jdbcTemplate = new JdbcTemplate(dataSource);
		identifyPlannerDao = new IdentifyPlannerDaoImpl(dataSource,
				entityManager);
		clearDB();
		saveJobLimit();
	}

	@After
	public void tearDown() throws Exception {
		clearDB();
		restoreJobLimit();
		identifyPlannerDao = null;
		System.setOut(bk_out);
		System.setErr(bk_err);
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testDoMakePlanProcess_normal() throws NoSuchMethodException,
			SecurityException, IllegalAccessException,
			IllegalArgumentException, InvocationTargetException,
			NoSuchFieldException {
		overrideByMock(true);
		Method method = IdentifyPlanManager.class
				.getDeclaredMethod("getMemMuSegmentMaps");
		method.setAccessible(true);
		ConcurrentHashMap<MuSegmentMapKey, List<MuSegmentMap>> memMap = (ConcurrentHashMap<MuSegmentMapKey, List<MuSegmentMap>>) method
				.invoke(identifyPlanManager);
		memMap.clear();

		prepareData_DoMakePlanProcess();
		ByteArrayOutputStream outContent = new ByteArrayOutputStream();
		ByteArrayOutputStream errContent = new ByteArrayOutputStream();
		System.setOut(new PrintStream(outContent));
		System.setErr(new PrintStream(errContent));
		identifyPlanManager.doMakePlanProcess();
		List<Map<String, Object>> recs = jdbcTemplate
				.queryForList("select job_id, count(*) as cnt from mu_job_execute_plans group by job_id");
		for (Map<String, Object> rec : recs) {
			long jobId = ((BigDecimal) rec.get("job_id")).longValue();
			int cnt = ((BigDecimal) rec.get("cnt")).intValue();
			if (jobId == 1000L || jobId == 1002L) {
				Assert.assertEquals(2, cnt);
			} else if (jobId == 1001L) {
				Assert.assertEquals(2, cnt);
			} else {
				Assert.fail("Unknown jobId!!");
			}
		}
		//assertLogMessg(outContent);		
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testDoMakePlanProcess_batch() throws NoSuchMethodException,
			SecurityException, IllegalAccessException,
			IllegalArgumentException, InvocationTargetException,
			NoSuchFieldException {
		overrideByMock(true);
		Method method = IdentifyPlanManager.class
				.getDeclaredMethod("getMemMuSegmentMaps");
		method.setAccessible(true);
		ConcurrentHashMap<MuSegmentMapKey, List<MuSegmentMap>> memMap = (ConcurrentHashMap<MuSegmentMapKey, List<MuSegmentMap>>) method
				.invoke(identifyPlanManager);
		memMap.clear();

		int jobNum = 60;
		Long[] jobIds = new Long[jobNum];
		int[] familyIds = new int[jobNum];
		int[] funcIds = new int[jobNum];
		for (int i = 0; i < jobNum; i++) {
			jobIds[i] = 2000L + i + 1;
			familyIds[i] = 1;
			funcIds[i] = 1;
		}
		prepareData_DoMakePlanProcess(jobIds, familyIds, funcIds);
		ByteArrayOutputStream outContent = new ByteArrayOutputStream();
		ByteArrayOutputStream errContent = new ByteArrayOutputStream();
		System.setOut(new PrintStream(outContent));
		System.setErr(new PrintStream(errContent));
		jdbcTemplate.update("update inquiry_traffic set job_limit_count = 100 "
				+ "where family_name = 'TI'");
		Field field = IdentifyPlanManager.class
				.getDeclaredField("commitThreashold");
		field.setAccessible(true);
		final int defaultCommitThreshold = (int) field.get(identifyPlanManager);
		identifyPlanManager.doMakePlanProcess();
		List<Map<String, Object>> recs = jdbcTemplate
				.queryForList("select job_id, count(*) as cnt from mu_job_execute_plans group by job_id");
		for (Map<String, Object> rec : recs) {
			int cnt = ((BigDecimal) rec.get("cnt")).intValue();
			Assert.assertEquals(2, cnt);
		}
		//assertLogMessgBatch(jobNum, jobIds, outContent, defaultCommitThreshold);		
	}

	@Test
	public void testDoMakePlanProcess_notify_failed_rollback_spring_datasouce_not_working() {
		overrideByMock(false);
		prepareData_DoMakePlanProcess();
		identifyPlanManager.doMakePlanProcess();		
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testProcessOneJob_normal() throws NoSuchMethodException,
			SecurityException, IllegalAccessException,
			IllegalArgumentException, InvocationTargetException {
		overrideByMock(true);

		String jobQueueSql = "insert into job_queue(job_id,priority,job_state,submission_ts,callback_style,failure_count,remain_jobs,family_id)"
				+ " values(?,1,0,3000,0,0,0,?)";
		String fusionJobSql = "insert into fusion_jobs(fusion_job_id,function_id,job_id,search_request_index) values(?,?,?,?)";
		String contaiJobSql = "insert into container_jobs(container_job_id,container_id,fusion_job_id,job_state) values(?,?,?,0)";
		String defragBeanSql = "insert into segment_defragmentation(container_id,start_ts,end_ts) values(5,2000,3000)";

		Long[] jobIds = { 1000L, 1001L, 1002L };
		int[] familyIds = { 1, 1, 1 };
		int[] functionIds = { 1, 1, 1 };
		long[][] fusionJobIds = new long[jobIds.length][2];
		long[][] containerJobIds = new long[jobIds.length][2];
		int[][] searchIndexs = new int[jobIds.length][2];
		int[][] containerIds = new int[jobIds.length][2];

		long baseFusionJobId = 2000l;
		long containerJobId = 5000l;
		int searchIndex = 0;
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 2; j++) {
				fusionJobIds[i][j] = baseFusionJobId++;
				containerJobIds[i][j] = containerJobId++;
				searchIndexs[i][j] = searchIndex++;
				if (i == 0 && j == 0 || i == 0 && j == 1) {
					containerIds[i][j] = 1;
				}
				if (i == 1 && j == 0 || i == 1 && j == 1) {
					containerIds[i][j] = 1;
				}
				if (i == 2 && j == 0 || i == 2 && j == 1) {
					containerIds[i][j] = 1;
				}
			}
		}
		for (int i = 0; i < jobIds.length; i++) {
			jdbcTemplate.update(jobQueueSql, new Object[] { jobIds[i],
					new Long(familyIds[i]) });
		}
		for (int i = 0; i < fusionJobIds.length; i++) {
			for (int j = 0; j < fusionJobIds[0].length; j++) {
				jdbcTemplate.update(fusionJobSql, new Object[] {
						new Long(fusionJobIds[i][j]),
						new Integer(functionIds[i]), new Long(jobIds[i]),
						new Integer(searchIndexs[i][j]) });
			}
		}

		for (int i = 0; i < containerJobIds.length; i++) {
			for (int j = 0; j < containerJobIds[0].length; j++) {
				jdbcTemplate.update(contaiJobSql, new Object[] {
						new Long(containerJobIds[i][j]),
						new Integer(containerIds[i][j]),
						new Long(fusionJobIds[i][j]) });
			}
		}
		jdbcTemplate.update(defragBeanSql);
		List<TopJobInfo> results = null;
		ConcurrentHashMap<MuSegmentMapKey, Boolean> alreadyPlannedMap = new ConcurrentHashMap<MuSegmentMapKey, Boolean>();
		try {
			results = identifyPlannerDao.getJobInfoForCreatePlans(jobIds);
		} catch (DataAccessException e) {
			e.printStackTrace();
		}
		long ts = System.currentTimeMillis();
		String insertRUCsql = "insert into resource_update_count (UPDATE_COUNT,UPDATE_TS)"
				+ " values (?,?)";
		jdbcTemplate.update(insertRUCsql, new Object[] { new Long(100),
				new Long(ts) });
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_MATCHERS,REPORTED_PERFORMANCE_FACTOR) "
				+ "VALUES(?,?,'WORKING',?,?)";

		String segSql = "insert into segments (SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,"
				+ "BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)"
				+ " values(?, ?, 1, 10, 10, 10, ?, 1, 100)";

		String mecSql = " insert into MU_ELIGIBLE_CONTAINERS(CONTAINER_ID,MU_ID) values(?,?)";
		String mefSql = "insert into MU_ELIGIBLE_FUNCTIONS( FUNCTION_ID,MU_ID) values(?,?)";
		String muSegReportSql = "insert into mu_seg_reports(mu_id,segment_id,status,segment_version) values(?,?,1,?)";

		Integer containerId = 1;
		Integer functionId = 1;
		Integer[] muIds = { 1, 2, 3, 4 };
		Integer[] muCpus = { 4, 8, 12, 8 };
		Double[] reportedPerformanceFactor = { 1.8D, 1.8D, 2.4D, 2.4D };
		Long[] segIds = { 1000L, 1001L, 1002L, 1003L, 1004L, 1005L, 1006L,
				1007L };
		Long[] segVer = { 1L, 1L, 2L, 2L, 3L, 4L, 5L, 6L };

		for (int i = 0; i < muIds.length; i++) {
			jdbcTemplate.update(
					muSql,
					new Object[] { muIds[i],
							String.valueOf(muIds[i].longValue()), muCpus[i],
							reportedPerformanceFactor[i] });
			jdbcTemplate.update(mecSql, new Object[] { containerId, muIds[i] });
			jdbcTemplate.update(mefSql, new Object[] { functionId, muIds[i] });
		}

		for (int i = 0; i < segIds.length; i++) {
			jdbcTemplate.update(segSql, new Object[] { segIds[i], containerId,
					segVer[i] });
		}
		int currentMu = 0;
		for (int i = 0; i < segIds.length; i++) {
			if (currentMu >= muIds.length) {
				currentMu = 0;
			}
			jdbcTemplate.update(muSegReportSql, new Object[] {
					muIds[currentMu], segIds[i], segVer[i] });
			currentMu++;
		}
		String inquiryLoadSql = "INSERT INTO MU_INQUIRY_LOAD (MU_ID, PRESSURE, REPORT_TS)  VALUES(?,?,?)";
		Long[] muPressure = { 4l, 5l, 6l, 7l };
		Long updateTS = new Long(System.currentTimeMillis());
		for (int i = 0; i < muIds.length; i++) {
			jdbcTemplate.update(inquiryLoadSql, new Object[] { muIds[i],
					muPressure[i], updateTS });
		}
		jdbcTemplate.update("commit");
		Method method = IdentifyPlanManager.class.getDeclaredMethod(
				"processOneJob", TopJobInfo.class, ConcurrentHashMap.class);
		method.setAccessible(true);
		for (int i = 0; i < results.size(); i++) {
			if (results.get(i).getTopJobId() != 1001L) {
				List<MuJobExecutePlan> plans = (List<MuJobExecutePlan>) method
						.invoke(identifyPlanManager, results.get(i),
								alreadyPlannedMap);
				Assert.assertTrue(plans.size() > 0);
				String getMaxPlanId = "select max(plan_id) from mu_job_execute_plans";
				Long planId = jdbcTemplate.queryForObject(getMaxPlanId,
						Long.class);
				Assert.assertNotNull(planId);
				JobQueueEntity jobQueue = entityManager.find(
						JobQueueEntity.class, jobIds[i].longValue());
				Assert.assertEquals(1, jobQueue.getJobState().ordinal());
				Assert.assertNotNull(jobQueue.getAssignedTs());
			}
		}		
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testProcessOneJob_URC_not_changed()
			throws NoSuchMethodException, SecurityException,
			IllegalAccessException, IllegalArgumentException,
			InvocationTargetException {
		overrideByMock(true);
		String jobQueueSql = "insert into job_queue(job_id,priority,job_state,submission_ts,callback_style,failure_count,remain_jobs,family_id)"
				+ " values(?,1,0,3000,0,0,0,?)";
		String fusionJobSql = "insert into fusion_jobs(fusion_job_id,function_id,job_id,search_request_index) values(?,?,?,?)";
		String contaiJobSql = "insert into container_jobs(container_job_id,container_id,fusion_job_id,job_state) values(?,?,?,0)";
		String defragBeanSql = "insert into segment_defragmentation(container_id,start_ts,end_ts) values(5,2000,3000)";

		Long[] jobIds = { 1000L, 1001L, 1002L };
		int[] familyIds = { 1, 1, 1 };
		int[] functionIds = { 1, 1, 1 };
		long[][] fusionJobIds = new long[jobIds.length][2];
		long[][] containerJobIds = new long[jobIds.length][2];
		int[][] searchIndexs = new int[jobIds.length][2];
		int[][] containerIds = new int[jobIds.length][2];

		long baseFusionJobId = 2000l;
		long containerJobId = 5000l;
		int searchIndex = 0;
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 2; j++) {
				fusionJobIds[i][j] = baseFusionJobId++;
				containerJobIds[i][j] = containerJobId++;
				searchIndexs[i][j] = searchIndex++;
				if (i == 0 && j == 0 || i == 0 && j == 1) {
					containerIds[i][j] = 1;
				}
				if (i == 1 && j == 0 || i == 1 && j == 1) {
					containerIds[i][j] = 1;
				}
				if (i == 2 && j == 0 || i == 2 && j == 1) {
					containerIds[i][j] = 1;
				}
			}
		}
		for (int i = 0; i < jobIds.length; i++) {
			jdbcTemplate.update(jobQueueSql, new Object[] { jobIds[i],
					new Long(familyIds[i]) });
		}
		for (int i = 0; i < fusionJobIds.length; i++) {
			for (int j = 0; j < fusionJobIds[0].length; j++) {
				jdbcTemplate.update(fusionJobSql, new Object[] {
						new Long(fusionJobIds[i][j]),
						new Integer(functionIds[i]), new Long(jobIds[i]),
						new Integer(searchIndexs[i][j]) });
			}
		}

		for (int i = 0; i < containerJobIds.length; i++) {
			for (int j = 0; j < containerJobIds[0].length; j++) {
				jdbcTemplate.update(contaiJobSql, new Object[] {
						new Long(containerJobIds[i][j]),
						new Integer(containerIds[i][j]),
						new Long(fusionJobIds[i][j]) });
			}
		}
		jdbcTemplate.update(defragBeanSql);
		List<TopJobInfo> results = null;
		ConcurrentHashMap<MuSegmentMapKey, Boolean> alreadyPlannedMap = new ConcurrentHashMap<MuSegmentMapKey, Boolean>();
		try {
			results = identifyPlannerDao.getJobInfoForCreatePlans(jobIds);
		} catch (DataAccessException e) {
			e.printStackTrace();
		}
		long ts = System.currentTimeMillis();
		String insertRUCsql = "insert into resource_update_count (UPDATE_COUNT,UPDATE_TS)"
				+ " values (?,?)";
		jdbcTemplate.update(insertRUCsql, new Object[] { new Long(100L),
				new Long(ts) });

		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_MATCHERS,REPORTED_PERFORMANCE_FACTOR) "
				+ "VALUES(?,?,'WORKING',?,?)";

		String segSql = "insert into segments (SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,"
				+ "BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)"
				+ " values(?, ?, 1, 10, 10, 10, ?, 1, 100)";

		String mecSql = " insert into MU_ELIGIBLE_CONTAINERS(CONTAINER_ID,MU_ID) values(?,?)";
		String mefSql = "insert into MU_ELIGIBLE_FUNCTIONS( FUNCTION_ID,MU_ID) values(?,?)";
		String muSegReportSql = "insert into mu_seg_reports(mu_id,segment_id,status,segment_version) values(?,?,1,?)";

		Integer containerId = 1;
		Integer functionId = 1;
		Integer[] muIds = { 1, 2, 3, 4 };
		Integer[] muCpus = { 4, 8, 12, 8 };
		Double[] reportedPerformanceFactor = { 1.8D, 1.8D, 2.4D, 2.4D };
		Long[] segIds = { 1000L, 1001L, 1002L, 1003L, 1004L, 1005L, 1006L,
				1007L };
		Long[] segVer = { 1L, 1L, 2L, 2L, 3L, 4L, 5L, 6L };

		for (int i = 0; i < muIds.length; i++) {
			jdbcTemplate.update(
					muSql,
					new Object[] { muIds[i],
							String.valueOf(muIds[i].longValue()), muCpus[i],
							reportedPerformanceFactor[i] });
			jdbcTemplate.update(mecSql, new Object[] { containerId, muIds[i] });
			jdbcTemplate.update(mefSql, new Object[] { functionId, muIds[i] });
		}

		for (int i = 0; i < segIds.length; i++) {
			jdbcTemplate.update(segSql, new Object[] { segIds[i], containerId,
					segVer[i] });
		}
		int currentMu = 0;
		for (int i = 0; i < segIds.length; i++) {
			if (currentMu >= muIds.length) {
				currentMu = 0;
			}
			jdbcTemplate.update(muSegReportSql, new Object[] {
					muIds[currentMu], segIds[i], segVer[i] });
			currentMu++;
		}
		String inquiryLoadSql = "INSERT INTO MU_INQUIRY_LOAD (MU_ID, PRESSURE, REPORT_TS)  VALUES(?,?,?)";
		Long[] muPressure = { 4l, 5l, 6l, 7l };
		Long updateTS = new Long(System.currentTimeMillis());
		for (int i = 0; i < muIds.length; i++) {
			jdbcTemplate.update(inquiryLoadSql, new Object[] { muIds[i],
					muPressure[i], updateTS });
		}
		jdbcTemplate.update("commit");
		Method setMemoryURC = IdentifyPlanManager.class.getDeclaredMethod(
				"setRUC", ResoureceUpdateCount.class);
		setMemoryURC.setAccessible(true);
		Long dbRuc = -999L;
		try {
			dbRuc = identifyPlannerDao.getRUCFromDB();
		} catch (PersistenceException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		ResoureceUpdateCount ruc = new ResoureceUpdateCount();
		ruc.setUpdateCount(dbRuc);
		setMemoryURC.invoke(identifyPlanManager, ruc);

		Method getMemoryMap = IdentifyPlanManager.class
				.getDeclaredMethod("getMemMuSegmentMaps");
		getMemoryMap.setAccessible(true);
		ConcurrentHashMap<MuSegmentMapKey, List<MuSegmentMap>> tmpMap = (ConcurrentHashMap<MuSegmentMapKey, List<MuSegmentMap>>) getMemoryMap
				.invoke(identifyPlanManager);

		List<MuSegmentMap> tmpList1 = createTestMuSegMaps(8, 1, 1, 0);
		tmpMap.put(new MuSegmentMapKey(1, 1), tmpList1);

		List<MuSegmentMap> tmpList2 = createTestMuSegMaps(8, 2, 2, 0);
		tmpMap.put(new MuSegmentMapKey(2, 2), tmpList2);

		Method method = IdentifyPlanManager.class.getDeclaredMethod(
				"processOneJob", TopJobInfo.class, ConcurrentHashMap.class);
		method.setAccessible(true);
		for (int i = 0; i < results.size(); i++) {
			if (results.get(i).getTopJobId() != 1001L) {
				List<MuJobExecutePlan> plans = (List<MuJobExecutePlan>) method
						.invoke(identifyPlanManager, results.get(i),
								alreadyPlannedMap);
				Assert.assertTrue(plans.size() > 0);
				String getMaxPlanId = "select max(plan_id) from mu_job_execute_plans";
				Long planId = jdbcTemplate.queryForObject(getMaxPlanId,
						Long.class);
				Assert.assertNotNull(planId);
				JobQueueEntity jobQueue = entityManager.find(
						JobQueueEntity.class, jobIds[i].longValue());
				Assert.assertEquals(1, jobQueue.getJobState().ordinal());
				Assert.assertNotNull(jobQueue.getAssignedTs());
			}
		}		
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testProcessOneJob_URC_not_changed_more_one()
			throws NoSuchMethodException, SecurityException,
			IllegalAccessException, IllegalArgumentException,
			InvocationTargetException {
		overrideByMock(true);
		String jobQueueSql = "insert into job_queue(job_id,priority,job_state,submission_ts,callback_style,failure_count,remain_jobs,family_id)"
				+ " values(?,1,0,3000,0,0,0,?)";
		String fusionJobSql = "insert into fusion_jobs(fusion_job_id,function_id,job_id,search_request_index) values(?,?,?,?)";
		String contaiJobSql = "insert into container_jobs(container_job_id,container_id,fusion_job_id,job_state) values(?,?,?,0)";
		String defragBeanSql = "insert into segment_defragmentation(container_id,start_ts,end_ts) values(5,2000,3000)";

		Long[] jobIds = { 1000L, 1001L, 1002L };
		int[] familyIds = { 1, 1, 1 };
		int[] functionIds = { 1, 1, 1 };
		long[][] fusionJobIds = new long[jobIds.length][2];
		long[][] containerJobIds = new long[jobIds.length][2];
		int[][] searchIndexs = new int[jobIds.length][2];
		int[][] containerIds = new int[jobIds.length][2];

		long baseFusionJobId = 2000l;
		long containerJobId = 5000l;
		int searchIndex = 0;
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 2; j++) {
				fusionJobIds[i][j] = baseFusionJobId++;
				containerJobIds[i][j] = containerJobId++;
				searchIndexs[i][j] = searchIndex++;
				if (i == 0 && j == 0 || i == 0 && j == 1) {
					containerIds[i][j] = 1;
				}
				if (i == 1 && j == 0 || i == 1 && j == 1) {
					containerIds[i][j] = 1;
				}
				if (i == 2 && j == 0 || i == 2 && j == 1) {
					containerIds[i][j] = 1;
				}
			}
		}
		for (int i = 0; i < jobIds.length; i++) {
			jdbcTemplate.update(jobQueueSql, new Object[] { jobIds[i],
					new Long(familyIds[i]) });
		}
		for (int i = 0; i < fusionJobIds.length; i++) {
			for (int j = 0; j < fusionJobIds[0].length; j++) {
				jdbcTemplate.update(fusionJobSql, new Object[] {
						new Long(fusionJobIds[i][j]),
						new Integer(functionIds[i]), new Long(jobIds[i]),
						new Integer(searchIndexs[i][j]) });
			}
		}

		for (int i = 0; i < containerJobIds.length; i++) {
			for (int j = 0; j < containerJobIds[0].length; j++) {
				jdbcTemplate.update(contaiJobSql, new Object[] {
						new Long(containerJobIds[i][j]),
						new Integer(containerIds[i][j]),
						new Long(fusionJobIds[i][j]) });
			}
		}
		jdbcTemplate.update(defragBeanSql);
		List<TopJobInfo> results = null;
		ConcurrentHashMap<MuSegmentMapKey, Boolean> alreadyPlannedMap = new ConcurrentHashMap<MuSegmentMapKey, Boolean>();
		try {
			results = identifyPlannerDao.getJobInfoForCreatePlans(jobIds);
		} catch (DataAccessException e) {
			e.printStackTrace();
		}
		long ts = System.currentTimeMillis();
		String insertRUCsql = "insert into resource_update_count (UPDATE_COUNT,UPDATE_TS)"
				+ " values (?,?)";
		jdbcTemplate.update(insertRUCsql, new Object[] { new Long(100),
				new Long(ts) });

		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_MATCHERS,REPORTED_PERFORMANCE_FACTOR) "
				+ "VALUES(?,?,'WORKING',?,?)";

		String segSql = "insert into segments (SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,"
				+ "BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)"
				+ " values(?, ?, 1, 10, 10, 10, ?, 1, 100)";

		String mecSql = " insert into MU_ELIGIBLE_CONTAINERS(CONTAINER_ID,MU_ID) values(?,?)";
		String mefSql = "insert into MU_ELIGIBLE_FUNCTIONS( FUNCTION_ID,MU_ID) values(?,?)";
		String muSegReportSql = "insert into mu_seg_reports(mu_id,segment_id,status,segment_version) values(?,?,1,?)";

		Integer containerId = 1;
		Integer functionId = 1;
		Integer[] muIds = { 1, 2, 3, 4 };
		Integer[] muCpus = { 4, 8, 12, 8 };
		Double[] reportedPerformanceFactor = { 1.8D, 1.8D, 2.4D, 2.4D };
		Long[] segIds = { 1000L, 1001L, 1002L, 1003L, 1004L, 1005L, 1006L };

		Long[] segVer = { 1L, 1L, 2L, 2L, 3L, 4L, 5L };

		for (int i = 0; i < muIds.length; i++) {
			jdbcTemplate.update(
					muSql,
					new Object[] { muIds[i],
							String.valueOf(muIds[i].longValue()), muCpus[i],
							reportedPerformanceFactor[i] });
			jdbcTemplate.update(mecSql, new Object[] { containerId, muIds[i] });
			jdbcTemplate.update(mefSql, new Object[] { functionId, muIds[i] });
		}

		for (int i = 0; i < segIds.length; i++) {
			jdbcTemplate.update(segSql, new Object[] { segIds[i], containerId,
					segVer[i] });
		}
		int currentMu = 0;
		for (int i = 0; i < segIds.length; i++) {
			if (currentMu >= muIds.length) {
				currentMu = 0;
			}
			jdbcTemplate.update(muSegReportSql, new Object[] {
					muIds[currentMu], segIds[i], segVer[i] });
			currentMu++;
		}
		String inquiryLoadSql = "INSERT INTO MU_INQUIRY_LOAD (MU_ID, PRESSURE, REPORT_TS)  VALUES(?,?,?)";
		Long[] muPressure = { 4l, 5l, 6l, 7l };
		Long updateTS = new Long(System.currentTimeMillis());
		for (int i = 0; i < muIds.length; i++) {
			jdbcTemplate.update(inquiryLoadSql, new Object[] { muIds[i],
					muPressure[i], updateTS });
		}
		jdbcTemplate.update("commit");
		Method setMemoryURC = IdentifyPlanManager.class.getDeclaredMethod(
				"setRUC", ResoureceUpdateCount.class);
		setMemoryURC.setAccessible(true);
		Long dbRuc = -999L;
		try {
			dbRuc = identifyPlannerDao.getRUCFromDB();
		} catch (PersistenceException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		ResoureceUpdateCount ruc = new ResoureceUpdateCount();
		ruc.setUpdateCount(dbRuc.longValue());
		setMemoryURC.invoke(identifyPlanManager, ruc);

		Method getMemoryMap = IdentifyPlanManager.class
				.getDeclaredMethod("getMemMuSegmentMaps");
		getMemoryMap.setAccessible(true);
		ConcurrentHashMap<MuSegmentMapKey, List<MuSegmentMap>> tmpMap = (ConcurrentHashMap<MuSegmentMapKey, List<MuSegmentMap>>) getMemoryMap
				.invoke(identifyPlanManager);

		List<MuSegmentMap> tmpList1 = createTestMuSegMaps(7, 1, 1, 0);
		tmpMap.put(new MuSegmentMapKey(1, 1), tmpList1);

		List<MuSegmentMap> tmpList2 = createTestMuSegMaps(7, 2, 2, 0);
		tmpMap.put(new MuSegmentMapKey(2, 2), tmpList2);

		Method method = IdentifyPlanManager.class.getDeclaredMethod(
				"processOneJob", TopJobInfo.class, ConcurrentHashMap.class);
		method.setAccessible(true);
		for (int i = 0; i < results.size(); i++) {
			if (results.get(i).getTopJobId() != 1001L) {
				List<MuJobExecutePlan> plans = (List<MuJobExecutePlan>) method
						.invoke(identifyPlanManager, results.get(i),
								alreadyPlannedMap);
				Assert.assertTrue(plans.size() > 0);
				String getMaxPlanId = "select max(plan_id) from mu_job_execute_plans";
				Long planId = jdbcTemplate.queryForObject(getMaxPlanId,
						Long.class);
				Assert.assertNotNull(planId);
				JobQueueEntity jobQueue = entityManager.find(
						JobQueueEntity.class, jobIds[i].longValue());
				Assert.assertEquals(1, jobQueue.getJobState().ordinal());
				Assert.assertNotNull(jobQueue.getAssignedTs());
			}
		}		
	}

	private void assertLogMessg(ByteArrayOutputStream outContent) {
		String logStr = outContent.toString();
		String start1stPlanningMessg = "Start planning jobId=1000";
		String start2ndPlanningMessg = "Start planning jobId=1001";
		String start3rdPlanningMessg = "Start planning jobId=1002";
		String skipSegVerFetchMessg = "Skip fetching segment version because already got it at the previous planning.";
		String changeFamilyIdMessg = "changed familyId against previous one.";
		Assert.assertEquals(1, logStr.split(changeFamilyIdMessg).length);
		Assert.assertEquals(3, logStr.split(skipSegVerFetchMessg).length);
		int start1stIndex = logStr.indexOf(start1stPlanningMessg);
		int start2ndIndex = logStr.indexOf(start2ndPlanningMessg);
		int start3rdIndex = logStr.indexOf(start3rdPlanningMessg);
		int changeFamilyIdIndex = logStr.indexOf(changeFamilyIdMessg);
		int skipIndex = logStr.indexOf(skipSegVerFetchMessg);
		Assert.assertTrue(start1stIndex < changeFamilyIdIndex
				&& changeFamilyIdIndex < start2ndIndex);
		Assert.assertTrue(start3rdIndex < skipIndex);
	}
	

	private void assertLogMessgBatch(int jobNum, Long[] jobIds,
			ByteArrayOutputStream outContent, int commitThreashold)
			throws NoSuchFieldException,
			SecurityException, IllegalArgumentException, IllegalAccessException {
		String logStr = outContent.toString();
		Field field = IdentifyPlanManager.class
				.getDeclaredField("COMMIT_THREASHOLD_MAX_LIMIT");
		field.setAccessible(true);
		final int maxCommitThreshold = (int) field.get(identifyPlanManager);
		final int expMessgCnt = getExpMaxThCommitMessgCnt(jobNum,
				commitThreashold,
				maxCommitThreshold);
		int lastCommitIndex = 0;
		int plannedCnt = 0;
		for (int i = 0; i < jobNum; i++) {
			plannedCnt++;
			if (plannedCnt == commitThreashold) {
				String startPlanningMessg = String.format(
						"Start planning jobId=%d", jobIds[i]);
				String startNextPlanningMessg = String.format(
						"Start planning jobId=%d", jobIds[i] + 1);
				String commitMessg = String.format(
						"Already %d times planned or", commitThreashold);
				int commitIndex = logStr.indexOf(commitMessg,
						lastCommitIndex + 1);
				int startPlanIndex = logStr.indexOf(startPlanningMessg);
				int startNextPlanIndex = logStr.indexOf(startNextPlanningMessg);
				Assert.assertTrue(
						String.format(
								"i=%d jobId=%d plannedCnt=%d commitThreashold=%d startPlanIndex=%d startNextPlanIndex=%d commitIndex=%d",
								i, jobIds[i], plannedCnt, commitThreashold,
								startPlanIndex, startNextPlanIndex, commitIndex),
						startPlanIndex < commitIndex
								&& commitIndex < startNextPlanIndex);
				if (commitThreashold < maxCommitThreshold) {
					Assert.assertEquals(2, logStr.split(commitMessg).length);
				} else {
					Assert.assertEquals(expMessgCnt,
							logStr.split(commitMessg).length);
				}
				lastCommitIndex = commitIndex;
				plannedCnt = 0;
				commitThreashold = Math.min(maxCommitThreshold,
						++commitThreashold);
			}
		}
		String skipSegVerFetchMessg = "Skip fetching segment version because already got it at the previous planning.";
		Assert.assertEquals(jobNum, logStr.split(skipSegVerFetchMessg).length);
	}

	

	private int getExpMaxThCommitMessgCnt(int jobNum, int commitThreshold,
			int maxCommitThreshold) {
		int expMessgCnt = 0;
		while (0 < jobNum) {
			jobNum -= commitThreshold++;
			commitThreshold = Math.min(commitThreshold++, maxCommitThreshold);
			if (commitThreshold == maxCommitThreshold
					&& maxCommitThreshold <= jobNum) {
				expMessgCnt++;
			}
		}
		return expMessgCnt + 1;
	}

	public void prepareData_DoMakePlanProcess() {
		Long[] jobIds = { 1000L, 1001L, 1002L };
		int[] familyIds = { 1, 1, 1 };
		int[] functionIds = { 1, 1, 1 };
		prepareData_DoMakePlanProcess(jobIds, familyIds, functionIds);
	}

	public void prepareData_DoMakePlanProcess(Long[] jobIds, int[] familyIds,
			int[] functionIds) {
		String insertMrSql = "insert into map_reducers(mr_id,unique_id,state) values(?,?,'WORKING')";
		Long[] mrIds = { 1000L, 1001L, 1002L, 1003L, 1004L };
		String[] uniqueIds = { "1000", "1001", "1002", "1003", "1004" };
		for (int i = 0; i < mrIds.length; i++) {
			jdbcTemplate.update(insertMrSql, new Object[] { mrIds[i],
					uniqueIds[i] });
		}
		String jobQueueSql = "insert into job_queue(job_id,priority,job_state,submission_ts,callback_style,failure_count,remain_jobs,family_id)"
				+ " values(?,1,0,3000,0,0,0,?)";
		String fusionJobSql = "insert into fusion_jobs(fusion_job_id,function_id,job_id,search_request_index) values(?,?,?,?)";
		String contaiJobSql = "insert into container_jobs(container_job_id,container_id,fusion_job_id,job_state) values(?,?,?,0)";
		String defragBeanSql = "insert into segment_defragmentation(container_id,start_ts,end_ts) values(5,2000,3000)";

		long[][] fusionJobIds = new long[jobIds.length][2];
		long[][] containerJobIds = new long[jobIds.length][2];
		int[][] searchIndexs = new int[jobIds.length][2];
		int[][] containerIds = new int[jobIds.length][2];

		long baseFusionJobId = 2000l;
		long containerJobId = 1;
		for (int i = 0; i < jobIds.length; i++) {
			for (int j = 0; j < 2; j++) {
				fusionJobIds[i][j] = baseFusionJobId++;
				containerJobIds[i][j] = containerJobId++;
				searchIndexs[i][j] = j + 1;
				if (i == 0 && j == 0 || i == 0 && j == 1) {
					containerIds[i][j] = 1;
				}
				if (i == 1 && j == 0 || i == 1 && j == 1) {
					containerIds[i][j] = 1;
				}
				if (i == 2 && j == 0 || i == 2 && j == 1) {
					containerIds[i][j] = 1;
				} else {
					containerIds[i][j] = 1;
				}
			}
		}
		for (int i = 0; i < jobIds.length; i++) {
			jdbcTemplate.update(jobQueueSql, new Object[] { jobIds[i],
					new Long(familyIds[i]) });
		}
		for (int i = 0; i < fusionJobIds.length; i++) {
			for (int j = 0; j < fusionJobIds[0].length; j++) {
				jdbcTemplate.update(fusionJobSql, new Object[] {
						new Long(fusionJobIds[i][j]),
						new Integer(functionIds[i]), new Long(jobIds[i]),
						new Integer(searchIndexs[i][j]) });
			}
		}
		for (int i = 0; i < containerJobIds.length; i++) {
			for (int j = 0; j < containerJobIds[0].length; j++) {
				jdbcTemplate.update(contaiJobSql, new Object[] {
						new Long(containerJobIds[i][j]),
						new Integer(containerIds[i][j]),
						new Long(fusionJobIds[i][j]) });
			}
		}
		jdbcTemplate.update(defragBeanSql);
		long updateTs = System.currentTimeMillis();
		long oldRUC = 1000;
		String insertRUCsql = "insert into resource_update_count (UPDATE_COUNT,UPDATE_TS)"
				+ "values (?,?)";
		jdbcTemplate.update(insertRUCsql, new Object[] { new Long(oldRUC),
				new Long(updateTs) });
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_MATCHERS,REPORTED_PERFORMANCE_FACTOR) "
				+ "VALUES(?,?,'WORKING',4,2.4)";

		String segSql = "insert into segments (SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,"
				+ "BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)"
				+ " values(?, ?, 1, 10, 10, 10, ?, 1, 100)";

		String mecSql = " insert into MU_ELIGIBLE_CONTAINERS(CONTAINER_ID,MU_ID) values(?,?)";
		String mefSql = "insert into MU_ELIGIBLE_FUNCTIONS( FUNCTION_ID,MU_ID) values(?,?)";
		String muSegReportSql = "insert into mu_seg_reports(mu_id,segment_id,status,segment_version) values(?,?,1,?)";

		Integer containerId = 1;
		Integer functionId = 1;
		Integer[] muIds = { 1, 2, 3, 4 };
		Long[] segIds = { 1000L, 1001L, 1002L, 1003L, 1004L, 1005L, 1006L,
				1007L };
		Long[] segVer = { 1L, 1L, 2L, 2L, 3L, 4L, 5L, 6L };

		for (int i = 0; i < muIds.length; i++) {
			jdbcTemplate.update(
					muSql,
					new Object[] { muIds[i],
							String.valueOf(muIds[i].longValue()) });
			jdbcTemplate.update(mecSql, new Object[] { containerId, muIds[i] });
			jdbcTemplate.update(mefSql, new Object[] { functionId, muIds[i] });
		}

		for (int i = 0; i < segIds.length; i++) {
			jdbcTemplate.update(segSql, new Object[] { segIds[i], containerId,
					segVer[i] });
		}
		int currentMu = 0;
		for (int i = 0; i < segIds.length; i++) {
			if (currentMu >= muIds.length) {
				currentMu = 0;
			}
			jdbcTemplate.update(muSegReportSql, new Object[] {
					muIds[currentMu], segIds[i], segVer[i] });
			currentMu++;
		}
		Long[] muPressure = { 4l, 5l, 6l, 7l };
		Long updateTS = new Long(System.currentTimeMillis());
		String inquiryLoadSql = "INSERT INTO MU_INQUIRY_LOAD (MU_ID, PRESSURE, REPORT_TS)  VALUES(?,?,?)";
		for (int i = 0; i < muIds.length; i++) {
			jdbcTemplate.update(inquiryLoadSql, new Object[] { muIds[i],
					muPressure[i], updateTS });
		}
		jdbcTemplate.execute("commit");
	}

	public Map<String, Double> getAllValues() {
		InputStream input = this.getClass().getClassLoader()
				.getResourceAsStream(PROPERTY_FILE_NAME);
		Properties prop = new Properties();
		Map<String, Double> results = new HashMap<>();
		Set<String> keys = new HashSet<String>();
		try {
			prop.load(input);
			Set<Object> sets = prop.keySet();
			Iterator<Object> it = sets.iterator();
			while (it.hasNext()) {
				String tmp = (String) it.next();
				keys.add(tmp);
			}
			for (String key : keys) {
				results.put(key, Double.valueOf(prop.getProperty(key)));
			}
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
		return results;
	}

	public List<MuSegmentMap> createTestMuSegMaps(int size, Integer functionId,
			Integer containerId, int sameSegCount) {
		List<MuSegmentMap> maps = new ArrayList<>();
		Long[] segIds = new Long[size];
		Long[] segVer = new Long[size];
		// Long[] segIds = { 1000L, 1001L, 1002L, 1003L, 1004L, 1005L,
		// 1006L,1007L };
		// Long[] segVer = { 1L, 1L, 2L, 2L, 3L, 4L, 5L, 6L };
		for (int i = 0; i < size; i++) {
			segIds[i] = 1000L + new Long(i);
			segVer[i] = new Long(i);
		}
		Integer[] muIds = { 1, 2, 3, 4, };
		int indexMu = 0;
		for (int i = 0; i < size; i++) {
			MuSegmentMap map = new MuSegmentMap();
			map.setContainerId(containerId);
			map.setFunctionId(functionId);
			if (i < size - 1) {
				map.setSegmentId(segIds[i]);
				map.setSegmentVersion(segVer[i]);
			} else {
				map.setSegmentId(Long.valueOf(i * 100));
				map.setSegmentVersion(Long.valueOf(i + 2));
			}
			map.setMuId(muIds[indexMu]);
			map.setStatus(0);
			maps.add(map);
			indexMu++;
			if (indexMu > 3) {
				indexMu = 0;
			}
		}
		return maps;
	}

	private void overrideByMock(final boolean overrideVal) {
		new MockUp<IdentifyPlanCreatedNotifer>() {
			@Mock
			public boolean sendTxtMessage(String plans) {
				return overrideVal;
			}

			@Mock
			public boolean sendCompressedByte(byte[] compressedJms) {
				return overrideVal;
			}
		};
		final Map<String, Double> factor = getAllValues();

		new MockUp<AdjustMuAblistyFactorPropertyUtil>() {
			@Mock
			public Map<String, Double> getAllValues() {
				return factor;
			}
		};

	}

	private void saveJobLimit() {
		List<Map<String, Object>> recs = jdbcTemplate
				.queryForList("select family_id, job_limit_count from inquiry_traffic");
		for (Map<String, Object> rec : recs) {
			Integer familyId = ((BigDecimal) rec.get("family_id")).intValue();
			Integer jobLimit = ((BigDecimal) rec.get("job_limit_count"))
					.intValue();
			jobLimitMap.put(familyId, jobLimit);
		}
	}

	private void restoreJobLimit() {
		for (Integer familyId : jobLimitMap.keySet()) {
			jdbcTemplate.update(
					"update inquiry_traffic set job_limit_count = ? "
							+ "where family_id = ?", jobLimitMap.get(familyId),
					familyId);
		}
		jdbcTemplate.execute("commit");
	}

	private void clearDB() {
		jdbcTemplate.execute("delete from job_queue");
		jdbcTemplate.execute("delete from segments");
		jdbcTemplate.execute("delete from resource_update_count");
		jdbcTemplate.execute("delete from map_reducers");
		jdbcTemplate.execute("delete from mu_eligible_containers");
		jdbcTemplate.execute("delete from mu_eligible_functions");
		jdbcTemplate.execute("delete from mu_seg_reports");
		jdbcTemplate.execute("delete from mu_job_execute_plans");
		jdbcTemplate.execute("delete from mu_inquiry_load");
		jdbcTemplate.execute("delete from match_units");
		jdbcTemplate.execute("delete segment_defragmentation");
		jdbcTemplate.execute("update inquiry_traffic set job_exec_count=0");
		jdbcTemplate.execute("update inquiry_traffic set job_complete_count=0");
		jdbcTemplate.execute("commit");
	}

}
