package jp.co.nec.aim.mm.acceptor.service;

import static jp.co.nec.aim.mm.constants.MMConfigProperty.INTERVAL_CLIENT_SYNC_RESPONSE_TIMEOUT;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Lists;

import jp.co.nec.aim.message.proto.AIMMessages.PBMuExtractJobResultItem;
import jp.co.nec.aim.message.proto.SyncService.SyncRequest;
import jp.co.nec.aim.message.proto.SyncService.SyncResponse;
import jp.co.nec.aim.mm.acceptor.AimSyncRequest;
import jp.co.nec.aim.mm.acceptor.Record;
import jp.co.nec.aim.mm.acceptor.Registration;
import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.constants.UidRequestType;
import jp.co.nec.aim.mm.dao.CommitDao;
import jp.co.nec.aim.mm.dao.FEJobDao;
import jp.co.nec.aim.mm.dao.FunctionDao;
import jp.co.nec.aim.mm.dao.SystemConfigDao;
import jp.co.nec.aim.mm.entities.FeJobQueueEntity;
import jp.co.nec.aim.mm.entities.FunctionTypeEntity;
import jp.co.nec.aim.mm.exception.DataBaseException;
import jp.co.nec.aim.mm.exception.TemplateException;
import jp.co.nec.aim.mm.exception.UidTimeoutException;
import jp.co.nec.aim.mm.exception.XmlException;
import jp.co.nec.aim.mm.jms.JmsSender;
import jp.co.nec.aim.mm.jms.NotifierEnum;
import jp.co.nec.aim.mm.procedure.FeJobProcedures;
import jp.co.nec.aim.mm.segment.sync.SegSyncInfos;
import jp.co.nec.aim.mm.sessionbeans.pojo.AimManager;
import jp.co.nec.aim.mm.util.XmlUtil;
import jp.co.nec.aim.mm.validator.AcceptorValidator;


/**
 * The main work flow of Sync <br>
 * Include following public method:
 * <p>
 * syncData
 * <p>
 * 
 * @author xiazp
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class AimSyncService {
    /** log instance **/
    private static Logger log = LoggerFactory.getLogger(AimSyncService.class);
    private static Logger probufDumpLog = LoggerFactory.getLogger("probufdump");
    
    @PersistenceContext(unitName = "aim-db")
    private EntityManager manager;
    
    @Resource(mappedName = "java:jboss/MySqlDS")
    private DataSource dataSource;
    
    private Registration reg;
    
    private AcceptorValidator validator;
    
    private FEJobDao feJobDao;
    
    private SystemConfigDao sysConfigDao;
    
    private FunctionDao functionDao;
    
    private FeJobProcedures feJobProcedures;    
   
    private CommitDao commitDao;
    
    
    
    @EJB
    private AimExtractService aimExService;
    
    /**
     * default constructor
     */
    public AimSyncService() {
    }
    
    @PostConstruct
    private void init() {
        this.reg = new Registration(dataSource, manager);
        this.validator = new AcceptorValidator(manager, dataSource);
        this.feJobDao = new FEJobDao(manager);
        this.functionDao = new FunctionDao(manager);
        this.sysConfigDao = new SystemConfigDao(manager);
        feJobProcedures = new FeJobProcedures(dataSource);      
        this.commitDao = new CommitDao(dataSource);
    }
    
    /**
     * The main work flow of syncData
     * 
     * @param request
     *            PBSyncJobRequest instance
     * @return the instance of PBSyncJobResponse
     */
    public String syncData(String syncRequest) {
        return syncData(syncRequest, null);
    }
    
    /**
     * The main work flow of syncData
     * 
     * @param syncRequest
     *            PBSyncJobRequest instance
     * @param delCount
     *            delete count
     * @return PBSyncJobResponse instance
     * @throws Exception 
     */
	public String syncData(final String syncRequest, final AtomicInteger delCount) {
		if (StringUtils.isBlank(syncRequest)) {
			throw new XmlException("insert request is empty");
		}		
		if (probufDumpLog.isDebugEnabled()) {
			probufDumpLog.debug(syncRequest);
		}	
		String cmd = XmlUtil.getXmlCmd(syncRequest);
		if (StringUtils.isBlank(cmd)) {
			throw new XmlException("Element is empty in sync request.");
		}
		if (!(cmd.equals("Delete") || cmd.equals("Insert"))) {
			throw new XmlException("Sync command is miss, it's must be 'Insert' or 'Delete'!");
		}

		// try {
		// JaxBUtil<Request> jaxbUtil = new JaxBUtil<Request>();
		// Request extRequest = jaxbUtil.unmarshal(Request.class, syncRequest);
		// } catch (JAXBException e) {
		// throw new XmlException(e.getMessage(), e.getCause());
		// }

		String refId = XmlUtil.getRefId(syncRequest, UidRequestType.Quality.name());
		String response = null;
		if (StringUtils.isBlank(refId)) {
			throw new XmlException("Reference id id empty in syncRequest!");
		}
		if (cmd.equals("Delete")) {
			response =  doSyncDelete(syncRequest, refId, delCount);
		} else if (cmd.equals("Insert")) {
			String refUrl = XmlUtil.getUrl(syncRequest, UidRequestType.Insert.name());
			if (!StringUtils.isBlank(refUrl)) {
				response = doSyncByRefUrl(syncRequest, refId, refUrl);
			} else {
				response = doSyncByRefId(syncRequest, refId);
			}
		}
		return response;
	}
            
            
  
   private String doSyncByRefId(final String syncRequest, String refId) {	   
       log.info("syncData insert by refernceId begin..");
       FeJobQueueEntity feEntity = null;
       try {                
           List<FeJobQueueEntity> resultList = feJobDao.getExResult(refId);
           if (resultList.isEmpty()) {
               AimError temErr = AimError.SYNC_INSERT_BY_REFID_NO_REF_DATA;
               throw new TemplateException(
                   temErr.getErrorCode(), temErr.getMessage(), String.valueOf(System.currentTimeMillis()), temErr.getUidCode());
           }
           feEntity = resultList.get(0);
       } catch (Exception e) {
           throw e;
       }
       
      final List<AimSyncRequest> aimRequestList = new ArrayList<>();
       Record record = new Record(feEntity.getResult(), feEntity.getDiagnostcs());
       AimSyncRequest aimReq = new AimSyncRequest(Integer.valueOf(1));
      aimRequestList.add(aimReq);           
       try {                
       	Map<Long, List<SegSyncInfos>> segSyncMap = reg.insert(refId, aimRequestList);              
           log.info("success insert into PERSON_BIOMETRICS table reqeustId={}, eenrollmentId={}",refId, refId); 
           SegSyncInfos segSyncInfo = segSyncMap.values().stream().collect(Collectors.toList()).get(0).get(0);
           if (segSyncInfo.isUpdateSegment()) {
           	// do call dm service insert update sync segment
           	// if dm service return true
           	  //commitDao.commit();
           	//id dm service return false
           	  //commitDao.rollback();                	
           } else {
           	// do call db service new sync segment
           	// if dm service return true
         	    //commitDao.commit();
         	   //id dm service return false
         	    // commitDao.rollback();
           }
           reg.pushOrCallSlb(segSyncMap);
           
       } catch (Exception  e1) {                
           Throwable cause = e1.getCause();
           Throwable lastCause = null;
           String errMsg = null;
           while (cause != null) {
               cause = cause.getCause();
               if (cause != null) {
                   lastCause = cause;
               }
           }
           if (lastCause != null) {
               errMsg = lastCause.getMessage(); 
           }                 
           AimError dbErr = AimError.SYNC_DB;
           errMsg = StringUtils.isNoneEmpty(errMsg) ? errMsg : String.format(dbErr.getMessage(), e1.getMessage());
           dbErr.setMessage(errMsg);
           throw new DataBaseException(dbErr.getErrorCode(), dbErr.getMessage(), String.valueOf(System.currentTimeMillis()), dbErr.getUidCode());              
       }
       //Create Sync respose; 
       //ProtobufDumpLogger.trace("SyncResponse", insByRefIdRes.getBatchJobId(), insByRefIdRes.getType().toString(), newPbMes.build());
      // return insByRefIdRes.build();
	return null;
       		
   }
   
   private String doSyncByRefUrl(final String syncRequest, String refId, String url) {	   
  		//sync by url      
       log.info("syncData insert by url begin..");
       // final FeJobQueueEntity feJob = new FeJobQueueEntity(); 
       String requestId = XmlUtil.geRequestId(syncRequest);
       FunctionTypeEntity fte = functionDao.getExtractFunction();
       if (fte == null) {
           AimError dbErr = AimError.SYNC_FUNCTIONTYPE;
           throw new DataBaseException(dbErr.getErrorCode(), dbErr.getMessage(), String.valueOf(System.currentTimeMillis()), dbErr.getUidCode());
       }
       Long newFeJobId = null; 
       try {
           newFeJobId = feJobProcedures.createNewFeJob(refId, requestId, syncRequest.getBytes()); //mustCommit  
       } catch (Exception e1) {               
           feJobDao.deleteExtractJob(newFeJobId);                            
           Throwable cause = e1.getCause();
           Throwable lastCause = null;
           String errMsg = null;
           while (cause != null) {
               cause = cause.getCause();
               if (cause != null) {
                   lastCause = cause;
               }
           }
           if (lastCause != null) {
               errMsg = lastCause.getMessage();
           }               
           AimError dbErr = AimError.SYNC_DB;
           errMsg = StringUtils.isNoneEmpty(errMsg) ? errMsg : String.format(dbErr.getMessage(), e1.getMessage());
           dbErr.setMessage(errMsg);
           throw new DataBaseException(dbErr.getErrorCode(), dbErr.getMessage(), String.valueOf(System.currentTimeMillis()), dbErr.getUidCode());              
       }      
       
       JmsSender.getInstance().sendToFEJobPlanner(NotifierEnum.ExtractService,
           String.format("create extract job id: %s", newFeJobId));
       Integer syncJobWaitTime = sysConfigDao.getMMPropertyInt(INTERVAL_CLIENT_SYNC_RESPONSE_TIMEOUT);
       if (Objects.isNull(syncJobWaitTime) || syncJobWaitTime < 0) {
           syncJobWaitTime = 100000;
       }            
       String key = String.valueOf(newFeJobId.longValue());
       Object extractJoblocker = new Object();
       AimManager.saveToExtractLockQueue(key, extractJoblocker);
       Optional<PBMuExtractJobResultItem> onejobResult = null;
       synchronized (extractJoblocker) {
           long startGetExtResultTime = System.currentTimeMillis();
           try {
               extractJoblocker.wait(syncJobWaitTime);
           } catch (InterruptedException e) {
               log.error(e.getMessage(), e);
               Thread.currentThread().interrupt();
           }
           try {
               onejobResult = Optional.ofNullable(AimManager.getExtractJobResult(key));
           } catch (NullPointerException e) {
               log.warn("can't get extractResponse, it may be timeout.");
               AimError timeoutErr = AimError.JOB_TIMEOUT;
               String errMsg = String.format(timeoutErr.getMessage(), "sync insert by url job timeout.");
               timeoutErr.setMessage(errMsg);
               throw new UidTimeoutException(timeoutErr.getErrorCode(), timeoutErr.getMessage(), String.valueOf(System.currentTimeMillis()), timeoutErr.getUidCode());     
           }
           if (onejobResult.isPresent()) {
               log.info("Get insert by url jobId({}) result success", newFeJobId);
               long endGetResultTime = System.currentTimeMillis();
               log.info("*****MM get insert by url job results used time = {}****",
                   endGetResultTime - startGetExtResultTime);
           } else {
               log.warn("Got empty PBMuExtractJobResultItem, key={}", key); 
               long currentTime = System.currentTimeMillis();
               if (currentTime - startGetExtResultTime >= syncJobWaitTime) {
                   log.warn(
                       "Timeout is happend! the waiting time = ({}), jobId({})",
                       currentTime - startGetExtResultTime, newFeJobId.longValue());
                   AimError timeoutErr = AimError.JOB_TIMEOUT;
                   String errMsg = String.format(timeoutErr.getMessage(), "sync insert by url job timeout.");
                   timeoutErr.setMessage(errMsg);
                   throw new UidTimeoutException(timeoutErr.getErrorCode(), timeoutErr.getMessage(), String.valueOf(System.currentTimeMillis()), timeoutErr.getUidCode());                       
               }
           }
       }
       AimManager.finishExtractJob(key);
     
       final List<AimSyncRequest> aimRequestByExtList = new ArrayList<>();
       Record recordByExt = new Record(onejobResult.get().getBisonTemplate().toByteArray());
       
       AimSyncRequest aimReqExt = new AimSyncRequest(Integer.valueOf(1), recordByExt);
       aimRequestByExtList.add(aimReqExt);
       reg.insert(onejobResult.get().getJobState().getReferenceId(), aimRequestByExtList);     
       //ProtobufDumpLogger.trace("SyncResponse", insByUrlRes.getBatchJobId(), insByUrlRes.getType().toString(), pbExtMes);
       //Todo create xml respose
       return null;
   }
   
   
   private String doSyncDelete(String deleteReq, String externalId,  final AtomicInteger delCount) {  
       if (log.isDebugEnabled()) {
           log.debug("syncData delete begin..");
       }
       int count = reg.delete(externalId, Lists.newArrayList(new Integer[] {1}));            
       if (delCount != null) {
           delCount.set(count);
       }
       //ToDo create deleteResponse
       //ProtobufDumpLogger.trace("SyncResponse", delRes.getBatchJobId(), delRes.getType().toString(), dlePbMes.build());
	return null;
       
	   
   }    
   
    private SyncResponse makeFailedSyncRes(final SyncRequest request) {
        SyncResponse.Builder faildSyncRes = SyncResponse.newBuilder();
        faildSyncRes.setBatchJobId(request.getBatchJobId());
        faildSyncRes.setType(request.getType());
       // faildSyncRes.addBusinessMessage(pbm.toByteString());
        //ProtobufDumpLogger.trace("SyncResponse", request.getBatchJobId(), request.getType().toString(), pbm);
        return faildSyncRes.build();
    }
}
