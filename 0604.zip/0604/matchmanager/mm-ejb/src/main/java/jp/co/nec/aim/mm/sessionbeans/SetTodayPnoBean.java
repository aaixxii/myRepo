package jp.co.nec.aim.mm.sessionbeans;

import java.time.LocalDate;

import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.sql.DataSource;

import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.aim.mm.dao.PartitionDao;
import jp.co.nec.aim.mm.partition.PartitionUtil;

@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class SetTodayPnoBean  {
	private static final Logger logger = LoggerFactory.getLogger(SetTodayPnoBean.class);
	
	@Resource(mappedName = "java:jboss/MySqlDS")
	private DataSource dataSource;
	private PartitionDao partitionDao;
	
	public SetTodayPnoBean() {		
	}

	public SetTodayPnoBean(DataSource dataSource) {
		partitionDao = new PartitionDao(dataSource);
	}
	
	public void execute() throws JobExecutionException {
		long value = PartitionUtil.getInstance().caculateHashAtThisToday(LocalDate.now());
		partitionDao.setTodayPno(value);
		logger.info("Success set p_no({}) in {}", value, LocalDate.now());
	}
}
