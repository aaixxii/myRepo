package jp.co.nec.aim.mm.acceptor.service;

import java.util.Arrays;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Lists;

import jp.co.nec.aim.mm.acceptor.AimInquiryRequest;
import jp.co.nec.aim.mm.acceptor.CommonOptions;
import jp.co.nec.aim.mm.acceptor.Inquiry;
import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.constants.UidRequestType;
import jp.co.nec.aim.mm.dao.DateDao;
import jp.co.nec.aim.mm.dao.InquiryJobDao;
import jp.co.nec.aim.mm.exception.ExceptionHelper;
import jp.co.nec.aim.mm.exception.XmlException;
import jp.co.nec.aim.mm.util.XmlUtil;
import jp.co.nec.aim.mm.validator.AcceptorValidator;

/**
 * The main work flow of inquiry <br>
 * 
 * Include following public method:
 * <p>
 * inquiry, getJobStatus, listJobIds, deleteJob clearJobs, getJobResult,
 * getJobResult
 * <p>
 * 
 * @author xiazp
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class AimInquiryService {
	/** log instance **/
	private static Logger log = LoggerFactory.getLogger(AimInquiryService.class);			
	private static Logger probufDumpLog = LoggerFactory.getLogger("probufdump");

	@PersistenceContext(unitName = "aim-db")
	private EntityManager manager;

	@Resource(mappedName = "java:jboss/MySqlDS")
	private DataSource dataSource;
	@EJB
	private Inquiry inquiry;	
	private AcceptorValidator validator;
	private InquiryJobDao inquiryJobDao;	
	private DateDao dateDao;
	private ExceptionHelper exception;

	/**
	 * AimInquiryService default constructor
	 */
	public AimInquiryService() {
	}

	@PostConstruct
	private void init() {
		this.inquiryJobDao = new InquiryJobDao(manager, dataSource);		
		this.validator = new AcceptorValidator(manager, dataSource);		
		this.dateDao = new DateDao(dataSource);
		this.exception = new ExceptionHelper(dateDao);
	}

	/**
	 * The main work flow of inquiry
	 * 
	 * @param request
	 *            PBInquiryJobRequest instance
	 * @param isFromServlet
	 *            IS called by SERVLET
	 * @return PBInquiryJobResponse instance
	 */
	public String inquiry(final String inqRequest, boolean isFromServlet) {			
		if (probufDumpLog.isDebugEnabled()) {
			probufDumpLog.debug(inqRequest);
		}
		if (StringUtils.isBlank(inqRequest)) {
			throw new XmlException("inquiry request is empty");
		}
		String cmd = XmlUtil.getXmlCmd(inqRequest);
		if (StringUtils.isBlank(cmd)) {
			throw new XmlException("Element is empty in sync request.");
		}
		if (!cmd.equals("Identify")) {
			throw new XmlException("Inquiry command is miss, it's must be 'Identif'!");
		}

		// try {
		// JaxBUtil<Request> jaxbUtil = new JaxBUtil<Request>();
		// Request extRequest = jaxbUtil.unmarshal(Request.class, syncRequest);
		// } catch (JAXBException e) {
		// throw new XmlException(e.getMessage(), e.getCause());
		// }

		String refId = XmlUtil.getRefId(inqRequest, UidRequestType.Identify.name());
		String refUrl = XmlUtil.getUrl(inqRequest, UidRequestType.Identify.name());
		String maxResults = XmlUtil.getIdentifyAtribute(inqRequest, "maxResults");
		String targetFPIR = XmlUtil.getIdentifyAtribute(inqRequest, "targetFPIR");
		String targetModalityFPIR = XmlUtil.getIdentifyAtribute(inqRequest, "targetModalityFPIR");
		String dedupModalityInstance = XmlUtil.getIdentifyAtribute(inqRequest, "dedupModalityInstance");
		String missingBiometric = XmlUtil.getIdentifyAtribute(inqRequest, "missingBiometric");
		String fullsearch = XmlUtil.getIdentifyAtribute(inqRequest, "fullsearch");
		
		if (!StringUtils.isBlank(refId)) {
			//get template data from dm_service
			//AimInquiryRequest aimInquiryRequest = new AimInquiryRequest("MI",Arrays.asList(1), inqRequest, templateData);
		}		 
			
		final CommonOptions options = new CommonOptions();
		options.setFromServlet(isFromServlet);
		options.setFunctioName("MI");
		options.setMaxCandidates(Integer.valueOf(maxResults));
		final List<AimInquiryRequest> aimRequestList = Lists.newArrayList();
		AimInquiryRequest aimInquiryRequest = new AimInquiryRequest("MI",Arrays.asList(1), inqRequest, null);
		aimRequestList.add(aimInquiryRequest);	
		long jobId = inquiry.inquiry(aimRequestList, options);	
		return String.valueOf(jobId);
	}


	/**
	 * delete the inquiry Job with specified job id
	 * 
	 * @param request
	 *            PBDeleteJobRequest instance
	 */
	public void deleteJob(String request) {
		String  refId = null;
//		if (request.hasReferenceId()) { //Todo
//			refId = request.getReferenceId();
//		}			
		if (StringUtils.isBlank(refId)) {
			log.warn("Got empty refernceId, skip");
			return;
		}

	}

	/**
	 * clear all inquiry Jobs
	 */
	public void clearJobs() {
		try {
			inquiryJobDao.clearJobs();
		} catch (Exception ex) {
			exception.throwDBException(AimError.INQ_DB, ex,
					"Exception occurred when clear inquiry job.");
		}
	}
}
