package jp.co.nec.aim.mm.identify.planner;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.Resource;
import javax.ejb.ConcurrencyManagement;
import javax.ejb.ConcurrencyManagementType;
import javax.ejb.EJB;
import javax.ejb.Lock;
import javax.ejb.LockType;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.sql.DataSource;
import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.NotSupportedException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;
import javax.transaction.UserTransaction;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.CannotAcquireLockException;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;

import jp.co.nec.aim.mm.dao.DateDao;
import jp.co.nec.aim.mm.dao.IdentifyPlannerDao;
import jp.co.nec.aim.mm.dao.IdentifyPlannerDaoImpl;
import jp.co.nec.aim.mm.logger.PerformanceLogger;
import jp.co.nec.aim.mm.notifier.IdentifyPlanCreatedNotifer;
import jp.co.nec.aim.mm.util.StopWatch;

/**
 * 
 * @author xiazp
 * 
 */
@Singleton
@Startup
@TransactionManagement(TransactionManagementType.BEAN)
@ConcurrencyManagement(ConcurrencyManagementType.BEAN)
public class IdentifyPlanManager {
	private ResoureceUpdateCount RUC = new ResoureceUpdateCount();
	private ConcurrentHashMap<MuSegmentMapKey, List<MuSegmentMap>> memMuSegmentMaps = new ConcurrentHashMap<MuSegmentMapKey, List<MuSegmentMap>>();
	private static Logger logger = LoggerFactory.getLogger(IdentifyPlanManager.class);
	private static String INQUIRY_DISTRIBUTOR_QUEUE = "IdentifyDispatchQueue";
	private IdentifyPlannerDao identifyDao;
	@Resource
	private UserTransaction userTransaction;
	@EJB
	IdentifyPlanCreatedNotifer notifer;
	@Resource(mappedName = "java:jboss/MySqlDS")
	private DataSource dataSource;
	@PersistenceContext(unitName = "aim-db")
	private EntityManager entityManager;
	private DateDao dateDao;

	public IdentifyPlanManager() {
	}

	@PostConstruct
	public void IndentiyPlannerStartup() {
		initialize();

	}

	@PreDestroy
	public void IndentiyPlannerShutdown() {
		identifyDao = null;
		dateDao = null;
	}
	
	@Lock(LockType.WRITE)
	private void initialize() {
		dateDao = new DateDao(dataSource);
		identifyDao = new IdentifyPlannerDaoImpl(dataSource, entityManager);
		RUC.setUpdateCount(0);
		try {
			identifyDao.setRUC(0L);
		} catch (PersistenceException | SQLException e) {
			logger.error(e.getMessage(), e);
			try {
				throw e;
			} catch (Exception e1) {
				logger.error(e1.getMessage(), e);
			}
		}
	}

	/**
	 * making mu executing plans for all queued jobs which job counts is under
	 * limited jobs
	 * 
	 * @return
	 */
	@Lock(LockType.WRITE)
	public void doMakePlanProcess() {
		logger.debug("IdentiyPlanner prepare to making mu executing plans...");
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		List<JobInfoFromDB> jobInfoList = new ArrayList<JobInfoFromDB>();
		boolean planSuccessed = false;
		try {
			Integer numOfMR = identifyDao.getWorkingMR();
			if (numOfMR < 1) {
				logger.warn("No MR is in working! skip creating plan.");
				return;
			}
			List<Long> limitedJobList = identifyDao.getLimitedJobsByFamiliy();
			if (limitedJobList == null || limitedJobList.size() < 0) {
				logger.debug("No job for create identify plans,Skip creating plan.");
				return;
			}
			Long[] jobIds = limitedJobList.stream().toArray(Long[]::new);
//			Long[] jobIds = new Long[limitedJobList.size()];
//			limitedJobList.toArray(jobIds);
			jobInfoList = identifyDao.getJobInfoForCreatePlans(jobIds);
			if (jobInfoList == null || jobInfoList.size() < 0) {
				logger.debug("Got empty job info from DB! IndentiyPlanner will be return.");
				return;
			}
			if (logger.isDebugEnabled()) {
				StringBuilder sb = new StringBuilder();
				for (JobInfoFromDB oneTopJob : jobInfoList) {
					sb.append("[");
					sb.append(String.valueOf(oneTopJob.getTopJobId()));
					sb.append("(");
					sb.append(oneTopJob.getContainerJobId());
					sb.append(",");
					sb.append(oneTopJob.getContainerId());
					sb.append(",");
					sb.append(oneTopJob.getFunctionId());
					sb.append(")");
				
					sb.append("]");
				}
				logger.debug("Got JobInfoList: " + sb.toString());
			}

		} catch (PersistenceException | DataAccessException | SQLException e) {
			logger.error(e.getMessage(), e);
			logger.error("IndentiyPlanner returned due to " + e.getClass().getName());
			return;
		}		
		List<MuJobExecutePlan> batchJobPlans = new ArrayList<MuJobExecutePlan>();
		try {
			userTransaction.begin();
			for (JobInfoFromDB oneJob : jobInfoList) {
				identifyDao.lockJobQueueRowForProcess(oneJob.getTopJobId());
				MuJobExecutePlan oneTopJobPlans = processOneJob(oneJob);
				if (oneTopJobPlans == null) {
					logger.warn(
							"Create jobb(JobId={}) planning process has failed. continue do next..",
							oneJob.getTopJobId());
					// userTransaction.rollback();
					continue;
				} else {
					boolean updateInquiryTrafficSuccessed = identifyDao
							.updateInquiryTraffic(oneJob.getTopJobId().longValue());
					if (updateInquiryTrafficSuccessed) {							
						batchJobPlans.add(oneTopJobPlans);
						//List<String> tmp = oneTopJobPlans.stream().map(one -> one.getJobId() + ":" + one.getPlanId().toString()).collect(Collectors.toList());
					}
				}
			}	
		
			byte[] byteJms = CompressUtil.zipCompressPlanList(batchJobPlans);
			boolean notifySuccssed = false;
			notifySuccssed = notifer.sendCompressedByte(byteJms);
			if (notifySuccssed) {
				String jobStr = jobInfoList.stream().map(one -> one.getTopJobId().toString()).collect(Collectors.joining(","));
				logger.info("IndendifyPlanner success create jobs({}) plans and success sent it to {} by JMS",jobStr, INQUIRY_DISTRIBUTOR_QUEUE);						
				userTransaction.commit();
				planSuccessed = true;
			} else {
				logger.warn("IndendifyPlanner faild to sent MR plans to {} by JMS", INQUIRY_DISTRIBUTOR_QUEUE);
				userTransaction.rollback();
			}			

		} catch (NotSupportedException | SystemException | NumberFormatException | SecurityException
				| IllegalStateException | RollbackException | HeuristicMixedException | HeuristicRollbackException
				| PersistenceException | SQLException | EmptyResultDataAccessException | CannotAcquireLockException e) {
			logger.error("Transaction rollbacked due to other exception({})!", e.getClass().getName());
			try {
				userTransaction.rollback();
			} catch (IllegalStateException | SecurityException | SystemException e1) {
				logger.error(e1.getMessage(), e1);
			}
		}

		stopWatch.stop();
		if (planSuccessed) {
			PerformanceLogger.log(getClass().getSimpleName(), "doMakePlanProcess", stopWatch.elapsedTime());
		}
		return;
	}

	/**
	 * 
	 * @param jobInfo
	 * @return
	 */
	private MuJobExecutePlan processOneJob(JobInfoFromDB jobInfo) {
		logger.debug("IndentiyPlanner processOneJob process is running...");
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		MuSegmentMapKey muSegKey = new MuSegmentMapKey(jobInfo.getFunctionId(), jobInfo.getContainerId());
	//	List<MuSegmentMapKey> muSegKeys = makeUniqeKey(jobInfo.getCombinedJobInfoList());
		Long dbRUC;
		try {
			dbRUC = identifyDao.getRUCFromDB();
			if (logger.isDebugEnabled()) {
				logger.debug("RUC in db = {}", dbRUC);
				logger.debug("RUC in memory = {}", this.getRUC().getUpdateCount());
			}
		} catch (PersistenceException | SQLException e2) {
			logger.error(e2.getMessage(), e2);
			return null;
		}
		if (memMuSegmentMaps == null) {
			memMuSegmentMaps = new ConcurrentHashMap<MuSegmentMapKey, List<MuSegmentMap>>();
		}
		if (dbRUC.longValue() != getRUC().getUpdateCount() || memMuSegmentMaps.size() == 0) {
			// Update MuSegmentMaps which MM already has
			
			if (!doUpdateMuSegMapsFromDB(muSegKey, jobInfo.getTopJobId())) {
				return null;
			}
			// Get MuSegmentMaps from DB if MM doesn't have.
			
			if (!memMuSegmentMaps.containsKey(muSegKey)) {
				if (!doUpdateMuSegMapsFromDB(muSegKey, jobInfo.getTopJobId())) {
					return null;
				}
			}			

			getRUC().setUpdateCount(dbRUC.longValue());
		} else {
			if (!memMuSegmentMaps.containsKey(muSegKey)) {					
				if (!doUpdateMuSegMapsFromDB(muSegKey, jobInfo.getTopJobId())) {
					return null;
				}
			} else {
				if (!doUpdateMuSegMapsFromMem(muSegKey, jobInfo.getTopJobId())) {
					return null;
				}
			}
		}
		
		//List<MuJobExecutePlan> muJobExecuteplans = new ArrayList<MuJobExecutePlan>();

		
		List<MuSegmentMap> newMap = memMuSegmentMaps.get(muSegKey);
		List<MuCpuAndPressure> muCpuAndPressureList = null;
		try {
			muCpuAndPressureList = identifyDao.getMuCpuAndPressure(fetchMuIdsFromMuSegMap(newMap));
			if (muCpuAndPressureList == null) {
				logger.warn("Number of working MU is decrease during planning MuJob assignment."
						+ " Skip distributing MuJob of TopLevelJobId {}", jobInfo.getTopJobId());
				return null;
			}
		} catch (PersistenceException | SQLException e1) {
			logger.error(e1.getMessage(), e1);
			return null;
		}
		MuExcutionPlanCreator creator = new MuExcutionPlanCreator(newMap, muCpuAndPressureList, dateDao);
		String planStringPerContainer = creator.createMuPlans();
		if (planStringPerContainer == null || planStringPerContainer.isEmpty()) {
			logger.warn("IdentifyPlanner created empty identify job plan! for funcitonId={},containerID = {}",
					muSegKey.getFunctionId(),muSegKey.getContainerId());
			return null;
		}
		creator = null;
		logger.debug("IdentifyPlanner created plan:{} for jobId:{} funtionId:{} containerId:{}",
				planStringPerContainer.toString(), jobInfo.getTopJobId(), muSegKey.getFunctionId(),
				muSegKey.getContainerId());
		Long planId = null;
		try {
			planId = identifyDao.updateAfterPlanned(jobInfo.getTopJobId(), jobInfo.getContainerId(),
					jobInfo.getContainerJobId(), jobInfo.getFunctionId(), planStringPerContainer);
		} catch (PersistenceException e) {
			logger.error(e.getMessage(), e);
			return null;
		}
		if (planId == null || planId.longValue() < 0l) {
			logger.warn("PlanId is incorrect! is null or less than 0!");
			return null;
		}
		logger.info("IndendifyPlanner has succeeded to create planId:{} for jobId:{} funtionId:{} containerId:{}",
				planId, jobInfo.getTopJobId(), jobInfo.getFunctionId(), jobInfo.getContainerId());
		MuJobExecutePlan muPlan = new MuJobExecutePlan();
		muPlan.setContainerId(jobInfo.getContainerId());
		muPlan.setJobId(jobInfo.getTopJobId());
		muPlan.setFunctionId(jobInfo.getFunctionId());
		muPlan.setPlanId(planId);
		muPlan.setPlan(planStringPerContainer);
		//muJobExecuteplans.add(muPlan);
		stopWatch.stop();
    	PerformanceLogger.log(getClass().getSimpleName(), "processOneJob", stopWatch.elapsedTime());
		logger.debug("processOneJob(JobId:{}) success finished.", jobInfo.getTopJobId());		
		return muPlan;
	}

	private boolean doUpdateMuSegMapsFromDB(MuSegmentMapKey muSegKey, Long jobId) {
		logger.info("Start updating memory MU_SEGMENT_MAP (functionId:{},ContainerId:{}) from DB.",
				muSegKey.getFunctionId(), muSegKey.getContainerId());
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		List<MuSegmentMap> tmpMap = null;
		try {
			tmpMap = identifyDao.getNewMuSegMaps(muSegKey.getContainerId(), muSegKey.getFunctionId());
		} catch (PersistenceException e) {
			logger.error(e.getMessage(), e);
			return false;
		}
		if (tmpMap == null) {
			logger.warn("Got empty muSegmentMap! can't create excuting plan for (functionId = {},containerid = {})",
					muSegKey.getFunctionId(), muSegKey.getContainerId());
			return false;
		}
		if (memMuSegmentMaps.contains(muSegKey)) {
			memMuSegmentMaps.remove(muSegKey);
		}
		memMuSegmentMaps.put(muSegKey, tmpMap);
		logger.info("Success to update memory MU_SEGMENT_MAP from DB.");
		if (!segCountIsEqual(muSegKey, jobId)) {
			return false;
		}
		stopWatch.stop();
		String muSegKeyStr = String.format("doUpdateMuSegMapsFromDB-%d-%d", muSegKey.getFunctionId(),
				muSegKey.getContainerId());
		PerformanceLogger.log(getClass().getSimpleName(), muSegKeyStr, stopWatch.elapsedTime());
		return true;
	}

	private boolean doUpdateMuSegMapsFromMem(MuSegmentMapKey muSegKey, Long jobId) {
		if (!segCountIsEqual(muSegKey, jobId)) {
			return false;
		}
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		List<MuSegmentMap> tempMap = memMuSegmentMaps.get(muSegKey);
		List<SegmentIdAndVeison> newSegVersions = null;
		try {
			newSegVersions = identifyDao.getSegmentVersionByContainerId(muSegKey.getContainerId());
		} catch (PersistenceException | SQLException e) {
			logger.error(e.getMessage(), e);
			return false;
		}
		if (newSegVersions == null) {
			logger.warn(
					"There are some worg! Got empty data while fetch new semgemts version from containerId = {} functionId = {}",
					muSegKey.getContainerId(), muSegKey.getFunctionId());
			return false;
		}
		for (MuSegmentMap map : tempMap) {
			for (SegmentIdAndVeison sv : newSegVersions) {
				if (map.getSegmentId().longValue() == sv.getSegmentId().longValue()) {
					map.setSegmentVersion(sv.getVersion());
					break;
				}
			}
		}
		stopWatch.stop();
		String muSegKeyStr = String.format("doUpdateMuSegMapsFromMem-%d-%d", muSegKey.getFunctionId(),
				muSegKey.getContainerId());
		PerformanceLogger.log(getClass().getSimpleName(), muSegKeyStr, stopWatch.elapsedTime());
		return true;
	}

	private boolean segCountIsEqual(MuSegmentMapKey muSegKey, Long jobId) {
		int segmentCountDB;
		try {
			segmentCountDB = identifyDao.getSegmentCount(muSegKey.getContainerId());
		} catch (PersistenceException | SQLException e) {
			logger.error(e.getMessage(), e);
			return false;
		}
		int segmentCountMem = calculatingSegmentCount(muSegKey);
		if (segmentCountDB != segmentCountMem) {
			logger.warn(
					"The count of segments in db is not equal it's in memory! "
							+ "DB count={} Mem count={} jobId={} functionId={} containerId={}",
					segmentCountDB, segmentCountMem, jobId, muSegKey.getFunctionId(), muSegKey.getContainerId());
		}
		return segmentCountDB == segmentCountMem;
	}

	@Lock(LockType.WRITE)
	private ResoureceUpdateCount getRUC() {
		return RUC;
	}

	@Lock(LockType.WRITE)
	private void setRUC(ResoureceUpdateCount rUC) {
		RUC = rUC;
	}

	@SuppressWarnings("unused")
	private ConcurrentHashMap<MuSegmentMapKey, List<MuSegmentMap>> getMemMuSegmentMaps() {
		return memMuSegmentMaps;
	}

	@Lock(LockType.WRITE)
	protected void setMemMuSegmentMaps(ConcurrentHashMap<MuSegmentMapKey, List<MuSegmentMap>> memMuSegmentMaps) {
		this.memMuSegmentMaps = memMuSegmentMaps;
	}

	@Lock(LockType.WRITE)
	private Integer calculatingSegmentCount(MuSegmentMapKey muSegKey) {
		int count = 0;
		List<MuSegmentMap> tmpMaps = null;
		Set<MuSegmentMapKey> muSegmentMapKeys = memMuSegmentMaps.keySet();
		for (MuSegmentMapKey key : muSegmentMapKeys) {
			if (key.equals(muSegKey)) {
				tmpMaps = memMuSegmentMaps.get(key);
				break;
			}
		}
		Collections.sort(tmpMaps, new MuSegmentMapComparator());
		long currentSegId = tmpMaps.get(0).getSegmentId().longValue();
		count++;
		for (int i = 0; i < tmpMaps.size(); i++) {
			if (currentSegId != tmpMaps.get(i).getSegmentId().longValue()) {
				count++;
				currentSegId = tmpMaps.get(i).getSegmentId();
			}
		}
		if (logger.isDebugEnabled()) {
			logger.debug("Segment counts in memory = {}", count);
		}
		return count;
	}

	/**
	 * 
	 * @param muSegMaps
	 * @return
	 */
	@Lock(LockType.WRITE)
	private Set<Integer> fetchMuIdsFromMuSegMap(List<MuSegmentMap> muSegMaps) {
		Set<Integer> muIds = new HashSet<Integer>();
		for (MuSegmentMap map : muSegMaps) {
			muIds.add(map.getMuId());
		}
		if (logger.isDebugEnabled()) {
			StringBuilder sb = new StringBuilder();
			for (Integer one : muIds) {
				sb.append(String.valueOf(one));
				sb.append(" ");
			}
			logger.debug("fetched MuIds from memory map:", sb.toString());
		}
		return muIds;
	}
}
