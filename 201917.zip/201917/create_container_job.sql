CREATE DEFINER=`aimuser`@`%` PROCEDURE `create_container_job`(IN p_job_id int,
IN p_search_request_index int,
IN p_function_id int,
IN p_inquiry_job_data blob,
IN p_container_list varchar(1024),
OUT p_empty_job int,
OUT p_remain_job int,
OUT p_fusion_job_id int)
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
begin_lab:
  BEGIN
    DECLARE l_fusion_job_id int;
    DECLARE l_result varchar(20);
    DECLARE l_count int;
    DECLARE v_result int;
    DECLARE v_id int;
    DECLARE t_error integer DEFAULT 0;
    DECLARE not_found int DEFAULT 0;
    DECLARE cur CURSOR FOR
    SELECT
      c.CONTAINER_ID
    FROM CONTAINERS c
    WHERE c.CONTAINER_ID IN (SELECT
        id
      FROM container_id)
    AND EXISTS (SELECT
        seg.SEGMENT_ID
      FROM SEGMENTS seg
      WHERE eg.CONTAINER_ID = c.CONTAINER_ID);
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET not_found = 1;
    DROP TEMPORARY TABLE IF EXISTS list_tmp;
    DROP TEMPORARY TABLE IF EXISTS l_container_ids;
    CREATE TEMPORARY TABLE l_container_ids (
      id int
    ) ENGINE = MEMORY;
    CALL strToTable(p_container_ids, "container_ids", @err);
    SELECT
      @err INTO v_result;
    IF v_result != 0 THEN
      SET p_empty_job = -1;
      SET p_remain_job = -1;
      SET p_fusion_job_id = -1;
      LEAVE begin_lab;
    END IF;

    CALL check_container_formats(p_function_id, p_container_list, @result);
    SELECT
      @result INTO l_result;
    IF l_result != 'OK' THEN
      SET p_empty_job = -1;
      SET p_remain_job = -1;
      SET p_fusion_job_id = -1;
      LEAVE begin_lab;
    END IF;
    -- first insert: create single row in fusion_jobs table.
    CALL insert_fusion_job_row(p_job_id,
    p_search_request_index,
    p_function_id,
    p_inquiry_job_data, @insertJobId);
    SELECT
      @insertJobId INTO l_fusion_job_id;
    IF l_fusion_job_id < 0 THEN
      SET p_empty_job = -1;
      SET p_remain_job = -1;
      SET p_fusion_job_id = -1;
      LEAVE begin_lab;
    END IF;
    SET p_empty_job := 1; -- 1 means FUSION_JOBS of l_fusion_job_id has no CONTAINER_JOBS records.    
    OPEN cur;
  lable_loop:
    LOOP
      FETCH cur INTO v_id;
      IF not_found = 1 THEN
        LEAVE lable_loop;
      END IF;
      INSERT INTO CONTAINER_JOBS (FUSION_JOB_ID, CONTAINER_ID)
        VALUES (l_fusion_job_id, v_id);
    END LOOP;
    CLOSE cur;
    SET p_empty_job := 0; -- 0 means FUSION_JOBS of l_fusion_job_id has some CONTAINER_JOBS records.    
    SELECT
      COUNT(id)
    FROM l_container_ids INTO p_remain_job;
    IF t_error = 1 THEN
      ROLLBACK;
      SET p_empty_job = -1;
      SET p_remain_job = -1;
      SET p_fusion_job_id = -1;
    ELSE
      COMMIT;
    END IF;
  END