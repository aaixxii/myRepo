CREATE DEFINER=`aimuser`@`%` PROCEDURE `get_container_results`(IN p_job_id long)
    READS SQL DATA
BEGIN
  DECLARE t_error integer DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
  SELECT
    cj.CONTAINER_JOB_RESULT
  FROM CONTAINER_JOBS cj,
       FUSION_JOBS fj,
       JOB_QUEUE jq
  WHERE cj.FUSION_JOB_ID = fj.FUSION_JOB_ID
  AND fj.JOB_ID = jq.JOB_ID
  AND jq.JOB_ID = p_job_id
  AND cj.JOB_STATE = 2
  AND jq.JOB_STATE = 1
  ORDER BY cj.CONTAINER_JOB_ID;

  IF t_error = 1 THEN
    -- select emty from retrun
    SELECT
      NULL;
  END IF;
END