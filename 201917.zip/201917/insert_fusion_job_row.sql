CREATE DEFINER=`aimuser`@`%` PROCEDURE `insert_fusion_job_row`(
IN p_job_id int,
IN p_search_request_index int,
IN p_function_id int,
IN p_inquiry_job_data blob,
OUT inserted_job_id int(38))
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN
  DECLARE l_fusion_job_id int;
  DECLARE t_error integer DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
  INSERT INTO FUSION_JOBS (FUNCTION_ID,
  JOB_ID,
  INQUIRY_JOB_DATA,
  SEARCH_REQUEST_INDEX)
    VALUES (p_function_id, p_job_id, p_inquiry_job_data, p_search_request_index);
  SELECT LAST_INSERT_ID() INTO l_fusion_job_id;    
  IF t_error = 1 THEN
    ROLLBACK;
    SET inserted_job_id = -1;
  ELSE
    COMMIT;
    SET inserted_job_id = l_fusion_job_id;
  END IF;
END