CREATE DEFINER=`aimuser`@`%` PROCEDURE `update_contact_time`(
IN p_unit_id int,
IN p_unit_type int)
BEGIN
  DECLARE t_error integer DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
  IF p_unit_type = 3 THEN
    UPDATE MU_CONTACTS
    SET CONTACT_TS = get_epoch_time_num()
    WHERE MU_ID = p_unit_id;

  ELSEIF p_unit_type = 1 THEN
    UPDATE DM_CONTACTS
    SET CONTACT_TS = get_epoch_time_num()
    WHERE DM_ID = p_unit_id;

  ELSEIF p_unit_type = 2 THEN
    UPDATE DM_CONTACTS
    SET CONTACT_TS = get_epoch_time_num()
    WHERE DM_ID = p_unit_id;
  END IF;
  IF t_error = 1 THEN
    ROLLBACK;
  ELSE
    COMMIT;
  END IF;
END