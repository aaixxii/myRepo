CREATE DEFINER=`aimuser`@`%` PROCEDURE `update_inquiry_load`(
IN p_mu_id int,
IN p_inquiry_load int,
OUT o_err int)
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN
  DECLARE l_count int;
  DECLARE t_error integer DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
  SET o_err = 0;
  SELECT
    COUNT(PRESSURE) INTO l_count
  FROM MU_INQUIRY_LOAD
  WHERE MU_ID = p_mu_id;
  IF (l_count = 0) THEN
    INSERT INTO MU_INQUIRY_LOAD (MU_ID,
    PRESSURE,
    REPORT_TS)
      VALUES (p_mu_id, p_inquiry_load, get_epoch_time_num());
  ELSE
    UPDATE MU_INQUIRY_LOAD
    SET PRESSURE = p_inquiry_load,
        REPORT_TS = get_epoch_time_num()
    WHERE MU_ID = p_mu_id;
    SELECT
      ROW_COUNT() INTO l_count;
    IF l_count = 0 THEN
      SET o_err = 1;
    END IF;
  END IF;
  IF t_error = 1 THEN
    ROLLBACK;
    SET o_err = 1;
  ELSE
    COMMIT;
  END IF;
END