CREATE DEFINER=`aimuser`@`%` PROCEDURE `force_quit_job`(IN p_code varchar(20),
IN p_reason varchar(1024),
IN p_failure_time varchar(20),
IN p_container_job_id int,
IN p_segment_id long,
IN p_result mediumblob,
OUT o_job_id long)
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN
  DECLARE l_job_id long;
  DECLARE l_mr_id int;
  DECLARE v_errcode int(10);
  DECLARE l_container_job_id int;
  DECLARE t_error integer DEFAULT 0;
  DECLARE v_idx int DEFAULT 999;
  DECLARE v_tmp_str varchar(20);
  DECLARE v_id int;
  DECLARE cur CURSOR FOR
  SELECT  id FROM l_container_ids;  
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
  DROP TEMPORARY TABLE IF EXISTS l_container_job_ids;
  CREATE TEMPORARY TABLE l_container_job_ids (
    id int
  ) ENGINE = MEMORY;
  SELECT
    jq.JOB_ID,
    cj.MR_ID INTO l_job_id, l_mr_id
  FROM JOB_QUEUE jq,
       FUSION_JOBS fj,
       CONTAINER_JOBS cj
  WHERE jq.JOB_ID = fj.JOB_ID
  AND fj.FUSION_JOB_ID = cj.FUSION_JOB_ID
  AND cj.CONTAINER_JOB_ID = p_container_job_id
  AND 0 < jq.REMAIN_JOBS
  AND jq.JOB_STATE < 2
  FOR UPDATE;
  UPDATE CONTAINER_JOBS
  SET JOB_STATE = 2,
      CONTAINER_JOB_RESULT = P_RESULT,
      RESULT_TS = get_epoch_time_num()
  WHERE CONTAINER_JOB_ID = p_container_job_id
  AND JOB_STATE < 2;
  INSERT INTO l_container_job_ids (id)
    VALUES ((SELECT cj.CONTAINER_JOB_ID FROM JOB_QUEUE jq, FUSION_JOBS fj, CONTAINER_JOBS cj WHERE jq.JOB_ID = l_job_id AND jq.JOB_ID = fj.JOB_ID AND fj.FUSION_JOB_ID = cj.FUSION_JOB_ID AND cj.CONTAINER_JOB_ID <> p_container_job_id));
  IF l_container_job_ids.COUNT() > 0 THEN
    OPEN cur;
  lable_loop:
    LOOP
      FETCH cur INTO v_id;
      SET l_container_job_id := v_id;
      UPDATE CONTAINER_JOBS
      SET RESULT_TS = get_epoch_time_num(),
          JOB_STATE = 2
      WHERE CONTAINER_JOB_ID = l_container_job_id;
      -- insert into container failure reason with other container job ids that belong to the same top level job
      CALL insert_failure_Reason(NULL, p_code, 'Container job failed due to the related Container job:' || p_container_job_id || ' has some error.', p_failure_time, l_container_job_id, NULL);
    END LOOP;
    CLOSE cur;
  END IF;
  UPDATE JOB_QUEUE
  SET REMAIN_JOBS = 0,
      FAILURE_COUNT = FAILURE_COUNT + 1
  WHERE JOB_ID = l_job_id;
  IF t_error = 1 THEN
    ROLLBACK;
  ELSE
    COMMIT;
  END IF;
END