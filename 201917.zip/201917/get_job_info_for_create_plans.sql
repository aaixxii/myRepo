CREATE DEFINER=`aimuser`@`%` PROCEDURE `get_job_info_for_create_plans`(
IN limited_job_ids varchar(2048))
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN
  DECLARE t_error integer DEFAULT 0;
  DECLARE v_idx int DEFAULT 999;
  DECLARE v_tmp_str varchar(20);
  DECLARE v_id int;
  DECLARE cur CURSOR FOR
  SELECT
    id
  FROM l_container_ids;
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
  DROP TEMPORARY TABLE IF EXISTS limited_ids_tab;
  CREATE TEMPORARY TABLE limited_ids_tab (
    id int
  ) ENGINE = MEMORY;
  WHILE v_idx > 0 DO
    SET v_idx = INSTR(limited_job_ids, ',');
    SET v_tmp_str = SUBSTR(limited_job_ids, 0, t_idx - 1);
    INSERT INTO limited_ids_tab (id)
      VALUES (CAST(v_tmp_str AS UNSIGNED));
    SET limited_job_ids = SUBSTR(limited_job_ids, v_idx + 1, LENGTH(limited_job_ids));
  END WHILE;

  SELECT
    jq.JOB_ID,
    jq.FAMILY_ID,
    fq.FUNCTION_ID,
    ssj.CONTAINER_ID,
    ssj.CONTAINER_JOB_ID
  FROM JOB_QUEUE jq,
       FUSION_JOBS fq,
       CONTAINER_JOBS ssj
  WHERE jq.JOB_ID = fq.JOB_ID
  AND fq.FUSION_JOB_ID = ssj.FUSION_JOB_ID
  AND jq.JOB_STATE = 0
  AND ssj.CONTAINER_ID != (SELECT
      CONTAINER_ID
    FROM SEGMENT_DEFRAGMENTATION)
  AND jq.JOB_ID IN (SELECT
      ID
    FROM LIMITED_JOB_IDS)
  ORDER BY PRIORITY,
  FAILURE_COUNT DESC,
  JOB_ID;
  IF t_error = 1 THEN
    -- select empty to return;
    SELECT
      NULL
    FROM dual;
  END IF;
END