CREATE DEFINER=`aimuser`@`%` PROCEDURE `fetch_timeout_job`(
)
BEGIN
  DECLARE l_epoch_time long;
  DECLARE t_error integer DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
  SET l_epoch_time := get_epoch_time_num();
  SELECT
    JOB_ID
  FROM JOB_QUEUE
  WHERE JOB_STATE = 'WORKING'
  AND 0 <= TIMEOUTS
  AND ASSIGNED_TS < (SELECT
      L_EPOCH_TIME - TIMEOUTS
    FROM DUAL)
  ORDER BY JOB_ID;
  IF t_error = 1 THEN
    SELECT
      1
    FROM dual
    WHERE FALSE;
  END IF;
END