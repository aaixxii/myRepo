CREATE DEFINER=`aimuser`@`%` PROCEDURE `decrease_extract_load`(IN p_mu_id int,
IN p_lot_count int,
OUT o_pressure int)
BEGIN
  DECLARE l_count int;
  DECLARE l_pressure int;
  DECLARE t_err int DEFAULT 0;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION SET t_err = 1;
  DECLARE CONTINUE HANDLER FOR SQLWARNING BEGIN
  END;
  SELECT
    COUNT(*) INTO l_count
  FROM MU_EXTRACT_LOAD
  WHERE MU_ID = p_mu_id;
  IF l_count > 0 THEN
    SELECT
      PRESSURE INTO l_pressure
    FROM MU_EXTRACT_LOAD
    WHERE MU_ID = p_mu_id
    FOR UPDATE;
    UPDATE MU_EXTRACT_LOAD
    SET PRESSURE = PRESSURE - p_lot_count,
        UPDATE_TS = get_epoch_time_num()
    WHERE MU_ID = P_MU_ID;
    SET O_PRESSURE = l_pressure;
  ELSE
    INSERT INTO MU_EXTRACT_LOAD (MU_ID,
    PRESSURE,
    UPDATE_TS)
      VALUES (P_MU_ID, 0, get_epoch_time_num());
    SET O_PRESSURE = 0;
  END IF;
  IF (l_pressure < 0) THEN
    UPDATE MU_EXTRACT_LOAD
    SET PRESSURE = 0,
        UPDATE_TS = get_epoch_time_num()
    WHERE MU_ID = p_mu_id;
  END IF;
  IF t_error = 1 THEN
    ROLLBACK;
  ELSE
    COMMIT;
  END IF;
END