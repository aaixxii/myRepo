CREATE DEFINER=`aimuser`@`%` PROCEDURE `get_mu_pressure_ability`(IN p_mu_ids varchar(1024))
    READS SQL DATA
    SQL SECURITY INVOKER
BEGIN
  --  p_mu_ids = "1000,1001,1002,1003";
  DECLARE t_error integer DEFAULT 0;
  DECLARE v_idx int DEFAULT 999;
  DECLARE v_tmp_str varchar(20);
  DECLARE v_id int;
  DECLARE CONTINUE HANDLER
  FOR SQLEXCEPTION
  SET t_error = 1;
  DROP TEMPORARY TABLE IF EXISTS mu_ids;
  CREATE TEMPORARY TABLE mu_ids (
    id int
  ) ENGINE = MEMORY;

  WHILE v_idx > 0 DO
    SET v_idx = INSTR(p_mu_ids, ',');
    SET v_tmp_str = SUBSTR(p_mu_ids, 0, v_idx - 1);
    INSERT INTO mu_ids (id)
      VALUES (CAST(v_tmp_str AS UNSIGNED));
    SET p_mu_ids = SUBSTR(p_mu_ids, v_idx + 1, LENGTH(p_mu_ids));
  END WHILE;
  SELECT
    ml.MU_ID,
    ml.PRESSURE,
    mu.NUMBER_OF_MATCHERS * mu.REPORTED_PERFORMANCE_FACTOR AS ability,
    ml.REPORT_TS
  FROM MU_INQUIRY_LOAD ml,
       MATCH_UNITS mu
  WHERE ml.MU_ID = mu.MU_ID
  AND mu.STATE = 'WORKING'
  AND mu.MU_ID IN (SELECT
      id
    FROM mu_ids)
  ORDER BY ml.MU_ID;
END