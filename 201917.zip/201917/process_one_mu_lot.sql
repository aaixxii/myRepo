CREATE DEFINER=`aimuser`@`%` PROCEDURE `process_one_mu_lot`(
IN p_mu_id int,
IN p_number_of_extractors int,
OUT l_lot_job_id int)
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
mylable:
  BEGIN
    DECLARE l_one_lot_count int;
    DECLARE l_mu_extract_load_count int;
    DECLARE l_fe_job_timeout int;
    DECLARE l_current_epoch_time int;
    DECLARE t_error integer DEFAULT 0;
    DECLARE v_idx int DEFAULT 999;
    DECLARE v_tmp_str varchar(20);
    DECLARE v_id int;
    DECLARE cur CURSOR FOR
    SELECT jobId  FROM l_locked_fe_job_ids;   
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
    DROP TEMPORARY TABLE IF EXISTS l_locked_fe_job_ids;
    CREATE TEMPORARY TABLE l_locked_fe_job_ids (jobId int  ) ENGINE = MEMORY;
   
    IF (p_mu_id <= 0 OR p_number_of_extractors <= 0) THEN      
      SET l_lot_job_id = -9999;
      LEAVE mylable;
    END IF;
    SET l_one_lot_count = p_number_of_extractors;
    INSERT INTO l_locked_fe_job_ids (jobId)
      VALUES ((SELECT JOB_ID FROM FE_JOB_QUEUE WHERE JOB_STATE = 0 AND PRIORITY = 1 ORDER BY PRIORITY, FAILURE_COUNT DESC, JOB_ID LIMIT 1));

    IF l_locked_fe_job_ids.count = 1 THEN
      SET l_one_lot_count = 1;
    ELSEIF l_locked_fe_job_ids.count < 1 THEN
      SELECT JOB_ID        
      FROM FE_JOB_QUEUE
      WHERE JOB_STATE = 0
      AND PRIORITY = 1
      ORDER BY PRIORITY, FAILURE_COUNT DESC,JOB_ID LIMIT l_one_lot_count;        
    END IF;
    IF (l_locked_fe_job_ids IS NULL
      OR l_locked_fe_job_ids.count = 0) THEN
      --  dbms_output.Put_line ('no fe_job to assign! return');        
      LEAVE mylable;
    END IF;
    SELECT  TOP_LEVEL_JOB_TIMEOUTS INTO l_fe_job_timeout     
    FROM FUNCTION_TYPES
    WHERE FUNCTION_ID = 17
    AND QUEUE_TYPE = 1;
    SET l_fe_job_timeout := l_fe_job_timeout * l_locked_fe_job_ids.count;
    SET l_current_epoch_time := get_epoch_time_num();
    
    INSERT INTO FE_LOT_JOBS (MU_ID, ASSIGNED_TS,TIMEOUTS) 
	VALUES (p_mu_id, l_current_epoch_time, l_fe_job_timeout);

    SELECT  MAX(LOT_JOB_ID) INTO l_lot_job_id FROM FE_LOT_JOBS;
    
    UPDATE MU_EXTRACT_LOAD
    SET PRESSURE = PRESSURE + 1,
        UPDATE_TS = L_CURRENT_EPOCH_TIME
    WHERE MU_ID = p_mu_id;

    OPEN cur;
  lable_loop:
    LOOP
      FETCH cur INTO v_id;
      UPDATE FE_JOB_QUEUE
      SET LOT_JOB_ID = l_lot_job_id,
          MU_ID = p_mu_id,
          JOB_STATE = 'WORKING',
          ASSIGNED_TS = l_current_epoch_time
      WHERE JOB_ID = v_id;
    END LOOP;
    CLOSE cur;
    IF t_error = 1 THEN
      ROLLBACK;
    ELSE
      COMMIT;
    END IF;
  END