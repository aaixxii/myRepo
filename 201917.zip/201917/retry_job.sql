CREATE DEFINER=`aimuser`@`%` PROCEDURE `retry_job`(IN p_job_id long,
OUT o_job_exec_count int)
BEGIN
  DECLARE l_job_exec_count int;
  DECLARE l_remain_jobs long;
  DECLARE l_family_id int;
  DECLARE t_error integer DEFAULT 0;
  DECLARE cur CURSOR FOR
  SELECT
    id
  FROM l_container_ids;
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
  DROP TEMPORARY TABLE IF EXISTS try_container_ids;
  CREATE TEMPORARY TABLE try_container_ids (
    id long
  ) ENGINE = MEMORY;
  INSERT INTO try_container_ids
    VALUES ((SELECT cj.CONTAINER_JOB_ID FROM JOB_QUEUE jq, FUSION_JOBS fj, CONTAINER_JOBS cj WHERE jq.JOB_STATE < 2 AND 0 < jq.REMAIN_JOBS AND jq.JOB_ID = fj.JOB_ID AND fj.FUSION_JOB_ID = cj.FUSION_JOB_ID AND jq.JOB_ID = p_job_id FOR UPDATE));

  SET l_remain_jobs = try_container_ids.count;
  IF (0 < l_remain_jobs) THEN
    UPDATE container_jobs
    SET mr_id = NULL,
        assigned_ts = NULL,
        job_state = c_job_state_queued,
        plan_id = NULL,
        result_ts = NULL,
        container_job_result = NULL
    WHERE container_job_id IN (SELECT
        id
      FROM try_container_ids);
    UPDATE job_queue
    SET job_state = 0,
        failure_count = failure_count + 1,
        assigned_ts = NULL,
        remain_jobs = l_remain_jobs
    WHERE job_id = p_job_id;

    SELECT
      jq.family_id INTO l_family_id
    FROM job_queue jq
    WHERE jq.job_id = p_job_id;

    UPDATE inquiry_traffic
    SET job_exec_count = job_exec_count - 1
    WHERE family_id = l_family_id;
    SELECT
      job_exec_count INTO l_job_exec_count
    FROM inquiry_traffic;

    IF l_job_exec_count < 0 THEN
      CALL Init_executing_job_count();
      SELECT
        job_exec_count INTO l_job_exec_count
      FROM inquiry_traffic
      WHERE family_id = l_family_id;
    END IF;
    IF t_error = 1 THEN
      ROLLBACK;
      SET o_job_exec_count = -1;
    ELSE
      COMMIT;
      SET o_job_exec_count = l_job_exec_count;
    END IF;
  END IF;
END