CREATE DEFINER=`aimuser`@`%` PROCEDURE `insert_failure_reason`(
IN p_mr_id int,
IN p_code varchar(20),
IN p_reason varchar(1024),
IN p_failure_time varchar(64),
IN p_container_job_id int,
IN p_segment_id long)
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN
  DECLARE l_segment_id long;
  DECLARE t_error integer DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
  IF p_segment_id IS NOT NULL
    OR p_segment_id > 0 THEN
    SET l_segment_id = p_segment_id;
  ELSE
    SET l_segment_id = NULL;
  END IF;
  INSERT INTO CONTAINER_JOB_FAILURE_REASONS (CODE,
  REASON,
  FAILURE_TIME,
  MR_ID,
  CONTAINER_JOB_ID,
  SEGMENT_ID)
    VALUES (p_code, p_reason, p_failure_time, p_mr_id, p_container_job_id, l_segment_id);
END