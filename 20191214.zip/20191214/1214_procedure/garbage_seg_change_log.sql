CREATE DEFINER=`aimuser`@`%` PROCEDURE `garbage_seg_change_log`(
  out r_delete_count INT
)
    READS SQL DATA
    SQL SECURITY INVOKER
begin_lab:
BEGIN
	DECLARE tmp_seg_id BIGINT(38);
    DECLARE l_count int DEFAULT 0;
    DECLARE l_bottom int;
    DECLARE l_max_diff int;
    DECLARE l_version int;
    DECLARE l_deleted int;
	DECLARE t_error int DEFAULT 0;
    DECLARE not_found int DEFAULT 0;
	DECLARE cur CURSOR FOR
     SELECT  seg_id FROM l_segment_ids;
	DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
    DECLARE CONTINUE handler FOR NOT found SET not_found=1;      
    DROP TEMPORARY TABLE IF EXISTS l_segment_ids;
    CREATE TEMPORARY TABLE l_segment_ids (
       seg_id BIGINT(38)
    ) ENGINE = MEMORY;
    SET  @@autocommit=0;
    INSERT INTO l_segment_ids(seg_id)
    SELECT segment_id FROM segments ORDER BY segment_id;
    SELECT count(seg_id) INTO l_count FROM l_segment_ids;
    IF l_count = 0 THEN
        set r_delete_count = 0;
        LEAVE begin_lab;
	END IF;
    SELECT cast(property_value as unsigned) INTO l_max_diff FROM system_config
	WHERE property_name = 'BEHAVIOR.MAX_SEGMENT_DIFFS';
     OPEN cur;
      lable_loop:LOOP      
		FETCH cur INTO tmp_seg_id;
	    IF not_found = 1 THEN
		  LEAVE lable_loop;
	    END IF;
		SELECT VERSION INTO l_version FROM SEGMENTS WHERE SEGMENT_ID = tmp_seg_id;
        SET l_bottom = l_version - l_max_diff;
	    select del_seg_chage_log(tmp_seg_id, l_bottom) into l_deleted;		
		SET  l_count = l_count + l_deleted;        
      end loop;
      CLOSE cur; 
       DROP TEMPORARY TABLE IF EXISTS l_segment_ids;
       set r_delete_count= l_count;
        DROP TEMPORARY TABLE IF EXISTS l_segment_ids;
END