CREATE DEFINER=`aimuser`@`%` PROCEDURE `persist_slb_matrix`(
IN p_slb_matrix varchar(2048),
IN p_container_id int,
IN p_component_type int
)
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN
  -- slb_matrix data="muId1:1000,muId2:1001,muId2:1003";  
  DECLARE t_len int;
  DECLARE t_idx int DEFAULT 1;
  DECLARE t_idx_2 int;
  DECLARE t_tmp varchar(20);
  DECLARE t_mu_id int;
  DECLARE t_seg int;
  DECLARE not_found int DEFAULT 0;
  DECLARE t_error integer DEFAULT 0;
  DECLARE cur CURSOR FOR
  SELECT  *  FROM list_tmp; 
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET not_found = 1;
  DROP TEMPORARY TABLE IF EXISTS list_tmp;
  CREATE TEMPORARY TABLE list_tmp (
    mu_id int,
    seg_id int
  ) ENGINE = MEMORY;
  SET  @@autocommit=0;
  SELECT
    LENGTH(p_slb_matrix) INTO t_len;
while_lab:
  WHILE t_len > 0
    && t_idx > 0 DO
    SET t_idx = INSTR(p_slb_matrix, ',');
    IF t_idx <= 0 THEN
      SET t_tmp = p_slb_matrix;
      SET t_idx_2 = INSTR(t_tmp, ':');
      SET t_mu_id = CAST(SUBSTR(t_tmp, 1, t_idx_2 - 1) AS UNSIGNED);
      SET t_seg = CAST(SUBSTR(t_tmp, t_idx_2 + 1, LENGTH(t_tmp)) AS UNSIGNED);
      INSERT INTO list_tmp
        VALUES (t_mu_id, t_seg);
      LEAVE while_lab;
    END IF;
    SET t_tmp = SUBSTR(p_slb_matrix, 1, t_idx - 1);
    SET t_idx_2 = INSTR(t_tmp, ':');
    SET t_mu_id = CAST(SUBSTR(t_tmp, 1, t_idx_2 - 1) AS UNSIGNED);
    SET t_seg = CAST(SUBSTR(t_tmp, t_idx_2 + 1, LENGTH(t_tmp)) AS UNSIGNED);
    INSERT INTO list_tmp
      VALUES (t_mu_id, t_seg);
    SET p_slb_matrix = SUBSTR(p_slb_matrix, t_idx + 1, LENGTH(p_slb_matrix));
    SET t_len = LENGTH(p_slb_matrix);
  END WHILE;
  OPEN cur;
lab_loop:
  LOOP
    FETCH cur INTO t_mu_id, t_seg;
    IF not_found = 1 THEN
      LEAVE lab_loop;
    END IF;
    IF (p_component_type = 3) THEN
      DELETE
        FROM MU_SEGMENTS
      WHERE SEGMENT_ID IN (SELECT
            SEGMENT_ID
          FROM SEGMENTS
          WHERE CONTAINER_ID = p_container_id);
      INSERT INTO MU_SEGMENTS (MU_ID, SEGMENT_ID, RANK)
        VALUES (t_mu_id, t_seg, 0);
    ELSEIF (p_component_type = 1) THEN
      DELETE
        FROM DM_SEGMENTS
      WHERE SEGMENT_ID IN (SELECT
            SEGMENT_ID
          FROM SEGMENTS
          WHERE CONTAINER_ID = p_container_id);
      INSERT INTO DM_SEGMENTS (DM_ID, SEGMENT_ID, RANK)
        VALUES (t_mu_id, t_seg, 0);
    END IF;
  END LOOP;
  IF t_error = 1 THEN
    ROLLBACK;   
  ELSE
    COMMIT;   
  END IF;
END