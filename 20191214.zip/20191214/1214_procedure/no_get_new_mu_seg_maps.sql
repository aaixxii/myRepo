CREATE DEFINER=`aimuser`@`%` PROCEDURE `get_new_mu_seg_maps`(
 IN p_container_id BIGINT(38), 
 IN p_function_id  INT, 
 OUT tab_name VARCHAR(50)
)
    READS SQL DATA
    SQL SECURITY INVOKER
BEGIN
  DROP TABLE IF EXISTS new_set_map;
CREATE TABLE new_set_map (
    mu_id INT,
    seg_id BIGINT,
    seg_ver BIGINT,
    container_id INT,
    function_id INT
)  ENGINE=INNODB;
   SET  @@autocommit=0;

INSERT INTO new_set_map(mu_id,seg_id,seg_ver,container_id,function_id)
SELECT map.MU_ID,
       map.SEGMENT_ID,
       seg.VERSION AS segment_version,
       seg.CONTAINER_ID,
       mf.FUNCTION_ID
FROM   MATCH_UNITS mu,
       SEGMENTS seg,
       MU_ELIGIBLE_FUNCTIONS mf,
       MU_SEG_REPORTS map
WHERE  mu.MU_ID = map.MU_ID
       AND seg.SEGMENT_ID = map.SEGMENT_ID
       AND mu.MU_ID = mf.MU_ID
       AND mu.STATE = C_WORKING_STATE_STRING
       AND map.STATUS <= 1
       AND mf.FUNCTION_ID = P_FUNCTION_ID
       AND seg.CONTAINER_ID = P_CONTAINER_ID
       AND seg.CONTAINER_ID != (SELECT CONTAINER_ID
                                FROM   SEGMENT_DEFRAGMENTATION); 
 set tab_name= 'new_set_map';
  if t_error =1 then 
   ROLLBACK;
     set tab_name= '';   
  else 
    commit;
  end if;
END