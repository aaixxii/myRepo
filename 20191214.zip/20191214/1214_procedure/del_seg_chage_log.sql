CREATE DEFINER=`aimuser`@`%` FUNCTION `del_seg_chage_log`(
  p_segment_id BIGINT(38),
  p_offset INT
) RETURNS int(11)
    READS SQL DATA
    SQL SECURITY INVOKER
BEGIN
  DECLARE l_del_count int DEFAULT 0; 
 		DELETE FROM SEGMENT_CHANGE_LOG WHERE SEGMENT_CHANGE_ID IN (
		  SELECT SEGMENT_CHANGE_ID FROM (
              SELECT 
                SEGMENT_CHANGE_ID
                FROM SEGMENT_CHANGE_LOG WHERE SEGMENT_ID = p_segment_id
                AND segment_version < p_offset
                ORDER BY SEGMENT_CHANGE_ID
                limit 10000
            ) as temp            
          );
      SELECT ROW_COUNT() into l_del_count;
RETURN l_del_count;
END