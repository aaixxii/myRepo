package jp.co.nec.aim.mm.procedure;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import jp.co.nec.aim.mm.entities.MapReducerEntity;
import jp.co.nec.aim.mm.util.CollectionsUtil;

import org.apache.commons.lang3.StringUtils;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.object.StoredProcedure;

/**
 * MRFetcherProcedure
 * 
 * @author liuyq
 * 
 */
public class MRFetcherProcedure extends StoredProcedure {
    private JdbcTemplate jdbcTemplate;
	/** sql **/
	private static final String SQL = "get_next_mr_position";

	/**
	 * MRFetcherProcedure constructor
	 * 
	 * @param dataSource
	 */
	public MRFetcherProcedure(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
		setDataSource(dataSource);
		setSql(SQL);
		declareParameter(new SqlOutParameter("tab_name", Types.VARCHAR));	
		compile();
	}

	/**
	 * execute
	 * 
	 * @return MapReducerEntity instance
	 */
	public MapReducerEntity execute() {
		Map<String, Object> map = new HashMap<String, Object>();
		Map<String, Object> resultMap = execute(map);
		String tableName = (String) resultMap.get("tab_name");
		if (StringUtils.isBlank(tableName)) return null;
		String sql = "select * from " + tableName;
		 List<Map<String, Object>> result = jdbcTemplate.queryForList(sql);
		 jdbcTemplate.execute("DROP TABLE IF EXISTS " + tableName);		
		final List<MapReducerEntity> list = new ArrayList<>();
		result.forEach(one -> {	
			long mrId = (long) one.get("mr_id");
			String mrUrl = (String) one.get("contact_url");
			MapReducerEntity mr = new MapReducerEntity();
			mr.setMrId(mrId);
			mr.setContactUrl(mrUrl);
			list.add(mr);			
		});
		
		if (CollectionsUtil.isEmpty(list)) {
			return null;
		} else {
			return CollectionsUtil.getFirst(list);
		}
	}

	/**
	 * CursorMapper
	 * 
	 * @author liuyq
	 * 
	 */
	private class CursorMapper implements RowMapper<MapReducerEntity> {
		@Override
		public MapReducerEntity mapRow(ResultSet rs, int rowNum)
				throws SQLException {
			long mrId = rs.getLong("MR_ID");
			if (mrId <= 0) {
				return null;
			}
			String contactUrl = rs.getString("CONTACT_URL");
			return new MapReducerEntity(mrId, contactUrl);
		}
	}

}
