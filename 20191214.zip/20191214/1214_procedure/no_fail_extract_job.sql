CREATE DEFINER=`aimuser`@`%` PROCEDURE `fail_extract_job`(
IN p_extract_job_id int,
IN p_mu_id int,
IN p_result blob,
IN p_reason varchar(1024),
IN p_code varchar(10),
IN p_time varchar(20),
OUT r_count int)
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN
  DECLARE l_count int;
  DECLARE l_epoch_time int;
  DECLARE t_error integer DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
  SET l_epoch_time := get_epoch_time_num();
  SET  @@autocommit=0;
UPDATE FE_JOB_QUEUE 
SET 
    LOT_JOB_ID = NULL,
    JOB_STATE = c_job_state_done,
    FAILED_FLAG = 1,
    RESULT_TS = l_epoch_time,
    RESULT = p_result,
    FAILURE_COUNT = FAILURE_COUNT + 1,
    MU_ID = p_mu_id
WHERE
    JOB_ID = p_extract_job_id
        AND JOB_STATE = 'WORKING'
        AND MU_ID = p_mu_id;
SELECT ROW_COUNT() INTO l_count;
  IF (0 < l_count) THEN
    INSERT INTO FE_JOB_FAILURE_REASONS (JOB_ID,
    MU_ID,
    CODE,
    REASON,
    FAILURE_TIME)
      VALUES (p_extract_job_id, p_mu_id, p_code, p_reason, p_time);
  END IF;
  IF t_error = 1 THEN
    ROLLBACK;
    SET r_count = -999;
  ELSE
    COMMIT;
    SET r_count = l_count;
  END IF;
SELECT r_count;
END