CREATE DEFINER=`aimuser`@`%` PROCEDURE `get_next_mr_position`(
 OUT tab_name VARCHAR(50)
)
my_label:BEGIN
	DECLARE  l_last_location  int DEFAULT 0;  
	DECLARE l_last_ts         int DEFAULT 0;
	DECLARE l_next_position   int DEFAULT 0;
	DECLARE l_next_mr_id      int DEFAULT 0;
	DECLARE l_seed            int DEFAULT 0;
	DECLARE l_count_last_mr   int DEFAULT 0;
	DECLARE l_count_reducer   int DEFAULT 0; 
    DECLARE t_error INTEGER DEFAULT 0;  
     DECLARE tmp_time BIGINT ; 
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1;  
    DROP TABLE IF EXISTS picked_mr;
   CREATE TABLE picked_mr (
      mr_id BIGINT,
      contact_url VARCHAR(300) 
   )  ENGINE=INNODB;  
   
  SET  @@autocommit=0; 
  SELECT COUNT(MR_ID) INTO l_count_reducer FROM  MAP_REDUCERS    
  WHERE STATE = 'WORKING'    
        AND RING_LOCATION IS NOT NULL;
  IF (l_count_reducer = 0) THEN         
	 LEAVE my_label; 
  END IF;
       -- LOCK TABLE LAST_ASSIGNED_MR WRITE; 
  start transaction;     
   SELECT  COUNT(ASSIGNED_LOCATION) INTO l_count_last_mr FROM  LAST_ASSIGNED_MR;
   IF(l_count_last_mr = 0) THEN
            SELECT UNIX_TIMESTAMP(NOW()) into tmp_time;
            SELECT mr_id, ring_location INTO l_next_mr_id, l_next_position
                   FROM MAP_REDUCERS 
                   WHERE STATE = 'WORKING'
                   AND RING_LOCATION IS NOT NULL ORDER BY ring_location LIMIT 1;                  
            INSERT INTO LAST_ASSIGNED_MR (assigned_location, assigned_ts) VALUES(l_next_position, tmp_time);
            COMMIT;
            -- at last, return the MR id and it's contact url    
     INSERT INTO picked_mr(mr_id, contact_url)
       SELECT mr.MR_ID, mr.CONTACT_URL FROM MAP_REDUCERS mr   
       WHERE  mr.MR_ID = l_next_mr_id;
	LEAVE my_label; 
  END IF;
           -- if last checkPoint is exist, then fetch the latest latest MR location
SELECT 
    assigned_location, assigned_ts
INTO l_last_location , l_last_ts FROM
    LAST_ASSIGNED_MR
ORDER BY assigned_ts
LIMIT 1;        
        -- fetch next MR location with specified latest MR location
SELECT 
    MR_ID AS mr_id,
    ring_location AS location,
    (- FLOOR((ring_location - (l_last_location + 1)) / 360) * 360) + (ring_location - (l_last_location + 1)) AS seed
INTO l_next_mr_id , l_next_position , l_seed FROM
    MAP_REDUCERS
WHERE
    STATE = 'WORKING'
        AND RING_LOCATION IS NOT NULL
ORDER BY SEED
LIMIT 1;
        -- save the last MR checkpoint
SELECT UNIX_TIMESTAMP(NOW()) into tmp_time;
UPDATE LAST_ASSIGNED_MR 
SET 
    assigned_location = l_next_position,
    assigned_ts = tmp_time
WHERE
    assigned_location = l_last_location
        AND assigned_ts = l_last_ts;
        -- let the other transaction find the last MR position
        COMMIT;
INSERT INTO picked_mr(mr_id, contact_url)        
SELECT 
    mr.MR_ID, mr.CONTACT_URL
FROM
    MAP_REDUCERS mr
WHERE
    mr.MR_ID = l_next_mr_id; 
      -- unlock table;
 set tab_name= 'picked_mr';
  if t_error =1 then 
   ROLLBACK;
     set tab_name= '';   
  else 
    commit;
  end if;     
END