CREATE DEFINER=`aimuser`@`%` PROCEDURE `testproc1`()
BEGIN    
    SELECT * FROM containers;
END
//