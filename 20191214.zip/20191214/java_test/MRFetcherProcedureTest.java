package jp.co.nec.aim.mm.procedure;

import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import javax.annotation.Resource;
import javax.sql.DataSource;
import javax.transaction.Transactional;

import jp.co.nec.aim.mm.entities.MapReducerEntity;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.google.common.collect.Lists;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class MRFetcherProcedureTest {
	@Resource
	private DataSource ds;
	private MRFetcherProcedure mrFetcherProcedure;
	@Resource
	private JdbcTemplate jdbcTemplate;

	@Before
	public void setUp() throws Exception {
		mrFetcherProcedure = new MRFetcherProcedure(ds);
		jdbcTemplate.update("delete from  container_jobs");
		jdbcTemplate.update("delete from  map_reducers");
		jdbcTemplate.update("delete from LAST_ASSIGNED_MR");
		jdbcTemplate.update("commit");

	}

	@After
	public void tearDown() throws Exception {
		jdbcTemplate.update("delete from  container_jobs");
		jdbcTemplate.update("delete from  map_reducers");
		jdbcTemplate.update("delete from LAST_ASSIGNED_MR");
		jdbcTemplate.update("commit");

	}

	@Test
	public void testExcute() {
		jdbcTemplate
				.update("insert into map_reducers values (1,1,'192.168.1.6','192.162.1.1','WORKING',1)");
		jdbcTemplate
				.update("insert into map_reducers values (2,120,'192.168.1.6','192.162.1.1','WORKING',1)");
		jdbcTemplate
				.update("insert into map_reducers values (3,79,'192.168.1.6','192.162.1.1','WORKING',1)");
		jdbcTemplate
				.update("insert into LAST_ASSIGNED_MR values (79,11111111111)");
		jdbcTemplate.update("commit");
		MapReducerEntity mr = mrFetcherProcedure.execute();
		jdbcTemplate.update("commit");
		Assert.assertEquals(2, mr.getMrId());
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from LAST_ASSIGNED_MR");
		Assert.assertEquals(1, list.size());
	}

	@Test
	public void test_mutip_thread_Excute() {
		jdbcTemplate
				.update("insert into map_reducers values (1,1,'192.168.1.6','192.162.1.1','WORKING',1)");
		jdbcTemplate
				.update("insert into map_reducers values (120,120,'192.168.1.6','192.162.1.1','WORKING',1)");
		jdbcTemplate
				.update("insert into map_reducers values (79,79,'192.168.1.6','192.162.1.1','WORKING',1)");
		jdbcTemplate
				.update("insert into map_reducers values (23,23,'192.168.1.6','192.162.1.1','WORKING',1)");
		jdbcTemplate
				.update("insert into map_reducers values (32,32,'192.168.1.6','192.162.1.1','WORKING',1)");
		jdbcTemplate
				.update("insert into map_reducers values (78,78,'192.168.1.6','192.162.1.1','WORKING',1)");
		jdbcTemplate
				.update("insert into map_reducers values (50,50,'192.168.1.6','192.162.1.1','WORKING',1)");
		jdbcTemplate
				.update("insert into map_reducers values (98,98,'192.168.1.6','192.162.1.1','WORKING',1)");
		jdbcTemplate
				.update("insert into map_reducers values (73,73,'192.168.1.6','192.162.1.1','WORKING',1)");
		jdbcTemplate
				.update("insert into map_reducers values (66,66,'192.168.1.6','192.162.1.1','WORKING',1)");
		jdbcTemplate
				.update("insert into LAST_ASSIGNED_MR values (79,11111111111)");
		jdbcTemplate.update("commit");

		final Queue<Long> queue = new ConcurrentLinkedQueue<Long>();
		ExecutorService service = null;
		try {
			service = Executors.newFixedThreadPool(20);
			List<Callable<Long>> tasks = Lists.newArrayList();
			for (int i = 0; i < 10; i++) {
				tasks.add(new Callable<Long>() {
					@Override
					public Long call() throws Exception {
						MRFetcherProcedure p = new MRFetcherProcedure(ds);
						MapReducerEntity mr = p.execute();
						queue.add(mr.getMrId());

						return null;
					}
				});
			}

			List<Future<Long>> fList = service.invokeAll(tasks);
			for (Future<Long> f : fList) {
				f.get();
			}

			for (Long mrId : queue) {
				System.out.println(mrId);
			}

		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (ExecutionException e) {
			e.printStackTrace();
		} finally {
			if (service != null) {
				service.shutdown();
			}
		}

	}

	@Test
	public void testExcuteLAST_ASSIGNED_MRIsEmpAndmutip_thread_Excute() {
		jdbcTemplate
				.update("insert into map_reducers values (1,1,'192.168.1.6','192.162.1.1','WORKING',1)");

		jdbcTemplate
				.update("insert into map_reducers values (2,2,'192.168.1.6','192.162.1.1','WORKING',1)");

		jdbcTemplate
				.update("insert into map_reducers values (12,12,'192.168.1.6','192.162.1.1','WORKING',1)");
		jdbcTemplate
				.update("insert into map_reducers values (14,14,'192.168.1.6','192.162.1.1','QUEUED',1)");

		jdbcTemplate
				.update("insert into map_reducers values (29,29,'192.168.1.6','192.162.1.1','WORKING',1)");

		jdbcTemplate
				.update("insert into map_reducers values (111,111,'192.168.1.6','192.162.1.1','WORKING',1)");

		jdbcTemplate
				.update("insert into map_reducers values (222,222,'192.168.1.6','192.162.1.1','WORKING',1)");

		jdbcTemplate
				.update("insert into map_reducers values (121,121,'192.168.1.6','192.162.1.1','WORKING',1)");

		jdbcTemplate
				.update("insert into map_reducers values (291,291,'192.168.1.6','192.162.1.1','WORKING',1)");

		jdbcTemplate
				.update("insert into map_reducers values (59,59,'192.168.1.6','192.162.1.1','WORKING',1)");

		jdbcTemplate
				.update("insert into map_reducers values (79,79,'192.168.1.6','192.162.1.1','WORKING',1)");

		jdbcTemplate
				.update("insert into map_reducers values (87,87,'192.168.1.6','192.162.1.1','WORKING',1)");

		jdbcTemplate
				.update("insert into map_reducers values (97,97,'192.168.1.6','192.162.1.1','WORKING',1)");

		jdbcTemplate
				.update("insert into map_reducers values (123,123,'192.168.1.6','192.162.1.1','WORKING',1)");

		jdbcTemplate
				.update("insert into map_reducers values (231,231,'192.168.1.6','192.162.1.1','WORKING',1)");

		jdbcTemplate
				.update("insert into map_reducers values (1211,1211,'192.168.1.6','192.162.1.1','WORKING',1)");

		jdbcTemplate
				.update("insert into map_reducers values (2922,2922,'192.168.1.6','192.162.1.1','WORKING',1)");
		jdbcTemplate.update("commit");
		/*
		 * MapReducerEntity mr = mrFetcherProcedure.execute();
		 * jdbcTemplate.update("commit"); Assert.assertEquals(1, mr.getMrId());
		 */

		final Queue<Long> queue = new ConcurrentLinkedQueue<Long>();
		ExecutorService service = null;
		try {
			service = Executors.newFixedThreadPool(16);
			List<Callable<Long>> tasks = Lists.newArrayList();
			for (int i = 0; i < 16; i++) {
				tasks.add(new Callable<Long>() {
					@Override
					public Long call() throws Exception {
						MRFetcherProcedure p = new MRFetcherProcedure(ds);
						MapReducerEntity mr = p.execute();
						queue.add(mr.getMrId());

						return null;
					}
				});
			}

			List<Future<Long>> fList = service.invokeAll(tasks);
			for (Future<Long> f : fList) {
				f.get();
			}

			for (Long mrId : queue) {
				System.out.println(mrId);
			}

		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (ExecutionException e) {
			e.printStackTrace();
		} finally {
			if (service != null) {
				service.shutdown();
			}
		}
	}

	@Test
	public void testExcuteLAST_ASSIGNED_MRIsEmp() {
		jdbcTemplate
				.update("insert into map_reducers values (1,1,'192.168.1.6','192.162.1.1','WORKING',1)");

		jdbcTemplate
				.update("insert into map_reducers values (2,2,'192.168.1.6','192.162.1.1','WORKING',1)");
		jdbcTemplate.update("commit");
		MapReducerEntity mr = mrFetcherProcedure.execute();
		jdbcTemplate.update("commit");
		Assert.assertEquals(1, mr.getMrId());
	}

	@Test
	public void testExcuteMRIsEmp() {
		jdbcTemplate
				.update("insert into LAST_ASSIGNED_MR values (1,11111111111)");
		jdbcTemplate.update("commit");
		MapReducerEntity mr = mrFetcherProcedure.execute();
		jdbcTemplate.update("commit");
		Assert.assertNull(mr.getRingLocation());
	}

}
