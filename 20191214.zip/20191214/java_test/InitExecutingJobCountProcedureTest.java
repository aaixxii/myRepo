package jp.co.nec.aim.mm.procedure;

import static org.junit.Assert.assertEquals;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.sql.DataSource;
import javax.transaction.Transactional;

import jp.co.nec.aim.mm.dao.DateDao;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class InitExecutingJobCountProcedureTest {
	@Resource
	private DataSource dataSource;
	@Resource
	private JdbcTemplate jdbcTemplate;

	private DateDao dateDao;
	private long curTime;

	@Before
	public void setUp() throws Exception {
		clearDB();
		dateDao = new DateDao(dataSource);
		curTime = 1000;

		intsertUnit();
		intsertInquiryJob();

	}

	@After
	public void tearDown() throws Exception {
		clearDB();
	}

	private void intsertUnit() {
		for (int id = 1; id <= 3; id++) {
			jdbcTemplate.execute("insert into MAP_REDUCERS(MR_ID, UNIQUE_ID,"
					+ " RING_LOCATION, STATE) values(" + id + ", '" + id
					+ "', " + id + ", 'WORKING')");
			jdbcTemplate.execute("insert into MR_CONTACTS(MR_ID, CONTACT_TS)"
					+ " values(" + id + ", " + curTime + ")");
		}
		jdbcTemplate.execute("insert into LAST_ASSIGNED_MR(ASSIGNED_LOCATION,"
				+ " ASSIGNED_TS) values(1, " + (curTime - 10000) + ")");
	}

	private void clearDB() {
		jdbcTemplate.execute("delete from JOB_QUEUE");
		jdbcTemplate.execute("delete from LAST_ASSIGNED_MR");
		jdbcTemplate.execute("delete from MR_CONTACTS");
		jdbcTemplate.execute("delete from MAP_REDUCERS");
		jdbcTemplate.execute("delete from SYSTEM_CONFIG");
		jdbcTemplate.execute("commit");
	}

	private void intsertInquiryJob() {
		String jqSQL = "insert into JOB_QUEUE(JOB_ID, PRIORITY, JOB_STATE,"
				+ " SUBMISSION_TS, ASSIGNED_TS, CALLBACK_STYLE, TIMEOUTS,"
				+ " FAILURE_COUNT, REMAIN_JOBS, FAMILY_ID)"
				+ " values(?, 5, ?, 1421206612748, ?, 0, 100000, ?, ?, ?)";

		String fjSQL = "insert into FUSION_JOBS(FUSION_JOB_ID, FUNCTION_ID,"
				+ " JOB_ID, SEARCH_REQUEST_INDEX) values(?, ?, ?, ?)";

		String cjSQL = "insert into CONTAINER_JOBS(CONTAINER_JOB_ID,"
				+ " CONTAINER_ID, FUSION_JOB_ID, MR_ID, ASSIGNED_TS, JOB_STATE,"
				+ " PLAN_ID) values(?, ?, ?, ?, ?, ?, ?)";

		String cjfrSQL = "insert into CONTAINER_JOB_FAILURE_REASONS(FAILURE_ID,"
				+ " CODE, REASON, FAILURE_TIME, MR_ID, CONTAINER_JOB_ID,"
				+ " SEGMENT_ID) values(1, 'test code', 'test reason', '"
				+ curTime + "', 1, 10, 1)";

		for (int jobId = 1; jobId <= 6; jobId++) {
			jdbcTemplate.update(jqSQL, new Object[] { jobId, (jobId - 1) % 3,
					curTime, 0, 4, jobId });
			for (int fjId = 1; fjId <= 2; fjId++) {
				jdbcTemplate.update(fjSQL, new Object[] {
						(jobId - 1) * 2 + fjId, jobId, jobId, fjId });
				for (int cjId = 1; cjId <= 2; cjId++) {
					jdbcTemplate.update(cjSQL, new Object[] {
							(((jobId - 1) * 2 + fjId) - 1) * 2 + cjId, cjId,
							(jobId - 1) * 2 + fjId, jobId % 3 + 1, curTime,
							(jobId - 1) % 3, jobId });
				}
			}

		}
		jdbcTemplate.update(cjfrSQL);
	}

	@Test
	public void test_FetchTimeoutJobProcedure() throws SQLException {

		InitExecutingJobCountProcedure procedure = new InitExecutingJobCountProcedure(
				dataSource);

		procedure.execute();

		// INQUIRY_TRAFFIC
		List<Map<String, Object>> listIT = jdbcTemplate.queryForList("select"
				+ " JOB_EXEC_COUNT from INQUIRY_TRAFFIC order by FAMILY_ID");
		assertEquals(9, listIT.size());
		for (int i = 0; i < listIT.size(); i++) {
			if (i == 1 || i == 4) {
				assertEquals("1", listIT.get(i).get("JOB_EXEC_COUNT")
						.toString());
			} else {
				assertEquals("0", listIT.get(i).get("JOB_EXEC_COUNT")
						.toString());
			}
		}
	}
}
