package jp.co.nec.aim.mm.procedure;

import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.util.StopWatch;

/**
 * Spring StoredProcedure to call retry_job()
 * 
 * @author jinxl
 * 
 */
public class RetryInquiryJobProcedure extends StoredProcedure {

	private static final String SQL = "retry_job";

	public RetryInquiryJobProcedure(DataSource dataSource) {
		setDataSource(dataSource);
		setSql(SQL);
		declareParameter(new SqlParameter("p_job_id", Types.BIGINT));
		declareParameter(new SqlOutParameter("l_job_exec_count", Types.BIGINT));
		compile();
	}

	/**
	 * Try to add 1 to JOB_QUEUE.FAILURE_COUNT and delete all MU_JOBS
	 * 
	 * @param container
	 *            Job Id containerJobId
	 * @return JOB_ID of JOB_QUEUE added 1 to FAILURE_COUNT, -1 if add JOB_QUEUE
	 *         which has muJobId not found
	 */
	public long execute(long toplevelJobId) {
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("p_job_id", toplevelJobId);
		Map<String, Object> resultMap = execute(map);
		Long excuteJob = (Long) resultMap.get("l_job_exec_count");

		long excuteJobId = null == excuteJob ? -2 : excuteJob.longValue();

		stopWatch.stop();
		return excuteJobId;
	}

}
