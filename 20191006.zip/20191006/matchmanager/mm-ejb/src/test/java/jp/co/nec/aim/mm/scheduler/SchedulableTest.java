//package jp.co.nec.aim.mm.scheduler;
//
//import static org.junit.Assert.assertFalse;
//
//import javax.annotation.Resource;
//import javax.persistence.EntityManager;
//import javax.persistence.PersistenceContext;
//import javax.sql.DataSource;
//import javax.transaction.Transactional;
//
//import jp.co.nec.aim.mm.common.JdbcTemplateHelper;
//import jp.co.nec.aim.mm.constants.SchedulerEnum;
//import jp.co.nec.aim.mm.dao.MatchManagerDao;
//import jp.co.nec.aim.mm.dao.SystemConfigDao;
//import mockit.Mock;
//import mockit.MockUp;
//
//import org.junit.After;
//import org.junit.Before;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.springframework.jdbc.core.JdbcTemplate;
//import org.springframework.test.context.ContextConfiguration;
//import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
//
//@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration
//@Transactional
//public class SchedulableTest {
//
//	@Resource
//	private DataSource ds;
//
//	@PersistenceContext(unitName = "aim-db")
//	private EntityManager entityManager;
//
//	@Resource
//	private JdbcTemplate jdbcTemplate;
//
//	private QuartzManager quartzmanager = null;
//	private JdbcTemplateHelper helper;
//	private SystemConfigDao sysConfigDao;
//
//	private ListCommon common;
//
//	private int intervalInMillis = 10000;
//
//	@Before
//	public void setUp() throws Exception {
//		if (helper == null) {
//			helper = new JdbcTemplateHelper();
//			sysConfigDao = new SystemConfigDao(entityManager);
//			common = new ListCommon();
//			common.init();
//		}
//
//		common.initSysConf(helper, jdbcTemplate, entityManager, sysConfigDao,
//				ds);
//		helper.UpdateSystemConfig(
//				entityManager,
//				SchedulerEnum.DefragSchedulable.getIntervalProperty().getName(),
//				String.valueOf(1000));
//		SchedulerEnum.DefragSchedulable.setIntervalInMillis(1000);
//		QuartzManager.INSTANCE = null;
//		quartzmanager = QuartzManager.getInstance(entityManager);
//		setMockMethods();
//	}
//
//	private void setMockMethods() {
//		new MockUp<MatchManagerDao>() {
//			@Mock
//			private String getMMUniqueId() {
//				return "10.84.75.213";
//			}
//		};
//	}
//
//	@After
//	public void tearDown() throws Exception {
//		common.initSysConf(helper, jdbcTemplate, entityManager, sysConfigDao,
//				ds);		
//		common.clear();
//	}
//
//	@Test
//	public void testAggregationSchedulable() {
//
//		common.setMockMethods01();
//		helper.insertMM_SameMMId_mmId10(jdbcTemplate);
//
//		try {
//			quartzmanager.startScheduler();
//
//			Thread.sleep(intervalInMillis);
//		} catch (InterruptedException e) {
//			assertFalse(true);
//		} finally {
//			quartzmanager.shutdownScheduler();
//		}
//		common.printf(Thread.currentThread().getStackTrace()[1].getClassName(),
//				Thread.currentThread().getStackTrace()[1].getMethodName());
//	}
//
//	@Test
//	public void testAggregationSchedulableException() {
//
//		common.setMockMethods02();
//		helper.insertMM_SameMMId_mmId10(jdbcTemplate);
//
//		try {
//			quartzmanager.startScheduler();
//
//			Thread.sleep(intervalInMillis);
//		} catch (InterruptedException e) {
//			assertFalse(true);
//		} finally {
//			quartzmanager.shutdownScheduler();
//		}
//
//		common.printf(Thread.currentThread().getStackTrace()[1].getClassName(),
//				Thread.currentThread().getStackTrace()[1].getMethodName());
//	}
//}
