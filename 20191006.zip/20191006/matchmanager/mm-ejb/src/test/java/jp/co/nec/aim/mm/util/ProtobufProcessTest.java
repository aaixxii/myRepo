package jp.co.nec.aim.mm.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.google.common.collect.Lists;
import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;

import jp.co.nec.aim.message.proto.AIMMessages.PBMuExtractJobItem;
import jp.co.nec.aim.message.proto.AIMMessages.PBMuExtractJobRequest;
import jp.co.nec.aim.message.proto.AIMMessages.PBMuExtractJobResultItem;
import jp.co.nec.aim.message.proto.BatchTypeProto.BatchType;
import jp.co.nec.aim.message.proto.BusinessMessage.E_REQUESET_TYPE;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBusinessMessage;
import jp.co.nec.aim.message.proto.BusinessMessage.PBCandidate;
import jp.co.nec.aim.message.proto.BusinessMessage.PBDataBlock;
import jp.co.nec.aim.message.proto.BusinessMessage.PBDataElement;
import jp.co.nec.aim.message.proto.BusinessMessage.PBDataGroup;
import jp.co.nec.aim.message.proto.BusinessMessage.PBRequest;
import jp.co.nec.aim.message.proto.BusinessMessage.PBResponse;
import jp.co.nec.aim.message.proto.BusinessMessage.PBResponseAttribute;
import jp.co.nec.aim.message.proto.ExtractService.ExtractResponse;
import jp.co.nec.aim.message.proto.InquiryService.IdentifyResponse;
import jp.co.nec.aim.mm.entities.FeJobPayloadEntity;
import jp.co.nec.aim.mm.sessionbeans.pojo.AimServiceState;

public class ProtobufProcessTest {
	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}
	
	@Test
	public void MuExtractJobResultItemTest() throws InvalidProtocolBufferException {		
		PBBusinessMessage pm = createPBBusinessMessage();
		PBMuExtractJobResultItem.Builder item = PBMuExtractJobResultItem.newBuilder();
		item.setResult(pm.toByteString());
		PBBusinessMessage newPm = PBBusinessMessage.parseFrom(item.getResult());
		System.out.print(newPm.toString());
		pm = null;
		item = null;		
	}
	
	@Test
	public void parsePBBusinessMessage() {
		List<PBBusinessMessage> pbMsgList = Lists.newArrayList();
		PBBusinessMessage.Builder pbMsg = PBBusinessMessage.newBuilder();		
		PBRequest.Builder pq = PBRequest.newBuilder();
		pq.setRequestId("12");
		pq.setRequestType(E_REQUESET_TYPE.IDENTIFY_DEFAULT);
		pbMsg.setRequest(pq);
		PBResponse.Builder ps = PBResponse.newBuilder();
		ps.setStatus("0:success");
		pbMsg.setResponse(ps);
		PBDataBlock.Builder pd = PBDataBlock.newBuilder();
		List<PBCandidate> pbList = Lists.newArrayList();
		for (int i = 0 ; i < 5; i++) {
			PBCandidate.Builder pb = PBCandidate.newBuilder();
			pb.setEnrollmentId("enroll");
			pb.setScaledScore(100 + i);			
			pbList.add(pb.build());
		}
		for (int i = 0 ; i < 4; i++) {
			PBCandidate.Builder pb = PBCandidate.newBuilder();
			pb.setEnrollmentId("external");
			pb.setScaledScore(10 + i);			
			pbList.add(pb.build());
		}
		
		for (int i = 0 ; i < 7; i++) {
			PBCandidate.Builder pb = PBCandidate.newBuilder();
			pb.setEnrollmentId("test" );
			pb.setScaledScore(27 + i);			
			pbList.add(pb.build());
		}
		for (int i = 0 ; i < 10; i++) {
			PBCandidate.Builder pb = PBCandidate.newBuilder();
			pb.setEnrollmentId("xia" + i);
			pb.setScaledScore(100 + i);			
			pbList.add(pb.build());
		}	
		
		Collections.shuffle(pbList); 		
		
		pd.getCandidateListBuilder().addAllCandidates(pbList);
		pd.getCandidateListBuilder().setMore(false);
		
		List<PBDataElement> pbDeList= new ArrayList<>();
		for (int i = 0 ; i < 5; i++) {
			PBDataElement.Builder pb = PBDataElement.newBuilder();
			pb.setElementName("read");
			pb.setElementValue(String.valueOf(i));
			pbDeList.add(pb.build());
		}
		for (int i = 3 ; i < 6; i++) {
			PBDataElement.Builder pb = PBDataElement.newBuilder();
			pb.setElementName("rmf");
			pb.setElementValue(String.valueOf(i));
			pbDeList.add(pb.build());
		}
		for (int i = 1 ; i < 5; i++) {
			PBDataElement.Builder pb = PBDataElement.newBuilder();
			pb.setElementName("iris");
			pb.setElementValue(String.valueOf(i));
			pbDeList.add(pb.build());
		}
		
		for (int i = 5; i < 10; i++) {
			PBDataElement.Builder pb = PBDataElement.newBuilder();
			pb.setElementName("face");
			pb.setElementValue(String.valueOf(i));
			pbDeList.add(pb.build());
		}
		System.out.print(pbDeList.toString());
		Collections.shuffle(pbDeList); 		
		PBDataGroup.Builder pg = PBDataGroup.newBuilder();
		pg.setGroupName("amr");
		for (int i = 0; i < pbDeList.size(); i++) {
			pg.addDataElement(i, pbDeList.get(i));
		}
		
		pd.addDataGroup(pg.build());		
		pbMsg.setDataBlock(pd.build());
		pbMsgList.add(pbMsg.build());
		
		IdentifyResponse.Builder identifyResponse = IdentifyResponse.newBuilder();
		identifyResponse.setBatchJobId(1000);
		identifyResponse.setType(BatchType.IDENTIFY);	
		
		for (int i = 0; i < pbMsgList.size(); i++) {
			
			identifyResponse.addBusinessMessage(ByteString.copyFrom(pbMsgList.get(i).toByteArray()));
		}
		
		PBBusinessMessage newPbMesg = null;
		try {
			newPbMesg = PBBusinessMessage.parseFrom(identifyResponse.getBusinessMessageList().get(0).toByteArray());
		} catch (InvalidProtocolBufferException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.print(newPbMesg.toString());
		pbMsgList = null;
		pbMsg = null;		
		 pq = null;
		 newPbMesg = null;
		
	}
	
	@Test
	public void buildFeRequestTest() {
		Long[] fejobIds = {1L,2L};
		List<FeJobPayloadEntity> payLoads =Lists.newArrayList();
		FeJobPayloadEntity payload = new FeJobPayloadEntity();
		payload.setId(1111L);
		payload.setJobId(1L);
		payload.setPayload("payload".getBytes());
		payLoads.add(payload);
		FeJobPayloadEntity payload2 = new FeJobPayloadEntity();
		payload2.setId(1112L);
		payload2.setJobId(2L);
		payload2.setPayload("payloadpayload".getBytes());
		payLoads.add(payload2);
		PBMuExtractJobRequest muRequest =  buildFeRequest(2000L,5000L,Arrays.asList(fejobIds),payLoads);
		System.out.print(muRequest.toString());
	}

	protected PBMuExtractJobRequest buildFeRequest(long lotJobId, long timeout, List<Long> feJobIds,
			List<FeJobPayloadEntity> payLoads) {
		PBMuExtractJobRequest.Builder request = PBMuExtractJobRequest.newBuilder();
		request.setLotJobId(lotJobId);
		try {
			for (int i = 0; i < feJobIds.size(); i++) {
				PBMuExtractJobItem.Builder extractItem = PBMuExtractJobItem.newBuilder();
				final Long jobId = feJobIds.get(i);
				extractItem.setJobId(feJobIds.get(i));
				extractItem.setJobTimeout(timeout < 0 ? Long.MAX_VALUE : timeout);
				payLoads.forEach(py -> {
					if (py.getJobId() == jobId.longValue()) {
						extractItem.setRequest(ByteString.copyFrom(py.getPayload()));
					}
				});		
				
				request.addJobs(i, extractItem.build());			
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		
		return request.build();
	}	
	
	@Test
	public void createPBExtractJobResultTest() {
		AimServiceState reason = new AimServiceState();
		reason.setErrMsg("error");
		reason.setErrorcode("333:faild");
		reason.setFailureTime(String.valueOf(System.currentTimeMillis()));
		ExtractResponse exRes = createPBExtractJobResult(100, reason);
		System.out.print(exRes.toString());
				
	}	
	private ExtractResponse createPBExtractJobResult(long jobId,
			AimServiceState reason) {
		ExtractResponse.Builder result = ExtractResponse.newBuilder();	
		PBBusinessMessage pbMes = createPBBusinessMessage();
		result.setBatchJobId(1000);
		result.setType(BatchType.EXTRACT);			
		PBResponse.Builder errRes = PBResponse.newBuilder();
		errRes.setErrorMessage(reason.getErrMsg());
		errRes.setStatus(reason.getErrorcode()+ ":" + "faild");
		PBResponseAttribute.Builder pbpa = PBResponseAttribute.newBuilder();
		pbpa.setAttributeName("createdTimestamp");
		pbpa.setAttributeValue(String.valueOf(System.currentTimeMillis()));
		errRes.addResponseAttributes(0, pbpa);	
		pbMes.toBuilder().setResponse(errRes);		
		result.addBusinessMessage(pbMes.toByteString());		
		return result.build();
	}
	
	public PBBusinessMessage createPBBusinessMessage() {
		List<PBBusinessMessage> pbMsgList = Lists.newArrayList();
		PBBusinessMessage.Builder pbMsg = PBBusinessMessage.newBuilder();		
		PBRequest.Builder pq = PBRequest.newBuilder();
		pq.setRequestId("12");
		pq.setRequestType(E_REQUESET_TYPE.IDENTIFY_DEFAULT);
		pbMsg.setRequest(pq);
				PBDataBlock.Builder pd = PBDataBlock.newBuilder();
		List<PBCandidate> pbList = Lists.newArrayList();
		for (int i = 0 ; i < 5; i++) {
			PBCandidate.Builder pb = PBCandidate.newBuilder();
			pb.setEnrollmentId("enroll");
			pb.setScaledScore(100 + i);			
			pbList.add(pb.build());
		}
		for (int i = 0 ; i < 4; i++) {
			PBCandidate.Builder pb = PBCandidate.newBuilder();
			pb.setEnrollmentId("external");
			pb.setScaledScore(10 + i);			
			pbList.add(pb.build());
		}
		
		for (int i = 0 ; i < 7; i++) {
			PBCandidate.Builder pb = PBCandidate.newBuilder();
			pb.setEnrollmentId("test" );
			pb.setScaledScore(27 + i);			
			pbList.add(pb.build());
		}
		for (int i = 0 ; i < 10; i++) {
			PBCandidate.Builder pb = PBCandidate.newBuilder();
			pb.setEnrollmentId("xia" + i);
			pb.setScaledScore(100 + i);			
			pbList.add(pb.build());
		}	
		
		Collections.shuffle(pbList); 		
		
		pd.getCandidateListBuilder().addAllCandidates(pbList);
		pd.getCandidateListBuilder().setMore(false);
		
		List<PBDataElement> pbDeList= new ArrayList<>();
		for (int i = 0 ; i < 5; i++) {
			PBDataElement.Builder pb = PBDataElement.newBuilder();
			pb.setElementName("read");
			pb.setElementValue(String.valueOf(i));
			pbDeList.add(pb.build());
		}
		for (int i = 3 ; i < 6; i++) {
			PBDataElement.Builder pb = PBDataElement.newBuilder();
			pb.setElementName("rmf");
			pb.setElementValue(String.valueOf(i));
			pbDeList.add(pb.build());
		}
		for (int i = 1 ; i < 5; i++) {
			PBDataElement.Builder pb = PBDataElement.newBuilder();
			pb.setElementName("iris");
			pb.setElementValue(String.valueOf(i));
			pbDeList.add(pb.build());
		}
		
		for (int i = 5; i < 10; i++) {
			PBDataElement.Builder pb = PBDataElement.newBuilder();
			pb.setElementName("face");
			pb.setElementValue(String.valueOf(i));
			pbDeList.add(pb.build());
		}
		System.out.print(pbDeList.toString());
		Collections.shuffle(pbDeList); 		
		PBDataGroup.Builder pg = PBDataGroup.newBuilder();
		pg.setGroupName("amr");
		for (int i = 0; i < pbDeList.size(); i++) {
			pg.addDataElement(i, pbDeList.get(i));
		}
		
		pd.addDataGroup(pg.build());		
		pbMsg.setDataBlock(pd.build());
		pbMsgList.add(pbMsg.build());
		return pbMsgList.get(0);
		
	}
	

}
