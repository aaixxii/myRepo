package jp.co.nec.aim.mm.identify.dispatch;

import static org.junit.Assert.*;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import jp.co.nec.aim.mm.common.HttpTestServer;
import jp.co.nec.aim.mm.constants.JobState;
import jp.co.nec.aim.mm.dao.InquiryJobDao;
import jp.co.nec.aim.mm.entities.ContainerJobEntity;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.identify.planner.MuJobExecutePlan;
import jp.co.nec.aim.mm.jms.JmsSender;
import mockit.Mock;
import mockit.MockUp;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mortbay.jetty.Handler;
import org.mortbay.jetty.HttpConnection;
import org.mortbay.jetty.Request;
import org.mortbay.jetty.handler.AbstractHandler;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.protobuf.InvalidProtocolBufferException;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration()
@Transactional
public class InquiryDispatcherTest {
	@Resource
	private DataSource dataSource;
	@PersistenceContext(unitName = "aim-db")
	private EntityManager entityManager;
	@Resource
	private InquiryDispatcher inquiryDispatcher;
	@Resource
	private JdbcTemplate jdbcTemplate;

	private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
	private final ByteArrayOutputStream errContent = new ByteArrayOutputStream();

	private static PrintStream bk_out = System.out;
	private static PrintStream bk_err = System.err;	

	@Before
	public void setUp() {
		jdbcTemplate.update("delete from MATCH_UNITS");
		jdbcTemplate.update("delete from JOB_QUEUE");
		jdbcTemplate.update("delete from fusion_jobs");
		jdbcTemplate.update("delete from container_jobs");
		jdbcTemplate.update("delete from mu_job_execute_plans");
		jdbcTemplate.update("delete from map_reducers");
		jdbcTemplate.update("delete from LAST_ASSIGNED_MR");
		jdbcTemplate.execute("commit");
		setMockMethod();
		System.setOut(new PrintStream(outContent));
		System.setErr(new PrintStream(errContent));
	}

	@After
	public void tearDown() {
		jdbcTemplate.update("delete from MATCH_UNITS");
		jdbcTemplate.update("delete from JOB_QUEUE");
		jdbcTemplate.update("delete from fusion_jobs");
		jdbcTemplate.update("delete from container_jobs");
		jdbcTemplate.update("delete from mu_job_execute_plans");
		jdbcTemplate.update("delete from map_reducers");
		jdbcTemplate.update("delete from LAST_ASSIGNED_MR");
		jdbcTemplate.execute("commit");		
		System.setOut(bk_out);
		System.setErr(bk_err);

	}

	private void setMockMethod() {
		new MockUp<JmsSender>() {
			@Mock
			private void convertAndSend(String queueName, Object object) {
				return;
			}
		};
	}

	private static HttpTestServer _server = null;

	@BeforeClass
	public static void init() throws Exception {
		_server = new HttpTestServer(65521);
		_server.start(getMockHandler());
	}

	@AfterClass
	public static void after() throws Exception {
		if (_server != null) {
			_server.stop();
		}
	}

	public static Handler getMockHandler() {
		Handler handler = new AbstractHandler() {
			public void handle(String target, HttpServletRequest request,
					HttpServletResponse response, int dispatch)
					throws IOException, ServletException {
				Request baseRequest = request instanceof Request ? (Request) request
						: HttpConnection.getCurrentConnection().getRequest();
				response.setStatus(200);
				response.setContentType("text/html;charset=utf-8");
				response.setCharacterEncoding("UTF-8");
				baseRequest.setHandled(true);
			}
		};
		return handler;
	}

	@Test
	public void testDispatchPlanIsNull() {
		jdbcTemplate
				.update("insert into job_queue(JOB_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE,TIMEOUTS,FAILURE_COUNT,REMAIN_JOBS,FAMILY_ID)values(1,5,0,123,0,10,0,0,1)");
		jdbcTemplate
				.update("insert into fusion_jobs(FUSION_JOB_ID,FUNCTION_ID,JOB_ID,INQUIRY_JOB_DATA,SEARCH_REQUEST_INDEX)values(1,1,1,TO_BLOB('111'),1)");
		jdbcTemplate
				.update("insert into container_jobs(CONTAINER_JOB_ID,CONTAINER_ID,FUSION_JOB_ID)values(1,1,1)");
		jdbcTemplate
				.update("insert into mu_job_execute_plans(PLAN_ID,JOB_ID,FUNCTION_ID,CONTAINER_ID,PLAN,PLANED_COUNT,PLANED_TS)values(1,1,1,1,TO_CLOB('plan'),1,111111)");
		jdbcTemplate
				.update("insert into map_reducers values (1,1,'192.168.1.6','127.0.0.1:65521','Working',1)");
		jdbcTemplate
				.update("insert into LAST_ASSIGNED_MR values (1,11111111111)");
		jdbcTemplate.update("commit");

		Map<Long, MuJobExecutePlan> map = null;
		try {
			inquiryDispatcher.dispatch(map);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof IllegalArgumentException);
			Assert.assertEquals(
					"Plans is empty while do inquiry dispatch operation.",
					e.getMessage());
		}

	}

	@Test
	public void testDispatchJobIdIsNull() {
		jdbcTemplate
				.update("insert into job_queue(JOB_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE,TIMEOUTS,FAILURE_COUNT,REMAIN_JOBS,FAMILY_ID)values(1,5,0,123,0,10,0,0,1)");
		jdbcTemplate
				.update("insert into fusion_jobs(FUSION_JOB_ID,FUNCTION_ID,JOB_ID,INQUIRY_JOB_DATA,SEARCH_REQUEST_INDEX)values(1,1,1,TO_BLOB('111'),1)");
		jdbcTemplate
				.update("insert into container_jobs(CONTAINER_JOB_ID,CONTAINER_ID,FUSION_JOB_ID)values(1,1,1)");
		jdbcTemplate
				.update("insert into mu_job_execute_plans(PLAN_ID,JOB_ID,FUNCTION_ID,CONTAINER_ID,PLAN,PLANED_COUNT,PLANED_TS)values(1,1,1,1,TO_CLOB('plan'),1,111111)");
		jdbcTemplate
				.update("insert into map_reducers values (1,1,'192.168.1.6','192.162.1.1','Working',1)");
		jdbcTemplate
				.update("insert into LAST_ASSIGNED_MR values (1,11111111111)");
		jdbcTemplate.update("commit");
		MuJobExecutePlan muJobExecutePlan = new MuJobExecutePlan();
		muJobExecutePlan.setContainerId(1);
		muJobExecutePlan.setPlanId(1l);
		muJobExecutePlan.setFunctionId(1);
		muJobExecutePlan.setPlan("plan");
		muJobExecutePlan.setPlanedCount(1);
		muJobExecutePlan.setPlanedTs(123);
		Map<Long, MuJobExecutePlan> map = Maps.newHashMap();
		map.put(1l, muJobExecutePlan);
		List<MuJobExecutePlan> muJobExecutePlans = Lists.newArrayList();
		muJobExecutePlans.add(muJobExecutePlan);
		try {
			inquiryDispatcher.dispatch(map);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof IllegalArgumentException);
			Assert.assertEquals(
					"Job id is not correct while do inquiry dispatch operation.",
					e.getMessage());
			return;
		}
		fail();

	}

	@Test
	public void testDispatchFunctionIdIsNull() {
		jdbcTemplate
				.update("insert into job_queue(JOB_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE,TIMEOUTS,FAILURE_COUNT,REMAIN_JOBS,FAMILY_ID)values(1,5,0,123,0,10,0,0,1)");
		jdbcTemplate
				.update("insert into fusion_jobs(FUSION_JOB_ID,FUNCTION_ID,JOB_ID,INQUIRY_JOB_DATA,SEARCH_REQUEST_INDEX)values(1,1,1,TO_BLOB('111'),1)");
		jdbcTemplate
				.update("insert into container_jobs(CONTAINER_JOB_ID,CONTAINER_ID,FUSION_JOB_ID)values(1,1,1)");
		jdbcTemplate
				.update("insert into mu_job_execute_plans(PLAN_ID,JOB_ID,FUNCTION_ID,CONTAINER_ID,PLAN,PLANED_COUNT,PLANED_TS)values(1,1,1,1,TO_CLOB('plan'),1,111111)");
		jdbcTemplate
				.update("insert into map_reducers values (1,1,'192.168.1.6','192.162.1.1','Working',1)");
		jdbcTemplate
				.update("insert into LAST_ASSIGNED_MR values (1,11111111111)");
		jdbcTemplate.update("commit");
		MuJobExecutePlan muJobExecutePlan = new MuJobExecutePlan();
		muJobExecutePlan.setContainerId(1);
		muJobExecutePlan.setJobId(1l);
		muJobExecutePlan.setPlan("plan");
		muJobExecutePlan.setPlanId(1l);
		muJobExecutePlan.setPlanedCount(1);
		muJobExecutePlan.setPlanedTs(123);
		Map<Long, MuJobExecutePlan> map = Maps.newHashMap();
		map.put(1l, muJobExecutePlan);
		List<MuJobExecutePlan> muJobExecutePlans = Lists.newArrayList();
		muJobExecutePlans.add(muJobExecutePlan);
		try {
			inquiryDispatcher.dispatch(map);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof IllegalArgumentException);
			Assert.assertEquals(
					"Function id is not correct while do inquiry dispatch operation.",
					e.getMessage());
			return;
		}
		fail();

	}

	@Test
	public void testDispatchContainerIdIsNull() {
		jdbcTemplate
				.update("insert into job_queue(JOB_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE,TIMEOUTS,FAILURE_COUNT,REMAIN_JOBS,FAMILY_ID)values(1,5,0,123,0,10,0,0,1)");
		jdbcTemplate
				.update("insert into fusion_jobs(FUSION_JOB_ID,FUNCTION_ID,JOB_ID,INQUIRY_JOB_DATA,SEARCH_REQUEST_INDEX)values(1,1,1,TO_BLOB('111'),1)");
		jdbcTemplate
				.update("insert into container_jobs(CONTAINER_JOB_ID,CONTAINER_ID,FUSION_JOB_ID)values(1,1,1)");
		jdbcTemplate
				.update("insert into mu_job_execute_plans(PLAN_ID,JOB_ID,FUNCTION_ID,CONTAINER_ID,PLAN,PLANED_COUNT,PLANED_TS)values(1,1,1,1,TO_CLOB('plan'),1,111111)");
		jdbcTemplate
				.update("insert into map_reducers values (1,1,'192.168.1.6','192.162.1.1','Working',1)");
		jdbcTemplate
				.update("insert into LAST_ASSIGNED_MR values (1,11111111111)");
		jdbcTemplate.update("commit");
		MuJobExecutePlan muJobExecutePlan = new MuJobExecutePlan();
		muJobExecutePlan.setFunctionId(1);
		muJobExecutePlan.setJobId(1l);
		muJobExecutePlan.setPlan("plan");
		muJobExecutePlan.setPlanId(1l);
		muJobExecutePlan.setPlanedCount(1);
		muJobExecutePlan.setPlanedTs(123);
		Map<Long, MuJobExecutePlan> map = Maps.newHashMap();
		map.put(1l, muJobExecutePlan);
		List<MuJobExecutePlan> muJobExecutePlans = Lists.newArrayList();
		muJobExecutePlans.add(muJobExecutePlan);
		try {
			inquiryDispatcher.dispatch(map);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof IllegalArgumentException);
			Assert.assertEquals(
					"Container id is not correct while do inquiry dispatch operation.",
					e.getMessage());
			return;
		}
		fail();

	}

	@Test
	public void testDispatchPlanIdIsNull() {
		jdbcTemplate
				.update("insert into job_queue(JOB_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE,TIMEOUTS,FAILURE_COUNT,REMAIN_JOBS,FAMILY_ID)values(1,5,0,123,0,10,0,0,1)");
		jdbcTemplate
				.update("insert into fusion_jobs(FUSION_JOB_ID,FUNCTION_ID,JOB_ID,INQUIRY_JOB_DATA,SEARCH_REQUEST_INDEX)values(1,1,1,TO_BLOB('111'),1)");
		jdbcTemplate
				.update("insert into container_jobs(CONTAINER_JOB_ID,CONTAINER_ID,FUSION_JOB_ID)values(1,1,1)");
		jdbcTemplate
				.update("insert into mu_job_execute_plans(PLAN_ID,JOB_ID,FUNCTION_ID,CONTAINER_ID,PLAN,PLANED_COUNT,PLANED_TS)values(1,1,1,1,TO_CLOB('plan'),1,111111)");
		jdbcTemplate
				.update("insert into map_reducers values (1,1,'192.168.1.6','192.162.1.1','Working',1)");
		jdbcTemplate
				.update("insert into LAST_ASSIGNED_MR values (1,11111111111)");
		jdbcTemplate.update("commit");
		MuJobExecutePlan muJobExecutePlan = new MuJobExecutePlan();
		muJobExecutePlan.setContainerId(1);
		muJobExecutePlan.setFunctionId(1);
		muJobExecutePlan.setJobId(1l);
		muJobExecutePlan.setPlan("plan");
		muJobExecutePlan.setPlanedCount(1);
		muJobExecutePlan.setPlanedTs(123);
		Map<Long, MuJobExecutePlan> map = Maps.newHashMap();
		map.put(1l, muJobExecutePlan);
		List<MuJobExecutePlan> muJobExecutePlans = Lists.newArrayList();
		muJobExecutePlans.add(muJobExecutePlan);
		try {
			inquiryDispatcher.dispatch(map);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof IllegalArgumentException);
			Assert.assertEquals(
					"Plan id is not correct while do inquiry dispatch operation.",
					e.getMessage());
			return;
		}
		fail();

	}

	@Test
	public void testDispatchPlanIdIsLessThanZero() {
		jdbcTemplate
				.update("insert into job_queue(JOB_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE,TIMEOUTS,FAILURE_COUNT,REMAIN_JOBS,FAMILY_ID)values(1,5,0,123,0,10,0,0,1)");
		jdbcTemplate
				.update("insert into fusion_jobs(FUSION_JOB_ID,FUNCTION_ID,JOB_ID,INQUIRY_JOB_DATA,SEARCH_REQUEST_INDEX)values(1,1,1,TO_BLOB('111'),1)");
		jdbcTemplate
				.update("insert into container_jobs(CONTAINER_JOB_ID,CONTAINER_ID,FUSION_JOB_ID)values(1,1,1)");
		jdbcTemplate
				.update("insert into mu_job_execute_plans(PLAN_ID,JOB_ID,FUNCTION_ID,CONTAINER_ID,PLAN,PLANED_COUNT,PLANED_TS)values(1,1,1,1,TO_CLOB('plan'),1,111111)");
		jdbcTemplate
				.update("insert into map_reducers values (1,1,'192.168.1.6','192.162.1.1','Working',1)");
		jdbcTemplate
				.update("insert into LAST_ASSIGNED_MR values (1,11111111111)");
		jdbcTemplate.update("commit");
		MuJobExecutePlan muJobExecutePlan = new MuJobExecutePlan();
		muJobExecutePlan.setContainerId(1);
		muJobExecutePlan.setFunctionId(1);
		muJobExecutePlan.setJobId(1l);
		muJobExecutePlan.setPlan("plan");
		muJobExecutePlan.setPlanedCount(1);
		muJobExecutePlan.setPlanedTs(123);
		muJobExecutePlan.setPlanId(-1l);
		List<MuJobExecutePlan> muJobExecutePlans = Lists.newArrayList();
		muJobExecutePlans.add(muJobExecutePlan);
		Map<Long, MuJobExecutePlan> map = Maps.newHashMap();
		map.put(-1l, muJobExecutePlan);

		try {
			inquiryDispatcher.dispatch(map);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof IllegalArgumentException);
			Assert.assertEquals(
					"Plan id is not correct while do inquiry dispatch operation.",
					e.getMessage());
			return;
		}
		fail();

	}

	@Test
	public void testDispatchContactUrlIsNull() {
		jdbcTemplate
				.update("insert into job_queue(JOB_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE,TIMEOUTS,FAILURE_COUNT,REMAIN_JOBS,FAMILY_ID)values(1,5,0,123,0,10,0,0,1)");
		jdbcTemplate
				.update("insert into fusion_jobs(FUSION_JOB_ID,FUNCTION_ID,JOB_ID,INQUIRY_JOB_DATA,SEARCH_REQUEST_INDEX)values(1,1,1,TO_BLOB('111'),1)");
		jdbcTemplate
				.update("insert into container_jobs(CONTAINER_JOB_ID,CONTAINER_ID,FUSION_JOB_ID)values(1,1,1)");
		jdbcTemplate
				.update("insert into mu_job_execute_plans(PLAN_ID,JOB_ID,FUNCTION_ID,CONTAINER_ID,PLAN,PLANED_COUNT,PLANED_TS)values(1,1,1,1,TO_CLOB('plan'),1,111111)");
		jdbcTemplate
				.update("insert into map_reducers (MR_ID,RING_LOCATION,UNIQUE_ID,STATE,VERSION)values (1,1,'192.168.1.6','Working',1)");
		jdbcTemplate
				.update("insert into LAST_ASSIGNED_MR values (1,11111111111)");
		jdbcTemplate.update("commit");
		MuJobExecutePlan muJobExecutePlan = new MuJobExecutePlan();
		muJobExecutePlan.setContainerId(1);
		muJobExecutePlan.setFunctionId(1);
		muJobExecutePlan.setJobId(1l);
		muJobExecutePlan.setPlan("plan");
		muJobExecutePlan.setPlanedCount(1);
		muJobExecutePlan.setPlanedTs(123);
		muJobExecutePlan.setPlanId(1l);
		List<MuJobExecutePlan> muJobExecutePlans = Lists.newArrayList();
		muJobExecutePlans.add(muJobExecutePlan);
		Map<Long, MuJobExecutePlan> map = Maps.newHashMap();
		map.put(1l, muJobExecutePlan);
		// try {
		inquiryDispatcher.dispatch(map);
		/*
		 * } catch (Exception e) { // TODO: handle exception Assert.assertTrue(e
		 * instanceof AimRuntimeException); AimRuntimeException exception =
		 * (AimRuntimeException)e; Assert.assertEquals(
		 * "Could not found the inquiry information with plan id:1",
		 * exception.getMessage()); Assert.assertEquals(
		 * "Could not found the inquiry information with plan id:1",
		 * e.getMessage()); return; } fail();
		 */

	}

	@Test
	public void testDispatchInfoIsNull() {
		jdbcTemplate
				.update("insert into job_queue(JOB_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE,TIMEOUTS,FAILURE_COUNT,REMAIN_JOBS,FAMILY_ID)values(1,5,0,123,0,10,0,0,1)");
		jdbcTemplate
				.update("insert into fusion_jobs(FUSION_JOB_ID,FUNCTION_ID,JOB_ID,INQUIRY_JOB_DATA,SEARCH_REQUEST_INDEX)values(1,1,1,TO_BLOB('111'),1)");
		jdbcTemplate
				.update("insert into container_jobs(CONTAINER_JOB_ID,CONTAINER_ID,FUSION_JOB_ID)values(1,1,1)");
		/*
		 * jdbcTemplate .update(
		 * "insert into mu_job_execute_plans(PLAN_ID,JOB_ID,FUNCTION_ID,CONTAINER_ID,PLAN,PLANED_COUNT,PLANED_TS)values(1,1,1,1,TO_CLOB('plan'),1,111111)"
		 * );
		 */
		jdbcTemplate
				.update("insert into map_reducers (MR_ID,RING_LOCATION,UNIQUE_ID,STATE,VERSION)values (1,1,'192.168.1.6','Working',1)");
		jdbcTemplate
				.update("insert into LAST_ASSIGNED_MR values (1,11111111111)");
		jdbcTemplate.update("commit");
		MuJobExecutePlan muJobExecutePlan = new MuJobExecutePlan();
		muJobExecutePlan.setContainerId(1);
		muJobExecutePlan.setFunctionId(1);
		muJobExecutePlan.setJobId(1l);
		muJobExecutePlan.setPlan("plan");
		muJobExecutePlan.setPlanedCount(1);
		muJobExecutePlan.setPlanedTs(123);
		muJobExecutePlan.setPlanId(1l);
		List<MuJobExecutePlan> muJobExecutePlans = Lists.newArrayList();
		muJobExecutePlans.add(muJobExecutePlan);
		Map<Long, MuJobExecutePlan> map = Maps.newHashMap();
		map.put(1l, muJobExecutePlan);
		try {
			inquiryDispatcher.dispatch(map);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof AimRuntimeException);
			AimRuntimeException exception = (AimRuntimeException) e;
			Assert.assertEquals(
					"Could not found the inquiry information with plan id:1",
					exception.getMessage());
			Assert.assertEquals(
					"Could not found the inquiry information with plan id:1",
					e.getMessage());
			return;
		}

	}

	@Test
	public void testDispatchInfoContactUrlIsNull() {
		jdbcTemplate
				.update("insert into job_queue(JOB_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE,TIMEOUTS,FAILURE_COUNT,REMAIN_JOBS,FAMILY_ID)values(1,5,0,123,0,10,0,0,1)");
		jdbcTemplate
				.update("insert into fusion_jobs(FUSION_JOB_ID,FUNCTION_ID,JOB_ID,INQUIRY_JOB_DATA,SEARCH_REQUEST_INDEX)values(1,1,1,TO_BLOB('111'),1)");
		jdbcTemplate
				.update("insert into container_jobs(CONTAINER_JOB_ID,CONTAINER_ID,FUSION_JOB_ID,PLAN_ID)values(1,1,1,1)");
		jdbcTemplate
				.update("insert into mu_job_execute_plans(PLAN_ID,JOB_ID,FUNCTION_ID,CONTAINER_ID,PLAN,PLANED_COUNT,PLANED_TS)values(1,1,1,1,TO_CLOB('plan'),1,111111)");
		jdbcTemplate
				.update("insert into map_reducers (MR_ID,RING_LOCATION,UNIQUE_ID,STATE,VERSION)values (1,1,'192.168.1.6','WORKING',1)");
		jdbcTemplate
				.update("insert into map_reducers (MR_ID,RING_LOCATION,UNIQUE_ID,STATE,VERSION)values (2,2,'192.168.1.6','WORKING',1)");
		jdbcTemplate
				.update("insert into LAST_ASSIGNED_MR values (1,11111111111)");
		jdbcTemplate.update("commit");
		MuJobExecutePlan muJobExecutePlan = new MuJobExecutePlan();
		muJobExecutePlan.setContainerId(1);
		muJobExecutePlan.setFunctionId(1);
		muJobExecutePlan.setJobId(1l);
		muJobExecutePlan.setPlan("plan");
		muJobExecutePlan.setPlanedCount(1);
		muJobExecutePlan.setPlanedTs(123);
		muJobExecutePlan.setPlanId(1l);
		List<MuJobExecutePlan> muJobExecutePlans = Lists.newArrayList();
		muJobExecutePlans.add(muJobExecutePlan);
		Map<Long, MuJobExecutePlan> map = Maps.newHashMap();
		map.put(1l, muJobExecutePlan);
		inquiryDispatcher.dispatch(map);
	}

	@Test
	public void testDispatchInfoContactUrlIsNull_retryCountThan11() {
		jdbcTemplate
				.update("insert into job_queue(JOB_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE,TIMEOUTS,FAILURE_COUNT,REMAIN_JOBS,FAMILY_ID)values(1,5,0,123,0,10,0,0,1)");
		jdbcTemplate
				.update("insert into fusion_jobs(FUSION_JOB_ID,FUNCTION_ID,JOB_ID,INQUIRY_JOB_DATA,SEARCH_REQUEST_INDEX)values(1,1,1,TO_BLOB('111'),1)");
		jdbcTemplate
				.update("insert into container_jobs(CONTAINER_JOB_ID,CONTAINER_ID,FUSION_JOB_ID)values(1,1,1)");
		jdbcTemplate
				.update("insert into mu_job_execute_plans(PLAN_ID,JOB_ID,FUNCTION_ID,CONTAINER_ID,PLAN,PLANED_COUNT,PLANED_TS)values(1,1,1,1,TO_CLOB('plan'),1,111111)");
		jdbcTemplate
				.update("insert into map_reducers (MR_ID,RING_LOCATION,UNIQUE_ID,STATE,VERSION)values (1,1,'192.168.1.6','WORKING',1)");
		jdbcTemplate
				.update("insert into map_reducers (MR_ID,RING_LOCATION,UNIQUE_ID,STATE,VERSION)values (2,2,'192.168.1.6','WORKING',1)");
		jdbcTemplate
				.update("insert into map_reducers (MR_ID,RING_LOCATION,UNIQUE_ID,STATE,VERSION)values (3,3,'192.168.1.6','WORKING',1)");
		jdbcTemplate
				.update("insert into map_reducers (MR_ID,RING_LOCATION,UNIQUE_ID,STATE,VERSION)values (4,4,'192.168.1.6','WORKING',1)");
		jdbcTemplate
				.update("insert into map_reducers (MR_ID,RING_LOCATION,UNIQUE_ID,STATE,VERSION)values (5,5,'192.168.1.6','WORKING',1)");
		jdbcTemplate
				.update("insert into map_reducers (MR_ID,RING_LOCATION,UNIQUE_ID,STATE,VERSION)values (6,6,'192.168.1.6','WORKING',1)");
		jdbcTemplate
				.update("insert into map_reducers (MR_ID,RING_LOCATION,UNIQUE_ID,STATE,VERSION)values (7,7,'192.168.1.6','WORKING',1)");
		jdbcTemplate
				.update("insert into map_reducers (MR_ID,RING_LOCATION,UNIQUE_ID,STATE,VERSION)values (8,8,'192.168.1.6','WORKING',1)");
		jdbcTemplate
				.update("insert into map_reducers (MR_ID,RING_LOCATION,UNIQUE_ID,STATE,VERSION)values (9,9,'192.168.1.6','WORKING',1)");
		jdbcTemplate
				.update("insert into map_reducers (MR_ID,RING_LOCATION,UNIQUE_ID,STATE,VERSION)values (10,10,'192.168.1.6','WORKING',1)");
		jdbcTemplate
				.update("insert into map_reducers (MR_ID,RING_LOCATION,UNIQUE_ID,STATE,VERSION)values (11,11,'192.168.1.6','WORKING',1)");
		jdbcTemplate
				.update("insert into map_reducers (MR_ID,RING_LOCATION,UNIQUE_ID,STATE,VERSION)values (12,12,'192.168.1.6','WORKING',1)");
		jdbcTemplate
				.update("insert into LAST_ASSIGNED_MR values (1,11111111111)");
		jdbcTemplate.update("commit");
		MuJobExecutePlan muJobExecutePlan = new MuJobExecutePlan();
		muJobExecutePlan.setContainerId(1);
		muJobExecutePlan.setFunctionId(1);
		muJobExecutePlan.setJobId(1l);
		muJobExecutePlan.setPlan("plan");
		muJobExecutePlan.setPlanedCount(1);
		muJobExecutePlan.setPlanedTs(123);
		muJobExecutePlan.setPlanId(1l);
		List<MuJobExecutePlan> muJobExecutePlans = Lists.newArrayList();
		muJobExecutePlans.add(muJobExecutePlan);
		Map<Long, MuJobExecutePlan> map = Maps.newHashMap();
		map.put(1l, muJobExecutePlan);
		// try {
		inquiryDispatcher.dispatch(map);
		/*
		 * } catch (Exception e) { // TODO: handle exception Assert.assertTrue(e
		 * instanceof AimRuntimeException); AimRuntimeException exception =
		 * (AimRuntimeException) e; Assert.assertEquals(
		 * "Could not found the inquiry information with plan id:1",
		 * exception.getMessage()); Assert.assertEquals(
		 * "Could not found the inquiry information with plan id:1",
		 * e.getMessage()); return; } fail();
		 */

	}

	@Test
	public void testDispatchInqDispatchInfoIsNull() {
		jdbcTemplate
				.update("insert into job_queue(JOB_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE,TIMEOUTS,FAILURE_COUNT,REMAIN_JOBS,FAMILY_ID)values(1,5,0,123,0,10,0,0,1)");
		jdbcTemplate
				.update("insert into fusion_jobs(FUSION_JOB_ID,FUNCTION_ID,JOB_ID,INQUIRY_JOB_DATA,SEARCH_REQUEST_INDEX)values(1,1,1,TO_BLOB('111'),1)");
		jdbcTemplate
				.update("insert into container_jobs(CONTAINER_JOB_ID,CONTAINER_ID,FUSION_JOB_ID)values(1,1,1)");
		jdbcTemplate
				.update("insert into mu_job_execute_plans(PLAN_ID,JOB_ID,FUNCTION_ID,CONTAINER_ID,PLAN,PLANED_COUNT,PLANED_TS)values(2,1,1,1,TO_CLOB('plan'),1,111111)");
		jdbcTemplate
				.update("insert into map_reducers values (1,1,'192.168.1.6','192.162.1.1','Working',1)");
		jdbcTemplate
				.update("insert into LAST_ASSIGNED_MR values (1,11111111111)");
		MuJobExecutePlan muJobExecutePlan = new MuJobExecutePlan();
		muJobExecutePlan.setPlanId(1l);
		muJobExecutePlan.setContainerId(1);
		muJobExecutePlan.setFunctionId(1);
		muJobExecutePlan.setJobId(1l);
		muJobExecutePlan.setPlan("plan");
		muJobExecutePlan.setPlanedCount(1);
		muJobExecutePlan.setPlanedTs(123);
		List<MuJobExecutePlan> muJobExecutePlans = Lists.newArrayList();
		muJobExecutePlans.add(muJobExecutePlan);
		Map<Long, MuJobExecutePlan> map = Maps.newConcurrentMap();
		map.put(1l, muJobExecutePlan);
		map.put(2l, muJobExecutePlan);

		inquiryDispatcher.dispatch(map);
		InquiryJobDao inquiryJobDao = new InquiryJobDao(entityManager,
				dataSource);
		ContainerJobEntity containerJob = inquiryJobDao.getContainerJob(1);
		Assert.assertEquals(JobState.QUEUED, containerJob.getJobState());

	}

	@Test
	public void testDispatchContainerJobIsNull()
			throws InvalidProtocolBufferException {
		jdbcTemplate
				.update("insert into job_queue(JOB_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE,TIMEOUTS,FAILURE_COUNT,REMAIN_JOBS,FAMILY_ID)values(1,5,0,123,0,10,0,0,1)");
		jdbcTemplate
				.update("insert into fusion_jobs(FUSION_JOB_ID,FUNCTION_ID,JOB_ID,INQUIRY_JOB_DATA,SEARCH_REQUEST_INDEX)values(1,1,1,TO_BLOB('111'),1)");
		jdbcTemplate
				.update("insert into container_jobs(CONTAINER_JOB_ID,CONTAINER_ID,FUSION_JOB_ID)values(1,1,1)");
		jdbcTemplate
				.update("insert into mu_job_execute_plans(PLAN_ID,JOB_ID,FUNCTION_ID,CONTAINER_ID,PLAN,PLANED_COUNT,PLANED_TS)values(1,1,1,1,TO_CLOB('plan'),1,111111)");
		jdbcTemplate
				.update("insert into map_reducers values (1,1,'http://127.0.0.1:65521/','http://127.0.0.1:65521/','WORKING',1)");
		jdbcTemplate
				.update("insert into map_reducers values (2,2,'http://127.0.0.1:65521/','http://127.0.0.1:65521/','WORKING',1)");
		jdbcTemplate
				.update("insert into LAST_ASSIGNED_MR values (1,11111111111)");
		jdbcTemplate.update("commit");
		MuJobExecutePlan muJobExecutePlan = new MuJobExecutePlan();
		muJobExecutePlan.setPlanId(1l);
		muJobExecutePlan.setContainerId(1);
		muJobExecutePlan.setFunctionId(1);
		muJobExecutePlan.setJobId(1l);
		muJobExecutePlan.setPlan("plan");
		muJobExecutePlan.setPlanedCount(1);
		muJobExecutePlan.setPlanedTs(123);
		List<MuJobExecutePlan> muJobExecutePlans = Lists.newArrayList();
		muJobExecutePlans.add(muJobExecutePlan);
		Map<Long, MuJobExecutePlan> map = Maps.newHashMap();
		map.put(1l, muJobExecutePlan);
		inquiryDispatcher.dispatch(map);
		InquiryJobDao inquiryJobDao = new InquiryJobDao(entityManager,
				dataSource);
		ContainerJobEntity containerJob = inquiryJobDao.getContainerJob(1);
		Assert.assertEquals(containerJob.getJobState(), JobState.QUEUED);

	}

	@Test
	public void testDispatchMrIsNullRemainJobsIsZero() {
		jdbcTemplate
				.update("insert into job_queue(JOB_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE,TIMEOUTS,FAILURE_COUNT,REMAIN_JOBS,FAMILY_ID)values(1,5,0,123,0,10,0,0,1)");
		jdbcTemplate
				.update("insert into fusion_jobs(FUSION_JOB_ID,FUNCTION_ID,JOB_ID,INQUIRY_JOB_DATA,SEARCH_REQUEST_INDEX)values(1,1,1,TO_BLOB('111'),1)");
		/*
		 * jdbcTemplate .update(
		 * "insert into map_reducers values (1,1,'http://127.0.0.1:65521/','http://127.0.0.1:65521/','WORKING',1)"
		 * ); jdbcTemplate .update(
		 * "insert into map_reducers values (2,2,'http://127.0.0.1:65521/','http://127.0.0.1:65521/','WORKING',1)"
		 * );
		 */
		jdbcTemplate
				.update("insert into container_jobs(CONTAINER_JOB_ID,CONTAINER_ID,FUSION_JOB_ID,PLAN_ID)values(1,1,1,1)");
		jdbcTemplate
				.update("insert into mu_job_execute_plans(PLAN_ID,JOB_ID,FUNCTION_ID,CONTAINER_ID,PLAN,PLANED_COUNT,PLANED_TS)values(1,1,1,1,TO_CLOB('plan'),1,111111)");

		jdbcTemplate
				.update("insert into LAST_ASSIGNED_MR values (1,11111111111)");
		jdbcTemplate.update("commit");
		MuJobExecutePlan muJobExecutePlan = new MuJobExecutePlan();
		muJobExecutePlan.setContainerId(1);
		muJobExecutePlan.setFunctionId(1);
		muJobExecutePlan.setJobId(1l);
		muJobExecutePlan.setPlan("plan");
		muJobExecutePlan.setPlanedCount(1);
		muJobExecutePlan.setPlanedTs(123);
		muJobExecutePlan.setPlanId(1l);
		List<MuJobExecutePlan> muJobExecutePlans = Lists.newArrayList();
		muJobExecutePlans.add(muJobExecutePlan);
		Map<Long, MuJobExecutePlan> map = Maps.newHashMap();
		map.put(1l, muJobExecutePlan);
		inquiryDispatcher.dispatch(map);
		jdbcTemplate.update("commit");
		List<Map<String, Object>> listMr = jdbcTemplate
				.queryForList("select * from LAST_ASSIGNED_MR");
		Assert.assertEquals(1, listMr.size());
		Assert.assertEquals(
				1,
				Integer.parseInt(listMr.get(0).get("ASSIGNED_LOCATION")
						.toString()));

	}

	@Test
	public void testDispatchMrIsNull() {
		jdbcTemplate
				.update("insert into job_queue(JOB_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE,TIMEOUTS,FAILURE_COUNT,REMAIN_JOBS,FAMILY_ID)values(1,5,1,123,0,10,0,1,1)");
		jdbcTemplate
				.update("insert into fusion_jobs(FUSION_JOB_ID,FUNCTION_ID,JOB_ID,INQUIRY_JOB_DATA,SEARCH_REQUEST_INDEX)values(1,1,1,TO_BLOB('111'),1)");
		/*
		 * jdbcTemplate .update(
		 * "insert into map_reducers values (1,1,'http://127.0.0.1:65521/','http://127.0.0.1:65521/','WORKING',1)"
		 * ); jdbcTemplate .update(
		 * "insert into map_reducers values (2,2,'http://127.0.0.1:65521/','http://127.0.0.1:65521/','WORKING',1)"
		 * );
		 */
		jdbcTemplate
				.update("insert into container_jobs(CONTAINER_JOB_ID,CONTAINER_ID,FUSION_JOB_ID,PLAN_ID)values(1,1,1,1)");
		jdbcTemplate
				.update("insert into mu_job_execute_plans(PLAN_ID,JOB_ID,FUNCTION_ID,CONTAINER_ID,PLAN,PLANED_COUNT,PLANED_TS)values(1,1,1,1,TO_CLOB('plan'),1,111111)");

		jdbcTemplate
				.update("insert into LAST_ASSIGNED_MR values (1,11111111111)");
		jdbcTemplate.update("commit");
		MuJobExecutePlan muJobExecutePlan = new MuJobExecutePlan();
		muJobExecutePlan.setContainerId(1);
		muJobExecutePlan.setFunctionId(1);
		muJobExecutePlan.setJobId(1l);
		muJobExecutePlan.setPlan("plan");
		muJobExecutePlan.setPlanedCount(1);
		muJobExecutePlan.setPlanedTs(123);
		muJobExecutePlan.setPlanId(1l);
		List<MuJobExecutePlan> muJobExecutePlans = Lists.newArrayList();
		muJobExecutePlans.add(muJobExecutePlan);
		Map<Long, MuJobExecutePlan> map = Maps.newHashMap();
		map.put(1l, muJobExecutePlan);
		inquiryDispatcher.dispatch(map);
		jdbcTemplate.update("commit");
		List<Map<String, Object>> listCj = jdbcTemplate
				.queryForList("select * from container_jobs");
		Assert.assertEquals(1, listCj.size());
		Map<String, Object> mapCj = listCj.get(0);
		Assert.assertEquals(null, mapCj.get("MR_ID"));
		Assert.assertEquals(0,
				Integer.parseInt(mapCj.get("JOB_STATE").toString()));
		List<Map<String, Object>> listJq = jdbcTemplate
				.queryForList("select * from job_queue");
		Assert.assertEquals(1, listJq.size());
		Map<String, Object> mapJq = listJq.get(0);
		Assert.assertEquals(1,
				Integer.parseInt(mapJq.get("FAILURE_COUNT").toString()));
		Assert.assertEquals(0,
				Integer.parseInt(mapJq.get("JOB_STATE").toString()));
	}

	@Test
	public void testDispatchMrIsNullFailureCountBiggerThanMax() {
		jdbcTemplate
				.update("insert into job_queue(JOB_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE,TIMEOUTS,FAILURE_COUNT,REMAIN_JOBS,FAMILY_ID)values(1,5,1,123,0,10,2,1,1)");
		jdbcTemplate
				.update("insert into fusion_jobs(FUSION_JOB_ID,FUNCTION_ID,JOB_ID,INQUIRY_JOB_DATA,SEARCH_REQUEST_INDEX)values(1,1,1,TO_BLOB('111'),1)");

		/*
		 * jdbcTemplate .update(
		 * "insert into map_reducers values (1,1,'http://127.0.0.1:65521/','http://127.0.0.1:65521/','WORKING',1)"
		 * ); jdbcTemplate .update(
		 * "insert into map_reducers values (2,2,'http://127.0.0.1:65521/','http://127.0.0.1:65521/','WORKING',1)"
		 * );
		 */

		jdbcTemplate
				.update("insert into container_jobs(CONTAINER_JOB_ID,CONTAINER_ID,FUSION_JOB_ID,PLAN_ID)values(1,1,1,1)");
		jdbcTemplate
				.update("insert into mu_job_execute_plans(PLAN_ID,JOB_ID,FUNCTION_ID,CONTAINER_ID,PLAN,PLANED_COUNT,PLANED_TS)values(1,1,1,1,TO_CLOB('plan'),1,111111)");

		jdbcTemplate
				.update("insert into LAST_ASSIGNED_MR values (1,11111111111)");
		jdbcTemplate.update("commit");

		MuJobExecutePlan muJobExecutePlan = new MuJobExecutePlan();
		muJobExecutePlan.setContainerId(1);
		muJobExecutePlan.setFunctionId(1);
		muJobExecutePlan.setJobId(1l);
		muJobExecutePlan.setPlan("plan");
		muJobExecutePlan.setPlanedCount(1);
		muJobExecutePlan.setPlanedTs(123);
		muJobExecutePlan.setPlanId(1l);
		List<MuJobExecutePlan> muJobExecutePlans = Lists.newArrayList();
		muJobExecutePlans.add(muJobExecutePlan);
		Map<Long, MuJobExecutePlan> map = Maps.newHashMap();
		map.put(1l, muJobExecutePlan);
		inquiryDispatcher.dispatch(map);
		jdbcTemplate.update("commit");
		List<Map<String, Object>> listCj = jdbcTemplate
				.queryForList("select * from container_jobs");
		Assert.assertEquals(1, listCj.size());
		Map<String, Object> mapCj = listCj.get(0);
		Assert.assertEquals(null, mapCj.get("MR_ID"));
		Assert.assertEquals(2,
				Integer.parseInt(mapCj.get("JOB_STATE").toString()));
		List<Map<String, Object>> listJq = jdbcTemplate
				.queryForList("select * from job_queue");
		Assert.assertEquals(1, listJq.size());
		Map<String, Object> mapJq = listJq.get(0);
		Assert.assertEquals(3,
				Integer.parseInt(mapJq.get("FAILURE_COUNT").toString()));
		Assert.assertEquals(2,
				Integer.parseInt(mapJq.get("JOB_STATE").toString()));
	}

	@Test
	public void testDispatch() {
		jdbcTemplate
				.update("insert into match_units(MU_ID,UNIQUE_ID,STATE,Contact_Url)values(1,2,'WORKING','192.168.1.1')");
		jdbcTemplate
				.update("insert into job_queue(JOB_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE,TIMEOUTS,FAILURE_COUNT,REMAIN_JOBS,FAMILY_ID)values(1,5,0,123,0,10,0,0,1)");
		jdbcTemplate
				.update("insert into fusion_jobs(FUSION_JOB_ID,FUNCTION_ID,JOB_ID,INQUIRY_JOB_DATA,SEARCH_REQUEST_INDEX)values(1,1,1,TO_BLOB('111'),1)");
		jdbcTemplate
				.update("insert into map_reducers values (1,1,'http://127.0.0.1:65521/','http://127.0.0.1:65521/','WORKING',1)");
		jdbcTemplate
				.update("insert into map_reducers values (2,2,'http://127.0.0.1:65521/','http://127.0.0.1:65521/','WORKING',1)");
		jdbcTemplate
				.update("insert into container_jobs(CONTAINER_JOB_ID,CONTAINER_ID,FUSION_JOB_ID,PLAN_ID)values(1,1,1,1)");
		jdbcTemplate
				.update("insert into mu_job_execute_plans(PLAN_ID,JOB_ID,FUNCTION_ID,CONTAINER_ID,PLAN,PLANED_COUNT,PLANED_TS)values(1,1,1,1,TO_CLOB('1,1:1,2:1'),1,111111)");

		jdbcTemplate
				.update("insert into LAST_ASSIGNED_MR values (1,11111111111)");
		jdbcTemplate.update("commit");

		MuJobExecutePlan muJobExecutePlan = new MuJobExecutePlan();
		muJobExecutePlan.setContainerId(1);
		muJobExecutePlan.setFunctionId(1);
		muJobExecutePlan.setJobId(1l);
		muJobExecutePlan.setPlan("1,1:1");
		muJobExecutePlan.setPlanedCount(1);
		muJobExecutePlan.setPlanedTs(123);
		muJobExecutePlan.setPlanId(1l);
		List<MuJobExecutePlan> muJobExecutePlans = Lists.newArrayList();
		muJobExecutePlans.add(muJobExecutePlan);
		Map<Long, MuJobExecutePlan> map = Maps.newHashMap();
		map.put(1l, muJobExecutePlan);
		inquiryDispatcher.dispatch(map);
		jdbcTemplate.update("commit");
		List<Map<String, Object>> listMr = jdbcTemplate
				.queryForList("select * from LAST_ASSIGNED_MR");
		Assert.assertEquals(1, listMr.size());
		Assert.assertEquals(
				2,
				Integer.parseInt(listMr.get(0).get("ASSIGNED_LOCATION")
						.toString()));
		List<Map<String, Object>> listConJobs = jdbcTemplate
				.queryForList("select * from container_jobs");
		Assert.assertEquals(1, listConJobs.size());
		Assert.assertEquals(2,
				Integer.parseInt(listConJobs.get(0).get("MR_ID").toString()));
	}

	@Test
	public void testDispatchTwoPlan() {
		jdbcTemplate
				.update("insert into match_units(MU_ID,UNIQUE_ID,STATE,Contact_Url)values(1,2,'WORKING','192.168.1.1')");
		jdbcTemplate
				.update("insert into job_queue(JOB_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE,TIMEOUTS,FAILURE_COUNT,REMAIN_JOBS,FAMILY_ID)values(1,5,0,123,0,10,0,0,1)");
		jdbcTemplate
				.update("insert into fusion_jobs(FUSION_JOB_ID,FUNCTION_ID,JOB_ID,INQUIRY_JOB_DATA,SEARCH_REQUEST_INDEX)values(1,1,1,TO_BLOB('111'),1)");
		jdbcTemplate
				.update("insert into map_reducers values (1,1,'http://127.0.0.1:65521/','http://127.0.0.1:65521/','WORKING',1)");
		jdbcTemplate
				.update("insert into map_reducers values (2,2,'http://127.0.0.1:65521/','http://127.0.0.1:65521/','WORKING',1)");
		jdbcTemplate
				.update("insert into container_jobs(CONTAINER_JOB_ID,CONTAINER_ID,FUSION_JOB_ID,PLAN_ID)values(1,1,1,1)");
		jdbcTemplate
				.update("insert into container_jobs(CONTAINER_JOB_ID,CONTAINER_ID,FUSION_JOB_ID,PLAN_ID)values(2,1,1,2)");
		jdbcTemplate
				.update("insert into mu_job_execute_plans(PLAN_ID,JOB_ID,FUNCTION_ID,CONTAINER_ID,PLAN,PLANED_COUNT,PLANED_TS)values(1,1,1,1,TO_CLOB('1,1:1,2:1'),1,111111)");

		jdbcTemplate
				.update("insert into LAST_ASSIGNED_MR values (1,11111111111)");
		jdbcTemplate.update("commit");

		MuJobExecutePlan muJobExecutePlan = new MuJobExecutePlan();
		muJobExecutePlan.setContainerId(1);
		muJobExecutePlan.setFunctionId(1);
		muJobExecutePlan.setJobId(1l);
		muJobExecutePlan.setPlan("1,1:1");
		muJobExecutePlan.setPlanedCount(1);
		muJobExecutePlan.setPlanedTs(123);
		muJobExecutePlan.setPlanId(1l);
		MuJobExecutePlan muJobExecutePlan1 = new MuJobExecutePlan();
		muJobExecutePlan1.setContainerId(1);
		muJobExecutePlan1.setFunctionId(1);
		muJobExecutePlan1.setJobId(1l);
		muJobExecutePlan1.setPlan("1,1:1");
		muJobExecutePlan1.setPlanedCount(1);
		muJobExecutePlan1.setPlanedTs(123);
		muJobExecutePlan1.setPlanId(2l);
		List<MuJobExecutePlan> muJobExecutePlans = Lists.newArrayList();
		muJobExecutePlans.add(muJobExecutePlan);
		Map<Long, MuJobExecutePlan> map = Maps.newHashMap();
		map.put(1l, muJobExecutePlan);
		map.put(2l, muJobExecutePlan1);
		inquiryDispatcher.dispatch(map);
		jdbcTemplate.update("commit");
		List<Map<String, Object>> listMr = jdbcTemplate
				.queryForList("select * from LAST_ASSIGNED_MR");
		Assert.assertEquals(1, listMr.size());
		Assert.assertEquals(
				1,
				Integer.parseInt(listMr.get(0).get("ASSIGNED_LOCATION")
						.toString()));
		List<Map<String, Object>> listConJobs = jdbcTemplate
				.queryForList("select * from container_jobs");
		Assert.assertEquals(2, listConJobs.size());
		List<Integer> list = Lists.newArrayList();
		list.add(1);
		list.add(2);
		Assert.assertFalse(listConJobs.get(0).get("MR_ID")
				.equals(listConJobs.get(1).get("MR_ID")));
		Assert.assertTrue(list.contains(Integer.parseInt(listConJobs.get(0)
				.get("MR_ID").toString())));
		Assert.assertTrue(list.contains(Integer.parseInt(listConJobs.get(1)
				.get("MR_ID").toString())));
	}

	@Ignore
	@Test
	public void testDispatchTwoPlanNoLastMr_ExistWorkingMU() {
		jdbcTemplate
				.update("insert into match_units(MU_ID,UNIQUE_ID,STATE,Contact_Url)values(1,2,'WORKING','192.168.1.1')");
		jdbcTemplate
				.update("insert into job_queue(JOB_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE,TIMEOUTS,FAILURE_COUNT,REMAIN_JOBS,FAMILY_ID)values(1,5,0,123,0,10,0,0,1)");
		jdbcTemplate
				.update("insert into fusion_jobs(FUSION_JOB_ID,FUNCTION_ID,JOB_ID,INQUIRY_JOB_DATA,SEARCH_REQUEST_INDEX)values(1,1,1,TO_BLOB('111'),1)");

		jdbcTemplate
				.update("insert into container_jobs(CONTAINER_JOB_ID,CONTAINER_ID,FUSION_JOB_ID)values(1,1,1)");
		jdbcTemplate
				.update("insert into mu_job_execute_plans(PLAN_ID,JOB_ID,FUNCTION_ID,CONTAINER_ID,PLAN,PLANED_COUNT,PLANED_TS)values(1,1,1,1,TO_CLOB('1,1:1,2:1'),1,111111)");
		jdbcTemplate
				.update("insert into map_reducers (MR_ID,RING_LOCATION,UNIQUE_ID,STATE,VERSION)values (1,1,'http://127.0.0.1:65521/','WORKING',1)");
		jdbcTemplate
				.update("insert into map_reducers (MR_ID,RING_LOCATION,UNIQUE_ID,STATE,VERSION)values (2,2,'http://127.0.0.1:65521/','WORKING',1)");
		jdbcTemplate
				.update("insert into LAST_ASSIGNED_MR values (1,11111111111)");
		jdbcTemplate.update("commit");

		MuJobExecutePlan muJobExecutePlan = new MuJobExecutePlan();
		muJobExecutePlan.setContainerId(1);
		muJobExecutePlan.setFunctionId(1);
		muJobExecutePlan.setJobId(1l);
		muJobExecutePlan.setPlan("1,1:1");
		muJobExecutePlan.setPlanedCount(1);
		muJobExecutePlan.setPlanedTs(123);
		muJobExecutePlan.setPlanId(1l);
		MuJobExecutePlan muJobExecutePlan1 = new MuJobExecutePlan();
		muJobExecutePlan1.setContainerId(1);
		muJobExecutePlan1.setFunctionId(1);
		muJobExecutePlan1.setJobId(1l);
		muJobExecutePlan1.setPlan("1,1:1");
		muJobExecutePlan1.setPlanedCount(1);
		muJobExecutePlan1.setPlanedTs(123);
		muJobExecutePlan1.setPlanId(2l);
		List<MuJobExecutePlan> muJobExecutePlans = Lists.newArrayList();
		muJobExecutePlans.add(muJobExecutePlan);
		Map<Long, MuJobExecutePlan> map = Maps.newHashMap();
		map.put(1l, muJobExecutePlan);
		map.put(2l, muJobExecutePlan1);
		inquiryDispatcher.dispatch(map);
		jdbcTemplate.update("commit");
		List<Map<String, Object>> listMr = jdbcTemplate
				.queryForList("select * from LAST_ASSIGNED_MR");
		Assert.assertEquals(1, listMr.size());
		Assert.assertEquals(
				1,
				Integer.parseInt(listMr.get(0).get("ASSIGNED_LOCATION")
						.toString()));
		List<Map<String, Object>> listConJobs = jdbcTemplate
				.queryForList("select * from container_jobs");
		Assert.assertEquals(1, listConJobs.size());
		Assert.assertEquals(1,
				Integer.parseInt(listConJobs.get(0).get("MR_ID").toString()));
	}

	@Test
	public void testDispatchTwoPlanNoLastMr() {
		jdbcTemplate
				.update("insert into job_queue(JOB_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE,TIMEOUTS,FAILURE_COUNT,REMAIN_JOBS,FAMILY_ID)values(1,5,0,123,0,10,0,0,1)");
		jdbcTemplate
				.update("insert into fusion_jobs(FUSION_JOB_ID,FUNCTION_ID,JOB_ID,INQUIRY_JOB_DATA,SEARCH_REQUEST_INDEX)values(1,1,1,TO_BLOB('111'),1)");

		jdbcTemplate
				.update("insert into container_jobs(CONTAINER_JOB_ID,CONTAINER_ID,FUSION_JOB_ID)values(1,1,1)");
		jdbcTemplate
				.update("insert into mu_job_execute_plans(PLAN_ID,JOB_ID,FUNCTION_ID,CONTAINER_ID,PLAN,PLANED_COUNT,PLANED_TS)values(1,1,1,1,TO_CLOB('1,1:1,2:1'),1,111111)");
		jdbcTemplate
				.update("insert into map_reducers (MR_ID,RING_LOCATION,UNIQUE_ID,STATE,VERSION)values (1,1,'http://127.0.0.1:65521/','WORKING',1)");
		jdbcTemplate
				.update("insert into map_reducers (MR_ID,RING_LOCATION,UNIQUE_ID,STATE,VERSION)values (2,2,'http://127.0.0.1:65521/','WORKING',1)");
		jdbcTemplate
				.update("insert into LAST_ASSIGNED_MR values (1,11111111111)");
		jdbcTemplate.update("commit");

		MuJobExecutePlan muJobExecutePlan = new MuJobExecutePlan();
		muJobExecutePlan.setContainerId(1);
		muJobExecutePlan.setFunctionId(1);
		muJobExecutePlan.setJobId(1l);
		muJobExecutePlan.setPlan("1,1:1");
		muJobExecutePlan.setPlanedCount(1);
		muJobExecutePlan.setPlanedTs(123);
		muJobExecutePlan.setPlanId(1l);
		MuJobExecutePlan muJobExecutePlan1 = new MuJobExecutePlan();
		muJobExecutePlan1.setContainerId(1);
		muJobExecutePlan1.setFunctionId(1);
		muJobExecutePlan1.setJobId(1l);
		muJobExecutePlan1.setPlan("1,1:1");
		muJobExecutePlan1.setPlanedCount(1);
		muJobExecutePlan1.setPlanedTs(123);
		muJobExecutePlan1.setPlanId(2l);
		List<MuJobExecutePlan> muJobExecutePlans = Lists.newArrayList();
		muJobExecutePlans.add(muJobExecutePlan);
		Map<Long, MuJobExecutePlan> map = Maps.newHashMap();
		map.put(1l, muJobExecutePlan);
		map.put(2l, muJobExecutePlan1);
		inquiryDispatcher.dispatch(map);
		jdbcTemplate.update("commit");
		List<Map<String, Object>> listMr = jdbcTemplate
				.queryForList("select * from LAST_ASSIGNED_MR");
		Assert.assertEquals(1, listMr.size());
		Assert.assertEquals(
				1,
				Integer.parseInt(listMr.get(0).get("ASSIGNED_LOCATION")
						.toString()));
		List<Map<String, Object>> listConJobs = jdbcTemplate
				.queryForList("select * from container_jobs");
		Assert.assertEquals(1, listConJobs.size());
		InquiryJobDao inquiryJobDao = new InquiryJobDao(entityManager,
				dataSource);
		ContainerJobEntity containerJob = inquiryJobDao.getContainerJob(1);
		Assert.assertEquals(containerJob.getJobState(), JobState.QUEUED);
	}
	
	@Test
	public void testMakeDeadJobInfo() throws NoSuchMethodException,
			SecurityException, IllegalAccessException,
			IllegalArgumentException, InvocationTargetException {
		int size = 5;
		List<ContainerJobEntity> jobList = new ArrayList<>();
		for (int i = 0; i < size; i++) {
			ContainerJobEntity oneJob = new ContainerJobEntity();
			oneJob.setMrId(Long.valueOf(i * 1000 + i));
			oneJob.setAssignedTs(Long.valueOf(System.currentTimeMillis()));
			oneJob.setPlanId(Long.valueOf(i * 2000 + i));
			oneJob.setContainerId(i * 3000 + i);
			oneJob.setFusionJobId(Long.valueOf(i * 4000 + i));
			oneJob.setJobState(JobState.WORKING);
			jobList.add(oneJob);			
		}		
		
		Method method = InquiryDispatcher.class.getDeclaredMethod(
				"makeDeadJobInfo", long.class, java.util.List.class);

		method.setAccessible(true);
		String results = (String) method.invoke(inquiryDispatcher, 1000, jobList);		
		Assert.assertNotNull(results);		
		System.out.println();	
		System.out.println(results);
		
	}

}
