//package jp.co.nec.aim.mm.procedure;
//
//import static org.junit.Assert.assertEquals;
//import static org.junit.Assert.assertNotNull;
//
//import javax.annotation.Resource;
//import javax.persistence.EntityManager;
//import javax.persistence.PersistenceContext;
//import javax.sql.DataSource;
//import javax.transaction.Transactional;
//
//import jp.co.nec.aim.mm.common.JdbcTemplateHelper;
//import jp.co.nec.aim.mm.constants.JobState;
//import jp.co.nec.aim.mm.dao.InquiryJobDao;
//import jp.co.nec.aim.mm.entities.ContainerJobEntity;
//import jp.co.nec.aim.mm.entities.JobQueueEntity;
//
//import org.junit.After;
//import org.junit.Before;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.springframework.jdbc.core.JdbcTemplate;
//import org.springframework.test.context.ContextConfiguration;
//import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
//
//@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration(locations = { "/applicationContext.xml" })
//@Transactional
//public class CorrectInquiryJobProcedureTest {
//	@Resource
//	private DataSource ds;
//
//	@PersistenceContext(unitName = "aim-db")
//	private EntityManager entityManager;
//
//	private InquiryJobDao inquiryjobdao;
//
//	@Resource
//	private JdbcTemplate jdbcTemplate;
//
//	private CorrectInquiryJobProcedure inquiryjobprocedure;
//	JdbcTemplateHelper helper = new JdbcTemplateHelper();
//
//	@Before
//	public void setUp() throws Exception {
//		inquiryjobprocedure = new CorrectInquiryJobProcedure(ds);
//		inquiryjobdao = new InquiryJobDao(entityManager);
//		helper.deleteInquiryJob(jdbcTemplate);
//		helper.scene01(jdbcTemplate);
//	}
//
//	@After
//	public void tearDown() throws Exception {
//		helper.deleteInquiryJob(jdbcTemplate);
//	}
//
//	@Test
//	public void testAction_jobId1000() {
//		byte[] result = "101101010".getBytes();
//		long remain_job = inquiryjobprocedure.action(1000, 0, 10741, result);
//		assertEquals(-1, remain_job);// NO_DATA_FOUND
//	}
//
//	@Test
//	public void testAction_jobId1001() {
//		byte[] result = "101101010".getBytes();
//		long remain_job = inquiryjobprocedure.action(1001, 0, 1, result);
//		assertEquals(-3, remain_job);// Update excute failure
//	}
//
//	@Test
//	public void testAction_jobId1002() {
//		byte[] result = "101101010".getBytes();
//		long remain_job = inquiryjobprocedure.action(1002, 5, 10741, result);
//		assertEquals(-2, remain_job);// sequence is not the same as failcount
//	}
//
//	@Test
//	public void testAction_jobId1003() {
//		byte[] result = "101101010".getBytes();
//		long remain_job = inquiryjobprocedure.action(1003, 0, 10741, result);
//		ContainerJobEntity containerJob = inquiryjobdao.getContainerJob(10741);
//		assertEquals(9, remain_job);
//		assertEquals(2, containerJob.getContainerId());
//		byte[] containerjobresult = containerJob.getContainerJobResult();
//		assertEquals(result.length, containerjobresult.length);
//		for (int index = 0; index < result.length; index++) {
//			assertEquals(result[index], containerjobresult[index]);
//		}
//		assertEquals(JobState.DONE, containerJob.getJobState());
//		assertNotNull(containerJob.getResultTs());
//
//		JobQueueEntity jobqueue = inquiryjobdao.getTopLevelJob(1003);
//		assertEquals(9, jobqueue.getRemainJobs());
//	}
//}
