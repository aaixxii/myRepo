package jp.co.nec.aim.mm.dao;

import javax.sql.DataSource;

import jp.co.nec.aim.mm.procedure.IncreaseRUCProcedure;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * @author mozj
 * 
 */
public class RUCDao {

	/** log instance **/
	private static final Logger log = LoggerFactory.getLogger(RUCDao.class);
	private DataSource dataSource;

	/**
	 * 
	 * @param dataSource
	 */
	public RUCDao(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	/**
	 * increaseRUC
	 */
	public void increaseRUC() {
		log.info("Ready to increase RUC.");
		IncreaseRUCProcedure procedure = new IncreaseRUCProcedure(dataSource);
		procedure.execute();
	}

}
