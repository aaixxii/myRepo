package jp.co.nec.aim.mm.logger;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * LRUMessageCashe is same as ch.qos.logback.classic.turbo.LRUMessageCashe
 * 
 * @author kurosu
 * 
 */
public class LRUMessageCache extends LinkedHashMap<String, Integer> {

	// LinkedHashMap permits null elements to be inserted

	private static final long serialVersionUID = 1L;

	private final int cacheSize;

	public LRUMessageCache(int cacheSize) {
		super((int) (cacheSize * (4.0f / 3)), 0.75f, true);
		if (cacheSize < 1) {
			throw new IllegalArgumentException(
					"Cache size cannnot be smaller than 1");
		}
		this.cacheSize = cacheSize;
	}

	public int getMessageCountAndThenIncrement(String msg) {
		// don't insert null elements
		if (msg == null) {
			return 0;
		}

		Integer i = super.get(msg);
		if (i == null) {
			i = 0;
		} else {
			i = new Integer(i.intValue() + 1);
		}
		super.put(msg, i);
		return i;
	}

	@SuppressWarnings("rawtypes")
	protected boolean removeEldestEntry(Map.Entry eldest) {
		return (cacheSize < size());
	}
}
