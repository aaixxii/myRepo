package jp.co.nec.aim.mm.acceptor.script;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = { "registrationScript", "searchScript",
		"deletionScript" })
@XmlRootElement(name = "aim-script")
public class AimScript {
	@XmlElement(name = "registration-script")
	protected RegistrationScript registrationScript;
	@XmlElement(name = "search-script")
	protected SearchScript searchScript;
	@XmlElement(name = "deletion-script")
	protected DeletionScript deletionScript;

	/**
	 * Gets the value of the searchScript property.
	 * 
	 * @return possible object is {@link SearchScript }
	 * 
	 */
	public SearchScript getSearchScript() {
		return searchScript;
	}

	/**
	 * Sets the value of the searchScript property.
	 * 
	 * @param value
	 *            allowed object is {@link SearchScript }
	 * 
	 */
	public void setSearchScript(SearchScript value) {
		this.searchScript = value;
	}

	/**
	 * Gets the value of the registrationScript property.
	 * 
	 * @return possible object is {@link RegistrationScript }
	 * 
	 */
	public RegistrationScript getRegistrationScript() {
		return registrationScript;
	}

	/**
	 * Sets the value of the registrationScript property.
	 * 
	 * @param value
	 *            allowed object is {@link RegistrationScript }
	 * 
	 */
	public void setRegistrationScript(RegistrationScript value) {
		this.registrationScript = value;
	}

	/**
	 * Gets the value of the deletionScript property.
	 * 
	 * @return possible object is {@link DeletionScript }
	 * 
	 */
	public DeletionScript getDeletionScript() {
		return deletionScript;
	}

	/**
	 * Sets the value of the deletionScript property.
	 * 
	 * @param value
	 *            allowed object is {@link DeletionScript }
	 * 
	 */
	public void setDeletionScript(DeletionScript value) {
		this.deletionScript = value;
	}

	/**
	 * <p>
	 * Java class for anonymous complex type.
	 * 
	 * <p>
	 * The following schema fragment specifies the expected content contained
	 * within this class.
	 * 
	 * <pre>
	 * &lt;complexType>
	 *   &lt;complexContent>
	 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
	 *       &lt;sequence>
	 *         &lt;element name="script-item" type="{urn:nec:aim}deletion-script-item"/>
	 *       &lt;/sequence>
	 *     &lt;/restriction>
	 *   &lt;/complexContent>
	 * &lt;/complexType>
	 * </pre>
	 * 
	 * 
	 */
	@XmlAccessorType(XmlAccessType.FIELD)
	@XmlType(name = "", propOrder = { "scriptItem" })
	@XmlRootElement(name = "deletion-script")
	public static class DeletionScript {

		@XmlElement(name = "script-item", required = true)
		protected List<DeletionScriptItem> scriptItem;

		/**
		 * getScriptItem
		 * 
		 * @return List<DeletionScriptItem>
		 */
		public List<DeletionScriptItem> getScriptItem() {
			if (scriptItem == null) {
				scriptItem = new ArrayList<DeletionScriptItem>();
			}
			return this.scriptItem;
		}

	}

	/**
	 * <p>
	 * Java class for anonymous complex type.
	 * 
	 * <p>
	 * The following schema fragment specifies the expected content contained
	 * within this class.
	 * 
	 * <pre>
	 * &lt;complexType>
	 *   &lt;complexContent>
	 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
	 *       &lt;sequence>
	 *         &lt;element name="script-item" type="{urn:nec:aim}registration-script-item" maxOccurs="unbounded"/>
	 *       &lt;/sequence>
	 *     &lt;/restriction>
	 *   &lt;/complexContent>
	 * &lt;/complexType>
	 * </pre>
	 * 
	 * 
	 */
	@XmlAccessorType(XmlAccessType.FIELD)
	@XmlType(name = "", propOrder = { "scriptItem" })
	@XmlRootElement(name = "registration-script")
	public static class RegistrationScript {

		@XmlElement(name = "script-item", required = true)
		protected List<RegistrationScriptItem> scriptItem;

		/**
		 * Gets the value of the scriptItem property.
		 * 
		 * <p>
		 * This accessor method returns a reference to the live list, not a
		 * snapshot. Therefore any modification you make to the returned list
		 * will be present inside the JAXB object. This is why there is not a
		 * <CODE>set</CODE> method for the scriptItem property.
		 * 
		 * <p>
		 * For example, to add a new item, do as follows:
		 * 
		 * <pre>
		 * getScriptItem().add(newItem);
		 * </pre>
		 * 
		 * 
		 * <p>
		 * Objects of the following type(s) are allowed in the list
		 * {@link RegistrationScriptItema }
		 * 
		 * 
		 */
		public List<RegistrationScriptItem> getScriptItem() {
			if (scriptItem == null) {
				scriptItem = new ArrayList<RegistrationScriptItem>();
			}
			return this.scriptItem;
		}
	}

	/**
	 * <p>
	 * Java class for anonymous complex type.
	 * 
	 * <p>
	 * The following schema fragment specifies the expected content contained
	 * within this class.
	 * 
	 * <pre>
	 * &lt;complexType>
	 *   &lt;complexContent>
	 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
	 *       &lt;sequence>
	 *         &lt;element name="script-item" type="{urn:nec:aim}search-script-item" maxOccurs="unbounded"/>
	 *       &lt;/sequence>
	 *     &lt;/restriction>
	 *   &lt;/complexContent>
	 * &lt;/complexType>
	 * </pre>
	 * 
	 * 
	 */
	@XmlAccessorType(XmlAccessType.FIELD)
	@XmlType(name = "", propOrder = { "scriptItem" })
	@XmlRootElement(name = "search-script")
	public static class SearchScript {

		@XmlElement(name = "script-item", required = true)
		protected List<SearchScriptItem> scriptItem;

		/**
		 * Gets the value of the scriptItem property.
		 * 
		 * <p>
		 * This accessor method returns a reference to the live list, not a
		 * snapshot. Therefore any modification you make to the returned list
		 * will be present inside the JAXB object. This is why there is not a
		 * <CODE>set</CODE> method for the scriptItem property.
		 * 
		 * <p>
		 * For example, to add a new item, do as follows:
		 * 
		 * <pre>
		 * getScriptItem().add(newItem);
		 * </pre>
		 * 
		 * 
		 * <p>
		 * Objects of the following type(s) are allowed in the list
		 * {@link SearchScriptItem }
		 * 
		 * 
		 */
		public List<SearchScriptItem> getScriptItem() {
			if (scriptItem == null) {
				scriptItem = new ArrayList<SearchScriptItem>();
			}
			return this.scriptItem;
		}

	}

}
