package jp.co.nec.aim.mm.jms;

public enum ReceiverEnum {
	AsynchQueue("AsynchQueueReceiver"), //
	FEJobPlan("FEJobPlanReceiver"), //
	InquiryJobPlan("InquiryJobPlanReceiver"), //
	FEJobDistributor("FeDistributorReceiver"), //
	InquiryJobDistributor("InquiryJDistributorReceiver"), //
	LoadBalance("SlbEventReceiver"), //
	;

	private String receiverName;

	private ReceiverEnum(String receiverName) {
		this.receiverName = receiverName;
	}

	public String getReceiverName() {
		return receiverName;
	}
}
