package com.nec.lmx.test;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Set;



public class SocketServer  {
	
	private ServerSocketChannel serverSocketChannel = null;
	private Selector selector;	
	private ByteBuffer lmxBuffer = ByteBuffer.allocate(1024);

	public static void main(String[] args) {
		SocketServer server = new SocketServer();
		server.init();
		try {
			server.service();
		} catch (IOException e) {			
			e.printStackTrace();
		}

	}
	
	private void init() {
		int port = 8888;
		int serverSocketTimeout = 6000;			
		try {
			 InetAddress hostIP = InetAddress.getLocalHost();
		      InetSocketAddress myAddress =
		          new InetSocketAddress(hostIP, port);
		     InetSocketAddress address = new InetSocketAddress(hostIP, port);
			selector = Selector.open();
			serverSocketChannel = ServerSocketChannel.open();
			serverSocketChannel.socket().setReuseAddress(true);
			serverSocketChannel.socket().setSoTimeout(serverSocketTimeout);
			serverSocketChannel.configureBlocking(false);
			
			serverSocketChannel.socket().bind(address);
			serverSocketChannel.register(selector, SelectionKey.OP_ACCEPT);
		} catch (IOException e) {
			String errmsg = "Can't starting MMR socket server!";
			System.out.println(errmsg);
		}
		System.out.println("MMR Socket Server is startedl");
	}
	
	public void service() throws IOException {		
		while (selector.select() > 0) {
			Set<SelectionKey> readyKeys = selector.selectedKeys();
			Iterator<SelectionKey> it = readyKeys.iterator();
			while (it.hasNext()) {
				SelectionKey key = (SelectionKey) it.next();				
				it.remove();
				if (!key.isValid()) {
					continue;
				}
				 if (key.isAcceptable()) {
					 SocketChannel socketChannel = serverSocketChannel.accept();
					socketChannel.configureBlocking(false);					 
				        InetAddress remoteAddr = socketChannel.socket().getInetAddress(); 
				        System.out.println("Connected to: " + remoteAddr);
				        read(socketChannel);
					
				 }
			} // #while
		} // #while
	}  

	private void read(SocketChannel socketChannel) {        
        lmxBuffer.clear();
        lmxBuffer.order(ByteOrder.BIG_ENDIAN);  
        	  try {        		  
        		  socketChannel.read(lmxBuffer);
				//lmxBuffer.flip();
				byte[] byteArr = new byte[1024];
				lmxBuffer.get(byteArr);
				String received = new String(byteArr, "UTF-8").trim();
				System.out.println(received);	
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}      
       
    }


}
