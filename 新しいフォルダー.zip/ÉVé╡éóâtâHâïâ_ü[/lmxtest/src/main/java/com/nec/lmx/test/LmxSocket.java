package com.nec.lmx.test;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.SocketChannel;

public class LmxSocket {
	private SocketChannel socketChannel;
	private Object channelLocker;

	private static final LmxSocket lmxSocket = new LmxSocket();

	public static LmxSocket getInstance() {
		return lmxSocket;
	}

	public LmxSocket() {
		this.channelLocker = new Object();
	}

	public void init(int port) {
		try {			
			  InetAddress hostIP = InetAddress.getLocalHost();
		      InetSocketAddress myAddress =
		          new InetSocketAddress(hostIP, port);
			socketChannel = SocketChannel.open(myAddress);
			socketChannel.configureBlocking(false);
			socketChannel.socket().setKeepAlive(true);
			System.out.println("Connecting to Server on port:" + port);

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void sendLinceseInfo(String licenseInfo) {
		int any = 0;
		try {
			byte[] bodys = licenseInfo.getBytes("UTF-8");			
			ByteBuffer sendBuff = ByteBuffer.allocate(1024);
			sendBuff.order(ByteOrder.BIG_ENDIAN);
			sendBuff.put(bodys);
			sendBuff.flip();
			try {
				while (sendBuff.hasRemaining()) {
					any = socketChannel.write(sendBuff);
					System.out.println("Send as : " + any);
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			System.out.println("Success send data to server.");

			try {
				Thread.sleep(1 * 60 * 60 * 1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
