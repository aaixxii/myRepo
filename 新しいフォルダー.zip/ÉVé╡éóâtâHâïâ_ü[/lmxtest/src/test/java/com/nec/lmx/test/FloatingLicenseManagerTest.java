package com.nec.lmx.test;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.Type;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

public class FloatingLicenseManagerTest {
	private final ConcurrentHashMap<String, String> licenseMap = new ConcurrentHashMap<>();

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testSendLicenseInfo() {
		licenseMap.put("AFIS", "TYPE=FULL;COMPONENT=VM;MODALTY=FINGER,FACE,PALM,IRIS");
		licenseMap.put("EXPIRED", "false");
		licenseMap.put("DIFFERENT", "false");
		Gson gson = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();	

		Type mapType = new TypeToken<Map<String, String>>() {}.getType();		
		String licesneInfo = gson.toJson(licenseMap, mapType);
		try {
			byte[] mybytes = licesneInfo.getBytes("UTF-8");
			String newString = new String(mybytes);
			System.out.println(licesneInfo);
			System.out.println(newString);
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}

	@Test
	public void testCheckEndDate() {
		
	}

}
