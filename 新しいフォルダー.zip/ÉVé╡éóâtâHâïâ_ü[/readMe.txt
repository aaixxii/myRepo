﻿****************************************************************
                       -- Instructions --                       
****************************************************************

1.Installation LinuxOS（RedHat5.5 and more）

2.Installation java jdk (jdk 1.6_29) and tomcat(7.0.42)

3.Create a new user for SM:
       groupadd sm
       useradd -g sm -d /home/smuser smuser
       passwd smuser

4. Compile the SM source using maven command:
       mvn clean package -PTokyo
       mvn -DskipTests=true clean package (if you want to skip the test)

5. After execute the maven package command,
   find the war package named [systemmanager.war] in the target path.

6. Copy the [systemmanager.war] to Tomcat Webapp folder and deploy.

7. OverWrite [SystemManager/tomcat/*] to Tomcat.

8. Modify the configuration files if necessary in directory 
      tomcat/conf/smConf/

   the following counfigurations must be modified based on your environment:
      jdbc.properties          modify the jdbc configurations
      MM.properties            modify the MM.IP_ADDRESS and MM.WEB_PORT_NUM
      queues.xml               modify the queue-hostname and queue-port
      SM.properties            modify the SM.IP_ADDRESS and SM.WEB_PORT_NUM

9. Run and Stop Service
    run command:
        ./runSM.sh

    stop command:
        ./stopSM.sh

End
