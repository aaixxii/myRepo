package com.nec.aim.uid.client;

import java.util.UUID;

import org.junit.Test;

import junit.framework.TestCase;

/**
 * Unit test for simple App.
 */
public class AppTest 
    extends TestCase
{
    /**
     * Create the test case
     *
     * @param testName name of the test case
     */
  @Test
    public void testApp()  {   
    	UUID uuid = UUID.randomUUID();
        String str = uuid.toString();      
        System.out.println(str.getBytes().length);
   
    
    }
	
    public static String getUUID32(){
		return UUID.randomUUID().toString().replace("-", "").toLowerCase();
	}
	public static String[] getUUID(int num){
		
		if( num <= 0)
			return null;
		
		String[] uuidArr = new String[num];
		
		for (int i = 0; i < uuidArr.length; i++) {
			uuidArr[i] = getUUID32();
		}
		
		return uuidArr;
	}
  
	@Test
	public void testPath() {
		String id = UUID.randomUUID().toString().toUpperCase();
		
		System.out.print("size:" + id);
		
	}
}
