package jp.co.nec.aim.mm.partition;

import java.util.concurrent.atomic.AtomicInteger;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.aim.mm.constants.JNDIConstants;
import jp.co.nec.aim.mm.dao.PartitionDao;
import jp.co.nec.aim.mm.util.JndiLookup;

public class PartitionService {    
    private static Logger logger = LoggerFactory.getLogger(PartitionService.class);  
    private  AtomicInteger prePno = new AtomicInteger(7);
    private DataSource dataSource;
    private PartitionDao partitionDao;
    
    public PartitionService(DataSource dataSource) {
        this.dataSource = dataSource;
        partitionDao = new PartitionDao(dataSource);
    }
    
    public void init() {
        dataSource = JndiLookup.lookUp(JNDIConstants.DataSourceName,DataSource.class);
        
    }
    
    public static void  initPartition() {      
        
    }
    
    public void updatePartitionCount(Integer newNo) {
        if (newNo.intValue() - prePno.get() > 0) {
            doAddPartitionNo(newNo.intValue());
        } else {
            doReducePartitionNo(newNo);
        }
        
    }
    
    private void doAddPartitionNo(int newNo) {
        int diff = newNo - prePno.get();
        long firstAddEpoch = System.currentTimeMillis() + diff * 24 * 60 *60 * 1000;
        long x = firstAddEpoch % prePno.get();
        long y = firstAddEpoch % newNo;
        long adjust = (x - y + newNo) % newNo;       
        int j = 0;
        for (int i = prePno.get() + 1; i <= newNo; i++) {
            long tmpEpoch = System.currentTimeMillis() + (diff + j) * 24 * 60 *60 * 1000;
            long newHashValue = caculateNewHashValue(i, tmpEpoch, adjust);
            partitionDao.createPartition(newHashValue);
            j++;
        }
        prePno = new AtomicInteger(newNo);
    }
    
    private void doReducePartitionNo(int newNo) {
        int diff = prePno.get() - newNo;
        long firstAddEpoch = System.currentTimeMillis() + diff * 24 * 60 *60 * 1000;
        long x = firstAddEpoch % prePno.get();
        long y = firstAddEpoch % newNo;
        long adjust = (x - y + newNo) % newNo;       
        int j = 0;
        for (int i = newNo + 1; i <= prePno.get(); i--) {
            long tmpEpoch = System.currentTimeMillis() + (diff - j) * 24 * 60 *60 * 1000;
            long newHashValue = caculateNewHashValue(i, tmpEpoch, adjust);
            partitionDao.deletePartition(newHashValue);
            j++;
        }
        prePno = new AtomicInteger(newNo);
        
    }
    
    private long caculateNewHashValue(int newNo, long epoch, long adjust) {  
        long newHashValue = (epoch + adjust) % newNo;
        return newHashValue;
        
    }
    
   
    
    
}
