package jp.co.nec.aim.sm.common.httpclient;
import static org.junit.Assert.assertEquals;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import  org.apache.commons.io.IOUtils;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mortbay.jetty.Handler;
import org.mortbay.jetty.HttpConnection;
import org.mortbay.jetty.Request;
import org.mortbay.jetty.handler.AbstractHandler;

import com.google.protobuf.InvalidProtocolBufferException;

import jp.co.nec.aim.message.proto.AIMMessages.PBEnterResponse;
import jp.co.nec.aim.sm.test.common.util.HttpTestServer;

public class CommonPostTest {

	private static HttpTestServer _server;
	private static CommonPost _commonPost;
	private String postUrl;
	private String excutingMethod;
	static int eventcase = 0;

	public static Handler getMockHandler() {
		Handler handler = new AbstractHandler() {
			
			public void handle(String target, HttpServletRequest request,
					HttpServletResponse response, int dispatch)
					throws IOException, ServletException {
				Request baseRequest = request instanceof Request ? (Request) request
						: HttpConnection.getCurrentConnection().getRequest();
				switch (eventcase) {
				case 0:
					response.setStatus(200);
					PBEnterResponse.Builder b = PBEnterResponse.newBuilder();

					b.setId(30);

					// String xmlContext = SMUtil
					// .convertJavaBeanToXml(enterResponse);
					// write(xmlContext, response.getOutputStream());
					b.build().writeTo(response.getOutputStream());
					break;
				case 1:
					response.setStatus(500);
					String data = "<html><head><title>JBoss Web/3.0.0-CR2 - Error report</title></head></html>";
					//Writer writer = new OutputStreamWriter(response.getOutputStream());	
					IOUtils.write(data,response.getOutputStream(), "UTF-8");

					//IOUtils.write(data,writer);
							
					response.setContentType("text/html;charset=utf-8");
					response.setCharacterEncoding("UTF-8");
				}

				baseRequest.setHandled(true);
			}

		};
		return handler;
	}

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		_server = new HttpTestServer(65513);
		_server.start(getMockHandler());
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		if (_server != null) {
			_server.stop();
		}
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
		eventcase = 0;
	}

	@Test
	public void testPostContext_Normal() throws InvalidProtocolBufferException {
		eventcase = 0;
		postUrl = "http://127.0.0.1:65513/test";

		_commonPost = new CommonPost(postUrl, new byte[] { 1, 2 },
				excutingMethod);
		HttpResponseInfo info = _commonPost.postContext();
		PBEnterResponse response = PBEnterResponse.parseFrom(info.getBytes());
		assertEquals(30, response.getId());
	}

	@Test
	public void testPostContext_status500() {
		eventcase = 1;
		postUrl = "http://127.0.0.1:65513/test";

		excutingMethod = "sendEnter";
		_commonPost = new CommonPost(postUrl, new byte[] { 1, 2 },
				excutingMethod);
		HttpResponseInfo info = _commonPost.postContext();

		assertEquals(info.getStatusCode(), 500);
	}

}
