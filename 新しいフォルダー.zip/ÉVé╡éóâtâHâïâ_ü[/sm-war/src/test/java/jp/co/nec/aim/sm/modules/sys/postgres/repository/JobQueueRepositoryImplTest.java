package jp.co.nec.aim.sm.modules.sys.postgres.repository;

import static org.junit.Assert.assertEquals;

import java.util.List;

import javax.sql.DataSource;

import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.modules.sys.postgres.entity.JobQueueEntity;
import jp.co.nec.aim.sm.modules.sys.postgres.pojo.mapping.JobAMRPojo;
import jp.co.nec.aim.sm.modules.sys.postgres.pojo.mapping.JobElapsePojo;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional(value = "postgresTXManager")
public class JobQueueRepositoryImplTest {
	@Autowired
	JobQueueRepository repository;

	@Autowired
	@Qualifier("postgresDataSource")
	DataSource datasource;

	JdbcTemplate jdbcTemplate;

	String fName[] = new String[] { "LI", "LLI", "TI", "TLI" };

	@Before
	public void before() {
		jdbcTemplate = new JdbcTemplate(datasource);

		cleanDB();
		prepareDB();
	}

	@After
	public void after() {
		cleanDB();
	}

	private void cleanDB() {
		jdbcTemplate.execute("delete from \"FUNCTION_TYPES\"");
		jdbcTemplate.execute("delete from \"JOB_QUEUE\"");
	}

	private void prepareDB() {
		for (int i = 0; i < 4; i++) {
			String functionSql = "insert into \"FUNCTION_TYPES\"("
					+ "\"FUNCTION_ID\", \"FUNCTION_NAME\") values(" + i + ", '"
					+ fName[i] + "')";

			jdbcTemplate.execute(functionSql);
			for (int j = 0; j < 4; j++) {
				String jobSql = "insert into \"JOB_QUEUE\"(\"JOB_QUEUE_ID\","
						+ " \"JOB_ID\", \"FUNCTION_ID\", \"PRIORITY\", \"STATE\","
						+ " \"MATCH_COUNT\", \"READ_COUNT\", \"SUBMISSION_TIME\","
						+ " \"RESULT_TIME\", \"JOB_COUNT\", \"MULTI_JOBS_HIT_COUNT\","
						+ " \"MULTI_JOBS_FAILED_COUNT\", \"ELAPSE_TIME_SUM\","
						+ " \"ELAPSE_TIME_MAX\", \"ELAPSE_TIME_MIN\") "
						+ " values("
						+ (i * 4 + j)
						+ ","
						+ (i * 4 + j)
						+ ","
						+ i
						+ ", 1, 2, "
						+ (i + 1)
						+ ","
						+ (i + 2)
						+ ", (timestamp '2013-07-13 10:10:11'),"
						+ " (timestamp '2013-07-13 12:10:11'), "
						+ (i + 1)
						+ "," + i + "," + i + "," + 2 + "," + 3 + "," + 1 + ")";

				jdbcTemplate.execute(jobSql);
			}
		}
	}

	@Test
	public void testGetJobAMR() {
		Page<JobAMRPojo> page = new Page<JobAMRPojo>(1, 10);
		List<JobAMRPojo> jobAMRList = repository.getJobAMR(page,
				new JobQueueEntity()).getList();

		assertEquals(4, jobAMRList.size());
		int assertCount = 0;
		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < fName.length; j++) {
				if (fName[j].equals(jobAMRList.get(i).getFunctionName())) {
					assertEquals((j + 1) * 4, jobAMRList.get(i)
							.getJobCountSum().intValue());
					assertEquals((j + 1) * 4, jobAMRList.get(i)
							.getMatchCountSum().intValue());
					assertEquals((j + 2) * 4, jobAMRList.get(i)
							.getReadCountSum().intValue());
					assertCount++;
				}
			}
		}
		assertEquals(4, assertCount);
	}

	@Test
	public void testGetJobAMR_2() {
		List<JobAMRPojo> jobAMRList = repository
				.getJobAMR(new JobQueueEntity());

		assertEquals(4, jobAMRList.size());
		int assertCount = 0;
		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < fName.length; j++) {
				if (fName[j].equals(jobAMRList.get(i).getFunctionName())) {
					assertEquals((j + 1) * 4, jobAMRList.get(i)
							.getJobCountSum().intValue());
					assertEquals((j + 1) * 4, jobAMRList.get(i)
							.getMatchCountSum().intValue());
					assertEquals((j + 2) * 4, jobAMRList.get(i)
							.getReadCountSum().intValue());
					assertCount++;
				}
			}
		}
		assertEquals(4, assertCount);
	}

	@Test
	public void testGetJobElapse() {
		Page<JobElapsePojo> page = new Page<JobElapsePojo>(1, 10);
		List<JobElapsePojo> jobElapseList = repository.getJobElapse(page,
				new JobQueueEntity()).getList();

		assertEquals(4, jobElapseList.size());
		int assertCount = 0;
		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < fName.length; j++) {
				if (fName[j].equals(jobElapseList.get(i).getFunctionName())) {
					assertEquals((j + 1) * 4, jobElapseList.get(i)
							.getJobCountSum().intValue());
					assertEquals("00:00:00.00" + (8 / ((j + 1) * 4)),
							jobElapseList.get(i).getElapseAvg());
					assertEquals("00:00:00.003", jobElapseList.get(i)
							.getElapseMax());
					assertEquals("00:00:00.001", jobElapseList.get(i)
							.getElapseMin());
					assertEquals(j * 4, jobElapseList.get(i).getHitCountSum()
							.intValue());
					assertEquals(j * 4, jobElapseList.get(i)
							.getFailedCountSum().intValue());
					assertCount++;
				}
			}
		}
		assertEquals(4, assertCount);
	}

	@Test
	public void testGetJobElapse_2() {
		List<JobElapsePojo> jobElapseList = repository
				.getJobElapse(new JobQueueEntity());

		assertEquals(4, jobElapseList.size());
		int assertCount = 0;
		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < fName.length; j++) {
				if (fName[j].equals(jobElapseList.get(i).getFunctionName())) {
					assertEquals((j + 1) * 4, jobElapseList.get(i)
							.getJobCountSum().intValue());
					assertEquals("00:00:00.00" + (8 / ((j + 1) * 4)),
							jobElapseList.get(i).getElapseAvg());
					assertEquals("00:00:00.003", jobElapseList.get(i)
							.getElapseMax());
					assertEquals("00:00:00.001", jobElapseList.get(i)
							.getElapseMin());
					assertEquals(j * 4, jobElapseList.get(i).getHitCountSum()
							.intValue());
					assertEquals(j * 4, jobElapseList.get(i)
							.getFailedCountSum().intValue());
					assertCount++;
				}
			}
		}
		assertEquals(4, assertCount);
	}
}
