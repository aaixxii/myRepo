package jp.co.nec.aim.sm.helper;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;

public class MmSqlScriptRunner {

	@Autowired
	@Qualifier("oracleDataSource")
	DataSource datasource;

	JdbcTemplate jdbcTemplate;
	private final static Logger log = LoggerFactory.getLogger(MmSqlScriptRunner.class);
	
	public static void doInsertContainersSql(JdbcTemplate jdbcTemplate) throws IOException{
		File sqlFile =  new File(MmSqlScriptRunner.class.getClassLoader().
		getResource("mm-seed/insert_containers.sql").getFile());
		doSqlFile(jdbcTemplate, sqlFile);
	}
	
	public static void doSqlFile(JdbcTemplate jdbcTemplate, File sqlFile) throws IOException{
		FileReader fileReader = new FileReader(sqlFile);
		BufferedReader br = new BufferedReader(fileReader);
		String line = br.readLine();
		while(line != null){
			if(!line.contains("prompt")){
				int index = line.lastIndexOf(";");
				jdbcTemplate.execute(line.substring(0, index));
			}
			line = br.readLine();
		}
	}
	
}
