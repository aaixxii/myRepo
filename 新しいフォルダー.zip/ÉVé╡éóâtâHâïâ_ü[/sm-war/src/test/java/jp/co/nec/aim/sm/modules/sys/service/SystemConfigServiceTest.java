package jp.co.nec.aim.sm.modules.sys.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.FormatTypeEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.FunctionTypeEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.MuEligibleContainerEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.MuEligibleContainerEntityPK;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.MuEligibleFunctionEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.MuEligibleFunctionEntityPK;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.SystemConfigEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.SystemInitEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.BiometricContainerPojo;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.EligibleBinsPojo;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.EligibleFunctionsPojo;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional(value = "oracleTXManager")
public class SystemConfigServiceTest {

	@Autowired
	SystemConfigService sysConfigService;

	@Autowired
	@Qualifier("oracleDataSource")
	DataSource datasource;

	JdbcTemplate jdbcTemplate;

	String[] formatName = new String[] { "RDBT", "RDBL", "LDB", "PBLNF" };
	String[] functionName = new String[] { "TI", "LI", "TLI", "LLI" };

	@Before
	public void before() {
		jdbcTemplate = new JdbcTemplate(datasource);
		cleanDB();
		prepareDB();
	}

	@After
	public void after() {
		cleanDB();
	}

	private void cleanDB() {
		jdbcTemplate.execute("delete from PERSON_BIOMETRICS");
		jdbcTemplate.execute("delete from MU_ELIGIBLE_CONTAINERS");
		jdbcTemplate.execute("delete from MU_ELIGIBLE_FUNCTIONS");
		jdbcTemplate.execute("delete from FE_JOB_QUEUE");
		jdbcTemplate.execute("delete from FE_LOT_JOBS");
		jdbcTemplate.execute("delete from JOB_QUEUE");
		jdbcTemplate.execute("delete from MATCH_UNITS");
		jdbcTemplate.execute("delete from SYSTEM_CONFIG");
		jdbcTemplate.execute("delete from SYSTEM_INIT");
		jdbcTemplate.execute("update CONTAINERS set MIN_REDUNDANCY = 1");
	}

	private void prepareDB() {
		for (int i = 1; i <= 4; i++) {
			String sql = "insert into MATCH_UNITS(MU_ID, UNIQUE_ID, STATE"
					+ ") values(" + i + ", 'unique_" + i + "', 'WORKING')";
			jdbcTemplate.execute(sql);
		}

		for (int i = 1; i <= 4; i++) {
			String sql = "insert into MU_ELIGIBLE_CONTAINERS(MU_ID, CONTAINER_ID"
					+ ") values(" + i + ", " + i + ")";
			jdbcTemplate.execute(sql);
		}

		for (int i = 1; i <= 4; i++) {
			String sql = "insert into MU_ELIGIBLE_FUNCTIONS(MU_ID, FUNCTION_ID"
					+ ") values(" + i + ", " + i + ")";
			jdbcTemplate.execute(sql);
		}

		for (int i = 1; i <= 4; i++) {
			String sql = "insert into SYSTEM_CONFIG(CONFIG_ID, PROPERTY_NAME,"
					+ " PROPERTY_VALUE) values(" + i + ", 'Key_" + i
					+ "', 'Value_" + i + "')";
			jdbcTemplate.execute(sql);
		}

		{
			String sql = "insert into SYSTEM_CONFIG(CONFIG_ID, PROPERTY_NAME,"
					+ " PROPERTY_VALUE) values(5, 'LOAD_BALANCER."
					+ "DEFAULT_MIN_REDUNDANCY', '2')";
			jdbcTemplate.execute(sql);
		}

		for (int i = 1; i <= 4; i++) {
			String sql = "insert into SYSTEM_INIT(INIT_ID, KEY_NAME,"
					+ " KEY_VALUE) values(" + i + ", 'Key_" + i + "', 'Value_"
					+ i + "')";
			jdbcTemplate.execute(sql);
		}
	}

	@Test
	public void testGetPageByClass_Bin() {
		Page<BiometricContainerPojo> page = new Page<BiometricContainerPojo>(1,
				10);
		BiometricContainerPojo entity = new BiometricContainerPojo();
		entity.setBinId(1l);
		entity.setFormat("RDBT");

		Page<BiometricContainerPojo> pageResult = sysConfigService
				.getPageByClass(page, entity, BiometricContainerPojo.class);

		assertEquals(1, pageResult.getList().size());
		assertEquals(1, pageResult.getList().get(0).getMinimumRedundancy()
				.intValue());
	}

	@Test
	public void testGetPageByClass_Bin_2() {
		Page<BiometricContainerPojo> page = new Page<BiometricContainerPojo>(1,
				10);
		BiometricContainerPojo entity = new BiometricContainerPojo();
		entity.setBinId(1l);
		entity.setFormat("RDBT");

		Page<BiometricContainerPojo> pageResult = sysConfigService
				.getPageByClass(page, entity, BiometricContainerPojo.class);

		assertEquals(1, pageResult.getList().size());
		assertEquals(1, pageResult.getList().get(0).getMinimumRedundancy()
				.intValue());
	}

	@Test
	public void testGetPageByClass_EligibleBin() {
		Page<MuEligibleContainerEntity> page = new Page<MuEligibleContainerEntity>(
				1, 10);
		MuEligibleContainerEntity entity = new MuEligibleContainerEntity();
		MuEligibleContainerEntityPK id = new MuEligibleContainerEntityPK();
		id.setContainerId(1l);
		id.setMuId(1l);
		entity.setId(id);

		Page<MuEligibleContainerEntity> pageResult = sysConfigService
				.getPageByClass(page, entity, MuEligibleContainerEntity.class);

		assertEquals(1, pageResult.getList().size());
	}

	@Test
	public void testGetPageByClass_EligibleBin_2() {
		Page<EligibleBinsPojo> page = new Page<EligibleBinsPojo>(1, 10);
		EligibleBinsPojo entity = new EligibleBinsPojo();
		entity.setBinId(1l);
		entity.setMatchUnitId(1l);

		Page<EligibleBinsPojo> pageResult = sysConfigService.getPageByClass(
				page, entity, EligibleBinsPojo.class);

		assertEquals(1, pageResult.getList().size());
	}

	@Test
	public void testGetPageByClass_EligibleFunction() {
		Page<MuEligibleFunctionEntity> page = new Page<MuEligibleFunctionEntity>(
				1, 10);
		MuEligibleFunctionEntity entity = new MuEligibleFunctionEntity();
		MuEligibleFunctionEntityPK id = new MuEligibleFunctionEntityPK();
		entity.setFunctionId(1);
		entity.setMuId(1l);

		id.setFunctionId(1);
		id.setMuId(1l);
		entity.setId(id);

		Page<MuEligibleFunctionEntity> pageResult = sysConfigService
				.getPageByClass(page, entity, MuEligibleFunctionEntity.class);

		assertEquals(1, pageResult.getList().size());
	}

	@Test
	public void testGetPageByClass_EligibleFunction_2() {
		String sql = "insert into MU_ELIGIBLE_FUNCTIONS(MU_ID, FUNCTION_ID"
				+ ") values(" + 1 + ", " + 2 + ")";
		jdbcTemplate.execute(sql);

		Page<EligibleFunctionsPojo> page = new Page<EligibleFunctionsPojo>(1,
				10);
		EligibleFunctionsPojo entity = new EligibleFunctionsPojo();
		entity.setMatchUnitId(1l);

		Page<EligibleFunctionsPojo> pageResult = sysConfigService
				.getPageByClass(page, entity, EligibleFunctionsPojo.class);

		assertEquals(1, pageResult.getList().size());
		assertEquals("TI,LI", pageResult.getList().get(0).getFunctions());
	}

	@Test
	public void testGetPageByClass_Function() {
		Page<FunctionTypeEntity> page = new Page<FunctionTypeEntity>(1, 10);
		FunctionTypeEntity entity = new FunctionTypeEntity();
		entity.setId(1);
		entity.setFunctionName(functionName[0]);

		Page<FunctionTypeEntity> pageResult = sysConfigService.getPageByClass(
				page, entity, FunctionTypeEntity.class);

		assertEquals(1, pageResult.getList().size());
	}

	@Test
	public void testGetPageByClass_SystemConfig() {
		Page<SystemConfigEntity> page = new Page<SystemConfigEntity>(1, 10);
		SystemConfigEntity systemConfig = new SystemConfigEntity();
		systemConfig.setConfigId(1);
		systemConfig.setPropertyName("Key_1");

		Page<SystemConfigEntity> pageResult = sysConfigService.getPageByClass(
				page, systemConfig, SystemConfigEntity.class);

		assertEquals(1, pageResult.getList().size());
		assertEquals("Value_1", pageResult.getList().get(0).getPropertyValue());
	}

	@Test
	public void testGetPageByClass_SystemInit() {
		Page<SystemInitEntity> page = new Page<SystemInitEntity>(1, 10);
		SystemInitEntity systemInit = new SystemInitEntity();
		systemInit.setInitId(1l);
		systemInit.setKeyName("Key_1");

		Page<SystemInitEntity> pageResult = sysConfigService.getPageByClass(
				page, systemInit, SystemInitEntity.class);

		assertEquals(1, pageResult.getList().size());
		assertEquals("Value_1", pageResult.getList().get(0).getKeyValue());
	}

	@Test
	public void testGetPageByClass_NOT() {
		Page<FormatTypeEntity> page = new Page<FormatTypeEntity>(1, 10);
		FormatTypeEntity entity = new FormatTypeEntity();

		Page<FormatTypeEntity> pageResult = sysConfigService.getPageByClass(
				page, entity, FormatTypeEntity.class);

		assertNull(pageResult);
	}

	@Test
	public void testGetListByClass_EligibleBin() {
		MuEligibleContainerEntity entity = new MuEligibleContainerEntity();
		MuEligibleContainerEntityPK id = new MuEligibleContainerEntityPK();
		id.setContainerId(1l);
		id.setMuId(1l);
		entity.setId(id);

		List<MuEligibleContainerEntity> listResult = sysConfigService
				.getListByClass(entity, MuEligibleContainerEntity.class);

		assertEquals(1, listResult.size());
	}

	@Test
	public void testGetListByClass_EligibleBin_2() {
		EligibleBinsPojo entity = new EligibleBinsPojo();
		entity.setBinId(1l);
		entity.setMatchUnitId(1l);

		List<EligibleBinsPojo> listResult = sysConfigService.getListByClass(
				entity, EligibleBinsPojo.class);

		assertEquals(1, listResult.size());
	}

	@Test
	public void testGetListByClass_EligibleFunction() {
		MuEligibleFunctionEntity entity = new MuEligibleFunctionEntity();
		MuEligibleFunctionEntityPK id = new MuEligibleFunctionEntityPK();

		entity.setFunctionId(1);
		entity.setMuId(1l);

		id.setFunctionId(1);
		id.setMuId(1l);
		entity.setId(id);

		List<MuEligibleFunctionEntity> listResult = sysConfigService
				.getListByClass(entity, MuEligibleFunctionEntity.class);

		assertEquals(1, listResult.size());
	}

	@Test
	public void testGetListByClass_EligibleFunction_2() {
		String sql = "insert into MU_ELIGIBLE_FUNCTIONS(MU_ID, FUNCTION_ID"
				+ ") values(" + 1 + ", " + 2 + ")";
		jdbcTemplate.execute(sql);

		EligibleFunctionsPojo entity = new EligibleFunctionsPojo();
		entity.setMatchUnitId(1l);

		List<EligibleFunctionsPojo> listResult = sysConfigService
				.getListByClass(entity, EligibleFunctionsPojo.class);

		assertEquals(1, listResult.size());
		assertEquals("TI,LI", listResult.get(0).getFunctions());
	}

	@Test
	public void testGetListByClass_Function() {
		FunctionTypeEntity entity = new FunctionTypeEntity();
		entity.setId(1);
		entity.setFunctionName(functionName[0]);

		List<FunctionTypeEntity> listResult = sysConfigService.getListByClass(
				entity, FunctionTypeEntity.class);

		assertEquals(1, listResult.size());
	}

	@Test
	public void testGetListByClass_SystemConfig() {
		SystemConfigEntity systemConfig = new SystemConfigEntity();
		systemConfig.setConfigId(1);
		systemConfig.setPropertyName("Key_1");

		List<SystemConfigEntity> listResult = sysConfigService.getListByClass(
				systemConfig, SystemConfigEntity.class);

		assertEquals(1, listResult.size());
		assertEquals("Value_1", listResult.get(0).getPropertyValue());
	}

	@Test
	public void testGetListByClass_SystemInit() {
		SystemInitEntity systemInit = new SystemInitEntity();
		systemInit.setInitId(1l);
		systemInit.setKeyName("Key_1");

		List<SystemInitEntity> listResult = sysConfigService.getListByClass(
				systemInit, SystemInitEntity.class);

		assertEquals(1, listResult.size());
		assertEquals("Value_1", listResult.get(0).getKeyValue());
	}

	@Test
	public void testGetListByClass_NOT() {

		FormatTypeEntity entity = new FormatTypeEntity();

		List<FormatTypeEntity> listResult = sysConfigService.getListByClass(
				entity, FormatTypeEntity.class);

		assertNull(listResult);
	}

	@Test
	public void testUpdateDBByClass_Bin() {
		int count = sysConfigService.updateDBByClass(
				BiometricContainerPojo.class, 1l, "RDBT", 3l, 1l, 1l);

		assertEquals(1, count);

		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from \"CONTAINERS\" where CONTAINER_ID = 1");
		assertEquals(1, list.size());
		assertEquals("1", list.get(0).get("CONTAINER_ID").toString());
		assertEquals("3", list.get(0).get("MIN_REDUNDANCY").toString());
	}

	@Test
	public void testUpdateDBByClass_SystemConfig() {
		int count = sysConfigService.updateDBByClass(SystemConfigEntity.class,
				1, null, "propertyValue");

		assertEquals(1, count);

		List<Map<String, Object>> sysConfigList = jdbcTemplate
				.queryForList("select * from SYSTEM_CONFIG where CONFIG_ID = 1");
		assertEquals(1, sysConfigList.size());
		assertEquals("1", sysConfigList.get(0).get("CONFIG_ID").toString());
		assertEquals("propertyValue", sysConfigList.get(0)
				.get("PROPERTY_VALUE"));
	}

	@Test
	public void testUpdateDBByClass_SystemInit() {
		int count = sysConfigService.updateDBByClass(SystemInitEntity.class,
				1l, "propertyValue");

		assertEquals(1, count);

		List<Map<String, Object>> sysInitList = jdbcTemplate
				.queryForList("select * from SYSTEM_INIT where INIT_ID = 1");
		assertEquals(1, sysInitList.size());
		assertEquals("1", sysInitList.get(0).get("INIT_ID").toString());
		assertEquals("propertyValue", sysInitList.get(0).get("KEY_VALUE"));
	}

	@Test
	public void testUpdateDBByClass_NOT() {
		int count = sysConfigService.updateDBByClass(FormatTypeEntity.class, 1);

		assertEquals(0, count);
	}

	@Test
	public void testGetAllFormatType() {
		List<String> list = sysConfigService.getAllFormatType();

		assertEquals(14, list.size());
	}

	@Test
	public void testGetAllFunctionType() {
		List<String> list = sysConfigService.getAllFunctionType();

		assertEquals(20, list.size());
	}

	@Test
	public void testGetAllBin() {

		List<Long> list = sysConfigService.getAllContainers();

		assertEquals(19, list.size());
	}

	@Test
	public void testExecuteAssignAction_EligibleBinAssign() {
		boolean result = sysConfigService.executeAssignAction(
				MuEligibleContainerEntity.class, "Assign", 1l, "2");

		assertTrue(result);

		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from MU_ELIGIBLE_CONTAINERS where MU_ID = 1");
		assertEquals(2, list.size());
	}

	@Test
	public void testExecuteAssignAction_EligibleBinUnAssign() {
		boolean result = sysConfigService.executeAssignAction(
				MuEligibleContainerEntity.class, "Unassign", 1l, "1");

		assertTrue(result);

		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from MU_ELIGIBLE_CONTAINERS where MU_ID = 1");
		assertEquals(0, list.size());
	}

	@Test
	public void testExecuteAssignAction_EligibleBin_NOT() {
		boolean result = sysConfigService.executeAssignAction(
				MuEligibleContainerEntity.class, "Una", 1l, "1");

		assertTrue(!result);
	}

	@Test
	public void testExecuteAssignAction_EligibleFunctionAssign() {
		boolean result = sysConfigService.executeAssignAction(
				MuEligibleFunctionEntity.class, "Assign", 1l, "LI");

		assertTrue(result);

		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from MU_ELIGIBLE_FUNCTIONS where MU_ID = 1");
		assertEquals(2, list.size());
	}

	@Test
	public void testExecuteAssignAction_EligibleFunctionAssign_All() {
		boolean result = sysConfigService.executeAssignAction(
				MuEligibleFunctionEntity.class, "Assign", 1l, "All");

		assertTrue(result);

		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from MU_ELIGIBLE_FUNCTIONS where MU_ID = 1");
		assertEquals(20, list.size());
	}

	@Test
	public void testExecuteAssignAction_EligibleFunctionUnAssign() {
		String sql = "insert into MU_ELIGIBLE_FUNCTIONS(MU_ID, FUNCTION_ID) values(1, 2)";
		jdbcTemplate.execute(sql);

		boolean result = sysConfigService.executeAssignAction(
				MuEligibleFunctionEntity.class, "Unassign", 1l, "TI");

		assertTrue(result);

		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from MU_ELIGIBLE_FUNCTIONS where MU_ID = 1");
		assertEquals(1, list.size());
		assertEquals("2", list.get(0).get("FUNCTION_ID").toString());
	}

	@Test
	public void testExecuteAssignAction_EligibleFunctionUnAssign_All() {
		String sql = "insert into MU_ELIGIBLE_FUNCTIONS(MU_ID, FUNCTION_ID) values(1, 2)";
		jdbcTemplate.execute(sql);

		boolean result = sysConfigService.executeAssignAction(
				MuEligibleFunctionEntity.class, "Unassign", 1l, "All");

		assertTrue(result);

		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from MU_ELIGIBLE_FUNCTIONS where MU_ID = 1");
		assertEquals(0, list.size());
	}

	@Test
	public void testExecuteAssignAction_EligibleFunction_NOTFunction() {
		boolean result = sysConfigService.executeAssignAction(
				MuEligibleFunctionEntity.class, "Unassign", 1l, "TTTI");

		assertTrue(!result);
	}

	@Test
	public void testExecuteAssignAction_EligibleFunction_NOTAction() {
		boolean result = sysConfigService.executeAssignAction(
				MuEligibleFunctionEntity.class, "Unas", 1l, "TTTI");

		assertTrue(!result);
	}

	@Test
	public void testExecuteAssignAction_NOT() {
		boolean result = sysConfigService.executeAssignAction(
				SystemInitEntity.class, "Unassign", 1l, "TTTI");

		assertTrue(!result);
	}
}
