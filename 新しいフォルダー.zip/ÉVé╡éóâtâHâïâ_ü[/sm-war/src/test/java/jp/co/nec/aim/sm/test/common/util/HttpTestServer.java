package jp.co.nec.aim.sm.test.common.util;
import org.mortbay.jetty.Handler;
import org.mortbay.jetty.Server;

/**
 * A server for answering HTTP requests with test response data.
 * 
 * @author Olaf Otto
 */
public class HttpTestServer {
	private int httpport = 65513;

	private Server _server;
	private String _responseBody;
	private String _requestBody;
	private String _mockResponseData;

	public HttpTestServer(int port) {
		if (port > 1024 && port < 65535)
			httpport = port;
	}

	public HttpTestServer(String mockData) {
		setMockResponseData(mockData);
	}

	public void start(Handler handler) throws Exception {
		configureServer(handler);
		startServer();
	}

	private void startServer() throws Exception {
		_server.start();
		System.out.print("server start!\n");
	}

	protected void configureServer(Handler handler) {
		_server = new Server(httpport);
		_server.setHandler(handler);
	}	

	public void stop() throws Exception {
		_server.stop();
		System.out.print("server stop!" + "\n");
	}

	public void setResponseBody(String responseBody) {
		_responseBody = responseBody;
	}

	public String getResponseBody() {
		return _responseBody;
	}

	public void setRequestBody(String requestBody) {
		_requestBody = requestBody;
	}

	public String getRequestBody() {
		return _requestBody;
	}

	public void setMockResponseData(String mockResponseData) {
		_mockResponseData = mockResponseData;
	}

	public String getMockResponseData() {
		return _mockResponseData;
	}

	protected Server getServer() {
		return _server;
	}
}

