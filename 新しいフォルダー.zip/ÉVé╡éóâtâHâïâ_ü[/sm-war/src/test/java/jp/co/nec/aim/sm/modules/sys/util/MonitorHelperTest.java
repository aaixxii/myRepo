package jp.co.nec.aim.sm.modules.sys.util;



import java.util.HashMap;
import java.util.Map;

import org.junit.Test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class MonitorHelperTest {	

	@Test
	public void testConvertMuLoadListToMap() {
		Map<String, Object> lastMap = new HashMap<String, Object>();
		String[] labels = new String[] {"mu1","mu2","mu3","mu4","mu5","mu6"};
		Integer[] datas = new Integer[] {new Integer(1),new Integer(2),new Integer(3),new Integer(4),new Integer(5),new Integer(6)};
		Map<String ,Object> datasetMap = new HashMap<String ,Object>();
		datasetMap.put("fillColor", "rgba(151,187,205,0.75)");
		datasetMap.put("strokeColor", "rgba(220,220,220,0.8)");
		datasetMap.put("data",datas);
		lastMap.put("labels", labels);
		lastMap.put("datasets",new Object[] {datasetMap});
		 ObjectMapper mapper = new ObjectMapper();
		 String jsonStr = null;
		 try {
			jsonStr = mapper.writerWithDefaultPrettyPrinter()
			            .writeValueAsString(lastMap);
		} catch (JsonProcessingException e) {			
			e.printStackTrace();
		}		 
		 System.out.print(jsonStr);			
	}
}
