//package jp.co.nec.aim.sm.common.utils;
//
//import static org.junit.Assert.assertEquals;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import jp.co.nec.aim.sm.modules.sys.oracle.entity.MuSegReportEntityPK;
//import jp.co.nec.aim.sm.modules.sys.oracle.entity.MuSegmentEntity;
//import jp.co.nec.aim.sm.modules.sys.postgres.pojo.mapping.EventLogPojo;
//
//import org.junit.Test;
//
//public class ExportDataTest {
//
//	@Test
//	public void testGettableList() {
//		List<EventLogPojo> list = new ArrayList<EventLogPojo>();
//		for (int i = 0; i < 5; i++) {
//			list.add(new EventLogPojo("type_" + i, i));
//		}
//
//		ExportData data = ExportData.getInstance();
//		data.gettableList(list);
//
//		List<String> tableList = data.getTablelist();
//		List<String> tableheadlist = data.getTableheadlist();
//
//		assertEquals(10, tableList.size());
//		for (int i = 0; i < 10; i++) {
//			if (i % 2 == 0) {
//				assertEquals("type_" + i / 2, tableList.get(i));
//			} else {
//				assertEquals(new Long(i / 2).toString(), tableList.get(i));
//			}
//		}
//
//		assertEquals(2, tableheadlist.size());
//		assertEquals("Message Type", tableheadlist.get(0));
//		assertEquals("Message Count", tableheadlist.get(1));
//	}
//
//	@Test
//	public void test() {
//		List<MuSegmentEntity> list = new ArrayList<MuSegmentEntity>();
//		for (int i = 0; i < 10; i++) {
//			MuSegmentEntity MuSegmentEntity = new MuSegmentEntity();
//			MuSegReportEntityPK id = new MuSegReportEntityPK();
//			id.setMatchUnitId(101l + i);
//			id.setSegmentId(2000l + i);
//			MuSegmentEntity.setId(id);
//			MuSegmentEntity.setRank(0);
//			list.add(MuSegmentEntity);
//		}
//		ExportData data = ExportData.getInstance();
//		data.gettableList(list);
//
//		List<String> tableList = data.getTablelist();
//		List<String> tableheadlist = data.getTableheadlist();
//		assertEquals("Match Unit ID", tableheadlist.get(0));
//		assertEquals("101", tableList.get(0));
//	}
// }
