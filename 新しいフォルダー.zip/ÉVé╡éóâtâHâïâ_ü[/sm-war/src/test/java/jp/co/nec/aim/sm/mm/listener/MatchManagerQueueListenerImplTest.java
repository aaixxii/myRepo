package jp.co.nec.aim.sm.mm.listener;

import static org.junit.Assert.assertEquals;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;

import jp.co.nec.aim.sm.common.properties.SMProperties;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Ignore
public class MatchManagerQueueListenerImplTest {
	@Autowired
	MatchManagerQueueListener queueListener;

	@Test
	public void test() throws Exception {
		if (queueListener.getLstThread().size() > 0) {
			queueListener.shutdownQueueListener();
		}

		ResourceLoader resourceLoader = new DefaultResourceLoader();
		Resource resource = resourceLoader.getResource("TestQueues");

		File bakFile = resource.getFile();
		String fileName = bakFile.getParent() + "/"
				+ SMProperties.getQueueFileName();

		copyFile(bakFile, fileName);

		try {

			queueListener.startupQueueListener();
			queueListener.startQueueNotifier();

			assertEquals(2, queueListener.getLstThread().size());
			assertEquals(2, queueListener.getLstQueueInfo().size());

			Thread.sleep(1500);

			copyFile(bakFile, fileName);

			Thread.sleep(1500);
		} finally {
			queueListener.shutdownQueueNotifier();
			queueListener.shutdownQueueListener();
		}

		assertEquals(0, queueListener.getLstThread().size());
		assertEquals(0, queueListener.getLstQueueInfo().size());

		File f = new File(fileName);
		f.delete();
	}

	private void copyFile(File src, String dec) throws Exception {
		InputStream inStream = new FileInputStream(src);
		FileOutputStream fs = new FileOutputStream(dec);

		int bytesum = 0;
		int byteread = 0;

		byte[] buffer = new byte[1444];
		while ((byteread = inStream.read(buffer)) != -1) {
			bytesum += byteread;
			fs.write(buffer, 0, byteread);
		}
		fs.flush();
		fs.close();
		inStream.close();
	}
}
