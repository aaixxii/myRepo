package jp.co.nec.aim.sm.modules.sys.web.listener;

import static org.junit.Assert.assertEquals;

import java.text.ParseException;

import javax.sql.DataSource;

import jp.co.nec.aim.sm.modules.sys.service.JobQueueService;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional(value = "postgresTXManager")
public class MMJobQueueHttpListenerTest {
	@Autowired
	@Qualifier("postgresDataSource")
	DataSource datasource;

	JdbcTemplate jdbcTemplate;

	@Autowired
	JobQueueService jobService;

	String fName[] = new String[] { "LI", "LLI", "TI", "TLI" };

	@Before
	public void before() {
		jdbcTemplate = new JdbcTemplate(datasource);

		cleanDB();
		prepareDB();
	}

	@After
	public void after() {
		cleanDB();
	}

	private void cleanDB() {
		jdbcTemplate.execute("delete from \"FUNCTION_TYPES\"");
		jdbcTemplate.execute("delete from \"JOB_QUEUE\"");
	}

	private void prepareDB() {
		for (int i = 0; i < 4; i++) {
			String functionSql = "insert into \"FUNCTION_TYPES\"("
					+ "\"FUNCTION_ID\", \"FUNCTION_NAME\") values(" + (i + 1)
					+ ", '" + fName[i] + "')";

			jdbcTemplate.execute(functionSql);
		}
	}

	@Test
	public void testSaveAndFlush() throws ParseException {
		MMJobQueueHttpListener servlet = new MMJobQueueHttpListener();
		String splitLine[] = new String[] { "1", "1", "1", "2", "100", "100",
				"true", "2013/09/01 10:00:10.854", "2013/09/01 08:03:12.344",
				"false", "false", "50", "500", "1", "false", "false", "0.45",
				"5000" };

		servlet.saveAndFlush(jobService, splitLine);

		int count = jdbcTemplate.queryForList(
				"select count(*) from \"JOB_QUEUE\" where \"JOB_ID\" = 1 ")
				.size();

		assertEquals(1, count);
	}
}
