package jp.co.nec.aim.sm.modules.sys.service;

import static org.junit.Assert.assertEquals;

import javax.sql.DataSource;

import jp.co.nec.aim.sm.common.constant.JobState;
import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.FeJobQueueEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.FusionJob;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.JobPojo;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.TopJobQueue;
import jp.co.nec.aim.sm.test.common.util.CommonUtils;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional(value = "oracleTXManager")
public class JobServiceTest {

	@Autowired
	JobService jobService;

	@Autowired
	@Qualifier("oracleDataSource")
	DataSource datasource;

	private JdbcTemplate jdbcTemplate;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {

	}

	@Before
	public void setUp() throws Exception {
		jdbcTemplate = new JdbcTemplate(datasource);
		CommonUtils.DeleteOracleData(jdbcTemplate);
		CommonUtils.prepare_JOB(jdbcTemplate);
		CommonUtils.prepareFeJobQueue(jdbcTemplate);
	}

	@After
	public void tearDown() throws Exception {
		CommonUtils.DeleteOracleData(jdbcTemplate);
	}

	@Test
	public void test_findJobPage() {
		Page<TopJobQueue> page = new Page<TopJobQueue>(1, 10);
		JobPojo job = new JobPojo();
		Page<TopJobQueue> pageResult = jobService.findJobPage(page, job);
		assertEquals(1, pageResult.getCount());
		assertEquals(1, pageResult.getList().size());
		assertEquals(1, pageResult.getMaxResults());
	}

	@Test
	public void test_findJobPage_01() {
		Page<TopJobQueue> page = new Page<TopJobQueue>(1, 10);
		JobPojo job = new JobPojo();
		job.setFunctiontype("LI");
		Page<TopJobQueue> pageResult = jobService.findJobPage(page, job);
		assertEquals(0, pageResult.getCount());
		assertEquals(0, pageResult.getList().size());
		assertEquals(0, pageResult.getMaxResults());
	}

	@Test
	public void test_findJobPage_02() {
		Page<TopJobQueue> page = new Page<TopJobQueue>(1, 10);
		JobPojo job = new JobPojo();
		job.setFunctiontype("TI");
		Page<TopJobQueue> pageResult = jobService.findJobPage(page, job);
		assertEquals(1, pageResult.getCount());
		assertEquals(1, pageResult.getList().size());
		assertEquals(1, pageResult.getMaxResults());
	}

	@Test
	public void test_findJobPage_03() {
		Page<TopJobQueue> page = new Page<TopJobQueue>(1, 10);
		JobPojo job = new JobPojo();
		job.setJobid(1l);
		Page<TopJobQueue> pageResult = jobService.findJobPage(page, job);
		assertEquals(1, pageResult.getCount());
		assertEquals(1, pageResult.getList().size());
		assertEquals(1, pageResult.getMaxResults());
	}

	@Test
	public void test_findJobPage_04() {
		Page<TopJobQueue> page = new Page<TopJobQueue>(1, 10);
		JobPojo job = new JobPojo();
		job.setJobStatus(JobState.WORKING);
		Page<TopJobQueue> pageResult = jobService.findJobPage(page, job);
		assertEquals(1, pageResult.getCount());
		assertEquals(1, pageResult.getList().size());
		assertEquals(1, pageResult.getMaxResults());
	}

	@Test
	public void test_findJobPage_05() {
		Page<TopJobQueue> page = new Page<TopJobQueue>(1, 10);
		JobPojo job = new JobPojo();
		job.setFailedFlag(0);
		Page<TopJobQueue> pageResult = jobService.findJobPage(page, job);
		assertEquals(1, pageResult.getCount());
		assertEquals(1, pageResult.getList().size());
		assertEquals(1, pageResult.getMaxResults());
	}

	@Test
	public void test_findFusionJobPage() {
		Page<FusionJob> page = new Page<FusionJob>(1, 10);
		FusionJob fusionjob = new FusionJob();
		Page<FusionJob> pageResult = jobService.findFusionJobPage(page,
				fusionjob);
		assertEquals(5, pageResult.getCount());
		assertEquals(5, pageResult.getList().size());
		assertEquals(5, pageResult.getMaxResults());
	}

	@Test
	public void test_findFusionJobPage_01() {
		Page<FusionJob> page = new Page<FusionJob>(1, 10);
		FusionJob fusionjob = new FusionJob();
		fusionjob.setFunctiontype("TI");
		Page<FusionJob> pageResult = jobService.findFusionJobPage(page,
				fusionjob);
		assertEquals(5, pageResult.getCount());
		assertEquals(5, pageResult.getList().size());
		assertEquals(5, pageResult.getMaxResults());
	}

	@Test
	public void test_findFusionJobPage_02() {
		Page<FusionJob> page = new Page<FusionJob>(1, 10);
		FusionJob fusionjob = new FusionJob();
		fusionjob.setFunctiontype("LI");
		Page<FusionJob> pageResult = jobService.findFusionJobPage(page,
				fusionjob);
		assertEquals(0, pageResult.getCount());
		assertEquals(0, pageResult.getList().size());
		assertEquals(0, pageResult.getMaxResults());
	}

	@Test
	public void test_findFusionJobPage_03() {
		Page<FusionJob> page = new Page<FusionJob>(1, 10);
		FusionJob fusionjob = new FusionJob();
		fusionjob.setFusionJobId(2l);
		Page<FusionJob> pageResult = jobService.findFusionJobPage(page,
				fusionjob);
		assertEquals(1, pageResult.getCount());
		assertEquals(1, pageResult.getList().size());
		assertEquals(1, pageResult.getMaxResults());
	}

	@Test
	public void test_findFusionJobPage_04() {
		Page<FusionJob> page = new Page<FusionJob>(1, 10);
		FusionJob fusionjob = new FusionJob();
		fusionjob.setJobId(1l);
		Page<FusionJob> pageResult = jobService.findFusionJobPage(page,
				fusionjob);
		assertEquals(5, pageResult.getCount());
		assertEquals(5, pageResult.getList().size());
		assertEquals(5, pageResult.getMaxResults());
	}

	@Test
	public void test_findFEJobQueuePage_not_set_jobId() {
		Page<FeJobQueueEntity> page = new Page<FeJobQueueEntity>(1, 10);
		FeJobQueueEntity fejob = new FeJobQueueEntity();
		Page<FeJobQueueEntity> pageResult = jobService.findFEJobQueuePage(page,
				fejob);
		assertEquals(10, pageResult.getCount());
		assertEquals(10, pageResult.getList().size());
		assertEquals(10, pageResult.getMaxResults());
	}

	@Test
	public void test_findFEJobQueuePage_set_jobId_find() {
		Page<FeJobQueueEntity> page = new Page<FeJobQueueEntity>(1, 10);
		FeJobQueueEntity fejob = new FeJobQueueEntity();
		fejob.setJobId(1L);
		Page<FeJobQueueEntity> pageResult = jobService.findFEJobQueuePage(page,
				fejob);
		assertEquals(1, pageResult.getCount());
		assertEquals(1, pageResult.getList().size());
		assertEquals(1, pageResult.getMaxResults());
	}

	@Test
	public void test_findFEJobQueuePage_set_jobId_not_find() {
		Page<FeJobQueueEntity> page = new Page<FeJobQueueEntity>(1, 10);
		FeJobQueueEntity fejob = new FeJobQueueEntity();
		fejob.setJobId(100L);
		Page<FeJobQueueEntity> pageResult = jobService.findFEJobQueuePage(page,
				fejob);
		assertEquals(0, pageResult.getCount());
		assertEquals(0, pageResult.getList().size());
		assertEquals(0, pageResult.getMaxResults());
	}

}
