package jp.co.nec.aim.sm.modules.sys.oracle.repository;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import jp.co.nec.aim.sm.modules.sys.oracle.entities.PreviousCompletedJobCounter;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.ComponentStatus;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.DBMonitorData;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.MuLoadPojo;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.TransactionMonitorData;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional(value = "oracleTXManager")
public class MonitorRepositoryImplTest {

	@Autowired
	private MonitorRepository monitorRepository;

	@Autowired
	@Qualifier("oracleDataSource")
	DataSource datasource;

	JdbcTemplate jdbcTemplate;

	@Before
	public void setUp() throws Exception {
		jdbcTemplate = new JdbcTemplate(datasource);		
		clear();
	}

	@After
	public void tearDown() throws Exception {
		clear();
	}

	@Test
	public void testGetComponentStatusList() {
		String insertMM = "insert into MATCH_MANAGERS(mm_id,unique_id,state) values(?,?,?)";
		String insertMR = "insert into MAP_REDUCERS(mr_id,unique_id,state) values(?,?,?)";
		String insertDM = "insert into DATA_MANAGERS(dm_id,unique_id,state) values(?,?,?)";
		String insertMU = "insert into MATCH_UNITS(mu_id,unique_id,state) values(?,?,?)";

		Long[] mmIds = { 100L, 101L, 102L };
		Long[] mrIds = { 200L, 201L, 202L, 203L, 204L };
		Long[] dmIds = { 300L, 301L, 302L };
		Long[] muIds = { 400L, 401L, 402L, 403L, 404L, 405L, 406L };
		String[] mmStauts = { "working", "timeout", "exit" };
		String[] mrStauts = { "working", "working", "timeout", "timeout",
				"exit" };
		String[] dmStauts = { "working", "exit", "timeout" };
		String[] muStauts = { "working", "working", "working", "timeout",
				"exit", "exit", "exit" };
		for (int i = 0; i < mmIds.length; i++) {
			jdbcTemplate.update(insertMM,
					new Object[] { mmIds[i], String.valueOf(mmIds[i]),
							mmStauts[i] });
		}
		for (int i = 0; i < mrIds.length; i++) {
			jdbcTemplate.update(insertMR,
					new Object[] { mrIds[i], String.valueOf(mrIds[i]),
							mrStauts[i] });
		}
		for (int i = 0; i < dmIds.length; i++) {
			jdbcTemplate.update(insertDM,
					new Object[] { dmIds[i], String.valueOf(dmIds[i]),
							dmStauts[i] });
		}
		for (int i = 0; i < muIds.length; i++) {
			jdbcTemplate.update(insertMU,
					new Object[] { muIds[i], String.valueOf(muIds[i]),
							muStauts[i] });
		}
		jdbcTemplate.execute("commit");
		List<ComponentStatus> results = monitorRepository
				.getComponentStatusList();
		assertEquals(12, results.size());
	}

	@Test
	public void testGetComponentStatusList_noResults() {
		List<ComponentStatus> results = monitorRepository
				.getComponentStatusList();
		assertEquals(0, results.size());
	}

	@Test
	public void testGetDBMonitorList() {
		String insertsql = ""
				+ "insert into PERSON_BIOMETRICS(BIOMETRICS_ID,EXTERNAL_ID,BIOMETRIC_DATA,"
				+ "BIOMETRIC_DATA_LEN,REGISTED_TS,CORRUPTED_FLAG,EVENT_ID,CONTAINER_ID)"
				+ " values(?,?,HEXTORAW('3E00210102CDA000C9'),50,1000,0,?,?)";				
		Long[] pbioIds = { 1000L, 1001L, 1002L, 1003L, 1004L, 1005L, 1006L,
				1007L };
		Integer[] containerIds = { 1, 1, 331, 331, 332, 3, 4, 336 };
		for (int i = 0; i < pbioIds.length; i++) {
			jdbcTemplate.update(insertsql,
					new Object[] { pbioIds[i], String.valueOf(pbioIds[i]),
							i + 1, containerIds[i] });
		}
		
		String insSegTabSql = "insert into segments(segment_id,container_id,bio_id_start,bio_id_end,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)"
				+ " values(?,?,?,?,333,1,?,?,333)";		
		Long segmentIds[] = {2000L,2001L,2002L,2003L,2004L,2005L,2006L,2007L};
		for (int i = 0 ;i < segmentIds.length; i++) {
			jdbcTemplate.update(insSegTabSql,new Object[] {segmentIds[i],containerIds[i],pbioIds[i], pbioIds[i],i,i});
		}
		
		jdbcTemplate.execute("commit");
		Integer scope = 1;
		List<DBMonitorData> results = monitorRepository.getDBMonitorList(scope);
		assertTrue(results.size() > 0);
		assertEquals(24, results.size());
	}

	@Test
	public void testGetDBMonitorList_no_results() {
		Integer scope = 1;
		List<DBMonitorData> results = monitorRepository.getDBMonitorList(scope);
		assertEquals(24, results.size());
	}
	
	@Test	
	public void testGetTransactionMonitorDataList() {
		String updateInquerySql = "update inquiry_traffic set job_complete_count= ? where FAMILY_NAME = ?";	
		String[] family_name = {"TI","LI","TLI","LLI","LIP","TLIP","LLIP","FI","II"};
		Long[] completeCount = {10L,20L,30L,40L,50L,60L,70L,80L,90L};
		for (int i = 0 ; i < 9 ; i++) {
			jdbcTemplate.update(updateInquerySql , new Object[] {completeCount[i],family_name[i]});
		}		
		String extractSql = "insert into extract_complete_count(complete_count,complete_ts) values(5,300)";
		jdbcTemplate.update(extractSql);
		jdbcTemplate.execute("commit");
		PreviousCompletedJobCounter preJobCounter = PreviousCompletedJobCounter.getInstance() ;
		Map<String, Long> preMap = preJobCounter.getPreCompleteJobMap();
		int valueOfTI = preMap.get("TI").intValue();
		int valueOfLI = preMap.get("LI").intValue();
		int valueOfTLI = preMap.get("TLI").intValue();
		int valueOfLLI = preMap.get("LLI").intValue();
		int valueOfLIP = preMap.get("LIP").intValue();
		int valueOfTLIP = preMap.get("TLIP").intValue();
		int valueOfLLIP = preMap.get("LLIP").intValue();
		int valueOfFI = preMap.get("FI").intValue();
		int valueOfII = preMap.get("II").intValue();
		int valueOfEXTRACT = preMap.get("EXTRACT").intValue();
		
		List<TransactionMonitorData> results = monitorRepository
				.getTransactionMonitorDataList();
		assertEquals(10, results.size());
		Map<String, Long> lastMap = preJobCounter.getPreCompleteJobMap();
		for (int i = 0 ; i < results.size(); i++) {
			switch (results.get(i).getFamily()){
			case "TI":								
				assertEquals((valueOfTI + results.get(i).getCount().intValue()),lastMap.get("TI").intValue());
				break;
			case "LI":				
				assertEquals((valueOfLI + results.get(i).getCount().intValue()),lastMap.get("LI").intValue());
				break;
			case "TLI":				
				assertEquals((valueOfTLI + results.get(i).getCount().intValue()),lastMap.get("TLI").intValue());
				break;
			case "LLI":				
				assertEquals((valueOfLLI + results.get(i).getCount().intValue()),lastMap.get("LLI").intValue());
				break;
			case "LIP":				
				assertEquals((valueOfLIP + results.get(i).getCount().intValue()),lastMap.get("LIP").intValue());
				break;
			case "TLIP":				
				assertEquals((valueOfTLIP + results.get(i).getCount().intValue()),lastMap.get("TLIP").intValue());
				break;
			case "LLIP":				
				assertEquals((valueOfLLIP + results.get(i).getCount().intValue()),lastMap.get("LLIP").intValue());
				break;
			case "FI":				
				assertEquals((valueOfFI + results.get(i).getCount().intValue()),lastMap.get("FI").intValue());
				break;
			case "II":				
				assertEquals((valueOfII + results.get(i).getCount().intValue()),lastMap.get("II").intValue());
				break;
			case "EXTRACT":				
				assertEquals((valueOfEXTRACT + results.get(i).getCount().intValue()),lastMap.get("EXTRACT").intValue());
				break;
			}
		}	
	}
	
	@Test	
	public void testGetTransactionMonitorDataList_minus() {
		String updateInquerySql = "update inquiry_traffic set job_complete_count= ? where FAMILY_NAME = ?";	
		String[] family_name = {"TI","LI","TLI","LLI","LIP","TLIP","LLIP","FI","II"};
		Long[] completeCount = {-10L,-20L,-30L,-40L,-50L,-60L,-70L,-80L,-90L};
		for (int i = 0 ; i < 9 ; i++) {
			jdbcTemplate.update(updateInquerySql , new Object[] {completeCount[i],family_name[i]});
		}		
		String extractSql = "insert into extract_complete_count(complete_count,complete_ts) values(5,300)";
		jdbcTemplate.update(extractSql);
		jdbcTemplate.execute("commit");
		PreviousCompletedJobCounter preJobCounter = PreviousCompletedJobCounter.getInstance() ;		
		
		List<TransactionMonitorData> results = monitorRepository
				.getTransactionMonitorDataList();
		assertEquals(10, results.size());
		Map<String, Long> lastMap = preJobCounter.getPreCompleteJobMap();
		assertEquals(0, lastMap.get("TI").intValue());
		assertEquals(0, lastMap.get("LI").intValue());
		assertEquals(0, lastMap.get("TLI").intValue());
		assertEquals(0, lastMap.get("LLI").intValue());
		assertEquals(0, lastMap.get("LIP").intValue());
		assertEquals(0, lastMap.get("TLIP").intValue());
		assertEquals(0, lastMap.get("LLIP").intValue());
		assertEquals(0, lastMap.get("FI").intValue());
		assertEquals(0, lastMap.get("II").intValue());
		assertEquals(5, lastMap.get("EXTRACT").intValue());				
	
	}
	
	@Test	
	public void testGetTransactionMonitorDataList_minus_more() {
		String updateInquerySql = "update inquiry_traffic set job_complete_count= ? where FAMILY_NAME = ?";	
		String[] family_name = {"TI","LI","TLI","LLI","LIP","TLIP","LLIP","FI","II"};
		Long[] completeCount = {-10L,-20L,-30L,-40L,-50L,60L,70L,80L,90L};
		for (int i = 0 ; i < 9 ; i++) {
			jdbcTemplate.update(updateInquerySql , new Object[] {completeCount[i],family_name[i]});
		}		
		String extractSql = "insert into extract_complete_count(complete_count,complete_ts) values(5,300)";
		jdbcTemplate.update(extractSql);
		jdbcTemplate.execute("commit");
		PreviousCompletedJobCounter preJobCounter = PreviousCompletedJobCounter.getInstance() ;
		Map<String, Long> preMap = preJobCounter.getPreCompleteJobMap();
		int valueOfTI = preMap.get("TI").intValue();
		int valueOfLI = preMap.get("LI").intValue();
		int valueOfTLI = preMap.get("TLI").intValue();
		int valueOfLLI = preMap.get("LLI").intValue();
		int valueOfLIP = preMap.get("LIP").intValue();
		int valueOfTLIP = preMap.get("TLIP").intValue();
		int valueOfLLIP = preMap.get("LLIP").intValue();
		int valueOfFI = preMap.get("FI").intValue();
		int valueOfII = preMap.get("II").intValue();
		int valueOfEXTRACT = preMap.get("EXTRACT").intValue();
		
		List<TransactionMonitorData> results = monitorRepository
				.getTransactionMonitorDataList();
		assertEquals(10, results.size());
		Map<String, Long> lastMap = preJobCounter.getPreCompleteJobMap();
		for (int i = 0 ; i < results.size(); i++) {
			switch (results.get(i).getFamily()){
			case "TI":
				assertEquals(0, lastMap.get("TI").intValue());					
				break;
			case "LI":	
				assertEquals(0, lastMap.get("LI").intValue());			
				break;
			case "TLI":	
				assertEquals(0, lastMap.get("TLI").intValue());
				
				break;
			case "LLI":	
				assertEquals(0, lastMap.get("LLI").intValue());
				break;
			case "LIP":	
				assertEquals(0, lastMap.get("LIP").intValue());				
				break;
			case "TLIP":
				assertEquals((valueOfTLIP + results.get(i).getCount().intValue()),lastMap.get("TLIP").intValue());
				break;
			case "LLIP":
				assertEquals((valueOfLLIP + results.get(i).getCount().intValue()),lastMap.get("LLIP").intValue());
				break;
			case "FI":
				assertEquals((valueOfFI + results.get(i).getCount().intValue()),lastMap.get("FI").intValue());
				break;
			case "II":	
				assertEquals((valueOfII + results.get(i).getCount().intValue()),lastMap.get("II").intValue());				
				break;
			case "EXTRACT":
				assertEquals((valueOfEXTRACT + results.get(i).getCount().intValue()),lastMap.get("EXTRACT").intValue());				
				break;
			}
		}
			
		}
	
	
	@Test
	public void testGetTransactionMonitor_Extract_Null() {
		String updateInquerySql = "update inquiry_traffic set job_complete_count= ? where family_id = ?";	
		Integer[] family_ids = {1,2,3,4,5,6,7,8,9};
		for (int i = 0 ; i < 9 ; i++) {
			jdbcTemplate.update(updateInquerySql , new Object[] {family_ids[i],family_ids[i]});
		}				
		jdbcTemplate.execute("commit");	
		
		List<TransactionMonitorData> results = monitorRepository
				.getTransactionMonitorDataList();		
		assertEquals(9, results.size());		
	}	
	
	@Test
	public void testGetMuInquiryLoadDataList() {
		String insertMuSql = "insert into MATCH_UNITS(mu_id,unique_id,state) values(?,?,'WORKING')";		
		String insertMuInquiyLoadSql = "insert into MU_INQUIRY_LOAD(mu_id,pressure,report_ts) values(?,?,1005)";
		Long[] muIds = { 1000L, 1002L, 1003L, 1004L, 1005L };		
		Long muInquiryLoad[] = { 10L, 11L, 12L, 13L, 14L };
		for (int i = 0; i < muIds.length; i++) {
			jdbcTemplate.update(insertMuSql,
					new Object[] { muIds[i], String.valueOf(muIds[i]) });	
			jdbcTemplate.update(insertMuInquiyLoadSql, new Object[] { muIds[i],
					muInquiryLoad[i] });
		}
		jdbcTemplate.execute("commit");
		List<MuLoadPojo> results = monitorRepository.getMuInquiryLoadDataList();
		assertTrue(results.size() > 0);
		assertEquals(5, results.size());
	}

	@Test
	public void testGetMuExtractLoadDataList() {
		String insertMuSql = "insert into MATCH_UNITS(mu_id,unique_id,state) values(?,?,'WORKING')";
		String insertMuExtractLoadSql = "insert into MU_EXTRACT_LOAD(mu_id,pressure,update_ts) values(?,?,1000)";		
		Long[] muIds = { 1000L, 1002L, 1003L, 1004L, 1005L };
		Long muExtractLoad[] = { 5L, 6L, 7L, 8L, 9L };		
		for (int i = 0; i < muIds.length; i++) {
			jdbcTemplate.update(insertMuSql,
					new Object[] { muIds[i], String.valueOf(muIds[i]) });
			jdbcTemplate.update(insertMuExtractLoadSql, new Object[] {
					muIds[i], muExtractLoad[i] });		
		}
		jdbcTemplate.execute("commit");
		List<MuLoadPojo> results = monitorRepository.getMuExtractLoadDataList();
		assertTrue(results.size() > 0);
		assertEquals(5, results.size());
	}	

	@Test
	public void testGetMuInquiryLoadDataList_zero_results() {
		List<MuLoadPojo> results = monitorRepository.getMuInquiryLoadDataList();
		assertEquals(0, results.size());
	}
	
	@Test
	public void testGetMuInquiryLoadDataList_null_results() {
		String insertMuSql = "insert into MATCH_UNITS(mu_id,unique_id,state) values(?,?,'WORKING')";			
		Long[] muIds = { 1000L, 1002L, 1003L, 1004L, 1005L };			
		for (int i = 0; i < muIds.length; i++) {
			jdbcTemplate.update(insertMuSql,
					new Object[] { muIds[i], String.valueOf(muIds[i]) });			
		}
		jdbcTemplate.execute("commit");		
		List<MuLoadPojo> results = monitorRepository.getMuInquiryLoadDataList();
		assertEquals(0, results.size());
		for (int i = 0 ; i < results.size(); i++) {
			assertEquals(0, results.get(i).getPressure().intValue());
		}
	}	
	
	@Test
	public void testGetMuExtractLoadDataList_zero_results() {
		List<MuLoadPojo> results = monitorRepository.getMuExtractLoadDataList();
		assertEquals(0, results.size());
	}

	@Test
	public void testGetMuExtractLoadDataList_null_results() {
		String insertMuSql = "insert into MATCH_UNITS(mu_id,unique_id,state) values(?,?,'WORKING')";		
		Long[] muIds = { 1000L, 1002L, 1003L, 1004L, 1005L };			
		for (int i = 0; i < muIds.length; i++) {
			jdbcTemplate.update(insertMuSql,
					new Object[] { muIds[i], String.valueOf(muIds[i]) });					
		}
		jdbcTemplate.execute("commit");		
		List<MuLoadPojo> results = monitorRepository.getMuExtractLoadDataList();
		assertEquals(0, results.size());
		for (int i = 0 ; i < results.size(); i++) {
			assertEquals(0, results.get(i).getPressure().intValue());
		}
	}
	
	
	@Test
	public void testGetSlbStatus() {
		String sql = "insert into SYSTEM_CONFIG(CONFIG_ID, PROPERTY_NAME,PROPERTY_VALUE) values(3000,'LOAD_BALANCER.ENABLED','true')";
		jdbcTemplate.execute(sql);
		String result = monitorRepository.getSlbStatus();
		assertNotNull(result);
		assertEquals("true",result);
	}

	public void clear() {
		jdbcTemplate.execute("delete from MATCH_MANAGERS");
		jdbcTemplate.execute("delete from MAP_REDUCERS");
		jdbcTemplate.execute("delete from DATA_MANAGERS");
		jdbcTemplate.execute("delete from FE_JOB_QUEUE");
		jdbcTemplate.execute("delete from FE_LOT_JOBS");
		jdbcTemplate.execute("delete from JOB_QUEUE");
		jdbcTemplate.execute("delete from PERSON_BIOMETRICS");
		jdbcTemplate.execute("delete from MU_EXTRACT_LOAD");
		jdbcTemplate.execute("delete from MU_EXTRACT_LOAD");
		jdbcTemplate.execute("delete from MATCH_UNITS");
		jdbcTemplate.execute("delete from SYSTEM_CONFIG");
		jdbcTemplate.execute("delete from segments");
		jdbcTemplate.execute("delete from  extract_complete_count ");
		jdbcTemplate.execute("update inquiry_traffic set job_complete_count= 0");
		jdbcTemplate.execute("commit");
	}

}
