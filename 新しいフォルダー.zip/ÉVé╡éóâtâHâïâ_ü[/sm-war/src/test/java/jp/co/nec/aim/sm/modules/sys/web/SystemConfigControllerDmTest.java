package jp.co.nec.aim.sm.modules.sys.web;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.List;

import javax.sql.DataSource;

import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.EligibleBinsPojo;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ExtendedModelMap;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional(value = "oracleTXManager")
@SuppressWarnings("unchecked")
public class SystemConfigControllerDmTest {
	
	@Autowired
	SystemConfigController sysConfigController;

	@Autowired
	@Qualifier("oracleDataSource")
	DataSource datasource;

	JdbcTemplate jdbcTemplate;

	ExtendedModelMap modelMap;
	MockHttpServletRequest request;
	MockHttpServletResponse response;

	String[] formatName = new String[] { "RDBT", "RDBL", "LDB", "PBLNF" };
	String[] functionName = new String[] { "TI", "LI", "TLI", "LLI" };
	String[] assignActions = { "Assign", "Unassign" };
	String[] binActions = { "Update", "Filter" };
	
	@Before
	public void before() {
		modelMap = new ExtendedModelMap();
		request = new MockHttpServletRequest();
		response = new MockHttpServletResponse();

		jdbcTemplate = new JdbcTemplate(datasource);
		clearDmDB();
		prepareDmDB();
	}

	@After
	public void after() {
		clearDmDB();
	}
	
	@Test
	public void testListDmEligibleBins_Assign_1() {	
		EligibleBinsPojo entity = new EligibleBinsPojo();
		entity.setMatchUnitId(1l);
		entity.setBinId(1l);
		entity.setAction(assignActions[0]);
		String result = sysConfigController.listDmEligibleBins(1L, entity,
				request, response, modelMap);
		assertEquals("modules/configure/eligibleContainers", result);

		List<String> binList = (List<String>) modelMap.get("binList");
		assertEquals(19, binList.size());

		Page<EligibleBinsPojo> page = (Page<EligibleBinsPojo>) modelMap
				.get("page");
		Assert.assertEquals(4, page.getCount());	

		List<String> actionList = (List<String>) modelMap.get("actionList");
		assertEquals(2, actionList.size());
		for (int i = 0; i < 2; i++) {
			assertTrue(actionList.contains(assignActions[i]));
		}

		String message = (String) modelMap.get("message");
		assertNull(message);
		
	}
	
	private void prepareDmDB() {
		String sql0 = "insert into SYSTEM_CONFIG(CONFIG_ID, PROPERTY_NAME,"
				+ " PROPERTY_VALUE) values(5, 'LOAD_BALANCER."
				+ "DEFAULT_MIN_REDUNDANCY', '2')";
		jdbcTemplate.execute(sql0);
		for (int i = 1; i <= 4; i++) {
			String sql = "insert into DATA_MANAGERS(DM_ID, UNIQUE_ID, STATE"
					+ ") values(" + i + ", 'unique_" + i + "', 'WORKING')";
			jdbcTemplate.execute(sql);
		}

		for (int i = 1; i <= 4; i++) {
			String sql = "insert into DM_ELIGIBLE_CONTAINERS(DM_ID, CONTAINER_ID"
					+ ") values(" + 1 + ", " + i + ")";
			jdbcTemplate.execute(sql);
		}
		jdbcTemplate.execute("commit");
	}
	
	private void clearDmDB() {
		jdbcTemplate.execute("delete from DATA_MANAGERS");
		jdbcTemplate.execute("delete from Dm_ELIGIBLE_CONTAINERS");
		jdbcTemplate.execute("delete from SYSTEM_CONFIG");
		jdbcTemplate.execute("commit");

	}
	
	
}
