package jp.co.nec.aim.sm.common.utils;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class SMUtilTest {
	
	
	@Test
	public void testGetYear() {
		
		String str = DateUtils.getYear();
		assertEquals("2018", str);	
		assertEquals(4, str.length());
	}
	
}


