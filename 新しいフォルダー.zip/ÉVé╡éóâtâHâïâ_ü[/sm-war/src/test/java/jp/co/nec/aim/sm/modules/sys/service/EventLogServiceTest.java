package jp.co.nec.aim.sm.modules.sys.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import java.sql.Timestamp;
import java.text.ParseException;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.modules.sys.postgres.entity.EventLogEntity;
import jp.co.nec.aim.sm.modules.sys.postgres.pojo.mapping.EventDetailPojo;
import jp.co.nec.aim.sm.modules.sys.postgres.pojo.mapping.EventLogPojo;
import jp.co.nec.aim.sm.modules.sys.postgres.pojo.mapping.MessageEventPojo;
import jp.co.nec.aim.sm.modules.sys.postgres.pojo.mapping.UnitEventPojo;
import jp.co.nec.aim.sm.modules.sys.postgres.repository.EventLogRepository;
import jp.co.nec.aim.sm.test.common.util.CommonUtils;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional(value = "postgresTXManager")
public class EventLogServiceTest {

	@Autowired
	EventLogService eventLogService;

	@Autowired
	private EventLogRepository repository;

	String[] MessageType = { "ERROR", "INFORMATION", "INFORMATION",
			"INFORMATION", "WARNING", "INFORMATION", "SERVICES_STARTED" };
	String msgArray[][] = { { "844000303", "400000" },
			{ "044000300", "100000" }, { "044000300", "100000" },
			{ "044000300", "100000" }, { "144114000", "200000" },
			{ "044000300", "100000" }, { "040000000", "110000" } };

	private String startTime = "2013-07-13 00:00:00";
	private String endTime = "2013-07-13 23:59:59";

	@Autowired
	@Qualifier("postgresDataSource")
	DataSource datasource;

	JdbcTemplate jdbcTemplate;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		jdbcTemplate = new JdbcTemplate(datasource);
		CommonUtils.DeletePostgreData(jdbcTemplate);
		CommonUtils.prepareEVENT_LOG(jdbcTemplate);
	}

	@After
	public void tearDown() throws Exception {
		CommonUtils.DeletePostgreData(jdbcTemplate);
	}

	private void prepareDB() {		
		repository.deleteAll();
		String time = "2013-07-13 12:10:10";
		Timestamp ts = Timestamp.valueOf(time);
		for (int i = 0; i < msgArray.length; i++) {
			EventLogEntity eventLogEntity = new EventLogEntity();
			eventLogEntity.setEventId(i + 1);
			eventLogEntity.setMessage("Test Message.");
			eventLogEntity.setMessageCode(msgArray[i][0]);
			eventLogEntity.setCls("jp.co.nec.aim.sm.web.test");
			eventLogEntity.setTimestamp(ts);
			eventLogEntity.setMessageType(msgArray[i][1]);
			eventLogEntity.setUnitId(361l + i);
			repository.saveAndFlush(eventLogEntity);
		}
	}

	@Test
	public void test_categoryEventLog_Empty() {
		EventLogEntity eventLog = new EventLogEntity();
		List<EventLogPojo> eventLogPojoList = eventLogService
				.getEvents(eventLog);
		assertEquals(4, eventLogPojoList.size());
		for (int i = 0; i < 4; i++) {
			if (eventLogPojoList.get(i).getMessageType()
					.equals("SERVICES_STARTED")) {
				assertEquals(1, eventLogPojoList.get(i).getMessageCount()
						.intValue());
			} else if (eventLogPojoList.get(i).getMessageType().equals("ERROR")) {
				assertEquals(2, eventLogPojoList.get(i).getMessageCount()
						.intValue());
			} else if (eventLogPojoList.get(i).getMessageType()
					.equals("WARNING")) {
				assertEquals(1, eventLogPojoList.get(i).getMessageCount()
						.intValue());
			} else if (eventLogPojoList.get(i).getMessageType()
					.equals("INFORMATION")) {
				assertEquals(8, eventLogPojoList.get(i).getMessageCount()
						.intValue());
			} else {
				fail();
			}
		}
	}

	@Test
	public void test_categoryEventLog_NotEmpty() throws ParseException {
		EventLogEntity eventLog = new EventLogEntity();
		eventLog.setStartTime("1998-05-01 00:00:00");
		eventLog.setEndTime("2005-05-01 23:59:59");
		List<EventLogPojo> eventLogPojoList = eventLogService
				.getEvents(eventLog);
		assertEquals(2, eventLogPojoList.size());
		for (int i = 0; i < 2; i++) {
			if (eventLogPojoList.get(i).getMessageType().equals("ERROR")) {
				assertEquals(1, eventLogPojoList.get(i).getMessageCount()
						.intValue());

			} else if (eventLogPojoList.get(i).getMessageType()
					.equals("INFORMATION")) {
				assertEquals(4, eventLogPojoList.get(i).getMessageCount()
						.intValue());
			} else {
				fail();
			}
		}
	}

	@Test
	public void testGetUnitEvents() {

		prepareDB();

		EventLogEntity eventLog = new EventLogEntity();
		eventLog.setStartTime(startTime);
		eventLog.setEndTime(endTime);
		List<UnitEventPojo> events = eventLogService.getUnitEvents(eventLog);
		assertEquals(7, events.size());
		for (int i = 0; i < 7; i++) {
			assertEquals(361l + i, events.get(i).getUnitId().longValue());
			assertEquals(1, events.get(i).getMessageCount().intValue());
			assertEquals(MessageType[i], events.get(i).getMessageType());
		}

		repository.deleteAll();
	}

	@Test
	public void testGetMessageEvents() {

		prepareDB();

		EventLogEntity eventLog = new EventLogEntity();
		eventLog.setStartTime(startTime);
		eventLog.setEndTime(endTime);
		List<MessageEventPojo> events = eventLogService
				.getMessageEvents(eventLog);
		assertEquals(7, events.size());
		for (int i = 0; i < 7; i++) {
			assertEquals(361l + i, events.get(i).getUnitId().longValue());
			assertEquals(msgArray[i][0], events.get(i).getMessageCode());
			assertEquals(1, events.get(i).getMessageCount().intValue());
			assertEquals(MessageType[i], events.get(i).getMessageType());
		}
	}

	@Test
	public void testGetMessageEvents_2() {
		prepareDB();

		EventLogEntity eventLog = new EventLogEntity();
		eventLog.setStartTime(startTime);
		eventLog.setEndTime(endTime);
		List<MessageEventPojo> events = eventLogService.getMessageEvents(
				new Page<MessageEventPojo>(1, 10), eventLog).getList();
		assertEquals(7, events.size());
		for (int i = 0; i < 7; i++) {
			assertEquals(361l + i, events.get(i).getUnitId().longValue());
			assertEquals(msgArray[i][0], events.get(i).getMessageCode());
			assertEquals(1, events.get(i).getMessageCount().intValue());
			assertEquals(MessageType[i], events.get(i).getMessageType());
		}
	}

	@Test
	public void testGetEventDetail() {
		prepareDB();

		EventLogEntity eventLog = new EventLogEntity();
		eventLog.setStartTime(startTime);
		eventLog.setEndTime(endTime);
		List<EventDetailPojo> events = eventLogService.getEventDetail(eventLog);
		assertEquals(7, events.size());
		for (int i = 0; i < 7; i++) {
			assertEquals(361l + i, events.get(i).getUnitId().longValue());
			assertEquals(msgArray[i][0], events.get(i).getMessageCode());
			assertEquals("2013/07/13 12:10:10.000", events.get(i)
					.getTimestamp());
			assertEquals(MessageType[i], events.get(i).getMessageType());
			assertEquals("Test Message.", events.get(i).getMessage());
		}
	}

	@Test
	public void testGetEventDetail_2() {
		prepareDB();

		EventLogEntity eventLog = new EventLogEntity();
		eventLog.setStartTime(startTime);
		eventLog.setEndTime(endTime);
		List<EventDetailPojo> events = eventLogService.getEventDetail(
				new Page<EventDetailPojo>(1, 10), eventLog).getList();
		assertEquals(7, events.size());
		for (int i = 0; i < 7; i++) {
			assertEquals(361l + i, events.get(i).getUnitId().longValue());
			assertEquals(msgArray[i][0], events.get(i).getMessageCode());
			assertEquals("2013/07/13 12:10:10.000", events.get(i)
					.getTimestamp());
			assertEquals(MessageType[i], events.get(i).getMessageType());
			assertEquals("Test Message.", events.get(i).getMessage());
		}
	}

	@Test
	public void testGetEventLogs() {
		prepareDB();

		EventLogEntity eventLog = new EventLogEntity();
		List<EventLogEntity> events = eventLogService.getEventLogs(eventLog);
		assertEquals(7, events.size());
		for (int i = 0; i < 7; i++) {
			assertNotNull(events.get(i).getEventId());
			assertEquals(361l + i, events.get(i).getUnitId().longValue());
			assertEquals(msgArray[i][0], events.get(i).getMessageCode());
			assertEquals("2013-07-13 12:10:10.0", events.get(i).getTimestamp()
					.toString());
			assertEquals(msgArray[i][1], events.get(i).getMessageType());
			assertEquals("Test Message.", events.get(i).getMessage());
		}
	}

	@Test
	public void testGetEventLogs_2() {
		prepareDB();

		EventLogEntity eventLog = new EventLogEntity();
		List<EventLogEntity> events = eventLogService.getEventLogs(
				new Page<EventLogEntity>(1, 10), eventLog).getList();
		assertEquals(7, events.size());
		for (int i = 0; i < 7; i++) {
			assertNotNull(events.get(i).getEventId());
			assertEquals(361l + i, events.get(i).getUnitId().longValue());
			assertEquals(msgArray[i][0], events.get(i).getMessageCode());
			assertEquals("2013-07-13 12:10:10.0", events.get(i).getTimestamp()
					.toString());
			assertEquals(msgArray[i][1], events.get(i).getMessageType());
			assertEquals("Test Message.", events.get(i).getMessage());
		}
	}

	@Test
	public void testGetHeaderList() {
		String[] MessageType = { "ERROR", "INFORMATION", "WARNING",
				"SERVICES_STARTED" };
		prepareDB();
		EventLogEntity eventLog = new EventLogEntity();
		eventLog.setStartTime(startTime);
		eventLog.setEndTime(endTime);
		List<UnitEventPojo> evnetsList = eventLogService
				.getUnitEvents(eventLog);
		List<String> headerList = eventLogService.getHeaderList(evnetsList);

		assertEquals(5, headerList.size());
		assertEquals("Unit ID", headerList.get(0));

		for (int i = 0; i < 4; i++) {
			assertEquals(MessageType[i], headerList.get(i + 1));
		}
	}

	@Test
	public void testGetLists() {
		prepareDB();

		EventLogEntity eventLog = new EventLogEntity();
		eventLog.setStartTime(startTime);
		eventLog.setEndTime(endTime);
		List<UnitEventPojo> evnetsList = eventLogService
				.getUnitEvents(eventLog);
		List<String> headerList = eventLogService.getHeaderList(evnetsList);

		List<List<String>> list = eventLogService.getLists(headerList,
				evnetsList);

		assertEquals(7, list.size());
		int[] index = new int[] { 1, 2, 2, 2, 3, 2, 4 };
		for (int i = 0; i < 7; i++) {
			assertEquals("" + (361 + i), list.get(i).get(0));
			for (int j = 1; j <= 4; j++) {
				if (j == index[i]) {
					assertEquals("1", list.get(i).get(j));
				} else {
					assertEquals("", list.get(i).get(j));
				}
			}
		}
	}

	@Test
	public void testGetTableList() {
		prepareDB();

		EventLogEntity eventLog = new EventLogEntity();
		eventLog.setStartTime(startTime);
		eventLog.setEndTime(endTime);
		List<UnitEventPojo> evnetsList = eventLogService
				.getUnitEvents(eventLog);
		List<String> headerList = eventLogService.getHeaderList(evnetsList);

		List<String> list = eventLogService
				.getTableList(headerList, evnetsList);

		assertEquals(35, list.size());
		int[] index = new int[] { 1, 2, 2, 2, 3, 2, 4 };
		for (int i = 0; i < 7; i++) {
			assertEquals("" + (361 + i), list.get(i * 5));
			for (int j = 1; j <= 4; j++) {
				int n = i * 5 + j;
				if (j == index[i]) {
					assertEquals("1", list.get(n));
				} else {
					assertEquals("", list.get(n));
				}
			}
		}
	}
	
	@Test
	public void getAlarmInfo() {
		repository.deleteAll();
		Date date = new Date();
		Timestamp timeStamp = new Timestamp(date.getTime());		
		String tmp = timeStamp.toString().substring(0, 18);
		//String time = "2015-06-17 13:30:10";
		Timestamp ts = Timestamp.valueOf(tmp);
		
		for (int i = 0; i < msgArray.length; i++) {
			EventLogEntity eventLogEntity = new EventLogEntity();
			eventLogEntity.setEventId(i + 1);
			eventLogEntity.setMessage("Test Message.");
			eventLogEntity.setMessageCode(msgArray[i][0]);
			eventLogEntity.setCls("jp.co.nec.aim.sm.web.test");
			eventLogEntity.setTimestamp(ts);
			eventLogEntity.setMessageType(msgArray[i][1]);
			eventLogEntity.setUnitId(361l + i);
			repository.saveAndFlush(eventLogEntity);
		}
		Integer timeVale = 100000;	
		Map<String,String> results = eventLogService.getAlarmInfo(timeVale);
		String res = results.get("lastAlm");
		assertEquals(ts.toString(),res);	
		System.out.println(pringJson(results));
	}
	
	@Test
	public void testGetCurrentTimeFromDB() {
		 Map<String,String> timeMap = eventLogService.getCurrentTimeFromDB();
		assertNotNull(timeMap);
		String value = timeMap.get("time");
		assertNotNull(value);
		System.out.println(pringJson(timeMap));
	}
	
	public String pringJson( Object object) {
		ObjectMapper mapper = new ObjectMapper();
        String jsonStr = null;
		try {
			jsonStr = mapper.writerWithDefaultPrettyPrinter()
			        .writeValueAsString(object);
		} catch (JsonProcessingException e) {			
			e.printStackTrace();
		}
		return jsonStr;		
	}
}
