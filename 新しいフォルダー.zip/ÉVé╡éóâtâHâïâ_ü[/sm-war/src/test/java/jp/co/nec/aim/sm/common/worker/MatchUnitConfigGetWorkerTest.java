package jp.co.nec.aim.sm.common.worker;

import static org.apache.commons.io.IOUtils.write;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.nec.aim.sm.common.async.agent.AsyncAgent;
import jp.co.nec.aim.sm.common.utils.MuConfigItemUtils;
import jp.co.nec.aim.sm.common.utils.MuConfigSectionUtils;
import jp.co.nec.aim.sm.common.utils.MuConfigUtils;
import jp.co.nec.aim.sm.common.utils.SMUtil;
import jp.co.nec.aim.sm.test.common.util.HttpTestServer;

import org.ini4j.InvalidFileFormatException;
import org.ini4j.Profile.Section;
import org.ini4j.Wini;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.mortbay.jetty.Handler;
import org.mortbay.jetty.HttpConnection;
import org.mortbay.jetty.Request;
import org.mortbay.jetty.handler.AbstractHandler;

public class MatchUnitConfigGetWorkerTest {
	private String postUrl = "http://127.0.0.1:65513/test";
	private URI ipPort;
	private MatchUnitConfigGetWorker matchUnitConfigGetWorker;
	private static HttpTestServer _server;
	static int eventcase = 0;
	private static StringBuffer iniOutput = new StringBuffer();
	private static String path;

	public static Handler getMockHandler() {
		Handler handler = new AbstractHandler() {
			public void handle(String target, HttpServletRequest request,
					HttpServletResponse response, int dispatch)
					throws IOException, ServletException {
				Request baseRequest = request instanceof Request ? (Request) request
						: HttpConnection.getCurrentConnection().getRequest();
				switch (eventcase) {
				case 0:
					response.setStatus(200);

					write(iniOutput.toString(), response.getOutputStream());
					break;
				case 1:
					response.setStatus(500);
					write("<html><head><title>JBoss Web/3.0.0-CR2 - Error report</title></head></html>",
							response.getOutputStream());
					break;
				case 2:
					response.setStatus(404);
					write("<html><head><title>JBoss Web/3.0.0-CR2 - Error report</title></head></html>",
							response.getOutputStream());
					break;
				case 3:
					response.setStatus(404);
					write("<html><head><title>JBoss Web/3.0.0-CR2 - Error report</title></head></html>",
							response.getOutputStream());
					break;
				}

				response.setContentType("text/html;charset=utf-8");
				response.setCharacterEncoding("UTF-8");
				baseRequest.setHandled(true);
			}

		};
		return handler;
	}

	public static void pareData() {
		//path = MatchUnitConfigGetWorkerTest.class.getResource("/").getPath()
		//		+ "MuConfig.dic";
		//File file = new File(path);	
		//URL url = MatchUnitConfigGetWorkerTest.class.getResource("MuConfig.dic");
		URL url = MatchUnitConfigGetWorkerTest.class.getClassLoader().getResource("MuConfig.dic");
		//String filePath = url.getPath();
		File file = null;
		try {
			file = new File(url.toURI());
		} catch (URISyntaxException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}		
		FileReader fileReader;
		try {
			fileReader = new FileReader(file);
			char[] data = new char[1024];
			int length = 0;

			while ((length = fileReader.read(data)) > 0) {
				String str = new String(data, 0, length);
				iniOutput.append(str);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		_server = new HttpTestServer(22);
		_server.start(getMockHandler());
		pareData();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		if (_server != null) {
			_server.stop();
		}
	}

	@Before
	public void setUp() throws Exception {
		if (SMUtil.isObjectNull(ipPort))
			ipPort = new URI(postUrl);
	}

	@After
	public void tearDown() throws Exception {
		eventcase = 0;
	}

	@Test
	@Ignore
	public void testDoTask() throws InvalidFileFormatException, IOException {
		AsyncAgent result = AsyncAgent
				.newInstance(new Object[] { ipPort, false });

		matchUnitConfigGetWorker = new MatchUnitConfigGetWorker(result);
		matchUnitConfigGetWorker.run();
		List<MuConfigUtils> map = MatchUnitParameterDictionary
				.getMatchUnitParameterMap(false);
		Wini iniparameter = new Wini(new File(path));
		Set<String> sectionNames = iniparameter.keySet();
		Iterator<String> it = sectionNames.iterator();
		while (it.hasNext()) {
			String section = (String) it.next();
			Section sec = iniparameter.get(section);
			Set<Entry<String, String>> parameter = sec.entrySet();
			Iterator<Entry<String, String>> its = parameter.iterator();
			while (its.hasNext()) {
				Entry<String, String> param = its.next();

				for (MuConfigUtils util : map) {
					if (util.getSection().equals(section)) {
						for (MuConfigSectionUtils sectUtil : util
								.getMuConfigSection()) {
							if (sectUtil.getKey().equals(param.getKey())) {
								for (MuConfigItemUtils itemUtil : sectUtil
										.getMuConfigItems()) {
									if (itemUtil.getMuIpName().equals(
											"MU(127.0.0.1:65513)")) {
										assertEquals(param.getValue(),
												itemUtil.getValue());
										return;
									}
								}
							}
						}
					}
				}
			}
		}

		fail();
	}

	@Test
	@Ignore
	public void testDoTask_status500() throws InvalidFileFormatException,
			IOException {
		AsyncAgent result = AsyncAgent
				.newInstance(new Object[] { ipPort, false });
		eventcase = 1;
		matchUnitConfigGetWorker = new MatchUnitConfigGetWorker(result);
		matchUnitConfigGetWorker.run();
		List<MuConfigUtils> map = MatchUnitParameterDictionary
				.getMatchUnitParameterMap(false);
		Wini iniparameter = new Wini(new File(path));
		Set<String> sectionNames = iniparameter.keySet();
		Iterator<String> it = sectionNames.iterator();
		while (it.hasNext()) {
			String section = (String) it.next();
			Section sec = iniparameter.get(section);
			Set<Entry<String, String>> parameter = sec.entrySet();
			Iterator<Entry<String, String>> its = parameter.iterator();
			while (its.hasNext()) {
				Entry<String, String> param = its.next();

				for (MuConfigUtils util : map) {
					if (util.getSection().equals(section)) {
						for (MuConfigSectionUtils sectUtil : util
								.getMuConfigSection()) {
							if (sectUtil.getKey().equals(param.getKey())) {
								assertEquals(0, sectUtil.getMuConfigItems()
										.size());
								return;
							}
						}
					}
				}
			}
		}

		fail();
	}

	@Test
	@Ignore
	public void testDoTask_status404() throws InvalidFileFormatException,
			IOException {
		AsyncAgent result = AsyncAgent
				.newInstance(new Object[] { ipPort, false });
		eventcase = 2;
		matchUnitConfigGetWorker = new MatchUnitConfigGetWorker(result);
		matchUnitConfigGetWorker.run();
		List<MuConfigUtils> map = MatchUnitParameterDictionary
				.getMatchUnitParameterMap(false);
		Wini iniparameter = new Wini(new File(path));
		Set<String> sectionNames = iniparameter.keySet();
		Iterator<String> it = sectionNames.iterator();
		while (it.hasNext()) {
			String section = (String) it.next();
			Section sec = iniparameter.get(section);
			Set<Entry<String, String>> parameter = sec.entrySet();
			Iterator<Entry<String, String>> its = parameter.iterator();
			while (its.hasNext()) {
				Entry<String, String> param = its.next();

				for (MuConfigUtils util : map) {
					if (util.getSection().equals(section)) {
						for (MuConfigSectionUtils sectUtil : util
								.getMuConfigSection()) {
							if (sectUtil.getKey().equals(param.getKey())) {
								assertEquals(0, sectUtil.getMuConfigItems()
										.size());
								return;
							}
						}
					}
				}
			}
		}

		fail();
	}

	@Test
	@Ignore
	public void testDoTask_status400() throws InvalidFileFormatException,
			IOException {
		AsyncAgent result = AsyncAgent
				.newInstance(new Object[] { ipPort, false });
		eventcase = 3;
		matchUnitConfigGetWorker = new MatchUnitConfigGetWorker(result);
		matchUnitConfigGetWorker.run();
		List<MuConfigUtils> map = MatchUnitParameterDictionary
				.getMatchUnitParameterMap(false);
		Wini iniparameter = new Wini(new File(path));
		Set<String> sectionNames = iniparameter.keySet();
		Iterator<String> it = sectionNames.iterator();
		while (it.hasNext()) {
			String section = (String) it.next();
			Section sec = iniparameter.get(section);
			Set<Entry<String, String>> parameter = sec.entrySet();
			Iterator<Entry<String, String>> its = parameter.iterator();
			while (its.hasNext()) {
				Entry<String, String> param = its.next();

				for (MuConfigUtils util : map) {
					if (util.getSection().equals(section)) {
						for (MuConfigSectionUtils sectUtil : util
								.getMuConfigSection()) {
							if (sectUtil.getKey().equals(param.getKey())) {
								assertEquals(0, sectUtil.getMuConfigItems()
										.size());
								return;
							}
						}
					}
				}
			}
		}
		fail();
	}
}
