package jp.co.nec.aim.sm.common.worker;

import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import jp.co.nec.aim.sm.common.constant.ProcessType;
import jp.co.nec.aim.sm.common.threadpool.ProcessMsg;
import jp.co.nec.aim.sm.common.utils.SMUtil;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.UnitPojo;
import jp.co.nec.aim.sm.unitcontrol.dispatcher.MessageManager;
import jp.co.nec.aim.sm.unitcontrol.dispatcher.RemoteTasksDispatcher;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

public class RemoteAssigntasksTest {

	private ProcessType action;
	private static List<UnitPojo> mulist = new ArrayList<UnitPojo>();

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		long id = 1;
		for (int i = 0; i < 15; i++) {
			UnitPojo pidUnit = new UnitPojo();
			pidUnit.setId(id + i);
			pidUnit.setContactURL("http://127.0.0.1:8080/");
			pidUnit.setState("TIMED_OUT");
			if (i % 4 == 0) {
				pidUnit.setType("MM");
			} else if (i % 4 == 1) {
				pidUnit.setType("DM");
			} else if (i % 4 == 2) {
				pidUnit.setType("MU");
			} else if (i % 4 == 3) {
				pidUnit.setType("SM");
			}
			pidUnit.setUniqueId("127.0.0.1");
			pidUnit.setVersion("4.0.0");
			mulist.add(pidUnit);
		}
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Ignore
	@Test
	public void test_SM() {
		final MessageManager manager = MessageManager.newInstance();
		action = ProcessType.START;
		RemoteTasksDispatcher remoteassigntasks = new RemoteTasksDispatcher(
				mulist, action, manager);
		remoteassigntasks.execute();
		ProcessMsg psg = new ProcessMsg();
		while (true) {
			psg = manager.getpMsg();
			if (!SMUtil.isObjectNull(psg)) {
				if (psg.isFlag()) {
					break;
				}
			}
		}
		assertTrue(psg.isFlag());
	}
}
