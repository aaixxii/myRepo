package jp.co.nec.aim.sm.modules.sys.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.sql.DataSource;

import jp.co.nec.aim.sm.modules.sys.oracle.entities.PreviousCompletedJobCounter;
import jp.co.nec.aim.sm.modules.sys.oracle.repository.MonitorRepository;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional(value = "oracleTXManager")
public class MonitorServiceTest {	
	@Autowired
	private MonitorRepository monitorRepository;
	@Autowired
	private MonitorService monitorService;

	@Autowired
	@Qualifier("oracleDataSource")
	DataSource datasource;

	JdbcTemplate jdbcTemplate;

	@Before
	public void setUp() throws Exception {
		jdbcTemplate = new JdbcTemplate(datasource);
		clear();
	}

	@After
	public void tearDown() throws Exception {
		clear();
	}

	@Test
	public void testGetComponentStatusData() {
		String insertMM = "insert into MATCH_MANAGERS(mm_id,unique_id,state) values(?,?,?)";
		String insertMR = "insert into MAP_REDUCERS(mr_id,unique_id,state) values(?,?,?)";
		String insertDM = "insert into DATA_MANAGERS(dm_id,unique_id,state) values(?,?,?)";
		String insertMU = "insert into MATCH_UNITS(mu_id,unique_id,state) values(?,?,?)";

		Long[] mmIds = { 100L, 101L, 102L };
		Long[] mrIds = { 200L, 201L, 202L, 203L, 204L };
		Long[] dmIds = { 300L, 301L, 302L };
		Long[] muIds = { 400L, 401L, 402L, 403L, 404L, 405L, 406L };
		String[] mmStauts = { "working", "timeout", "exit" };
		String[] mrStauts = { "working", "working", "timeout", "timeout",
				"exit" };
		String[] dmStauts = { "working", "exit", "timeout" };
		String[] muStauts = { "working", "working", "working", "timeout",
				"exit", "exit", "exit" };
		for (int i = 0; i < mmIds.length; i++) {
			jdbcTemplate.update(insertMM,
					new Object[] { mmIds[i], String.valueOf(mmIds[i]),
							mmStauts[i] });
		}
		for (int i = 0; i < mrIds.length; i++) {
			jdbcTemplate.update(insertMR,
					new Object[] { mrIds[i], String.valueOf(mrIds[i]),
							mrStauts[i] });
		}
		for (int i = 0; i < dmIds.length; i++) {
			jdbcTemplate.update(insertDM,
					new Object[] { dmIds[i], String.valueOf(dmIds[i]),
							dmStauts[i] });
		}
		for (int i = 0; i < muIds.length; i++) {
			jdbcTemplate.update(insertMU,
					new Object[] { muIds[i], String.valueOf(muIds[i]),
							muStauts[i] });
		}
		jdbcTemplate.execute("commit");
		Map<String, Map<String, Integer>> results = monitorService
				.getComponentStatusData();
		assertNotNull(results);
		assertEquals(4, results.size());
		Set<Entry<String, Map<String, Integer>>> mapSet = results.entrySet();
		Iterator<Entry<String, Map<String, Integer>>> it = mapSet.iterator();
		while (it.hasNext()) {
			Entry<String, Map<String, Integer>> temp = it.next();
			String key = temp.getKey();
			Map<String, Integer> subMap = temp.getValue();
			switch (key) {
			case "mm":
				assertSubComponentMapValue(subMap, 1, 1, 1);
				break;
			case "mr":
				assertSubComponentMapValue(subMap, 2, 2, 1);
				break;
			case "dm":
				assertSubComponentMapValue(subMap, 1, 1, 1);
				break;
			case "mu":
				assertSubComponentMapValue(subMap, 3, 1, 3);
				break;
			}
		}
		System.out.println(pringJson(results));
	}

	@Test
	public void testGetComponentStatusData_null() {
		Map<String, Map<String, Integer>> results = monitorService
				.getComponentStatusData();
		assertNull(results);
	}

	@Test
	public void testGetDBMonitorData() {
		String insertsql = ""
				+ "insert into PERSON_BIOMETRICS(BIOMETRICS_ID,EXTERNAL_ID,BIOMETRIC_DATA,"
				+ "BIOMETRIC_DATA_LEN,REGISTED_TS,CORRUPTED_FLAG,EVENT_ID,CONTAINER_ID)"
				+ " values(?,?,HEXTORAW('3E00210102CDA000C9'),50,1000,0,?,?)";				
		Long[] pbioIds = { 1000L, 1001L, 1002L, 1003L, 1004L, 1005L, 1006L,
				1007L };
		Integer[] containerIds = { 1, 1, 331, 331, 332, 3, 4, 336 };
		for (int i = 0; i < pbioIds.length; i++) {
			jdbcTemplate.update(insertsql,
					new Object[] { pbioIds[i], String.valueOf(pbioIds[i]),
							i + 1, containerIds[i] });
		}
		
		String insSegTabSql = "insert into segments(segment_id,container_id,bio_id_start,bio_id_end,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)"
				+ " values(?,?,?,?,333,1,?,?,333)";		
		Long segmentIds[] = {2000L,2001L,2002L,2003L,2004L,2005L,2006L,2007L};
		for (int i = 0 ;i < segmentIds.length; i++) {
			jdbcTemplate.update(insSegTabSql,new Object[] {segmentIds[i],containerIds[i],pbioIds[i], pbioIds[i],i,i});
		}
		
		jdbcTemplate.execute("commit");
		Integer scope = 1;
		Map<String, Map<String, Integer>> results = monitorService
				.getDBMonitorData(scope);
		assertNotNull(results);
		assertEquals(2, results.size());
		Map<String, Integer> tenprintMap = results.get("tenprintMonitor");
		Map<String, Integer> tenprintResults = new HashMap<>();
		tenprintResults.put("SDBTM", 1);
		tenprintResults.put("RDBT", 2);
		tenprintResults.put("RDBTM", 2);
		assertDBMonitorSubMap(tenprintMap, "SDBTM", 1, "RDBT", 2, "RDBTM", 2);
		Map<String, Integer> latentMap = results.get("latentMonitor");
		assertDBMonitorSubMap(latentMap, "LDBM", 1, "SDBL", 1, "RDBL", 1);
		System.out.println(pringJson(results));
	}

	@Test	
	public void testGetTransactionMonitorData() {
		String updateInquerySql = "update inquiry_traffic set job_complete_count= 2";		
		jdbcTemplate.update(updateInquerySql);		
		jdbcTemplate.execute("commit");
		String extractSql = "insert into extract_complete_count(complete_count,complete_ts) values(5,300)";
		jdbcTemplate.update(extractSql);	
		jdbcTemplate.execute("commit");
		PreviousCompletedJobCounter preJobCounter = PreviousCompletedJobCounter.getInstance() ;
		Map<String, Long> preMap = preJobCounter.getPreCompleteJobMap();
		int valueOfTI = preMap.get("TI").intValue();
		int valueOfLI = preMap.get("LI").intValue();
		int valueOfTLI = preMap.get("TLI").intValue();
		int valueOfLLI = preMap.get("LLI").intValue();
		int valueOfLIP = preMap.get("LIP").intValue();
		int valueOfTLIP = preMap.get("TLIP").intValue();
		int valueOfLLIP = preMap.get("LLIP").intValue();
		int valueOfFI = preMap.get("FI").intValue();
		int valueOfII = preMap.get("II").intValue();
		int valueOfEXTRACT = preMap.get("EXTRACT").intValue();
		Map<String, Map<String, Long>> results = monitorService
				.getTransactionMonitorData();
		assertNotNull(results);
		assertEquals(3, results.size());
		Map<String, Long> tenprintMap = results.get("tenprintFunction");
		assertTrue(tenprintMap.containsKey("TLI"));
		assertTrue(tenprintMap.containsKey("II"));
		assertTrue(tenprintMap.containsKey("TLIP"));
		assertTrue(tenprintMap.containsKey("TI"));
		assertTrue(tenprintMap.containsKey("FI"));	
		
		Map<String, Long> lastMap = preJobCounter.getPreCompleteJobMap();
		
		Set<String> tenprintkeys = tenprintMap.keySet();
		Iterator<String> it = tenprintkeys.iterator();
		while (it.hasNext()) {
			String key = it.next();
			switch (key) {
			case "TI":								
				assertEquals((valueOfTI + tenprintMap.get("TI").intValue()),lastMap.get("TI").intValue());
				break;	
			case "TLI":				
				assertEquals((valueOfTLI + tenprintMap.get(key).intValue()),lastMap.get("TLI").intValue());
				break;	
			case "TLIP":				
				assertEquals((valueOfTLIP + tenprintMap.get(key).intValue()),lastMap.get("TLIP").intValue());
				break;

			case "FI":				
				assertEquals((valueOfFI + tenprintMap.get(key).intValue()),lastMap.get("FI").intValue());
				break;
			case "II":				
				assertEquals((valueOfII + tenprintMap.get(key).intValue()),lastMap.get("II").intValue());
				break;	
			}
		}	

		Map<String, Long> latentMap = results.get("latentFunction");
		assertTrue(latentMap.containsKey("LLIP"));
		assertTrue(latentMap.containsKey("LI"));
		assertTrue(latentMap.containsKey("LLI"));
		assertTrue(latentMap.containsKey("LIP"));
		
		Set<String> latentKeys = latentMap.keySet();
		Iterator<String> itLatent = latentKeys.iterator();
		while (itLatent.hasNext()) {
			String key  = itLatent.next();
			switch (key) {	
			case "LI":				
				assertEquals((valueOfLI + latentMap.get(key).intValue()),lastMap.get("LI").intValue());
				break;
			case "LLI":				
				assertEquals((valueOfLLI + latentMap.get(key).intValue()),lastMap.get("LLI").intValue());
				break;
			case "LIP":				
				assertEquals((valueOfLIP + latentMap.get(key).intValue()),lastMap.get("LIP").intValue());
				break;
			case "LLIP":				
				assertEquals((valueOfLLIP + latentMap.get(key).intValue()),lastMap.get("LLIP").intValue());
				break;
			}
		}

		Map<String, Long> extractMap = results.get("extract");
		assertEquals(10,
				tenprintMap.size() + (latentMap.size() + extractMap.size()));
		assertEquals(1, extractMap.size());
		Iterator<Entry<String, Long>> extractIt = extractMap.entrySet().iterator();
		Entry<String, Long> tmp = extractIt.next();
		assertEquals(tmp.getKey(), "EXTRACT");		
		assertEquals((valueOfEXTRACT + extractMap.get("EXTRACT").intValue()),lastMap.get("EXTRACT").intValue());
		System.out.println(pringJson(results));	
	}

	@Test
	public void testGetMuInqueryLoadData() {
		String insertMuSql = "insert into MATCH_UNITS(mu_id,unique_id,state) values(?,?,'WORKING')";		
		String insertMuInquiyLoadSql = "insert into MU_INQUIRY_LOAD(mu_id,pressure,report_ts) values(?,?,1005)";
		Long[] muIds = { 1000L, 1002L, 1003L, 1004L, 1005L };
		Long muInquiryLoad[] = { 10L, 11L, 12L, 13L, 14L };
		for (int i = 0; i < muIds.length; i++) {
			jdbcTemplate.update(insertMuSql,
					new Object[] { muIds[i], String.valueOf(muIds[i]) });	
			jdbcTemplate.update(insertMuInquiyLoadSql, new Object[] { muIds[i],
					muInquiryLoad[i] });
		}
		jdbcTemplate.execute("commit");
		Map<String, Long> results = monitorService.getMuInquiryLoadData();
		assertNotNull(results);
		assertEquals(5, results.size());
		assertTrue(results.containsKey("1000"));
		assertTrue(results.containsKey("1002"));
		assertTrue(results.containsKey("1003"));
		assertTrue(results.containsKey("1004"));
		assertTrue(results.containsKey("1005"));
		assertEquals(10, results.get("1000").intValue());
		assertEquals(11, results.get("1002").intValue());
		assertEquals(12, results.get("1003").intValue());
		assertEquals(13, results.get("1004").intValue());
		assertEquals(14, results.get("1005").intValue());
		System.out.println(pringJson(results));
	}
	
	@Test
	public void testGetExtractMuLoadData() {
		String insertMuSql = "insert into MATCH_UNITS(mu_id,unique_id,state) values(?,?,'WORKING')";
		String insertMuExtractLoadSql = "insert into MU_EXTRACT_LOAD(mu_id,pressure,update_ts) values(?,?,1000)";		
		Long[] muIds = { 1000L, 1002L, 1003L, 1004L, 1005L };
		Long muExtractLoad[] = { 5L, 6L, 7L, 8L, 9L };		
		for (int i = 0; i < muIds.length; i++) {
			jdbcTemplate.update(insertMuSql,
					new Object[] { muIds[i], String.valueOf(muIds[i]) });
			jdbcTemplate.update(insertMuExtractLoadSql, new Object[] {
					muIds[i], muExtractLoad[i] });		
		}
		jdbcTemplate.execute("commit");
		Map<String, Long> results = monitorService.getMuExtractLoadData();
		assertNotNull(results);
		assertEquals(5, results.size());
		assertTrue(results.containsKey("1000"));
		assertTrue(results.containsKey("1002"));
		assertTrue(results.containsKey("1003"));
		assertTrue(results.containsKey("1004"));
		assertTrue(results.containsKey("1005"));
		assertEquals(5, results.get("1000").intValue());
		assertEquals(6, results.get("1002").intValue());
		assertEquals(7, results.get("1003").intValue());
		assertEquals(8, results.get("1004").intValue());
		assertEquals(9, results.get("1005").intValue());
		System.out.println(pringJson(results));
	}

	public void assertDBMonitorSubMap(Map<String, Integer> subMap, String key1,
			int value1, String key2, int value2, String key3, int value3) {
		assertEquals(subMap.get(key1).intValue(), value1);
		assertEquals(subMap.get(key2).intValue(), value2);
		assertEquals(subMap.get(key3).intValue(), value3);
	}

	public void assertSubComponentMapValue(Map<String, Integer> subMap,
			int workingValue, int timeoutValue, int exitValue) {
		Set<Entry<String, Integer>> subMapSet = subMap.entrySet();
		Iterator<Entry<String, Integer>> subIt = subMapSet.iterator();
		while (subIt.hasNext()) {
			Entry<String, Integer> subTemp = subIt.next();
			String subKey = subTemp.getKey();
			Integer subValue = subTemp.getValue();
			switch (subKey) {
			case "working":
				assertEquals(workingValue, subValue.intValue());
				break;
			case "timeout":
				assertEquals(timeoutValue, subValue.intValue());
				break;
			case "exit":
				assertEquals(exitValue, subValue.intValue());
				break;
			}
		}		
	}
	
	@Test
	public void testGetSlbStatus() {
		String sql = "insert into SYSTEM_CONFIG(CONFIG_ID, PROPERTY_NAME,PROPERTY_VALUE) values(3000,'LOAD_BALANCER.ENABLED','true')";
		jdbcTemplate.execute(sql);
		Map<String, Boolean> result = monitorService.getSlbStatus();
		assertEquals(1,result.size());
		Set<Entry<String, Boolean>> tmp = result.entrySet();
		Iterator<Entry<String, Boolean>> it = tmp.iterator();		
		Entry<String, Boolean> res = it.next();
		assertEquals("slb",res.getKey());
		assertEquals(new Boolean("true"),res.getValue());		
		System.out.println(pringJson(result));		
		
	}	

	public void clear() {
		jdbcTemplate.execute("delete from MATCH_MANAGERS");
		jdbcTemplate.execute("delete from MAP_REDUCERS");
		jdbcTemplate.execute("delete from DATA_MANAGERS");
		jdbcTemplate.execute("delete from FE_JOB_QUEUE");
		jdbcTemplate.execute("delete from FE_LOT_JOBS");
		jdbcTemplate.execute("delete from MATCH_UNITS");
		jdbcTemplate.execute("delete from JOB_QUEUE");
		jdbcTemplate.execute("delete from PERSON_BIOMETRICS");
		jdbcTemplate.execute("delete from MU_EXTRACT_LOAD");
		jdbcTemplate.execute("delete from MU_EXTRACT_LOAD");
		jdbcTemplate.execute("delete from SYSTEM_CONFIG");
		jdbcTemplate.execute("delete from segments");
		jdbcTemplate.execute("delete from  extract_complete_count ");
		jdbcTemplate.execute("update inquiry_traffic set job_complete_count= 0");		
		jdbcTemplate.execute("commit");
	}
	
	public String pringJson( Object object) {
		ObjectMapper mapper = new ObjectMapper();
        String jsonStr = null;
		try {
			jsonStr = mapper.writerWithDefaultPrettyPrinter()
			        .writeValueAsString(object);
		} catch (JsonProcessingException e) {			
			e.printStackTrace();
		}
		return jsonStr;		
	}

}
