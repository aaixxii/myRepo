package jp.co.nec.aim.sm.common.persistence;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import jp.co.nec.aim.sm.modules.sys.postgres.entity.JobQueueEntity;

import org.junit.Test;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

public class PageTest {

	@Test
	public void testPage_1() {
		MockHttpServletRequest request = new MockHttpServletRequest();
		MockHttpServletResponse response = new MockHttpServletResponse();

		request.setParameter("pageNo", "1");
		request.setParameter("pageSize", "10");
		request.setParameter("orderBy", "10");

		Page<BaseEntity> page1 = new Page<BaseEntity>(request, response);

		assertEquals(1, page1.getPageNo());
		assertEquals(10, page1.getPageSize());
		assertEquals("10", page1.getOrderBy());
	}

	@Test
	public void testPage_2() {
		MockHttpServletRequest request = new MockHttpServletRequest();
		MockHttpServletResponse response = new MockHttpServletResponse();

		request.setParameter("pageNo", "1");
		request.setParameter("pageSize", "10");
		request.setParameter("orderBy", "10");

		Page<BaseEntity> page1 = new Page<BaseEntity>(request, response, 2);

		assertEquals(1, page1.getPageNo());
		assertEquals(2, page1.getPageSize());
		assertEquals("10", page1.getOrderBy());
	}

	@Test
	public void testPage_3() {
		Page<BaseEntity> page1 = new Page<BaseEntity>(1, 10);

		assertEquals(1, page1.getPageNo());
		assertEquals(10, page1.getPageSize());
		assertEquals(0, page1.getCount());
		assertEquals(0, page1.getList().size());
		assertEquals("", page1.getOrderBy());
	}

	@Test
	public void testPage_4() {
		Page<BaseEntity> page1 = new Page<BaseEntity>(1, 1000, 10);

		assertEquals(1, page1.getPageNo());
		assertEquals(1000, page1.getPageSize());
		assertEquals(10, page1.getCount());
		assertEquals(0, page1.getList().size());
		assertEquals("", page1.getOrderBy());
	}

	@Test
	public void testPage_5() {
		List<JobQueueEntity> list = new ArrayList<JobQueueEntity>();
		for (int i = 0; i < 5; i++) {
			list.add(new JobQueueEntity());
		}
		Page<JobQueueEntity> page1 = new Page<JobQueueEntity>(1, -10, 10, list);

		assertEquals(1, page1.getPageNo());
		assertEquals(-10, page1.getPageSize());
		assertEquals(10, page1.getCount());
		assertEquals(5, page1.getList().size());
		assertEquals("", page1.getOrderBy());
	}

	@Test
	public void testInitialize_1() {
		Page<JobQueueEntity> page1 = new Page<JobQueueEntity>(0, 10, 15);

		page1.initialize();

		assertEquals(1, page1.getPageNo());
		assertEquals(1, page1.getFirst());
		assertEquals(2, page1.getLast());
		assertTrue(page1.isFirstPage());
	}

	@Test
	public void testInitialize_2() {
		Page<JobQueueEntity> page1 = new Page<JobQueueEntity>(1, 10, -20);

		page1.initialize();

		assertEquals(1, page1.getPageNo());
		assertEquals(1, page1.getFirst());
		assertEquals(1, page1.getLast());
		assertEquals(1, page1.getNext());
		assertEquals(1, page1.getPrev());
		assertTrue(page1.isFirstPage());
		assertTrue(page1.isLastPage());
		assertEquals(0, page1.getFirstResult());
	}

	@Test
	public void testInitialize_3() {
		Page<JobQueueEntity> page1 = new Page<JobQueueEntity>(2, 5, 20);

		page1.initialize();

		assertEquals(2, page1.getPageNo());
		assertEquals(1, page1.getFirst());
		assertEquals(4, page1.getLast());
		assertEquals(3, page1.getNext());
		assertEquals(1, page1.getPrev());
		assertTrue(!page1.isFirstPage());
		assertTrue(!page1.isLastPage());
		assertEquals(4, page1.getTotalPage());
	}

	@Test
	public void testToString_1() {
		Page<JobQueueEntity> page1 = new Page<JobQueueEntity>(1, 5, 10);

		String str = page1.toString();

		assertEquals(665, str.length());
	}

	@Test
	public void testToString_2() {
		Page<JobQueueEntity> page1 = new Page<JobQueueEntity>(7, 5, 60);

		String str = page1.toString();

		assertEquals(1151, str.length());
	}

	@Test
	public void testToString_3() {
		Page<JobQueueEntity> page1 = new Page<JobQueueEntity>(2, 5, 10);

		String str = page1.toString();

		assertEquals(665, str.length());
	}

	@Test
	public void testGetSpringPage() {
		List<JobQueueEntity> list = new ArrayList<JobQueueEntity>();
		for (int i = 0; i < 10; i++) {
			list.add(new JobQueueEntity());
		}
		PageImpl<JobQueueEntity> page = new PageImpl<JobQueueEntity>(list);
		Page<JobQueueEntity> page1 = new Page<JobQueueEntity>(2, 5, 10);
		page1.setSpringPage(page);
		page1.setPageNo(2);
		page1.setPageSize(5);
		page1.setOrderBy("JOB_ID, JOB_STATE DESC, RESULTS_TS ASC");
		Pageable pageable = page1.getSpringPage();

		assertEquals(5, pageable.getPageSize());
		assertEquals(1, pageable.getPageNumber());
	}

}
