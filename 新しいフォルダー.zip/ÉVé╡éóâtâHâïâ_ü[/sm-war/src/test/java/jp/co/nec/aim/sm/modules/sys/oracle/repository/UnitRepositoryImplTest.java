package jp.co.nec.aim.sm.modules.sys.oracle.repository;

import javax.sql.DataSource;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@Ignore
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional(value = "oracleTXManager")
public class UnitRepositoryImplTest {
	@Autowired
	MatchUnitRepository repository;

	@Autowired
	@Qualifier("oracleDataSource")
	DataSource datasource;

	JdbcTemplate jdbcTemplate;

	@Before
	public void before() {
		jdbcTemplate = new JdbcTemplate(datasource);
		cleanDB();
		prepareDB();
	}

	@After
	public void after() {
		cleanDB();
	}

	private void cleanDB() {
		jdbcTemplate.execute("delete from MU_JOBS");
		jdbcTemplate.execute("delete from MATCH_UNITS");
		jdbcTemplate.execute("commit");
	}

	private void prepareDB() {
		for (int i = 1; i <= 6; i++) {
			for (int j = 0; j <= 2; j++) {
				String sql = "insert into MATCH_UNITS(MU_ID, UNIQUE_ID, "
						+ "CONTACT_URL, STATE, TYPE, REVISION, BALANCED_FLAG,"
						+ " VERSION) values(" + (i * 4 + j) + ", 'uniqueId_"
						+ i + "', 'ContactURL_" + i + "', 'TIMED_OUT', " + j
						+ ", 1, 0, '4.0.0')";
				jdbcTemplate.execute(sql);
			}
		}
	}

	// @Test
	// public void testGetAllUnits() {
	// Page<MatchUnitEntity> page = new Page<MatchUnitEntity>(1, 30);
	// MatchUnitEntity muEntity = new MatchUnitEntity();
	// muEntity.setMuId(4L);
	// muEntity.setType(UnitType.MU);
	// muEntity.setState(UnitState.TIMED_OUT);
	// Page<MatchUnitEntity> pageResult = repository.getAllUnits(page,
	// muEntity);
	//
	// assertEquals(1, pageResult.getList().size());
	// }
	//
	// @Test
	// public void testCountByUnitType() {
	//
	// long count = repository.countByUnitType(UnitType.MU);
	//
	// assertEquals(6, count);
	// }
	//
	// @Test
	// public void testGetUnitType() {
	//
	// List<UnitType> list = repository.getUnitType();
	//
	// assertEquals(3, list.size());
	// }
	//
	// @Test
	// public void testGetAllBalanceableUnitIds() {
	// List<Long> list = repository.getAllBalanceableUnitIds();
	//
	// assertEquals(12, list.size());
	// }
}
