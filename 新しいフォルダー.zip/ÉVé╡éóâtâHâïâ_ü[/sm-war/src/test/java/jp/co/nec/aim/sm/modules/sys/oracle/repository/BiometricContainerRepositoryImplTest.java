package jp.co.nec.aim.sm.modules.sys.oracle.repository;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.ContainerEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.BiometricContainerPojo;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional(value = "oracleTXManager")
public class BiometricContainerRepositoryImplTest {
	@Autowired
	BiometricContainerRepository repository;

	@Autowired
	@Qualifier("oracleDataSource")
	DataSource datasource;

	JdbcTemplate jdbcTemplate;

	String[] formatName = new String[] { "RDBT", "RDBL", "LDB", "PBLNF" };

	@Before
	public void before() {
		jdbcTemplate = new JdbcTemplate(datasource);
		cleanDB();
		// prepareDB();
	}

	@After
	public void after() {
		cleanDB();
	}

	private void cleanDB() {
		jdbcTemplate.execute("delete from JOB_QUEUE");
		jdbcTemplate.execute("delete from PERSON_BIOMETRICS");
		jdbcTemplate.execute("commit");

	}

	@Test
	public void testFindBiometricContainerPage_2() {
		String sql = "select CONTAINER_ID as binId, FORMAT_NAME as format,"
				+ " MIN_REDUNDANCY as minimumRedundancy"
				+ " from CONTAINERS b, FORMAT_TYPES ft "
				+ " where b.FORMAT_ID = ft.FORMAT_ID"
                                +  " and CONTAINER_ID=1"
                               +  " and FORMAT_NAME = 'RDBT' "                               
                               +  "order by CONTAINER_ID";
		
		List<Map<String, Object>> resultList = jdbcTemplate.queryForList(sql);
		//BigDecimal containerId = (BigDecimal) resultList.get(0).get("binId");
		BigDecimal minimumRedundancy = (BigDecimal) resultList.get(0).get("minimumRedundancy");		

		Page<BiometricContainerPojo> page = new Page<BiometricContainerPojo>(1,
				10);
		BiometricContainerPojo entity = new BiometricContainerPojo();
		entity.setBinId(1l);
		entity.setFormat("RDBT");
		Page<BiometricContainerPojo> pageResult = repository
				.findBiometricContainerPage(page, entity);

		assertEquals(1, pageResult.getList().size());
		assertEquals(minimumRedundancy.intValue(), pageResult.getList().get(0).getMinimumRedundancy()
				.intValue());
	}

	@Test
	public void testUpdateBiometricContainer() {
		int count = repository.updateBiometricContainer(1l, "RDBT", 3L, 1L, 1L);

		assertEquals(1, count);

		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from CONTAINERS where CONTAINER_ID = 1 and CONTAINER_NAME = 'RDBT'");
		assertEquals(1, list.size());
		assertEquals("1", list.get(0).get("CONTAINER_ID").toString());
		assertEquals("3", list.get(0).get("MIN_REDUNDANCY").toString());
	}

	@Test
	public void testGetAllBin() {

		List<Long> list = repository.getAllContainers();

		assertEquals(19, list.size());
		for (long i = 1; i <= 4; i++) {
			assertTrue(list.contains(i));
		}
	}
	
	@Test
	public void testGetDmEligibleBinList() {
		clearDmDB();
		 prepareDmDB();
		List<ContainerEntity> resulst = repository.getDmEligibleBinList(1L);
		Assert.assertEquals(4, resulst.size());		
		clearDmDB();
	}
	
	private void prepareDmDB() {
		for (int i = 1; i <= 4; i++) {
			String sql = "insert into DATA_MANAGERS(DM_ID, UNIQUE_ID, STATE"
					+ ") values(" + i + ", 'unique_" + i + "', 'WORKING')";
			jdbcTemplate.execute(sql);
		}

		for (int i = 1; i <= 4; i++) {
			String sql = "insert into DM_ELIGIBLE_CONTAINERS(DM_ID, CONTAINER_ID"
					+ ") values(" + 1 + ", " + i + ")";
			jdbcTemplate.execute(sql);
		}
		jdbcTemplate.execute("commit");
	}
	
	private void clearDmDB() {
		jdbcTemplate.execute("delete from DATA_MANAGERS");
		jdbcTemplate.execute("delete from Dm_ELIGIBLE_CONTAINERS");
		jdbcTemplate.execute("delete from SYSTEM_CONFIG");
		jdbcTemplate.execute("commit");

	}
}
