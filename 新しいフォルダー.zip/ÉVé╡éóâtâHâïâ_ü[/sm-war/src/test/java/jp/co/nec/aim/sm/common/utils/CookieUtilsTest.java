package jp.co.nec.aim.sm.common.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import javax.servlet.http.Cookie;

import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

public class CookieUtilsTest {

	@Test
	public void testSetCookie_1() {
		MockHttpServletResponse response = new MockHttpServletResponse();

		CookieUtils.setCookie(response, "name", "value", 60 * 60 * 24);

		Cookie cookie = response.getCookie("name");

		assertEquals("value", cookie.getValue());
		assertEquals(60 * 60 * 24, cookie.getMaxAge());
	}

	@Test
	public void testSetCookie_2() {
		MockHttpServletResponse response = new MockHttpServletResponse();

		CookieUtils.setCookie(response, "name", "value");

		Cookie cookie = response.getCookie("name");

		assertEquals("value", cookie.getValue());
		assertEquals(60 * 60 * 24, cookie.getMaxAge());
	}

	@Test
	public void testGetCookie_1() {
		MockHttpServletRequest request = new MockHttpServletRequest();

		String value = CookieUtils.getCookie(request, "name");

		assertNull(value);
	}

	@Test
	public void testGetCookie_2() {
		MockHttpServletRequest request = new MockHttpServletRequest();
		Cookie cookie = new Cookie("name", "value");
		request.setCookies(cookie);

		String value = CookieUtils.getCookie(request, "name");

		assertEquals("value", value);
	}

	@Test
	public void testGetCookie_3() {
		MockHttpServletRequest request = new MockHttpServletRequest();
		MockHttpServletResponse response = new MockHttpServletResponse();

		Cookie cookie = new Cookie("name", "value");
		request.setCookies(cookie);

		String value = CookieUtils.getCookie(request, response, "name");

		assertEquals("value", value);
		
		Cookie responseCookie = response.getCookie("name");
		assertEquals("value", responseCookie.getValue());
	}

	@Test
	public void testGetCookie_4() {
		MockHttpServletRequest request = new MockHttpServletRequest();
		MockHttpServletResponse response = new MockHttpServletResponse();

		Cookie cookie = new Cookie("name", "value");
		request.setCookies(cookie);

		String value = CookieUtils.getCookie(request, response, "name", true);

		assertEquals("value", value);
		
		Cookie responseCookie = response.getCookie("name");
		assertEquals("value", responseCookie.getValue());
	}

}
