package jp.co.nec.aim.sm.common.worker;

import static org.junit.Assert.assertEquals;

import java.net.URL;
import java.util.List;

import jp.co.nec.aim.sm.common.utils.MuConfigSectionUtils;
import jp.co.nec.aim.sm.common.utils.MuConfigUtils;
import mockit.Deencapsulation;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;


public class MuParameterDictionaryTest {
	
	private static final String[] muSections = 
	                              {"System", "ProcessMonitor", "HTTP", "ThreadPool", "Paths", "ProcessMonitor", "Log", "Manager", "ChildProc", "TI", "TI-M",
			                        "LI", "LI-S", "LI-M", "LI-X", "LI-P", "TLI", "TLI-S", "TLI-M", "TLI-X", "TLI-P", 
			                        "LLI", "LLI-S", "LLI-M", "LLI-X", "LLI-P", "FI", "II", "ImageDownload", "SVT", "QC", 
			                        "CoreEngine", "Finger", "Palm", "Face", "Iris"
	                               };	

	
	private static final String[][] system = {
                                              {"AppPath", "^(\\/.*)$", "view"},                                             
                                              {"MyIpAddress", "^(\\d|[01]?\\d\\d|2[0-4]\\d|25[0-5])\\.(\\d|[01]?\\d\\d|2[0-4]\\d|25[0-5])\\.(\\d|[01]?\\d\\d|2[0-4]\\d|25[0-5])\\.(\\d|[01]?\\d\\d|2[0-4]\\d|25[0-5])$", "view"},
                                              {"MyPort", "^(0|[1-9]\\d*)$", "view"},	
                                              {"MaxCacheSize", "^(0|[1-9]\\d*)$", "view"},
                                              {"DiskSpaceLowThreshold", "^(0|[1-9]\\d*)$", "writable"},
                                              {"DiskSpaceCriticalThreshold", "^(0|[1-9]\\d*)$", "writable"},
                                              {"CPUClock", "^([0-9]\\d*\\.\\d{1,2})$", "hidden"},
                                              {"HyperThreading", "^(on|off)$", "view"},
                                              {"HyperThreadingRate", "^([0-9]\\d*\\.\\d{1,2})$", "hidden"}                                              
											 };
	
	@Before
	public void setUp() throws Exception {
		URL muDicUrl = Thread.currentThread().getContextClassLoader().getResource("MuConfig.dic");
		String muDicFilePath = muDicUrl.getPath();
		
		URL mrDicUrl = Thread.currentThread().getContextClassLoader().getResource("MrConfig.dic");
		String mrDicFilePath = mrDicUrl.getPath();	
		
		Deencapsulation.setField(MatchUnitParameterDictionary.class, "MU_DIC_PATH", muDicFilePath);
		Deencapsulation.setField(MatchUnitParameterDictionary.class, "MR_DIC_PATH", mrDicFilePath);
	}	

	@After
	public void tearDown() throws Exception {
		
	}	
	
	@Test
	public void testMuDicSetion() {
		List<MuConfigUtils> muMap;
		muMap = MatchUnitParameterDictionary.getMatchUnitParameterMap(false);

		assertEquals(35, muMap.size());
		for (int i = 0; i < muSections.length; i++) {
			assertEquals(true, compareSectionName(muMap, muSections[i]));
		}
	}
	
	@Test
	public void testMuRegExpPatterns() {
		List<MuConfigUtils> muMap;
		muMap = MatchUnitParameterDictionary.getMatchUnitParameterMap(false);
		for (MuConfigUtils mt : muMap) {
			if (mt.getSection().equals("System")) {
				List<MuConfigSectionUtils> tmp = mt.getMuConfigSection();
				 for (int i = 0; i < system.length; i++) {
					 assertEquals(true, testConfigItems(tmp, system[i]));
				 }				 
			}
		}
	}
	
	private boolean testConfigItems(List<MuConfigSectionUtils> items, String[] itemArray) {
		int count = 0;
		for (MuConfigSectionUtils itm : items) {
			if (itm.getKey().equals(itemArray[0])
				&&  itm.getRule().equals(itemArray[1])
				&& itm.getType().equals(itemArray[2])) {
				count++;				
			}
		}
		return count == 1 ? true :false;
	}
	
	private boolean compareSectionName(List<MuConfigUtils> muDicList, String oneSection) {		
		int count = 0;
		for (int i = 0; i < muDicList.size(); i++) {
			if (muDicList.get(i).getSection().equals(oneSection)) {
				count++;
			}			
		}
		return count == 1 ? true :false;
	}
}
