package jp.co.nec.aim.sm.modules.sys.web;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.fail;

import java.util.List;

import javax.sql.DataSource;

import jp.co.nec.aim.sm.common.constant.UnitState;
import jp.co.nec.aim.sm.common.constant.UnitType;
import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.MatchUnitEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.UnitPojo;
import jp.co.nec.aim.sm.test.common.util.CommonUtils;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ExtendedModelMap;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional(value = "oracleTXManager")
public class UnitStateControllerTest {

	@Autowired
	UnitStateController unitStateController;
	@Autowired
	@Qualifier("oracleDataSource")
	DataSource datasource;
	JdbcTemplate jdbcTemplate;

	@Before
	public void before() {
		jdbcTemplate = new JdbcTemplate(datasource);
		CommonUtils.DeleteOracleData(jdbcTemplate);
		CommonUtils.prepareMATCH_MANAGERS(jdbcTemplate);
		CommonUtils.prepareMATCH_UNITS(jdbcTemplate);
	}

	@After
	public void after() {
		CommonUtils.DeleteOracleData(jdbcTemplate);
	}

	@Test
	public void testGet() {
		MatchUnitEntity unit = unitStateController.get(21L);

		assertEquals("MU:192.168.100.36", unit.getUniqueId());
		assertEquals("http://192.168.100.36:8080/", unit.getContactUrl());
		assertEquals("WORKING", unit.getState().name());
		assertEquals("3.1.0-SNAPSHOT-I", unit.getVersion());
	}

	@Test
	public void testGet_Null() {
		MatchUnitEntity unit = unitStateController.get(null);

		assertNull(unit.getUniqueId());
		assertNull(unit.getContactUrl());
		assertNull(unit.getState());
		assertNull(unit.getVersion());
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testList() {
		try {
			ExtendedModelMap modelMap = new ExtendedModelMap();
			MatchUnitEntity unit = new MatchUnitEntity();
			MockHttpServletRequest request = new MockHttpServletRequest();
			MockHttpServletResponse response = new MockHttpServletResponse();

			String result = unitStateController.list(null, null, unit, request,
					response, modelMap);

			assertEquals("modules/units/unitlist", result);

			List<String> stateList = (List<String>) modelMap.get("stateList");
			assertEquals(3, stateList.size());

			Page<UnitPojo> page = (Page<UnitPojo>) modelMap.get("page");
			assertEquals(9, page.getList().size());

			assertEquals(unit.toString(), modelMap.get("unit").toString());

		} catch (Exception e) {
			fail();
		}
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testList_01() {
		try {
			ExtendedModelMap modelMap = new ExtendedModelMap();
			MatchUnitEntity unit = new MatchUnitEntity();
			MockHttpServletRequest request = new MockHttpServletRequest();
			MockHttpServletResponse response = new MockHttpServletResponse();
			unit.setMuId(21L);
			String result = unitStateController.list(null, null, unit, request,
					response, modelMap);

			assertEquals("modules/units/unitlist", result);

			List<String> stateList = (List<String>) modelMap.get("stateList");
			assertEquals(3, stateList.size());

			Page<UnitPojo> page = (Page<UnitPojo>) modelMap.get("page");
			assertEquals(1, page.getList().size());

			assertEquals(unit.toString(), modelMap.get("unit").toString());

		} catch (Exception e) {
			fail();
		}
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testList_02() {
		try {
			ExtendedModelMap modelMap = new ExtendedModelMap();
			MatchUnitEntity unit = new MatchUnitEntity();
			MockHttpServletRequest request = new MockHttpServletRequest();
			MockHttpServletResponse response = new MockHttpServletResponse();
			unit.setState(UnitState.WORKING);
			String result = unitStateController.list(null, null, unit, request,
					response, modelMap);

			assertEquals("modules/units/unitlist", result);

			List<String> stateList = (List<String>) modelMap.get("stateList");
			assertEquals(3, stateList.size());

			Page<UnitPojo> page = (Page<UnitPojo>) modelMap.get("page");
			assertEquals(6, page.getList().size());

			assertEquals(unit.toString(), modelMap.get("unit").toString());

		} catch (Exception e) {
			fail();
		}
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testList_03() {
		try {
			ExtendedModelMap modelMap = new ExtendedModelMap();
			MatchUnitEntity unit = new MatchUnitEntity();
			MockHttpServletRequest request = new MockHttpServletRequest();
			MockHttpServletResponse response = new MockHttpServletResponse();
			unit.setType(UnitType.MM);
			String result = unitStateController.list(null, null, unit, request,
					response, modelMap);

			assertEquals("modules/units/unitlist", result);

			List<String> stateList = (List<String>) modelMap.get("stateList");
			assertEquals(3, stateList.size());

			Page<UnitPojo> page = (Page<UnitPojo>) modelMap.get("page");
			assertEquals(3, page.getList().size());

			assertEquals(unit.toString(), modelMap.get("unit").toString());

		} catch (Exception e) {
			fail();
		}
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testList_04() {
		try {
			ExtendedModelMap modelMap = new ExtendedModelMap();
			MatchUnitEntity unit = new MatchUnitEntity();
			MockHttpServletRequest request = new MockHttpServletRequest();
			MockHttpServletResponse response = new MockHttpServletResponse();
			unit.setType(UnitType.MU);
			String result = unitStateController.list(null, null, unit, request,
					response, modelMap);

			assertEquals("modules/units/unitlist", result);

			List<String> stateList = (List<String>) modelMap.get("stateList");
			assertEquals(3, stateList.size());

			Page<UnitPojo> page = (Page<UnitPojo>) modelMap.get("page");
			assertEquals(3, page.getList().size());

			assertEquals(unit.toString(), modelMap.get("unit").toString());

		} catch (Exception e) {
			fail();
		}
	}

	@Test
	public void testForm() {
		ExtendedModelMap modelMap = new ExtendedModelMap();
		String result = unitStateController.form(null, modelMap);

		assertEquals("modules/units/unitlist", result);
		assertNull(modelMap.get("event"));
	}
}
