package jp.co.nec.aim.sm.modules.sys.postgres.repository;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.modules.sys.postgres.entity.EventLogEntity;
import jp.co.nec.aim.sm.modules.sys.postgres.pojo.mapping.EventDetailPojo;
import jp.co.nec.aim.sm.modules.sys.postgres.pojo.mapping.EventLogPojo;
import jp.co.nec.aim.sm.modules.sys.postgres.pojo.mapping.MessageEventPojo;
import jp.co.nec.aim.sm.modules.sys.postgres.pojo.mapping.UnitEventPojo;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional(value = "postgresTXManager")
public class EventLogRepositoryImplTest {

	@Autowired
	private EventLogRepository repository;

	String[] MessageType = { "ERROR", "INFORMATION", "INFORMATION",
			"INFORMATION", "WARNING", "INFORMATION", "SERVICES_STARTED" };

	String msgArray[][] = { { "844000303", "400000" },
			{ "044000300", "100000" }, { "044000300", "100000" },
			{ "044000300", "100000" }, { "144114000", "200000" },
			{ "044000300", "100000" }, { "040000000", "110000" } };

	private String startTime = "2013-07-13 00:00:00";
	private String endTime = "2013-07-13 23:59:59";

	@Before
	public void before() {
		repository.deleteAll();
		String time = "2013-07-13 12:10:10";
		Timestamp ts = Timestamp.valueOf(time);
		for (int i = 0; i < msgArray.length; i++) {
			EventLogEntity eventLogEntity = new EventLogEntity();
			eventLogEntity.setEventId(i + 1);
			eventLogEntity.setMessage("Test Message.");
			eventLogEntity.setMessageCode(msgArray[i][0]);
			eventLogEntity.setCls("jp.co.nec.aim.sm.web.test");
			eventLogEntity.setTimestamp(ts);
			eventLogEntity.setMessageType(msgArray[i][1]);
			eventLogEntity.setUnitId(361l + i);
			repository.saveAndFlush(eventLogEntity);
		}
	}

	@After
	public void after() {
		repository.deleteAll();
	}

	@Test
	public void testGetEvents() {
		EventLogEntity eventLog = new EventLogEntity();
		eventLog.setStartTime(startTime);
		eventLog.setEndTime(endTime);
		List<EventLogPojo> events = repository.getEvents(eventLog);
		assertEquals(4, events.size());
		for (int i = 0; i < 4; i++) {
			if (events.get(i).getMessageType().equals("SERVICES_STARTED")) {
				assertEquals(1, events.get(i).getMessageCount().intValue());
			} else if (events.get(i).getMessageType().equals("ERROR")) {
				assertEquals(1, events.get(i).getMessageCount().intValue());
			} else if (events.get(i).getMessageType().equals("WARNING")) {
				assertEquals(1, events.get(i).getMessageCount().intValue());
			} else if (events.get(i).getMessageType().equals("INFORMATION")) {
				assertEquals(4, events.get(i).getMessageCount().intValue());
			} else {
				fail();
			}
		}
	}

	@Test
	public void testGetUnitEvents() {
		EventLogEntity eventLog = new EventLogEntity();
		eventLog.setStartTime(startTime);
		eventLog.setEndTime(endTime);
		List<UnitEventPojo> events = repository.getUnitEvents(eventLog);
		assertEquals(7, events.size());
		for (int i = 0; i < 7; i++) {
			assertEquals(361l + i, events.get(i).getUnitId().longValue());
			assertEquals(1, events.get(i).getMessageCount().intValue());
			assertEquals(MessageType[i], events.get(i).getMessageType());
		}
	}

	@Test
	public void testGetMessageEvents() {
		EventLogEntity eventLog = new EventLogEntity();
		eventLog.setStartTime(startTime);
		eventLog.setEndTime(endTime);
		List<MessageEventPojo> events = repository.getMessageEvents(eventLog);
		assertEquals(7, events.size());
		for (int i = 0; i < 7; i++) {
			assertEquals(361l + i, events.get(i).getUnitId().longValue());
			assertEquals(msgArray[i][0], events.get(i).getMessageCode());
			assertEquals(1, events.get(i).getMessageCount().intValue());
			assertEquals(MessageType[i], events.get(i).getMessageType());
		}
	}

	@Test
	public void testGetMessageEvents_2() {
		EventLogEntity eventLog = new EventLogEntity();
		eventLog.setStartTime(startTime);
		eventLog.setEndTime(endTime);
		List<MessageEventPojo> events = repository.getMessageEvents(
				new Page<MessageEventPojo>(1, 10), eventLog).getList();
		assertEquals(7, events.size());
		for (int i = 0; i < 7; i++) {
			assertEquals(361l + i, events.get(i).getUnitId().longValue());
			assertEquals(msgArray[i][0], events.get(i).getMessageCode());
			assertEquals(1, events.get(i).getMessageCount().intValue());
			assertEquals(MessageType[i], events.get(i).getMessageType());
		}
	}

	@Test
	public void testGetEventDetail() {
		EventLogEntity eventLog = new EventLogEntity();
		eventLog.setStartTime(startTime);
		eventLog.setEndTime(endTime);
		List<EventDetailPojo> events = repository.getEventDetail(eventLog);
		assertEquals(7, events.size());
		for (int i = 0; i < 7; i++) {
			assertEquals(361l + i, events.get(i).getUnitId().longValue());
			assertEquals(msgArray[i][0], events.get(i).getMessageCode());
			assertEquals("2013/07/13 12:10:10.000", events.get(i)
					.getTimestamp());
			assertEquals(MessageType[i], events.get(i).getMessageType());
			assertEquals("Test Message.", events.get(i).getMessage());
		}
	}

	@Test
	public void testGetEventDetail_2() {
		EventLogEntity eventLog = new EventLogEntity();
		eventLog.setStartTime(startTime);
		eventLog.setEndTime(endTime);
		List<EventDetailPojo> events = repository.getEventDetail(
				new Page<EventDetailPojo>(1, 10), eventLog).getList();
		assertEquals(7, events.size());
		for (int i = 0; i < 7; i++) {
			assertEquals(361l + i, events.get(i).getUnitId().longValue());
			assertEquals(msgArray[i][0], events.get(i).getMessageCode());
			assertEquals("2013/07/13 12:10:10.000", events.get(i)
					.getTimestamp());
			assertEquals(MessageType[i], events.get(i).getMessageType());
			assertEquals("Test Message.", events.get(i).getMessage());
		}
	}

	@Test
	public void testGetEventLogs_Empty() {
		EventLogEntity eventLog = new EventLogEntity();
		eventLog.setEventId(-1);
		eventLog.setUnitId(1l);
		eventLog.setMessageType("INFORMATION");
		List<EventLogEntity> events = repository.getEventLogs(eventLog);
		assertEquals(0, events.size());
	}

	@Test
	public void testGetEventLogs() {
		EventLogEntity eventLog = new EventLogEntity();
		List<EventLogEntity> events = repository.getEventLogs(eventLog);
		assertEquals(7, events.size());
		for (int i = 0; i < 7; i++) {
			assertNotNull(events.get(i).getEventId());
			assertEquals(361l + i, events.get(i).getUnitId().longValue());
			assertEquals(msgArray[i][0], events.get(i).getMessageCode());
			assertEquals("2013-07-13 12:10:10.0", events.get(i).getTimestamp()
					.toString());
			assertEquals(msgArray[i][1], events.get(i).getMessageType());
			assertEquals("Test Message.", events.get(i).getMessage());
		}
	}

	@Test
	public void testGetEventLogs_Empty_2() {
		EventLogEntity eventLog = new EventLogEntity();
		eventLog.setEventId(-1);
		eventLog.setUnitId(1l);
		eventLog.setMessageType("INFORMATION");
		List<EventLogEntity> events = repository.getEventLogs(
				new Page<EventLogEntity>(1, 10), eventLog).getList();
		assertEquals(0, events.size());
	}

	@Test
	public void testGetEventLogs_2() {
		EventLogEntity eventLog = new EventLogEntity();
		List<EventLogEntity> events = repository.getEventLogs(
				new Page<EventLogEntity>(1, 10), eventLog).getList();
		assertEquals(7, events.size());
		for (int i = 0; i < 7; i++) {
			assertNotNull(events.get(i).getEventId());
			assertEquals(361l + i, events.get(i).getUnitId().longValue());
			assertEquals(msgArray[i][0], events.get(i).getMessageCode());
			assertEquals("2013-07-13 12:10:10.0", events.get(i).getTimestamp()
					.toString());
			assertEquals(msgArray[i][1], events.get(i).getMessageType());
			assertEquals("Test Message.", events.get(i).getMessage());
		}
	}
	
	@Test
	public void testGetAlarmInfo() {
		repository.deleteAll();
		Date date = new Date();
		Timestamp timeStamp = new Timestamp(date.getTime());		
		String tmp = timeStamp.toString().substring(0, 18);
		//String time = "2015-06-17 13:30:10";
		Timestamp ts = Timestamp.valueOf(tmp);
		
		for (int i = 0; i < msgArray.length; i++) {
			EventLogEntity eventLogEntity = new EventLogEntity();
			eventLogEntity.setEventId(i + 1);
			eventLogEntity.setMessage("Test Message.");
			eventLogEntity.setMessageCode(msgArray[i][0]);
			eventLogEntity.setCls("jp.co.nec.aim.sm.web.test");
			eventLogEntity.setTimestamp(ts);
			eventLogEntity.setMessageType(msgArray[i][1]);
			eventLogEntity.setUnitId(361l + i);
			repository.saveAndFlush(eventLogEntity);
		}
		Integer timeVale = 100000;
		 String results = repository.getAlarmInfo(timeVale);
		 assertNotNull(results);	
		 assertEquals(ts.toString(),results);
	}
	
	@Test
	public void testGetAlarmInfo_noData() {
		Integer timeVale = 100000;
		 String results = repository.getAlarmInfo(timeVale);
		 assertEquals(null,results);		
	}
	
	@Test
	public void testGetDBTime() {		
	     String results = null;
		 results = repository.getDBTime();;
		 assertNotNull(results); 		
	}	
}
