package jp.co.nec.aim.sm.modules.sys.web;

import static org.junit.Assert.assertEquals;

import javax.sql.DataSource;

import jp.co.nec.aim.sm.common.constant.JobState;
import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.FeJobQueueEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.FusionJob;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.JobPojo;
import jp.co.nec.aim.sm.modules.sys.postgres.entity.JobQueueEntity;
import jp.co.nec.aim.sm.modules.sys.postgres.entity.UserEntity;
import jp.co.nec.aim.sm.modules.sys.util.UserUtils;
import jp.co.nec.aim.sm.test.common.util.CommonUtils;
import mockit.Mock;
import mockit.MockUp;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ExtendedModelMap;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional(value = "oracleTXManager")
public class JobControllerTest {

	@Autowired
	JobController jobController;

	@Autowired
	@Qualifier("oracleDataSource")
	DataSource datasource;

	JdbcTemplate jdbcTemplate;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {

	}

	@Before
	public void setUp() throws Exception {
		jdbcTemplate = new JdbcTemplate(datasource);
		CommonUtils.DeleteOracleData(jdbcTemplate);
		CommonUtils.prepare_JOB(jdbcTemplate);
		CommonUtils.prepareFeJobQueue(jdbcTemplate);
		CommonUtils.prepareFeJobPayload(jdbcTemplate);
	}

	@After
	public void tearDown() throws Exception {
		CommonUtils.DeleteOracleData(jdbcTemplate);
	}

	@Test
	public void test_listJobs() {
		MockUp<UserUtils> mocked = null;
		try {
			mocked = new MockUp<UserUtils>() {
				@Mock
				public UserEntity getUser() {
					return new UserEntity();
				}
			};

			JobPojo job = new JobPojo();
			ExtendedModelMap modelMap = new ExtendedModelMap();
			MockHttpServletRequest request = new MockHttpServletRequest();
			MockHttpServletResponse response = new MockHttpServletResponse();

			String result = jobController.listJobs(null, null, null, job,
					request, response, modelMap);
			assertEquals("modules/jobs/jobslist", result);

			@SuppressWarnings("unchecked")
			Page<JobPojo> pageresult = (Page<JobPojo>) modelMap.get("page");
			assertEquals(1, pageresult.getList().size());
			assertEquals(1, pageresult.getCount());
		} finally {
			mocked.tearDown();
		}
	}

	@Test
	public void test_listJobs_01() {
		MockUp<UserUtils> mocked = null;
		try {
			mocked = new MockUp<UserUtils>() {
				@Mock
				public UserEntity getUser() {
					return new UserEntity();
				}
			};
			JobPojo job = new JobPojo();
			ExtendedModelMap modelMap = new ExtendedModelMap();
			MockHttpServletRequest request = new MockHttpServletRequest();
			MockHttpServletResponse response = new MockHttpServletResponse();
			job.setFunctiontype("LI");
			String result = jobController.listJobs(null, null, null, job,
					request, response, modelMap);
			assertEquals("modules/jobs/jobslist", result);

			@SuppressWarnings("unchecked")
			Page<JobQueueEntity> pageresult = (Page<JobQueueEntity>) modelMap
					.get("page");
			assertEquals(0, pageresult.getList().size());
			assertEquals(0, pageresult.getCount());
		} finally {
			mocked.tearDown();
		}
	}

	@Test
	public void test_listJobs_02() {
		MockUp<UserUtils> mocked = null;
		try {
			mocked = new MockUp<UserUtils>() {
				@Mock
				public UserEntity getUser() {
					return new UserEntity();
				}
			};
			JobPojo job = new JobPojo();
			ExtendedModelMap modelMap = new ExtendedModelMap();
			MockHttpServletRequest request = new MockHttpServletRequest();
			MockHttpServletResponse response = new MockHttpServletResponse();
			job.setFunctiontype("TI");
			String result = jobController.listJobs(null, null, null, job,
					request, response, modelMap);
			assertEquals("modules/jobs/jobslist", result);

			@SuppressWarnings("unchecked")
			Page<JobQueueEntity> pageresult = (Page<JobQueueEntity>) modelMap
					.get("page");
			assertEquals(1, pageresult.getList().size());
			assertEquals(1, pageresult.getCount());
		} finally {
			mocked.tearDown();
		}
	}

	@Test
	public void test_listJobs_03() {
		MockUp<UserUtils> mocked = null;
		try {
			mocked = new MockUp<UserUtils>() {
				@Mock
				public UserEntity getUser() {
					return new UserEntity();
				}
			};
			JobPojo job = new JobPojo();
			ExtendedModelMap modelMap = new ExtendedModelMap();
			MockHttpServletRequest request = new MockHttpServletRequest();
			MockHttpServletResponse response = new MockHttpServletResponse();
			job.setJobid(1l);
			String result = jobController.listJobs(null, null, null, job,
					request, response, modelMap);
			assertEquals("modules/jobs/jobslist", result);

			@SuppressWarnings("unchecked")
			Page<JobQueueEntity> pageresult = (Page<JobQueueEntity>) modelMap
					.get("page");
			assertEquals(1, pageresult.getList().size());
			assertEquals(1, pageresult.getCount());
		} finally {
			mocked.tearDown();
		}
	}

	@Test
	public void test_listJobs_04() {
		MockUp<UserUtils> mocked = null;
		try {
			mocked = new MockUp<UserUtils>() {
				@Mock
				public UserEntity getUser() {
					return new UserEntity();
				}
			};
			JobPojo job = new JobPojo();
			ExtendedModelMap modelMap = new ExtendedModelMap();
			MockHttpServletRequest request = new MockHttpServletRequest();
			MockHttpServletResponse response = new MockHttpServletResponse();
			job.setJobStatus(JobState.WORKING);
			String result = jobController.listJobs(null, null, null, job,
					request, response, modelMap);
			assertEquals("modules/jobs/jobslist", result);

			@SuppressWarnings("unchecked")
			Page<JobQueueEntity> pageresult = (Page<JobQueueEntity>) modelMap
					.get("page");
			assertEquals(1, pageresult.getList().size());
			assertEquals(1, pageresult.getCount());
		} finally {
			mocked.tearDown();
		}
	}

	public void test_listJobs_05() {
		JobPojo job = new JobPojo();
		ExtendedModelMap modelMap = new ExtendedModelMap();
		MockHttpServletRequest request = new MockHttpServletRequest();
		MockHttpServletResponse response = new MockHttpServletResponse();
		job.setFailedFlag(0);
		String result = jobController.listJobs(null, null, null, job, request,
				response, modelMap);
		assertEquals("modules/jobs/jobslist", result);

		@SuppressWarnings("unchecked")
		Page<JobQueueEntity> pageresult = (Page<JobQueueEntity>) modelMap
				.get("page");
		assertEquals(1, pageresult.getList().size());
		assertEquals(1, pageresult.getCount());
	}

	@Test
	public void test_listFusionJobs() {
		FusionJob fusionjob = new FusionJob();
		ExtendedModelMap modelMap = new ExtendedModelMap();
		MockHttpServletRequest request = new MockHttpServletRequest();
		MockHttpServletResponse response = new MockHttpServletResponse();

		String result = jobController.listFusionJobs(null, fusionjob, request,
				response, modelMap);
		assertEquals("modules/jobs/fusionjoblist", result);

		@SuppressWarnings("unchecked")
		Page<FusionJob> pageresult = (Page<FusionJob>) modelMap.get("page");
		assertEquals(5, pageresult.getList().size());
		assertEquals(5, pageresult.getCount());
	}

	@Test
	public void test_listFusionJobs_01() {
		FusionJob fusionjob = new FusionJob();
		ExtendedModelMap modelMap = new ExtendedModelMap();
		MockHttpServletRequest request = new MockHttpServletRequest();
		MockHttpServletResponse response = new MockHttpServletResponse();
		fusionjob.setFunctiontype("TI");
		String result = jobController.listFusionJobs(null, fusionjob, request,
				response, modelMap);
		assertEquals("modules/jobs/fusionjoblist", result);

		@SuppressWarnings("unchecked")
		Page<FusionJob> pageresult = (Page<FusionJob>) modelMap.get("page");
		assertEquals(5, pageresult.getList().size());
		assertEquals(5, pageresult.getCount());
	}

	@Test
	public void test_listFusionJobs_02() {
		FusionJob fusionjob = new FusionJob();
		ExtendedModelMap modelMap = new ExtendedModelMap();
		MockHttpServletRequest request = new MockHttpServletRequest();
		MockHttpServletResponse response = new MockHttpServletResponse();
		fusionjob.setFunctiontype("LI");
		String result = jobController.listFusionJobs(null, fusionjob, request,
				response, modelMap);
		assertEquals("modules/jobs/fusionjoblist", result);

		@SuppressWarnings("unchecked")
		Page<FusionJob> pageresult = (Page<FusionJob>) modelMap.get("page");
		assertEquals(0, pageresult.getList().size());
		assertEquals(0, pageresult.getCount());
	}

	@Test
	public void test_listFusionJobs_03() {
		FusionJob fusionjob = new FusionJob();
		ExtendedModelMap modelMap = new ExtendedModelMap();
		MockHttpServletRequest request = new MockHttpServletRequest();
		MockHttpServletResponse response = new MockHttpServletResponse();
		fusionjob.setFusionJobId(2l);
		String result = jobController.listFusionJobs(null, fusionjob, request,
				response, modelMap);
		assertEquals("modules/jobs/fusionjoblist", result);

		@SuppressWarnings("unchecked")
		Page<FusionJob> pageresult = (Page<FusionJob>) modelMap.get("page");
		assertEquals(1, pageresult.getList().size());
		assertEquals(1, pageresult.getCount());
	}

	@Test
	public void test_listFusionJobs_04() {
		FusionJob fusionjob = new FusionJob();
		ExtendedModelMap modelMap = new ExtendedModelMap();
		MockHttpServletRequest request = new MockHttpServletRequest();
		MockHttpServletResponse response = new MockHttpServletResponse();
		fusionjob.setJobId(1l);
		String result = jobController.listFusionJobs(null, fusionjob, request,
				response, modelMap);
		assertEquals("modules/jobs/fusionjoblist", result);

		@SuppressWarnings("unchecked")
		Page<FusionJob> pageresult = (Page<FusionJob>) modelMap.get("page");
		assertEquals(5, pageresult.getList().size());
		assertEquals(5, pageresult.getCount());
	}

	@Test
	public void test_listFeJobQueue_all_List() {
		doListFeJobQueueTest(null, 10);
	}

	@Test
	public void test_listFeJobQueue_find_List() {
		doListFeJobQueueTest(1L, 1);
	}

	@Test
	public void test_listFeJobQueue_not_find_List() {
		doListFeJobQueueTest(100L, 0);
	}

	@Test
	public void test_FeJobResult() {
		String clazz = "FEJobQueueEntity";
		String field = "results";
		Long jobId = 1L;
		String expResult = CommonUtils.getExtResult().toString();
		doListFeJobReqTest(clazz, jobId, field, expResult);
	}

	@Test
	public void test_listFeJobPayload() {
		String clazz = "FeJobPayloadEntity";
		String field = "inputPayload";
		Long jobId = 1L;
		String expResult = CommonUtils.getExtReq().toString();
		doListFeJobReqTest(clazz, jobId, field, expResult);
	}

	private void doListFeJobQueueTest(Long jobId, int expFindCount) {
		MockUp<UserUtils> mocked = null;
		try {
			mocked = new MockUp<UserUtils>() {
				@Mock
				public UserEntity getUser() {
					return new UserEntity();
				}
			};
			FeJobQueueEntity fejob = new FeJobQueueEntity();
			ExtendedModelMap modelMap = new ExtendedModelMap();
			MockHttpServletRequest request = new MockHttpServletRequest();
			MockHttpServletResponse response = new MockHttpServletResponse();
			fejob.setJobId(jobId);
			String result = jobController.listFEJobQueue(null, fejob, request,
					response, modelMap);
			assertEquals("modules/jobs/fejobqueuelist", result);

			@SuppressWarnings("unchecked")
			Page<FeJobQueueEntity> pageresult = (Page<FeJobQueueEntity>) modelMap
					.get("page");
			assertEquals(expFindCount, pageresult.getList().size());
			assertEquals(expFindCount, pageresult.getCount());
		} finally {
			mocked.tearDown();
		}
	}

	private void doListFeJobReqTest(String clazz, Long jobId, String field,
			String expResult) {
		MockUp<UserUtils> mocked = null;
		try {
			mocked = new MockUp<UserUtils>() {
				@Mock
				public UserEntity getUser() {
					return new UserEntity();
				}
			};
			FeJobQueueEntity fejob = new FeJobQueueEntity();
			ExtendedModelMap modelMap = new ExtendedModelMap();
			MockHttpServletRequest request = new MockHttpServletRequest();
			fejob.setJobId(jobId);
			String result = jobController.JobResultlist(clazz, jobId, field,
					request, modelMap);
			assertEquals("modules/jobs/jobresult", result);
			System.out.println(modelMap);
			String pageresult = (String) modelMap.get("result");
			assertEquals(expResult, pageresult);
		} finally {
			mocked.tearDown();
		}
	}
}
