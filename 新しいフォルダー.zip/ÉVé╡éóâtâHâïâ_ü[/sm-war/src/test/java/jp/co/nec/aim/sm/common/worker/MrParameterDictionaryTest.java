package jp.co.nec.aim.sm.common.worker;

import static org.junit.Assert.assertEquals;

import java.net.URL;
import java.util.List;

import jp.co.nec.aim.sm.common.utils.MuConfigSectionUtils;
import jp.co.nec.aim.sm.common.utils.MuConfigUtils;
import mockit.Deencapsulation;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;


public class MrParameterDictionaryTest {
	
	private static final String[] mrSections = 
	                              {"System", "ProcessMonitor", "HTTP", "ThreadPool", "Log", "Dispatcher", "HeartBeat", "JobMonitor" };
	                              
	
	private static final String[][] system = {
	                                          {"AppPath", "^(\\/.*)$", "view"},
	                                          {"MyId", "^([1-9]|\\d{2,19}|9[0-1]\\d{17,17}|92[0-1]\\d{16,16}|922[0-2]\\d{15,15}|9223[0-2]\\d{14,14}|92233[1-6]\\d{13,13}|922337[0-1]\\d{12,12}|92233720[0-2]\\d{10,10}|922337203[1-5]\\d{9,9}|9223372036[0-7]\\d{8,8}|92233720368[0-4]\\d{7,7}|922337203685[0-3]\\d{6,6}|9223372036854[0-6]\\d{5,5}|92233720368547[0-6]\\d{4,4}|922337203685477[0-4]\\d{3,3}|9223372036854775[0-7]\\d{2,2}|922337203685477580[0-8])$", "view"},
	                                          {"MyIpAddress", "^(\\d|[01]?\\d\\d|2[0-4]\\d|25[0-5])\\.(\\d|[01]?\\d\\d|2[0-4]\\d|25[0-5])\\.(\\d|[01]?\\d\\d|2[0-4]\\d|25[0-5])\\.(\\d|[01]?\\d\\d|2[0-4]\\d|25[0-5])$", "view"},
	                                          {"MyPort", "^(0|102[4-9]|10[3-9]\\d|1[1-9]\\d{2,2}|[2-9]\\d{3,3}|5\\d{4,4}|6[0-4]\\d{3,3}|65[0-4]\\d{2,2}|655[0-2]\\d|6553[0-5])$", "view"},	                         
	                                         };
	
	
	
	private static final String[][] processMonitor  = {
                                                      	{"MonitorPort", "^(102[4-9]|10[3-9]\\d|1[1-9]\\d{2,2}|[2-9]\\d{3,3}|5\\d{4,4}|6[0-4]\\d{3,3}|65[0-4]\\d{2,2}|655[0-2]\\d|6553[0-5])$", "view"},
                                                      	{"WaitForConnect", "^([1-9]|\\d{2,19}|1[0-7]\\d{18,18}|18[0-3]\\d{17,17}|184[0-3]\\d{16,16}|1844[0-5]\\d{15,15}|18446[0-6]\\d{14,14}|184467[0-3]\\d{13,13}|1844674[0-3]\\d{12,12}|184467440[0-6]\\d{10,10}|1844674407[0-2]\\d{9,9}|18446744073[0-6]\\d{8,8}|1844674407370[0-8]\\d{6,6}|18446744073709[0-4]\\d{5,5}|184467440737095[0-4]\\d{4,4}|18446744073709551[0-5]\\d{2,2}|18446744073709550\\d{3,3}|1844674407370955161[0-5]|1844674407370955160\\d{1,1}|1844674407370955161[0-5])$", "writable"},
                                                      	{"SwitchingLimit", "^(\\d{1,9}|[1-3]\\d{9,9}|4[0-1]\\d{8,8}|42[0-8]\\d{7,7}|429[0-3]\\d{6,6}|4294[0-8]\\d{5,5}|42949[0-5]\\d{4,4}|429496[0-6]\\d{3,3}|4294967[0-1]\\d{2,2}|42949672[0-8]\\d{1,1}|429496729[0-5])$", "writable"},
                                                      	{"StandAlone", "^(true|false)$", "writable"}                                                      	
	                                                  };	

	@Before
	public void setUp() throws Exception {
		URL muDicUrl = Thread.currentThread().getContextClassLoader().getResource("MuConfig.dic");
		String muDicFilePath = muDicUrl.getPath();
		
		URL mrDicUrl = Thread.currentThread().getContextClassLoader().getResource("MrConfig.dic");
		String mrDicFilePath = mrDicUrl.getPath();	
		
		Deencapsulation.setField(MatchUnitParameterDictionary.class, "MU_DIC_PATH", muDicFilePath);
		Deencapsulation.setField(MatchUnitParameterDictionary.class, "MR_DIC_PATH", mrDicFilePath);
	}	

	@After
	public void tearDown() throws Exception {		
	}	
	
	@Test
	public void testMrDicSetion() {
		List<MuConfigUtils> mrMap;
		mrMap = MatchUnitParameterDictionary.getMatchUnitParameterMap(true);

		assertEquals(mrSections.length, mrMap.size());
		for (int i = 0; i < mrSections.length; i++) {
			assertEquals(true, compareSectionName(mrMap, mrSections[i]));
		}
	}
	
	@Test
	public void testSystemMrRegExpPatterns() {
		List<MuConfigUtils> mrMap;
		mrMap = MatchUnitParameterDictionary.getMatchUnitParameterMap(true);
		for (MuConfigUtils mt : mrMap) {
			if (mt.getSection().equals("System")) {
				List<MuConfigSectionUtils> tmp = mt.getMuConfigSection();
				 for (int i = 0; i < system.length; i++) {
					 assertEquals(true, testConfigItems(tmp, system[i]));
				 }				 
			}
		}		
	}
	
	@Test
	public void testProcessMonitorMrRegExpPatterns() {
		List<MuConfigUtils> mrMap;
		mrMap = MatchUnitParameterDictionary.getMatchUnitParameterMap(true);
		for (MuConfigUtils mt : mrMap) {
			if (mt.getSection().equals("ProcessMonitor")) {
				List<MuConfigSectionUtils> tmp = mt.getMuConfigSection();
				 for (int i = 0; i < processMonitor.length; i++) {
					 assertEquals(true, testConfigItems(tmp, processMonitor[i]));
				 }				 
			}
		}		
	}
	
	private boolean testConfigItems(List<MuConfigSectionUtils> items, String[] itemArray) {
		int count = 0;
		for (MuConfigSectionUtils itm : items) {
			if (itm.getKey().equals(itemArray[0])
				&&  itm.getRule().equals(itemArray[1])
				&& itm.getType().equals(itemArray[2])) {
				count++;				
			}
		}
		return count == 1 ? true :false;		
	}
	
	private boolean compareSectionName(List<MuConfigUtils> muDicList, String oneSection) {		
		int count = 0;
		for (int i = 0; i < muDicList.size(); i++) {
			if (muDicList.get(i).getSection().equals(oneSection)) {
				count++;
			}			
		}
		return count == 1 ? true :false;
	}
}
