package jp.co.nec.aim.sm.common.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class EnumUtilTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test_getAllstatus() {
		List<String> statuslist = EnumUtil.getSegmentReportStatelist();
		assertEquals("IN_MEMORY", statuslist.get(0));
		assertEquals("ON_DISK", statuslist.get(1));
		assertEquals("CURRENTLY_DOWNLOADING", statuslist.get(2));
		assertEquals("IN_DOWNLOAD_QUEUE", statuslist.get(3));
		assertEquals("ERROR", statuslist.get(4));
	}

	@Test
	public void test_findAllUnitState() {
		List<String> unitStatelist = EnumUtil.getUnitStatelist();
		assertEquals("WORKING", unitStatelist.get(0));
		assertEquals("TIMED_OUT", unitStatelist.get(1));
		assertEquals("EXITED", unitStatelist.get(2));
	}

	@Test
	public void test_findAllUnitType() {
		List<String> unitTypelist = EnumUtil.getUnitTypelist();
		assertEquals("MU", unitTypelist.get(0));
		assertEquals("DM", unitTypelist.get(1));
		assertEquals("MM", unitTypelist.get(2));
		assertEquals("MR", unitTypelist.get(3));
	}

	@Test
	public void test_findAllUnitCtrlType() {
		List<String> unitCtrlTypelist = EnumUtil.getUnitCtrlTypelist();
		assertEquals("MU", unitCtrlTypelist.get(0));
		assertEquals("DM", unitCtrlTypelist.get(1));
		assertEquals("MM", unitCtrlTypelist.get(2));
	}

	@Test
	public void test_findAllUtilAction() {
		List<String> processTypelist = EnumUtil.getProcessTypelist();
		assertEquals("START", processTypelist.get(0));
		assertEquals("STOP", processTypelist.get(1));
		assertEquals("RESTART", processTypelist.get(2));
		// assertEquals("STATUS", processTypelist.get(3));
		// assertEquals("FORCE_STOP", processTypelist.get(4));
		// assertEquals("FORCE_RESTART", processTypelist.get(5));
	}

	@Test
	public void test_getAllAction() {
		List<String> segmentAllocationlist = EnumUtil
				.getSegmentAllocationlist();
		assertEquals("Allocation", segmentAllocationlist.get(0));
		assertEquals("DeAllocation", segmentAllocationlist.get(1));
	}
	@Test
	public void test_getAllEnum_JobState() {
		List<String> list = EnumUtil.getJobStatelist();
		assertEquals("QUEUED", list.get(0));
		assertEquals("WORKING", list.get(1));
		assertEquals("COMPLETED", list.get(2));
	}

	@Test
	public void test_getAllJobStatus() {
		List<String> jobStatuslist = EnumUtil.getJobStatuslist();
		assertEquals("QUEUED", jobStatuslist.get(0));
		assertEquals("WORKING", jobStatuslist.get(1));
		assertEquals("COMPLETED", jobStatuslist.get(2));
//		assertEquals("ERROR", jobStatuslist.get(3));
	}

	@Test
	public void testGetAssignActions() {
		List<String> list = EnumUtil.getAssignActionList();
		String[] actions = { "Assign", "Unassign" };
		assertEquals(2, list.size());
		for (int i = 0; i < 2; i++) {
			assertTrue(list.contains(actions[i]));
		}
	}

	@Test
	public void testGetBinActions() {
		List<String> list = EnumUtil.getBinActionList();
		String[] actions = { "Update", "Filter" };
		assertEquals(2, list.size());
		for (int i = 0; i < 2; i++) {
			assertTrue(list.contains(actions[i]));
		}
	}

	@Test
	public void testGetMassegeTypeList() {
		List<String> list = EnumUtil.getMassegeTypeList();

		assertEquals(5, list.size());
		assertEquals("INFORMATION", list.get(0));
		assertEquals("WARNING", list.get(1));
		assertEquals("ALERT", list.get(2));
		assertEquals("ERROR", list.get(3));
		assertEquals("EMERGENCY", list.get(4));
	}
}
