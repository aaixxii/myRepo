package jp.co.nec.aim.sm.modules.sys.oracle.repository;

import static org.junit.Assert.assertEquals;

import java.util.List;

import javax.sql.DataSource;

import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.FusionJob;
import jp.co.nec.aim.sm.test.common.util.CommonUtils;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional(value = "oracleTXManager")
public class FusionJobRepositoryTest {

	@Autowired
	FusionJobRepository fusionjobrepository;
	@Autowired
	@Qualifier("oracleDataSource")
	DataSource datasource;
	JdbcTemplate jdbcTemplate;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {

		jdbcTemplate = new JdbcTemplate(datasource);
		CommonUtils.DeleteOracleData(jdbcTemplate);
		CommonUtils.prepareMATCH_UNITS(jdbcTemplate);
		CommonUtils.prepare_JOB_01(jdbcTemplate);
	}

	@After
	public void tearDown() throws Exception {
		CommonUtils.DeleteOracleData(jdbcTemplate);
	}

	@Test
	public void test_findFusionJobPage() {
		Page<FusionJob> page = new Page<FusionJob>(1, 10);
		FusionJob fusionjob = new FusionJob();
		Page<FusionJob> pageResult = this.fusionjobrepository
				.findFusionJobPage(page, fusionjob);
		assertEquals(7, pageResult.getList().size());
	}

	@Test
	public void test_findFusionJobPage_fusionJobId() {
		Page<FusionJob> page = new Page<FusionJob>(1, 10);
		FusionJob fusionjob = new FusionJob();
		fusionjob.setFusionJobId(1l);
		Page<FusionJob> pageResult = this.fusionjobrepository
				.findFusionJobPage(page, fusionjob);
		assertEquals(1, pageResult.getList().size());
	}

	@Test
	public void test_findFusionJobPage_Functiontype() {
		Page<FusionJob> page = new Page<FusionJob>(1, 10);
		FusionJob fusionjob = new FusionJob();
		fusionjob.setFunctionId(1);
		Page<FusionJob> pageResult = this.fusionjobrepository
				.findFusionJobPage(page, fusionjob);

		assertEquals(3, pageResult.getList().size());
	}

	@Test
	public void test_findFusionJobPage_jobid() {
		Page<FusionJob> page = new Page<FusionJob>(1, 10);
		FusionJob fusionjob = new FusionJob();
		fusionjob.setJobId(3l);
		Page<FusionJob> pageResult = this.fusionjobrepository
				.findFusionJobPage(page, fusionjob);
		assertEquals(3, pageResult.getList().size());
	}

	@Test
	public void test_findFusionJobList() {
		FusionJob fusionjob = new FusionJob();
		List<FusionJob> listResult = this.fusionjobrepository
				.findFusionJobList(fusionjob);
		assertEquals(7, listResult.size());
	}

	@Test
	public void test_findFusionJobList_fusionJobId() {
		FusionJob fusionjob = new FusionJob();
		fusionjob.setFusionJobId(1l);
		List<FusionJob> listResult = this.fusionjobrepository
				.findFusionJobList(fusionjob);
		assertEquals(1, listResult.size());
	}

	@Test
	public void test_findFusionJobList_Functiontype() {
		FusionJob fusionjob = new FusionJob();
		fusionjob.setFunctionId(1);
		List<FusionJob> listResult = this.fusionjobrepository
				.findFusionJobList(fusionjob);
		assertEquals(3, listResult.size());
	}

	@Test
	public void test_findFusionJobList_jobid() {
		FusionJob fusionjob = new FusionJob();
		fusionjob.setJobId(3l);
		List<FusionJob> listResult = this.fusionjobrepository
				.findFusionJobList(fusionjob);
		assertEquals(3, listResult.size());
	}

	@Test
	public void test_findResultsByfusionJobId() {
		Long fusionJobId = 1l;
		String field = "inquiryJobData";
		String result = this.fusionjobrepository.findResultsByfusionJobId(
				fusionJobId, field);
		assertEquals("No Inquiry request data was found..", result);
	}
}
