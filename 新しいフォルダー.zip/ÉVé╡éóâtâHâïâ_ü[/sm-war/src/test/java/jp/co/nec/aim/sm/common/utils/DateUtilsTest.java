package jp.co.nec.aim.sm.common.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.Date;

import org.apache.commons.lang.time.DateFormatUtils;
import org.junit.Test;

public class DateUtilsTest {

	@Test
	public void testGetDate_1() {
		String str = DateUtils.getDate();

		assertEquals(10, str.length());
	}

	@Test
	public void testGetDate_2() {
		String str = DateUtils.getDate("yyyy-MM-dd HH:mm:ss");

		assertEquals(19, str.length());
	}

	@Test
	public void testFormatDate_1() {
		String str = DateUtils.formatDate(new Date(), "yyyy-MM-dd HH:mm:ss");

		assertEquals(19, str.length());
	}

	@Test
	public void testFormatDate_2() {
		String str = DateUtils.formatDate(new Date());

		assertEquals(10, str.length());
	}

	@Test
	public void testGetTime() {
		String str = DateUtils.getTime();

		assertEquals(8, str.length());
	}

	@Test
	public void testGetDateTime() {
		String str = DateUtils.getDateTime();

		assertEquals(19, str.length());
	}

	@Test
	public void testGetYear() {
		String str = DateUtils.getYear();

		assertEquals(4, str.length());
	}

	@Test
	public void testGetMonth() {
		String str = DateUtils.getMonth();

		assertEquals(2, str.length());
	}

	@Test
	public void testGetDay() {
		String str = DateUtils.getDay();

		assertEquals(2, str.length());
	}

	@Test
	public void testGetWeek() {
		String str = DateUtils.getWeek();

		assertEquals(DateFormatUtils.format(new Date(), "E"), str);
	}

	@Test
	public void testParseDate() {
		Date date = DateUtils.parseDate(null);
		assertNull(date);

		date = DateUtils.parseDate("rewew");
		assertNull(date);

		date = DateUtils.parseDate("2013-10-10");
		assertTrue(date.toString().contains("Thu Oct 10 00:00:00"));
	}

	@Test
	public void testPastDays() {
		Date date = new Date(new Date().getTime() - 3 * 24 * 60 * 60 * 1000);
		long t = DateUtils.pastDays(date);

		assertEquals(3, t);
	}
}
