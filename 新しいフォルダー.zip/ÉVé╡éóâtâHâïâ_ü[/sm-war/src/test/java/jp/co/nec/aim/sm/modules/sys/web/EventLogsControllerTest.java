package jp.co.nec.aim.sm.modules.sys.web;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.List;

import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.modules.sys.postgres.entity.EventLogEntity;
import jp.co.nec.aim.sm.modules.sys.postgres.repository.EventLogRepository;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ExtendedModelMap;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional(value = "postgresTXManager")
public class EventLogsControllerTest {
	@Autowired
	EventLogsController eventLogsController;
	@Autowired
	private EventLogRepository repository;

	String msgArray[][] = { { "844000303", "400000" },
			{ "044000300", "100000" }, { "044000300", "100000" },
			{ "044000300", "100000" }, { "144114000", "200000" },
			{ "044000300", "100000" }, { "040000000", "110000" } };

	@Before
	public void before() {
		repository.deleteAll();
		String time = "2013-07-13 12:10:10";
		Timestamp ts = Timestamp.valueOf(time);
		for (int i = 0; i < msgArray.length; i++) {
			EventLogEntity eventLogEntity = new EventLogEntity();
			eventLogEntity.setEventId(i + 1);
			eventLogEntity.setMessage("Test Message.");
			eventLogEntity.setMessageCode(msgArray[i][0]);
			eventLogEntity.setCls("jp.co.nec.aim.sm.web.test");
			eventLogEntity.setTimestamp(ts);
			eventLogEntity.setMessageType(msgArray[i][1]);
			eventLogEntity.setUnitId(361l + i);
			repository.saveAndFlush(eventLogEntity);
		}
	}

	@After
	public void after() {
		repository.deleteAll();
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testList_Empty() {
		try {
			ExtendedModelMap modelMap = new ExtendedModelMap();

			MockHttpServletRequest request = new MockHttpServletRequest();
			MockHttpServletResponse response = new MockHttpServletResponse();

			EventLogEntity event = new EventLogEntity();
			event.setEventId(-1);

			String result = eventLogsController.list(null, null, event,
					request, response, modelMap);

			assertEquals("modules/eventlogs/eventlog", result);
			Page<EventLogEntity> page = (Page<EventLogEntity>) modelMap
					.get("page");
			List<EventLogEntity> events = page.getList();

			List<String> typeList = (List<String>) modelMap.get("typeList");
			assertEquals(5, typeList.size());
			assertEquals("INFORMATION", typeList.get(0));
			assertEquals("WARNING", typeList.get(1));
			assertEquals("ALERT", typeList.get(2));
			assertEquals("ERROR", typeList.get(3));
			assertEquals("EMERGENCY", typeList.get(4));

			assertEquals(0, events.size());

			assertNull(modelMap.get("graphURL"));

		} catch (IOException e) {
			fail();
		}
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testList() {
		try {
			ExtendedModelMap modelMap = new ExtendedModelMap();

			MockHttpServletRequest request = new MockHttpServletRequest();
			MockHttpServletResponse response = new MockHttpServletResponse();

			EventLogEntity event = new EventLogEntity();

			String result = eventLogsController.list(null, null, event,
					request, response, modelMap);

			assertEquals("modules/eventlogs/eventlog", result);

			Page<EventLogEntity> page = (Page<EventLogEntity>) modelMap
					.get("page");
			List<EventLogEntity> events = page.getList();

			assertEquals(7, events.size());
			for (int i = 0; i < 7; i++) {
				assertNotNull(events.get(i).getEventId());
				assertEquals(361l + i, events.get(i).getUnitId().longValue());
				assertEquals(msgArray[i][0], events.get(i).getMessageCode());
				assertEquals("2013-07-13 12:10:10.0", events.get(i)
						.getTimestamp().toString());
				assertEquals(msgArray[i][1], events.get(i).getMessageType());
				assertEquals("Test Message.", events.get(i).getMessage());
			}

			List<String> typeList = (List<String>) modelMap.get("typeList");
			assertEquals(5, typeList.size());
			assertEquals("INFORMATION", typeList.get(0));
			//assertEquals("SERVICES_STARTED", typeList.get(1));
			//assertEquals("SERVICES_STOPPED", typeList.get(2));
			assertEquals("WARNING", typeList.get(1));
			assertEquals("ALERT", typeList.get(2));
			assertEquals("ERROR", typeList.get(3));
			assertEquals("EMERGENCY", typeList.get(4));
			// assertEquals("UNKNWON", typeList.get(7));

			assertNull(modelMap.get("graphURL"));
		} catch (IOException e) {
			fail();
		}
	}
}
