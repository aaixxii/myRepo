package jp.co.nec.aim.sm.modules.sys;

import static org.junit.Assert.assertTrue;
import jp.co.nec.aim.sm.common.constant.SMConstant;

import org.junit.Test;

public class BaseServiceTest extends BaseService {

	static BaseServiceTest server = new BaseServiceTest();

	@Test
	public void testSetField_Null() {
		String str = server.setField(null);

		assertTrue(str.equals(SMConstant.NOT_FOUND));
	}

	@Test
	public void testSetField_Empty() {
		String str = server.setField("");

		assertTrue(str.equals(SMConstant.NOT_FOUND));
	}

	@Test
	public void testSetField_XmlResult() {
		String result = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
				+ "<ns2:extract-job-result xmlns:ns2=\"urn:nec:aim\"/>";
		String str = server.setField(result);

		assertTrue(str
				.contains("<ns2:extract-job-result xmlns:ns2=\"urn:nec:aim\"/>"));
		//assertTrue(str.contains("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"));
	}

	@Test
	public void testSetField_Space() {
		String str = server.setField("   ");

		assertTrue(str.equals(SMConstant.NOT_FOUND));
	}

	@Test
	public void testSetField_Normal() {
		String str = server.setField("  ersdfs ");

		assertTrue(str.equals("  ersdfs "));
	}

	@Test
	public void test() {
		String result = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
				+ "<ns2:searchinputspayload xmlns:ns2=\"urn:nec:aim\">"
				+ "<meta-info>"
				+ "<meta-common gender=\"U\" race=\"-1\" region=\"U\" yob=\"-1\" yobRange=\"-1\"/>"
				+ "<meta-tenprint primaryPatterns=\"SSSSSSSSSS\" referencePatterns=\"UUUUUUUUUU\"/>"
				+ "</meta-info>"
				+ "<preselection-options applyFingerSelectionMode=\"false\" applyGender=\"false\""
				+ " applyPatternThreshold=\"false\" applyYob=\"false\" applyYobThreshold=\"false\""
				+ " candidateVerificationThreshold=\"1\" cardQualityThreshold=\"1\" filterMode=\"1\""
				+ " fingerSelectionMode=\"10\" patternThreshold=\"1.25\" yobThreshold=\"10\"/>"
				+ "<pc2-options applyDistortionLevel=\"false\" applyRotationLimit=\"false\""
				+ " applySpeedLevel=\"false\" distortionLevel=\"1\" rotationLimit=\"1\" speedLevel=\"6\"/>"
				+ "</ns2:searchinputspayload>";

		String str = server.setField(result);
		assertTrue(str.contains("<meta-info>"));
	}
}
