package jp.co.nec.aim.sm.modules.sys.web.listener;

import static org.junit.Assert.assertEquals;

import java.text.ParseException;

import javax.sql.DataSource;

import jp.co.nec.aim.sm.modules.sys.service.ExtractjobQueueService;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional(value = "postgresTXManager")
public class MMExtractJobQueueHttpListenerTest {
	@Autowired
	@Qualifier("postgresDataSource")
	DataSource datasource;

	JdbcTemplate jdbcTemplate;

	@Autowired
	ExtractjobQueueService jobService;

	@Before
	public void before() {
		jdbcTemplate = new JdbcTemplate(datasource);

		cleanDB();
		prepareDB();
	}

	@After
	public void after() {
		cleanDB();
	}

	private void cleanDB() {
		jdbcTemplate.execute("delete from \"FUNCTION_TYPES\"");
		jdbcTemplate.execute("delete from \"EXTRACT_JOB_QUEUE\"");
	}

	private void prepareDB() {
		String functionSql = "insert into \"FUNCTION_TYPES\"("
				+ "\"FUNCTION_ID\", \"FUNCTION_NAME\") values(17, 'EXTRACTION')";

		jdbcTemplate.execute(functionSql);

	}

	@Test
	public void testSaveAndFlush() throws ParseException {
		MMExtractJobQueueHttpListener servlet = new MMExtractJobQueueHttpListener();
		String splitLine[] = new String[] { "1", "17", "1", "2", "0", "100",
				"2013/09/01 10:00:10.854", "2013/09/01 08:03:12.344",
				"2013/09/01 08:03:12.344", "0", "false" };

		servlet.saveAndFlush(jobService, splitLine);

		int count = jdbcTemplate
				.queryForList(
						"select count(*) from \"EXTRACT_JOB_QUEUE\" where \"EXTRACT_JOB_ID\" = 1 ")
				.size();

		assertEquals(1, count);
	}
}
