package jp.co.nec.aim.sm.common.security;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

import org.junit.Test;

public class DigestsTest {
	static String testString = "Test String";
	static String saltString = "salt String";
	byte[] byteArray = new byte[] { -91, 16, 63, -100, 11, 125, 95, -10, -99,
			-36, 56, 96, 124, 116, -27, 61, 74, -63, 32, -14 };

	byte[] saltArray = new byte[] { -27, -9, -23, -111, 0, -15, 10, 55, -126,
			68, 6, 112, -95, 93, 30, -31, 0, -81, 24, 77 };

	byte[] ite3Array = new byte[] { -128, -4, 74, -98, 121, -37, -97, -19, 61,
			-34, 41, -40, 6, -45, 20, -111, -39, -85, -24, -116 };

	byte[] md5Array = new byte[] { -67, 8, -70, 60, -104, 46, -86, -41, 104,
			96, 37, 54, -5, -114, 17, -124 };

	@Test
	public void testSha1_One() {
		byte[] result = Digests.sha1(testString.getBytes());

		assertArrayEquals(result, byteArray);
	}

	@Test
	public void testSha1_salt_null() {
		byte[] result = Digests.sha1(testString.getBytes(), null);

		assertArrayEquals(result, byteArray);
	}

	@Test
	public void testSha1_salt() {
		byte[] result = Digests.sha1(testString.getBytes(), saltString
				.getBytes());

		assertArrayEquals(result, saltArray);
	}

	@Test
	public void testSha1_ite_0() {
		byte[] result = Digests.sha1(testString.getBytes(), null, 0);

		assertArrayEquals(result, byteArray);
	}

	@Test
	public void testSha1_ite_1() {
		byte[] result = Digests.sha1(testString.getBytes(), null, 1);

		assertArrayEquals(result, byteArray);
	}

	@Test
	public void testSha1_ite_3() {
		byte[] result = Digests.sha1(testString.getBytes(), null, 3);

		assertArrayEquals(result, ite3Array);
	}

	@Test
	public void testGenerateSalt_0() {
		try {
			Digests.generateSalt(0);
		} catch (IllegalArgumentException e) {
			assertEquals(
					"numBytes argument must be a positive integer (1 or larger): 0",
					e.getMessage());
			return;
		}
		fail();
	}

	@Test
	public void testGenerateSalt() {
		byte[] result = Digests.generateSalt(10);

		assertEquals(10, result.length);
	}

	@Test
	public void testMd5() {
		InputStream input = new ByteArrayInputStream(testString.getBytes());
		try {
			byte[] result = Digests.md5(input);
			assertArrayEquals(result, md5Array);
		} catch (IOException e) {
			fail();
		}
	}

	@Test
	public void testSha1() {
		InputStream input = new ByteArrayInputStream(testString.getBytes());
		try {
			byte[] result = Digests.sha1(input);
			assertArrayEquals(result, byteArray);
		} catch (IOException e) {
			fail();
		}
	}
}
