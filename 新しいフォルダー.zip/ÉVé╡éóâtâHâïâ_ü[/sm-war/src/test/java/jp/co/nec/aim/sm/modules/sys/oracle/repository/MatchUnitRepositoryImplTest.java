package jp.co.nec.aim.sm.modules.sys.oracle.repository;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.util.List;

import javax.sql.DataSource;

import jp.co.nec.aim.sm.common.constant.UnitState;
import jp.co.nec.aim.sm.common.constant.UnitType;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.MatchManagerEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.MatchUnitEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.MatchUnitUnionMatchUnitContact;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.UnitPojo;
import jp.co.nec.aim.sm.test.common.util.CommonUtils;

import org.apache.commons.lang3.StringUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional(value = "oracleTXManager")
public class MatchUnitRepositoryImplTest {

	@Autowired
	private MatchUnitRepository matchUnitDao;

	@Autowired
	@Qualifier("oracleDataSource")
	DataSource datasource;

	JdbcTemplate jdbcTemplate;

	@Before
	public void setUp() throws Exception {
		jdbcTemplate = new JdbcTemplate(datasource);
		CommonUtils.DeleteOracleData(jdbcTemplate);
		CommonUtils.prepareMATCH_UNITS(jdbcTemplate);
		CommonUtils.prepareMATCH_MANAGERS(jdbcTemplate);
	}

	@After
	public void tearDown() throws Exception {
		CommonUtils.DeleteOracleData(jdbcTemplate);
	}

	@Test
	public void test_getUnitbyMuId() {
		MatchUnitUnionMatchUnitContact contact = matchUnitDao.getUnitbyMuId(
				202L, "MR");
		assertEquals(202, contact.getMuId().intValue());
		assertEquals("http://192.168.100.202:8080/mapReducers",
				contact.getContactURL());
		assertNull(contact.getPrimarySize());
		assertNull(contact.getSecondarySize());
		assertNull(contact.getNumberOfExtractors());
		assertNull(contact.getNumberOfMatchers());
		assertNull(contact.getReportedPerformanceFactor());
		assertEquals("WORKING", contact.getState());
		assertEquals("MR:192.168.100.202", contact.getUniqueId());		
		assertEquals(StringUtils.EMPTY,contact.getContact_ts());
		assertEquals("5.0.1", contact.getVersion());
		contact = matchUnitDao.getUnitbyMuId(102L, "DM");
		assertEquals(102, contact.getMuId().intValue());
		assertEquals("http://192.168.100.34:8080/datamanager",
				contact.getContactURL());
		assertNull(contact.getPrimarySize());
		assertNull(contact.getSecondarySize());
		assertNull(contact.getNumberOfExtractors());
		assertNull(contact.getNumberOfMatchers());
		assertNull(contact.getReportedPerformanceFactor());
		assertEquals("WORKING", contact.getState());
		assertEquals("DM:192.168.100.34", contact.getUniqueId());
		assertEquals(StringUtils.EMPTY,contact.getContact_ts());
		assertEquals("5.0.1", contact.getVersion());

		contact = matchUnitDao.getUnitbyMuId(21L, "MU");
		assertEquals(21, contact.getMuId().intValue());
		assertEquals("http://192.168.100.36:8080/", contact.getContactURL());
		assertNotNull(contact.getPrimarySize());
		assertNotNull(contact.getSecondarySize());
		assertNotNull(contact.getNumberOfExtractors());
		assertNotNull(contact.getNumberOfMatchers());
		assertNotNull(contact.getReportedPerformanceFactor());
		assertEquals("WORKING", contact.getState());
		assertEquals("MU:192.168.100.36", contact.getUniqueId());
		assertEquals(StringUtils.EMPTY,contact.getContact_ts());
		assertEquals("3.1.0-SNAPSHOT-I", contact.getVersion());

		contact = matchUnitDao.getUnitbyMuId(201L, "MU");
		assertNull(contact);

		contact = matchUnitDao.getUnitbyMuId(11L, "SM");
		assertNull(contact);
	}

	@Test
	public void test_getUnitbyMuId_01() {
		String insertsql = "insert into MR_CONTACTS ( MR_ID ,CONTACT_TS) values(?,?)";
		jdbcTemplate.update(insertsql,
				new Object[] { 202, System.currentTimeMillis() });
		MatchUnitUnionMatchUnitContact contact = matchUnitDao.getUnitbyMuId(
				202L, "MR");
		assertEquals(202, contact.getMuId().intValue());
		assertEquals("http://192.168.100.202:8080/mapReducers",
				contact.getContactURL());
		assertNull(contact.getPrimarySize());
		assertNull(contact.getSecondarySize());
		assertNull(contact.getNumberOfExtractors());
		assertNull(contact.getNumberOfMatchers());
		assertNull(contact.getReportedPerformanceFactor());
		assertEquals("WORKING", contact.getState());
		assertEquals("MR:192.168.100.202", contact.getUniqueId());
		assertNotNull(contact.getContact_ts());
		assertEquals("5.0.1", contact.getVersion());
	}

	@Test
	public void test_getAllMUUnits() {
		List<UnitPojo> units = matchUnitDao.getAllMUUnits();
		assertEquals(3, units.size());

		List<UnitPojo> workunits = matchUnitDao.getAllWorkingMUUnits();
		assertEquals(1, workunits.size());

	}

	@Test
	public void test_findPIDUnitPojolist() {
		MatchUnitEntity unit = new MatchUnitEntity();
		List<UnitPojo> units = matchUnitDao.findPIDUnitPojolist(unit, false);
		assertEquals(8, units.size());

		unit.setType(UnitType.MM);
		units = matchUnitDao.findPIDUnitPojolist(unit, false);
		assertEquals(3, units.size());

		unit.setType(UnitType.SM);
		units = matchUnitDao.findPIDUnitPojolist(unit, false);
		assertEquals(0, units.size());

		unit.setType(UnitType.MU);
		units = matchUnitDao.findPIDUnitPojolist(unit, false);
		assertEquals(3, units.size());

		unit.setType(UnitType.DM);
		units = matchUnitDao.findPIDUnitPojolist(unit, false);
		assertEquals(1, units.size());

		unit.setType(UnitType.MR);
		units = matchUnitDao.findPIDUnitPojolist(unit, false);
		assertEquals(1, units.size());

		unit.setType(null);
		units = matchUnitDao.findPIDUnitPojolist(unit, true);
		assertEquals(9, units.size());

		unit.setType(UnitType.MM);
		unit.setMuId(4L);
		units = matchUnitDao.findPIDUnitPojolist(unit, false);
		assertEquals(1, units.size());

		unit.setType(UnitType.MM);
		unit.setMuId(null);
		unit.setState(UnitState.WORKING);
		units = matchUnitDao.findPIDUnitPojolist(unit, false);
		assertEquals(2, units.size());

		unit.setType(UnitType.MM);
		unit.setMuId(4L);
		unit.setState(UnitState.EXITED);
		units = matchUnitDao.findPIDUnitPojolist(unit, false);
		assertEquals(0, units.size());

		unit.setType(UnitType.SM);
		unit.setMuId(333L);
		unit.setState(null);
		units = matchUnitDao.findPIDUnitPojolist(unit, false);
		assertEquals(0, units.size());

		unit.setType(UnitType.SM);
		unit.setMuId(null);
		unit.setState(UnitState.WORKING);
		units = matchUnitDao.findPIDUnitPojolist(unit, false);
		assertEquals(0, units.size());

		unit.setType(UnitType.SM);
		unit.setMuId(333L);
		unit.setState(UnitState.WORKING);
		units = matchUnitDao.findPIDUnitPojolist(unit, false);
		assertEquals(0, units.size());

		unit.setType(UnitType.MU);
		unit.setMuId(21L);
		unit.setState(null);
		units = matchUnitDao.findPIDUnitPojolist(unit, false);
		assertEquals(1, units.size());

		unit.setType(UnitType.MU);
		unit.setMuId(null);
		unit.setState(UnitState.WORKING);
		units = matchUnitDao.findPIDUnitPojolist(unit, false);
		assertEquals(1, units.size());

		unit.setType(UnitType.MU);
		unit.setMuId(21L);
		unit.setState(UnitState.EXITED);
		units = matchUnitDao.findPIDUnitPojolist(unit, false);
		assertEquals(0, units.size());

		unit.setType(UnitType.DM);
		unit.setMuId(102L);
		unit.setState(null);
		units = matchUnitDao.findPIDUnitPojolist(unit, false);
		assertEquals(1, units.size());

		unit.setType(UnitType.DM);
		unit.setMuId(null);
		unit.setState(UnitState.WORKING);
		units = matchUnitDao.findPIDUnitPojolist(unit, false);
		assertEquals(1, units.size());

		unit.setType(UnitType.DM);
		unit.setMuId(102L);
		unit.setState(UnitState.EXITED);
		units = matchUnitDao.findPIDUnitPojolist(unit, false);
		assertEquals(0, units.size());

		unit.setType(UnitType.MR);
		unit.setMuId(202L);
		unit.setState(null);
		units = matchUnitDao.findPIDUnitPojolist(unit, false);
		assertEquals(1, units.size());

		unit.setType(UnitType.MR);
		unit.setMuId(null);
		unit.setState(UnitState.WORKING);
		units = matchUnitDao.findPIDUnitPojolist(unit, false);
		assertEquals(1, units.size());

		unit.setType(UnitType.MR);
		unit.setMuId(202L);
		unit.setState(UnitState.TIMED_OUT);
		units = matchUnitDao.findPIDUnitPojolist(unit, false);
		assertEquals(0, units.size());
	}

	@Test
	public void test_getMMbyMuId() {
		long muId = 3;
		MatchManagerEntity mm = matchUnitDao.getMMbyMuId(muId);
		assertEquals(null, mm);

		muId = 4;
		mm = matchUnitDao.getMMbyMuId(muId);
		assertNotNull(mm);
		assertEquals(4, mm.getMmId());
		assertEquals("http://127.0.0.1:8080/matchmanager", mm.getContactUrl());
		assertEquals(UnitState.valueOf("WORKING"), mm.getState());
		assertEquals("127.0.0.1", mm.getUniqueId());
	}

}
