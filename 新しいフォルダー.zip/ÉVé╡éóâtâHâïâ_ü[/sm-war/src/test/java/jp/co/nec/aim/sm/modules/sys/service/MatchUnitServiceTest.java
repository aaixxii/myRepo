package jp.co.nec.aim.sm.modules.sys.service;

import static org.junit.Assert.assertEquals;

import java.util.List;

import javax.sql.DataSource;

import jp.co.nec.aim.sm.common.constant.UnitState;
import jp.co.nec.aim.sm.common.constant.UnitType;
import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.MatchUnitEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.UnitPojo;
import jp.co.nec.aim.sm.test.common.util.CommonUtils;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional(value = "oracleTXManager")
public class MatchUnitServiceTest {

	@Autowired
	UnitService matchUnitService;

	@Autowired
	@Qualifier("oracleDataSource")
	DataSource datasource;

	JdbcTemplate jdbcTemplate;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		jdbcTemplate = new JdbcTemplate(datasource);
		CommonUtils.DeleteOracleData(jdbcTemplate);
		CommonUtils.prepareMATCH_UNITS(jdbcTemplate);
	}

	@After
	public void tearDown() throws Exception {
		CommonUtils.DeleteOracleData(jdbcTemplate);
	}

	@Test
	public void test_findunitnull_01() {
		MatchUnitEntity unit = new MatchUnitEntity();
		List<UnitPojo> mupage = matchUnitService.findAllUnitsList(unit, false);
		assertEquals(5, mupage.size());
	}

	@Test
	public void test_findunit_State_01() {
		MatchUnitEntity unit = new MatchUnitEntity();
		unit.setState(UnitState.WORKING);
		List<UnitPojo> mupage = matchUnitService.findAllUnitsList(unit, false);
		assertEquals(3, mupage.size());
	}

	@Test
	public void test_findunit_UnitType_01() {
		MatchUnitEntity unit = new MatchUnitEntity();
		unit.setType(UnitType.DM);
		List<UnitPojo> mupage = matchUnitService.findAllUnitsList(unit, false);
		assertEquals(1, mupage.size());
	}

	@Test
	public void test_findunit_ManagedUnitId_01() {
		MatchUnitEntity unit = new MatchUnitEntity();
		unit.setMuId(202l);
		List<UnitPojo> mupage = matchUnitService.findAllUnitsList(unit, false);
		assertEquals(1, mupage.size());
	}

	@Test
	public void test_findunitnull() {
		MockHttpServletRequest request = new MockHttpServletRequest();
		MockHttpServletResponse response = new MockHttpServletResponse();
		Page<UnitPojo> page = new Page<UnitPojo>(request, response);
		MatchUnitEntity unit = new MatchUnitEntity();
		Page<UnitPojo> mupage = matchUnitService.find(page, unit);
		assertEquals(0, mupage.getFirst());
		assertEquals(5, mupage.getMaxResults());
		assertEquals(5, mupage.getCount());
		assertEquals(5, mupage.getList().size());
	}

	@Test
	public void test_find_page() {
		Page<UnitPojo> page = new Page<UnitPojo>(1, 50);
		MatchUnitEntity unit = new MatchUnitEntity();
		Page<UnitPojo> mupage = matchUnitService.find(page, unit);
		assertEquals(0, mupage.getFirst());
		assertEquals(5, mupage.getMaxResults());
		assertEquals(5, mupage.getCount());
		assertEquals(5, mupage.getList().size());
	}

	@Test
	public void test_findunit_State() {
		MockHttpServletRequest request = new MockHttpServletRequest();
		MockHttpServletResponse response = new MockHttpServletResponse();
		Page<UnitPojo> page = new Page<UnitPojo>(request, response);
		MatchUnitEntity unit = new MatchUnitEntity();
		unit.setState(UnitState.WORKING);
		Page<UnitPojo> mupage = matchUnitService.find(page, unit);
		assertEquals(0, mupage.getFirst());
		assertEquals(3, mupage.getMaxResults());
		assertEquals(3, mupage.getCount());
		assertEquals(3, mupage.getList().size());
	}

	@Test
	public void test_findunit_UnitType() {
		MockHttpServletRequest request = new MockHttpServletRequest();
		MockHttpServletResponse response = new MockHttpServletResponse();
		Page<UnitPojo> page = new Page<UnitPojo>(request, response);
		MatchUnitEntity unit = new MatchUnitEntity();
		unit.setType(UnitType.DM);
		Page<UnitPojo> mupage = matchUnitService.find(page, unit);
		assertEquals(0, mupage.getFirst());
		assertEquals(1, mupage.getMaxResults());
		assertEquals(1, mupage.getCount());
		assertEquals(1, mupage.getList().size());
	}

	@Test
	public void test_findunit_ManagedUnitId() {
		MockHttpServletRequest request = new MockHttpServletRequest();
		MockHttpServletResponse response = new MockHttpServletResponse();
		Page<UnitPojo> page = new Page<UnitPojo>(request, response);
		MatchUnitEntity unit = new MatchUnitEntity();
		unit.setMuId(202l);
		Page<UnitPojo> mupage = matchUnitService.find(page, unit);
		assertEquals(0, mupage.getFirst());
		assertEquals(1, mupage.getMaxResults());
		assertEquals(1, mupage.getCount());
		assertEquals(1, mupage.getList().size());
	}
}
