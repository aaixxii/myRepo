package jp.co.nec.aim.sm.modules.sys.web;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import jp.co.nec.aim.sm.modules.sys.oracle.repository.MonitorRepository;
import jp.co.nec.aim.sm.modules.sys.postgres.entity.EventLogEntity;
import jp.co.nec.aim.sm.modules.sys.postgres.repository.EventLogRepository;
import jp.co.nec.aim.sm.modules.sys.service.EventLogService;
import jp.co.nec.aim.sm.modules.sys.service.MonitorService;
import mockit.Mock;
import mockit.MockUp;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional(value = "oracleTXManager")
public class MonitorControllerTest {
	@Autowired
	MonitorController monitorController;

	@Autowired
	private MonitorRepository monitorRepository;
	@Autowired
	private MonitorService monitorService;

	@Autowired
	@Qualifier("oracleDataSource")
	DataSource datasource;
	
	@Autowired
	private EventLogRepository eventLogRepository;
	@Autowired
	private EventLogService eventLogService;

	@Autowired
	@Qualifier("postgresDataSource")
	DataSource postGressDatasource;
	
	

	JdbcTemplate jdbcTemplate;
	JdbcTemplate postGressJdbcTemplate;

	private MockMvc mockMvc;

	@Before
	public void setUp() throws Exception {
		jdbcTemplate = new JdbcTemplate(datasource);
		postGressJdbcTemplate = new JdbcTemplate(postGressDatasource);
		clear();
		mockMvc = MockMvcBuilders.standaloneSetup(monitorController).build();
	}

	@After
	public void tearDown() throws Exception {
		clear();
	}

	@Test
	public void testGetComponentStatusChartData() {
		String insertMM = "insert into MATCH_MANAGERS(mm_id,unique_id,state) values(?,?,?)";
		String insertMR = "insert into MAP_REDUCERS(mr_id,unique_id,state) values(?,?,?)";
		String insertDM = "insert into DATA_MANAGERS(dm_id,unique_id,state) values(?,?,?)";
		String insertMU = "insert into MATCH_UNITS(mu_id,unique_id,state) values(?,?,?)";

		Long[] mmIds = { 100L, 101L, 102L };
		Long[] mrIds = { 200L, 201L, 202L, 203L, 204L };
		Long[] dmIds = { 300L, 301L, 302L };
		Long[] muIds = { 400L, 401L, 402L, 403L, 404L, 405L, 406L };
		String[] mmStauts = { "working", "timeout", "exit" };
		String[] mrStauts = { "working", "working", "timeout", "timeout",
				"exit" };
		String[] dmStauts = { "working", "exit", "timeout" };
		String[] muStauts = { "working", "working", "working", "timeout",
				"exit", "exit", "exit" };
		for (int i = 0; i < mmIds.length; i++) {
			jdbcTemplate.update(insertMM,
					new Object[] { mmIds[i], String.valueOf(mmIds[i]),
							mmStauts[i] });
		}
		for (int i = 0; i < mrIds.length; i++) {
			jdbcTemplate.update(insertMR,
					new Object[] { mrIds[i], String.valueOf(mrIds[i]),
							mrStauts[i] });
		}
		for (int i = 0; i < dmIds.length; i++) {
			jdbcTemplate.update(insertDM,
					new Object[] { dmIds[i], String.valueOf(dmIds[i]),
							dmStauts[i] });
		}
		for (int i = 0; i < muIds.length; i++) {
			jdbcTemplate.update(insertMU,
					new Object[] { muIds[i], String.valueOf(muIds[i]),
							muStauts[i] });
		}
		jdbcTemplate.execute("commit");

		try {
			mockMvc.perform(
					get("/chart/status").accept(MediaType.APPLICATION_JSON))
					.andExpect(status().is(200))
					.andExpect(jsonPath("$.mm.working").value(1))
					.andExpect(jsonPath("$.mm.exit").value(1))
					.andExpect(jsonPath("$.mm.timeout").value(1))
					.andExpect(jsonPath("$.mr.working").value(2))
					.andExpect(jsonPath("$.mr.timeout").value(2))
					.andExpect(jsonPath("$.mr.exit").value(1))
					.andExpect(jsonPath("$.dm.working").value(1))
					.andExpect(jsonPath("$.dm.exit").value(1))
					.andExpect(jsonPath("$.dm.timeout").value(1))
					.andExpect(jsonPath("$.mu.working").value(3))
					.andExpect(jsonPath("$.mu.exit").value(3))
					.andExpect(jsonPath("$.mu.timeout").value(1));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void testGetComponentStatusChartData_null()	 {
		try {
			mockMvc.perform(
					get("/chart/status").accept(MediaType.APPLICATION_JSON))
					.andExpect(status().is(200))
					.andExpect(jsonPath("$.mm.WORKING").value(0))
					.andExpect(jsonPath("$.mm.TIMED_OUT").value(0))
					.andExpect(jsonPath("$.mm.EXITED").value(0))
					.andExpect(jsonPath("$.mr.WORKING").value(0))
					.andExpect(jsonPath("$.mr.TIMED_OUT").value(0))
					.andExpect(jsonPath("$.mr.EXITED").value(0))
					.andExpect(jsonPath("$.dm.WORKING").value(0))
					.andExpect(jsonPath("$.dm.EXITED").value(0))
					.andExpect(jsonPath("$.dm.TIMED_OUT").value(0))
					.andExpect(jsonPath("$.mu.WORKING").value(0))
					.andExpect(jsonPath("$.mu.EXITED").value(0))
					.andExpect(jsonPath("$.mu.TIMED_OUT").value(0));
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	@Test
	public void testGetComponentStatusChartData_Exception() {
		try {
			mockMvc.perform(
					get("/chart/status").accept(MediaType.APPLICATION_JSON))
					.andExpect(status().is(200))
					.andExpect(jsonPath("$.mm.WORKING").value(0))
					.andExpect(jsonPath("$.mm.TIMED_OUT").value(0))
					.andExpect(jsonPath("$.mm.EXITED").value(0))
					.andExpect(jsonPath("$.mr.WORKING").value(0))
					.andExpect(jsonPath("$.mr.TIMED_OUT").value(0))
					.andExpect(jsonPath("$.mr.EXITED").value(0))
					.andExpect(jsonPath("$.dm.WORKING").value(0))
					.andExpect(jsonPath("$.dm.EXITED").value(0))
					.andExpect(jsonPath("$.dm.TIMED_OUT").value(0))
					.andExpect(jsonPath("$.mu.WORKING").value(0))
					.andExpect(jsonPath("$.mu.EXITED").value(0))
					.andExpect(jsonPath("$.mu.TIMED_OUT").value(0));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testGetDBMonitorChartData() {
		String insertsql = ""
				+ "insert into PERSON_BIOMETRICS(BIOMETRICS_ID,EXTERNAL_ID,BIOMETRIC_DATA,"
				+ "BIOMETRIC_DATA_LEN,REGISTED_TS,CORRUPTED_FLAG,EVENT_ID,CONTAINER_ID)"
				+ " values(?,?,HEXTORAW('3E00210102CDA000C9'),50,1000,0,?,?)";				
		Long[] pbioIds = { 1000L, 1001L, 1002L, 1003L, 1004L, 1005L, 1006L,
				1007L };
		Integer[] containerIds = { 1, 1, 331, 331, 332, 3, 4, 336 };
		for (int i = 0; i < pbioIds.length; i++) {
			jdbcTemplate.update(insertsql,
					new Object[] { pbioIds[i], String.valueOf(pbioIds[i]),
							i + 1, containerIds[i] });
		}
		
		String insSegTabSql = "insert into segments(segment_id,container_id,bio_id_start,bio_id_end,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)"
				+ " values(?,?,?,?,333,1,?,?,333)";		
		Long segmentIds[] = {2000L,2001L,2002L,2003L,2004L,2005L,2006L,2007L};
		for (int i = 0 ;i < segmentIds.length; i++) {
			jdbcTemplate.update(insSegTabSql,new Object[] {segmentIds[i],containerIds[i],pbioIds[i], pbioIds[i],i,i});
		}
		
		jdbcTemplate.execute("commit");
		try {
			mockMvc.perform(
					get("/chart/database?scopeId=1").accept(
							MediaType.APPLICATION_JSON))
					.andExpect(status().is(200))
					.andExpect(jsonPath("$.tenprintMonitor.SDBTM").value(1))
					.andExpect(jsonPath("$.tenprintMonitor.RDBT").value(2))
					.andExpect(jsonPath("$.tenprintMonitor.RDBTM").value(2))
					.andExpect(jsonPath("$.latentMonitor.LDBM").value(1))
					.andExpect(jsonPath("$.latentMonitor.SDBL").value(1))
					.andExpect(jsonPath("$.latentMonitor.RDBL").value(1));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testGetTransactionMonitorChartData() {
		String updateInquerySql = "update inquiry_traffic set job_complete_count= 2";		
		jdbcTemplate.update(updateInquerySql);		
		jdbcTemplate.execute("commit");
		String extractSql = "insert into extract_complete_count(complete_count,complete_ts) values(5,300)";
		jdbcTemplate.update(extractSql);
		jdbcTemplate.execute("commit");
		jdbcTemplate.execute("commit");
		
		new MockUp<MonitorService>() {
			@Mock
			Map<String, Map<String, Long>> getTransactionMonitorData(){
				return createResultMap();
			}
		};
		try {
			mockMvc.perform(
					get("/chart/transactions").accept(
							MediaType.APPLICATION_JSON))
					.andExpect(status().is(200))
					.andExpect(jsonPath("$.tenprintFunction.TLI").value(2))
					.andExpect(jsonPath("$.tenprintFunction.II").value(2))
					.andExpect(jsonPath("$.tenprintFunction.TI").value(2))
					.andExpect(jsonPath("$.tenprintFunction.TLIP").value(2))
					.andExpect(jsonPath("$.tenprintFunction.FI").value(2))
					.andExpect(jsonPath("$.latentFunction.LLIP").value(2))
					.andExpect(jsonPath("$.latentFunction.LI").value(2))
					.andExpect(jsonPath("$.latentFunction.LLI").value(2))
					.andExpect(jsonPath("$.latentFunction.LIP").value(2))
					.andExpect(jsonPath("$.extract.EXTRACT").value(5));

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testGetMuExtractLoadChartData() {
		String insertMuSql = "insert into MATCH_UNITS(mu_id,unique_id,state) values(?,?,'WORKING')";
		String insertMuExtractLoadSql = "insert into MU_EXTRACT_LOAD(mu_id,pressure,update_ts) values(?,?,1000)";		
		Long[] muIds = { 1000L, 1002L, 1003L, 1004L, 1005L };
		Long muExtractLoad[] = { 5L, 6L, 7L, 8L, 9L };		
		for (int i = 0; i < muIds.length; i++) {
			jdbcTemplate.update(insertMuSql,
					new Object[] { muIds[i], String.valueOf(muIds[i]) });
			jdbcTemplate.update(insertMuExtractLoadSql, new Object[] {
					muIds[i], muExtractLoad[i] });		
		}
		jdbcTemplate.execute("commit");
		try {
			mockMvc.perform(
					get("/chart/muExtractloads").accept(MediaType.APPLICATION_JSON))
					.andExpect(status().is(200))
					.andExpect(jsonPath("$.1000").value(5))
					.andExpect(jsonPath("$.1002").value(6))
					.andExpect(jsonPath("$.1003").value(7))
					.andExpect(jsonPath("$.1004").value(8))
					.andExpect(jsonPath("$.1005").value(9));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void testGetMuInquiryLoadChartData() {
		String insertMuSql = "insert into MATCH_UNITS(mu_id,unique_id,state) values(?,?,'WORKING')";		
		String insertMuInquiyLoadSql = "insert into MU_INQUIRY_LOAD(mu_id,pressure,report_ts) values(?,?,1005)";
		Long[] muIds = { 1000L, 1002L, 1003L, 1004L, 1005L };	
		Long muInquiryLoad[] = { 10L, 11L, 12L, 13L, 14L };
		for (int i = 0; i < muIds.length; i++) {
			jdbcTemplate.update(insertMuSql,
					new Object[] { muIds[i], String.valueOf(muIds[i]) });	
			jdbcTemplate.update(insertMuInquiyLoadSql, new Object[] { muIds[i],
					muInquiryLoad[i] });
		}
		jdbcTemplate.execute("commit");
		try {
			mockMvc.perform(
					get("/chart/muInquiryloads").accept(MediaType.APPLICATION_JSON))
					.andExpect(status().is(200))
					.andExpect(jsonPath("$.1000").value(10))
					.andExpect(jsonPath("$.1002").value(11))
					.andExpect(jsonPath("$.1003").value(12))
					.andExpect(jsonPath("$.1004").value(13))
					.andExpect(jsonPath("$.1005").value(14));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}	
	

	@Test
	public void testGetMuLoadChartData_Exception() {
		try {
			mockMvc.perform(
					get("/chart/muloads").accept(MediaType.APPLICATION_JSON))
					.andExpect(jsonPath("$.ERROR").value(-9999))
					.andExpect(status().isInternalServerError());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void getAlarmInfo() {
		eventLogRepository.deleteAll();
		Date date = new Date();
		Timestamp timeStamp = new Timestamp(date.getTime());		
		String tmp = timeStamp.toString().substring(0, 18);		
		Timestamp ts = Timestamp.valueOf(tmp);
		String msgArray[][] = { { "844000303", "400000" },
				{ "044000300", "100000" }, { "044000300", "100000" },
				{ "044000300", "100000" }, { "144114000", "200000" },
				{ "044000300", "100000" }, { "040000000", "110000" } };		
		for (int i = 0; i < msgArray.length; i++) {
			EventLogEntity eventLogEntity = new EventLogEntity();
			eventLogEntity.setEventId(i + 1);
			eventLogEntity.setMessage("Test Message.");
			eventLogEntity.setMessageCode(msgArray[i][0]);
			eventLogEntity.setCls("jp.co.nec.aim.sm.web.test");
			eventLogEntity.setTimestamp(ts);
			eventLogEntity.setMessageType(msgArray[i][1]);
			eventLogEntity.setUnitId(361l + i);
			eventLogRepository.saveAndFlush(eventLogEntity);
		}		
		String alarmTimeBefore = "100000";
		try {
			mockMvc.perform(
					get("/chart/event").accept(MediaType.APPLICATION_JSON)
					.param("alarmTimeBefore", alarmTimeBefore))					
					.andExpect(status().is(200))
					.andExpect(jsonPath("$.lastAlm").value(ts.toString()));	
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void testGetCurrentDbTime() {
		try {
			mockMvc.perform(
					get("/chart/time").accept(MediaType.APPLICATION_JSON))									
					.andExpect(status().is(200))
					.andExpect(jsonPath("$.time").exists());	
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	@Test
	public void getSlbSetting() {
		String sql = "insert into SYSTEM_CONFIG(CONFIG_ID, PROPERTY_NAME,PROPERTY_VALUE) values(3000,'LOAD_BALANCER.ENABLED','true')";
		jdbcTemplate.execute(sql);		
		try {
			mockMvc.perform(
					get("/chart/slb").accept(MediaType.APPLICATION_JSON))
					.andExpect(status().is(200))
					.andExpect(jsonPath("$.slb").value(true));					
		} catch (Exception e) {
			e.printStackTrace();
		}
	}	

	public void clear() {
		jdbcTemplate.execute("delete from MATCH_MANAGERS");
		jdbcTemplate.execute("delete from MAP_REDUCERS");
		jdbcTemplate.execute("delete from DATA_MANAGERS");
		jdbcTemplate.execute("delete from FE_JOB_QUEUE");
		jdbcTemplate.execute("delete from FE_LOT_JOBS");
		jdbcTemplate.execute("delete from MATCH_UNITS");
		jdbcTemplate.execute("delete from JOB_QUEUE");
		jdbcTemplate.execute("delete from PERSON_BIOMETRICS");
		jdbcTemplate.execute("delete from MU_EXTRACT_LOAD");
		jdbcTemplate.execute("delete from MU_EXTRACT_LOAD");
		jdbcTemplate.execute("delete from SYSTEM_CONFIG");
		jdbcTemplate.execute("delete from segments");
		jdbcTemplate.execute("delete from  extract_complete_count ");
		jdbcTemplate.execute("update inquiry_traffic set job_complete_count= 0");		
		jdbcTemplate.execute("commit");
	}
	public String pringJson( Object object) {
		ObjectMapper mapper = new ObjectMapper();
        String jsonStr = null;
		try {
			jsonStr = mapper.writerWithDefaultPrettyPrinter()
			        .writeValueAsString(object);
		} catch (JsonProcessingException e) {			
			e.printStackTrace();
		}
		return jsonStr;		
	}
	
	public  Map<String, Map<String, Long>> createResultMap() {
		Map<String , Map<String,Long>> transactionMaps = new HashMap<String , Map<String,Long>>();		
		 Map<String,Long> tenprintMap = new HashMap<>();		 
		 tenprintMap.put("TLI", 2L);
		 tenprintMap.put("II", 2L);
		 tenprintMap.put("TI", 2L);
		 tenprintMap.put("TLIP", 2L);
		 tenprintMap.put("FI", 2L); 
		 
		 Map<String,Long> latentMap = new HashMap<>();
		 latentMap.put("LLIP", 2L);
		 latentMap.put("LI", 2L);
		 latentMap.put("LLI", 2L);
		 latentMap.put("LIP", 2L);
		 
		 Map<String,Long> extractMap = new HashMap<>();
		 extractMap.put("EXTRACT", 5L);
		
		 transactionMaps.put("tenprintFunction", tenprintMap);
		 transactionMaps.put("latentFunction", latentMap);
		 transactionMaps.put("extract", extractMap);
		 return transactionMaps;		
	}
	
	private Map<String, Map<String, Integer>> createErrorResponseMap() {
		Map<String, Map<String, Integer>> errorResponse = new HashMap<String, Map<String, Integer>>();
		Map<String, Integer> errorMap = new HashMap<String, Integer>();
		errorMap.put("NoData", new Integer(-9999));
		errorResponse.put("ERROR", errorMap);
		pringJson(errorMap);
		return errorResponse;
	}
	
	@Test
	public void testprintJson() {
		Map<String, Map<String, Integer>> errors = createErrorResponseMap();
		System.out.println(pringJson(errors));
	}
	

}
