package jp.co.nec.aim.sm.modules.sys.web.listener;

import static org.apache.commons.io.IOUtils.write;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.fail;

import java.io.IOException;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.nec.aim.message.proto.AIMMessages.PBEnterResponse;
import jp.co.nec.aim.sm.common.constant.SMConstant;
import jp.co.nec.aim.sm.common.threadpool.SMExecutor;
import jp.co.nec.aim.sm.common.threadpool.StandardThreadExecutor;
import jp.co.nec.aim.sm.mm.listener.MMQueueListener;
import jp.co.nec.aim.sm.mm.listener.MatchManagerQueueListener;
import jp.co.nec.aim.sm.modules.sys.web.register.CommunicationThread;
import jp.co.nec.aim.sm.test.common.util.HttpTestServer;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mortbay.jetty.Handler;
import org.mortbay.jetty.HttpConnection;
import org.mortbay.jetty.Request;
import org.mortbay.jetty.handler.AbstractHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
public class SystemManagerListenerTest {
	@Autowired
	MatchManagerQueueListener queueListener;

	private SystemManagerListener listener = new SystemManagerListener();
	private static HttpTestServer _server;
	private static int eventcase = 0;

	public static Handler getMockHandler() {
		Handler handler = new AbstractHandler() {
			public void handle(String target, HttpServletRequest request,
					HttpServletResponse response, int dispatch)
					throws IOException, ServletException {
				Request baseRequest = request instanceof Request ? (Request) request
						: HttpConnection.getCurrentConnection().getRequest();
				switch (eventcase) {
				case 0:
					response.setStatus(200);
					PBEnterResponse.Builder builder = PBEnterResponse
							.newBuilder();
					builder.setId(30);
					builder.build().writeTo(response.getOutputStream());
					break;
				case 1:
					response.setStatus(500);
					write("<html><head><title>JBoss Web/3.0.0-CR2 - Error report</title></head></html>",
							response.getOutputStream());
				}
				response.setContentType("text/html;charset=utf-8");
				response.setCharacterEncoding("UTF-8");
				baseRequest.setHandled(true);
			}

		};
		return handler;
	}

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		_server = new HttpTestServer(22);
		_server.start(getMockHandler());
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		if (_server != null) {
			_server.stop();
		}
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
		eventcase = 0;
	}

	@Test
	public void testSendEnter() {
		listener.contextInitialized(null);

		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		CommunicationThread.doStop();
		Assert.assertEquals(null, SMConstant.getSM_ID());
	}

	@Test
	public void testSendExit() {
		queueListener.startupQueueListener();
		queueListener.startQueueNotifier();
		SMExecutor executor = StandardThreadExecutor.getInstance();
		// save the matchManagerQueueListener instance
		MMQueueListener.getInstance().setListener(queueListener);
		MockHttpServletRequest request = new MockHttpServletRequest();
		ServletContextEvent sce = new ServletContextEvent(
				request.getServletContext());
		listener.contextDestroyed(sce);

		assertNull(MMQueueListener.getInstance().getListener());
		try {
			executor.execute(null);
			fail();
		} catch (IllegalStateException e) {

		} catch (Exception e) {
			fail();
		} finally {
			queueListener.shutdownQueueNotifier();
			queueListener.shutdownQueueListener();
		}
	}
}
