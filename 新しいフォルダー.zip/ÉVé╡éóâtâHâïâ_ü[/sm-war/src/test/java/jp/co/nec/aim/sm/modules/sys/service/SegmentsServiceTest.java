package jp.co.nec.aim.sm.modules.sys.service;

import static org.junit.Assert.assertEquals;

import javax.sql.DataSource;

import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.MuSegmentEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.SegmentSegmentReport;
import jp.co.nec.aim.sm.test.common.util.CommonUtils;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional(value = "oracleTXManager")
public class SegmentsServiceTest {

	@Autowired
	SegmentsService segService;

	@Autowired
	@Qualifier("oracleDataSource")
	DataSource datasource;

	JdbcTemplate jdbcTemplate;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		jdbcTemplate = new JdbcTemplate(datasource);
		CommonUtils.DeleteOracleData(jdbcTemplate);
		CommonUtils.prepareMU_SEG_REPORTS(jdbcTemplate);
		CommonUtils.prepare_JOB_01(jdbcTemplate);
	}

	@After
	public void tearDown() throws Exception {
		CommonUtils.DeleteOracleData(jdbcTemplate);
	}

	@Test
	public void testFindSegmentAllocation() {
		Page<MuSegmentEntity> page = new Page<MuSegmentEntity>(1, 10);
		MuSegmentEntity seg = new MuSegmentEntity();
		Page<MuSegmentEntity> segPage = segService.findSegmentAllocation(page,
				seg);
		assertEquals(300, segPage.getCount());
		assertEquals(10, segPage.getList().size());
	}

	@Test
	public void testGetSegmentSegmentReports() {
		Page<SegmentSegmentReport> page = new Page<SegmentSegmentReport>(1, 10);
		long muId = 21;
		Page<SegmentSegmentReport> segReportPage = segService
				.getSegmentSegmentReports(page, muId);

		assertEquals(100, segReportPage.getCount());
		assertEquals(10, segReportPage.getList().size());
	}

	@Test
	public void testGetSegmentSegmentReports_101() {
		Page<SegmentSegmentReport> page = new Page<SegmentSegmentReport>(1, 10);
		long muId = 101;
		Page<SegmentSegmentReport> segReportPage = segService
				.getSegmentSegmentReports(page, muId);

		assertEquals(100, segReportPage.getCount());
		assertEquals(10, segReportPage.getList().size());
	}

	@Test
	public void testGetSegmentSegmentReports_100() {
		Page<SegmentSegmentReport> page = new Page<SegmentSegmentReport>(1, 10);
		long muId = 100;
		Page<SegmentSegmentReport> segReportPage = segService
				.getSegmentSegmentReports(page, muId);

		assertEquals(100, segReportPage.getCount());
		assertEquals(10, segReportPage.getList().size());
	}

	@Test
	public void testGetSegmentSegmentReports_102() {
		Page<SegmentSegmentReport> page = new Page<SegmentSegmentReport>(1, 10);
		long muId = 102;
		Page<SegmentSegmentReport> segReportPage = segService
				.getSegmentSegmentReports(page, muId);

		assertEquals(0, segReportPage.getCount());
		assertEquals(0, segReportPage.getList().size());
	}

}
