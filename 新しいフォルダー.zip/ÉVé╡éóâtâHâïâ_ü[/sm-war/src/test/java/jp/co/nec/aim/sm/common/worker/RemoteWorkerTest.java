package jp.co.nec.aim.sm.common.worker;

import static org.junit.Assert.assertTrue;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.nec.aim.sm.common.async.agent.AsyncAgent;
import jp.co.nec.aim.sm.common.constant.ProcessType;
import jp.co.nec.aim.sm.common.constant.UnitType;
import jp.co.nec.aim.sm.common.threadpool.SMExecutor;
import jp.co.nec.aim.sm.common.threadpool.StandardThreadExecutor;
import jp.co.nec.aim.sm.test.common.util.HttpTestServer;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.mortbay.jetty.Handler;
import org.mortbay.jetty.HttpConnection;
import org.mortbay.jetty.Request;
import org.mortbay.jetty.handler.AbstractHandler;

//
@Ignore
public class RemoteWorkerTest {

	private static HttpTestServer _server;
	private String ipAddress;
	private UnitType type;
	private ProcessType processType;
	private static StringBuffer messages = new StringBuffer();
	private SMExecutor executor = StandardThreadExecutor.getInstance();

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		_server = new HttpTestServer(65521);
		_server.start(getMockHandler());
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		if (_server != null) {
			_server.stop();
		}
	}

	@Before
	public void setUp() throws Exception {
		messages.setLength(0);
	}

	@After
	public void tearDown() throws Exception {
		messages.setLength(0);
	}

	public static Handler getMockHandler() {
		Handler handler = new AbstractHandler() {
			public void handle(String target, HttpServletRequest request,
					HttpServletResponse response, int dispatch)
					throws IOException, ServletException {
				Request baseRequest = request instanceof Request ? (Request) request
						: HttpConnection.getCurrentConnection().getRequest();
				response.setStatus(200);
				response.setContentType("text/html;charset=utf-8");
				response.setCharacterEncoding("UTF-8");
				baseRequest.setHandled(true);
			}

		};
		return handler;
	}

	@Test
	public void test_DM_START() {
		ipAddress = "127.0.0.1";
		type = UnitType.DM;
		processType = ProcessType.START;
		AsyncAgent agent = AsyncAgent.newInstance(new Object[] { ipAddress,
				type.name().toLowerCase(), processType, messages });
		// executor.execute(new OperateRemoteServiceWorker(agent));

		while (true) {
			if (agent.isDone()) {
				break;
			}
		}

		assertTrue(messages
				.toString()
				.contains(
						"remote server ssh file location: /home/smuser1/.ssh/id_rsa<br/>"));
		assertTrue(messages.toString().contains(
				"remote server ipaddress: 127.0.0.1"));
		assertTrue(messages.toString().contains(
				"unable to authenticate remote user"));
		assertTrue(messages.toString().contains(
				"#executed, start remote service."));
	}

	@Test
	public void test_MM_START() {
		ipAddress = "127.0.0.1";
		type = UnitType.MM;
		processType = ProcessType.START;
		AsyncAgent agent = AsyncAgent.newInstance(new Object[] { ipAddress,
				type.name().toLowerCase(), processType, messages });
		// executor.execute(new OperateRemoteServiceWorker(agent));

		while (true) {
			if (agent.isDone()) {
				break;
			}
		}

		assertTrue(messages
				.toString()
				.contains(
						"remote server ssh file location: /home/smuser1/.ssh/id_rsa<br/>"));
		assertTrue(messages.toString().contains(
				"remote server ipaddress: 127.0.0.1"));
		assertTrue(messages.toString().contains(
				"unable to authenticate remote user"));
		assertTrue(messages.toString().contains(
				"#executed, start remote service."));
	}

	@Test
	public void test_MU_START() {
		ipAddress = "127.0.0.1";
		type = UnitType.MU;
		processType = ProcessType.START;
		AsyncAgent agent = AsyncAgent.newInstance(new Object[] { ipAddress,
				type.name().toLowerCase(), processType, messages });
		// executor.execute(new OperateRemoteServiceWorker(agent));

		while (true) {
			if (agent.isDone()) {
				break;
			}
		}

		assertTrue(messages
				.toString()
				.contains(
						"remote server ssh file location: /home/smuser1/.ssh/id_rsa<br/>"));
		assertTrue(messages.toString().contains(
				"remote server ipaddress: 127.0.0.1"));
		assertTrue(messages.toString().contains(
				"unable to authenticate remote user"));
		assertTrue(messages.toString().contains(
				"#executed, start remote service."));
	}

	@Test
	public void test_SM_START() {
		ipAddress = "127.0.0.1";
		type = UnitType.SM;
		processType = ProcessType.START;
		AsyncAgent agent = AsyncAgent.newInstance(new Object[] { ipAddress,
				type.name().toLowerCase(), processType, messages });
		// executor.execute(new OperateRemoteServiceWorker(agent));

		while (true) {
			if (agent.isDone()) {
				break;
			}
		}

		assertTrue(messages
				.toString()
				.contains(
						"remote server ssh file location: /home/smuser1/.ssh/id_rsa<br/>"));
		assertTrue(messages.toString().contains(
				"remote server ipaddress: 127.0.0.1"));
		assertTrue(messages.toString().contains(
				"unable to authenticate remote user"));
		assertTrue(messages.toString().contains(
				"#executed, start remote service."));
	}

	@Test
	public void test_DM_STOP() {
		ipAddress = "127.0.0.1";
		type = UnitType.DM;
		processType = ProcessType.STOP;
		AsyncAgent agent = AsyncAgent.newInstance(new Object[] { ipAddress,
				type.name().toLowerCase(), processType, messages });
		// executor.execute(new OperateRemoteServiceWorker(agent));

		while (true) {
			if (agent.isDone()) {
				break;
			}
		}

		assertTrue(messages
				.toString()
				.contains(
						"remote server ssh file location: /home/smuser1/.ssh/id_rsa<br/>"));
		assertTrue(messages.toString().contains(
				"remote server ipaddress: 127.0.0.1"));
		assertTrue(messages.toString().contains(
				"unable to authenticate remote user"));
		assertTrue(messages.toString().contains(
				"#executed, stop remote service."));
	}

	@Test
	public void test_DM_STATUS() {
		ipAddress = "127.0.0.1";
		type = UnitType.DM;
		// processType = ProcessType.STATUS;
		AsyncAgent agent = AsyncAgent.newInstance(new Object[] { ipAddress,
				type.name().toLowerCase(), processType, messages });
		// executor.execute(new OperateRemoteServiceWorker(agent));

		while (true) {
			if (agent.isDone()) {
				break;
			}
		}

		assertTrue(messages
				.toString()
				.contains(
						"remote server ssh file location: /home/smuser1/.ssh/id_rsa<br/>"));
		assertTrue(messages.toString().contains(
				"remote server ipaddress: 127.0.0.1"));
		assertTrue(messages.toString().contains(
				"unable to authenticate remote user"));
		assertTrue(messages.toString().contains(
				"#executed, status remote service"));
	}

	@Test
	public void test_DM_FORCE_RESTART() {
		ipAddress = "127.0.0.1";
		type = UnitType.DM;
		// processType = ProcessType.FORCE_RESTART;
		AsyncAgent agent = AsyncAgent.newInstance(new Object[] { ipAddress,
				type.name().toLowerCase(), processType, messages });
		// executor.execute(new OperateRemoteServiceWorker(agent));

		while (true) {
			if (agent.isDone()) {
				break;
			}
		}

		assertTrue(messages
				.toString()
				.contains(
						"remote server ssh file location: /home/smuser1/.ssh/id_rsa<br/>"));
		assertTrue(messages.toString().contains(
				"remote server ipaddress: 127.0.0.1"));
		assertTrue(messages.toString().contains(
				"unable to authenticate remote user"));
		assertTrue(messages.toString().contains(
				"called remote service stop process"));
	}

	@Test
	public void test_DM_FORCE_STOP() {
		ipAddress = "127.0.0.1";
		type = UnitType.DM;
		// processType = ProcessType.FORCE_STOP;
		AsyncAgent agent = AsyncAgent.newInstance(new Object[] { ipAddress,
				type.name().toLowerCase(), processType, messages });
		// executor.execute(new OperateRemoteServiceWorker(agent));

		while (true) {
			if (agent.isDone()) {
				break;
			}
		}

		assertTrue(messages
				.toString()
				.contains(
						"remote server ssh file location: /home/smuser1/.ssh/id_rsa<br/>"));
		assertTrue(messages.toString().contains(
				"remote server ipaddress: 127.0.0.1"));
		assertTrue(messages.toString().contains(
				"unable to authenticate remote user"));
		assertTrue(messages.toString().contains(
				" #executed, forcestop remote service"));
	}
}
