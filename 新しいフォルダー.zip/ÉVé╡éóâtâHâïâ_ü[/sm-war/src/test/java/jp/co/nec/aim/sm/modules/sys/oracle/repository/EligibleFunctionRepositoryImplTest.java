package jp.co.nec.aim.sm.modules.sys.oracle.repository;

import static org.junit.Assert.assertEquals;

import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.MuEligibleFunctionEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.MuEligibleFunctionEntityPK;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.EligibleFunctionsPojo;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional(value = "oracleTXManager")
public class EligibleFunctionRepositoryImplTest {
	@Autowired
	EligibleFunctionRepository repository;

	@Autowired
	@Qualifier("oracleDataSource")
	DataSource datasource;

	JdbcTemplate jdbcTemplate;

	String[] formatName = new String[] { "RDBT", "RDBL", "LDB", "PBLNF" };
	String[] functionName = new String[] { "TI", "LI", "TLI", "LLI" };

	@Before
	public void before() {
		jdbcTemplate = new JdbcTemplate(datasource);
		cleanDB();
		prepareDB();
	}

	@After
	public void after() {
		cleanDB();
	}

	private void cleanDB() {
		jdbcTemplate.execute("delete from PERSON_BIOMETRICS");
		jdbcTemplate.execute("delete from FE_JOB_QUEUE");
		jdbcTemplate.execute("delete from JOB_QUEUE");
		jdbcTemplate.execute("delete from MU_ELIGIBLE_FUNCTIONS");
		jdbcTemplate.execute("delete from MATCH_UNITS");
		jdbcTemplate.execute("delete from FE_LOT_JOBS");
		// jdbcTemplate.execute("delete from AFIS_BINS");
		// jdbcTemplate.execute("delete from BINS");
		// jdbcTemplate.execute("delete from FORMAT_TYPES");
		// jdbcTemplate.execute("delete from FUNCTION_TYPES");
		jdbcTemplate.execute("commit");
	}

	private void prepareDB() {
		for (int i = 1; i <= 4; i++) {
			String sql = "insert into MATCH_UNITS(MU_ID, UNIQUE_ID, STATE,"
					+ "  VERSION) values(" + i + ", 'unique_" + i
					+ "', 'WORKING',  0)";
			jdbcTemplate.execute(sql);
		}
		// for (int i = 1; i <= 4; i++) {
		// String sql = "insert into FUNCTION_TYPES(FUNCTION_ID,"
		// + " FUNCTION_NAME, QUEUE_TYPE) values(" + i + ", '"
		// + functionName[i - 1] + "', " + i + ")";
		// jdbcTemplate.execute(sql);
		// }
		// for (int i = 1; i <= 4; i++) {
		// String sql = "insert into FORMAT_TYPES(FORMAT_ID, EMBEDDED_ID,"
		// + " FORMAT_NAME) values(" + i + ", " + i + ", '"
		// + formatName[i - 1] + "')";
		// jdbcTemplate.execute(sql);
		// }
		// for (int i = 1; i <= 4; i++) {
		// String sql = "insert into BINS(BIN_ID, FORMAT_ID, MIN_REDUNDANCY,"
		// + " VERSION_TARGETING_FLAG) values(" + i + ", " + i + ", "
		// + i + ", 0)";
		// jdbcTemplate.execute(sql);
		// }
		for (int i = 1; i <= 4; i++) {
			String sql = "insert into MU_ELIGIBLE_FUNCTIONS(MU_ID, FUNCTION_ID"
					+ ") values(" + i + ", " + i + ")";
			jdbcTemplate.execute(sql);
		}
	}

	@Test
	public void testFindEligibleFunctionPage() {
		Page<MuEligibleFunctionEntity> page = new Page<MuEligibleFunctionEntity>(
				1, 10);
		MuEligibleFunctionEntity entity = new MuEligibleFunctionEntity();
		// MuEligibleFunctionEntityPK id = new MuEligibleFunctionEntityPK();
		entity.setFunctionId(1);
		entity.setMuId(1l);
		// entity.setId(id);
		Page<MuEligibleFunctionEntity> pageResult = repository
				.findEligibleFunctionPage(page, entity);
		assertEquals(1, pageResult.getList().size());
	}

	@Test
	public void testFindAssignedFunctionPage() {
		String sql = "insert into MU_ELIGIBLE_FUNCTIONS(MU_ID, FUNCTION_ID"
				+ ") values(" + 1 + ", " + 2 + ")";
		jdbcTemplate.execute(sql);

		Page<EligibleFunctionsPojo> page = new Page<EligibleFunctionsPojo>(1,
				10);
		EligibleFunctionsPojo entity = new EligibleFunctionsPojo();
		entity.setMatchUnitId(1l);

		Page<EligibleFunctionsPojo> pageResult = repository
				.findAssignedFunctionPage(page, entity);

		assertEquals(1, pageResult.getList().size());
		assertEquals("TI,LI", pageResult.getList().get(0).getFunctions());
	}

	@Test
	public void testFindEligibleFunction() {
		MuEligibleFunctionEntity entity = new MuEligibleFunctionEntity();
		// MuEligibleFunctionEntityPK id = new MuEligibleFunctionEntityPK();
		entity.setFunctionId(1);
		entity.setMuId(1);
		List<MuEligibleFunctionEntity> list = repository
				.findEligibleFunction(entity);

		assertEquals(1, list.size());
	}

	@Test
	public void testFindAssignedFunction() {
		String sql = "insert into MU_ELIGIBLE_FUNCTIONS(MU_ID, FUNCTION_ID"
				+ ") values(" + 1 + ", " + 2 + ")";
		jdbcTemplate.execute(sql);

		EligibleFunctionsPojo entity = new EligibleFunctionsPojo();
		entity.setMatchUnitId(1l);

		List<EligibleFunctionsPojo> list = repository
				.findAssignedFunction(entity);

		assertEquals(1, list.size());
		assertEquals("TI,LI", list.get(0).getFunctions());
	}

	@Test
	public void testAssignFunction() {
		MuEligibleFunctionEntity entity = new MuEligibleFunctionEntity();
		MuEligibleFunctionEntityPK id = new MuEligibleFunctionEntityPK();
		id.setFunctionId(2);
		id.setMuId(1l);
		entity.setId(id);
		repository.assignFunction(entity);

		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from MU_ELIGIBLE_FUNCTIONS where MU_ID = 1");
		assertEquals(2, list.size());
	}

	@Test
	public void testAssignFunction_All() {
		MuEligibleFunctionEntity entity = new MuEligibleFunctionEntity();
		MuEligibleFunctionEntityPK id = new MuEligibleFunctionEntityPK();
		id.setFunctionId(0);
		id.setMuId(1);
		entity.setId(id);
		repository.assignFunction(entity);

		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from MU_ELIGIBLE_FUNCTIONS where MU_ID = 1");
		assertEquals(20, list.size());
	}

	@Test
	public void testUnAssignFunction() {
		MuEligibleFunctionEntity entity = new MuEligibleFunctionEntity();
		MuEligibleFunctionEntityPK id = new MuEligibleFunctionEntityPK();
		id.setFunctionId(1);
		id.setMuId(1l);
		entity.setId(id);

		String sql = "insert into MU_ELIGIBLE_FUNCTIONS(MU_ID, FUNCTION_ID) values(1, 2)";
		jdbcTemplate.execute(sql);

		repository.unAssignFunction(entity);

		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select FUNCTION_ID from MU_ELIGIBLE_FUNCTIONS where MU_ID = 1");
		assertEquals(1, list.size());
		assertEquals("2", list.get(0).get("FUNCTION_ID").toString());
	}

	@Test
	public void testUnAssignFunction_All() {
		MuEligibleFunctionEntity entity = new MuEligibleFunctionEntity();
		MuEligibleFunctionEntityPK id = new MuEligibleFunctionEntityPK();
		id.setFunctionId(0);
		id.setMuId(1l);
		entity.setId(id);

		String sql = "insert into MU_ELIGIBLE_FUNCTIONS(MU_ID, FUNCTION_ID) values(1, 2)";
		jdbcTemplate.execute(sql);

		repository.unAssignFunction(entity);

		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select FUNCTION_ID from MU_ELIGIBLE_FUNCTIONS where MU_ID = 1");
		assertEquals(0, list.size());
	}
}
