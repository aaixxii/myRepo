package jp.co.nec.aim.sm.modules.sys.oracle.repository;

import static org.junit.Assert.assertEquals;

import java.util.List;

import javax.sql.DataSource;

import jp.co.nec.aim.sm.common.constant.JobState;
import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.FeJobQueueEntity;
import jp.co.nec.aim.sm.test.common.util.CommonUtils;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional(value = "oracleTXManager")
public class FEJobQueueRepositoryTest {
	@Autowired
	FEJobQueueRepository fejobqueuerepository;

	@Autowired
	@Qualifier("oracleDataSource")
	DataSource datasource;
	JdbcTemplate jdbcTemplate;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		jdbcTemplate = new JdbcTemplate(datasource);
		CommonUtils.DeleteOracleData(jdbcTemplate);
		CommonUtils.prepareFEJobsdata(jdbcTemplate);
	}

	@After
	public void tearDown() throws Exception {
		CommonUtils.DeleteOracleData(jdbcTemplate);
	}

	@Test
	public void test_findFEJobQueuePage() {
		Page<FeJobQueueEntity> page = new Page<FeJobQueueEntity>(1, 10);
		FeJobQueueEntity fusionjob = new FeJobQueueEntity();
		Page<FeJobQueueEntity> pageResult = this.fejobqueuerepository
				.findFEJobQueuePage(page, fusionjob);
		assertEquals(10, pageResult.getList().size());
	}

	@Test
	public void test_findFEJobQueuePage_jobid() {
		Page<FeJobQueueEntity> page = new Page<FeJobQueueEntity>(1, 10);
		FeJobQueueEntity fusionjob = new FeJobQueueEntity();
		fusionjob.setJobId(125l);
		Page<FeJobQueueEntity> pageResult = this.fejobqueuerepository
				.findFEJobQueuePage(page, fusionjob);
		assertEquals(1, pageResult.getList().size());
	}

	@Test
	public void test_findFEJobQueuePage_functionType() {
		Page<FeJobQueueEntity> page = new Page<FeJobQueueEntity>(1, 10);
		FeJobQueueEntity fusionjob = new FeJobQueueEntity();
		fusionjob.setFunctionId(2);
		Page<FeJobQueueEntity> pageResult = this.fejobqueuerepository
				.findFEJobQueuePage(page, fusionjob);
		assertEquals(10, pageResult.getList().size());
		assertEquals(40, pageResult.getCount());
	}

	@Test
	public void test_findFEJobQueuePage_JobStatus() {
		Page<FeJobQueueEntity> page = new Page<FeJobQueueEntity>(1, 10);
		FeJobQueueEntity fusionjob = new FeJobQueueEntity();
		fusionjob.setJobStatus(JobState.COMPLETED);
		Page<FeJobQueueEntity> pageResult = this.fejobqueuerepository
				.findFEJobQueuePage(page, fusionjob);
		assertEquals(10, pageResult.getList().size());
		assertEquals(13, pageResult.getCount());
	}

	@Test
	public void test_findFEJobQueuePage_FailedFlag() {
		Page<FeJobQueueEntity> page = new Page<FeJobQueueEntity>(1, 10);
		FeJobQueueEntity fusionjob = new FeJobQueueEntity();
		fusionjob.setFailedFlag(3);
		Page<FeJobQueueEntity> pageResult = this.fejobqueuerepository
				.findFEJobQueuePage(page, fusionjob);
		assertEquals(0, pageResult.getList().size());
	}

	@Test
	public void test_findFEJobQueuePage_MatchUnitId() {
		Page<FeJobQueueEntity> page = new Page<FeJobQueueEntity>(1, 10);
		FeJobQueueEntity fusionjob = new FeJobQueueEntity();
		fusionjob.setMatchUnitId(21);
		Page<FeJobQueueEntity> pageResult = this.fejobqueuerepository
				.findFEJobQueuePage(page, fusionjob);
		assertEquals(10, pageResult.getList().size());
		assertEquals(40, pageResult.getCount());
	}

	@Test
	public void test_findFEJobQueueList() {
		FeJobQueueEntity fusionjob = new FeJobQueueEntity();
		List<FeJobQueueEntity> listResult = this.fejobqueuerepository
				.findFEJobQueueList(fusionjob);
		assertEquals(40, listResult.size());
	}

	@Test
	public void test_findFEJobQueueList_jobid() {
		FeJobQueueEntity fusionjob = new FeJobQueueEntity();
		fusionjob.setJobId(125l);
		List<FeJobQueueEntity> listResult = this.fejobqueuerepository
				.findFEJobQueueList(fusionjob);
		assertEquals(1, listResult.size());
	}

	@Test
	public void test_findFEJobQueueList_functionType() {
		FeJobQueueEntity fusionjob = new FeJobQueueEntity();
		fusionjob.setFunctionId(2);
		List<FeJobQueueEntity> listResult = this.fejobqueuerepository
				.findFEJobQueueList(fusionjob);
		assertEquals(40, listResult.size());
	}

	@Test
	public void test_findFEJobQueueList_JobStatus() {
		FeJobQueueEntity fusionjob = new FeJobQueueEntity();
		fusionjob.setJobStatus(JobState.COMPLETED);
		List<FeJobQueueEntity> listResult = this.fejobqueuerepository
				.findFEJobQueueList(fusionjob);
		assertEquals(13, listResult.size());
	}

	@Test
	public void test_findFEJobQueueList_FailedFlag() {
		FeJobQueueEntity fusionjob = new FeJobQueueEntity();
		fusionjob.setFailedFlag(3);
		List<FeJobQueueEntity> listResult = this.fejobqueuerepository
				.findFEJobQueueList(fusionjob);
		assertEquals(0, listResult.size());
	}

	@Test
	public void test_findFEJobQueueList_MatchUnitId() {
		FeJobQueueEntity fusionjob = new FeJobQueueEntity();
		fusionjob.setMatchUnitId(21);
		List<FeJobQueueEntity> listResult = this.fejobqueuerepository
				.findFEJobQueueList(fusionjob);
		assertEquals(40, listResult.size());
	}

	@Test
	public void test_findResultsByjobId() {
		Long jobId = 125l;
		String field = "results";
		String result = this.fejobqueuerepository.findResultsByjobId(jobId,
				field);
		assertEquals("No results was found..", result);
	}
}
