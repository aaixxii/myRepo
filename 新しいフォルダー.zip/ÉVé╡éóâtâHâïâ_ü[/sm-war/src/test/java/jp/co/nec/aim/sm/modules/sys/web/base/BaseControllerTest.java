package jp.co.nec.aim.sm.modules.sys.web.base;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.springframework.web.servlet.mvc.support.RedirectAttributesModelMap;

public class BaseControllerTest {

	class BaseControllerSub extends BaseController {

	};

	@Test
	public void testAddMessage() {
		BaseControllerSub baseController = new BaseControllerSub();
		RedirectAttributesModelMap modelMap = new RedirectAttributesModelMap();
		String messages = "Test Massage";
		baseController.addMessage(modelMap, messages);

		String message = (String) modelMap.getFlashAttributes().get("message");
		assertEquals("Test Massage", message);
	}
}
