package jp.co.nec.aim.sm.common.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class PropertiesUtilTest {
	PropertiesUtil property = new PropertiesUtil("SM.properties", "log");

	@Test
	public void testGetProperty_1() {
		String value = property.getProperty("productName");
		assertEquals("NEC AIM System Manager", value);
	}

	@Test
	public void testGetProperty_2() {
		String value = property.getProperty("Test", "default");
		assertEquals("default", value);
	}

	@Test
	public void testGetProperty_3() {
		System.setProperty("Test", "value");
		String value = property.getProperty("Test", "default");
		assertEquals("value", value);
	}

	@Test
	public void testGetInteger_1() {
		Integer value = property.getInteger("page.pageSize");
		assertEquals(100, value.intValue());
	}

	@Test
	public void testGetInteger_2() {
		Integer value = property.getInteger("pageSize", 20);
		assertEquals(20, value.intValue());
	}

	@Test
	public void testGetDouble_1() {
		Double value = property.getDouble("page.pageSize");
		assertEquals(100, value.intValue());
	}

	@Test
	public void testGetDouble_2() {
		Double value = property.getDouble("pageSize", 20);
		assertEquals(20, value.intValue());
	}

	@Test
	public void testGetBoolean_1() {
		System.setProperty("testBoolean", "false");
		Boolean value = property.getBoolean("testBoolean");
		assertTrue(!value);
	}

	@Test
	public void testGetBoolean_2() {
		Boolean value = property.getBoolean("test", true);
		assertTrue(value);
	}
}
