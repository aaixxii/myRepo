package jp.co.nec.aim.sm.common.utils;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class EncodesTest {
	
	String input = "Test String.";
	
	@Test
	public void testEncodeHex() {
		String result = Encodes.encodeHex(input.getBytes());
		assertEquals("5465737420537472696e672e", result);
	}
	
	@Test
	public void testDecodeHex() {
		byte[] result = Encodes.decodeHex("5465737420537472696e672e");
		assertArrayEquals(input.getBytes(), result);
	}
	
	@Test
	public void testEncodeBase64() {
		String result = Encodes.encodeBase64(input.getBytes());
		assertEquals("VGVzdCBTdHJpbmcu", result);
	}
	
	@Test
	public void testEncodeUrlSafeBase64() {
		String result = Encodes.encodeUrlSafeBase64(input.getBytes());
		assertEquals("VGVzdCBTdHJpbmcu", result);
	}
	
	@Test
	public void testDecodeBase64() {
		byte[] result = Encodes.decodeBase64("VGVzdCBTdHJpbmcu");
		assertArrayEquals(input.getBytes(), result);
	}
	
	@Test
	public void testEncodeBase62() {
		String result = Encodes.encodeBase62(input.getBytes());
		assertEquals("MdrsWLsqhmfk", result);
	}
	
	@Test
	public void testEscapeHtml() {
		String result = Encodes.escapeHtml(input);
		assertEquals("Test String.", result);
	}
	
	@Test
	public void testUnescapeHtml() {
		String result = Encodes.unescapeHtml(input);
		assertEquals("Test String.", result);
	}
	
	@Test
	public void testEscapeXml() {
		String result = Encodes.escapeXml(input);
		assertEquals("Test String.", result);
	}
	
	@Test
	public void testUnescapeXml() {
		String result = Encodes.unescapeXml(input);
		assertEquals("Test String.", result);
	}
	
	@Test
	public void testUrlEncode() {
		String result = Encodes.urlEncode(input);
		assertEquals("Test+String.", result);
	}
	
	@Test
	public void testUrlDecode() {
		String result = Encodes.urlDecode(input);
		assertEquals("Test String.", result);
	}
}
