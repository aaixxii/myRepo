package jp.co.nec.aim.sm.common.worker;

import static org.junit.Assert.assertEquals;

import java.util.List;

import jp.co.nec.aim.sm.common.utils.MuConfigUtils;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional(value = "oracleTXManager")
public class MatchUnitParameterDictionaryTest {
	
	@Ignore
	@Test
	public void test() {
		List<MuConfigUtils> map;
		map = MatchUnitParameterDictionary.getMatchUnitParameterMap(false);

		assertEquals(30, map.size());

		int i = 0;
		assertEquals("system", map.get(i++).getSection());
		assertEquals("mumgr", map.get(i++).getSection());
		assertEquals("childproc", map.get(i++).getSection());
		assertEquals("TI", map.get(i++).getSection());
		assertEquals("TI-M", map.get(i++).getSection());
		assertEquals("LI", map.get(i++).getSection());
		assertEquals("LI-S", map.get(i++).getSection());
		assertEquals("LI-M", map.get(i++).getSection());
		assertEquals("LI-X", map.get(i++).getSection());
		assertEquals("TLI", map.get(i++).getSection());
		assertEquals("TLI-S", map.get(i++).getSection());
		assertEquals("TLI-M", map.get(i++).getSection());
		assertEquals("TLI-X", map.get(i++).getSection());
		assertEquals("LLI", map.get(i++).getSection());
		assertEquals("LLI-S", map.get(i++).getSection());
		assertEquals("LLI-M", map.get(i++).getSection());
		assertEquals("LLI-X", map.get(i++).getSection());
		assertEquals("LI-P", map.get(i++).getSection());
		assertEquals("TLI-P", map.get(i++).getSection());
		assertEquals("LLI-P", map.get(i++).getSection());
		assertEquals("logging", map.get(i++).getSection());
		assertEquals("PerfomanceLog", map.get(i++).getSection());
		assertEquals("paths", map.get(i++).getSection());
		assertEquals("Statistics", map.get(i++).getSection());
		assertEquals("Face", map.get(i++).getSection());
		assertEquals("LFML", map.get(i++).getSection());
		assertEquals("QC", map.get(i++).getSection());
		assertEquals("SVT", map.get(i++).getSection());
		assertEquals("ReExtract", map.get(i++).getSection());
		assertEquals("download", map.get(i++).getSection());

		i = 0;
		assertEquals(10, map.get(i++).getMuConfigSection().size());
		assertEquals(48, map.get(i++).getMuConfigSection().size());
		assertEquals(17, map.get(i++).getMuConfigSection().size());
		assertEquals(12, map.get(i++).getMuConfigSection().size());
		assertEquals(25, map.get(i++).getMuConfigSection().size());
		assertEquals(4, map.get(i++).getMuConfigSection().size());
		assertEquals(7, map.get(i++).getMuConfigSection().size());
		assertEquals(4, map.get(i++).getMuConfigSection().size());
		assertEquals(7, map.get(i++).getMuConfigSection().size());
		assertEquals(4, map.get(i++).getMuConfigSection().size());
		assertEquals(7, map.get(i++).getMuConfigSection().size());
		assertEquals(4, map.get(i++).getMuConfigSection().size());
		assertEquals(7, map.get(i++).getMuConfigSection().size());
		assertEquals(4, map.get(i++).getMuConfigSection().size());
		assertEquals(7, map.get(i++).getMuConfigSection().size());
		assertEquals(4, map.get(i++).getMuConfigSection().size());
		assertEquals(7, map.get(i++).getMuConfigSection().size());
		assertEquals(4, map.get(i++).getMuConfigSection().size());
		assertEquals(4, map.get(i++).getMuConfigSection().size());
		assertEquals(4, map.get(i++).getMuConfigSection().size());
		assertEquals(9, map.get(i++).getMuConfigSection().size());
		assertEquals(6, map.get(i++).getMuConfigSection().size());
		assertEquals(9, map.get(i++).getMuConfigSection().size());
		assertEquals(9, map.get(i++).getMuConfigSection().size());
		assertEquals(19, map.get(i++).getMuConfigSection().size());
		assertEquals(2, map.get(i++).getMuConfigSection().size());
		assertEquals(7, map.get(i++).getMuConfigSection().size());
		assertEquals(2, map.get(i++).getMuConfigSection().size());
		assertEquals(1, map.get(i++).getMuConfigSection().size());
		assertEquals(4, map.get(i++).getMuConfigSection().size());
	}
}
