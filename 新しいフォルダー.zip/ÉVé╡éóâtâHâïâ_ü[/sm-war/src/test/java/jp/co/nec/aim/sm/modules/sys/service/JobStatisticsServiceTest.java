package jp.co.nec.aim.sm.modules.sys.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.modules.sys.postgres.entity.JobStatistics;
import jp.co.nec.aim.sm.modules.sys.postgres.pojo.mapping.CardQualityPojo;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional(value = "postgresTXManager")
public class JobStatisticsServiceTest {
	@Autowired
	JobStatisticsService jobService;

	@Autowired
	@Qualifier("postgresDataSource")
	DataSource datasource;

	JdbcTemplate jdbcTemplate;

	String fName[] = new String[] { "LI", "LLI", "TI", "TLI" };

	@Before
	public void before() {
		jdbcTemplate = new JdbcTemplate(datasource);

		cleanDB();
		prepareDB();
	}

	@After
	public void after() {
		cleanDB();
	}

	private void cleanDB() {
		jdbcTemplate.execute("delete from \"JOB_STATISTICS\"");
	}

	private void prepareDB() {
		for (int i = 0; i < 4; i++) {
			String type = "Roll";
			if (i > 1) {
				type = "Slap";
			}
			String jobSql = "insert into \"JOB_STATISTICS\"(\"STATISTICS_ID\","
					+ " \"MU_ID\", \"FUNCTION\", \"SEGMENT_ID\", \"JOB_COUNT\","
					+ " \"START_TIME\", \"AVG_OF_ELAPS\", \"AMR\","
					+ " \"CARD_QUALITY_TYPE\", \"CARD_QUALITY_UNDER_100\","
					+ " \"CARD_QUALITY_UNDER_200\", \"CARD_QUALITY_UNDER_300\","
					+ " \"CARD_QUALITY_UNDER_400\", \"CARD_QUALITY_UNDER_500\","
					+ " \"CARD_QUALITY_UNDER_600\", \"CARD_QUALITY_UNDER_700\","
					+ " \"CARD_QUALITY_UNDER_800\") " + " values(" + i + ", "
					+ i + ", '" + fName[i] + "', 1, " + (i + 1)
					+ ", (timestamp '2013-07-1" + i + " 10:10:11')," + (i + 2)
					+ ", " + (i + 3) + ", '" + type + "', " + i
					+ ", 0, 0, 0, 0, 0, 0, 0)";

			jdbcTemplate.execute(jobSql);
		}
	}

	@Test
	public void testGetFunctionList() {
		List<String> functionList = jobService.getFunctionList();
		assertEquals(4, functionList.size());
		for (int i = 0; i < 4; i++) {
			assertTrue(functionList.contains(fName[i]));
		}
	}

	@Test
	public void testGetMuIdList() {
		List<Long> muIdList = jobService.getMuIdList();
		assertEquals(4, muIdList.size());
		for (int i = 0; i < 4; i++) {
			assertTrue(muIdList.contains(new Long(i)));
		}
	}

	@Test
	public void testGetUnitJobAMR() {
		Page<JobStatistics> page = new Page<JobStatistics>(1, 10);
		JobStatistics statistics = new JobStatistics();
		statistics.setSqlStartTime("2013-07-10 00:00:00");
		statistics.setSqlEndTime("2013-07-14 23:59:59");
		List<JobStatistics> jobAMRList = jobService.getUnitJobAMR(page,
				statistics).getList();

		assertEquals(4, jobAMRList.size());
		for (int i = 0; i < 4; i++) {
			assertEquals(fName[i], jobAMRList.get(i).getFunction());
			assertEquals((i + 1), jobAMRList.get(i).getJobCount().intValue());
			assertEquals(i, jobAMRList.get(i).getMuid().intValue());
			assertEquals(new Double(i + 3), jobAMRList.get(i).getAmr());
		}
	}

	@Test
	public void testGetUnitJobAMR_2() {
		List<JobStatistics> jobAMRList = jobService
				.getUnitJobAMR(new JobStatistics());

		assertEquals(4, jobAMRList.size());
		for (int i = 0; i < 4; i++) {
			assertEquals(fName[i], jobAMRList.get(i).getFunction());
			assertEquals((i + 1), jobAMRList.get(i).getJobCount().intValue());
			assertEquals(i, jobAMRList.get(i).getMuid().intValue());
			assertEquals(new Double(i + 3), jobAMRList.get(i).getAmr());
		}
	}

	@Test
	public void testGetUnitJobElapse() {
		Page<JobStatistics> page = new Page<JobStatistics>(1, 10);
		JobStatistics statistics = new JobStatistics();
		statistics.setSqlStartTime("2013-07-10 00:00:00");
		statistics.setSqlEndTime("2013-07-14 23:59:59");
		List<JobStatistics> jobElapseList = jobService.getUnitJobElapse(page,
				statistics).getList();

		assertEquals(4, jobElapseList.size());
		for (int i = 0; i < 4; i++) {
			assertEquals(fName[i], jobElapseList.get(i).getFunction());
			assertEquals((i + 1), jobElapseList.get(i).getJobCount().intValue());
			assertEquals(i, jobElapseList.get(i).getMuid().intValue());
			assertEquals((i + 2), jobElapseList.get(i).getAvgOfElaps()
					.intValue());
		}
	}

	@Test
	public void testGetUnitJobElapse_2() {
		List<JobStatistics> jobElapseList = jobService
				.getUnitJobElapse(new JobStatistics());

		assertEquals(4, jobElapseList.size());
		for (int i = 0; i < 4; i++) {
			assertEquals(fName[i], jobElapseList.get(i).getFunction());
			assertEquals((i + 1), jobElapseList.get(i).getJobCount().intValue());
			assertEquals(i, jobElapseList.get(i).getMuid().intValue());
			assertEquals((i + 2), jobElapseList.get(i).getAvgOfElaps()
					.intValue());
		}
	}

	@Test
	public void testGetHeaderList() {
		List<JobStatistics> jobStatList = new ArrayList<JobStatistics>();
		for (int i = 0; i < 4; i++) {
			JobStatistics jobStat = new JobStatistics();
			jobStat.setAmr(new Double(i));
			jobStat.setMuid(i);
			jobStat.setFunction("function_" + i);
			jobStatList.add(jobStat);
		}

		List<String> headerList = jobService.getHeaderList(jobStatList, "head");

		assertEquals(6, headerList.size());
		assertEquals("Match Unit ID", headerList.get(0));
		for (int j = 0; j < 4; j++) {
			assertEquals("function_" + j, headerList.get(j + 1));
		}
		assertEquals("head", headerList.get(5));
	}

	@Test
	public void testGetLists() {
		List<JobStatistics> jobStatList = new ArrayList<JobStatistics>();
		for (int i = 0; i < 4; i++) {
			JobStatistics jobStat = new JobStatistics();
			jobStat.setAmr(new Double(i));
			jobStat.setMuid(i);
			jobStat.setFunction("function_" + i);
			jobStatList.add(jobStat);
		}
		List<String> headerList = jobService.getHeaderList(jobStatList);
		List<List<String>> dataList = jobService.getLists(headerList,
				jobStatList, JobStatisticsService.UNIT_AMR);

		assertEquals(4, dataList.size());
		for (int i = 0; i < 4; i++) {
			assertEquals("" + i, dataList.get(i).get(0));
			for (int j = 0; j < 4; j++) {
				if (i == j) {
					assertEquals(new Double(i).toString(),
							dataList.get(i).get(j + 1));
				} else {
					assertEquals(new Double(0).toString(),
							dataList.get(i).get(j + 1));
				}
			}
		}
	}

	@Test
	public void testGetLists_muJobs() {
		List<JobStatistics> jobStatList = new ArrayList<JobStatistics>();
		for (int i = 0; i < 4; i++) {
			JobStatistics jobStat = new JobStatistics();
			jobStat.setJobCount(i);
			jobStat.setMuid(i);
			jobStat.setFunction("function_" + i);
			jobStatList.add(jobStat);
		}
		List<String> headerList = jobService
				.getHeaderList(jobStatList, "Total");
		List<List<String>> dataList = jobService.getLists(headerList,
				jobStatList, JobStatisticsService.SEGMNET_COUNT);

		assertEquals(4, dataList.size());
		for (int i = 0; i < 4; i++) {
			assertEquals("" + i, dataList.get(i).get(0));
			for (int j = 0; j < 4; j++) {
				if (i == j) {
					assertEquals(new Integer(i).toString(), dataList.get(i)
							.get(j + 1));
				} else {
					assertEquals("", dataList.get(i).get(j + 1));
				}
			}
			assertEquals(new Integer(i).toString(), dataList.get(i).get(5));
		}
	}

	@Test
	public void testGetTableList() {
		List<JobStatistics> jobStatList = new ArrayList<JobStatistics>();
		for (int i = 0; i < 4; i++) {
			JobStatistics jobStat = new JobStatistics();
			jobStat.setAvgOfElaps(i);
			jobStat.setMuid(i);
			jobStat.setFunction("function_" + i);
			jobStatList.add(jobStat);
		}
		List<String> headerList = jobService.getHeaderList(jobStatList);
		List<String> tableList = jobService.getTableList(headerList,
				jobStatList, JobStatisticsService.UNIT_ELAPSE);

		assertEquals(20, tableList.size());
		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 5; j++) {
				int index = i * 5 + j;
				if (j == 0) {
					assertEquals("" + i, tableList.get(index));
				} else {
					if (i == j - 1) {
						assertEquals(new Double(i).toString(),
								tableList.get(index));
					} else {
						assertEquals(new Double(0).toString(),
								tableList.get(index));
					}
				}
			}
		}
	}

	@Test
	public void testGetCardQualityRoll() {
		Page<CardQualityPojo> page = new Page<CardQualityPojo>(1, 10);
		JobStatistics statistics = new JobStatistics();
		statistics.setSqlStartTime("2013-07-10 00:00:00");
		statistics.setSqlEndTime("2013-07-14 23:59:59");

		List<CardQualityPojo> qualityList = jobService.getCardQualityRoll(page,
				statistics).getList();

		assertEquals(1, qualityList.size());

		assertEquals("Roll", qualityList.get(0).getQualityType());
		assertEquals(1, qualityList.get(0).getCount100().intValue());
		assertEquals(0, qualityList.get(0).getCount200().intValue());
		assertEquals(0, qualityList.get(0).getCount300().intValue());
		assertEquals(0, qualityList.get(0).getCount400().intValue());
		assertEquals(0, qualityList.get(0).getCount500().intValue());
		assertEquals(0, qualityList.get(0).getCount600().intValue());
		assertEquals(0, qualityList.get(0).getCount700().intValue());
		assertEquals(0, qualityList.get(0).getCount800().intValue());

	}

	@Test
	public void testGetCardQualityRoll_2() {
		JobStatistics statistics = new JobStatistics();
		statistics.setSqlStartTime("2013-07-10 00:00:00");
		statistics.setSqlEndTime("2013-07-14 23:59:59");

		List<CardQualityPojo> qualityList = jobService
				.getCardQualityRoll(statistics);

		assertEquals(1, qualityList.size());

		assertEquals("Roll", qualityList.get(0).getQualityType());
		assertEquals(1, qualityList.get(0).getCount100().intValue());
		assertEquals(0, qualityList.get(0).getCount200().intValue());
		assertEquals(0, qualityList.get(0).getCount300().intValue());
		assertEquals(0, qualityList.get(0).getCount400().intValue());
		assertEquals(0, qualityList.get(0).getCount500().intValue());
		assertEquals(0, qualityList.get(0).getCount600().intValue());
		assertEquals(0, qualityList.get(0).getCount700().intValue());
		assertEquals(0, qualityList.get(0).getCount800().intValue());
	}

	@Test
	public void testGetCardQualitySlap() {
		Page<CardQualityPojo> page = new Page<CardQualityPojo>(1, 10);
		JobStatistics statistics = new JobStatistics();
		statistics.setSqlStartTime("2013-07-10 00:00:00");
		statistics.setSqlEndTime("2013-07-14 23:59:59");

		List<CardQualityPojo> qualityList = jobService.getCardQualitySlap(page,
				statistics).getList();

		assertEquals(1, qualityList.size());

		assertEquals("Slap", qualityList.get(0).getQualityType());
		assertEquals(5, qualityList.get(0).getCount100().intValue());
		assertEquals(0, qualityList.get(0).getCount200().intValue());
		assertEquals(0, qualityList.get(0).getCount300().intValue());
		assertEquals(0, qualityList.get(0).getCount400().intValue());
		assertEquals(0, qualityList.get(0).getCount500().intValue());
		assertEquals(0, qualityList.get(0).getCount600().intValue());
		assertEquals(0, qualityList.get(0).getCount700().intValue());
		assertEquals(0, qualityList.get(0).getCount800().intValue());

	}

	@Test
	public void testGetCardQualitySlap_2() {
		JobStatistics statistics = new JobStatistics();
		statistics.setSqlStartTime("2013-07-10 00:00:00");
		statistics.setSqlEndTime("2013-07-14 23:59:59");

		List<CardQualityPojo> qualityList = jobService
				.getCardQualitySlap(statistics);

		assertEquals(1, qualityList.size());

		assertEquals("Slap", qualityList.get(0).getQualityType());
		assertEquals(5, qualityList.get(0).getCount100().intValue());
		assertEquals(0, qualityList.get(0).getCount200().intValue());
		assertEquals(0, qualityList.get(0).getCount300().intValue());
		assertEquals(0, qualityList.get(0).getCount400().intValue());
		assertEquals(0, qualityList.get(0).getCount500().intValue());
		assertEquals(0, qualityList.get(0).getCount600().intValue());
		assertEquals(0, qualityList.get(0).getCount700().intValue());
		assertEquals(0, qualityList.get(0).getCount800().intValue());
	}

	@Test
	public void testGetCardQuality() {
		Page<CardQualityPojo> page = new Page<CardQualityPojo>(1, 10);
		JobStatistics statistics = new JobStatistics();
		statistics.setSqlStartTime("2013-07-10 00:00:00");
		statistics.setSqlEndTime("2013-07-14 23:59:59");

		List<CardQualityPojo> qualityList = jobService.getCardQuality(page,
				statistics).getList();

		assertEquals(2, qualityList.size());

		for (int i = 0; i < 2; i++) {
			if (qualityList.get(i).getQualityType().equals("Slap")) {
				assertEquals(5, qualityList.get(i).getCount100().intValue());
			} else {
				assertEquals(1, qualityList.get(i).getCount100().intValue());
			}
			assertEquals(0, qualityList.get(i).getCount200().intValue());
			assertEquals(0, qualityList.get(i).getCount300().intValue());
			assertEquals(0, qualityList.get(i).getCount400().intValue());
			assertEquals(0, qualityList.get(i).getCount500().intValue());
			assertEquals(0, qualityList.get(i).getCount600().intValue());
			assertEquals(0, qualityList.get(i).getCount700().intValue());
			assertEquals(0, qualityList.get(i).getCount800().intValue());
		}

	}

	@Test
	public void testGetCardQuality_2() {
		JobStatistics statistics = new JobStatistics();
		statistics.setSqlStartTime("2013-07-10 00:00:00");
		statistics.setSqlEndTime("2013-07-14 23:59:59");

		List<CardQualityPojo> qualityList = jobService
				.getCardQuality(statistics);

		assertEquals(2, qualityList.size());

		for (int i = 0; i < 2; i++) {
			if (qualityList.get(i).getQualityType().equals("Slap")) {
				assertEquals(5, qualityList.get(i).getCount100().intValue());
			} else {
				assertEquals(1, qualityList.get(i).getCount100().intValue());
			}
			assertEquals(0, qualityList.get(i).getCount200().intValue());
			assertEquals(0, qualityList.get(i).getCount300().intValue());
			assertEquals(0, qualityList.get(i).getCount400().intValue());
			assertEquals(0, qualityList.get(i).getCount500().intValue());
			assertEquals(0, qualityList.get(i).getCount600().intValue());
			assertEquals(0, qualityList.get(i).getCount700().intValue());
			assertEquals(0, qualityList.get(i).getCount800().intValue());
		}
	}

}
