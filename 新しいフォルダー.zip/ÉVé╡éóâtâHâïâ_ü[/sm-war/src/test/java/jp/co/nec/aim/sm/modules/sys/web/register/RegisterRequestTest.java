package jp.co.nec.aim.sm.modules.sys.web.register;

import static org.apache.commons.io.IOUtils.write;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.nec.aim.message.proto.AIMMessages.PBComponentInfo;
import jp.co.nec.aim.message.proto.AIMMessages.PBEnterResponse;
import jp.co.nec.aim.sm.common.constant.SMConstant;
import jp.co.nec.aim.sm.common.properties.ApplicationProperties;
import jp.co.nec.aim.sm.test.common.util.HttpTestServer;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.mortbay.jetty.Handler;
import org.mortbay.jetty.HttpConnection;
import org.mortbay.jetty.Request;
import org.mortbay.jetty.handler.AbstractHandler;

public class RegisterRequestTest {

	private RegisterRequest registerRequest = new RegisterRequest();
	protected static Class<?> clazz;
	private static HttpTestServer _server;
	private static int eventcase = 0;
	private static byte[] bytes = null;

	public static Handler getMockHandler() {
		Handler handler = new AbstractHandler() {
			public void handle(String target, HttpServletRequest request,
					HttpServletResponse response, int dispatch)
					throws IOException, ServletException {
				// requstObject = SMUtil.convertXmltoJavaBean(clazz,
				// request.getInputStream());
				Request baseRequest = request instanceof Request ? (Request) request
						: HttpConnection.getCurrentConnection().getRequest();
				switch (eventcase) {
				case 0:
					response.setStatus(200);

					write(bytes, response.getOutputStream());
					break;
				case 1:
					response.setStatus(500);
					write("<html><head><title>JBoss Web/3.0.0-CR2 - Error report</title></head></html>",
							response.getOutputStream());
				}
				response.setContentType("text/html;charset=utf-8");
				response.setCharacterEncoding("UTF-8");
				baseRequest.setHandled(true);
			}
		};
		return handler;
	}

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		_server = new HttpTestServer(22);
		_server.start(getMockHandler());
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		if (_server != null) {
			_server.stop();
		}
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
		eventcase = 0;
		SMConstant.setSM_ID(null);
	}

	@Test	
	public void testGenerateEnterPostContext() {
		String expVersion = ApplicationProperties.getSmVersion();
		PBComponentInfo component = registerRequest.createComponentInfo();
		assertTrue(component.getContactUrl().contains("systemmanager"));				
		assertEquals(expVersion, component.getVersion());
		assertTrue( component.getUniqueId().contains("SM"));
		assertEquals(false, component.getResourceInfo().getSegmentMapChanged());
	}

	@Test
	@Ignore
	public void testSendEnter() {
		PBEnterResponse.Builder builder = PBEnterResponse.newBuilder();
		builder.setId(30);
		bytes = builder.build().toByteArray();

		registerRequest.sendEnter();

		assertEquals(30L, SMConstant.getSM_ID().longValue());
	}

	@Test
	@Ignore
	public void testSendExit() {
		SMConstant.setSM_ID(20L);

		registerRequest.sendExit();
	}

}
