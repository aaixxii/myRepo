package jp.co.nec.aim.sm.modules.sys.web;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.List;

import javax.sql.DataSource;

import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.exception.SMServiceException;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.SystemConfigEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.SystemInitEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.BiometricContainerPojo;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.EligibleBinsPojo;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.EligibleFunctionsPojo;
import jp.co.nec.aim.sm.modules.sys.service.SystemConfigService;
import mockit.Mock;
import mockit.MockUp;


import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ExtendedModelMap;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional(value = "oracleTXManager")
@SuppressWarnings("unchecked")
public class SystemConfigControllerTest {

	@Autowired
	SystemConfigController sysConfigController;

	@Autowired
	@Qualifier("oracleDataSource")
	DataSource datasource;

	JdbcTemplate jdbcTemplate;
	MockUp<SystemConfigService> mocked;

	ExtendedModelMap modelMap;
	MockHttpServletRequest request;
	MockHttpServletResponse response;

	String[] formatName = new String[] { "RDBT", "RDBL", "LDB", "PBLNF" };
	String[] functionName = new String[] { "TI", "LI", "TLI", "LLI" };
	String[] assignActions = { "Assign", "Unassign" };
	String[] binActions = { "Update", "Filter" };

	@Before
	public void before() {
		modelMap = new ExtendedModelMap();
		request = new MockHttpServletRequest();
		response = new MockHttpServletResponse();

		jdbcTemplate = new JdbcTemplate(datasource);
		cleanDB();
		prepareDB();
	}

	@After
	public void after() {
		cleanDB();
	}

	private void cleanDB() {
		jdbcTemplate.execute("delete from PERSON_BIOMETRICS");
		jdbcTemplate.execute("delete from MU_ELIGIBLE_CONTAINERS");
		jdbcTemplate.execute("delete from MU_ELIGIBLE_FUNCTIONS");
		jdbcTemplate.execute("delete from FE_JOB_QUEUE");
		jdbcTemplate.execute("delete from JOB_QUEUE");
		jdbcTemplate.execute("delete from FE_LOT_JOBS");
		jdbcTemplate.execute("delete from MATCH_UNITS");
		jdbcTemplate.execute("delete from CONTAINERS");
		jdbcTemplate.execute("delete from FORMAT_TYPES");
		jdbcTemplate.execute("delete from FUNCTION_TYPES");
		jdbcTemplate.execute("delete from SYSTEM_CONFIG");
		jdbcTemplate.execute("delete from SYSTEM_INIT");
	}

	private void prepareDB() {
		for (int i = 1; i <= 4; i++) {
			String sql = "insert into MATCH_UNITS(MU_ID, UNIQUE_ID, STATE"
					+ ") values(" + i + ", 'unique_" + i + "', 'WORKING')";
			jdbcTemplate.execute(sql);
		}

		for (int i = 1; i <= 4; i++) {
			String sql = "insert into FUNCTION_TYPES(FUNCTION_ID,"
					+ " FUNCTION_NAME, TOP_LEVEL_JOB_TIMEOUTS, CONTAINER_JOB_TIMEOUTS, QUEUE_TYPE) values("
					+ i + ", '" + functionName[i - 1] + "', " + "100, 100, "
					+ i + ")";
			jdbcTemplate.execute(sql);
		}

		for (int i = 1; i <= 4; i++) {
			String sql = "insert into FORMAT_TYPES(FORMAT_ID, DETAILS,"
					+ " FORMAT_NAME) values(" + i + ", " + i + ", '"
					+ formatName[i - 1] + "')";
			jdbcTemplate.execute(sql);
		}

		for (int i = 1; i <= 4; i++) {
			String sql = "insert into \"CONTAINERS\"(CONTAINER_ID,CONTAINER_NAME, SCOPE_ID, FORMAT_ID, MAX_SEGMENT_SIZE"
					+ ") values(" + i + ",'RDBT',1, " + i + ", 20000000)";
			jdbcTemplate.execute(sql);
		}

		for (int i = 1; i <= 4; i++) {
			String sql = "insert into MU_ELIGIBLE_CONTAINERS(MU_ID, CONTAINER_ID"
					+ ") values(" + i + ", " + i + ")";
			jdbcTemplate.execute(sql);
		}

		for (int i = 1; i <= 4; i++) {
			String sql = "insert into MU_ELIGIBLE_FUNCTIONS(MU_ID, FUNCTION_ID"
					+ ") values(" + i + ", " + i + ")";
			jdbcTemplate.execute(sql);
		}

		for (int i = 1; i <= 4; i++) {
			String sql = "insert into SYSTEM_CONFIG(CONFIG_ID, PROPERTY_NAME,"
					+ " PROPERTY_VALUE) values(" + i + ", 'Key_" + i
					+ "', 'Value_" + i + "')";
			jdbcTemplate.execute(sql);
		}

		{
			String sql = "insert into SYSTEM_CONFIG(CONFIG_ID, PROPERTY_NAME,"
					+ " PROPERTY_VALUE) values(5, 'LOAD_BALANCER."
					+ "DEFAULT_MIN_REDUNDANCY', '2')";
			jdbcTemplate.execute(sql);
		}

		for (int i = 1; i <= 4; i++) {
			String sql = "insert into SYSTEM_INIT(INIT_ID, KEY_NAME,"
					+ " KEY_VALUE) values(" + i + ", 'Key_" + i + "', 'Value_"
					+ i + "')";
			jdbcTemplate.execute(sql);
		}
	}

	private void setMock() {
		 mocked = new MockUp<SystemConfigService>() {
			@Mock
			@SuppressWarnings("unused")
			public int updateDBByClass(Class<?> clazz, Object... objs)
					throws Exception {
				throw new SMServiceException("Test Mock Exception.");
			}

			@Mock
			@SuppressWarnings("unused")
			public boolean executeAssignAction(Class<?> clazz, String action,
					Long muId, String obj) throws Exception {
				throw new SMServiceException("Test Mock Exception.");
			}

			@Mock
			@SuppressWarnings("unused")
			public <T> List<T> getListByClass(Object obj, Class<?> clazz)
					throws Exception {
				throw new SMServiceException("Test Mock Exception.");
			}
		};
	}

	private void tearDownMocks() {
		mocked.tearDown();
	}

	@Test
	public void testListBiometricContainers_NoUpdate() {
		BiometricContainerPojo entity = new BiometricContainerPojo();

		String result = sysConfigController.listBiometricContainers(null,
				entity, request, response, modelMap);
		assertEquals("modules/configure/containers", result);

		List<String> formatList = (List<String>) modelMap.get("formatList");
		assertEquals(4, formatList.size());
		for (int i = 0; i < 4; i++) {
			assertTrue(formatList.contains(formatName[i]));
		}

		Page<BiometricContainerPojo> page = (Page<BiometricContainerPojo>) modelMap
				.get("page");
		assertEquals(4, page.getList().size());
		for (int i = 0; i < 4; i++) {
			assertEquals(i + 1l, page.getList().get(i).getBinId().longValue());
			assertEquals(formatName[i], page.getList().get(i).getFormat());
			// assertEquals(i + 1l, page.getList().get(i).getMinimumRedundancy()
			// .longValue());
		}

		List<String> actionList = (List<String>) modelMap.get("actionList");
		assertEquals(2, actionList.size());
		for (int i = 0; i < 2; i++) {
			assertTrue(actionList.contains(binActions[i]));
		}

		String message = (String) modelMap.get("message");
		assertNull(message);
	}

	@Test
	public void testListBiometricContainers_NoUpdate_2() {
		BiometricContainerPojo entity = new BiometricContainerPojo();
		entity.setBinId(1l);
		entity.setFormat("RDBL");

		String result = sysConfigController.listBiometricContainers(null,
				entity, request, response, modelMap);
		assertEquals("modules/configure/containers", result);

		List<String> formatList = (List<String>) modelMap.get("formatList");
		assertEquals(4, formatList.size());
		for (int i = 0; i < 4; i++) {
			assertTrue(formatList.contains(formatName[i]));
		}

		Page<BiometricContainerPojo> page = (Page<BiometricContainerPojo>) modelMap
				.get("page");
		assertEquals(0, page.getList().size());

		List<String> actionList = (List<String>) modelMap.get("actionList");
		assertEquals(2, actionList.size());
		for (int i = 0; i < 2; i++) {
			assertTrue(actionList.contains(binActions[i]));
		}

		String message = (String) modelMap.get("message");
		assertNull(message);
	}

	@Test
	public void testListBiometricContainers_NoUpdate_3() {
		BiometricContainerPojo entity = new BiometricContainerPojo();
		entity.setBinId(1l);
		entity.setFormat("RDBL");
		entity.setAction("Update");

		String result = sysConfigController.listBiometricContainers(null,
				entity, request, response, modelMap);
		assertEquals("modules/configure/containers", result);

		List<String> formatList = (List<String>) modelMap.get("formatList");
		assertEquals(4, formatList.size());
		for (int i = 0; i < 4; i++) {
			assertTrue(formatList.contains(formatName[i]));
		}

		Page<BiometricContainerPojo> page = (Page<BiometricContainerPojo>) modelMap
				.get("page");
		assertEquals(0, page.getList().size());

		List<String> actionList = (List<String>) modelMap.get("actionList");
		assertEquals(2, actionList.size());
		for (int i = 0; i < 2; i++) {
			assertTrue(actionList.contains(binActions[i]));
		}

		String message = (String) modelMap.get("message");
		assertEquals("can not find Contanier: containerId = 1, format = RDBL",
				message);
	}

	@Test
	public void testListBiometricContainers_Update() {
		BiometricContainerPojo entity = new BiometricContainerPojo();
		entity.setBinId(1l);
		entity.setFormat("RDBT");
		entity.setMinimumRedundancy(10l);
		entity.setAction("Update");

		String result = sysConfigController.listBiometricContainers(null,
				entity, request, response, modelMap);
		assertEquals("modules/configure/containers", result);

		List<String> formatList = (List<String>) modelMap.get("formatList");
		assertEquals(4, formatList.size());
		for (int i = 0; i < 4; i++) {
			assertTrue(formatList.contains(formatName[i]));
		}

		Page<BiometricContainerPojo> page = (Page<BiometricContainerPojo>) modelMap
				.get("page");
		assertEquals(1, page.getList().size());
		assertEquals(1l, page.getList().get(0).getBinId().longValue());
		assertEquals(formatName[0], page.getList().get(0).getFormat());
		assertEquals(10l, page.getList().get(0).getMinimumRedundancy()
				.longValue());

		List<String> actionList = (List<String>) modelMap.get("actionList");
		assertEquals(2, actionList.size());
		for (int i = 0; i < 2; i++) {
			assertTrue(actionList.contains(binActions[i]));
		}

		String message = (String) modelMap.get("message");
		assertNull(message);
	}

	@Test
	public void testListBiometricContainers_Update_2() {
		BiometricContainerPojo entity = new BiometricContainerPojo();
		entity.setBinId(1l);
		entity.setFormat("RDBT");
		entity.setAction("Update");

		String result = sysConfigController.listBiometricContainers(null,
				entity, request, response, modelMap);
		assertEquals("modules/configure/containers", result);

		List<String> formatList = (List<String>) modelMap.get("formatList");
		assertEquals(4, formatList.size());
		for (int i = 0; i < 4; i++) {
			assertTrue(formatList.contains(formatName[i]));
		}

		Page<BiometricContainerPojo> page = (Page<BiometricContainerPojo>) modelMap
				.get("page");
		assertEquals(1, page.getList().size());
		assertEquals(1l, page.getList().get(0).getBinId().longValue());
		assertEquals(formatName[0], page.getList().get(0).getFormat());
		assertEquals(2, page.getList().get(0).getMinimumRedundancy()
				.longValue());

		List<String> actionList = (List<String>) modelMap.get("actionList");
		assertEquals(2, actionList.size());
		for (int i = 0; i < 2; i++) {
			assertTrue(actionList.contains(binActions[i]));
		}

		String message = (String) modelMap.get("message");
		assertNull(message);
	}

	@Test
	public void testListBiometricContainers_Exception() {
		try {
			setMock();

			BiometricContainerPojo entity = new BiometricContainerPojo();
			entity.setBinId(1l);
			entity.setFormat("RDBT");
			entity.setAction("Update");

			String result = sysConfigController.listBiometricContainers(null,
					entity, request, response, modelMap);
			assertEquals("modules/configure/containers", result);

			List<String> formatList = (List<String>) modelMap.get("formatList");
			assertEquals(4, formatList.size());
			for (int i = 0; i < 4; i++) {
				assertTrue(formatList.contains(formatName[i]));
			}

			Page<BiometricContainerPojo> page = (Page<BiometricContainerPojo>) modelMap
					.get("page");
			assertEquals(1, page.getList().size());

			List<String> actionList = (List<String>) modelMap.get("actionList");
			assertEquals(2, actionList.size());
			for (int i = 0; i < 2; i++) {
				assertTrue(actionList.contains(binActions[i]));
			}

			String message = (String) modelMap.get("message");
			assertNotNull(message);
		} finally {
			tearDownMocks();
		}
	}

	@Test
	public void testListEligibleFunctions_NoAssign() {
		EligibleFunctionsPojo entity = new EligibleFunctionsPojo();

		String result = sysConfigController.listEligibleFunctions(null, entity,
				request, response, modelMap);
		assertEquals("modules/configure/eligiblefunctions", result);

		List<String> functionList = (List<String>) modelMap.get("functionList");
		assertEquals(4, functionList.size());
		for (int i = 0; i < 4; i++) {
			assertTrue(functionList.contains(functionName[i]));
		}

		Page<EligibleFunctionsPojo> page = (Page<EligibleFunctionsPojo>) modelMap
				.get("page");
		assertEquals(4, page.getList().size());
		for (int i = 0; i < 4; i++) {
			assertEquals(i + 1l, page.getList().get(i).getMatchUnitId()
					.longValue());
			assertEquals(functionName[i], page.getList().get(i).getFunctions());
		}

		List<String> actionList = (List<String>) modelMap.get("actionList");
		assertEquals(2, actionList.size());
		for (int i = 0; i < 2; i++) {
			assertTrue(actionList.contains(assignActions[i]));
		}

		String message = (String) modelMap.get("message");
		assertNull(message);
	}

	@Test
	public void testListEligibleFunctions_NoAssign_2() {
		EligibleFunctionsPojo entity = new EligibleFunctionsPojo();
		entity.setMatchUnitId(6l);

		String result = sysConfigController.listEligibleFunctions(null, entity,
				request, response, modelMap);
		assertEquals("modules/configure/eligiblefunctions", result);

		List<String> functionList = (List<String>) modelMap.get("functionList");
		assertEquals(4, functionList.size());
		for (int i = 0; i < 4; i++) {
			assertTrue(functionList.contains(functionName[i]));
		}

		Page<EligibleFunctionsPojo> page = (Page<EligibleFunctionsPojo>) modelMap
				.get("page");
		assertEquals(0, page.getList().size());

		List<String> actionList = (List<String>) modelMap.get("actionList");
		assertEquals(2, actionList.size());
		for (int i = 0; i < 2; i++) {
			assertTrue(actionList.contains(assignActions[i]));
		}

		String message = (String) modelMap.get("message");
		assertNull(message);
	}

	@Test
	public void testListEligibleFunctions_NoAssign_3() {
		EligibleFunctionsPojo entity = new EligibleFunctionsPojo();
		entity.setMatchUnitId(6l);
		entity.setFunctions("TI");
		entity.setAction("NoAssign_3");

		String result = sysConfigController.listEligibleFunctions(null, entity,
				request, response, modelMap);
		assertEquals("modules/configure/eligiblefunctions", result);

		List<String> functionList = (List<String>) modelMap.get("functionList");
		assertEquals(4, functionList.size());
		for (int i = 0; i < 4; i++) {
			assertTrue(functionList.contains(functionName[i]));
		}

		Page<EligibleFunctionsPojo> page = (Page<EligibleFunctionsPojo>) modelMap
				.get("page");
		assertEquals(0, page.getList().size());

		List<String> actionList = (List<String>) modelMap.get("actionList");
		assertEquals(2, actionList.size());
		for (int i = 0; i < 2; i++) {
			assertTrue(actionList.contains(assignActions[i]));
		}

		String message = (String) modelMap.get("message");
		assertEquals("Assign Action: Unit ID = 6 is not existed.", message);
	}

	@Test
	public void testListEligibleFunctions_Assign_1() {
		EligibleFunctionsPojo entity = new EligibleFunctionsPojo();
		entity.setMatchUnitId(1l);
		entity.setFunctions(functionName[0]);
		entity.setAction(assignActions[0]);

		String result = sysConfigController.listEligibleFunctions(null, entity,
				request, response, modelMap);
		assertEquals("modules/configure/eligiblefunctions", result);

		List<String> functionList = (List<String>) modelMap.get("functionList");
		assertEquals(4, functionList.size());
		for (int i = 0; i < 4; i++) {
			assertTrue(functionList.contains(functionName[i]));
		}

		Page<EligibleFunctionsPojo> page = (Page<EligibleFunctionsPojo>) modelMap
				.get("page");
		assertEquals(1, page.getList().size());
		assertEquals(functionName[0], page.getList().get(0).getFunctions());

		List<String> actionList = (List<String>) modelMap.get("actionList");
		assertEquals(2, actionList.size());
		for (int i = 0; i < 2; i++) {
			assertTrue(actionList.contains(assignActions[i]));
		}

		String message = (String) modelMap.get("message");
		assertNull(message);
	}

	@Test
	public void testListEligibleFunctions_Assign_2() {
		EligibleFunctionsPojo entity = new EligibleFunctionsPojo();
		entity.setMatchUnitId(1l);
		entity.setFunctions(functionName[1]);
		entity.setAction(assignActions[0]);

		String result = sysConfigController.listEligibleFunctions(null, entity,
				request, response, modelMap);
		assertEquals("modules/configure/eligiblefunctions", result);

		List<String> functionList = (List<String>) modelMap.get("functionList");
		assertEquals(4, functionList.size());
		for (int i = 0; i < 4; i++) {
			assertTrue(functionList.contains(functionName[i]));
		}

		Page<EligibleFunctionsPojo> page = (Page<EligibleFunctionsPojo>) modelMap
				.get("page");
		assertEquals(1, page.getList().size());
		assertEquals("TI,LI", page.getList().get(0).getFunctions());

		List<String> actionList = (List<String>) modelMap.get("actionList");
		assertEquals(2, actionList.size());
		for (int i = 0; i < 2; i++) {
			assertTrue(actionList.contains(assignActions[i]));
		}

		String message = (String) modelMap.get("message");
		assertNull(message);
	}

	@Test
	public void testListEligibleFunctions_UnAssign_1() {
		EligibleFunctionsPojo entity = new EligibleFunctionsPojo();
		entity.setMatchUnitId(1l);
		entity.setFunctions(functionName[0]);
		entity.setAction(assignActions[1]);

		String result = sysConfigController.listEligibleFunctions(null, entity,
				request, response, modelMap);
		assertEquals("modules/configure/eligiblefunctions", result);

		List<String> functionList = (List<String>) modelMap.get("functionList");
		assertEquals(4, functionList.size());
		for (int i = 0; i < 4; i++) {
			assertTrue(functionList.contains(functionName[i]));
		}

		Page<EligibleFunctionsPojo> page = (Page<EligibleFunctionsPojo>) modelMap
				.get("page");
		assertEquals(0, page.getList().size());

		List<String> actionList = (List<String>) modelMap.get("actionList");
		assertEquals(2, actionList.size());
		for (int i = 0; i < 2; i++) {
			assertTrue(actionList.contains(assignActions[i]));
		}

		String message = (String) modelMap.get("message");
		assertNull(message);
	}

	@Test
	public void testListEligibleFunctions_UnAssign_2() {
		EligibleFunctionsPojo entity = new EligibleFunctionsPojo();
		entity.setMatchUnitId(1l);
		entity.setFunctions(functionName[1]);
		entity.setAction(assignActions[1]);

		String result = sysConfigController.listEligibleFunctions(null, entity,
				request, response, modelMap);
		assertEquals("modules/configure/eligiblefunctions", result);

		List<String> functionList = (List<String>) modelMap.get("functionList");
		assertEquals(4, functionList.size());
		for (int i = 0; i < 4; i++) {
			assertTrue(functionList.contains(functionName[i]));
		}

		Page<EligibleFunctionsPojo> page = (Page<EligibleFunctionsPojo>) modelMap
				.get("page");
		assertEquals(1, page.getList().size());

		List<String> actionList = (List<String>) modelMap.get("actionList");
		assertEquals(2, actionList.size());
		for (int i = 0; i < 2; i++) {
			assertTrue(actionList.contains(assignActions[i]));
		}

		String message = (String) modelMap.get("message");
		assertNull(message);
	}

	@Test
	public void testListEligibleFunctions_Exception() {
		EligibleFunctionsPojo entity = new EligibleFunctionsPojo();
		entity.setMatchUnitId(11l);
		entity.setFunctions(functionName[0]);
		entity.setAction(assignActions[0]);

		String result = sysConfigController.listEligibleFunctions(null, entity,
				request, response, modelMap);
		assertEquals("modules/configure/eligiblefunctions", result);

		List<String> functionList = (List<String>) modelMap.get("functionList");
		assertEquals(4, functionList.size());
		for (int i = 0; i < 4; i++) {
			assertTrue(functionList.contains(functionName[i]));
		}

		Page<EligibleFunctionsPojo> page = (Page<EligibleFunctionsPojo>) modelMap
				.get("page");
		assertEquals(0, page.getList().size());

		List<String> actionList = (List<String>) modelMap.get("actionList");
		assertEquals(2, actionList.size());
		for (int i = 0; i < 2; i++) {
			assertTrue(actionList.contains(assignActions[i]));
		}

		String message = (String) modelMap.get("message");
		assertNotNull(message);
	}

	@Test
	public void testListEligibleBins_NoAssign() {
		EligibleBinsPojo entity = new EligibleBinsPojo();

		String result = sysConfigController.listEligibleBins(null, entity,
				request, response, modelMap);
		assertEquals("modules/configure/eligibleContainers", result);

		List<Long> binList = (List<Long>) modelMap.get("binList");
		assertEquals(4, binList.size());
		for (int i = 0; i < 4; i++) {
			assertTrue(binList.contains(i + 1l));
		}

		Page<EligibleBinsPojo> page = (Page<EligibleBinsPojo>) modelMap
				.get("page");
		assertEquals(4, page.getList().size());
		for (int i = 0; i < 4; i++) {
			assertEquals(i + 1l, page.getList().get(i).getMatchUnitId()
					.longValue());
			assertEquals(i + 1l, page.getList().get(i).getBinId().longValue());
		}

		List<String> actionList = (List<String>) modelMap.get("actionList");
		assertEquals(2, actionList.size());
		for (int i = 0; i < 2; i++) {
			assertTrue(actionList.contains(assignActions[i]));
		}

		String message = (String) modelMap.get("message");
		assertNull(message);
	}

	@Test
	public void testListEligibleBins_NoAssign_2() {
		EligibleBinsPojo entity = new EligibleBinsPojo();
		entity.setMatchUnitId(6l);

		String result = sysConfigController.listEligibleBins(null, entity,
				request, response, modelMap);
		assertEquals("modules/configure/eligibleContainers", result);

		List<String> binList = (List<String>) modelMap.get("binList");
		assertEquals(4, binList.size());
		for (int i = 0; i < 4; i++) {
			assertTrue(binList.contains(i + 1l));
		}

		Page<EligibleBinsPojo> page = (Page<EligibleBinsPojo>) modelMap
				.get("page");
		assertEquals(0, page.getList().size());

		List<String> actionList = (List<String>) modelMap.get("actionList");
		assertEquals(2, actionList.size());
		for (int i = 0; i < 2; i++) {
			assertTrue(actionList.contains(assignActions[i]));
		}

		String message = (String) modelMap.get("message");
		assertNull(message);
	}

	@Test
	public void testListEligibleBins_NoAssign_3() {
		EligibleBinsPojo entity = new EligibleBinsPojo();
		entity.setMatchUnitId(6l);
		entity.setBinIds("1");
		entity.setAction("NoAssign_3");

		String result = sysConfigController.listEligibleBins(null, entity,
				request, response, modelMap);
		assertEquals("modules/configure/eligibleContainers", result);

		List<String> binList = (List<String>) modelMap.get("binList");
		assertEquals(4, binList.size());
		for (int i = 0; i < 4; i++) {
			assertTrue(binList.contains(i + 1l));
		}

		Page<EligibleBinsPojo> page = (Page<EligibleBinsPojo>) modelMap
				.get("page");
		assertEquals(0, page.getList().size());

		List<String> actionList = (List<String>) modelMap.get("actionList");
		assertEquals(2, actionList.size());
		for (int i = 0; i < 2; i++) {
			assertTrue(actionList.contains(assignActions[i]));
		}

		String message = (String) modelMap.get("message");
		assertEquals("Assign Action: Unit ID = 6 is not existed.", message);
	}

	@Test
	public void testListEligibleBins_Assign_1() {
		EligibleBinsPojo entity = new EligibleBinsPojo();
		entity.setMatchUnitId(1l);
		entity.setBinId(1l);
		entity.setAction(assignActions[0]);

		String result = sysConfigController.listEligibleBins(null, entity,
				request, response, modelMap);
		assertEquals("modules/configure/eligibleContainers", result);

		List<String> binList = (List<String>) modelMap.get("binList");
		assertEquals(4, binList.size());
		for (int i = 0; i < 4; i++) {
			assertTrue(binList.contains(i + 1l));
		}

		Page<EligibleBinsPojo> page = (Page<EligibleBinsPojo>) modelMap
				.get("page");
		assertEquals(1, page.getList().size());
		assertEquals(1l, page.getList().get(0).getBinId().longValue());

		List<String> actionList = (List<String>) modelMap.get("actionList");
		assertEquals(2, actionList.size());
		for (int i = 0; i < 2; i++) {
			assertTrue(actionList.contains(assignActions[i]));
		}

		String message = (String) modelMap.get("message");
		assertNull(message);
	}

	@Test
	public void testListEligibleBins_UnAssign_1() {
		EligibleBinsPojo entity = new EligibleBinsPojo();
		entity.setMatchUnitId(1l);
		entity.setBinIds("1");
		entity.setAction(assignActions[1]);

		String result = sysConfigController.listEligibleBins(null, entity,
				request, response, modelMap);
		assertEquals("modules/configure/eligibleContainers", result);

		List<String> binList = (List<String>) modelMap.get("binList");
		assertEquals(4, binList.size());
		for (int i = 0; i < 4; i++) {
			assertTrue(binList.contains(i + 1l));
		}

		Page<EligibleBinsPojo> page = (Page<EligibleBinsPojo>) modelMap
				.get("page");
		assertEquals(0, page.getList().size());

		List<String> actionList = (List<String>) modelMap.get("actionList");
		assertEquals(2, actionList.size());
		for (int i = 0; i < 2; i++) {
			assertTrue(actionList.contains(assignActions[i]));
		}

		String message = (String) modelMap.get("message");
		assertNull(message);
	}

	@Test
	public void testListEligibleBins_Exception() {
		try {
			setMock();

			EligibleBinsPojo entity = new EligibleBinsPojo();
			entity.setMatchUnitId(11l);
			entity.setBinIds("11");
			entity.setAction(assignActions[0]);

			String result = sysConfigController.listEligibleBins(null, entity,
					request, response, modelMap);
			assertEquals("modules/configure/eligibleContainers", result);

			List<String> binList = (List<String>) modelMap.get("binList");
			assertEquals(4, binList.size());
			for (int i = 0; i < 4; i++) {
				assertTrue(binList.contains(i + 1l));
			}

			Page<EligibleBinsPojo> page = (Page<EligibleBinsPojo>) modelMap
					.get("page");
			assertEquals(0, page.getList().size());

			List<String> actionList = (List<String>) modelMap.get("actionList");
			assertEquals(2, actionList.size());
			for (int i = 0; i < 2; i++) {
				assertTrue(actionList.contains(assignActions[i]));
			}

			String message = (String) modelMap.get("message");
			assertNotNull(message);
		} finally {
			tearDownMocks();
		}
	}

	@Test
	public void testListSystemInitialization_NoUpdate() {
		SystemInitEntity entity = new SystemInitEntity();

		String result = sysConfigController.listSystemInitialization(entity,
				request, response, modelMap);
		assertEquals("modules/configure/systeminit", result);

		Page<SystemInitEntity> page = (Page<SystemInitEntity>) modelMap
				.get("page");
		assertEquals(4, page.getList().size());
		for (int i = 0; i < 4; i++) {
			assertEquals(i + 1l, page.getList().get(i).getInitId().longValue());
			assertEquals("Key_" + (i + 1), page.getList().get(i).getKeyName());
			assertEquals("Value_" + (i + 1), page.getList().get(i)
					.getKeyValue());
		}

		String message = (String) modelMap.get("message");
		assertNull(message);
	}

	@Test
	public void testListSystemInitialization_NoUpdate_2() {
		SystemInitEntity entity = new SystemInitEntity();
		entity.setInitId(11l);
		entity.setKeyValue("KeyValue");
		request.setParameter("keyValue", "KeyValue");

		String result = sysConfigController.listSystemInitialization(entity,
				request, response, modelMap);
		assertEquals("modules/configure/systeminit", result);

		Page<SystemInitEntity> page = (Page<SystemInitEntity>) modelMap
				.get("page");
		assertEquals(0, page.getList().size());
		String message = (String) modelMap.get("message");
		assertEquals("can not find System Init: InitId = 11", message);
	}

	@Test
	public void testListSystemInitialization_NoUpdate_3() {
		SystemInitEntity entity = new SystemInitEntity();
		entity.setInitId(1l);

		String result = sysConfigController.listSystemInitialization(entity,
				request, response, modelMap);
		assertEquals("modules/configure/systeminit", result);

		Page<SystemInitEntity> page = (Page<SystemInitEntity>) modelMap
				.get("page");
		assertEquals(1, page.getList().size());
		for (int i = 0; i < 1; i++) {
			assertEquals(i + 1l, page.getList().get(i).getInitId().longValue());
			assertEquals("Key_" + (i + 1), page.getList().get(i).getKeyName());
			assertEquals("Value_" + (i + 1), page.getList().get(i)
					.getKeyValue());
		}

		String message = (String) modelMap.get("message");
		assertNull(message);
	}

	@Test
	public void testListSystemInitialization_Update() {
		SystemInitEntity entity = new SystemInitEntity();
		entity.setInitId(1l);
		entity.setKeyValue("KeyValue");
		request.setParameter("keyValue", "KeyValue");

		String result = sysConfigController.listSystemInitialization(entity,
				request, response, modelMap);
		assertEquals("modules/configure/systeminit", result);

		Page<SystemInitEntity> page = (Page<SystemInitEntity>) modelMap
				.get("page");
		assertEquals(1, page.getList().size());
		for (int i = 0; i < 1; i++) {
			assertEquals(i + 1l, page.getList().get(i).getInitId().longValue());
			assertEquals("Key_" + (i + 1), page.getList().get(i).getKeyName());
			if (i != 0) {
				assertEquals("Value_" + (i + 1), page.getList().get(i)
						.getKeyValue());
			} else {
				assertEquals("KeyValue", page.getList().get(i).getKeyValue());
			}
		}

		String message = (String) modelMap.get("message");
		assertNull(message);
	}

	@Test
	public void testListSystemInitialization_Exception() {
		try {
			setMock();

			SystemInitEntity entity = new SystemInitEntity();
			entity.setInitId(1l);
			entity.setKeyValue("KeyValue");
			request.setParameter("keyValue", "KeyValue");

			String result = sysConfigController.listSystemInitialization(
					entity, request, response, modelMap);
			assertEquals("modules/configure/systeminit", result);

			Page<SystemInitEntity> page = (Page<SystemInitEntity>) modelMap
					.get("page");
			assertEquals(1, page.getList().size());
			for (int i = 0; i < 1; i++) {
				assertEquals(i + 1l, page.getList().get(i).getInitId()
						.longValue());
				assertEquals("Key_" + (i + 1), page.getList().get(i)
						.getKeyName());
				assertEquals("Value_" + (i + 1), page.getList().get(i)
						.getKeyValue());
			}

			String message = (String) modelMap.get("message");
			assertNotNull(message);
		} finally {
			tearDownMocks();
		}
	}

	@Test
	public void testListSystemConfig_NoUpdate() {
		SystemConfigEntity entity = new SystemConfigEntity();

		String result = sysConfigController.listSystemConfig(entity, request,
				response, modelMap);
		assertEquals("modules/configure/systemconfig", result);

		Page<SystemConfigEntity> page = (Page<SystemConfigEntity>) modelMap
				.get("page");
		assertEquals(5, page.getList().size());
		for (int i = 0; i < 4; i++) {
			assertEquals(i + 1l, page.getList().get(i).getConfigId()
					.longValue());
			assertEquals("Key_" + (i + 1), page.getList().get(i)
					.getPropertyName());
			assertEquals("Value_" + (i + 1), page.getList().get(i)
					.getPropertyValue());
		}

		assertEquals(4 + 1l, page.getList().get(4).getConfigId().longValue());
		assertEquals("LOAD_BALANCER.DEFAULT_MIN_REDUNDANCY", page.getList()
				.get(4).getPropertyName());
		assertEquals("2", page.getList().get(4).getPropertyValue());

		String message = (String) modelMap.get("message");
		assertNull(message);
	}

	@Test
	public void testListSystemConfig_NoUpdate_2() {
		SystemConfigEntity entity = new SystemConfigEntity();
		entity.setConfigId(11);
		entity.setPropertyValue("LI");

		String result = sysConfigController.listSystemConfig(entity, request,
				response, modelMap);
		assertEquals("modules/configure/systemconfig", result);

		Page<SystemConfigEntity> page = (Page<SystemConfigEntity>) modelMap
				.get("page");
		assertEquals(0, page.getList().size());

		String message = (String) modelMap.get("message");
		assertEquals(
				"can not find System Config: ConfigId = 11 PropertyName = null",
				message);
	}

	@Test
	public void testListSystemConfig_NoUpdate_3() {
		SystemConfigEntity entity = new SystemConfigEntity();
		entity.setConfigId(1);

		String result = sysConfigController.listSystemConfig(entity, request,
				response, modelMap);
		assertEquals("modules/configure/systemconfig", result);

		Page<SystemConfigEntity> page = (Page<SystemConfigEntity>) modelMap
				.get("page");
		assertEquals(1, page.getList().size());
		for (int i = 0; i < 1; i++) {
			assertEquals(i + 1l, page.getList().get(i).getConfigId()
					.longValue());
			assertEquals("Key_" + (i + 1), page.getList().get(i)
					.getPropertyName());
			assertEquals("Value_" + (i + 1), page.getList().get(i)
					.getPropertyValue());
		}

		String message = (String) modelMap.get("message");
		assertNull(message);
	}

	@Test
	public void testListSystemConfig_Update() {
		SystemConfigEntity entity = new SystemConfigEntity();
		entity.setConfigId(1);
		entity.setPropertyValue("PropertyValue");

		String result = sysConfigController.listSystemConfig(entity, request,
				response, modelMap);
		assertEquals("modules/configure/systemconfig", result);

		Page<SystemConfigEntity> page = (Page<SystemConfigEntity>) modelMap
				.get("page");
		assertEquals(1, page.getList().size());
		for (int i = 0; i < 1; i++) {
			assertEquals(i + 1l, page.getList().get(i).getConfigId()
					.longValue());
			assertEquals("Key_" + (i + 1), page.getList().get(i)
					.getPropertyName());
			if (i != 0) {
				assertEquals("Value_" + (i + 1), page.getList().get(i)
						.getPropertyValue());
			} else {
				assertEquals("PropertyValue", page.getList().get(i)
						.getPropertyValue());
			}
		}

		String message = (String) modelMap.get("message");
		assertNull(message);
	}

	@Test
	public void testListSystemConfig_Exception() {
		try {
			setMock();

			SystemConfigEntity entity = new SystemConfigEntity();
			entity.setConfigId(1);
			entity.setPropertyValue("PropertyValue");

			String result = sysConfigController.listSystemConfig(entity,
					request, response, modelMap);
			assertEquals("modules/configure/systemconfig", result);

			Page<SystemConfigEntity> page = (Page<SystemConfigEntity>) modelMap
					.get("page");
			assertEquals(1, page.getList().size());
			for (int i = 0; i < 1; i++) {
				assertEquals(i + 1l, page.getList().get(i).getConfigId()
						.longValue());
				assertEquals("Key_" + (i + 1), page.getList().get(i)
						.getPropertyName());
				assertEquals("Value_" + (i + 1), page.getList().get(i)
						.getPropertyValue());
			}

			String message = (String) modelMap.get("message");
			assertNotNull(message);
		} finally {
			tearDownMocks();
		}
	}
}
