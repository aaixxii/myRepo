package jp.co.nec.aim.sm.modules.sys.oracle.repository;

import static org.junit.Assert.assertEquals;

import java.util.List;

import javax.sql.DataSource;

import jp.co.nec.aim.sm.common.constant.JobState;
import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.JobPojo;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.TopJobQueue;
import jp.co.nec.aim.sm.test.common.util.CommonUtils;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional(value = "oracleTXManager")
public class JobRepositoryTest {

	@Autowired
	JobRepository jobrepository;
	@Autowired
	@Qualifier("oracleDataSource")
	DataSource datasource;
	JdbcTemplate jdbcTemplate;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {

	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		jdbcTemplate = new JdbcTemplate(datasource);
		CommonUtils.DeleteOracleData(jdbcTemplate);
		CommonUtils.prepareMATCH_UNITS(jdbcTemplate);
		CommonUtils.prepare_JOB_01(jdbcTemplate);
	}

	@After
	public void tearDown() throws Exception {
		CommonUtils.DeleteOracleData(jdbcTemplate);
	}

	@Test
	public void test_findJobPage() {
		Page<TopJobQueue> page = new Page<TopJobQueue>(1, 10);
		JobPojo job = new JobPojo();
		Page<TopJobQueue> pageResult = jobrepository.findJobPage(page, job);
		assertEquals(3, pageResult.getList().size());
		assertEquals(Long.valueOf(3), pageResult.getList().get(0).getJobId());
		assertEquals("WORKING", pageResult.getList().get(0).getJobStatus());
		assertEquals(Long.valueOf(2), pageResult.getList().get(1).getJobId());
		assertEquals("WORKING", pageResult.getList().get(1).getJobStatus());
		assertEquals(Long.valueOf(1), pageResult.getList().get(2).getJobId());
		assertEquals("WORKING", pageResult.getList().get(2).getJobStatus());
	}

	@Test
	public void test_findJobPage_jobid() {
		Page<TopJobQueue> page = new Page<TopJobQueue>(1, 10);
		JobPojo job = new JobPojo();
		job.setJobid(1l);
		Page<TopJobQueue> pageResult = jobrepository.findJobPage(page, job);
		assertEquals(1, pageResult.getList().size());
		assertEquals(Long.valueOf(1), pageResult.getList().get(0).getJobId());
		assertEquals("WORKING", pageResult.getList().get(0).getJobStatus());
	}

	@Test
	public void test_findJobPage_JobState_WORKING() {
		Page<TopJobQueue> page = new Page<TopJobQueue>(1, 10);
		JobPojo job = new JobPojo();
		job.setJobStatus(JobState.WORKING);
		Page<TopJobQueue> pageResult = jobrepository.findJobPage(page, job);
		assertEquals(3, pageResult.getList().size());
		assertEquals(Long.valueOf(3), pageResult.getList().get(0).getJobId());
		assertEquals("WORKING", pageResult.getList().get(0).getJobStatus());
		assertEquals(Long.valueOf(2), pageResult.getList().get(1).getJobId());
		assertEquals("WORKING", pageResult.getList().get(1).getJobStatus());
		assertEquals(Long.valueOf(1), pageResult.getList().get(2).getJobId());
		assertEquals("WORKING", pageResult.getList().get(2).getJobStatus());
	}

	@Test
	public void test_findJobPage_JobState_COMPLETED() {
		Page<TopJobQueue> page = new Page<TopJobQueue>(1, 10);
		JobPojo job = new JobPojo();
		job.setJobStatus(JobState.COMPLETED);
		Page<TopJobQueue> pageResult = jobrepository.findJobPage(page, job);
		assertEquals(0, pageResult.getList().size());
	}

	@Test
	public void test_findJobPage_FunctionTI() {
		Page<TopJobQueue> page = new Page<TopJobQueue>(1, 10);
		JobPojo job = new JobPojo();
		job.setFunctiontype("TI");
		Page<TopJobQueue> pageResult = jobrepository.findJobPage(page, job);
		assertEquals(3, pageResult.getList().size());
		assertEquals(Long.valueOf(3), pageResult.getList().get(0).getJobId());
		assertEquals("WORKING", pageResult.getList().get(0).getJobStatus());
		assertEquals(Long.valueOf(2), pageResult.getList().get(1).getJobId());
		assertEquals("WORKING", pageResult.getList().get(1).getJobStatus());
		assertEquals(Long.valueOf(1), pageResult.getList().get(2).getJobId());
		assertEquals("WORKING", pageResult.getList().get(2).getJobStatus());
	}

	@Test
	public void test_findJobPage_FunctionLI() {
		Page<TopJobQueue> page = new Page<TopJobQueue>(1, 10);
		JobPojo job = new JobPojo();
		job.setFunctiontype("LI");
		Page<TopJobQueue> pageResult = jobrepository.findJobPage(page, job);
		assertEquals(3, pageResult.getList().size());
		assertEquals(Long.valueOf(3), pageResult.getList().get(0).getJobId());
		assertEquals("WORKING", pageResult.getList().get(0).getJobStatus());
		assertEquals(Long.valueOf(2), pageResult.getList().get(1).getJobId());
		assertEquals("WORKING", pageResult.getList().get(1).getJobStatus());
		assertEquals(Long.valueOf(1), pageResult.getList().get(2).getJobId());
		assertEquals("WORKING", pageResult.getList().get(2).getJobStatus());
	}

	@Test
	public void test_findJobPage_FailedFlag() {
		Page<TopJobQueue> page = new Page<TopJobQueue>(1, 10);
		JobPojo job = new JobPojo();
		job.setFailedFlag(1);
		Page<TopJobQueue> pageResult = jobrepository.findJobPage(page, job);
		assertEquals(0, pageResult.getList().size());
	}

	@Test
	public void test_findJobList() {
		JobPojo job = new JobPojo();
		List<TopJobQueue> listResult = jobrepository.findJobList(job);
		assertEquals(3, listResult.size());
	}

	@Test
	public void test_findJobList_jobid() {
		JobPojo job = new JobPojo();
		job.setJobid(2l);
		List<TopJobQueue> listResult = jobrepository.findJobList(job);
		assertEquals(1, listResult.size());
	}

	@Test
	public void test_findJobList_JobState() {
		JobPojo job = new JobPojo();
		job.setJobStatus(JobState.WORKING);
		List<TopJobQueue> listResult = jobrepository.findJobList(job);
		assertEquals(3, listResult.size());
	}

	@Test
	public void test_findJobList_Function() {
		JobPojo job = new JobPojo();
		job.setFunctiontype("TI");
		List<TopJobQueue> listResult = jobrepository.findJobList(job);
		assertEquals(3, listResult.size());
	}

	@Test
	public void test_findJobList_FailedFlag() {
		JobPojo job = new JobPojo();
		job.setFailedFlag(null);
		List<TopJobQueue> listResult = jobrepository.findJobList(job);
		assertEquals(3, listResult.size());
	}

	@Test
	public void test_findResultsByjobId() {
		String result = this.jobrepository.findResultsByjobId(1l, "results");
		assertEquals("No results was found..", result);
	}
}
