package jp.co.nec.aim.sm.modules.sys.oracle.repository;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import jp.co.nec.aim.sm.common.constant.MMConfigProperty;
import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.exception.SMDaoException;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.SystemConfigEntity;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional(value = "oracleTXManager")
public class SystemConfigRepositoryImplTest {
	@Autowired
	SystemConfigRepository repository;

	@Autowired
	@Qualifier("oracleDataSource")
	DataSource datasource;

	JdbcTemplate jdbcTemplate;

	@Before
	public void before() {
		jdbcTemplate = new JdbcTemplate(datasource);
		cleanDB();
		prepareDB();
	}

	@After
	public void after() {
		cleanDB();
	}

	private void cleanDB() {
		jdbcTemplate.execute("delete from SYSTEM_CONFIG");
		jdbcTemplate.execute("commit");
	}

	private void prepareDB() {
		for (int i = 1; i <= 4; i++) {
			String sql = "insert into SYSTEM_CONFIG(CONFIG_ID, PROPERTY_NAME,"
					+ " PROPERTY_VALUE) values(" + i + ", 'Key_" + i
					+ "', 'Value_" + i + "')";
			jdbcTemplate.execute(sql);
		}
	}

	@Test
	public void testFindSystemConfigPage() {
		Page<SystemConfigEntity> page = new Page<SystemConfigEntity>(1, 10);
		SystemConfigEntity systemConfig = new SystemConfigEntity();
		systemConfig.setConfigId(1);
		systemConfig.setPropertyName("Key_1");
		Page<SystemConfigEntity> pageResult = repository.findSystemConfigPage(
				page, systemConfig);

		assertEquals(1, pageResult.getList().size());
		assertEquals("Value_1", pageResult.getList().get(0).getPropertyValue());
	}

	@Test
	public void testFindSystemConfig() {
		SystemConfigEntity systemConfig = new SystemConfigEntity();
		systemConfig.setConfigId(1);
		systemConfig.setPropertyName("Key_1");
		List<SystemConfigEntity> list = repository
				.findSystemConfig(systemConfig);

		assertEquals(1, list.size());
		assertEquals("Value_1", list.get(0).getPropertyValue());
	}

	@Test
	public void testFindByPropertyName() {
		SystemConfigEntity systemConfig = repository
				.findByPropertyName("Key_1");

		assertEquals(1, systemConfig.getConfigId().intValue());
		assertEquals("Value_1", systemConfig.getPropertyValue());
	}

	@Test
	public void testFindByPropertyName_Exception() {
		try {
			repository.findByPropertyName("Exception");
			fail();
		} catch (SMDaoException smde) {
			assertEquals("Can not find Property = Exception", smde.getMessage());
		} catch (Exception e) {
			fail();
		}
	}

	@Test
	public void testFindByProperty() {
		String sql = "insert into SYSTEM_CONFIG(CONFIG_ID, PROPERTY_NAME,"
				+ " PROPERTY_VALUE) values(" + 6 + ", '"
				+ MMConfigProperty.MUJOB_TIMEOUT.getName() + "', 'Value_" + 6
				+ "')";
		jdbcTemplate.execute(sql);
		SystemConfigEntity systemConfig = repository
				.findByProperty(MMConfigProperty.MUJOB_TIMEOUT);

		assertEquals(6, systemConfig.getConfigId().intValue());
		assertEquals("Value_6", systemConfig.getPropertyValue());
	}

	@Test
	public void testUpdateSystemConfig() {
		int count = repository.updateSystemConfig(1, null, "propertyValue");
		assertEquals(1, count);

		List<Map<String, Object>> sysConfigList = jdbcTemplate
				.queryForList("select * from SYSTEM_CONFIG where CONFIG_ID = 1");
		assertEquals(1, sysConfigList.size());
		assertEquals("1", sysConfigList.get(0).get("CONFIG_ID").toString());
		assertEquals("propertyValue", sysConfigList.get(0)
				.get("PROPERTY_VALUE"));
	}

	@Test
	public void testUpdateSystemConfig_2() {
		int count = repository.updateSystemConfig(null, "Key_1",
				"propertyValue");
		assertEquals(1, count);
		List<Map<String, Object>> sysConfigList = jdbcTemplate
				.queryForList("select * from SYSTEM_CONFIG where PROPERTY_NAME = 'Key_1'");
		assertEquals(1, sysConfigList.size());
		assertEquals("1", sysConfigList.get(0).get("CONFIG_ID").toString());
		assertEquals("Key_1", sysConfigList.get(0).get("PROPERTY_NAME")
				.toString());
		assertEquals("propertyValue", sysConfigList.get(0)
				.get("PROPERTY_VALUE"));
	}

	@Test
	public void testUpdateSystemConfig_3() {
		int count = repository.updateSystemConfig(1, "Key_1", "propertyValue");

		assertEquals(1, count);

		List<Map<String, Object>> sysConfigList = jdbcTemplate
				.queryForList("select * from SYSTEM_CONFIG where PROPERTY_NAME = 'Key_1'");
		assertEquals(1, sysConfigList.size());
		assertEquals("1", sysConfigList.get(0).get("CONFIG_ID").toString());
		assertEquals("Key_1", sysConfigList.get(0).get("PROPERTY_NAME")
				.toString());
		assertEquals("propertyValue", sysConfigList.get(0)
				.get("PROPERTY_VALUE"));
	}

	@Test
	public void testUpdateSystemConfig_4() {
		int count = repository.updateSystemConfig(null, null, "propertyValue");

		assertEquals(0, count);

		List<Map<String, Object>> sysConfigList = jdbcTemplate
				.queryForList("select * from SYSTEM_CONFIG where PROPERTY_NAME = 'Key_1'");
		assertEquals(1, sysConfigList.size());
		assertEquals("1", sysConfigList.get(0).get("CONFIG_ID").toString());
		assertEquals("Key_1", sysConfigList.get(0).get("PROPERTY_NAME")
				.toString());
		assertEquals("Value_1", sysConfigList.get(0).get("PROPERTY_VALUE"));
	}

	@Test
	public void testGetProperty() {
		String sql = "insert into SYSTEM_CONFIG(CONFIG_ID, PROPERTY_NAME,"
				+ " PROPERTY_VALUE) values(" + 6 + ", '"
				+ MMConfigProperty.MUJOB_TIMEOUT.getName() + "', 'Value_" + 6
				+ "')";
		jdbcTemplate.execute(sql);
		String result = repository.getProperty(MMConfigProperty.MUJOB_TIMEOUT);

		assertEquals("Value_6", result);
	}

	@Test
	public void testGetLongProperty() {
		String sql = "insert into SYSTEM_CONFIG(CONFIG_ID, PROPERTY_NAME,"
				+ " PROPERTY_VALUE) values(" + 6 + ", '"
				+ MMConfigProperty.MUJOB_TIMEOUT.getName() + "', '" + 6
				+ "')";
		jdbcTemplate.execute(sql);
		long result = repository
				.getLongProperty(MMConfigProperty.MUJOB_TIMEOUT);

		assertEquals(6l, result);
	}

	@Test
	public void testGetIntProperty() {
		String sql = "insert into SYSTEM_CONFIG(CONFIG_ID, PROPERTY_NAME,"
				+ " PROPERTY_VALUE) values(" + 6 + ", '"
				+ MMConfigProperty.MUJOB_TIMEOUT.getName() + "', '" + 6
				+ "')";
		jdbcTemplate.execute(sql);
		int result = repository.getIntProperty(MMConfigProperty.MUJOB_TIMEOUT);

		assertEquals(6l, result);
	}

	@Test
	public void testGetBooleanProperty() {
		String sql = "insert into SYSTEM_CONFIG(CONFIG_ID, PROPERTY_NAME,"
				+ " PROPERTY_VALUE) values(" + 6 + ", '"
				+ MMConfigProperty.MUJOB_TIMEOUT.getName() + "', 'true')";
		jdbcTemplate.execute(sql);
		boolean result = repository
				.getBooleanProperty(MMConfigProperty.MUJOB_TIMEOUT);

		assertTrue(result);
	}
}
