package jp.co.nec.aim.sm.modules.sys.oracle.repository;

import static org.junit.Assert.assertEquals;

import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.DmEligibleContainerEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.DmEligibleContainerEntityPK;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional(value = "oracleTXManager")
public class DmEligibleBiometricContainerRepositoryImplTest {
	@Autowired
	DmEligibleBiometricContainerRepository repository;

	@Autowired
	@Qualifier("oracleDataSource")
	DataSource datasource;

	JdbcTemplate jdbcTemplate;

	String[] formatName = new String[] { "RDBT", "RDBL", "LDB", "PBLNF" };

	@Before
	public void before() {
		jdbcTemplate = new JdbcTemplate(datasource);
		cleanDB();
		prepareDB();
	}

	@After
	public void after() {
		cleanDB();
	}

	private void cleanDB() {
		jdbcTemplate.execute("delete from PERSON_BIOMETRICS");
		jdbcTemplate.execute("delete from DATA_MANAGERS");
		jdbcTemplate.execute("delete from DM_ELIGIBLE_CONTAINERS");
		jdbcTemplate.execute("commit");
	}

	private void prepareDB() {
		for (int i = 1; i <= 4; i++) {
			String sql = "insert into DATA_MANAGERS(DM_ID, UNIQUE_ID, STATE,"
					+ "  VERSION) values(" + i + ", 'unique_" + i
					+ "', 'WORKING',  0)";
			jdbcTemplate.execute(sql);
		}
		for (int i = 1; i <= 4; i++) {
			String sql = "insert into DM_ELIGIBLE_CONTAINERS(DM_ID, CONTAINER_ID"
					+ ") values(" + i + ", " + i + ")";
			jdbcTemplate.execute(sql);
		}
	}



	@Test
	public void testFindDmEligibleBinsPage() {
		Page<DmEligibleContainerEntity> page = new Page<DmEligibleContainerEntity>(
				1, 10);
		DmEligibleContainerEntity entity = new DmEligibleContainerEntity();
		DmEligibleContainerEntityPK id = new DmEligibleContainerEntityPK();
		id.setContainerId(1);
		id.setDmId(1l);
		entity.setId(id);
		Page<DmEligibleContainerEntity> pageResult = repository
				.findDmEligibleBinsPage(page, entity);

		assertEquals(1, pageResult.getList().size());
	}

	@Test
	public void testFindDmEligibleBins() {
		DmEligibleContainerEntity entity = new DmEligibleContainerEntity();
		DmEligibleContainerEntityPK id = new DmEligibleContainerEntityPK();
		id.setContainerId(1l);
		id.setDmId(1l);
		entity.setId(id);
		List<DmEligibleContainerEntity> list = repository
				.findDmEligibleBins(entity);
		assertEquals(1, list.size());
	}

	@Test
	public void testAssignDmBin() {
		repository.assignDmBin(1l, "2");

		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from DM_ELIGIBLE_CONTAINERS where DM_ID = 1");
		assertEquals(2, list.size());
	}

	@Test
	public void testUnAssignDmBin() {
		String sql = "insert into DM_ELIGIBLE_CONTAINERS(DM_ID, CONTAINER_ID) values(1, 2)";
		jdbcTemplate.execute(sql);

		repository.unAssignDmBin(1l, "1");

		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select CONTAINER_ID from DM_ELIGIBLE_CONTAINERS where DM_ID = 1");
		assertEquals(1, list.size());
		assertEquals("2", list.get(0).get("CONTAINER_ID").toString());
	}

}
