package jp.co.nec.aim.sm.modules.sys.oracle.repository;

import static org.junit.Assert.assertEquals;

import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.SystemInitEntity;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional(value = "oracleTXManager")
public class SystemInitRepositoryImplTest {
	@Autowired
	SystemInitRepository repository;

	@Autowired
	@Qualifier("oracleDataSource")
	DataSource datasource;

	JdbcTemplate jdbcTemplate;

	@Before
	public void before() {
		jdbcTemplate = new JdbcTemplate(datasource);
		cleanDB();
		prepareDB();
	}

	@After
	public void after() {
		cleanDB();
	}

	private void cleanDB() {
		jdbcTemplate.execute("delete from SYSTEM_INIT");
	}

	private void prepareDB() {
		for (int i = 1; i <= 4; i++) {
			String sql = "insert into SYSTEM_INIT(INIT_ID, KEY_NAME,"
					+ " KEY_VALUE) values(" + i + ", 'Key_" + i
					+ "', 'Value_" + i + "')";
			jdbcTemplate.execute(sql);
		}
	}

	@Test
	public void testFindSystemInitPage() {
		Page<SystemInitEntity> page = new Page<SystemInitEntity>(1, 10);
		SystemInitEntity systemInit = new SystemInitEntity();
		systemInit.setInitId(1l);
		systemInit.setKeyName("Key_1");
		Page<SystemInitEntity> pageResult = repository.findSystemInitPage(page,
				systemInit);

		assertEquals(1, pageResult.getList().size());
		assertEquals("Value_1", pageResult.getList().get(0).getKeyValue());
	}

	@Test
	public void testFindSystemInit() {
		SystemInitEntity systemInit = new SystemInitEntity();
		systemInit.setInitId(1l);
		systemInit.setKeyName("Key_1");
		List<SystemInitEntity> list = repository.findSystemInit(systemInit);

		assertEquals(1, list.size());
		assertEquals("Value_1", list.get(0).getKeyValue());
	}

	@Test
	public void testUpdateSystemInit() {
		int count = repository.updateSystemInit(1l, "propertyValue");

		assertEquals(1, count);

		List<Map<String, Object>> sysInitList = jdbcTemplate
				.queryForList("select * from SYSTEM_INIT where INIT_ID = 1");
		assertEquals(1, sysInitList.size());
		assertEquals("1", sysInitList.get(0).get("INIT_ID").toString());
		assertEquals("propertyValue", sysInitList.get(0).get("KEY_VALUE"));
	}
}
