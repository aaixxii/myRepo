package jp.co.nec.aim.sm.modules.sys.oracle.repository;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.util.List;

import javax.sql.DataSource;

import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.FormatTypeEntity;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional(value = "oracleTXManager")
public class FormatTypeRepositoryImplTest {
	@Autowired
	FormatTypeRepository repository;

	@Autowired
	@Qualifier("oracleDataSource")
	DataSource datasource;

	JdbcTemplate jdbcTemplate;

	String[] formatName = new String[] { "RDBT", "RDBL", "LDB", "PBLNF" };

	@Before
	public void before() {
		jdbcTemplate = new JdbcTemplate(datasource);
		cleanDB();
		// prepareDB();
	}

	@After
	public void after() {
		cleanDB();
	}

	private void cleanDB() {
		jdbcTemplate.execute("delete from JOB_QUEUE");
		jdbcTemplate.execute("delete from PERSON_BIOMETRICS");
		// jdbcTemplate.execute("delete from AFIS_BINS");
		// jdbcTemplate.execute("delete from BINS");
		// jdbcTemplate.execute("delete from FORMAT_TYPES");
		jdbcTemplate.execute("commit");
	}

	@Test
	public void testFindFormatTypePage() {
		Page<FormatTypeEntity> page = new Page<FormatTypeEntity>(1, 10);
		FormatTypeEntity entity = new FormatTypeEntity();
		entity.setFormatId(1);
		entity.setFormatName(formatName[0]);
		Page<FormatTypeEntity> pageResult = repository.findFormatTypePage(page,
				entity);

		assertEquals(1, pageResult.getList().size());
		// assertEquals(1,
		// pageResult.getList().get(0).getEmbeddedId().intValue());
	}

	@Test
	public void testGetAllFormatType() {

		List<String> list = repository.getAllFormatType();

		assertEquals(14, list.size());
	}

	@Test
	public void testGetFormatId() {
		Integer result = repository.getFormatId(formatName[0]);

		assertEquals(1, result.intValue());

		result = repository.getFormatId("Test");

		assertNull(result);
	}
}
