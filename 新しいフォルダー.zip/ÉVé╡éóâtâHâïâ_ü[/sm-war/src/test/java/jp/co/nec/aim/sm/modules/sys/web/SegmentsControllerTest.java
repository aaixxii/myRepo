package jp.co.nec.aim.sm.modules.sys.web;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import javax.sql.DataSource;

import jp.co.nec.aim.sm.common.constant.UnitType;
import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.SegmentSegmentReport;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional(value = "oracleTXManager")
public class SegmentsControllerTest {	
	
	@Autowired
	@Qualifier("oracleDataSource")
	DataSource datasource;
	
	@Autowired
	SegmentsController assignedSegmentsController;
	
	private JdbcTemplate jdbcTemplate;
	private MockMvc mockMvc;
	

	@Before
	public void setUp() throws Exception {
		jdbcTemplate = new JdbcTemplate(datasource);
		clearDb();
		//mockMvc = MockMvcBuilders.webAppContextSetup(this.wac).build();
		mockMvc = MockMvcBuilders.standaloneSetup(assignedSegmentsController).build();
		
	}

	@After
	public void tearDown() throws Exception {
		clearDb();		
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testListSegmentSegmentReport_dm() {
		prepareDmSegSetReportDB();	
		Long muId = 1L;
		String type = UnitType.DM.name();
	        try {
				mockMvc.perform(get("/segments/segmentsegmentreport/list")	               
				        .param("type", type)
				        .param("muId", String.valueOf(muId))
				).andExpect(status().isOk())
			      .andExpect(MockMvcResultMatchers.view().name("modules/segments/segmentsegmentreportlist"))  
			      .andExpect(MockMvcResultMatchers.model().attributeExists("muId"))
			      .andExpect(MockMvcResultMatchers.model().attributeExists("type"))			      
			      .andExpect(MockMvcResultMatchers.model().attribute("type", UnitType.DM.name()))
			      .andReturn();
				
				MvcResult mvcResult = mockMvc.perform(get("/segments/segmentsegmentreport/list")	               
				        .param("type", type)
				        .param("muId", String.valueOf(muId))
				).andExpect(status().isOk())
			      .andReturn(); 
				
				 ModelMap modelMap = mvcResult.getModelAndView().getModelMap();	
				 Page<SegmentSegmentReport> resultsPage = (Page<SegmentSegmentReport>) modelMap.get("page");
				 Assert.assertEquals(2, resultsPage.getCount());				 
				 Assert.assertEquals(4, modelMap.size());				 
			} catch (Exception e) {				
				e.printStackTrace();
			}
	}
	
	private void prepareDmSegSetReportDB() {
		for (int i = 1; i <= 4; i++) {
			String sql = "insert into DATA_MANAGERS(DM_ID, UNIQUE_ID, STATE,"
					+ "  VERSION) values(" + i + ", 'unique_" + i
					+ "', 'WORKING',  0)";
			jdbcTemplate.execute(sql);
		}
		
		String insertsql = ""
				+ "insert into PERSON_BIOMETRICS(BIOMETRICS_ID,EXTERNAL_ID,BIOMETRIC_DATA,"
				+ "BIOMETRIC_DATA_LEN,REGISTED_TS,CORRUPTED_FLAG,EVENT_ID,CONTAINER_ID)"
				+ " values(?,?,HEXTORAW('3E00210102CDA000C9'),50,1000,0,?,?)";				
		Long[] pbioIds = { 1000L, 1001L, 1002L, 1003L, 1004L, 1005L, 1006L,
				1007L };
		Integer[] containerIds = { 1, 1, 331, 331, 332, 3, 4, 336 };
		for (int i = 0; i < pbioIds.length; i++) {
			jdbcTemplate.update(insertsql,
					new Object[] { pbioIds[i], String.valueOf(pbioIds[i]),
							i + 1, containerIds[i] });
		}
		
		String insSegTabSql = "insert into segments(segment_id,container_id,bio_id_start,bio_id_end,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)"
				+ " values(?,?,?,?,333,1,?,?,333)";		
		Long segmentIds[] = {2000L,2001L,2002L,2003L,2004L,2005L,2006L,2007L};
		for (int i = 0 ;i < segmentIds.length; i++) {
			jdbcTemplate.update(insSegTabSql,new Object[] {segmentIds[i],containerIds[i],pbioIds[i], pbioIds[i],i,i});
		}
		
		String insDmSegmentsSql = "insert into DM_SEGMENTS(DM_ID," + "SEGMENT_ID," + "RANK"
				+ ") values (?,?,?)";
		jdbcTemplate.update(insDmSegmentsSql, new Object[] { 1, 2000, 0 });
		jdbcTemplate.update(insDmSegmentsSql, new Object[] { 1, 2001, 0 });	
		
		String insDmSegReportsql = "insert into dm_seg_reports(dm_id, segment_id, status, segment_version) values (?,?,?,?)";
		
		jdbcTemplate.update(insDmSegReportsql, new Object[] { 1, 2000, 1, 10561 });
		jdbcTemplate.update(insDmSegReportsql, new Object[] { 1, 2001, 1, 10561 });	
		
		jdbcTemplate.execute("commit");		
	}
	
	public void clearDb() {
		jdbcTemplate.execute("delete from DATA_MANAGERS");
		jdbcTemplate.execute("delete from PERSON_BIOMETRICS");
		jdbcTemplate.execute("delete from DM_SEGMENTS");
		jdbcTemplate.execute("delete from DM_SEG_REPORTS");		
		jdbcTemplate.execute("delete from segments");		
	}

}
