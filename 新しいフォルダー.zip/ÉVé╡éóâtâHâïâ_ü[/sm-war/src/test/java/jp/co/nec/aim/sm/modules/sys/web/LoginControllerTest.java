package jp.co.nec.aim.sm.modules.sys.web;

import static org.junit.Assert.assertEquals;

import javax.servlet.http.Cookie;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml",
		"classpath:applicationContext-shiro.xml" })
public class LoginControllerTest {

	@Autowired
	LoginController loginController;

	@Before
	public void before() {
	}

	@After
	public void after() {
	}

	@Test
	public void testGetThemeInCookie() {
		MockHttpServletRequest request = new MockHttpServletRequest();
		MockHttpServletResponse response = new MockHttpServletResponse();
		request.setParameter("url", "Test URL");
		String result = loginController.getThemeInCookie("isNotBlank", request,
				response);
		Cookie cookie = response.getCookie("theme");
		assertEquals("isNotBlank", cookie.getValue());
		assertEquals("redirect:Test URL", result);

		String theme = "";
		result = loginController.getThemeInCookie(theme, request, response);

		assertEquals("redirect:Test URL", result);
	}
}
