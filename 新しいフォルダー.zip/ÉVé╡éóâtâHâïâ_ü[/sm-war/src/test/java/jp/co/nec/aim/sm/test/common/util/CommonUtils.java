package jp.co.nec.aim.sm.test.common.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractInputPayload;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractTenprintInput;
import jp.co.nec.aim.message.proto.ExtractService.PBExtractJobRequest;
import jp.co.nec.aim.message.proto.ExtractService.PBExtractJobResult;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.jdbc.core.JdbcTemplate;

public class CommonUtils {

	private static String insertsql;

	/**
	 * Oracle
	 * 
	 * @param jdbctemplate
	 */
	public static void prepareFEJobsdata(JdbcTemplate jdbctemplate) {
		insertsql = "insert into MATCH_UNITS(  MU_ID," + "UNIQUE_ID,"
				+ "CONTACT_URL," + "STATE," + "PRIMARY_SIZE,"
				+ "SECONDARY_SIZE," + "REPORTED_PERFORMANCE_FACTOR,"
				+ "NUMBER_OF_MATCHERS,"
				+ "NUMBER_OF_EXTRACTORS) values(?,?,?,?,?,?,?,?,?)";
		Log();
		jdbctemplate.update(insertsql,
				new Object[] { 21, "192.168.100.36",
						"http://192.168.100.36:8080/", "WORKING", 0, 999999488,
						1, 1, 1 });

		insertsql = "insert into FE_JOB_QUEUE( JOB_ID," + "FUNCTION_ID,"
				+ "PRIORITY," + "JOB_STATE," + "FAILED_FLAG," + "MU_ID,"
				+ "ASSIGNED_TS," + "RESULT_TS, SUBMISSION_TS, CALLBACK_STYLE"
				+ ")" + " values(?,?,?,?,?,?,?,?,?,?)";

		Log();
		for (int i = 0; i < 40; i++) {
			jdbctemplate.update(insertsql,
					new Object[] { 100 + i, 2, i % 7, i % 3, i % 2, 21,
							new Date().getTime(), new Date().getTime(),
							new Date().getTime(), 0 });
		}

	}

	public static void prepareSYSTEM_CONFIG(JdbcTemplate jdbctemplate) {
		insertsql = "insert into SYSTEM_CONFIG(CONFIG_ID," + "PROPERTY_NAME,"
				+ "PROPERTY_VALUE," + "NAMESPACE) values (?,?,?,?)";
		Log();
		jdbctemplate.update(insertsql, new Object[] { 151,
				"DYNAMIC_THRESHOLD.LIMITS.HIT_THRESHOLD.MIN", "0", "MM" });
	}

	public static void prepareMATCH_UNITS(JdbcTemplate jdbctemplate) {
		insertsql = "insert into MATCH_UNITS(  MU_ID," + "UNIQUE_ID,"
				+ "CONTACT_URL," + "STATE," + "PRIMARY_SIZE,"
				+ "SECONDARY_SIZE," + "REPORTED_PERFORMANCE_FACTOR,"
				+ "NUMBER_OF_MATCHERS,"
				+ "NUMBER_OF_EXTRACTORS,VERSION) values(?,?,?,?,?,?,?,?,?,?)";
		Log();
		jdbctemplate.update(insertsql, new Object[] { 21, "MU:192.168.100.36",
				"http://192.168.100.36:8080/", "WORKING", 999999488,
				13945794560L, 1, 1, 1, "3.1.0-SNAPSHOT-I" });

		jdbctemplate.update(insertsql, new Object[] { 100, "MU:192.168.100.35",
				"http://192.168.100.35:8080/", "TIMED_OUT", 999999488,
				33469022208l, 1, 1, 1, "3.1.0-SNAPSHOT-I" });

		jdbctemplate.update(insertsql, new Object[] { 101, "MU:192.168.100.37",
				"http://192.168.100.37:8080/", "TIMED_OUT", 999999488,
				33469022208l, 1, 1, 1, "3.1.0-SNAPSHOT-I" });

		insertsql = "insert into DATA_MANAGERS(  DM_ID ,UNIQUE_ID ,CONTACT_URL,STATE,VERSION) values(?,?,?,?,?)";

		jdbctemplate.update(insertsql, new Object[] { 102, "DM:192.168.100.34",
				"http://192.168.100.34:8080/datamanager", "WORKING", "5.0.1" });

		insertsql = "insert into MAP_REDUCERS(  MR_ID ,RING_LOCATION,UNIQUE_ID ,CONTACT_URL,STATE,VERSION) values(?,?,?,?,?,?)";

		jdbctemplate
				.update(insertsql, new Object[] { 202, 202,
						"MR:192.168.100.202",
						"http://192.168.100.202:8080/mapReducers", "WORKING",
						"5.0.1" });
	}

	public static void prepareMU_CONTACTS(JdbcTemplate jdbctemplate) {
		insertsql = "insert into MU_CONTACTS(MU_ID," + "LAST_CONTACT_TS,"
				+ "LAST_REPORT_TS," + "IDLE_FLAG) values (?,?,?,?)";
		jdbctemplate.update(insertsql, new Object[] { 21, new Date(),
				new Date(), 1 });
		jdbctemplate.update(insertsql, new Object[] { 100, new Date(),
				new Date(), 1 });
		jdbctemplate.update(insertsql, new Object[] { 101, new Date(),
				new Date(), 0 });
		jdbctemplate.update(insertsql, new Object[] { 41, new Date(),
				new Date(), 1 });
	}

	public static void prepareMATCH_MANAGERS(JdbcTemplate jdbctemplate) {
		insertsql = "insert into MATCH_MANAGERS (MM_ID," + "UNIQUE_ID,"
				+ "STATE," + "CONTACT_URL," + "HEARTBEAT_TS,"
				+ "VERSION) values (?,?,?,?,?,?)";
		Log();
		jdbctemplate.update(
				insertsql,
				new Object[] { 4, "127.0.0.1", "WORKING",
						"http://127.0.0.1:8080/matchmanager",
						System.currentTimeMillis(), "4.0.0-Beta6" });
		jdbctemplate.update(
				insertsql,
				new Object[] { 5, "192.168.100.21", "WORKING",
						"http://192.168.100.21:8080/matchmanager",
						System.currentTimeMillis(), "4.0.0-Beta6" });
		jdbctemplate.update(
				insertsql,
				new Object[] { 6, "192.168.100.22", "EXITED",
						"http://192.168.100.22:8080/matchmanager",
						System.currentTimeMillis(), "4.0.0-Beta6" });
	}

	public static void prepareMATCH_MANAGERS_one(JdbcTemplate jdbctemplate) {
		insertsql = "insert into MATCH_MANAGERS (MM_ID," + "UNIQUE_ID,"
				+ "STATE," + "CONTACT_URL," + "LAST_HEARTBEAT_TS,"
				+ "VERSION) values (?,?,?,?,?,?)";
		Log();
		jdbctemplate.update(insertsql, new Object[] { 4, "127.0.0.1",
				"WORKING", "http://127.0.0.1:8080/matchmanager", new Date(),
				"4.0.0-Beta6" });
	}

	public static void prepareMATCH_MANAGERS_two(JdbcTemplate jdbctemplate) {
		insertsql = "insert into MATCH_MANAGERS (MM_ID," + "UNIQUE_ID,"
				+ "STATE," + "CONTACT_URL," + "LAST_HEARTBEAT_TS,"
				+ "VERSION) values (?,?,?,?,?,?)";
		Log();
		jdbctemplate.update(insertsql, new Object[] { 4, "127.0.0.1",
				"WORKING", "http://127.0.0.1:8080/matchmanager/", new Date(),
				"4.0.0-Beta6" });
	}

	@SuppressWarnings("deprecation")
	public static void prepareSEGMENTS(JdbcTemplate jdbctemplate) {
		insertsql = "insert into SEGMENTS (SEGMENT_ID," + "CONTAINER_ID,"
				+ "BIO_ID_START," + "BIO_ID_END," + "BINARY_LENGTH_COMPACTED,"
				+ "RECORD_COUNT," + "VERSION," + "REVISION,"
				+ "BINARY_LENGTH_UNCOMPACTED ) values(?,?,?,?,?,?,?,?,?)";
		Log();
		final String containerIdSql = "select CONTAINER_ID from \"CONTAINERS\" where CONTAINER_ID=?";
		int containerId = jdbctemplate.queryForInt(containerIdSql,
				new Object[] { 4 });
		for (int i = 0; i < 100; i++) {
			jdbctemplate.update(insertsql, new Object[] { i, containerId,
					221000 + 100 * i + 1, 223000 + 100 * i, 8387938, 1000,
					10561, 10561, 8387938 });
		}

		containerId = jdbctemplate.queryForInt(containerIdSql,
				new Object[] { 323 });

		for (int i = 0; i < 100; i++) {
			jdbctemplate.update(insertsql, new Object[] { 100 + i, containerId,
					241000 + 100 * i, 243000 + 100 * i, 8387938, 1000, 10561,
					10561, 8387938 });
		}

		containerId = jdbctemplate.queryForInt(containerIdSql,
				new Object[] { 336 });
		for (int i = 0; i < 100; i++) {
			jdbctemplate.update(insertsql, new Object[] { 200 + i, containerId,
					261000 + 100 * i + 1, 263000 + 100 * i, 8387938, 1000,
					10561, 10561, 8387938 });
		}
	}

	public static void prepareMU_SEGMENTS(JdbcTemplate jdbctemplate) {
		insertsql = "insert into MU_SEGMENTS(MU_ID," + "SEGMENT_ID," + "RANK"
				+ ") values (?,?,?)";
		Log();
		for (int i = 0; i < 100; i++) {
			jdbctemplate.update(insertsql, new Object[] { 100, i, 0 });
		}
		for (int i = 0; i < 100; i++) {
			jdbctemplate.update(insertsql, new Object[] { 21, 100 + i, 0 });
		}

		for (int i = 0; i < 100; i++) {
			jdbctemplate.update(insertsql, new Object[] { 101, 200 + i, 0 });
		}
	}

	public static void prepareSYSTEM_INIT(JdbcTemplate jdbctemplate) {
		insertsql = "insert into SYSTEM_INIT( INIT_ID," + "KEY_NAME,"
				+ "KEY_VALUE," + "LAST_TS)values(?,?,?,?)";
		Log();
		jdbctemplate.update(insertsql, new Object[] { 1,
				"FLOW_CONTROL_ENABLED", "true", new Date() });
		jdbctemplate.update(insertsql, new Object[] { 2, "DEFRAG_BIN_ID", "-1",
				new Date() });
		jdbctemplate.update(insertsql, new Object[] { 3, "DEFRAG_MULTI_BOOT",
				"false", new Date() });
	}

	@SuppressWarnings("deprecation")
	public static void prepare_JOB(JdbcTemplate jdbctemplate) {
		int fusionjobid = 0;
		int jobid = 0;
		int segmentsetjobid = 0;
		jdbctemplate.update("insert into MATCH_UNITS(MU_ID, UNIQUE_ID, STATE)"
				+ " values(10, '10', 'WORKING')");

		final String insertContainerJobs = "insert into CONTAINER_JOBS (CONTAINER_JOB_ID, CONTAINER_ID,"
				+ "FUSION_JOB_ID,JOB_STATE) values (?,?,?,0)";

		final String insertFusionJobs = "insert into fusion_jobs (FUSION_JOB_ID, FUNCTION_ID, "
				+ "JOB_ID, SEARCH_REQUEST_INDEX) values(?,?,?,?)";

		final String insertJobQueue = "insert into job_queue(JOB_ID, priority, job_state, SUBMISSION_TS, CALLBACK_STYLE, FAMILY_ID) values(?,?,?,?,?,?)";

		final String containerIdSql = "select CONTAINER_ID from \"CONTAINERS\" where CONTAINER_ID=4";
		int containerId = jdbctemplate.queryForInt(containerIdSql);
		final String segmentCount = "select count(*) FROM segments where CONTAINER_ID="
				+ containerId;

		final String segmentsCount01 = "select count(*) FROM segments";
		int icount01 = jdbctemplate.queryForInt(segmentsCount01);
		if (icount01 == 0) {
			prepareSEGMENTS(jdbctemplate);
		}

		int icount = jdbctemplate.queryForInt(segmentCount);
		for (int x = 1; x <= icount; x++) {
			if (x == 1) {
				jobid++;
				jdbctemplate.update(insertJobQueue, new Object[] { jobid, 1, 1,
						new Date().getTime(), 0, 1 });

				fusionjobid++;
				jdbctemplate.update(insertFusionJobs, new Object[] {
						fusionjobid, 1, jobid, 1 });
				segmentsetjobid++;
				jdbctemplate.update(insertContainerJobs, new Object[] {
						segmentsetjobid, containerId, fusionjobid });
			} else if (x % 25 == 0) {
				fusionjobid++;
				jdbctemplate.update(insertFusionJobs, new Object[] {
						fusionjobid, 1, jobid, 1 });
			} else if (x % 15 == 0) {
				segmentsetjobid++;
				jdbctemplate.update(insertContainerJobs, new Object[] {
						segmentsetjobid, containerId, fusionjobid });
			}
		}
	}

	
	public static void prepare_JOB_01(JdbcTemplate jdbctemplate) {
		int fusionjobid = 0;
		int jobid = 0;
		int segmentsetjobid = 0;

		final String insertContainerJobs = "insert into CONTAINER_JOBS (CONTAINER_JOB_ID, CONTAINER_ID,"
				+ "FUSION_JOB_ID,JOB_STATE) values (?,?,?,0)";

		final String insertFusionJobs = "insert into fusion_jobs (FUSION_JOB_ID, FUNCTION_ID, "
				+ "JOB_ID, SEARCH_REQUEST_INDEX) values(?,?,?,?)";

		final String insertJobQueue = "insert into job_queue(JOB_ID, priority, job_state, SUBMISSION_TS, CALLBACK_STYLE, FAMILY_ID) values(?,?,?,?,?,?)";

		final String containerIdSql = "select CONTAINER_ID from \"CONTAINERS\" where CONTAINER_ID=4";		
		int containerId = jdbctemplate.queryForObject(containerIdSql,Integer.class);
		
		final String segmentCount = "select count(*) FROM segments where CONTAINER_ID="
				+ containerId;

		final String segmentsCount01 = "select count(*) FROM segments";
		int icount01 = jdbctemplate.queryForObject(segmentsCount01,Integer.class);
		if (icount01 == 0) {
			prepareSEGMENTS(jdbctemplate);
		}

		int icount = jdbctemplate.queryForObject(segmentCount, Integer.class);
		for (int x = 1; x <= icount; x++) {
			if (x % 35 == 1) {
				jobid++;
				jdbctemplate.update(insertJobQueue, new Object[] { jobid, 1, 1,
						new Date().getTime(), 0, 1 });

				fusionjobid++;
				jdbctemplate.update(insertFusionJobs, new Object[] {
						fusionjobid, 1, jobid, 1 });
				segmentsetjobid++;
				jdbctemplate.update(insertContainerJobs, new Object[] {
						segmentsetjobid, containerId, fusionjobid });
			} else if (x % 25 == 0) {
				fusionjobid++;
				jdbctemplate.update(insertFusionJobs, new Object[] {
						fusionjobid, 2, jobid, x % 3 });
			} else if (x % 15 == 0) {
				segmentsetjobid++;
				jdbctemplate.update(insertContainerJobs, new Object[] {
						segmentsetjobid, containerId, fusionjobid });
			}
		}
	}

	public static void prepareFeJobQueue(JdbcTemplate jdbcTemplate) {
		final String insertFeJobQueueSql = "insert into fe_job_queue("
				+ "JOB_ID, FUNCTION_ID, PRIORITY, JOB_STATE, RESULT, SUBMISSION_TS, CALLBACK_STYLE)"
				+ " values(?,?,?,?,?,?,?)";
		for (int i = 1; i <= 10; i++) {
			jdbcTemplate.update(insertFeJobQueueSql, new Object[] { i, 17, 5,
					2, getExtResult().toByteArray(), new Date().getTime(), 1 });
		}
	}

	public static void prepareFeJobPayload(JdbcTemplate jdbcTemplate) {
		final String insertFeJobPayloadSql = "insert into fe_job_payloads("
				+ "PAYLOAD_ID, PAYLOAD, JOB_ID)" + " values(?,?,?)";
		for (int i = 1; i <= 10; i++) {
			jdbcTemplate.update(insertFeJobPayloadSql, new Object[] { i,
					getExtReq().toByteArray(), i });
		}
	}

	public static PBExtractJobResult getExtResult() {
		PBExtractJobResult.Builder builder = PBExtractJobResult.newBuilder();
		builder.setServiceState(getSs());
		builder.setJobId(1L);
		return builder.build();
	}

	public static PBServiceState getSs() {
		PBServiceState.Builder builder = PBServiceState.newBuilder();
		builder.setState(ServiceStateType.SERVICE_STATE_SUCCESS);
		return builder.build();
	}

	public static PBExtractJobRequest getExtReq() {
		PBExtractJobRequest.Builder builder = PBExtractJobRequest.newBuilder();
		PBExtractInputPayload.Builder builder2 = PBExtractInputPayload
				.newBuilder();
		PBExtractTenprintInput.Builder builder3 = PBExtractTenprintInput
				.newBuilder();
		builder2.setTenprintInput(builder3.build());
		builder.setInputPayload(builder2.build());
		return builder.build();
	}

	public static void prepareMU_SEG_REPORTS(JdbcTemplate jdbctemplate) {
		prepareMATCH_UNITS(jdbctemplate);
		prepareSEGMENTS(jdbctemplate);
		prepareMU_SEGMENTS(jdbctemplate);
		insertsql = "insert into MU_SEG_REPORTS( MU_ID," + "SEGMENT_ID,"
				+ "STATUS," + "SEGMENT_VERSION,"
				+ "SEGMENT_QUEUED_VERSION) values (?,?,?,?,?)";
		for (int i = 0; i < 100; i++) {
			jdbctemplate.update(insertsql, new Object[] { 100, i, 1, 10561,
					10561 });
		}

		for (int i = 0; i < 100; i++) {
			jdbctemplate.update(insertsql, new Object[] { 21, 100 + i, 1,
					10561, 10561 });
		}

		for (int i = 0; i < 100; i++) {
			jdbctemplate.update(insertsql, new Object[] { 101, 200 + i, 1,
					10561, 10561 });
		}
	}

	// @SuppressWarnings("deprecation")
	// public static void prepareMU_JOB_FAILURE_REASONS(JdbcTemplate
	// jdbctemplate) {
	//
	// Log();
	// prepare_JOB(jdbctemplate);
	// int icount = jdbctemplate.queryForInt("select count(*) from MU_JOBS");
	// insertsql = "insert into MU_JOB_FAILURE_REASONS ( FAILURE_ID,"
	// + "REASON," + "FAILURE_TS," + "MU_JOB_ID) values (?,?,?,?)";
	// for (int i = 1; i <= icount; i++) {
	// jdbctemplate.update(insertsql, new Object[] { 100 + i, "ERROR",
	// new Date(), i });
	// }
	// }

	public static void preparePERSON_BIOMETRICS(JdbcTemplate jdbctemplate) {
		insertsql = "insert into PERSON_BIOMETRICS (BIOMETRICS_ID,"
				+ "EXTERNAL_ID," + "BIOMETRIC_DATA," + "BIOMETRIC_DATA_LEN,"
				+ "DATE_ADDED," + "CORRUPTED_FLAG," + "EVENT_ID,"
				+ "BIN_ID) values (?,?,?,?,?,?,?,?)";
		Log();
		String ss = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAA";
		for (int i = 0; i < 15; i++) {
			jdbctemplate.update(insertsql, new Object[] { 221000 + 100 * i + 1,
					"EXTERNAL_ID_" + 221000 + 100 * i + 1, ss, 1056,
					new Date(), 0, 2001, 4 });
		}
	}

	/**
	 * postgreSql
	 * 
	 * @param jdbctemplate
	 */
	public static void prepareUSERS(JdbcTemplate jdbctemplate) {
		String username = "administrator";
		String password = "admin@123";
		String pwd = covert(password);
		insertsql = "insert into \"USERS\" (\"USER_ID\"," + "\"USER_NAME\","
				+ "\"MUST_CHANGE_PASSWORD_FLAG\"," + "\"PASSWORD\","
				+ "\"ROLE\"," + "\"FIRST_NAME\"," + "\"LAST_NAME\","
				+ "\"EMAIL\")values (?,?,?,?,?,?,?,?)";
		Log();
		jdbctemplate.update(insertsql, new Object[] { 1001, username, 0, pwd,
				"Admin", "admin", "admin", "admin@126.com" });
		jdbctemplate.update(insertsql,
				new Object[] { 1002, "xushanniyater", 0, covert("xushan@123"),
						"User", "admin", "admin", "admin@123.com" });
		jdbctemplate.update(insertsql, new Object[] { 1003, "admin", 1,
				covert("Sdbserver1234"), "Admin", "admin", "admin",
				"admin@168.com" });
		jdbctemplate.update(insertsql, new Object[] { 1004, "zaiwei", 1,
				covert("xushan@123"), "User", "admin", "admin",
				"admin123@123.com" });

		jdbctemplate.update(insertsql, new Object[] { 1005, "guang", 1,
				covert("Sdbserver1234"), "Admin", "admin", "admin",
				"guang@168.com" });

		jdbctemplate.update(insertsql, new Object[] { 1006, "liang", 1,
				covert("Sdbserver1234"), "Admin", "admin", "admin",
				"liang@168.com" });

		jdbctemplate.update(insertsql, new Object[] { 1007, "yunque", 1,
				covert("Sdbserver1234"), "Admin", "admin", "admin",
				"yunque@168.com" });
	}

	public static void prepareUSER_RELATIONS(JdbcTemplate jdbctemplate) {
		insertsql = "insert into \"USER_RELATIONS\" (\"USER_ID\","
				+ "\"ASSOCIATED_USER_ID\") values(?,?)";
		Log();
		jdbctemplate.update(insertsql, new Object[] { 1001, 2100 });
		jdbctemplate.update(insertsql, new Object[] { 1001, 2500 });
	}

	public static void prepareUSER_RELATIONS_TWO(JdbcTemplate jdbctemplate) {
		insertsql = "insert into \"USER_RELATIONS\" (\"USER_ID\","
				+ "\"ASSOCIATED_USER_ID\") values(?,?)";
		Log();
		jdbctemplate.update(insertsql, new Object[] { 1001, 1002 });
		jdbctemplate.update(insertsql, new Object[] { 1003, 1004 });
		jdbctemplate.update(insertsql, new Object[] { 1005, 1006 });
		jdbctemplate.update(insertsql, new Object[] { 1006, 1007 });
	}

	public static void prepareUSER_RELATIONS_FOUR(JdbcTemplate jdbctemplate) {
		insertsql = "insert into \"USER_RELATIONS\" (\"USER_ID\","
				+ "\"ASSOCIATED_USER_ID\") values(?,?)";
		Log();
		jdbctemplate.update(insertsql, new Object[] { 1001, 1004 });
	}

	public static void prepareUSER_RELATIONS_THREE(JdbcTemplate jdbctemplate) {
		insertsql = "insert into \"USER_RELATIONS\" (\"USER_ID\","
				+ "\"ASSOCIATED_USER_ID\") values(?,?)";
		Log();
		jdbctemplate.update(insertsql, new Object[] { 1001, 1001 });
	}

	public static void prepareLOGIN_DETAILS(JdbcTemplate jdbctemplate) {
		insertsql = "insert into \"LOGIN_DETAILS\" (\"LOGIN_ID\","
				+ "\"USER_NAME\"," + "\"LOGIN_TYPE\","
				+ "\"TIMESTAMP\") values (?,?,?,?)";
		Log();
		jdbctemplate.update(insertsql, new Object[] { "66B85470F53B7",
				"administrator", "IN", new Date() });
		jdbctemplate.update(insertsql, new Object[] { "66EEE00497141",
				"administrator", "IN", new Date() });
		jdbctemplate.update(insertsql, new Object[] { "743921D4CB9DA",
				"xushanniyater", "IN", new Date() });
		jdbctemplate.update(insertsql, new Object[] { "751D6EE6CB725",
				"xushanniyater", "IN", new Date() });
		jdbctemplate.update(insertsql, new Object[] { "7A6CEA73FA2F9", "admin",
				"IN", new Date() });
		jdbctemplate.update(insertsql, new Object[] { "7E13CB4C10334", "admin",
				"IN", new Date() });

	}

	public static void prepareEVENT_LOG(JdbcTemplate jdbctemplate) {

		try {
			DateFormat dateFormat;
			dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
			dateFormat.setLenient(false);
			java.util.Date timeDate;
			timeDate = dateFormat.parse("1998-05-01");
			java.sql.Date dateTime = new java.sql.Date(timeDate.getTime());

			insertsql = "insert into \"EVENT_LOG\" (\"EVENT_ID\","
					+ "\"UNIT_ID\"," + "\"TIMESTAMP\"," + "\"MESSAGE_CODE\" ,"
					+ "\"MESSAGE\"," + "\"CLASS\","
					+ "\"MESSAGE_TYPE\") values (?,?,?,?,?,?,?)";
			Log();
			jdbctemplate.update(insertsql, new Object[] { 732592, 999,
					dateTime, "044000300",
					" The user=admin logged in to the server.",
					"jp.co.nec.aim.sm.web.action.PersonBiometricsAction",
					"100000" });

			jdbctemplate
					.update(insertsql,
							new Object[] {
									732593,
									999.00,
									dateTime,
									"044000301",
									" The user=admin key loaded to the system manager session.",
									"jp.co.nec.aim.sm.web.action.PersonBiometricsAction",
									"100000" });
			jdbctemplate.update(insertsql, new Object[] { 732645, 999.00,
					dateTime, "844000306",
					" Username LoginAction Unable to authorize user.",
					"jp.co.nec.aim.sm.web.action.PersonBiometricsAction",
					"400000" });
			timeDate = dateFormat.parse("2005-05-01");
			dateTime = new java.sql.Date(timeDate.getTime());
			jdbctemplate.update(insertsql, new Object[] { 732646, 999.00,
					dateTime, "044000300",
					" The user=admin logged in to the server.",
					"jp.co.nec.aim.sm.web.action.PersonBiometricsAction",
					"100000" });
			jdbctemplate
					.update(insertsql,
							new Object[] {
									732647,
									999.00,
									dateTime,
									"044000301",
									" The user=admin key loaded to the system manager session.",
									"jp.co.nec.aim.sm.web.action.PersonBiometricsAction",
									"100000" });
			jdbctemplate.update(insertsql, new Object[] { 36629550, 361.00,
					new Date(), "844000303", "Test Message.",
					"jp.co.nec.aim.sm.web.test", "400000" });
			jdbctemplate.update(insertsql, new Object[] { 36629551, 362.00,
					new Date(), "044000300", "Test Message.",
					"jp.co.nec.aim.sm.web.test", "100000" });
			jdbctemplate.update(insertsql, new Object[] { 36629552, 363.00,
					new Date(), "044000300", "Test Message.",
					"jp.co.nec.aim.sm.web.test", "100000" });
			jdbctemplate.update(insertsql, new Object[] { 36629553, 364.00,
					new Date(), "044000300", "Test Message.",
					"jp.co.nec.aim.sm.web.test", "100000" });
			jdbctemplate.update(insertsql, new Object[] { 36629554, 365.00,
					new Date(), "144114000", "Test Message.",
					"jp.co.nec.aim.sm.web.test", "200000" });
			jdbctemplate.update(insertsql, new Object[] { 36629555, 366.00,
					new Date(), "044000300", "Test Message.",
					"jp.co.nec.aim.sm.web.test", "100000" });
			jdbctemplate.update(insertsql, new Object[] { 36629556, 367.00,
					new Date(), "040000000", "Test Message.",
					"jp.co.nec.aim.sm.web.test", "110000" });
		} catch (ParseException e) {
			e.printStackTrace();
		}// util类型

	}

	public static void prepareEVENT_CATEGORY(JdbcTemplate jdbctemplate) {
		insertsql = "insert into \"EVENT_CATEGORY\" ( "
				+ " \"MESSAGE_TYPE_ID\"," + "  \"CATEGORY1\"  ) values (?,?)";
		jdbctemplate.update(insertsql, new Object[] { 100000, "100000" });
		jdbctemplate.update(insertsql, new Object[] { 110000, "110000" });
		jdbctemplate.update(insertsql, new Object[] { 200000, "200000" });
		jdbctemplate.update(insertsql, new Object[] { 400000, "400000" });
	}

	public static void DeleteOracleData(JdbcTemplate jdbctemplate) {

		insertsql = "delete from MATCH_MANAGERS";
		jdbctemplate.update(insertsql);
		insertsql = "delete from FE_JOB_QUEUE";
		jdbctemplate.update(insertsql);
		insertsql = "delete from FE_JOB_PAYLOADS";
		jdbctemplate.update(insertsql);
		insertsql = "delete from FE_LOT_JOBS";
		jdbctemplate.update(insertsql);
		insertsql = "delete from SYSTEM_CONFIG";
		jdbctemplate.update(insertsql);
		insertsql = "delete from SYSTEM_INIT";
		jdbctemplate.update(insertsql);
		insertsql = "delete from CONTAINER_JOBS";
		jdbctemplate.update(insertsql);
		insertsql = "delete from fusion_jobs";
		jdbctemplate.update(insertsql);
		insertsql = "delete from job_queue";
		jdbctemplate.update(insertsql);
		insertsql = "delete from MATCH_UNITS";
		jdbctemplate.update(insertsql);
		insertsql = "delete from SEGMENTS";
		jdbctemplate.update(insertsql);
		insertsql = "delete from PERSON_BIOMETRICS";
		jdbctemplate.update(insertsql);
		insertsql = "delete from CONTAINER_JOB_FAILURE_REASONS";
		jdbctemplate.update(insertsql);
		insertsql = "delete from MU_SEG_REPORTS";
		jdbctemplate.update(insertsql);
		insertsql = "delete from MAP_REDUCERS";
		jdbctemplate.update(insertsql);
		insertsql = "delete from DATA_MANAGERS";
		jdbctemplate.update(insertsql);
		jdbctemplate.execute("commit");
	}

	public static void DeletePostgreData(JdbcTemplate jdbctemplate) {
		insertsql = "delete from \"EVENT_LOG\"";
		jdbctemplate.update(insertsql);
		insertsql = "delete from \"EVENT_CATEGORY\"";
		jdbctemplate.update(insertsql);
		jdbctemplate.execute("commit");
	}

	public static void Log() {
		System.out.println(insertsql);
	}

	public static String covert(String password) {
		byte passwordRaw[] = DigestUtils.sha512(password);
		String hash = new String((new Base64()).encode(passwordRaw));
		return hash;
	}
}
