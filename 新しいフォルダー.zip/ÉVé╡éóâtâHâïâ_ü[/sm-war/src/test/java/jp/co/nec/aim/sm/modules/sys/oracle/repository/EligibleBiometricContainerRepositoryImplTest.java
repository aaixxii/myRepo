package jp.co.nec.aim.sm.modules.sys.oracle.repository;

import static org.junit.Assert.assertEquals;

import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.MuEligibleContainerEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.MuEligibleContainerEntityPK;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.EligibleBinsPojo;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional(value = "oracleTXManager")
public class EligibleBiometricContainerRepositoryImplTest {
	@Autowired
	EligibleBiometricContainerRepository repository;

	@Autowired
	@Qualifier("oracleDataSource")
	DataSource datasource;

	JdbcTemplate jdbcTemplate;

	String[] formatName = new String[] { "RDBT", "RDBL", "LDB", "PBLNF" };

	@Before
	public void before() {
		jdbcTemplate = new JdbcTemplate(datasource);
		cleanDB();
		prepareDB();
	}

	@After
	public void after() {
		cleanDB();
	}

	private void cleanDB() {
		jdbcTemplate.execute("delete from PERSON_BIOMETRICS");
		jdbcTemplate.execute("delete from JOB_QUEUE");
		jdbcTemplate.execute("delete from FE_LOT_JOBS");
		jdbcTemplate.execute("delete from MATCH_UNITS");
		jdbcTemplate.execute("delete from MU_ELIGIBLE_CONTAINERS");
		jdbcTemplate.execute("commit");
	}

	private void prepareDB() {
		for (int i = 1; i <= 4; i++) {
			String sql = "insert into MATCH_UNITS(MU_ID, UNIQUE_ID, STATE,"
					+ "  VERSION) values(" + i + ", 'unique_" + i
					+ "', 'WORKING',  0)";
			jdbcTemplate.execute(sql);
		}
		for (int i = 1; i <= 4; i++) {
			String sql = "insert into MU_ELIGIBLE_CONTAINERS(MU_ID, CONTAINER_ID"
					+ ") values(" + i + ", " + i + ")";
			jdbcTemplate.execute(sql);
		}
	}

	@Test
	public void testFindEligibleBinsPage() {
		Page<MuEligibleContainerEntity> page = new Page<MuEligibleContainerEntity>(
				1, 10);
		MuEligibleContainerEntity entity = new MuEligibleContainerEntity();
		MuEligibleContainerEntityPK id = new MuEligibleContainerEntityPK();
		id.setContainerId(1);
		id.setMuId(1l);
		entity.setId(id);
		Page<MuEligibleContainerEntity> pageResult = repository
				.findEligibleBinsPage(page, entity);

		assertEquals(1, pageResult.getList().size());
	}

	@Test
	public void testFindEligibleBinsPage_2() {
		Page<EligibleBinsPojo> page = new Page<EligibleBinsPojo>(1, 10);
		EligibleBinsPojo entity = new EligibleBinsPojo();
		entity.setBinId(1l);
		entity.setMatchUnitId(1l);
		Page<EligibleBinsPojo> pageResult = repository.findEligibleBinsPage(
				page, entity);

		assertEquals(1, pageResult.getList().size());
	}

	@Test
	public void testFindEligibleBins() {
		MuEligibleContainerEntity entity = new MuEligibleContainerEntity();
		MuEligibleContainerEntityPK id = new MuEligibleContainerEntityPK();
		id.setContainerId(1l);
		id.setMuId(1l);
		entity.setId(id);
		List<MuEligibleContainerEntity> list = repository
				.findEligibleBins(entity);

		assertEquals(1, list.size());
	}

	@Test
	public void testFindEligibleBins_2() {
		EligibleBinsPojo entity = new EligibleBinsPojo();
		entity.setBinId(1l);
		entity.setMatchUnitId(1l);
		List<EligibleBinsPojo> list = repository.findEligibleBins(entity);

		assertEquals(1, list.size());
	}

	@Test
	public void testAssignBin() {
		repository.assignBin(1l, "2");

		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from MU_ELIGIBLE_CONTAINERS where MU_ID = 1");
		assertEquals(2, list.size());
	}

	@Test
	public void testAssignBin_All() {
		repository.assignBin(1l, "");

		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from MU_ELIGIBLE_CONTAINERS where MU_ID = 1");
		assertEquals(19, list.size());
	}

	@Test
	public void testUnAssignBin() {
		String sql = "insert into MU_ELIGIBLE_CONTAINERS(MU_ID, CONTAINER_ID) values(1, 2)";
		jdbcTemplate.execute(sql);

		repository.unAssignBin(1l, "1");

		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select CONTAINER_ID from MU_ELIGIBLE_CONTAINERS where MU_ID = 1");
		assertEquals(1, list.size());
		assertEquals("2", list.get(0).get("CONTAINER_ID").toString());
	}

	@Test
	public void testUnAssignBin_All() {
		repository.unAssignBin(1l, "");

		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from MU_ELIGIBLE_CONTAINERS where MU_ID = 1");
		assertEquals(0, list.size());
	}
}
