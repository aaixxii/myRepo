//package jp.co.nec.aim.sm.common.utils;
//
//import static org.junit.Assert.assertEquals;
//import static org.junit.Assert.assertNull;
//import static org.junit.Assert.assertTrue;
//import static org.junit.Assert.fail;
//
//import java.lang.reflect.Field;
//import java.lang.reflect.InvocationTargetException;
//import java.lang.reflect.Method;
//import java.util.ArrayList;
//
//import jp.co.nec.aim.sm.modules.sys.oracle.entity.MuSegReportEntityPK;
//import jp.co.nec.aim.sm.modules.sys.oracle.entity.MuSegReportEntity;
//import jp.co.nec.aim.sm.modules.sys.postgres.pojo.mapping.EventLogPojo;
//
//import org.junit.Test;
//
//public class ReflectionsTest {
//
//	@Test
//	public void testInvokeGetter() {
//		EventLogPojo event = new EventLogPojo("Test", 10);
//		String value = (String) Reflections.invokeGetter(event, "messageType");
//		assertEquals("Test", value);
//	}
//
//	@Test
//	public void testInvokeSetter_1() {
//		EventLogPojo event = new EventLogPojo("Test", 10);
//		Reflections.invokeSetter(event, "messageType", "set");
//		assertEquals("set", event.getMessageType());
//	}
//
//	@Test
//	public void testInvokeSetter() {
//		MuSegReportEntity entity = new MuSegReportEntity();
//		entity.setId(new MuSegReportEntityPK());
//		Reflections.invokeSetter(entity, "Id.matchUnitId", new Long(10));
//		assertEquals(10, entity.getId().getMatchUnitId().longValue());
//	}
//
//	@Test
//	public void testGetFieldValue() {
//		EventLogPojo event = new EventLogPojo("Test", 10);
//		String value = (String) Reflections.getFieldValue(event, "messageType");
//		assertEquals("Test", value);
//	}
//
//	@Test
//	public void testSetFieldValue() {
//		EventLogPojo event = new EventLogPojo("Test", 10);
//		Reflections.setFieldValue(event, "messageType", "Set");
//		assertEquals("Set", event.getMessageType());
//	}
//
//	@Test
//	public void testInvokeMethod() {
//		EventLogPojo event = new EventLogPojo("Test", 10);
//		String value = (String) Reflections.invokeMethod(event,
//				"getMessageType", new Class[] {}, new Object[] {});
//		assertEquals("Test", value);
//	}
//
//	@Test
//	public void testInvokeMethodByName() {
//		EventLogPojo event = new EventLogPojo("Test", 10);
//		String value = (String) Reflections.invokeMethodByName(event,
//				"getMessageType", new Object[] {});
//		assertEquals("Test", value);
//	}
//
//	@Test
//	public void testGetAccessibleField() {
//		EventLogPojo event = new EventLogPojo("Test", 10);
//		Field field = Reflections.getAccessibleField(event, "messageType");
//		try {
//			String value = (String) field.get(event);
//			assertEquals("Test", value);
//		} catch (Exception e) {
//			fail();
//		}
//	}
//
//	@Test
//	public void testGetAccessibleMethod() {
//		EventLogPojo event = new EventLogPojo("Test", 10);
//		Method method = Reflections.getAccessibleMethod(event,
//				"getMessageType", new Class[] {});
//		String value = method.getName();
//		assertEquals("getMessageType", value);
//	}
//
//	@Test
//	public void testGetAccessibleMethod_2() {
//		EventLogPojo event = new EventLogPojo("Test", 10);
//		Method method = Reflections.getAccessibleMethod(event, "getMessa",
//				new Class[] {});
//		assertNull(method);
//	}
//
//	@Test
//	public void testGetAccessibleMethodByName() {
//		EventLogPojo event = new EventLogPojo("Test", 10);
//		Method method = Reflections.getAccessibleMethodByName(event,
//				"getMessageType");
//		String value = method.getName();
//		assertEquals("getMessageType", value);
//	}
//
//	@Test
//	public void testGetAccessibleMethodByName_2() {
//		EventLogPojo event = new EventLogPojo("Test", 10);
//		Method method = Reflections
//				.getAccessibleMethodByName(event, "getMessa");
//		assertNull(method);
//	}
//
//	@Test
//	public void testMakeAccessible_Method() {
//		RefTestClass testClass = new RefTestClass();
//		Method[] methods = testClass.getClass().getDeclaredMethods();
//		Method method = null;
//		for (Method m : methods) {
//			if (m.getName().equals("setStr")) {
//				method = m;
//				break;
//			}
//		}
//		assertTrue(!method.isAccessible());
//
//		Reflections.makeAccessible(method);
//
//		assertTrue(method.isAccessible());
//	}
//
//	@Test
//	public void testMakeAccessible_Field() {
//		EventLogPojo event = new EventLogPojo("Test", 10);
//		Field field = null;
//		try {
//			field = event.getClass().getDeclaredField("messageType");
//		} catch (Exception e) {
//			fail();
//		}
//
//		assertTrue(!field.isAccessible());
//
//		Reflections.makeAccessible(field);
//
//		assertTrue(field.isAccessible());
//	}
//
//	@Test
//	public void testGetClassGenricType() {
//		Class<RefTestClass> cls = Reflections
//				.getClassGenricType(RefTestClass.class);
//
//		assertEquals("Object", cls.getSimpleName());
//	}
//
//	@SuppressWarnings("unchecked")
//	@Test
//	public void testGetClassGenricType_index_1() {
//		ArrayList<RefTestClass> testClass = new ArrayList<RefTestClass>();
//		Class cls = Reflections.getClassGenricType(testClass.getClass(), 0);
//
//		assertEquals("Object", cls.getSimpleName());
//	}
//
//	@SuppressWarnings("unchecked")
//	@Test
//	public void testGetClassGenricType_index_2() {
//		ArrayList<RefTestClass> testClass = new ArrayList<RefTestClass>();
//		Class cls = Reflections.getClassGenricType(testClass.getClass(), 1);
//
//		assertEquals("Object", cls.getSimpleName());
//	}
//
//	@SuppressWarnings("unchecked")
//	@Test
//	public void testGetUserClass_1() {
//		Class cls = Reflections.getUserClass(getClass());
//		assertEquals("Class", cls.getSimpleName());
//	}
//
//	@Test
//	public void testConvertReflectionExceptionToUnchecked() {
//		NoSuchMethodException inExp1 = new NoSuchMethodException(
//				"NoSuchMethodException");
//		RuntimeException exp = Reflections
//				.convertReflectionExceptionToUnchecked(inExp1);
//		assertEquals("java.lang.NoSuchMethodException: NoSuchMethodException",
//				exp.getMessage());
//
//		InvocationTargetException inExp2 = new InvocationTargetException(inExp1);
//		exp = Reflections.convertReflectionExceptionToUnchecked(inExp2);
//		assertEquals("java.lang.NoSuchMethodException: NoSuchMethodException",
//				exp.getMessage());
//
//		RuntimeException inExp3 = new RuntimeException("RuntimeException");
//		exp = Reflections.convertReflectionExceptionToUnchecked(inExp3);
//		assertEquals("RuntimeException", exp.getMessage());
//
//		Exception inExp4 = new Exception("RuntimeException");
//		exp = Reflections.convertReflectionExceptionToUnchecked(inExp4);
//		assertEquals("Unexpected Checked Exception.", exp.getMessage());
//	}
//
//}
//
//class RefTestClass {
//	public String str;
//
//	private void setStr(String str) {
//		this.str = str;
//	}
//
//	public void set(String str) {
//		setStr(str);
//	}
// }
