package jp.co.nec.aim.sm.modules.sys.oracle.repository;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.FunctionTypeEntity;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional(value = "oracleTXManager")
public class FunctionTypeRepositoryImplTest {
	@Autowired
	FunctionTypeRepository repository;

	@Autowired
	@Qualifier("oracleDataSource")
	DataSource datasource;

	JdbcTemplate jdbcTemplate;

	String[] functionName = new String[] { "TI", "LI", "TLI", "LLI" };

	@Before
	public void before() {
		jdbcTemplate = new JdbcTemplate(datasource);
		cleanDB();
		// prepareDB();
	}

	@After
	public void after() {
		cleanDB();
	}

	private void cleanDB() {
		jdbcTemplate.execute("delete from FE_JOB_QUEUE");
		jdbcTemplate.execute("delete from JOB_QUEUE");
		jdbcTemplate.execute("commit");
		// jdbcTemplate.execute("delete from FUNCTION_TYPES");
	}

	//
	// private void prepareDB() {
	// for (int i = 1; i <= 4; i++) {
	// String sql = "insert into FUNCTION_TYPES(FUNCTION_ID,"
	// + " FUNCTION_NAME, QUEUE_TYPE) values(" + i + ", '"
	// + functionName[i - 1] + "', " + i + ")";
	// jdbcTemplate.execute(sql);
	// }
	// }

	@Test
	public void testFindFunctionTypePage() {
		Page<FunctionTypeEntity> page = new Page<FunctionTypeEntity>(1, 10);
		FunctionTypeEntity entity = new FunctionTypeEntity();

		entity.setId(1);
		entity.setFunctionName(functionName[0]);
		Page<FunctionTypeEntity> pageResult = repository.findFunctionTypePage(
				page, entity);

		assertEquals(1, pageResult.getList().size());
	}

	@Test
	public void testFindFunctionType() {
		FunctionTypeEntity entity = new FunctionTypeEntity();
		entity.setId(1);
		entity.setFunctionName(functionName[0]);
		List<FunctionTypeEntity> list = repository.findFunctionType(entity);

		assertEquals(1, list.size());
	}

	@Test
	public void testGetAllFunctionType() {
		List<String> list = repository.getAllFunctionType();

		assertEquals(20, list.size());
	}

	@Test
	public void testGetFunctionId() {
		Integer result = repository.getFunctionId(functionName[0]);

		assertEquals(1, result.intValue());

		result = repository.getFunctionId("Test");

		assertNull(result);
	}

	@Test
	public void testUpdateFunctionType() {
		Integer result = repository.updateFunctionType(1, 3, null, 5l, 10l);

		assertEquals(1, result.intValue());

		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from FUNCTION_TYPES where FUNCTION_ID = 1");
		assertEquals(1, list.size());
		// assertEquals("3", list.get(0).get("JOB_LIMIT").toString());
		assertEquals(-1, ((BigDecimal) list.get(0)
				.get("TOP_LEVEL_JOB_TIMEOUTS")).intValue());
		assertEquals("5", list.get(0).get("CONTAINER_JOB_TIMEOUTS").toString());
		assertEquals("10", list.get(0).get("INTERNAL_CANDIDATE_SIZE")
				.toString());
	}
}
