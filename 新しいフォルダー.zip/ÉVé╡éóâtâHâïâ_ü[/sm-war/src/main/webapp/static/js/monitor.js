/* monitor js */
var alarmTimeBefore;
var scopeId;
var browser;
var mustBlink = false;
var compoentNames = ["MM", "MR", "DM", "MU"];
var labelWorking = "working";
var labelTimeout = "timeout";
var labelExited = "exit";

var MU_EXTRACT_LOAD_Type = "Extract";
var MU_INQUIRY_LOAD_Type = "Inquiry";

var workingColor = "#2e8b57";
var timeOutColor = "yellow";
var exitedColor = "gray";

var TI_StrokeColor = "#FF0000";
var TLI_StrokeColor = "#F08080";
var TLIP_StrokeColor = "#FF7F50";
var FI_StrokeColor = "#A0522D";
var II_StrokeColor = "#FFA500";
var EXTRACT_StrokeColor = "#FF0000";

var TI_PointColor = "#008000";
var TLI_PointColor = "#00FF7F";
var TLIP_PointColor = "#40E0D0";
var FI_PointColor = "#7B68EE";
var II_PointColor = " #DDA0DD ";
var muLoad_PointColor = "#1E90FE";
var EXTRACT_PointColor = "#A52A2A";

var LLIP_StrokeColor = "#FF0000";
var LI_StrokeColor = "#F08080";
var LLI_StrokeColor = "#FF7F50";
var LIP_StrokeColor = "#A0522D";

var LLIP_PointColor = "#FFD700";
var LI_PointColor = "#00FFFF";
var LLI_PointColor = "#1E90FF";
var FI_PointColor = "#7B68EE";
var LIP_PointColor = "#8B0000 ";

var TENPRINT_RDBT_ChartFillColor = TI_PointColor;
var TENPRINT_SDBT_ChartFillColor = TI_PointColor;
var TENPRINT_RDBTM_ChartFillColor = TI_PointColor;
var TENPRINT_SDBTM_ChartFillColor = TI_PointColor;

var TENPRINT_LDB_ChartFillColor = TLI_PointColor;
var TENPRINT_LDBS_ChartFillColor = TLI_PointColor;
var TENPRINT_LDBM_ChartFillColor = TLI_PointColor;
var TENPRINT_LDBX_ChartFillColor = TLI_PointColor;

var TENPRINT_PLDB_ChartFillColor = TLIP_PointColor;

var TENPRINT_FDB_ChartFillColor = FI_PointColor;
var TENPRINT_IDB_ChartFillColor = II_PointColor;

var LATENT_RDBL_ChartFillColor = LI_PointColor;
var LATENT_SDBL_ChartFillColor = LI_PointColor;
var LATENT_RDBLS_ChartFillColor = LI_PointColor;
var LATENT_SDBLS_ChartFillColor = LI_PointColor;
var LATENT_RDBLM_ChartFillColor = LI_PointColor;
var LATENT_SDBLM_ChartFillColor = LI_PointColor;
var LATENT_XDBL_ChartFillColor = LI_PointColor;

var LATENT_LDB_ChartFillColor = LLI_PointColor;
var LATENT_LDBS_ChartFillColor = LLI_PointColor;
var LATENT_LDBM_ChartFillColor = LLI_PointColor;
var LATENT_LDBX_ChartFillColor = LLI_PointColor;

var LATENT_PDB_ChartFillColor = LIP_PointColor;
var LATENT_PLDB_ChartFillColor = LLIP_PointColor;

var FDB_ChartFillColor = "#FF0000";
var IDB_ChartFillColor = "#FFE4B5";
var LDB_ChartFillColor = "#FFD700";
var LDBM_ChartFillColor = "#9ACD32";
var LDBS_ChartFillColor = "#6B8E23";
var LDBX_ChartFillColor = "#008000";
var PDB_ChartFillColor = "#7FFF00";
var PLDB_ChartFillColor = "#BCE2E8";
var RDBL_ChartFillColor = "#32CD32";
var RDBLM_ChartFillColor = "#FFB6C1";
var RDBLS_ChartFillColor = "#DC143C";
var RDBT_ChartFillColor = "#FF69B4";
var RDBTM_ChartFillColor = "#DA70D6";
var SDBL_ChartFillColor = "#9932CC";
var RDBTM_ChartFillColor = "#F8F8FF";
var SDBLM_ChartFillColor = "#00008B";
var SDBLS_ChartFillColor = "#B0C4DE";
var SDBT_ChartFillColor = "##0000FF";
var SDBTM_ChartFillColor = "#8B0000";
var XDBL_ChartFillColor = "#7B68EE";

var Print_BarChartStokeColor = "#B0C4DE";
var Latent_BarChartStokeColor = "#7B68EE";

var muInquiryLoad_StrokeColor = "#1E90FF";
var muInquiryLoad_FillColor = "#87CEEB";

var muExtractLoad_StrokeColor = "#8B4513";
var muExtractLoad_FillColor = "#FFA500";

var mmCanvasId = "mmChart";
var mrCanvasId = "mrChart";
var dmCanvasId = "dmChart";
var muCanvasId = "muChart";

var tenprintMonitorCanvasId = "ten_print_bar";
var latentMonitorCanvasId = "latent_bar";
var tenprintFunctionCanvasId = "ten_print_line";
var latentFunctionCanvasId = "latent_print_line";
var extractCanvasId = "extract_line";
var muLoadCanvusId = "mu_load_bar";

var muInquiryloadBarChart;
var muExtractloadBarChart;
var tenprintLineChart;
var latentLineChart;
var extractlineChart;
var tenprintBatChart;
var latentBarChart;

var lineChartOptions = {
    pointDot: false,
    bezierCurve: false,
    datasetFill: false,
    animation: false,
    scaleFontStyle: "bold",
    scaleFontColor: "white",
    multiTooltipTemplate: "<%= datasetLabel %> - <%= value %>",
    legendTemplate: "<% for (var i=0; i<datasets.length; i++){%><span style=\"color:<%=datasets[i].strokeColor%>\">■</span><%if(datasets[i].label){%><%=datasets[i].label%><%}%><%}%>"
};

var pieChartOptions = {
    multiTooltipTemplate: "<%= datasetLabel %> - <%= value %>",
    legendTemplate: "<% for (var i=0; i<segments.length; i++){%><span style=\"color:<%=segments[i].fillColor%>\">■</span><%if(segments[i].label){%><%=segments[i].label%><%}%><%}%>"
};

var barChartOptions = {
    scaleFontStyle: "bold",
    scaleFontColor: "white",
    animation: false,
    multiTooltipTemplate: "<%= datasetLabel %> - <%= value %>",
    legendTemplate: "<% for (var i=0; i<datasets.length; i++){%><span style=\"color:<%=datasets[i].fillColor%>\">■</span><%if(datasets[i].label){%><%=datasets[i].label%><%}%><%}%>"

};


function lineChartColor(strokeColor, pointColor) {
    this.strokeColor = strokeColor;
    this.pointColor = pointColor;
}

function getChartInstance(name) {
    switch (name) {
    case "tenprintFunction":
        return tenprintLineChart;
        break;
    case "latentFunction":
        return latentLineChart;
        break;
    case "extract":
        return extractlineChart;
        break;

    case "tenprintMonitor":
        return tenprintBatChart;
        break;

    case "latentMonitor":
        return latentBarChart;
        break;
    }
}

function getCanvasId(name) {
    switch (name) {
    case "mm":
        return mmCanvasId;
        break;
    case "mr":
        return mrCanvasId;
        break;
    case "dm":
        return dmCanvasId;
        break;
    case "mu":
        return muCanvasId;
        break;
    case "tenprintMonitor":
        return tenprintMonitorCanvasId;
        break;
    case "latentMonitor":
        return latentMonitorCanvasId;
        break;
    case "tenprintFunction":
        return tenprintFunctionCanvasId;
        break;
    case "latentFunction":
        return latentFunctionCanvasId;
        break;
    case "extract":
        return extractCanvasId;
        break;
    case "muload":
        return muloadCanvasId;
        break;
    }
}

function getLineColor(name) {
    switch (name.toUpperCase()) {
    case "TI":
        return new lineChartColor(TI_StrokeColor, TI_PointColor);
        break;
    case "TLI":
        return new lineChartColor(TLI_StrokeColor, TLI_PointColor);
        break;
    case "II":
        return new lineChartColor(II_StrokeColor, II_PointColor);
        break;
    case "TLIP":
        return new lineChartColor(TLIP_StrokeColor, TLIP_PointColor);
        break;
    case "FI":
        return new lineChartColor(FI_StrokeColor, FI_PointColor);
        break;
    case "LI":
        return new lineChartColor(LI_StrokeColor, LI_PointColor);
        break;

    case "LLIP":
        return new lineChartColor(LLIP_StrokeColor, LLIP_PointColor);
        break;
    case "LLI":
        return new lineChartColor(LLI_StrokeColor, LLI_PointColor);
        break;
    case "LIP":
        return new lineChartColor(LIP_StrokeColor, LIP_PointColor);
        break;
    case "EXTRACT":
        return new lineChartColor(EXTRACT_StrokeColor, EXTRACT_PointColor);
        break;
    }
}

function getPieColor(name) {
    switch (name.toUpperCase()) {
    case "WORKING":
        return workingColor;
        break;
    case "TIME_OUT":
        return timeOutColor;
        break;
    case "EXITED":
        return exitedColor;
        break;
    }
}

function getBarChartFillColor(name) {
    switch (name.toUpperCase()) {
    case "FDB":
        return FDB_ChartFillColor;
        break;
    case "IDB":
        return IDB_ChartFillColor;
        break;
    case " LDB":
        return LDB_ChartFillColor;
        break;
    case " LDBM":
        return LDBM_ChartFillColor;
        break;

    case "LDBS":
        return LDBS_ChartFillColor;
        break;
    case " LDBX":
        return LDBX_ChartFillColor;
        break;
    case "PDB":
        return PDB_ChartFillColor;
        break;

    case "PLDB":
        return PLDB_ChartFillColor;
        break;
    case "RDBL":
        return RDBL_ChartFillColor;
        break;
    case "RDBLM":
        return RDBLM_ChartFillColor;
        break;
    case "RDBLS":
        return RDBLS_ChartFillColor;
        break;
    case "RDBT":
        return RDBT_ChartFillColor;
        break;
    case "RDBTM":
        return RDBTM_ChartFillColor;
        break;
    case "SDBL":
        return SDBL_ChartFillColor;
        break;
    case "RDBTM":
        return RDBTM_ChartFillColor;
        break;
    case "SDBLM":
        return SDBLM_ChartFillColor;
        break;
    case "SDBLS":
        return SDBLS_ChartFillColor;
        break;
    case "SDBT":
        return SDBT_ChartFillColor;
        break;
    case "SDBTM":
        return SDBTM_ChartFillColor;
        break;
    case "XDBL":
        return XDBL_ChartFillColor;
        break;
    }
}

function getBarStokeColor(name) {
    switch (name) {
    case "tenprintMonitor":
        return Print_BarChartStokeColor;
        break;
    case "latentMonitor":
        return Latent_BarChartStokeColor;
        break;
    }
}

var mmPieChart;
var mrPieChart;
var dmPieChart;
var mrPieChart;

var pieDatas = {
    "mm": [{
        "value": 0,
        "color": "#2e8b57",
        "label": "working"
    },
    {
        "value": 0,
        "color": "yellow",
        "label": "timeout"
    },
    {
        "value": 1,
        "color": "gray",
        "label": "exit"
    }],
    "mr": [{
        "value": 0,
        "color": "#2e8b57",
        "label": "working"
    },
    {
        "value": 0,
        "color": "yellow",
        "label": "timeout"
    },
    {
        "value": 1,
        "color": "gray",
        "label": "exit"
    }],
    "dm": [{
        "value": 0,
        "color": "#2e8b57",
        "label": "working"
    },
    {
        "value": 0,
        "color": "yellow",
        "label": "timeout"
    },
    {
        "value": 1,
        "color": "gray",
        "label": "exit"
    }],
    "mu": [{
        "value": 0,
        "color": "#2e8b57",
        "label": "working"
    },
    {
        "value": 0,
        "color": "yellow",
        "label": "timeout"
    },
    {
        "value": 1,
        "color": "gray",
        "label": "exit"
    }]
};

function doUpdadeOnePie(pieChartInstance, newData) {}

function updatePieCharts(pieJsonString) {
    var pieJsonData = pieJsonString;
    for (var unitType in pieJsonData) {
        switch (unitType) {
        case "mm":
            var tmp = pieJsonData[unitType];
            mmPieChart.segments[0].value = (tmp.WORKING == undefined ? 0 : tmp.WORKING);
            mmPieChart.segments[1].value = (tmp.TIMED_OUT == undefined ? 0 : tmp.TIMED_OUT);
            mmPieChart.segments[2].value = (tmp.EXITED == undefined ? 0 : tmp.EXITED);
            mmPieChart.update();
            var canvasId = "mmChart";
            doAfterPieChartChanged(canvasId, tmp);
            break;
        case "mr":
            var tmp = pieJsonData[unitType];
            mrPieChart.segments[0].value = (tmp.WORKING == undefined ? 0 : tmp.WORKING);
            mrPieChart.segments[1].value = (tmp.TIMED_OUT == undefined ? 0 : tmp.TIMED_OUT);
            mrPieChart.segments[2].value = (tmp.EXITED == undefined ? 0 : tmp.EXITED);
            mrPieChart.update();
            var canvasId = "mrChart";
            doAfterPieChartChanged(canvasId, tmp);
            break;
        case "dm":
            var tmp = pieJsonData[unitType];
            dmPieChart.segments[0].value = (tmp.WORKING == undefined ? 0 : tmp.WORKING);
            dmPieChart.segments[1].value = (tmp.TIMED_OUT == undefined ? 0 : tmp.TIMED_OUT);
            dmPieChart.segments[2].value = (tmp.EXITED == undefined ? 0 : tmp.EXITED);
            dmPieChart.update();
            var canvasId = "dmChart";
            doAfterPieChartChanged(canvasId, tmp);
            break;
        case "mu":
            var tmp = pieJsonData[unitType];
            muPieChart.segments[0].value = (tmp.WORKING == undefined ? 0 : tmp.WORKING);
            muPieChart.segments[1].value = (tmp.TIMED_OUT == undefined ? 0 : tmp.TIMED_OUT);
            muPieChart.segments[2].value = (tmp.EXITED == undefined ? 0 : tmp.EXITED);
            muPieChart.update();
            var canvasId = "muChart";
            doAfterPieChartChanged(canvasId, tmp);
            break;
        }
    }
}

function doAfterPieChartChanged(canvasId, pieJsonDataO) {
    var pieList = document.getElementsByClassName("pie");
    pieJsonDataO.WORKING = (pieJsonDataO.WORKING == undefined ? 0 : pieJsonDataO.WORKING);
    pieJsonDataO.TIMED_OUT = (pieJsonDataO.TIMED_OUT == undefined ? 0 : pieJsonDataO.TIMED_OUT);
    pieJsonDataO.EXITED = (pieJsonDataO.EXITED == undefined ? 0 : pieJsonDataO.EXITED);

    var notWorking = pieJsonDataO.TIMED_OUT + pieJsonDataO.EXITED;
    var spanMO = document.getElementById(canvasId).previousSibling.parentNode.getElementsByTagName('span')[0];
    spanMO.innerHTML = notWorking;

    var all = pieJsonDataO.WORKING + pieJsonDataO.TIMED_OUT + pieJsonDataO.EXITED;
    if (all == 0) {
        pieJsonDataO.EXITED = 1;
        percent = "-";
    } else {
        percent = Math.round(pieJsonDataO.WORKING / (all) * 100);
    }

    switch (canvasId) {
    case "mmChart":
        pieList[0].getElementsByClassName("percent")[0].innerHTML = percent.toString() + "%";
        pieList[0].getElementsByClassName("percent")[0].style.fontWeight = "bold";

        var circle = pieList[0].getElementsByClassName("circle")[0];
        if (notWorking > 0) {
            circle.style.visibility = "visible"
        } else {
            circle.style.visibility = "hidden";
        }
        break;
    case "mrChart":
        pieList[2].getElementsByClassName("percent")[0].innerHTML = percent.toString() + "%";
        pieList[2].getElementsByClassName("percent")[0].style.fontWeight = "bold";
        var circle = pieList[2].getElementsByClassName("circle")[0];
        if (notWorking > 0) {
            circle.style.visibility = "visible"
        } else {
            circle.style.visibility = "hidden";
        }
        break;
    case "dmChart":
        pieList[1].getElementsByClassName("percent")[0].innerHTML = percent.toString() + "%";
        pieList[1].getElementsByClassName("percent")[0].style.fontWeight = "bold";
        var circle = pieList[1].getElementsByClassName("circle")[0];
        if (notWorking > 0) {
            circle.style.visibility = "visible"
        } else {
            circle.style.visibility = "hidden";
        }
        break;
    case "muChart":
        pieList[3].getElementsByClassName("percent")[0].innerHTML = percent.toString() + "%";
        pieList[3].getElementsByClassName("percent")[0].style.fontWeight = "bold";
        var circle = pieList[3].getElementsByClassName("circle")[0];
        if (notWorking > 0) {
            circle.style.visibility = "visible"
        } else {
            circle.style.visibility = "hidden";
        }
        break;
    }
}

var lineLabel = ["60", "--", "--", "--", "--", "--", "--", "--", "--", "--", "50", "--", "--", "--", "--", "--", "--", "--", "--", "--", "40", "--", "--", "--", "--", "--", "--", "--", "--", "--", "30", "--", "--", "--", "--", "--", "--", "--", "--", "--", "20", "--", "--", "--", "--", "--", "--", "--", "--", "--", "10", "--", "--", "--", "--", "--", "--", "--", "--", "--", "0"];
var lineData = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];

// var lineLabel = ["540","480","420", "360", "300", "240", "180", "120", "60",
// "0"];
// var lineData = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
var extactLineChartData = {
    labels: lineLabel,
    datasets: [{
        label: "EXTRACT",
        strokeColor: EXTRACT_PointColor,
        pointColor: EXTRACT_PointColor,
        data: lineData
    }]
};

var tenprintLineData = {
    labels: lineLabel,
    datasets: [{
        label: "TI",
        strokeColor: TI_PointColor,
        pointColor: TI_PointColor,

        data: lineData
    },
    {
        label: "TLI",
        pointColor: TLI_PointColor,
        strokeColor: TLI_PointColor,

        data: lineData
    },
    {
        label: "TLIP",
        pointColor: TLIP_PointColor,
        strokeColor: TLIP_PointColor,

        data: lineData
    },
    {
        label: "FI",
        pointColor: FI_PointColor,
        strokeColor: FI_PointColor,
        data: lineData
    },    
    {
        label: "II",
        pointColor: II_PointColor,
        strokeColor: II_PointColor,
        data: lineData
    }]
};

var latentLineData = {
    labels: lineLabel,
    datasets: [{
        label: "LI",
        strokeColor: LI_PointColor,
        pointColor: LI_PointColor,
        data: lineData
    },
    {
        label: "LLI",
        strokeColor: LLI_PointColor,
        pointColor: LLI_PointColor,
        data: lineData
    },
    {
        label: "LIP",
        strokeColor: LIP_PointColor,
        pointColor: LIP_PointColor,
        data: lineData
    },
    {
        label: "LLIP",
        strokeColor: LLIP_PointColor,
        pointColor: LLIP_PointColor,
        data: lineData
    }]
};

var tenprintFunction = ["TI", "TLI", "TLIP", "FI", "II"];
var latentFunction = ["LI", "LLI", "LIP", "LLIP"];
var extractFunction = ["EXTRACT"];
var functionTypes = ['tenprintFunction', 'latentFunction', 'extract'];

function addDefaultLineData(lineChartJsonStr) {
    if (!lineChartJsonStr.tenprintFunction) {
        lineChartJsonStr.tenprintFunction = {
            "TI": 0,
            "TLI": 0,           
            "TLIP": 0,
            "FI": 0,
            "II": 0
        };
    }

    if (!lineChartJsonStr.latentFunction) {
        lineChartJsonStr.latentFunction = {
            "LI": 0,
            "LLI": 0,
            "LIP": 0,
            "LLIP": 0
        };
    }

    if (!lineChartJsonStr.extract) {
        lineChartJsonStr.extract = {
            "EXTRACT": 0
        };
    }
    return lineChartJsonStr;
}

function updateLineCharts(lineChartJsonStr) {
    var lineJson = addDefaultLineData(lineChartJsonStr);
    for (var key in lineJson) {
        var chartInstance = getChartInstance(key);
        var length = chartInstance.datasets.length;
        var oneLineTypeData = lineJson[key];
        var dataArray;

        switch (key) {
        case "tenprintFunction":
            dataArray = new Array(tenprintFunction.length);
            for (i = 0; i < dataArray.length; i++) {
                dataArray[i] = 0;
            }
            for (i = 0; i < tenprintFunction.length; i++) {
                for (var oneType in oneLineTypeData) {
                    if (tenprintFunction[i] == oneType) {
                        dataArray[i] = oneLineTypeData[oneType];
                    }
                }
            }
            var ctx = document.getElementById("ten_print_line").getContext("2d");
            ctx.canvas.width = 400;
            ctx.canvas.height = 248;
            break;

        case "latentFunction":
            dataArray = new Array(latentFunction.length);
            for (i = 0; i < dataArray.length; i++) {
                dataArray[i] = 0;
            }
            for (i = 0; i < latentFunction.length; i++) {
                for (var oneType in oneLineTypeData) {
                    if (latentFunction[i] == oneType) {
                        dataArray[i] = oneLineTypeData[oneType];
                    }
                }
            }
            var ctx = document.getElementById("latent_print_line").getContext("2d");
            ctx.canvas.width = 400;
            ctx.canvas.height = 248;
            break;

        case "extract":
            dataArray = new Array(extractFunction.length);
            for (i = 0; i < dataArray.length; i++) {
                dataArray[i] = 0;
            }
            for (i = 0; i < extractFunction.length; i++) {
                for (var oneType in oneLineTypeData) {
                    if (extractFunction[i] == oneType) {
                        dataArray[i] = oneLineTypeData[oneType];
                    }
                }
            }
            var ctx = document.getElementById("extract_line").getContext("2d");
            ctx.canvas.width = 400;
            ctx.canvas.height = 248;
            break;
        }

        for (i = 0; i < length; i++) {
            var subLength = chartInstance.datasets[i].points.length;
            for (j = 0; j < subLength - 1; j++) {
                chartInstance.datasets[i].points[j].value = chartInstance.datasets[i].points[j + 1].value;
            }
            chartInstance.datasets[i].points[subLength - 1].value = dataArray[i];
        }
        chartInstance.update();
    }
}

var tenprintBarDbName = ["RDBT", "SDBT", "RDBTM", "SDBTM", "LDB", "LDBS", "LDBM", "LDBX", "PLDB", "FDB", "IDB"];

var latentBarDbName = ["RDBL", "SDBL", "RDBLS", "SDBLS", "RDBLM", "SDBLM", "XDBL", "LDB", "LDBS", "LDBM", "LDBX", "PDB", "PLDB"];

var barXAixs = ["0"];
var barData = [0];

var tenprintBarData = {
    labels: ["Tenprint"],
    datasets: [{
        label: "RDBT",
        fillColor: TENPRINT_RDBT_ChartFillColor,
        strokeColor: Print_BarChartStokeColor,
        data: barData
    },
    {
        label: "SDBT",
        fillColor: TENPRINT_SDBT_ChartFillColor,
        strokeColor: Print_BarChartStokeColor,
        data: barData
    },
    {
        label: "RDBTM",
        fillColor: TENPRINT_RDBTM_ChartFillColor,
        strokeColor: Print_BarChartStokeColor,
        data: barData
    },
    {
        label: "SDBTM",
        fillColor: TENPRINT_SDBTM_ChartFillColor,
        strokeColor: Print_BarChartStokeColor,
        data: barData
    },
    {
        label: "LDB",
        fillColor: TENPRINT_LDB_ChartFillColor,
        strokeColor: Print_BarChartStokeColor,
        data: barData
    },
    {
        label: "LDBS",
        fillColor: TENPRINT_LDBS_ChartFillColor,
        strokeColor: Print_BarChartStokeColor,
        data: barData
    },
    {
        label: "LDBM",
        fillColor: TENPRINT_LDBM_ChartFillColor,
        strokeColor: Print_BarChartStokeColor,
        data: barData
    },
    {
        label: "LDBX",
        fillColor: TENPRINT_LDBX_ChartFillColor,
        strokeColor: Print_BarChartStokeColor,
        data: barData
    },
    {
        label: "PLDB",
        fillColor: TENPRINT_PLDB_ChartFillColor,
        strokeColor: Print_BarChartStokeColor,
        data: barData
    },
    {
        label: "FDB",
        fillColor: TENPRINT_FDB_ChartFillColor,
        strokeColor: Print_BarChartStokeColor,
        data: barData
    },
    {
        label: "IDB",
        fillColor: TENPRINT_IDB_ChartFillColor,
        strokeColor: Print_BarChartStokeColor,
        data: barData
    }]
};

var latentBarData = {
    labels: ["Latent"],
    datasets: [{
        label: "RDBL",
        fillColor: LATENT_RDBL_ChartFillColor,
        strokeColor: Latent_BarChartStokeColor,
        data: barData
    },
    {
        label: "SDBL",
        fillColor: LATENT_SDBL_ChartFillColor,
        strokeColor: Latent_BarChartStokeColor,
        data: barData
    },
    {
        label: "RDBLS",
        fillColor: LATENT_RDBLS_ChartFillColor,
        strokeColor: Latent_BarChartStokeColor,
        data: barData
    },
    {
        label: "SDBLS",
        fillColor: LATENT_SDBLS_ChartFillColor,
        strokeColor: Latent_BarChartStokeColor,
        data: barData
    },
    {
        label: "RDBLM",
        fillColor: LATENT_RDBLM_ChartFillColor,
        strokeColor: Latent_BarChartStokeColor,
        data: barData
    },
    {
        label: "SDBLM",
        fillColor: LATENT_SDBLM_ChartFillColor,
        strokeColor: Latent_BarChartStokeColor,
        data: barData
    },
    {
        label: "XDBL",
        fillColor: LATENT_XDBL_ChartFillColor,
        strokeColor: Latent_BarChartStokeColor,
        data: barData
    },
    {
        label: "LDB",
        fillColor: LATENT_LDB_ChartFillColor,
        strokeColor: Latent_BarChartStokeColor,
        data: barData
    },
    {
        label: "LDBS",
        fillColor: LATENT_LDBS_ChartFillColor,
        strokeColor: Latent_BarChartStokeColor,
        data: barData
    },
    {
        label: "LDBX",
        fillColor: LATENT_LDBX_ChartFillColor,
        strokeColor: Latent_BarChartStokeColor,
        data: barData
    },
    {
        label: "LDBM",
        fillColor: LATENT_LDBM_ChartFillColor,
        strokeColor: Latent_BarChartStokeColor,
        data: barData
    },
    {
        label: "PDB",
        fillColor: LATENT_PDB_ChartFillColor,
        strokeColor: Latent_BarChartStokeColor,
        data: barData
    },
    {
        label: "PLDB",
        fillColor: LATENT_PLDB_ChartFillColor,
        strokeColor: Latent_BarChartStokeColor,
        data: barData
    }]
};

function findData(tobefound, target) {
    var x;
    var result = false;
    for (x in target) {
        if (tobefound == target[x]);
        result = true;
    }
    return result;
}

function updateBarChartsSameColor(barChartJsonString) {
    // var barChartJsonO = JSON.parse(barChartJsonString);
    var barChartJsonO = barChartJsonString;
    for (var oneType in barChartJsonO) {
        oneTypeJsonData = barChartJsonO[oneType];
        var labelsArray = new Array();
        var dataSetArray = new Array();
        var data = new Array();
        for (var key in oneTypeJsonData) {
            labelsArray.push(key);
            data.push(oneTypeJsonData[key]);
        }
        var detasetO = new Object();
        detasetO.label = oneType,
        detasetO.fillColor = "#008B8B";
        detasetO.strokeColor = "yellow";
        detasetO.data = data;
        dataSetArray.push(detasetO);

        barChartData = new Object();
        barChartData.labels = labelsArray;
        barChartData.datasets = dataSetArray;
        var canvasId = getCanvasId(oneType);
        var chartInstance = getChartInstance(oneType);
        if (chartInstance != null) {
            chartInstance.destroy();
        }
        var ctx = document.getElementById(canvasId).getContext("2d");
        ctx.canvas.width = 400;
        ctx.canvas.height = 248;
        chartInstance = new Chart(document.getElementById(canvasId).getContext("2d")).Bar(barChartData, barChartOptions);
    }
}

function updateBarCharts_xx(barChartJsonString) {
    var barLabel;
    var barStokeColor;
    var barChartJsonO = barChartJsonString;
    for (var oneType in barChartJsonO) {
        barLabel = oneType;
        barStokeColor = getBarStokeColor(oneType);
        oneTypeJsonData = barChartJsonO[oneType];
        var labelsArray = new Array();
        var dataSetArray = new Array();
        var data = new Array();
        for (var key in oneTypeJsonData) {
            labelsArray.push(key);
            data.push(oneTypeJsonData[key]);
        }
        var size = data.length;
        var detaset = [];
        barChartData = new Object();
        var dataSetArr = [];
        for (i = 0; i < size; i++) {
            var unit = new Object();
            unit.label = labelsArray[i];
            unit.fillColor = getBarChartFillColor(labelsArray[i]);
            unit.strokeColor = barStokeColor;
            unit.data = [data[i]];
            dataSetArr.push(data[i]);
            detaset.push(unit);
        }

        barChartData.labels = [barLabel];
        barChartData.datasets = detaset;

        var canvasId = getCanvasId(oneType);
        var chartInstance = getChartInstance(oneType);
        if (chartInstance != null) {
            chartInstance.destroy();
        }

        var ctx = document.getElementById(canvasId).getContext("2d");
        ctx.canvas.width = 400;
        ctx.canvas.height = 248;
        chartInstance = new Chart(document.getElementById(canvasId).getContext("2d")).Bar(barChartData, barChartOptions);
    }
}

function updateBarCharts(barChartJsonStr) {
    var barJson = barChartJsonStr;
    for (var key in barJson) {
        var chartInstance = getChartInstance(key);
        var length = chartInstance.datasets.length;
        var oneBarTypeData = barJson[key];
        var dataArray;
        switch (key) {
        case "tenprintMonitor":
            dataArray = new Array(tenprintBarDbName.length);
            for (i = 0; i < dataArray.length; i++) {
                dataArray[i] = 0;
            }
            for (i = 0; i < tenprintBarDbName.length; i++) {
                for (var oneType in oneBarTypeData) {
                    if (tenprintBarDbName[i] == oneType) {
                        dataArray[i] = oneBarTypeData[oneType];
                    }
                }
            }
            break;

        case "latentMonitor":
            dataArray = new Array(latentBarDbName.length);
            for (i = 0; i < dataArray.length; i++) {
                dataArray[i] = 0;
            }
            for (i = 0; i < latentBarDbName.length; i++) {
                for (var oneType in oneBarTypeData) {
                    if (latentBarDbName[i] == oneType) {
                        dataArray[i] = oneBarTypeData[oneType];
                    }
                }
            }
            break;
        }

        for (i = 0; i < length; i++) {
            var subLength = chartInstance.datasets[i].bars.length;
            for (j = 0; j < subLength - 1; j++) {
                chartInstance.datasets[i].bars[j].value = chartInstance.datasets[i].bars[j + 1].value;
            }
            chartInstance.datasets[i].bars[subLength - 1].value = dataArray[i];
        }
        chartInstance.update();
    }
}

var muInquiryLoadChartData = {
    labels: [" ", " ", " ", " ", " ", " ", " ", " "],
    datasets: [{
        fillColor: muInquiryLoad_FillColor,
        strokeColor: muInquiryLoad_StrokeColor,
        data: [0, 0, 0, 0, 0, 0, 0, 0]
    }]
};

var muExtractLoadChartData = {
    labels: [" ", " ", " ", " ", " ", " ", " ", " "],
    datasets: [{
        fillColor: muExtractLoad_FillColor,
        strokeColor: muExtractLoad_StrokeColor,
        data: [0, 0, 0, 0, 0, 0, 0, 0]
    }]
};

var muTimer;
function updateMuLoadChart_old(muLoadJsonStr) {
    while (muloadBarChart.datasets[0].bars.length) {
        muloadBarChart.removeData();
        muloadBarChart.destroy();
    }

    var muLoadJson = muLoadJsonStr;
    var keyArr = [];
    var dataArr = [];
    for (var mu in muLoadJson) {
        keyArr.push(mu.toString());
        dataArr.push(muLoadJson[mu]);
    }

    for (j = 0; j < keyArr.length; j++) {
        updateBarData(dataArr[j], keyArr[j]);
    }
    muloadBarChart.update();
    clearInterval(muTimer);
}

function updateBarData(data, label) {
    muTimer = setInterval(function() {
        muloadBarChart.addData([data], label);
        if (muloadBarChart.datasets[0].bars.length >= 10) {
            muloadBarChart.removeData();
        }
    },
    2000);
}
function updateMuLoadChart(muLoadJsonStr, muLoadType) {
    var canvasId;
    var barChartInstance;
    var fillColor;
    var strokeColor;
    if (muLoadType == "Inquiry") {
        canvasId = "mu_inquiry_load";
        barChartInstance = muInquiryloadBarChart;
        fillColor = muInquiryLoad_FillColor;
        strokeColor = muInquiryLoad_StrokeColor;
    }
    if (muLoadType == "Extract") {
        canvasId = "mu_extract_load";
        barChartInstance = muExtractloadBarChart;
        fillColor = muExtractLoad_FillColor;
        strokeColor = muExtractLoad_StrokeColor;
    }

    if (barChartInstance != null) {
        barChartInstance.destroy();
    }
    var muLoadJson = muLoadJsonStr;
    var labels = [];
    var datasets = [];
    var data = [];
    for (var mu in muLoadJson) {
        labels.push(mu);
        data.push(muLoadJson[mu]);
    }
    var unit = new Object();
    unit.label = mu;
    unit.fillColor = fillColor;
    unit.strokeColor = strokeColor;
    unit.data = data;
    datasets.push(unit);
    muLoadChartData = new Object();
    muLoadChartData.labels = labels;
    muLoadChartData.datasets = datasets;

    var ctx = document.getElementById(canvasId).getContext("2d");
    ctx.canvas.width = 400;
    ctx.canvas.height = 124;
    barChartInstance = new Chart(document.getElementById(canvasId).getContext("2d")).Bar(muLoadChartData, barChartOptions);
}

function toggleMuLoadDisplay() {

}

function updateMuLoadChartXX(muLoadJsonStr) {
    if (muloadBarChart != null) {
        muloadBarChart.destroy();
    }
    var muLoadJson = muLoadJsonStr;
    var labels = [];
    var datasets = [];
    var data = [];
    for (var mu in muLoadJson) {
        labels.push(mu);
        data.push(muLoadJson[mu]);
    }
    var unit = new Object();
    unit.label = mu;
    unit.fillColor = muLoad_FillColor;
    unit.strokeColor = muLoad_StrokeColor;
    unit.data = data;
    datasets.push(unit);
    muLoadChartData = new Object();
    muLoadChartData.labels = labels;
    muLoadChartData.datasets = datasets;
    var ctx = document.getElementById("mu_load_bar").getContext("2d");
    ctx.canvas.width = 400;
    ctx.canvas.height = 248;
    muloadBarChart = new Chart(document.getElementById("mu_load_bar").getContext("2d")).Bar(muLoadChartData, barChartOptions);
}

function blink() {
    var alarm = document.getElementById("alarm");
    if (!mustBlink) {
        alarm.style.fontSize = "40px";
        for (i = 0; i < 18; i++) {
            alarm.style.fontSize += 1;
        }
    } else {
        alarm.style.fontSize = "68px";
    }
    mustBlink = !mustBlink;
}

function setBlink() {
    intervalId = setInterval(blink, 500);
}

function toggleSlb(slb) {
    var mysheet = $('link[href="/systemmanager/static/css/home_style.css"]')[0].sheet;
    if (slb) {
        mysheet.addRule('#slbRectangle:before', 'background: green');
        mysheet.addRule('#slbRectangle', 'background: green');
        // document.styleSheets[0].addRule('#slbRectangle', 'border: 1px solid
        // green');
        mysheet.addRule('#slbRectangle:before', 'border: 1px solid green');
        mysheet.addRule('#slbRectangle:after', 'border: 1px solid green');

    } else {
        mysheet.addRule('#slbRectangle', 'background: gray');
        mysheet.addRule('#slbRectangle:before', 'background: gray');
        // document.styleSheets[0].addRule('#slbRectangle', 'border: 1px solid
        // gray');
        mysheet.addRule('#slbRectangle:before', 'border: 1px solid gray');
        mysheet.addRule('#slbRectangle:after', 'border: 1px solid  gray');
    }
    // slbOn = !slbOn;
}

function setSlbOn() {
    setInterval(toggleSlb, 500);
}

function Point(x, y) {
    this.x = x;
    this.y = y;
}

var barPrintLegendMode = false;
var barLatentLegendMode = false;

function displsyLegends(e) {
    var evt = e || window.event;
    if (e.preventDefault) {
        e.preventDefault();
    } else {
        e.returnValue = false;
    }
    var srcTarget = e.target || window.event.srcElement;
    var targetlegendId;
    var chart;
    switch (srcTarget.id) {
    case "barTenprintLeg":        
        if(!barPrintLegendMode && !barLatentLegendMode) {
        	document.getElementById("barTenprintLeg").innerHTML = tenprintBatChart.generateLegend();
        	barPrintLegendMode = true;
        } else { 
        	document.getElementById("barTenprintLeg").innerHTML = "Tenprint Legend";
            barPrintLegendMode = false;
        }        
        document.getElementById("barTenprintLeg").style.fontSize = "small"; 
        break;
    case "barLatentLeg":    	
    	 if(!barLatentLegendMode && !barPrintLegendMode) {
    		 document.getElementById("barLatentLeg").innerHTML = latentBarChart.generateLegend(); 
    		 barLatentLegendMode = true;
    	 } else { 
    		  document.getElementById("barLatentLeg").innerHTML = "Latent Legend";
        	  barLatentLegendMode = false;
    	 }    	
    	document.getElementById("barLatentLeg").style.fontSize = "small";    	
        break;
    }
}
 

function addDisplayLegendEvent() {
    document.getElementById("barTenprintLeg").addEventListener("click", displsyLegends);
    document.getElementById("barLatentLeg").addEventListener("click", displsyLegends);

}

function initPage() {
    var tbMiddle = document.getElementById("tb_middle_t");
    var tbMiddleTr = tbMiddle.getElementsByTagName('tr')[0];
    var tbMiddleTdList = tbMiddleTr.getElementsByTagName('td');
    var last = tbMiddleTdList.length;
    tbMiddleTdList[last - 1].style.borderRight = "1px solid gray";
    var circles = document.getElementsByClassName("circle");
    for (i = 0; i < circles.length; i++) {
        circles[i].style.visibility = "hidden";
    }

    mmPieChart = new Chart(document.getElementById("mmChart").getContext("2d")).Pie(pieDatas.mm, pieChartOptions);
    mrPieChart = new Chart(document.getElementById("mrChart").getContext("2d")).Pie(pieDatas.mr, pieChartOptions);
    dmPieChart = new Chart(document.getElementById("dmChart").getContext("2d")).Pie(pieDatas.dm, pieChartOptions);
    muPieChart = new Chart(document.getElementById("muChart").getContext("2d")).Pie(pieDatas.mu, pieChartOptions);
    document.getElementById("pieLegend").innerHTML = mmPieChart.generateLegend();

    extractlineChart = new Chart(document.getElementById("extract_line").getContext("2d")).Line(extactLineChartData, lineChartOptions);
    document.getElementById("lineExtractionLegend").innerHTML = extractlineChart.generateLegend();
    tenprintLineChart = new Chart(document.getElementById("ten_print_line").getContext("2d")).Line(tenprintLineData, lineChartOptions);
    document.getElementById("lineTenprintLegend").innerHTML = tenprintLineChart.generateLegend();
    latentLineChart = new Chart(document.getElementById("latent_print_line").getContext("2d")).Line(latentLineData, lineChartOptions);
    document.getElementById("lineLatentLegend").innerHTML = latentLineChart.generateLegend();
    tenprintBatChart = new Chart(document.getElementById("ten_print_bar").getContext("2d")).Bar(tenprintBarData, barChartOptions);
    document.getElementById("barTenprintLegend").innerHTML = tenprintBatChart.generateLegend();
    latentBarChart = new Chart(document.getElementById("latent_bar").getContext("2d")).Bar(latentBarData, barChartOptions);
    document.getElementById("barLatentLegend").innerHTML = latentBarChart.generateLegend();
    muInquiryloadBarChart = new Chart(document.getElementById("mu_inquiry_load").getContext("2d")).Bar(muInquiryLoadChartData, barChartOptions);
    muExtractloadBarChart = new Chart(document.getElementById("mu_extract_load").getContext("2d")).Bar(muExtractLoadChartData, barChartOptions); 
    toggleSlb(false);
    // handleEvent(0);
    // setBarChartToScrollInX();
    addDisplayLegendEvent();
    var usedBrowser = isWhatBrowser();
    if (usedBrowser == "IE") {
    	document.getElementById("body_frame").style.overflowY="visible";    	
    }
    if (usedBrowser == "FIREFOX") {
        var pieTable = document.getElementById("tb_upper_g");
        var pieTr = pieTable.getElementsByTagName('tr')[0];
        var pieTd = pieTr.getElementsByTagName('td')[0];
        var pieList = pieTd.getElementsByTagName('div');
        for (i = 0; i < pieList.length; i = i + 3) {
            pieList[i].style.marginRight = "15px";
            var legend = pieList[i].getElementsByTagName('legend')[0];
            legend.style.top = "0px";
            var circle = pieList[i].getElementsByTagName('div')[0];
            circle.style.top = "0px";
            circle.style.left = "20px";
            var vas = pieList[i].getElementsByTagName('canvas')[0];
            vas.style.top = "-20px";
            var percent = pieList[i].getElementsByTagName('div')[1];
            percent.style.top = "-10px";
            percent.style.left = "10px";
        }
    }
}

function setBarChartToScrollInX() {
    var tbBottomG = document.getElementById("tb_bottom_g");
    var tbBottomGTr = tbBottomG.getElementsByTagName('tr')[0];
    var tbBottomGTdList = tbBottomGTr.getElementsByTagName('td');
    for (i = 0; i < tbBottomGTdList.length; i++) {
        tbBottomGTdList[i].style.overflowX = "scroll";
    }
}

function isWhatBrowser() {
    var explorer = navigator.userAgent;
    if (explorer.indexOf("MSIE") >= 0 || explorer.indexOf("Trident") >= 0) {
        browser = "IE";
    } else if (explorer.indexOf("Firefox") >= 0) {
        browser = "FIREFOX";
    } else if (explorer.indexOf("Chrome") >= 0) {
        browser = "CHROME";
    } else if (explorer.indexOf("Opera") >= 0) {
        browser = "OPERA";
    } else if (explorer.indexOf("Safari") >= 0) {
        browser = "SAFARI";
    } else if (explorer.indexOf("Netscape") >= 0) {
        browser = "NETSCAPE";
    }
    return browser;
}

function getScopIdAndAlarmTimeSetting(scopId, alarmTimeSetting) {
    scopeId = scopId;
    alarmTimeBefore = alarmTimeSetting;
}

var intervalId;
function displayLastAlarmTime(lastAlm) {
    var disTime;
    if (lastAlm != null && lastAlm != undefined) {
        disTime = lastAlm.substring(0, 19);
    } else {
        disTime = "--";
    }
    document.getElementById("alarmTime").innerHTML = disTime;
}

function stopBlink() {
    clearInterval(intervalId);
    document.getElementById("alarm").style.backgroundColor = "green";
    document.getElementById("alarm").style.fontSize = "40px";
}

function ajaxEvnetLog() {
    $.ajax({
        type: "GET",
        url: "/systemmanager/chart/event",
        data: {
            "alarmTimeBefore": alarmTimeBefore
        },
        timeout: 2000,
        dataType: "text",
        cache: false,
        async: false,
        success: function(data, status) {
            if (data == "" || data == null || data == undefined) {
                return;
            }
            var json = JSON.parse(data);
            var lastAlm;
            for (var key in json) {
                lastAlm = json[key];
            }
            displayLastAlarmTime(lastAlm);
        },
        error: function(XMLHttpRequest, status, errorThrown) {
            alertMessage('error occurred when request to event.');
        }
    });
}

function ajaxSlbStatus() {
    $.ajax({
        type: "GET",
        url: "/systemmanager/chart/slb",
        timeout: 2000,
        dataType: "text",
        cache: false,
        async: false,
        success: function(data, status) {
            if (data == "" || data == null || data == undefined) {
                return;
            }
            var json = JSON.parse(data);
            var slb;
            for (var key in json) {
                slb = json[key];
            }
            toggleSlb(slb);
        },
        error: function(XMLHttpRequest, status, errorThrown) {
            alertMessage('Can not to get data for display Slb status, Reason: ' + errorThrown);
        }
    });
}

function ajaxPieChart() {
    $.ajax({
        type: "GET",
        url: "/systemmanager/chart/status",
        timeout: 2000,
        dataType: "json",
        cache: false,
        async: false,
        success: function(data, status) {
            if (data == "" || data == null || data == undefined) {
                return;
            }
            updatePieCharts(data);
        },
        error: function(XMLHttpRequest, status, errorThrown) {
            alertMessage('Can not to get data for Pie chart, Reason: ' + errorThrown);
        }
    });
}

function ajaxLineChart() {
    $.ajax({
        type: "GET",
        url: "/systemmanager/chart/transactions",
        timeout: 2000,
        dataType: "json",
        cache: false,
        async: false,
        success: function(data, status) {
            if (data == "" || data == null || data == undefined) {
                return;
            }
            updateLineCharts(data);
        },
        error: function(XMLHttpRequest, status, errorThrown) {
            alertMessage('Can not to get data for Line chart, Reason: ' + errorThrown);
        }
    });
}

function ajaxBarChart() {
    $.ajax({
        type: "GET",
        url: "/systemmanager/chart/database",
        context: document.body,
        timeout: 2000,
        data: {
            "scopeId": scopeId
        },
        dataType: "json",
        cache: false,
        async: true,
        success: function(data, status) {
            if (data == "" || data == null || data == undefined) {
                return;
            }
            updateBarCharts(data);
        },
        error: function(XMLHttpRequest, status, errorThrown) {
            alertMessage('Can not to get data for Bar chart, Reason: ' + errorThrown);
        }
    });
}

function ajaxMuInquiryLoadChart() {
    $.ajax({
        type: "GET",
        url: "/systemmanager/chart/muInquiryloads",
        timeout: 2000,
        dataType: "json",
        cache: false,
        async: true,
        success: function(data, status, xhr) {
            if (data == "" || data == null || data == undefined) {
                return;
            }
            updateMuLoadChart(data, MU_INQUIRY_LOAD_Type);
        },
        error: function(XMLHttpRequest, status, errorThrown) {
            alertMessage('Can not to get data for MU inquiry load chart, ' + 'Reason: ' + errorThrown);
        }
    });
}

function ajaxMuExtractLoadChart() {
    $.ajax({
        type: "GET",
        url: "/systemmanager/chart/muExtractloads",
        timeout: 2000,
        dataType: "json",
        cache: false,
        async: true,
        success: function(data, status, xhr) {
            if (data == "" || data == null || data == undefined) {
                return;
            }
            updateMuLoadChart(data, MU_EXTRACT_LOAD_Type);
        },
        error: function(XMLHttpRequest, status, errorThrown) {
            alertMessage('Can not to get data for MU Extract load chart, ' + 'Reason: ' + errorThrown);
        }
    });
}

function ajaxMuLoadChart() {
    $.ajax({
        type: "GET",
        url: "/systemmanager/chart/muloads",
        timeout: 2000,
        dataType: "json",
        cache: false,
        async: true,
        success: function(data, status, xhr) {
            if (data == "" || data == null || data == undefined) {
                return;
            }
            updateMuLoadChart(data);
        },
        error: function(XMLHttpRequest, status, errorThrown) {
            alertMessage('Can not to get data for MU load chart, ' + 'Reason: ' + errorThrown);
        }
    });
}

var isAlerted = true;
function alertMessage(message) {
    if (isAlerted) {
        top.$.jBox.alert(message, "System Alert");
        isAlerted = false;
    }
    return false;
}