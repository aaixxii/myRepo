/* only for test */
function testPieChart() {
    var pieJsonData = {
            "mm": {
                "WORKING": 2,
                "TIMED_OUT": 1,
                "EXITED": 0
            },
            "mr": {
                "WORKING": 2,
                "TIMED_OUT": 0,
                "EXITED": 0
            },
            "dm": {
                "WORKING": 1,
                "TIMED_OUT": 1,
                "EXITED": 1
            },
            "mu": {
                "WORKING": 3,
                "TIMED_OUT": 1,
                "EXITED": 3
            }
        };

    var pieStr = JSON.stringify(pieJsonData);
    updatePieCharts(pieJsonData);
}

function testPieChartTimer() {
    setInterval(testPieChart, 1000);
}

function testMuInquriryloadChart() {
    var muLoadJson = {
        "1025": 23,
        "1020": 15,
        "1030": 20,
        "1009": 18,
        "1008": 8,
        "1007": 16,
        "1006": 24,
        "1001": 15,
        "1003": 19,
        "1004": 21,
        "1002": 17,
        "1005": 23,
        "1000": 15
    };
    var str = JSON.stringify(muLoadJson); 
	updateMuLoadChart( muLoadJson, "Inquiry");
}

function testMuInquiryLoadTimer() {
    setInterval(testMuInquriryloadChart, 1000);	
}


function testMuExtractloadChart() {
    var muLoadJson = {
        "1010": 20,
        "1011": 18,
        "1018": 8,
        "1017": 16,
        "1016": 24,
        "1015": 15,
        "1013": 19,
        "1014": 21,
        "1012": 17 
    };
    var str = JSON.stringify(muLoadJson); 
	updateMuLoadChart( muLoadJson, "Extract");
}

function testMuExtractLoadTimer() {
    setInterval(testMuExtractloadChart, 1000);	
}

function testBarChart() {
    var barJsonStr = {
        "latentMonitor": {
            "LDBM": 1,
            "SDBL": 2,
            "XDBL": 3,
            "RDBLS": 4,
            "SDBLS": 5,
            "RDBLM": 3,
            "SDBLM": 6,
            "XDBL": 2,
            "LDB": 3,
            "LDBS": 5,
            "LDBX": 4,
            "XDBL": 5,
            "PDB": 3,
            "PLDB": 5,
            "RDBL": 4
        },
        "tenprintMonitor": {
            "SDBTM": 2,
            "RDBT": 4,
            "SDBT": 3,
            "LDB": 5,
            "LDBS": 3,
            "LDBM": 2,
            "LDBX": 6,
            "PLDB": 5,
            "FDB": 4,
            "IDB": 2,
            "RDBTM": 3
        }
    };
    var barStr = JSON.stringify(barJsonStr);
    updateBarCharts(barJsonStr);
}
 
function testBarChartTimer() {
    setInterval(testBarChart, 1000);
}

function testLineCharts() {
    var rTLI = Math.floor(Math.random() * 90 + 2);
    var rII = Math.floor(Math.random() * 80 + 2);
    var rTI = Math.floor(Math.random() * 7 + 2);
    var rTLI = Math.floor(Math.random() * 60 + 2);
    var rTLIP = Math.floor(Math.random() * 50 + 2);
    var rFI = Math.floor(Math.random() * 40 + 2);
    var rLLIP = Math.floor(Math.random() * 30 + 2);
    var rLI = Math.floor(Math.random() * 20 + 2);
    var rLLI = Math.floor(Math.random() * 10 + 2);
    var rLIP = Math.floor(Math.random() * 5 + 2);
    var rextract = Math.floor(Math.random() * 4 + 2);
    var lineJson = {
        "tenprintFunction": {
            "TLI": 1,
            "II": 2,
            "TI": 3,
            "TLIP": 4,
            "FI": 1
        },
        "latentFunction": {
            "LLIP": 2,
            "LI": 1,
            "LLI": 2,
            "LIP": 4
        },
        "extract": {
            "EXTRACT": 2
        }
    };
    var extact = lineJson.extract;
	extact.EXTRACT = rextract;
    var tenprint = lineJson.tenprintFunction;
    tenprint.TLI = rTLI;
    tenprint.II = rII;
    tenprint.TI = rTI;
    tenprint.TLIP = rTLIP;
    tenprint.FI = rFI;
    var lantent = lineJson.latentFunction;
    lantent.LLIP = rLLIP;
    lantent.LI = rLI;
    lantent.LLI = rLLI;
    lantent.LIP = rLIP;

	var str = JSON.stringify(lineJson);
    updateLineCharts(lineJson);
}

function testLineChartTimer() {
    setInterval(testLineCharts, 1000);
}

function testAlarmOn() {
	var alarm = 
		{
		   "count" : 2
	   }
var str = 	JSON.stringify(alarm);	  
handleEvent(str);
}

function testAlarmOff() {
	var alarm = 
		{
		   "count" : 0
	   }
var str = 	JSON.stringify(alarm);	  
handleEvent(str);
}