/* monitor js */
var slbCheckInterval = 5000;
var alarmCheckInterval = 5000;
var pieChartInterval = 5000;
var lineChartInterval = 2000;
var barChartInterval = 5000;
var muLoadChartInterval = 5000;
var browser;

var SM_SERVER_URL = "";
var alarmTimeBefore = "5000";
var mustBlink = false;
var slbOn = true;
var circleNum = [];
var compoentNames = [ "MM", "MR", "DM", "MU" ];
var labelWorking = "working";
var labelTimeout = "timeout";
var labelExited = "exit";

var workingColor = "#2e8b57";
var timeOutColor = "yellow";
var exitedColor = "gray";

var TI_StrokeColor = "#FF0000";
var TLI_StrokeColor = "#F08080";
var TLIP_StrokeColor = "#FF7F50";
var FI_StrokeColor = "#A0522D";
var II_StrokeColor = "#FFA500";
var EXTRACT_StrokeColor = "#FF0000";

var TI_PointColor = "#008000";
var TLI_PointColor = "#00FF7F";
var TLIP_PointColor = "#40E0D0";
var FI_PointColor = "#7B68EE";
var II_PointColor = " #DDA0DD ";
var muLoad_PointColor = "#1E90FE";
var EXTRACT_PointColor = "#008000";

var LLIP_StrokeColor = "#FF0000";
var LI_StrokeColor = "#F08080";
var LLI_StrokeColor = "#FF7F50";
var LIP_StrokeColor = "#A0522D";

var LLIP_PointColor = "#008000";
var LI_PointColor = "#00FF7F";
var LLI_PointColor = "#40E0D0";
var FI_PointColor = "#7B68EE";
var LIP_PointColor = " #DDA0DD ";

var BarChartFillColor = "#B0C4DE";
var BarChartStokeColor = "#7B68EE";
var muLoad_StrokeColor = "#9A32CD";
var muLoad_FillColor = "#A4D3EE";

var muLoadColor = "#1E90FF";

var mmCanvasId = "mmChart";
var mrCanvasId = "mrChart";
var dmCanvasId = "dmChart";
var muCanvasId = "muChart";
var tenprintMonitorCanvasId = "ten_print_bar";
var latentMonitorCanvasId = "latent_bar";
var tenprintFunctionCanvasId = "ten_print_line";
var latentFunctionCanvasId = "latent_print_line";
var extractCanvasId = "extract_line";
var muLoadCanvusId = "mu_load_bar";

var pieChart;
var lineChart;
var barChart;
var muloadBarChart;
var tenprintLineChart;
var latentLineChart;
var extractlineChart;

var tenprintFunction = [ "TI", "TLI", "TLIP", "FI", "II" ];
var latentFunction = [ "LI", "LLI", "LIP", "LLIP" ];

var lineChartOptions = {
	bezierCurve : false,
	datasetFill : false,
	animation : false,
	responsive : true
};

var barChartOptions = {
	animation : false,
};

function lineChartColor(strokeColor, pointColor) {
	this.strokeColor = strokeColor;
	this.pointColor = pointColor;
}

function getChartInstance(name) {
	switch (name) {
	case "tenprintFunction":
		return tenprintLineChart;
		break;
	case "latentFunction":
		return latentLineChart;
		break;
	case "extract":
		return extractlineChart;
		break;
	}
}

function getCanvasId(name) {
	switch (name) {
	case "mm":
		return mmCanvasId;
		break;
	case "mr":
		return mrCanvasId;
		break;
	case "dm":
		return dmCanvasId;
		break;
	case "mu":
		return muCanvasId;
		break;
	case "tenprintMonitor":
		return tenprintMonitorCanvasId;
		break;
	case "latentMonitor":
		return latentMonitorCanvasId;
		break;
	case "tenprintFunction":
		return tenprintFunctionCanvasId;
		break;
	case "latentFunction":
		return latentFunctionCanvasId;
		break;
	case "extract":
		return extractCanvasId;
		break;
	case "muload":
		return muloadCanvasId;
		break;
	}
}

function getLineColor(name) {
	switch (name.toUpperCase()) {
	case "TI":
		return new lineChartColor(TI_StrokeColor, TI_PointColor);
		break;
	case "TLI":
		return new lineChartColor(TLI_StrokeColor, TLI_PointColor);
		break;
	case "II":
		return new lineChartColor(II_StrokeColor, II_PointColor);
		break;
	case "TLIP":
		return new lineChartColor(TLIP_StrokeColor, TLIP_PointColor);
		break;
	case "FI":
		return new lineChartColor(FI_StrokeColor, FI_PointColor);
		break;
	case "LI":
		return new lineChartColor(LI_StrokeColor, LI_PointColor);
		break;

	case "LLIP":
		return new lineChartColor(LLIP_StrokeColor, LLIP_PointColor);
		break;
	case "LLI":
		return new lineChartColor(LLI_StrokeColor, LLI_PointColor);
		break;
	case "LIP":
		return new lineChartColor(LIP_StrokeColor, LIP_PointColor);
		break;
	case "EXTRACT":
		return new lineChartColor(EXTRACT_StrokeColor, EXTRACT_PointColor);
		break;
	}
}

function getPieColor(name) {
	switch (name.toLowerCase()) {
	case "working":
		return workingColor;
		break;
	case "timed_out":
		return timeOutColor;
		break;
	case "exit":
		return exitedColor;
		break;
	}
}

function pieStruct(label, value) {
	var unit = {
		value : value,
		color : getPieColor(label),
		label : label
	};
	return unit;
}

/**
 * updatePieCharts
 * 
 * @param pieJsonString
 */
function updatePieCharts(pieJsonString) {
	pieChart = null;
	// var pieJsonData = JSON.parse(pieJsonString);
	var pieJsonData = pieJsonString;
	for ( var unitType in pieJsonData) {
		var oneCompoentTypeData = pieJsonData[unitType];
		var onePieData = new Array();
		for ( var key in oneCompoentTypeData) {
			tmp = new pieStruct(key, oneCompoentTypeData[key]);
			onePieData.push(tmp);
		}
		var canvasId = getCanvasId(unitType);
		pieChart = null;
		var obj = document.getElementById(canvasId);
		var $obj = $(obj);
		$obj.attr('width', $obj.attr('width') - 2).attr('height',
				$obj.attr('height') - 2).attr('style', '');
		pieChart = new Chart(obj.getContext("2d")).Pie(onePieData);
		doAfterPieChartChange(canvasId, oneCompoentTypeData);
	}
}

/**
 * doAfterPieChartChange
 * 
 * @param canvasId
 * @param pieJsonDataO
 */
function doAfterPieChartChange(canvasId, pieJsonDataO) {
	var pieList = document.getElementsByClassName("pie");

	var working = 0;
	var timeout = 0;
	var exit = 0;
	var all = 0;
	if (pieJsonDataO.WORKING != undefined) {
		working = pieJsonDataO.WORKING;
	}
	if (pieJsonDataO.TIMED_OUT != undefined) {
		timeout = pieJsonDataO.TIMED_OUT;
	}
	if (pieJsonDataO.EXIT != undefined) {
		exit = pieJsonDataO.EXIT
	}
	var all = working + timeout + exit;

	var notWorking = timeout + exit;
	var spanMO = document.getElementById(canvasId).previousSibling.parentNode
			.getElementsByTagName('span')[0];
	spanMO.innerHTML = notWorking;

	var percent = "-";
	if (all != 0) {
		var percent = Math.round(working / (all) * 100);
	}

	switch (canvasId) {
	case "mmChart":
		pieList[0].getElementsByClassName("percent")[0].innerHTML = percent
				.toString()
				+ "%";
		var circle = pieList[0].getElementsByClassName("circle")[0];
		if (notWorking > 0) {
			circle.style.visibility = "visible"
		} else {
			circle.style.visibility = "hidden";
		}
		break;
	case "mrChart":
		pieList[2].getElementsByClassName("percent")[0].innerHTML = percent
				.toString()
				+ "%";
		var circle = pieList[2].getElementsByClassName("circle")[0];
		if (notWorking > 0) {
			circle.style.visibility = "visible"
		} else {
			circle.style.visibility = "hidden";
		}
		break;
	case "dmChart":
		pieList[1].getElementsByClassName("percent")[0].innerHTML = percent
				.toString()
				+ "%";
		var circle = pieList[1].getElementsByClassName("circle")[0];
		if (notWorking > 0) {
			circle.style.visibility = "visible"
		} else {
			circle.style.visibility = "hidden";
		}
		break;
	case "muChart":
		pieList[3].getElementsByClassName("percent")[0].innerHTML = percent
				.toString()
				+ "%";
		var circle = pieList[3].getElementsByClassName("circle")[0];
		if (notWorking > 0) {
			circle.style.visibility = "visible"
		} else {
			circle.style.visibility = "hidden";
		}
		break;
	}
}

function updateMuLoadChart(muLoadJsonStr) {
	muloadBarChart = null;
	// var muLoadJson = JSON.parse(muLoadJsonStr);
	var muLoadJson = muLoadJsonStr;
	var labels = [];
	var datasets = [];
	var data = [];
	for ( var mu in muLoadJson) {
		labels.push(mu);
		data.push(muLoadJson[mu]);
	}
	var unit = new Object();
	unit.label = mu;
	unit.fillColor = muLoad_FillColor;
	unit.strokeColor = muLoad_StrokeColor;
	unit.data = data;
	datasets.push(unit);
	muLoadChartData = new Object();
	muLoadChartData.labels = labels;
	muLoadChartData.datasets = datasets;
	var obj = document.getElementById("mu_load_bar");
	var $obj = $(obj);
	$obj.attr('width', $obj.attr('width') - 8).attr('height',
			$obj.attr('height') - 2).attr('style', '');

	muloadBarChart = new Chart(obj.getContext("2d")).Bar(muLoadChartData,
			barChartOptions);
}

var lineBase = 5000;
var stop = 100
var step = 5;
var index = 1;
var extactLineChartDataHolder = {
	labels : [ "35", "30", "25", "20", "15", "10", "5", "0" ],
	datasets : [ {
		label : "extract",
		strokeColor : EXTRACT_StrokeColor,
		pointColor : EXTRACT_PointColor,
		data : [ 0, 0, 0, 0, 0, 0, 0, 0 ]
	} ]
};

var tenprintLineData = {
	labels : [ "35", "30", "25", "20", "15", "10", "5", "0" ],
	datasets : [ {
		label : "TI",
		pointColor : TI_PointColor,
		strokeColor : TI_StrokeColor,
		data : [ 0, 0, 0, 0, 0, 0, 0, 0 ]
	}, {
		label : "TLI",
		strokeColor : TLI_StrokeColor,
		pointColor : TLI_PointColor,
		data : [ 0, 0, 0, 0, 0, 0, 0, 0 ]
	}, {
		label : "FI",
		strokeColor : FI_StrokeColor,
		pointColor : FI_PointColor,
		data : [ 0, 0, 0, 0, 0, 0, 0, 0 ]
	}, {
		label : "TLIP",
		strokeColor : TLIP_StrokeColor,
		pointColor : TLIP_PointColor,
		data : [ 0, 0, 0, 0, 0, 0, 0, 0 ]
	}, {
		label : "II",
		strokeColor : II_StrokeColor,
		pointColor : II_PointColor,
		data : [ 0, 0, 0, 0, 0, 0, 0, 0 ]
	} ]
};

var latentLineData = {
	labels : [ "35", "30", "25", "20", "15", "10", "5", "0" ],
	datasets : [ {
		label : "LI",
		strokeColor : LI_StrokeColor,
		pointColor : LI_PointColor,
		data : [ 0, 0, 0, 0, 0, 0, 0, 0 ]
	}, {
		label : "LLI",
		strokeColor : LLI_StrokeColor,
		pointColor : LLI_PointColor,
		data : [ 0, 0, 0, 0, 0, 0, 0, 0 ]
	}, {
		label : "LIP",
		strokeColor : LIP_StrokeColor,
		pointColor : LIP_PointColor,
		data : [ 0, 0, 0, 0, 0, 0, 0, 0 ]
	}, {
		label : "LLIP",
		strokeColor : LLIP_StrokeColor,
		pointColor : LLIP_PointColor,
		data : [ 0, 0, 0, 0, 0, 0, 0, 0 ]
	} ]
};

function newUpdateMuExtactLineChart(lineExJsonStr) {
	var lineExjson = JSON.parse(lineExJsonStr);
	for ( var exkey in lineExjson) {
		var nextX = lineBase.toString() + "sec";
		var length = extractlineChart.datasets[0].points.length;
		for (i = 0; i < length - 1; i++) {
			extractlineChart.datasets[0].points[i].value = extractlineChart.datasets[0].points[i + 1].value;
		}
		extractlineChart.datasets[0].points[length - 1].value = lineExjson[exkey];
		extractlineChart.update();
	}
}
var xAixs = [ "35", "30", "25", "20", "15", "10", "5", "0" ];

/**
 * updateLineCharts
 * 
 * @param lineChartJsonStr
 */
function updateLineCharts(lineChartJsonStr) {
	var lineJson = lineChartJsonStr;
	// var lineJson = JSON.parse(lineChartJsonStr);
	for ( var key in lineJson) {
		var chartInstance = getChartInstance(key);
		var length = chartInstance.datasets.length;
		var oneLine = lineJson[key];
		var dataArray = [];

		switch (key) {
		case "tenprintFunction":
			for ( var tenprint in tenprintFunction) {
				var count = oneLine[tenprintFunction[tenprint]];
				if (count !== null && count !== undefined) {
					dataArray.push(count);
				} else {
					dataArray.push('0');
				}
			}
			break;
		case "latentFunction":
			for ( var latent in latentFunction) {
				var count = oneLine[latentFunction[latent]];
				if (count !== null && count !== undefined) {
					dataArray.push(count);
				} else {
					dataArray.push('0');
				}
			}
			break;
		case "extract":
			for ( var onetype in oneLine) {
				dataArray.push(oneLine[onetype]);
			}
		}

		for (i = 0; i < length; i++) {
			var subLength = chartInstance.datasets[i].points.length;
			for (j = 0; j < subLength - 1; j++) {
				chartInstance.datasets[i].points[j].value = chartInstance.datasets[i].points[j + 1].value;
			}
			chartInstance.datasets[i].points[subLength - 1].value = dataArray[i];
		}
		chartInstance.update();
	}
}

function updateLatentLineCharts(onelineTypeJsonString) {
	var lineJson = JSON.parse(onelineTypeJsonString);
	var length = latentLineChart.datasets.length;
	var i = 0;

	var dataArray = [];
	for ( var key in lineJson) {
		dataArray.push(lineJson[key]);
	}
	for (i = 0; i < length; i++) {
		var sub = latentLineChart.datasets[i].points.length;
		for (j = 0; j < sub - 1; j++) {
			latentLineChart.datasets[i].points[j].value = latentLineChart.datasets[i].points[j + 1].value;
		}
		latentLineChart.datasets[i].points[sub - 1].value = dataArray[i];
	}
	latentLineChart.update();
}

function updateTenprintLineCharts(onelineTypeJsonString) {
	var lineJson = JSON.parse(onelineTypeJsonString);
	var length = tenprintLineChart.datasets.length;
	var i = 0;

	var dataArray = [];
	for ( var key in lineJson) {
		dataArray.push(lineJson[key]);
	}
	for (i = 0; i < length; i++) {
		var sub = tenprintLineChart.datasets[i].points.length;
		for (j = 0; j < sub - 1; j++) {
			tenprintLineChart.datasets[i].points[j].value = tenprintLineChart.datasets[i].points[j + 1].value;
		}
		tenprintLineChart.datasets[i].points[sub - 1].value = dataArray[i];
	}
	tenprintLineChart.update();
}

function updateBarCharts(barChartJsonString) {
	barChart = null;
	// var barChartJsonO = JSON.parse(barChartJsonString);
	var barChartJsonO = barChartJsonString;
	for ( var oneType in barChartJsonO) {
		oneTypeJsonData = barChartJsonO[oneType];
		var labelsArray = new Array();
		var dataSetArray = new Array();
		var data = new Array();
		for ( var key in oneTypeJsonData) {
			labelsArray.push(key);
			data.push(oneTypeJsonData[key]);
		}
		var detasetO = new Object();
		detasetO.label = oneType, detasetO.fillColor = BarChartFillColor;
		detasetO.strokeColor = BarChartStokeColor;
		detasetO.data = data;
		dataSetArray.push(detasetO);

		barChartData = new Object();
		barChartData.labels = labelsArray;
		barChartData.datasets = dataSetArray;
		var canvasId = getCanvasId(oneType);
		barChart = null;

		var obj = document.getElementById(canvasId);
		var $obj = $(obj);
		$obj.attr('width', $obj.attr('width') - 8).attr('height',
				$obj.attr('height') - 2).attr('style', '');

		barChart = new Chart(obj.getContext("2d")).Bar(barChartData,
				barChartOptions);
	}
}

function blink() {
	var alarm = document.getElementById("alarm");
	if (!mustBlink) {
		alarm.style.backgroundColor = "red";
		alarm.style.fontSize = "40px";
	} else {
		alarm.style.backgroundColor = "red";
		alarm.style.fontSize = "65px";
	}
	mustBlink = !mustBlink;
}

function setBlink() {
	setInterval(blink, 500);
}

function toggleSlb(jsonStr) {
	var json = JSON.parse(jsonStr);
	for ( var key in json) {
		var slb = json[key]
	}
	if (slb) {
		document.styleSheets[0].addRule('#slbRectangle:before',
				'background: green');
		document.styleSheets[0].addRule('#slbRectangle', 'background: green');
		// document.styleSheets[0].addRule('#slbRectangle', 'border: 1px solid
		// green');
		document.styleSheets[0].addRule('#slbRectangle:before',
				'border: 1px solid green');
		document.styleSheets[0].addRule('#slbRectangle:after',
				'border: 1px solid green');

	} else {
		document.styleSheets[0].addRule('#slbRectangle', 'background: gray');
		document.styleSheets[0].addRule('#slbRectangle:before',
				'background: gray');
		// document.styleSheets[0].addRule('#slbRectangle', 'border: 1px solid
		// gray');
		document.styleSheets[0].addRule('#slbRectangle:before',
				'border: 1px solid gray');
		document.styleSheets[0].addRule('#slbRectangle:after',
				'border: 1px solid  gray');
	}
	// slbOn = !slbOn;
}

function setSlbOn() {
	setInterval(toggleSlb, 500);
}

function Point(x, y) {
	this.x = x;
	this.y = y;
}

function initPage() {
	var tbMiddle = document.getElementById("tb_middle_t");
	var tbMiddleTr = tbMiddle.getElementsByTagName('tr')[0];
	var tbMiddleTdList = tbMiddleTr.getElementsByTagName('td');
	var last = tbMiddleTdList.length;
	tbMiddleTdList[last - 1].style.borderRight = "1px solid gray";
	var circles = document.getElementsByClassName("circle");
	for (i = 0; i < circles.length; i++) {
		circles[i].style.visibility = "hidden";
	}
	extractlineChart = new Chart(document.getElementById("extract_line")
			.getContext("2d"))
			.Line(extactLineChartDataHolder, lineChartOptions);
	tenprintLineChart = new Chart(document.getElementById("ten_print_line")
			.getContext("2d")).Line(tenprintLineData, lineChartOptions);
	latentLineChart = new Chart(document.getElementById("latent_print_line")
			.getContext("2d")).Line(latentLineData, lineChartOptions);

	var usedBrowser = isWhatBrowser();
	if (usedBrowser == "FIREFOX") {
		var pieTable = document.getElementById("tb_upper_g");
		var pieTr = pieTable.getElementsByTagName('tr')[0];
		var pieTd = pieTr.getElementsByTagName('td')[0];
		var pieList = pieTd.getElementsByTagName('div');
		for (i = 0; i < pieList.length; i = i + 3) {
			pieList[i].style.marginRight = "15px";
			var legend = pieList[i].getElementsByTagName('legend')[0];
			legend.style.top = "0px";
			var circle = pieList[i].getElementsByTagName('div')[0];
			circle.style.top = "0px";
			circle.style.left = "20px";
			var vas = pieList[i].getElementsByTagName('canvas')[0];
			vas.style.top = "-20px";
			var percent = pieList[i].getElementsByTagName('div')[1];
			percent.style.top = "-10px";
			percent.style.left = "10px";
		}
	}
}

function setMuloadScrollInX() {
	var tbBottomG = document.getElementById("tb_bottom_g");
	var tbBottomGTr = tbBottomG.getElementsByTagName('tr')[0];
	var tbBottomGTdList = tbBottomGTr.getElementsByTagName('td');
	var last = tbBottomGTdList.length;
	tbBottomGTdList[last - 1].style.overflowX = "scroll";
}

function isWhatBrowser() {
	var explorer = navigator.userAgent;
	if (explorer.indexOf("MSIE") >= 0 || explorer.indexOf("Trident") >= 0) {
		browser = "IE";
	} else if (explorer.indexOf("Firefox") >= 0) {
		browser = "FIREFOX";
	} else if (explorer.indexOf("Chrome") >= 0) {
		browser = "CHROME";
	} else if (explorer.indexOf("Opera") >= 0) {
		browser = "OPERA";
	} else if (explorer.indexOf("Safari") >= 0) {
		browser = "SAFARI";
	} else if (explorer.indexOf("Netscape") >= 0) {
		browser = "NETSCAPE";
	}
	return browser;
}

var eventTimer;
function handleEvent(eventJson) {
	var json = JSON.parse(eventJson);
	var count;
	for ( var key in json) {
		count = json[key];
	}
	if (count > 0) {
		var d = new Date();
		var dateStr = new String(d.getMonth()) + "  " + new String(d.getDay())
				+ "  " + new String(d.getHours()) + ":"
				+ new String(d.getMinutes()) + ":" + new String(d.getSeconds())
				+ "  " + new String(d.getFullYear());
		document.getElementById("alarmTime").innerHTML = "Last Alarm: "
				+ dateStr;
		eventTimer = setBlink();
	} else {
		clearInterval(eventTimer);
		alarm.style.backgroundColor = "green";
		alarm.style.fontSize = "40px";
	}
}

function ajaxEvnetLog() {
	$.ajax({
		type : "GET",
		url : "/systemmanager/chart/event?alarmTimeBefore=1",
		data : alarmTimeBefore,
		timeout : 2000,
		dataType : "text",
		cache : false,
		async : false,
		success : function(data, status) {
			handleEvent(data);
		},
		error : function(XMLHttpRequest, status, errorThrown) {
			alert("fail:" + XMLHttpRequest);
			alert("status:" + status);
		}
	});
}

function ajaxSlbStatus() {
	$.ajax({
		type : "GET",
		url : "/systemmanager/chart/slb",
		timeout : 2000,
		dataType : "text",
		cache : false,
		async : false,
		success : function(data, status) {
			toggleSlb(data);
		},
		error : function(XMLHttpRequest, status, errorThrown) {
			alert("fail:" + XMLHttpRequest);
			alert("status:" + status);
		}
	});
}

function ajaxPieChart() {
	$.ajax({
		type : "GET",
		url : "/systemmanager/chart/status",
		timeout : 2000,
		dataType : "json",
		cache : false,
		async : false,
		success : function(data, status) {
			updatePieCharts(data);
		},
		error : function(XMLHttpRequest, status, errorThrown) {
			alert("fail:" + XMLHttpRequest);
			alert("status:" + status);
		}
	});
}

function ajaxLineChart() {
	$.ajax({
		type : "GET",
		url : "/systemmanager/chart/transactions",
		timeout : 2000,
		dataType : "json",
		cache : false,
		async : false,
		success : function(data, status) {
			updateLineCharts(data);
		},
		error : function(XMLHttpRequest, status, errorThrown) {
			alert("fail:" + XMLHttpRequest);
			alert("status:" + status);
		}
	});
}

function ajaxBarChart() {
	$.ajax({
		type : "GET",
		url : "/systemmanager/chart/database?scopeId=1",
		context : document.body,
		timeout : 2000,
		dataType : "json",
		cache : false,
		async : true,
		success : function(data, status) {
			updateBarCharts(data);
		},
		error : function(XMLHttpRequest, status, errorThrown) {
			alert("fail:" + XMLHttpRequest);
			alert("status:" + status);
		}
	});
}

function ajaxMuLoadChart() {
	$.ajax({
		type : "GET",
		url : "/systemmanager/chart/muloads",
		timeout : 2000,
		dataType : "json",
		cache : false,
		async : true,
		success : function(data, status, xhr) {
			updateMuLoadChart(data);
		},
		error : function(XMLHttpRequest, status, errorThrown) {
			alert("fail:" + XMLHttpRequest);
			alert("status:" + status);
		}
	});
}

function setChartTimer() {
	ajaxPieChart();
	ajaxLineChart();
	ajaxMuLoadChart();
	ajaxBarChart();
	ajaxSlbStatus();
	setInterval(ajaxPieChart, pieChartInterval);
	setInterval(ajaxLineChart, lineChartInterval);
	setInterval(ajaxMuLoadChart, muLoadChartInterval);
	setInterval(ajaxBarChart, barChartInterval);
	setInterval(ajaxSlbStatus, slbCheckInterval);
	// setInterval(ajaxEvnetLog, alarmCheckInterval);
}