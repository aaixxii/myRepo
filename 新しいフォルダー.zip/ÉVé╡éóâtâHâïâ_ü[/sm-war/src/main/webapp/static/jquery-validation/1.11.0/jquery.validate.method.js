/*
 * Translated default messages for the jQuery validation plugin.
 * Locale: ZH (Chinese, 中文 (Zhōngwén), 汉语, 漢語)
 */
(function ($) {
	$.extend($.validator.messages, {
		required: "This field is required.",
		remote: "Please correct this information.",
		email: "Please enter a valid email address.",
		url: "Please enter a valid url.",
		date: "Please enter a valid date.",
		dateISO: "Please enter a valid date(ISO).",
		number: "Please enter a valid number.",
		digits: "Enter only integer.",
		creditcard: "Please enter a valid credit card number.",
		equalTo: "Please re-enter the same value.",
		accept: "Please enter the string has a legitimate extension.",
		maxlength: $.validator.format("Please enter the string at m {0} characters long."),
		minlength: $.validator.format("Please enter the string at least {0} characters long."),
		rangelength: $.validator.format("Please enter the string between {0} and {1} characters long."),
		range: $.validator.format("Please enter a value between {0} and {1}."),
		max: $.validator.format("Please enter a maximum value of {0}."),
		min: $.validator.format("Please enter a minimum value of {0}.")
	});
}(jQuery));

jQuery.validator.addMethod("ip", function(value, element) {
	return this.optional(element) || (/^(\d+)\.(\d+)\.(\d+)\.(\d+)$/.test(value) && (RegExp.$1 <256 && RegExp.$2<256 && RegExp.$3<256 && RegExp.$4<256));   
}, "Please enter a valid IP address.");

jQuery.validator.addMethod("abc",function(value, element) {
	return this.optional(element) || /^[a-zA-Z0-9_]*$/.test(value);
},"Please enter alphanumeric or underscore");

jQuery.validator.addMethod("username",function(value, element) {
	return this.optional(element) || /^[a-zA-Z0-9][a-zA-Z0-9_]{2,19}$/.test(value);
},"3-20 letters or numbers at the beginning, which allows alphanumeric characters and underscores");

jQuery.validator.addMethod("noEqualTo",function(value, element, param) {
	return value != $(param).val();
},"Please re-enter a different value");


jQuery.validator.addMethod("realName", function(value, element) {
    return this.optional(element) || /^[\u4e00-\u9fa5]{2,30}$/.test(value);
}, "Name can only be 2-30 characters");


jQuery.validator.addMethod("userName", function(value, element) {
    return this.optional(element) || /^[\u0391-\uFFE5\w]+$/.test(value);
}, "Login names can only consist of text, letters, numbers and underscores");


jQuery.validator.addMethod("mobile", function(value, element) {
    var length = value.length;
    return this.optional(element) || (length == 11 && /^(((13[0-9]{1})|(15[0-9]{1}))+\d{8})$/.test(value));
}, "Please fill in your correct phone number");


jQuery.validator.addMethod("simplePhone", function(value, element) {
    var tel = /^(\d{3,4}-?)?\d{7,9}$/g;
    return this.optional(element) || (tel.test(value));
}, "Please fill in your correct phone number");


jQuery.validator.addMethod("zipCode", function(value, element) {
    var tel = /^[0-9]{6}$/;
    return this.optional(element) || (tel.test(value));
}, "Please fill in your correct postal code");


jQuery.validator.addMethod("qq", function(value, element) {
    var tel = /^[1-9][0-9]{4,}$/;
    return this.optional(element) || (tel.test(value));
}, "Please fill in your correct QQ number");
 

jQuery.validator.addMethod("card",function(value, element) {
	return this.optional(element) || checkIdcard(value);
},"Enter the correct ID number (15-18 bits)")

} 