﻿
/* jBox Configure */
var jBoxConfig = {};

jBoxConfig.defaults = {
    id: null, 
    top: '15%', 
    border: 5, 
    opacity: 0.05, 
    timeout: 0, 
    showType: 'fade', 
    showSpeed: 'fast', 
    showIcon: false,
    showClose: true, 
    draggable: true, 
    dragLimit: false, 
    dragClone: false, 
    persistent: false, 
    showScrolling: true, 
    ajaxData: {}, 
    iframeScrolling: 'auto', 

    title: '&nbsp;Message', 
    width: 350, 
    height: 'auto', 
    bottomText: '', 
    buttons: { 'OK': 'ok' }, 
    buttonsFocus: 0, 
    loaded: function (h) { }, 
    submit: function (v, h, f) { return true; }, 
    closed: function () { }
};

jBoxConfig.stateDefaults = {
    content: '', 
    buttons: { 'OK': 'ok' },
    buttonsFocus: 0,
    submit: function (v, h, f) { return true; } 
};

jBoxConfig.tipDefaults = {
    content: '', 
    icon: 'info', 
    top: '40%',
    width: 'auto',
    height: 'auto', 
    opacity: 0, 
    timeout: 3000, 
    closed: function () { } 
};

jBoxConfig.messagerDefaults = {
    content: '',
    title: 'jBox',
    icon: 'none', 
    width: 350, 
    height: 'auto',
    timeout: 3000, 
    showType: 'slide',
    showSpeed: 600, 
    border: 0, 
    buttons: {},
    buttonsFocus: 0,
    loaded: function (h) { },
    submit: function (v, h, f) { return true; }, 
    closed: function () { } 
};

jBoxConfig.languageDefaults = {
    close: 'Close', 
    ok: 'OK', 
    yes: 'Yes', 
    no: 'No',
    cancel: 'Cancel' 
};

$.jBox.setDefaults(jBoxConfig);
