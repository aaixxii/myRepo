/*-----------------------------------------------------------------------------------------/
 * JQuery PlugIn - Slide Show(or, Switch Tab) Written By KEVIN SHEEP(http://www.ks-pe.com)
 * Based On JQuery 1.2.6+
 *
/*----------------------------------------------------------------------------------------*/

jQuery.fn.switchTab = function(settings) {
	settings = jQuery.extend({
		defaultIndex: 0,
		titOnClassName: "on",
		titCell: "dt span",
		mainCell: "dd",
		delayTime: 250,
		interTime: 0,
		trigger: "click",
		effect: "",
		omitLinks: false,
		debug: ""
	},
	settings,
	{
		version: 130
	});

	this.each(function() {
		var st;
		var curTagIndex = -1;
		var obj = jQuery(this);
		if(settings.omitLinks){
			settings.titCell = settings.titCell + "[href^='#']";
		}
		var oTit = obj.find(settings.titCell);
		var oMain = obj.find(settings.mainCell);
		var cellCount = oTit.length;
		var ShowSTCon = function (oi){
			if(oi != curTagIndex){
				oTit.eq(curTagIndex).removeClass(settings.titOnClassName);
				oMain.hide();
				obj.find(settings.titCell + ":eq(" + oi + ")").addClass(settings.titOnClassName);
				if(settings.delayTime <250 && settings.effect != "")settings.effect = "";
				if(settings.effect == "fade"){
					obj.find(settings.mainCell + ":eq(" + oi + ")").fadeIn({queue: false, duration: 250});
				}else if(settings.effect == "slide"){
					obj.find(settings.mainCell + ":eq(" + oi + ")").slideDown({queue: false, duration: 250});
				}else{
					obj.find(settings.mainCell + ":eq(" + oi + ")").show();
				}
				curTagIndex = oi;
			}
		};
		
		var ShowNext = function (){
			oTit.eq(curTagIndex).removeClass(settings.titOnClassName);
			oMain.hide();
			if(++curTagIndex >= cellCount)curTagIndex = 0;
			oTit.eq(curTagIndex).addClass(settings.titOnClassName);
			oMain.eq(curTagIndex).show();
			//ShowSTCon(curTagIndex);
		};
		
		
		if(settings.defaultIndex >= 0)ShowSTCon(settings.defaultIndex);

		//
		if(settings.interTime > 0){
			var sInterval = setInterval(function(){
				ShowNext();
			}, settings.interTime);
		}

		
		oTit.each(function(i, ele){
			if(settings.trigger=="click"){
				jQuery(ele).click(function(){
					ShowSTCon(i);
					return false;
				});
			}else if(settings.delayTime > 0){
				jQuery(ele).hover(function(){
					st = setTimeout(function(){
						ShowSTCon(i);
						st = null;
					}, settings.delayTime);
				},function(){
					if(st!=null)clearTimeout(st);
				});
			}else{
				jQuery(ele).mouseover(function(){
					ShowSTCon(i);
				});
				if(settings.defaultIndex < 0){
					jQuery(ele).mouseout(function(){
						oTit.removeClass(settings.titOnClassName);
						oMain.hide();						
					});
				}
			}
		});
	});
	if(settings.debug!="")alert(settings[settings.debug]);
	return this;
};