/*
 * The MIT License
 * 
 * Copyright (c) 2004-2010, Sun Microsystems, Inc., Kohsuke Kawaguchi,
 * Daniel Dyer, Yahoo! Inc., Alan Harder, InfraDNA, Inc.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
//
//
// JavaScript for Jenkins
//     See http://www.ibm.com/developerworks/web/library/wa-memleak/?ca=dgr-lnxw97JavascriptLeaks
//     for memory leak patterns and how to prevent them.
//
//
// Auto-scroll support for progressive log output.
//   See http://radio.javaranch.com/pascarello/2006/08/17/1155837038219.html
//
function AutoScroller(scrollContainer) {
	// get the height of the viewport.
	// See http://www.howtocreate.co.uk/tutorials/javascript/browserwindow
	function getViewportHeight() {
		if (typeof (window.innerWidth) == 'number') {
			// Non-IE
			return window.innerHeight;
		} else if (document.documentElement
				&& (document.documentElement.clientWidth || document.documentElement.clientHeight)) {
			// IE 6+ in 'standards compliant mode'
			return document.documentElement.clientHeight;
		} else if (document.body
				&& (document.body.clientWidth || document.body.clientHeight)) {
			// IE 4 compatible
			return document.body.clientHeight;
		}
		return null;
	}

	return {
		bottomThreshold : 25,
		scrollContainer : scrollContainer,

		getCurrentHeight : function() {
			var scrollDiv = this.scrollContainer;

			if (scrollDiv.scrollHeight > 0)
				return scrollDiv.scrollHeight;
			else if (scrollDiv.offsetHeight > 0)
				return scrollDiv.offsetHeight;

			return null; // huh?
		},

		// return true if we are in the "stick to bottom" mode
		isSticking : function() {
			var scrollDiv = this.scrollContainer;
			var currentHeight = this.getCurrentHeight();

			// when used with the BODY tag, the height needs to be the viewport
			// height, instead of
			// the element height.
			// var height = ((scrollDiv.style.pixelHeight) ?
			// scrollDiv.style.pixelHeight : scrollDiv.offsetHeight);
			var height = getViewportHeight();
			var scrollPos = Math.max(scrollDiv.scrollTop,
					document.documentElement.scrollTop);
			var diff = currentHeight - scrollPos - height;
			/*window
					.alert("diff=" + diff + ", currentHeight=" + currentHeight
							+ ",scrollTop=" + scrollDiv.scrollTop + ",height="
							+ height);*/

			return diff < this.bottomThreshold;
		},

		scrollToBottom : function() {
			var scrollDiv = this.scrollContainer;
			var currentHeight = this.getCurrentHeight();
			if (document.documentElement)
				document.documentElement.scrollTop = currentHeight
			scrollDiv.scrollTop = currentHeight;
		}
	};
}
