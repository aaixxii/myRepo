package jp.co.nec.aim.sm.common.properties;

import jp.co.nec.aim.sm.common.utils.PropertiesUtil;

public class JdbcProperties {

	private static PropertiesUtil jdbcLoader;

	public static String getConfig(String key) {
		if (jdbcLoader == null) {
			jdbcLoader = new PropertiesUtil("jdbc.properties");
		}

		return jdbcLoader.getProperty(key);
	}

	public static String getDriver() {
		return getConfig("oracle.jdbc.driver");
	}

	public static String getUrl() {
		return getConfig("oracle.jdbc.url");
	}

	public static String getUserName() {
		return getConfig("oracle.jdbc.username");
	}

	public static String getPassword() {
		return getConfig("oracle.jdbc.password");
	}

	public static String getMaxActive() {
		return getConfig("oracle.jdbc.maxActive");
	}

	public static String getInitialSize() {
		return getConfig("oracle.jdbc.initialSize");
	}
}
