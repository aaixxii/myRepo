package jp.co.nec.aim.sm.common.properties;

import jp.co.nec.aim.sm.common.utils.PropertiesUtil;

public class ApplicationProperties {
	private static PropertiesUtil propertiesLoader;

	public static String getConfig(String key) {
		if (propertiesLoader == null) {
			propertiesLoader = new PropertiesUtil("application.properties");
		}
		return propertiesLoader.getProperty(key);
	}

	public static String getSmVersion() {
		return getConfig("smVersion");
	}
}
