package jp.co.nec.aim.sm.common.constant;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.EXTRACT;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.EXTRACT_LINE_POINT_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.EXTRACT_LINE_STROKE_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.FDB;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.FDB_BAR_STROKE_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.FI;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.FI_LINE_POINT_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.IDB;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.IDB_BAR_STROKE_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.II;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.II_LINE_POINT_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.LATENT_FUNCTION;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.LATENT_FUNCTION_FILL_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.LATENT_FUNCTION_STROKE_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.LDB;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.LDBM;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.LDBM_BAR_STROKE_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.LDBS;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.LDBS_BAR_FILL_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.LDBS_BAR_STROKE_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.LDBX;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.LDBX_BAR_FILL_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.LDBX_BAR_STROKE_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.LDB_BAR_STROKE_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.LI;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.LIM;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.LIM_LINE_POINT_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.LIM_LINE_STROKE_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.LIP;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.LIP_LINE_POINT_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.LIP_LINE_STROKE_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.LIS;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.LIS_LINE_POINT_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.LIS_LINE_STROKE_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.LIX;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.LIX_LINE_POINT_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.LIX_LINE_STROKE_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.LI_LINE_POINT_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.LI_LINE_STROKE_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.LLI;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.LLIM;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.LLIM_LINE_POINT_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.LLIM_LINE_STROKE_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.LLIP;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.LLIP_LINE_POINT_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.LLIP_LINE_STROKE_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.LLIS;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.LLIS_LINE_POINT_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.LLIS_LINE_STROKE_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.LLIX;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.LLIX_LINE_POINT_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.LLIX_LINE_STROKE_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.LLI_LINE_POINT_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.LLI_LINE_STROKE_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.PDB;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.PDB_BAR_STROKE_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.PLDB;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.PLDB_BAR_FILL_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.PLDB_BAR_STROKE_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.PRINT_FUNCTION;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.PRINT_FUNCTION_FILL_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.PRINT_FUNCTION_STROKE_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.RDBL;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.RDBLM;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.RDBLM_BAR_STROKE_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.RDBLS;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.RDBLS_BAR_STROKE_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.RDBL_BAR_STROKE_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.SDBL;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.SDBLM;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.SDBLM_BAR_STROKE_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.SDBLS;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.SDBLS_BAR_STROKE_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.SDBL_BAR_STROKE_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.TI;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.TIM;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.TIM_LINE_POINT_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.TIM_LINE_STROKE_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.TI_LINE_POINT_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.TI_LINE_STROKE_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.TLI;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.TLIM;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.TLIM_LINE_POINT_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.TLIP;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.TLIP_LINE_POINT_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.TLIP_LINE_STROKE_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.TLIS;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.TLIS_LINE_POINT_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.TLIS_LINE_STROKE_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.TLIX;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.TLI_LINE_POINT_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.XDBL;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.XDBL_BAR_STROKE_COLOR;

public enum ChartColorEnum {	
	
	TI_COLOR(TI,TI_LINE_STROKE_COLOR,TI_LINE_POINT_COLOR),
	TIM_COLOR(TIM,TIM_LINE_STROKE_COLOR,TIM_LINE_POINT_COLOR),
	TLI_COLOR(TLI,TI_LINE_STROKE_COLOR,TLI_LINE_POINT_COLOR),
	TLIS_COLOR(TLIS,TLIS_LINE_STROKE_COLOR,TLIS_LINE_POINT_COLOR),
	TLIM_COLOR(TLIM,TI_LINE_STROKE_COLOR,TLIM_LINE_POINT_COLOR),
	TLIX_COLOR(TLIX,TI_LINE_STROKE_COLOR,TI_LINE_POINT_COLOR),
	TLIP_COLOR(TLIP,TLIP_LINE_STROKE_COLOR,TLIP_LINE_POINT_COLOR),
	FI_COLOR(FI,TI_LINE_STROKE_COLOR,FI_LINE_POINT_COLOR),
	II_COLOR(II,TI_LINE_STROKE_COLOR,II_LINE_POINT_COLOR),
	LI_COLOR(LI,LI_LINE_STROKE_COLOR,LI_LINE_POINT_COLOR),
	LIS_COLOR(LIS,LIS_LINE_STROKE_COLOR,LIS_LINE_POINT_COLOR),
	LIM_COLOR(LIM,LIM_LINE_STROKE_COLOR,LIM_LINE_POINT_COLOR),
	LIX_COLOR(LIX,LIX_LINE_STROKE_COLOR,LIX_LINE_POINT_COLOR),
	LLI_COLOR(LLI,LLI_LINE_STROKE_COLOR,LLI_LINE_POINT_COLOR),
	LLIS_COLOR(LLIS,LLIS_LINE_STROKE_COLOR,LLIS_LINE_POINT_COLOR),
	LLIM_COLOR(LLIM,LLIM_LINE_STROKE_COLOR,LLIM_LINE_POINT_COLOR),
	LLIX_COLOR(LLIX,LLIX_LINE_STROKE_COLOR,LLIX_LINE_POINT_COLOR),	
	LIP_COLOR(LIP,LIP_LINE_STROKE_COLOR,LIP_LINE_POINT_COLOR),	
	LLIP_COLOR(LLIP,LLIP_LINE_STROKE_COLOR,LLIP_LINE_POINT_COLOR),
	EXTRACT_COLOR(EXTRACT,EXTRACT_LINE_STROKE_COLOR,EXTRACT_LINE_POINT_COLOR),
	
	PRINT_FUNCTION_COLOR(PRINT_FUNCTION,PRINT_FUNCTION_FILL_COLOR,PRINT_FUNCTION_STROKE_COLOR),
	LATENT_FUNCTION_COLOR(LATENT_FUNCTION,LATENT_FUNCTION_FILL_COLOR,LATENT_FUNCTION_STROKE_COLOR),
	
	LDBX_COLOR(LDBX,LDBX_BAR_FILL_COLOR,LDBX_BAR_STROKE_COLOR),
	PLDB_COLOR(PLDB,PLDB_BAR_FILL_COLOR,PLDB_BAR_STROKE_COLOR),
	FDB_COLOR(FDB,LDBX_BAR_FILL_COLOR,FDB_BAR_STROKE_COLOR),
	IDB_COLOR(IDB,LDBX_BAR_FILL_COLOR,IDB_BAR_STROKE_COLOR),
	RDBL_COLOR(RDBL,LDBX_BAR_FILL_COLOR,RDBL_BAR_STROKE_COLOR),
	SDBL_COLOR(SDBL,LDBX_BAR_FILL_COLOR,SDBL_BAR_STROKE_COLOR),
	RDBLS_COLOR(RDBLS,LDBX_BAR_FILL_COLOR,RDBLS_BAR_STROKE_COLOR),
	SDBLS_COLOR(SDBLS,LDBX_BAR_FILL_COLOR,SDBLS_BAR_STROKE_COLOR),
	RDBLM_COLOR(RDBLM,LDBX_BAR_FILL_COLOR,RDBLM_BAR_STROKE_COLOR),
	SDBLM_COLOR(SDBLM,LDBX_BAR_FILL_COLOR,SDBLM_BAR_STROKE_COLOR),
	XDBL_COLOR(XDBL,LDBX_BAR_FILL_COLOR,XDBL_BAR_STROKE_COLOR),
	LDB_COLOR(LDB,LDBX_BAR_FILL_COLOR,LDB_BAR_STROKE_COLOR),
	LDBS_COLOR(LDBS,LDBS_BAR_FILL_COLOR,LDBS_BAR_STROKE_COLOR),
	LDBM_COLOR(LDBM,LDBX_BAR_FILL_COLOR,LDBM_BAR_STROKE_COLOR),
	PDB_COLOR(PDB,LDBX_BAR_FILL_COLOR,PDB_BAR_STROKE_COLOR);
	
	ChartColorEnum(String name,String strokeColor,String pointColor) {
		this.name = name;
		this.strokeColor = strokeColor;
		this.pointColor = pointColor;		
	}
	private String name;
	private String strokeColor;
	private String pointColor;
	public String getStrokeColor() {
		return strokeColor;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setStrokeColor(String strokeColor) {
		this.strokeColor = strokeColor;
	}
	public String getPointColor() {
		return pointColor;
	}
	public void setPointColor(String pointColor) {
		this.pointColor = pointColor;
	}
	
	
	public static ChartColorEnum getChartColorValue(String name) {
		for (ChartColorEnum color : ChartColorEnum.values()) {
			if (name.equals(color.getName())) {
				return color;
				}
		}
		return null;
	}	
}
