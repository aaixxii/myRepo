package jp.co.nec.aim.sm.mm.listener;

/**
 * 
 */
public interface SystemManagerIfc {
	public static final String EVENTCODE_INFO = "100000";
	public static final String EVENTCODE_WARN = "200000";
	public static final String EVENTCODE_ALERT = "300000";
	public static final String EVENTCODE_ERROR = "400000";
	public static final String EVENTCODE_EMERGENCY = "500000";

	public static final String REPLACE_CHARS[] = { "'", "," };
	public static final String REPLACE_BY_CHARS[] = { "~", "-" };

	public static final int WORKING = 1;
	public static final int STOPPED = 0;
	public static final int UNLIMITED_REATTEMPT = -1;
	public static final String QUEUE_TYPE_ERROR = "ERROR";
	public static final String QUEUE_TYPE_INFO = "INFO";
	public static final String NOTIFY_STATUS_ERROR = "ERROR";

	public static final Long UNKNOWN_MUID = 0l;
}
