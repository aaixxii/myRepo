package jp.co.nec.aim.sm.modules.sys.oracle.repository;

import java.util.ArrayList;
import java.util.List;

import jp.co.nec.aim.sm.common.constant.UnitState;
import jp.co.nec.aim.sm.common.constant.UnitType;
import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.common.utils.SMUtil;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.MatchManagerEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.MatchUnitEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.MatchUnitUnionMatchUnitContact;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.UnitPojo;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * EventLogRepositoryImpl interface
 */
public class MatchUnitRepositoryImpl {

	@Autowired
	MatchManagerRepository matchmanagerrepository;

	@Autowired
	MatchUnitRepository unitrepository;

	private static String matchUnitUnionMatchUnitContactsql = "select  mu.mu_id as muId, mu.unique_id as uniqueId, mu.contact_url as contactURL, mu.state as state,"
			+ " 'MU' as type, mu.primary_size as primarySize, mu.secondary_size as secondarySize,"
			+ " mu.reported_performance_factor as reportedPerformanceFactor,"
			+ " mu.number_of_matchers as numberOfMatchers,"
			+ " mu.number_of_extractors as numberOfExtractors,"
			+ " mu.version as version,"
			+ " mc.contact_ts as contact_ts  from  MATCH_UNITS mu "
			+ " left join MU_CONTACTS mc  on mu.MU_ID=mc.MU_ID ";

	private static String DMUnionDMContactsql = "select dm.dm_id as muid "
			+ "      ,dm.unique_id as uniqueid"
			+ "      ,dm.contact_url as contacturl"
			+ "      ,dm.state as state" + "      ,'DM' as type"
			+ "      ,'' as primarysize" + "      ,'' as secondarysize"
			+ "      ,'' as reportedperformancefactor"
			+ "      ,'' as numberofmatchers"
			+ "      ,'' as numberofextractors"
			+ "      ,dm.version as version"
			+ "      ,dc.contact_ts as contact_ts" + "  from data_managers dm"
			+ "  left join dm_contacts dc on dm.dm_id=dc.dm_id ";

	private static String MRUnionMRContactsql = "select mr.mr_id as muid "
			+ "      ,mr.unique_id as uniqueid"
			+ "      ,mr.contact_url as contacturl"
			+ "      ,mr.state as state" + "      ,'MR' as type"
			+ "      ,'' as primarysize" + "      ,'' as secondarysize"
			+ "      ,'' as reportedperformancefactor"
			+ "      ,'' as numberofmatchers"
			+ "      ,'' as numberofextractors"
			+ "      ,mr.version as version"
			+ "      ,mc.contact_ts as contact_ts" + "  from map_reducers mr"
			+ "  left join mr_contacts mc on mr.mr_id=mc.mr_id ";

	private static String SMUnionSMContactsql = "select sm.sm_id as muid "
			+ "      ,sm.unique_id as uniqueid"
			+ "      ,sm.contact_url as contacturl"
			+ "      ,sm.state as state" + "      ,'SM' as type"
			+ "      ,'' as primarysize" + "      ,'' as secondarysize"
			+ "      ,'' as reportedperformancefactor"
			+ "      ,'' as numberofmatchers"
			+ "      ,'' as numberofextractors"
			+ "      ,sm.version as version" + "      ,'' as contact_ts"
			+ "  from SYSTEM_MANAGERS sm";

	private static String MMSQL = "select MM_ID as id, UNIQUE_ID as uniqueId,CONTACT_URL as contactURL,STATE as state,'MM' as type,VERSION as version from MATCH_MANAGERS";
	private static String MUSQL = "select MU_ID as id, UNIQUE_ID as uniqueId,CONTACT_URL as contactURL,STATE as state,'MU' as type,VERSION as version from MATCH_UNITS ";
	private static String DMSQL = "select DM_ID as id, UNIQUE_ID as uniqueId,CONTACT_URL as contactURL,STATE as state,'DM' as type,VERSION as version from DATA_MANAGERS ";
	private static String MRSQL = "select MR_ID as id, UNIQUE_ID as uniqueId,CONTACT_URL as contactURL,STATE as state,'MR' as type,VERSION as version from MAP_REDUCERS ";
	private static String SMSQL = "select SM_ID as id, UNIQUE_ID as uniqueId,CONTACT_URL as contactURL,STATE as state,'SM' as type,VERSION as version from SYSTEM_MANAGERS ";

	/**
	 * Get MM Unit via muId
	 * 
	 * @param muId
	 * @return
	 */
	public MatchManagerEntity getMMbyMuId(Long mmId) {
		MatchManagerEntity mm = matchmanagerrepository.findOne(mmId);
		return mm;
	}

	/**
	 * Get not MM Unit via muId
	 * 
	 * @param muId
	 * @return
	 */
	public MatchUnitUnionMatchUnitContact getUnitbyMuId(Long muId, String type) {
		String sqlString = null;
		if (type.equals(UnitType.MU.name())) {
			sqlString = matchUnitUnionMatchUnitContactsql;
			sqlString += " where mu.MU_ID=" + muId;
		} else if (type.equals(UnitType.MR.name())) {
			sqlString = MRUnionMRContactsql;
			sqlString += " where mr.MR_ID=" + muId;
		} else if (type.equals(UnitType.DM.name())) {
			sqlString = DMUnionDMContactsql;
			sqlString += " where dm.DM_ID=" + muId;
		} else if (type.equals(UnitType.SM.name())) {
			sqlString = SMUnionSMContactsql;
			sqlString += " where sm.SM_ID=" + muId;
		}
		List<MatchUnitUnionMatchUnitContact> unit = unitrepository.findBySql(
				sqlString, MatchUnitUnionMatchUnitContact.class);
		if (SMUtil.isListNullOrEmpty(unit)) {
			return null;
		}
		return unit.get(0);
	}

	/**
	 * Get ALL MU Units
	 * 
	 * @return
	 */
	public List<UnitPojo> getAllMUUnits() {
		String sqlString = MUSQL;
		List<UnitPojo> mu = unitrepository.findBySql(sqlString, UnitPojo.class);
		return mu;
	}

	/**
	 * Get ALL WORKING MU Units
	 * 
	 * @return
	 */
	public List<UnitPojo> getAllWorkingMUUnits() {
		String sqlString = MUSQL;
		sqlString += "where STATE = 'WORKING'";
		List<UnitPojo> mu = unitrepository.findBySql(sqlString, UnitPojo.class);
		return mu;
	}


	/**
	 * Get ALL WORKING MR Units
	 * 
	 * @return
	 */
	public List<UnitPojo> getAllWorkingMRUnits()
	{
		String sqlString = MRSQL;
		sqlString += "where STATE = 'WORKING'";
		List<UnitPojo> mr = unitrepository.findBySql(sqlString, UnitPojo.class);
		return mr;
	}
	/**
	 * Get ALL Units and pagination
	 * 
	 * @param page
	 * @param unit
	 * @return
	 */
	public Page<UnitPojo> findPIDUnitPojo(Page<UnitPojo> page,
			MatchUnitEntity unit, boolean hasSM) {
		List<UnitPojo> pidunitpojolist = findPIDUnitPojolist(unit, hasSM);
		Page<UnitPojo> pidpage = setPageList(pidunitpojolist, page);
		return pidpage;
	}

	/**
	 * Get ALL Units
	 * 
	 * @param unit
	 * @return
	 */
	public List<UnitPojo> findPIDUnitPojolist(MatchUnitEntity unit,
			boolean hasSM) {
		List<UnitPojo> mm = new ArrayList<UnitPojo>();
		List<UnitPojo> mu = new ArrayList<UnitPojo>();
		List<UnitPojo> dm = new ArrayList<UnitPojo>();
		List<UnitPojo> sm = new ArrayList<UnitPojo>();
		List<UnitPojo> mr = new ArrayList<UnitPojo>();

		final UnitType type = unit.getType();
		if (!SMUtil.isObjectNull(type)) {
			switch (type) {
			case MM:
				mm = getMM(unit);
				break;
			case DM:
				dm = getDM(unit);
				break;
			case SM:
				sm = getSM(unit);
				break;
			case MU:
				mu = getMU(unit);
				break;
			case MR:
				mr = getMR(unit);
			default:
				break;
			}
		} else {
			mm = getMM(unit);
			mu = getMU(unit);
			dm = getDM(unit);
			mr = getMR(unit);
			sm = getSM(unit);
		}
		List<UnitPojo> pidunitpojolist = new ArrayList<UnitPojo>();
		if (!SMUtil.isObjectNull(mm)) {
			pidunitpojolist.addAll(mm);
		}
		if (!SMUtil.isObjectNull(mu)) {
			pidunitpojolist.addAll(mu);
		}
		if (!SMUtil.isObjectNull(dm)) {
			pidunitpojolist.addAll(dm);
		}

		if (!SMUtil.isObjectNull(mr)) {
			pidunitpojolist.addAll(mr);
		}

		if (!SMUtil.isObjectNull(sm) && hasSM) {
			pidunitpojolist.addAll(sm);
		}

		return pidunitpojolist;
	}

	/**
	 * Set pagination
	 * 
	 * @param list
	 * @param page
	 * @return
	 */
	private <T> Page<T> setPageList(List<T> list, Page<T> page) {
		int size = list.size();
		// get count
		if (!page.isDisabled() && !page.isNotCount()) {
			page.setCount(size);
			if (page.getCount() < 1) {
				return page;
			}
		}

		List<T> tmp = new ArrayList<T>();
		if (!page.isDisabled()) {
			int firstResult = page.getFirstResult();
			int maxResult = page.getMaxResults();
			int lastResult = (firstResult + maxResult) > size ? size
					: (firstResult + maxResult);
			tmp = list.subList(firstResult, lastResult);
		}

		page.setList(tmp);
		return page;
	}

	/**
	 * Get not MM Unit via muId
	 * 
	 * @param muId
	 * @return
	 */
	public List<UnitPojo> getMM(MatchUnitEntity unit) {
		String sqlString = MMSQL;
		if (!SMUtil.isObjectNull(unit)) {
			// add the unit id condition
			final Long unitId = unit.getMuId();
			if (!SMUtil.isObjectNull(unitId)) {
				sqlString += " where MM_ID=" + unitId.toString();
			}
			// add condition unit state
			final UnitState state = unit.getState();
			if (state != null) {
				if (!SMUtil.isObjectNull(unitId)) {
					sqlString += " and ";
				} else {
					sqlString += " where ";
				}
				sqlString += "STATE='" + state.name() + "'";
			}
		}

		List<UnitPojo> mm = unitrepository.findBySql(sqlString, UnitPojo.class);
		if (SMUtil.isListNullOrEmpty(mm)) {
			return null;
		}
		return mm;
	}

	/**
	 * Get All DM
	 * 
	 * @param muId
	 * @return
	 */
	public List<UnitPojo> getDM(MatchUnitEntity unit) {
		String sqlString = DMSQL;
		if (!SMUtil.isObjectNull(unit)) {
			// add the unit id condition
			final Long unitId = unit.getMuId();
			if (!SMUtil.isObjectNull(unitId)) {
				sqlString += " where DM_ID=" + unitId.toString();
			}
			// add condition unit state
			final UnitState state = unit.getState();
			if (state != null) {
				if (!SMUtil.isObjectNull(unitId)) {
					sqlString += " and ";
				} else {
					sqlString += " where ";
				}
				sqlString += "STATE='" + state.name() + "'";
			}
		}

		List<UnitPojo> dm = unitrepository.findBySql(sqlString, UnitPojo.class);
		if (SMUtil.isListNullOrEmpty(dm)) {
			return null;
		}
		return dm;
	}

	/**
	 * Get All MU
	 * 
	 * @param muId
	 * @return
	 */
	public List<UnitPojo> getMU(MatchUnitEntity unit) {
		String sqlString = MUSQL;
		if (!SMUtil.isObjectNull(unit)) {
			// add the unit id condition
			final Long unitId = unit.getMuId();
			if (!SMUtil.isObjectNull(unitId)) {
				sqlString += " where MU_ID=" + unitId.toString();
			}
			// add condition unit state
			final UnitState state = unit.getState();
			if (state != null) {
				if (!SMUtil.isObjectNull(unitId)) {
					sqlString += " and ";
				} else {
					sqlString += " where ";
				}
				sqlString += "STATE= '" + state.name() + "'";
			}
		}

		List<UnitPojo> mu = unitrepository.findBySql(sqlString, UnitPojo.class);
		if (SMUtil.isListNullOrEmpty(mu)) {
			return null;
		}
		return mu;
	}

	/**
	 * Get All MR
	 * 
	 * @param muId
	 * @return
	 */
	public List<UnitPojo> getMR(MatchUnitEntity unit) {
		String sqlString = MRSQL;
		if (!SMUtil.isObjectNull(unit)) {
			// add the unit id condition
			final Long unitId = unit.getMuId();
			if (!SMUtil.isObjectNull(unitId)) {
				sqlString += " where MR_ID=" + unitId.toString();
			}
			// add condition unit state
			final UnitState state = unit.getState();
			if (state != null) {
				if (!SMUtil.isObjectNull(unitId)) {
					sqlString += " and ";
				} else {
					sqlString += " where ";
				}
				sqlString += "STATE= '" + state.name() + "'";
			}
		}

		List<UnitPojo> mu = unitrepository.findBySql(sqlString, UnitPojo.class);
		if (SMUtil.isListNullOrEmpty(mu)) {
			return null;
		}
		return mu;
	}

	/**
	 * Get not MM Unit via muId
	 * 
	 * @param muId
	 * @return
	 */
	public List<UnitPojo> getSM(MatchUnitEntity unit) {
		String sqlString = SMSQL;
		if (!SMUtil.isObjectNull(unit)) {
			// add the unit id condition
			final Long unitId = unit.getMuId();
			if (!SMUtil.isObjectNull(unitId)) {
				sqlString += " where SM_ID=" + unitId.toString();
			}
			// add condition unit state
			final UnitState state = unit.getState();
			if (state != null) {
				if (!SMUtil.isObjectNull(unitId)) {
					sqlString += " and ";
				} else {
					sqlString += " where ";
				}
				sqlString += "STATE='" + state.name() + "'";
			}
		}

		List<UnitPojo> sm = unitrepository.findBySql(sqlString, UnitPojo.class);
		if (SMUtil.isListNullOrEmpty(sm)) {
			return null;
		}
		return sm;
	}
}
