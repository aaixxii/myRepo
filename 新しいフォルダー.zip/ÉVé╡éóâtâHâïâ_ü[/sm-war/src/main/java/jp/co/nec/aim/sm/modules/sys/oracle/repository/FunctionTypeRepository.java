package jp.co.nec.aim.sm.modules.sys.oracle.repository;

import java.util.List;

import jp.co.nec.aim.sm.common.persistence.BaseRepository;
import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.FunctionTypeEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.FunctionTypeTrafficPojo;

public interface FunctionTypeRepository extends
		BaseRepository<FunctionTypeEntity, Long> {
	/** find function type page **/
	public Page<FunctionTypeEntity> findFunctionTypePage(
			Page<FunctionTypeEntity> page, FunctionTypeEntity functionType);

	public Page<FunctionTypeTrafficPojo> findFunctionTypePage1(
			Page<FunctionTypeTrafficPojo> page,
			FunctionTypeTrafficPojo functionType);

	/** find function type List **/
	public List<FunctionTypeEntity> findFunctionType(
			FunctionTypeEntity functionType);

	/** get all function type **/
	public List<String> getAllFunctionType();

	/** get function id by name **/
	public Integer getFunctionId(String functionName);

	/** update Function Type **/
	public int updateFunctionType(Integer functionId, Integer jobLimit,
			Long timeouts, Long muJobTimeouts, Long internalCandidateSize);

	

}
