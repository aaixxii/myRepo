package jp.co.nec.aim.sm.mm.listener;

import java.util.Properties;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageConsumer;
import javax.jms.QueueConnection;
import javax.jms.QueueReceiver;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import jp.co.nec.aim.sm.common.constant.SMConstant;
import jp.co.nec.aim.sm.common.utils.SMUtil;
import jp.co.nec.aim.sm.mm.listener.reattempt.MatchManagerReattempt;

import org.jboss.naming.remote.client.RemoteContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Strings;

/**
 * QueueRunner
 * 
 * @author liuyq
 *
 */
public class QueueRunner extends Thread {

	private QueueInformation info;
	private QueueConnection connection;
	private QueueSession session;
	private QueueReceiver reciever;
	private MatchManagerQueueListener matchManagerQueueListener;
	private MatchManagerReattempt matchManagerReattempt = new MatchManagerReattempt();
	private Integer queueStatus = 1;
	private static final Logger log = LoggerFactory
			.getLogger(QueueRunner.class);

	private static final String DEFAULT_CONNECTION_FACTORY = "jms/RemoteConnectionFactory";
	private static final String DEFAULT_DESTINATION_PREFIX = "queue/"; // "java:/jms/queue/infoQueue";
	private static final String DEFAULT_USERNAME = "jmsuser";
	private static final String DEFAULT_PASSWORD = "jmsuser";
	private static final String INITIAL_CONTEXT_FACTORY = "org.jboss.naming.remote.client.InitialContextFactory";

	@SuppressWarnings("unused")
	private QueueRunner() {
	}

	public QueueRunner(QueueInformation queueInformation,
			MatchManagerQueueListener matchManagerQueueListener) {
		this.info = queueInformation;
		this.matchManagerQueueListener = matchManagerQueueListener;

	}

	/**
	 * @return the queueInformation
	 */
	public QueueInformation getQueueInformation() {
		return info;
	}

	/**
	 * @param info
	 *            the queueInformation to set
	 */
	public void setQueueInformation(QueueInformation info) {
		this.info = info;
	}

	public void run() {
		if (SMUtil.isObjectNull(SMConstant.getSM_ID())) {
			matchManagerQueueListener.notifyStatus(info.getQueueID(), "ERROR");
			return;
		}

		ConnectionFactory connectionFactory = null;
		Connection connection = null;
		Session session = null;
		MessageConsumer consumer = null;
		Destination destination = null;
		Context context = null;
		RemoteContext remoteContext = null;

		try {
			// Set up the context for the JNDI lookup
			final Properties env = new Properties();
			env.put(Context.INITIAL_CONTEXT_FACTORY, INITIAL_CONTEXT_FACTORY);
			String providerUrl = "http-remoting://" + info.getQueueHostname()
					+ ":" + info.getQueuePort();
			env.put(Context.PROVIDER_URL,
					System.getProperty(Context.PROVIDER_URL, providerUrl));
			env.put(Context.SECURITY_PRINCIPAL,
					System.getProperty(
							"username",
							Strings.isNullOrEmpty(info.getUserName()) ? DEFAULT_USERNAME
									: info.getUserName()));
			env.put(Context.SECURITY_CREDENTIALS,
					System.getProperty(
							"password",
							Strings.isNullOrEmpty(info.getPassword()) ? DEFAULT_PASSWORD
									: info.getPassword()));
			context = new InitialContext(env);

			// Perform the JNDI lookups
			String connectionFactoryString = System.getProperty(
					"connection.factory", DEFAULT_CONNECTION_FACTORY);
			log.info("Attempting to acquire connection factory \""
					+ connectionFactoryString + "\"");
			connectionFactory = (ConnectionFactory) context
					.lookup(connectionFactoryString);
			log.info("Found connection factory \"" + connectionFactoryString
					+ "\" in JNDI");

			String queueName = DEFAULT_DESTINATION_PREFIX + info.getQueueName();
			log.info("Attempting to acquire Queue \"" + queueName + "\"");
			remoteContext = (RemoteContext) context.lookup("jms");
			destination = (Destination) remoteContext.lookup(queueName);
			log.info("Found Queue \"" + queueName + "\" in JNDI");

			// Create the JMS connection, session, producer, and consumer
			connection = connectionFactory.createConnection(
					System.getProperty("username", DEFAULT_USERNAME),
					System.getProperty("password", DEFAULT_PASSWORD));
			session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);

			// create the consumer
			consumer = session.createConsumer(destination);

			// set the consumer message listener to specified listener
			consumer.setMessageListener(info.getMessageListener());

			// set the connection exception listener
			connection.setExceptionListener(info.getExceptionListener());

			// set the queue status to listening
			queueStatus = 1;

			log.info("start Queue Listener:" + info.getQueueName());
			// start the connection's each session
			connection.start();

		} catch (Exception ex) {
			shut();

			// output the log information
			log.error("init the queue: " + info.getQueueName()
					+ " exception occurred..", ex);

			// set the queue status to exception level
			queueStatus = 0;
			matchManagerReattempt.logError("QueueRunner:start(), "
					+ "found jms communication failure,"
					+ " error description: " + ex.getMessage());
			matchManagerQueueListener.notifyStatus(info.getQueueID(), "ERROR");
		} finally {
			if (remoteContext != null) {
				try {
					remoteContext.close();
				} catch (NamingException e) {
					log.error("NamingException occurred..", e);
				}
			}

			if (context != null) {
				try {
					context.close();
				} catch (NamingException e) {
					log.error("NamingException occurred..", e);
				}
			}

		}

	}

	public void shut() {
		log.info("QueueRunner Shut Down");
		if (reciever != null) {
			try {
				reciever.close();
			} catch (JMSException e) {
				log.warn("JMSException occurred while close receiver", e);
			}
		}

		if (session != null) {
			try {
				session.close();
			} catch (JMSException e) {
				log.warn("JMSException occurred while close session", e);
			}
		}
		/*
		 * The null check ensures that if the queue is started intially but not
		 * able establish connection with current configurations
		 */
		if (connection != null) {
			try {
				connection.stop();
			} catch (JMSException e) {
				matchManagerReattempt.logError("QueueRunner:shut(): found JMS"
						+ " communication failure, error description: "
						+ e.getMessage());
				// e.printStackTrace();
				matchManagerQueueListener.notifyStatus(info.getQueueID(),
						"ERROR");
			}

			// close operation is necessary for shutdown
			// and close operation is different from stop
			try {
				connection.close();
			} catch (JMSException e) {
				log.warn("JMSException occurred while close connection", e);
			}
		}

	}

	/**
	 * @return the queueStatus
	 */
	public Integer getQueueStatus() {
		return queueStatus;
	}
}
