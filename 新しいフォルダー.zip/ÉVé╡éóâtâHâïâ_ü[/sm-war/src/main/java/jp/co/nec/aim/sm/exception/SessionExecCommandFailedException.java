package jp.co.nec.aim.sm.exception;

/**
 * SessionExecCommandFailedException
 * 
 * @author liuyq
 */
public class SessionExecCommandFailedException extends RuntimeException {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -335026656751093927L;

	/**
	 * @param message
	 */
	public SessionExecCommandFailedException(String message) {
		super(message);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public SessionExecCommandFailedException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * @param cause
	 */
	public SessionExecCommandFailedException(Throwable cause) {
		super(cause);
	}
}
