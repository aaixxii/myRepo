package jp.co.nec.aim.sm.modules.sys.oracle.repository;

import java.util.List;

import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.common.utils.SMUtil;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.DataManagerEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.DmEligibleContainerEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.EligibleBinsPojo;

import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

public class DmEligibleBiometricContainerRepositoryImpl {
	/** the log instance **/
	private static Logger logger = LoggerFactory
			.getLogger(EligibleBiometricContainerRepositoryImpl.class);

	@Autowired
	DmEligibleBiometricContainerRepository repository;

	/**
	 * get Detached Criteria
	 * 
	 * @param eligibleBins
	 * @return
	 */
	private DetachedCriteria getDetachedCriteria(
			DmEligibleContainerEntity eligibleBins) {
		// create the DetachedCriteria instance without session
		final DetachedCriteria dc = DetachedCriteria
				.forClass(DmEligibleContainerEntity.class);

		// add condition matchUnitId
		final Long matchUnitId = eligibleBins.getId().getDmId();
		if (!SMUtil.isObjectNull(matchUnitId)) {
			logger.debug("add condition dmId = {}", matchUnitId);
			dc.add(Restrictions.eq("id.dmId", matchUnitId));
		}

		// add condition binId
		final Long binId = eligibleBins.getId().getContainerId();
		if (!SMUtil.isObjectNull(binId)) {
			logger.debug("add condition containerId = {}", binId);
			dc.add(Restrictions.eq("id.containerId", binId));
		}

		return dc;
	}

	/**
	 * find Eligible Biometric Container page
	 * 
	 * @param page
	 * @param eligibleBins
	 * @return
	 */
	public Page<DmEligibleContainerEntity> findDmEligibleBinsPage(
			Page<DmEligibleContainerEntity> page,
			DmEligibleContainerEntity eligibleBins) {
		final DetachedCriteria dc = getDetachedCriteria(eligibleBins);
		// add order by condition
		if (!StringUtils.isNotBlank(page.getOrderBy())) {
			logger.debug("add Order id.muId");
			dc.addOrder(Order.asc("id.dmId"));
			dc.addOrder(Order.asc("id.containerId"));
		}
		logger.debug("find Page for DmEligibleContainerEntity");
		return repository.findPage(page, dc);
	}

	private String getEligibleBinsSql(EligibleBinsPojo eligibleBins) {
		/*
		 * String sql = "SELECT MU_ID as matchUnitId, b.BIN_ID as binId," +
		 * " FORMAT_NAME as format, MIN_REDUNDANCY as minimumRedundancy " +
		 * " from MU_ELIGIBLE_CONTAINERS meb, BINS b, FORMAT_TYPES ft" +
		 * " where meb.BIN_ID=b.BIN_ID and b.FORMAT_ID=ft.FORMAT_ID";
		 */

		String sql = "SELECT DM_ID as matchUnitId, b.CONTAINER_ID as binId,"
				+ " FORMAT_NAME as format, MIN_REDUNDANCY as minimumRedundancy,MIN_MU_NUM_FOR_SLB as minMuNumForSlb,MAX_SEGMENT_SIZE as maxSegmentSize"
				+ " from DM_ELIGIBLE_CONTAINERS meb, CONTAINERS b, FORMAT_TYPES ft"
				+ " where meb.CONTAINER_ID=b.CONTAINER_ID and b.FORMAT_ID=ft.FORMAT_ID";

		Long matchUnitId = eligibleBins.getMatchUnitId();
		if (!SMUtil.isObjectNull(matchUnitId)) {
			sql += " AND DM_ID=" + matchUnitId;
		}

		String binIds = eligibleBins.getBinIds();
		if (StringUtils.isNotBlank(binIds)) {
			sql += " AND meb.CONTAINER_ID in (" + binIds + ")";
		}

		String format = eligibleBins.getFormat();
		if (StringUtils.isNotBlank(format)) {
			sql += " AND FORMAT_NAME=" + format;
		}

		sql += " order by DM_ID, b.CONTAINER_ID";

		return sql;
	}

	public static void main(String[] args) {
		String sql = "SELECT DM_ID as matchUnitId, b.CONTAINER_ID as binId,"
				+ " FORMAT_NAME as format, MIN_REDUNDANCY as minimumRedundancy "
				+ " from DM_ELIGIBLE_CONTAINERS meb, CONTAINERS b, FORMAT_TYPES ft"
				+ " where meb.CONTAINER_ID=b.CONTAINER_ID and b.FORMAT_ID=ft.FORMAT_ID";
		sql += " order by DM_ID, b.CONTAINER_ID";
		//System.out.print(sql);
	}

	/**
	 * find Eligible Biometric Container page
	 * 
	 * @param page
	 * @param eligibleBins
	 * @return
	 */
	public Page<EligibleBinsPojo> findEligibleBinsPage(
			Page<EligibleBinsPojo> page, EligibleBinsPojo eligibleBins) {
		String sql = getEligibleBinsSql(eligibleBins);

		logger.debug("find Page for EligibleBinsPojo: {}", sql);
		return repository.findBySql(page, sql, EligibleBinsPojo.class);
	}

	/**
	 * find Eligible Biometric Container List
	 * 
	 * @param page
	 * @param eligibleBins
	 * @return
	 */
	public List<DmEligibleContainerEntity> findDmEligibleBins(
			DmEligibleContainerEntity eligibleBins) {
		final DetachedCriteria dc = getDetachedCriteria(eligibleBins);
		// add order by condition
		dc.addOrder(Order.asc("id.dmId"));
		dc.addOrder(Order.asc("id.containerId"));

		logger.debug("find List for DmEligibleContainerEntity");
		return repository.find(dc);
	}

	/**
	 * find Eligible Biometric Container List
	 * 
	 * @param page
	 * @param eligibleBins
	 * @return
	 */
	public List<EligibleBinsPojo> findEligibleBins(EligibleBinsPojo eligibleBins) {
		String sql = getEligibleBinsSql(eligibleBins);		
		return repository.findBySql(sql, EligibleBinsPojo.class);
	}

	/**
	 * assign Match Unit Eligible Biometric Container
	 * 
	 * @param eligibleBins
	 * @return
	 */
	public void assignDmBin(Long matchUnitId, String binIds) {
		String sql = "insert into DM_ELIGIBLE_CONTAINERS(DM_ID, CONTAINER_ID) select "
				+ matchUnitId
				+ ", CONTAINER_ID from CONTAINERS where CONTAINER_ID not in ("
				+ "select CONTAINER_ID from DM_ELIGIBLE_CONTAINERS where DM_ID ="
				+ matchUnitId + ")";
		if (StringUtils.isNotBlank(binIds)) {
			sql += " and CONTAINER_ID in (" + binIds + ")";
		}
		repository.updateBySql(sql);
		repository.flush();
	}

	/**
	 * unAssign Match Unit Eligible Biometric Container
	 * 
	 * @param eligibleBins
	 */
	public void unAssignDmBin(Long matchUnitId, String binIds) {
		String sql = "delete from DM_ELIGIBLE_CONTAINERS where DM_ID="
				+ matchUnitId;
		if (StringUtils.isNotBlank(binIds)) {
			sql += " and CONTAINER_ID in (" + binIds + ")";
		}
		repository.updateBySql(sql);
		repository.flush();
	}
	
	public DataManagerEntity findDmEtifyById(long dmId) {
		return repository.getEntityManager().find(DataManagerEntity.class, dmId);		
	}
}
