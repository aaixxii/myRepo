package jp.co.nec.aim.sm.modules.sys.postgres.pojo.mapping;

import java.io.Serializable;

import jp.co.nec.aim.sm.common.annocation.FieldMapped;
import jp.co.nec.aim.sm.common.annocation.InquiryMapping;

@InquiryMapping
public class UserTrackPojo implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -3785979229081661279L;

	@FieldMapped
	private String userName;

	@FieldMapped
	private String userRole;

	@FieldMapped
	private String loginType;

	@FieldMapped
	private String timestamp;

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

	public String getUserRole() {
		return userRole;
	}

	public void setLoginType(String loginType) {
		this.loginType = loginType;
	}

	public String getLoginType() {
		return loginType;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	public String getTimestamp() {
		return timestamp;
	}

}
