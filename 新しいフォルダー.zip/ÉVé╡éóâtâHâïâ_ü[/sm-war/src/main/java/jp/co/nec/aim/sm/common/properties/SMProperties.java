package jp.co.nec.aim.sm.common.properties;

import jp.co.nec.aim.sm.common.utils.PropertiesUtil;

public class SMProperties {

	private static PropertiesUtil smLoader;

	public static String getConfig(String key) {
		if (smLoader == null) {
			smLoader = new PropertiesUtil("SM.properties");
		}
		return smLoader.getProperty(key);
	}

	public static String getSmIp() {
		return getConfig("SM.IP_ADDRESS");
	}

	public static String getSmPort() {
		return getConfig("SM.WEB_PORT_NUM");
	}

	public static String getQueueFileName() {
		return getConfig("SM.QUEUE_FILE");
	}

	public static Long getSmInterval() {
		return Long.valueOf(getConfig("SM.REPORT_INTERVAL"));
	}
	
	public static String getSlbCheckInterval() {
		return getConfig("SM.SLB_CHECK_INTERVAL");
	}
	
	public static String getAlarmCheckInterval() {
		return getConfig("SM.ALARM_CHECK_INTERVAL");
	}
	
	public static String getPieChartInterval() {
		return getConfig("SM.PIE_CHART_INTERVAL");
	}
	public static String getLineChartInterval () {
		return getConfig("SM.LINE_CHART_INTERVAL");
	}
	
	public static String getBarChartInterval() {
		return getConfig("SM.BAR_CHART_INTERVAL");
	}
	
	public static String getMuLoadChartInterval() {
		return getConfig("SM.MU_LOAD_CHART_INTEVAL");
	}
	
	public static String getScopeId() {
		return getConfig("AIM.SCOPEID");
	}
	
	public static String getAlarmTimeSetting() {
		return getConfig("SM.GET_ALARM_TIME_SETTING");
	}

	public static String getSmUnitConnectTimeoutSetting() {
		return getConfig("SM.UNIT_CONNECT_TIMEOUT");
	}

	public static String getSmUnitKexTimeoutSetting() {
		return getConfig("SM.UNIT_KEX_TIMEOUT");
	}
	
	
}
