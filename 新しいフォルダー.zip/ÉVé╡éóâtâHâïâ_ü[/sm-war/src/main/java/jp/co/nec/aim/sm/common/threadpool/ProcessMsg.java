package jp.co.nec.aim.sm.common.threadpool;

public class ProcessMsg {
	private boolean flag;
	private String tmpMessage;
	private StringBuffer message = new StringBuffer();

	public boolean isFlag() {
		return flag;
	}

	public void setFlag(boolean flag) {
		this.flag = flag;
	}

	public String getTmpMessage() {
		if (!tmpMessage.isEmpty()) {
			return "<p>" + tmpMessage + "</p>";
		}
		return null;
	}

	public void setTmpMessage(String tmpMessage) {
		this.tmpMessage = tmpMessage;
	}

	public StringBuffer getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message.append(message);
	}
}
