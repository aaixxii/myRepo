package jp.co.nec.aim.sm.modules.sys.oracle.repository;

import java.util.List;

import jp.co.nec.aim.sm.common.persistence.BaseRepository;
import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.DataManagerEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.DmEligibleContainerEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.DmEligibleContainerEntityPK;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.EligibleBinsPojo;

public interface DmEligibleBiometricContainerRepository extends
		BaseRepository<DmEligibleContainerEntity, DmEligibleContainerEntityPK> {
	
	public Page<DmEligibleContainerEntity> findDmEligibleBinsPage(
			Page<DmEligibleContainerEntity> page,
			DmEligibleContainerEntity eligibleBins);

	/** find Eligible Biometric Container List **/
	public Page<EligibleBinsPojo> findEligibleBinsPage(
			Page<EligibleBinsPojo> page, EligibleBinsPojo eligibleBins);

	/** find Eligible Biometric Container page **/
	public List<DmEligibleContainerEntity> findDmEligibleBins(DmEligibleContainerEntity eligibleBins);	

	/** find Eligible Biometric Container List **/
	public List<EligibleBinsPojo> findEligibleBins(EligibleBinsPojo eligibleBins);

	/** assign Match Unit Eligible Biometric Container **/
	public void assignDmBin(Long matchUnitId, String binIds);

	/** unAssign Match Unit Eligible Biometric Container **/
	public void unAssignDmBin(Long matchUnitId, String binIds);
	
	public DataManagerEntity findDmEtifyById(long dmId);

}
