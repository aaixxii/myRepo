package jp.co.nec.aim.sm.common.constant;

public enum MessageType {
	INFORMATION("100000"), WARNING("200000"), 
	ALERT("300000"), ERROR("400000"), EMERGENCY("500000");

	private String messageCode;

	private MessageType(String messageCode) {
		this.messageCode = messageCode;
	}

	public String getMessageCode() {
		return messageCode;
	}

	public static String getMessageCode(String typeName) {
		for (MessageType type : MessageType.values()) {
			if (type.name().equals(typeName)) {
				return type.messageCode;
			}
		}

		return "";
	}

	public static String getMessageTypeName(String messageCode) {
		for (MessageType type : MessageType.values()) {
			if (type.messageCode.equals(messageCode)) {
				return type.name();
			}
		}

		return "UNKNWON";
	}
}
