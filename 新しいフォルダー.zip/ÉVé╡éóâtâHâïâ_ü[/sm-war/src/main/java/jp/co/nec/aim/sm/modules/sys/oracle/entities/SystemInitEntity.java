package jp.co.nec.aim.sm.modules.sys.oracle.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the SYSTEM_INIT database table.
 * 
 */
@Entity
@Table(name = "SYSTEM_INIT")
@NamedQuery(name = "SystemInitEntity.findAll", query = "SELECT s FROM SystemInitEntity s")
public class SystemInitEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "SYSTEM_INIT_INITID_GENERATOR", sequenceName = "SYSTEM_INIT_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SYSTEM_INIT_INITID_GENERATOR")
	@Column(name = "INIT_ID")
	private Long initId;

	@Column(name = "KEY_NAME")
	private String keyName;

	@Column(name = "KEY_VALUE")
	private String keyValue;

	public SystemInitEntity() {
	}

	public Long getInitId() {
		return initId;
	}

	public void setInitId(Long initId) {
		this.initId = initId;
	}

	public String getKeyName() {
		return this.keyName;
	}

	public void setKeyName(String keyName) {
		this.keyName = keyName;
	}

	public String getKeyValue() {
		return this.keyValue;
	}

	public void setKeyValue(String keyValue) {
		this.keyValue = keyValue;
	}

}