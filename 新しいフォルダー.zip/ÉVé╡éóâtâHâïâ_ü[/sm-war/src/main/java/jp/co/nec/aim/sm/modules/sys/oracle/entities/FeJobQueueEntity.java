package jp.co.nec.aim.sm.modules.sys.oracle.entities;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import jp.co.nec.aim.sm.common.constant.CallbackStyle;
import jp.co.nec.aim.sm.common.constant.FeJobStatus;
import jp.co.nec.aim.sm.common.constant.JobState;
import jp.co.nec.aim.sm.common.utils.DateUtils;

import org.apache.commons.lang3.StringUtils;

/**
 * The persistent class for the FE_JOB_QUEUE database table.
 * 
 */
@Entity
@Table(name = "FE_JOB_QUEUE")
public class FeJobQueueEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "fe_job_queue_generator", sequenceName = "FE_JOB_QUEUE_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "fe_job_queue_generator")
	@Column(name = "JOB_ID")
	private Long jobId;

	@Column(name = "ASSIGNED_TS")
	private String assignedTs;

	@Column(name = "CALLBACK_STYLE")
	@Enumerated(value = EnumType.ORDINAL)
	private CallbackStyle callbackStyle;

	@Column(name = "CALLBACK_URL")
	private String callbackUrl;

	@Column(name = "FAILED_FLAG")
	private Integer failedFlag;

	@Column(name = "FAILURE_COUNT")
	private Integer failureCount;

	@Column(name = "FUNCTION_ID")
	private Integer functionId;

	@Column(name = "JOB_STATE")
	@Enumerated(value = EnumType.ORDINAL)
	private JobState jobStatus;

	@Column(name = "LOT_JOB_ID")
	private Long lotJobId;

	@Column(name = "MU_ID")
	private Integer matchUnitId;

	private Integer priority;

	@Column(name = "\"RESULT\"")
	private byte[] result;

	@Column(name = "RESULT_TS")
	private String resultTs;

	@Column(name = "SUBMISSION_TS")
	private String submissionTs;

	@Transient
	private List<FeJobStatus> statusList;

	@Transient
	private String submissionTsStr;

	public FeJobQueueEntity() {
	}

	public Long getJobId() {
		return jobId;
	}

	public void setJobId(Long jobId) {
		this.jobId = jobId;
	}

	public String getAssignedTs() {
		if (StringUtils.isBlank(assignedTs)) {
			return StringUtils.EMPTY;
		}

		return DateUtils.formatDate(new Date(Long.valueOf(assignedTs)),
				new Object[] { "yyyy-MM-dd HH:mm:ss" });
	}

	public void setAssignedTs(String assignedTs) {
		this.assignedTs = assignedTs;
	}

	public CallbackStyle getCallbackStyle() {
		return callbackStyle;
	}

	public void setCallbackStyle(CallbackStyle callbackStyle) {
		this.callbackStyle = callbackStyle;
	}

	public String getCallbackUrl() {
		return callbackUrl;
	}

	public void setCallbackUrl(String callbackUrl) {
		this.callbackUrl = callbackUrl;
	}

	public Integer getFailedFlag() {
		return failedFlag;
	}

	public void setFailedFlag(Integer failedFlag) {
		this.failedFlag = failedFlag;
	}

	public Integer getFailureCount() {
		return failureCount;
	}

	public void setFailureCount(Integer failureCount) {
		this.failureCount = failureCount;
	}

	public Integer getFunctionId() {
		return functionId;
	}

	public void setFunctionId(Integer functionId) {
		this.functionId = functionId;
	}

	public JobState getJobStatus() {
		return jobStatus;
	}

	public void setJobStatus(JobState jobStatus) {
		this.jobStatus = jobStatus;
	}

	public Long getLotJobId() {
		return lotJobId;
	}

	public void setLotJobId(Long lotJobId) {
		this.lotJobId = lotJobId;
	}

	public Integer getMatchUnitId() {
		return matchUnitId;
	}

	public void setMatchUnitId(Integer matchUnitId) {
		this.matchUnitId = matchUnitId;
	}

	public Integer getPriority() {
		return priority;
	}

	public void setPriority(Integer priority) {
		this.priority = priority;
	}

	public byte[] getResult() {
		return result;
	}

	public void setResult(byte[] result) {
		this.result = result;
	}

	public String getResultTs() {
		if (StringUtils.isBlank(resultTs)) {
			return StringUtils.EMPTY;
		}

		return DateUtils.formatDate(new Date(Long.valueOf(resultTs)),
				new Object[] { "yyyy-MM-dd HH:mm:ss" });
	}

	public void setResultTs(String resultTs) {
		this.resultTs = resultTs;
	}

	public String getSubmissionTs() {
		return submissionTs;
	}

	public void setSubmissionTs(String submissionTs) {
		this.submissionTs = submissionTs;
	}

	public List<FeJobStatus> getStatusList() {
		if (statusList == null) {
			statusList = new ArrayList<FeJobStatus>();
		}

		return statusList;
	}

	public void setStatusList(List<FeJobStatus> statusList) {
		this.statusList = statusList;
	}

	public String getSubmissionTsStr() {
		if (StringUtils.isBlank(submissionTs)) {
			return StringUtils.EMPTY;
		}

		return DateUtils.formatDate(new Date(Long.valueOf(submissionTs)),
				new Object[] { "yyyy-MM-dd HH:mm:ss" });
	}

}