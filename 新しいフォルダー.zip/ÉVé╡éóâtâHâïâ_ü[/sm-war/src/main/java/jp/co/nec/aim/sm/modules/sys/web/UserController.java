package jp.co.nec.aim.sm.modules.sys.web;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.nec.aim.sm.common.constant.Constants;
import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.modules.sys.postgres.entity.RoleEntity;
import jp.co.nec.aim.sm.modules.sys.postgres.entity.UserEntity;
import jp.co.nec.aim.sm.modules.sys.service.UserService;
import jp.co.nec.aim.sm.modules.sys.util.UserUtils;
import jp.co.nec.aim.sm.modules.sys.web.base.BaseController;

import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.apache.shiro.authz.annotation.RequiresUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.google.common.collect.Lists;

@Controller
@RequestMapping(value = "/user")
public class UserController extends BaseController {

	@Autowired
	private UserService userService;

	@ModelAttribute("userEntity")
	public UserEntity get(@RequestParam(required = false) Long id) {
		if (id != null) {
			return userService.getUser(id);
		} else {
			return new UserEntity();
		}
	}

	@RequiresPermissions(Constants.PERMISSION_ADMIN)
	@RequestMapping(value = { "list", "" })
	public String list(UserEntity user, HttpServletRequest request,
			HttpServletResponse response, Model model) {
		Page<UserEntity> page = userService.findUser(new Page<UserEntity>(
				request, response), user);
		model.addAttribute("page", page);
		model.addAttribute("user", user);

		saveCurrentPageInfo(request, "/user/list", model);
		return "modules/sys/userList";
	}

	@RequiresPermissions(Constants.PERMISSION_ADMIN)
	@RequestMapping(value = "form")
	public String form(UserEntity user, HttpServletRequest request, Model model) {
		model.addAttribute("user", user);
		model.addAttribute("allRoles", userService.findAllRole());

		saveCurrentPageInfo(request, "/user/form", model);
		return "modules/sys/userForm";
	}

	@RequiresPermissions(Constants.PERMISSION_VIEWER)
	@RequestMapping(value = "save")
	public String save(UserEntity user, String oldLoginName,
			String newPassword, HttpServletRequest request, Model model,
			RedirectAttributes redirectAttributes) {
		if (StringUtils.isNotBlank(newPassword)) {
			user.setPassword(UserService.entryptPassword(newPassword));
		}

		if (!beanValidator(model, user)) {
			return form(user, request, model);
		}

		if (!"true".equals(checkLoginName(oldLoginName, user.getLoginName()))) {
			addMessage(model, "Save User' " + user.getLoginName()
					+ "' failure， The Login Name has already exist.");
			return form(user, request, model);
		}

		List<RoleEntity> roleList = Lists.newArrayList();
		List<Long> roleIdList = user.getRoleIdList();
		for (RoleEntity r : userService.findAllRole()) {
			if (roleIdList.contains(r.getRoleId())) {
				roleList.add(r);
			}
		}
		user.setRoleList(roleList);
		userService.saveUser(user);
		if (user.getLoginName().equals(UserUtils.getUser().getLoginName())) {
			UserUtils.getCacheMap().clear();
		}
		addMessage(redirectAttributes, "Save User' " + user.getLoginName()
				+ "' Successfully.");
		return "redirect:/user/?repage";
	}

	@RequiresPermissions(Constants.PERMISSION_ADMIN)
	@RequestMapping(value = "delete")
	public String delete(Long id, RedirectAttributes redirectAttributes) {
		if (UserUtils.getUser().getId().equals(id)) {
			addMessage(redirectAttributes,
					"Delete user failure, the current user deletion is not allowed.");
		} else if (UserEntity.isAdmin(id)) {
			addMessage(redirectAttributes,
					"Delete user failure, the super administrator deletion is not allowed.");
		} else {
			userService.deleteUser(id);
			addMessage(redirectAttributes, "Delete user Successfully.");
		}
		return "redirect:/user/?repage";
	}

	@RequiresPermissions(Constants.PERMISSION_ADMIN)
	@ResponseBody
	@RequestMapping(value = "checkLoginName")
	public String checkLoginName(String oldLoginName, String loginName) {
		if (loginName != null && loginName.equals(oldLoginName)) {
			return "true";
		} else if (loginName != null
				&& userService.getUserByLoginName(loginName) == null) {
			return "true";
		}
		return "false";
	}

	@RequiresPermissions(Constants.PERMISSION_VIEWER)
	@RequiresUser
	@RequestMapping(value = "info")
	public String info(UserEntity user, HttpServletRequest request, Model model) {
		UserEntity currentUser = UserUtils.getUser();
		if (StringUtils.isNotBlank(user.getName())) {
			currentUser = UserUtils.getUser(true);
			currentUser.setEmail(user.getEmail());
			currentUser.setPhone(user.getPhone());
			currentUser.setMobile(user.getMobile());
			userService.saveUser(currentUser);
//			model.addAttribute("message", "save user information successfully.");
			return "redirect:/user/?repage";
		}
		model.addAttribute("user", currentUser);

		saveCurrentPageInfo(request, "/user/info", model);
		return "modules/sys/userInfo";
	}

	@RequiresPermissions(Constants.PERMISSION_VIEWER)
	@RequiresUser
	@RequestMapping(value = "modifyPwd")
	public String modifyPwd(String oldPassword, String newPassword,
			HttpServletRequest request, Model model) {
		UserEntity user = UserUtils.getUser();
		if (StringUtils.isNotBlank(oldPassword)
				&& StringUtils.isNotBlank(newPassword)) {
			if (UserService.validatePassword(oldPassword, user.getPassword())) {
				userService.updatePasswordById(user.getId(),
						user.getLoginName(), newPassword);
				model.addAttribute("message", "Modify password successfully.");
			} else {
				model.addAttribute("message",
						"Modify password failure. the old password is incorrect.");
			}
		}
		model.addAttribute("user", user);

		saveCurrentPageInfo(request, "/user/modifyPwd", model);
		return "modules/sys/userModifyPwd";
	}
}
