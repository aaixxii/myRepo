package jp.co.nec.aim.sm.common.utils;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.net.HttpURLConnection;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.stream.StreamSource;

import org.apache.commons.httpclient.HttpMethod;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ch.ethz.ssh2.Connection;
import ch.ethz.ssh2.Session;

/**
 * SMUtil
 */
public final class SMUtil {

	/** the log instance **/
	private static Logger logger = LoggerFactory.getLogger(SMUtil.class);

	/**
	 * check the object is null or not
	 * 
	 * @param object
	 * @return the object is null or not
	 */
	public static boolean isObjectNull(final Object object) {
		return (object == null);
	}

	/**
	 * isListNullOrEmpty
	 * 
	 * @param list
	 * @return
	 */
	public static boolean isListNullOrEmpty(final List<?> list) {
		return (list == null || list.isEmpty());
	}

	/**
	 * removeListNull
	 * 
	 * @param list
	 * @return
	 */
	public static <T> List<T> removeListNull(final List<T> list) {
		for (int i = (list.size() - 1); i >= 0; i--) {
			if (isObjectNull(list.get(i))) {
				list.remove(i);
			}
		}
		return list;
	}

	public static boolean isNullOrEmpty(String str) {
		return (str == null || str.isEmpty());
	}

	/**
	 * cast the object to specified type
	 * 
	 * @param o
	 * @return
	 */

	@SuppressWarnings("unchecked")
	public static <T> T cast(final Object o) {
		return (T) o;
	}

	/**
	 * isNullOrEmpty
	 * 
	 * @param objects
	 * @return
	 */
	public static boolean isNullOrEmpty(Object[] objects) {
		return ((objects == null) || (objects.length == 0));
	}

	/**
	 * close the reader
	 * 
	 * @param reader
	 */
	public static void close(final Reader reader) {
		if (reader != null) {
			try {
				reader.close();
			} catch (IOException e) {
				logger.error("IOException occurred..", e);
			}
		}
	}

	/**
	 * close the Session
	 * 
	 * @param Session
	 */
	public static void close(final Session session) {
		if (session != null) {
			session.close();
		}
	}

	/**
	 * close the Connection
	 * 
	 * @param Connection
	 */
	public static void close(final Connection conn) {
		if (conn != null) {
			conn.close();
		}
	}

	/**
	 * close the InputStream
	 * 
	 * @param is
	 */
	public static void close(final InputStream is) {
		// close the inputStream
		if (is != null) {
			try {
				is.close();
			} catch (IOException e) {
				logger.error("close the connection inputStream error..", e);
			}
		}

	}

	/**
	 * close the OutputStream
	 * 
	 * @param output
	 */
	public static void close(final OutputStream output) {
		// close the outputStream
		if (output != null) {
			try {
				output.close();
			} catch (IOException e) {
				logger.error("close the connection outputStream error..", e);
			}
		}

	}

	/**
	 * close the HttpURLConnection
	 * 
	 * @param connection
	 */
	public static void close(final HttpURLConnection connection) {
		// close the url connection
		if (connection != null) {
			connection.disconnect();
		}
	}

	public static void close(final HttpMethod post) {
		// close the url connection
		if (post != null) {
			post.releaseConnection();
		}
	}

	/**
	 * Javabean convert to Xml
	 * 
	 * @param obj
	 * @return
	 */
	public static <T> String convertJavaBeanToXml(T obj) {
		Class<?> clazz = obj.getClass();
		JAXBContext jaxbCtx;
		StringWriter sw = new StringWriter();
		try {
			jaxbCtx = JAXBContext.newInstance(clazz);
			Marshaller marshaller = jaxbCtx.createMarshaller();
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT,
					Boolean.TRUE);
			marshaller.marshal(obj, sw);
		} catch (JAXBException e) {
			logger.error("JAXBContext unable to marshell : ", e);
			return null;
		}
		return sw.toString();
	}

	/**
	 * Xml convert to JavaBean
	 * 
	 * @param clazz
	 * @param is
	 * @return
	 */
	public static Object convertXmltoJavaBean(Class<?> clazz, InputStream isR) {
		JAXBContext jaxbCtx;
		Object obj = null;
		try {
			jaxbCtx = JAXBContext.newInstance(clazz);
			Unmarshaller unmarshaller = jaxbCtx.createUnmarshaller();
			obj = unmarshaller.unmarshal(isR);
		} catch (JAXBException e) {
			logger.error("JAXBContext unable to Unmarshell : ", e);
		}
		return obj;
	}

	public static Object convertXmltoJavaBean(Class<?> clazz, String xml) {
		JAXBContext jaxbCtx;
		Object obj = null;
		try {
			jaxbCtx = JAXBContext.newInstance(clazz);
			Unmarshaller unmarshaller = jaxbCtx.createUnmarshaller();
			obj = unmarshaller.unmarshal(new StringReader(xml));
		} catch (JAXBException e) {
			logger.error("JAXBContext unable to Unmarshell : ", e);
		}
		return obj;
	}

	public static <T> T convertXmltoJAXBElement(Class<T> clazz, String xml) {
		JAXBContext jaxbCtx;
		T obj = null;
		try {
			jaxbCtx = JAXBContext.newInstance(clazz);
			Unmarshaller unmarshaller = jaxbCtx.createUnmarshaller();
			obj = unmarshaller.unmarshal(
					new StreamSource(new StringReader(xml)), clazz).getValue();
		} catch (JAXBException e) {
			logger.error("JAXBContext unable to Unmarshell : ", e);
		}
		return obj;
	}
}
