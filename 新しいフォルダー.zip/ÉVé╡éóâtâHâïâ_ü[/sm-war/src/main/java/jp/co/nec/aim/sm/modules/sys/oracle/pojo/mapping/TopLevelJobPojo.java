package jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Transient;

import jp.co.nec.aim.sm.common.annocation.FieldMapped;
import jp.co.nec.aim.sm.common.annocation.InquiryMapping;

@InquiryMapping
public class TopLevelJobPojo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4640173868178724492L;

	@FieldMapped
	private String function;

	@FieldMapped
	private Long wait;

	@FieldMapped
	private Long exec;

	@FieldMapped
	private Long done;

	private Long growing;

	@FieldMapped
	private Long jobLimit;

	@FieldMapped
	private Timestamp oldestexecjobTimestamp;

	@Transient
	private String startTime;

	@Transient
	private String endTime;

	public String getFunction() {
		return this.function;
	}

	public void setFunction(String function) {
		this.function = function;
	}

	public Long getWait() {
		return this.wait;
	}

	public void setWait(Long wait) {
		this.wait = wait;
	}

	public Long getExec() {
		return this.exec;
	}

	public void setExec(Long exec) {
		this.exec = exec;
	}

	public Long getDone() {
		return this.done;
	}

	public void setDone(Long done) {
		this.done = done;
	}

	public Long getJobLimit() {
		return this.jobLimit;
	}

	public void setJobLimit(Long jobLimit) {
		this.jobLimit = jobLimit;
	}

	public Timestamp getOldestexecjobTimestamp() {
		return oldestexecjobTimestamp;
	}

	public void setOldestexecjobTimestamp(Timestamp oldestexecjobTimestamp) {
		this.oldestexecjobTimestamp = oldestexecjobTimestamp;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public Long getGrowing() {
		return growing;
	}

	public void setGrowing(Long growing) {
		this.growing = growing;
	}
}