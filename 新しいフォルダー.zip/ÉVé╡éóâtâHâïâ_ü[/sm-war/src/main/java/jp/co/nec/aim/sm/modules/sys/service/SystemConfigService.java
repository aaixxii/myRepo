package jp.co.nec.aim.sm.modules.sys.service;

import java.util.List;

import jp.co.nec.aim.sm.common.constant.EligibleAssignAction;
import jp.co.nec.aim.sm.common.constant.MMConfigProperty;
import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.exception.SMServiceException;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.ContainerEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.DataManagerEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.DmEligibleContainerEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.FunctionTypeEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.MuEligibleContainerEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.MuEligibleFunctionEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.MuEligibleFunctionEntityPK;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.SystemConfigEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.SystemInitEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.BiometricContainerPojo;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.EligibleBinsPojo;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.EligibleFunctionsPojo;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.FunctionTypeTrafficPojo;
import jp.co.nec.aim.sm.modules.sys.oracle.repository.BiometricContainerRepository;
import jp.co.nec.aim.sm.modules.sys.oracle.repository.DmEligibleBiometricContainerRepository;
import jp.co.nec.aim.sm.modules.sys.oracle.repository.EligibleBiometricContainerRepository;
import jp.co.nec.aim.sm.modules.sys.oracle.repository.EligibleFunctionRepository;
import jp.co.nec.aim.sm.modules.sys.oracle.repository.FormatTypeRepository;
import jp.co.nec.aim.sm.modules.sys.oracle.repository.FunctionTypeRepository;
import jp.co.nec.aim.sm.modules.sys.oracle.repository.SystemConfigRepository;
import jp.co.nec.aim.sm.modules.sys.oracle.repository.SystemInitRepository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional(value = "oracleTXManager")
public class SystemConfigService {

	/** the log instance **/
	private static Logger logger = LoggerFactory
			.getLogger(SystemConfigService.class);

	@Autowired
	private BiometricContainerRepository binDao;

	@Autowired
	private EligibleBiometricContainerRepository eligibleBinDao;
	
	@Autowired
	private DmEligibleBiometricContainerRepository eligibleBinDaoDm;


	@Autowired
	private EligibleFunctionRepository eligibleFunctionDao;

	@Autowired
	private FormatTypeRepository formatTypeDao;

	@Autowired
	private FunctionTypeRepository functionTypeDao;

	@Autowired
	private SystemConfigRepository systemConfigDao;

	@Autowired
	private SystemInitRepository systemInitDao;

	/**
	 * get Page by class type
	 * 
	 * @param <T>
	 * @param page
	 * @param obj
	 * @param clazz
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public <T> Page<T> getPageByClass(@SuppressWarnings("rawtypes") Page page,
			Object obj, Class<?> clazz) {
		try {
			// if (clazz.equals(BiometricContainerEntity.class)) {
			// logger.debug("find Biometric Container Page");
			// return (Page<T>) binDao.findBiometricContainerPage(page,
			// (BiometricContainerEntity) obj);
			// }

			if (clazz.equals(BiometricContainerPojo.class)) {
				logger.debug("find Biometric Container Page");
				Page<BiometricContainerPojo> bcpPage = binDao
						.findBiometricContainerPage(page,
								(BiometricContainerPojo) obj);
				setDefaultMinRedundancy(bcpPage.getList());
				return (Page<T>) bcpPage;
			} else if (clazz.equals(MuEligibleContainerEntity.class)) {
				logger.debug("find Eligible Bins Page");
				return (Page<T>) eligibleBinDao.findEligibleBinsPage(page,
						(MuEligibleContainerEntity) obj);
			} else if (clazz.equals(DmEligibleContainerEntity.class)) {
				logger.debug("find DmEligible Bins Page");
				return (Page<T>) eligibleBinDaoDm.findDmEligibleBinsPage(page,
						(DmEligibleContainerEntity) obj);				
				
			} else if (clazz.equals(EligibleBinsPojo.class)) {
				logger.debug("find Eligible Bins Page");
				Page<EligibleBinsPojo> ebPage = eligibleBinDao
						.findEligibleBinsPage(page, (EligibleBinsPojo) obj);
				setDefaultMinRedundancy(ebPage.getList());
				return (Page<T>) ebPage;
			} else if (clazz.equals(MuEligibleFunctionEntity.class)) {
				logger.debug("find Eligible Function Page");
				return (Page<T>) eligibleFunctionDao.findEligibleFunctionPage(
						page, (MuEligibleFunctionEntity) obj);
			} else if (clazz.equals(EligibleFunctionsPojo.class)) {
				logger.debug("find Eligible Function Page");
				return (Page<T>) eligibleFunctionDao.findAssignedFunctionPage(
						page, (EligibleFunctionsPojo) obj);
			} else if (clazz.equals(FunctionTypeEntity.class)) {
				logger.debug("find Function Type Page");
				return (Page<T>) functionTypeDao.findFunctionTypePage(page,
						(FunctionTypeEntity) obj);
			} else if (clazz.equals(FunctionTypeTrafficPojo.class)) {
				return (Page<T>) functionTypeDao.findFunctionTypePage1(page,
						(FunctionTypeTrafficPojo) obj);
			} else if (clazz.equals(SystemConfigEntity.class)) {
				logger.debug("find System Config Page");
				return (Page<T>) systemConfigDao.findSystemConfigPage(page,
						(SystemConfigEntity) obj);
			} else if (clazz.equals(SystemInitEntity.class)) {
				logger.debug("find System Init Page");
				return (Page<T>) systemInitDao.findSystemInitPage(page,
						(SystemInitEntity) obj);
			} else {
				logger.warn("the class {} is not support.", clazz);
				return null;
			}
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			throw new SMServiceException(ex);
		}
	}

	private <T> void setDefaultMinRedundancy(List<T> list) {
		SystemConfigEntity sce = systemConfigDao
				.findByProperty(MMConfigProperty.DEFAULT_MIN_REDUNDANCY);
		for (T iterm : list) {
			if (iterm.getClass().equals(EligibleBinsPojo.class)) {
				if (((EligibleBinsPojo) iterm).getMinimumRedundancy() == null) {
					((EligibleBinsPojo) iterm).setMinimumRedundancy(Long
							.valueOf(sce.getPropertyValue()));
				}
			} else if (iterm.getClass().equals(BiometricContainerPojo.class)) {
				if (((BiometricContainerPojo) iterm).getMinimumRedundancy() == null) {
					((BiometricContainerPojo) iterm).setMinimumRedundancy(Long
							.valueOf(sce.getPropertyValue()));
				}
			}
		}
	}

	/**
	 * get Page by class type
	 * 
	 * @param <T>
	 * @param page
	 * @param obj
	 * @param clazz
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public <T> List<T> getListByClass(Object obj, Class<?> clazz) {
		try {
			// if (clazz.equals(BiometricContainerEntity.class)) {
			// logger.debug("find Biometric Container Page");
			// return (List<T>) binDao
			// .findBiometricContainer((BiometricContainerEntity) obj);
			// } else if (clazz.equals(BiometricContainerPojo.class)) {
			// logger.debug("find Biometric Container Page");
			// List<BiometricContainerPojo> bcList = binDao
			// .findBiometricContainer((BiometricContainerPojo) obj);
			// setDefaultMinRedundancy(bcList);
			// return (List<T>) bcList;
			// }

			if (clazz.equals(MuEligibleContainerEntity.class)) {
				logger.debug("find Eligible Bins Page");
				return (List<T>) eligibleBinDao
						.findEligibleBins((MuEligibleContainerEntity) obj);
			} else if (clazz.equals(DmEligibleContainerEntity.class)) {
				logger.debug("find DmEligible Bins Page");
				return (List<T>) eligibleBinDaoDm
						.findDmEligibleBins((DmEligibleContainerEntity) obj);			
			} else if (clazz.equals(EligibleBinsPojo.class)) {
				logger.debug("find Eligible Bins Page");
				List<EligibleBinsPojo> ebList = eligibleBinDao
						.findEligibleBins((EligibleBinsPojo) obj);
				setDefaultMinRedundancy(ebList);
				return (List<T>) ebList;
			} else if (clazz.equals(MuEligibleFunctionEntity.class)) {
				logger.debug("find Eligible Function Page");
				return (List<T>) eligibleFunctionDao
						.findEligibleFunction((MuEligibleFunctionEntity) obj);
			} else if (clazz.equals(EligibleFunctionsPojo.class)) {
				logger.debug("find Eligible Function Page");
				return (List<T>) eligibleFunctionDao
						.findAssignedFunction((EligibleFunctionsPojo) obj);
			} else if (clazz.equals(FunctionTypeEntity.class)) {
				logger.debug("find Function Type Page");
				return (List<T>) functionTypeDao
						.findFunctionType((FunctionTypeEntity) obj);
			} else if (clazz.equals(SystemConfigEntity.class)) {
				logger.debug("find System Config Page");
				return (List<T>) systemConfigDao
						.findSystemConfig((SystemConfigEntity) obj);
			} else if (clazz.equals(SystemInitEntity.class)) {
				logger.debug("find System Init Page");
				return (List<T>) systemInitDao
						.findSystemInit((SystemInitEntity) obj);
			} else {
				logger.warn("the class {} is not support.", clazz);
				return null;
			}
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			throw new SMServiceException(ex);
		}
	}

	/**
	 * update DB by class type
	 * 
	 * @param clazz
	 * @param objs
	 * @return
	 */
	public int updateDBByClass(Class<?> clazz, Object... objs) {
		try {
			if (clazz.equals(BiometricContainerPojo.class)) {
				logger.debug("update Biometric Container: binId = {},"
						+ " formatName = {}, minimumRedundancy = {}", objs);
				return binDao.updateBiometricContainer((Long) objs[0],
						(String) objs[1], (Long) objs[2], (Long) objs[3],
						(Long) objs[4]);
			} else if (clazz.equals(FunctionTypeTrafficPojo.class)) {
				logger.debug("update Function Type: functionId = {},"
						+ " jobLimit = {}, timeouts = {}, muJobTimeouts = {},"
						+ " internalCandidateSize = {}", objs);
				return functionTypeDao.updateFunctionType((Integer) objs[0],
						(Integer) objs[1], (Long) objs[2], (Long) objs[3],
						(Long) objs[4]);
			} else if (clazz.equals(SystemConfigEntity.class)) {
				logger.debug("update System Config: configId = {},"
						+ "  propertyName = {}, propertyValue = {}", objs);
				return systemConfigDao.updateSystemConfig((Integer) objs[0],
						(String) objs[1], (String) objs[2]);
			} else if (clazz.equals(SystemInitEntity.class)) {
				logger.debug("update System Init: initId = {}, value = {}",
						objs);
				return systemInitDao.updateSystemInit((Long) objs[0],
						(String) objs[1]);
			} else {
				logger.warn("the class {} is not support.", clazz);
				return 0;
			}
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			throw new SMServiceException(ex);
		}
	}

	/**
	 * get all format type from DB
	 * 
	 * @return
	 */
	public List<String> getAllFormatType() {
		try {
			logger.debug("get all format type from DB");
			return formatTypeDao.getAllFormatType();
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			throw new SMServiceException(ex);
		}
	}

	/**
	 * get all function type from DB
	 * 
	 * @return
	 */
	public List<String> getAllFunctionType() {
		try {
			logger.debug("get all function type from DB");
			return functionTypeDao.getAllFunctionType();
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			throw new SMServiceException(ex);
		}
	}

	/**
	 * get all bin id from DB
	 * 
	 * @return
	 */
	public List<Long> getAllContainers() {
		try {
			logger.debug("get all bin id from DB");
			return binDao.getAllContainers();
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			throw new SMServiceException(ex);
		}
	}

	/**
	 * execute Assign Action
	 * 
	 * @param clazz
	 * @param action
	 * @param obj
	 * @return
	 */
	public boolean executeAssignAction(Class<?> clazz, String action,
			Long muId, String obj) {
		try {
			if (clazz.equals(MuEligibleContainerEntity.class)) {
				logger.debug("{} Bin: muId = {}, binId = {}", new Object[] {
						action, muId, obj });
				if (action.equals(EligibleAssignAction.Assign.name())) {
					eligibleBinDao.assignBin(muId, obj);
				} else if (action.equals(EligibleAssignAction.Unassign.name())) {
					eligibleBinDao.unAssignBin(muId, obj);
				} else {
					logger.warn("the action {} is not support.", action);
					return false;
				}
			} else if (clazz.equals(DmEligibleContainerEntity.class)) {
				logger.debug("{} Bin: dmId = {}, binId = {}", new Object[] {
						action, muId, obj });
				if (action.equals(EligibleAssignAction.Assign.name())) {
					eligibleBinDaoDm.assignDmBin(muId, obj);
				} else if (action.equals(EligibleAssignAction.Unassign.name())) {
					eligibleBinDaoDm.unAssignDmBin(muId, obj);
				} else {
					logger.warn("the action {} is not support.", action);
					return false;
				}
			} else if (clazz.equals(MuEligibleFunctionEntity.class)) {
				Integer functionTypeId = null;
				String functionName = (String) obj;
				if (functionName.equals("All")) {
					functionTypeId = 0;
				} else {
					functionTypeId = functionTypeDao
							.getFunctionId(functionName);
					if (functionTypeId == null) {
						logger.warn("Can not find functionTypeId by name={}.",
								functionName);
						return false;
					}
				}
				// create MuEligibleFunctionEntityPK
				MuEligibleFunctionEntityPK id = new MuEligibleFunctionEntityPK();
				id.setMuId(muId);
				id.setFunctionId(functionTypeId);

				// create MuEligibleFunctionEntity
				MuEligibleFunctionEntity eligibleFunction = null;
				eligibleFunction = new MuEligibleFunctionEntity();
				eligibleFunction.setId(id);

				if (action.equals(EligibleAssignAction.Assign.name())) {
					logger.debug("assign Bin: muId = {}, functionId = {}",
							eligibleFunction.getId().getMuId(),
							eligibleFunction.getId().getFunctionId());
					eligibleFunctionDao.assignFunction(eligibleFunction);
				} else if (action.equals(EligibleAssignAction.Unassign.name())) {
					logger.debug("unAssign Bin: muId = {}, functionId = {}",
							eligibleFunction.getId().getMuId(),
							eligibleFunction.getId().getFunctionId());
					eligibleFunctionDao.unAssignFunction(eligibleFunction);
				} else {
					logger.warn("the action {} is not support.", action);
					return false;
				}

			} else {
				logger.warn("the class {} is not support.", clazz);
				return false;
			}

			return true;
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			throw new SMServiceException(ex);
		}
	}
	
	public DataManagerEntity findDmEtifyById(long dmId) {
		return eligibleBinDaoDm.findDmEtifyById(dmId);
	}
	
	public List<ContainerEntity> getContainerListForDm(Long dmId) {
		return binDao.getDmEligibleBinList(dmId);
		
	}
}
