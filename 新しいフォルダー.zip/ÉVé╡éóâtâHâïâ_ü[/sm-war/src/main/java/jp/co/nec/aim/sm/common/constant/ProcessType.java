package jp.co.nec.aim.sm.common.constant;

public enum ProcessType {
	START(0, "start"), STOP(1, "stop"), RESTART(2, "restart")/*, STATUS(3,
			"status"), FORCE_STOP(4, "force-stop"), FORCE_RESTART(5,
			"force-restart")*/;

	private int value;
	private String operationType;

	private ProcessType(int value, String operationType) {
		this.value = value;
		this.operationType = operationType;
	}

	public static ProcessType getProcessType(int value) {

		for (ProcessType p : ProcessType.values()) {
			if (p.value == value)
				return p;
		}
		throw new IllegalArgumentException("Unknown ProcessType: " + value);
	}

	public String getOperationType() {
		return operationType;
	}

}
