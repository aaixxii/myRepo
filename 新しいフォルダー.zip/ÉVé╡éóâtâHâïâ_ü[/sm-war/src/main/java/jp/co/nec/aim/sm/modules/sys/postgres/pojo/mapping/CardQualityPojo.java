package jp.co.nec.aim.sm.modules.sys.postgres.pojo.mapping;

import java.io.Serializable;

import jp.co.nec.aim.sm.common.annocation.FieldMapped;
import jp.co.nec.aim.sm.common.annocation.InquiryMapping;

@InquiryMapping
public class CardQualityPojo implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 885566262341365820L;

	@FieldMapped
	private String qualityType;

	@FieldMapped
	private Integer count100;

	@FieldMapped
	private Integer count200;

	@FieldMapped
	private Integer count300;

	@FieldMapped
	private Integer count400;

	@FieldMapped
	private Integer count500;

	@FieldMapped
	private Integer count600;

	@FieldMapped
	private Integer count700;

	@FieldMapped
	private Integer count800;

	public void setQualityType(String qualityType) {
		this.qualityType = qualityType;
	}

	public String getQualityType() {
		return qualityType;
	}

	public void setCount100(Integer count100) {
		this.count100 = count100;
	}

	public Integer getCount100() {
		return count100;
	}

	public void setCount200(Integer count200) {
		this.count200 = count200;
	}

	public Integer getCount200() {
		return count200;
	}

	public void setCount300(Integer count300) {
		this.count300 = count300;
	}

	public Integer getCount300() {
		return count300;
	}

	public void setCount400(Integer count400) {
		this.count400 = count400;
	}

	public Integer getCount400() {
		return count400;
	}

	public void setCount500(Integer count500) {
		this.count500 = count500;
	}

	public Integer getCount500() {
		return count500;
	}

	public void setCount600(Integer count600) {
		this.count600 = count600;
	}

	public Integer getCount600() {
		return count600;
	}

	public void setCount700(Integer count700) {
		this.count700 = count700;
	}

	public Integer getCount700() {
		return count700;
	}

	public void setCount800(Integer count800) {
		this.count800 = count800;
	}

	public Integer getCount800() {
		return count800;
	}

}
