package jp.co.nec.aim.sm.modules.sys.oracle.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The persistent class for the CONTAINER_JOB_FAILURE_REASONS database table.
 * 
 */
@Entity
@Table(name = "CONTAINER_JOB_FAILURE_REASONS")
public class ContainerJobFailureReasonEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "FAILURE_ID")
	private long failureId;

	@Column(name = "CODE")
	private String code;

	@Column(name = "CONTAINER_JOB_ID")
	private long containerJobId;

	@Column(name = "FAILURE_TIME")
	private String failureTime;

	@Column(name = "MR_ID")
	private Long mrId;

	@Column(name = "REASON")
	private String reason;

	@Column(name = "SEGMENT_ID")
	private Long segmentId;

	public ContainerJobFailureReasonEntity() {
	}

	public long getFailureId() {
		return failureId;
	}

	public void setFailureId(long failureId) {
		this.failureId = failureId;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public long getContainerJobId() {
		return containerJobId;
	}

	public void setContainerJobId(long containerJobId) {
		this.containerJobId = containerJobId;
	}

	public String getFailureTime() {
		return failureTime;
	}

	public void setFailureTime(String failureTime) {
		this.failureTime = failureTime;
	}

	public Long getMrId() {
		return mrId;
	}

	public void setMrId(Long mrId) {
		this.mrId = mrId;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public Long getSegmentId() {
		return segmentId;
	}

	public void setSegmentId(Long segmentId) {
		this.segmentId = segmentId;
	}

}