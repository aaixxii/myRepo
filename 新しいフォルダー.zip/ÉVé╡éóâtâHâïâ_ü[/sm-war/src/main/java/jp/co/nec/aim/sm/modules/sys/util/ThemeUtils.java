package jp.co.nec.aim.sm.modules.sys.util;

import java.util.ArrayList;
import java.util.List;

/**
 * ThemeUtil is used by fns.tld
 */
public final class ThemeUtils {

	/** the theme array **/
	private static final String[][] themeArray = new String[][] {
			new String[] { "Default Theme", "default" },
			new String[] { "Cerulean Theme", "cerulean" },
			new String[] { "Orange Theme", "readable" },
			new String[] { "Red Theme", "united" },
			new String[] { "Flat Theme", "flat" } };

	/**
	 * create the theme instance and add to list array <br>
	 * at last return the list
	 * 
	 * @return theme list
	 */
	public static List<Theme> getThemeList() {
		final List<Theme> themes = new ArrayList<Theme>();
		int themeId = 1;
		for (final String[] theme : themeArray) {
			themes.add(new Theme(themeId, theme[0], theme[1], themeId));
		}
		return themes;
	}
}
