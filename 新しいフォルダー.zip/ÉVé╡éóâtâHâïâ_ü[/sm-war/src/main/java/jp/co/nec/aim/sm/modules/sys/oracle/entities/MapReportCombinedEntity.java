package jp.co.nec.aim.sm.modules.sys.oracle.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

/**
 * @author Erik Vandekieft
 */
@Entity
@IdClass(jp.co.nec.aim.sm.modules.sys.oracle.entities.UnitSegReportPK.class)
public class MapReportCombinedEntity {
	private long unitId; // ok
	private long segmentId; // ok
	private Integer rank; //
	private Integer status; //
	private Integer reportVersion;
	private Integer reportQueuedVersion;
	private Integer latestVersion;
	private String sourceURLBase;

	@Column(name = "SOURCE_URL_BASE")
	public String getSourceURLBase() {
		return sourceURLBase;
	}

	public void setSourceURLBase(String sourceURLBase) {
		this.sourceURLBase = sourceURLBase;
	}

	@Id
	@Column(name = "UNIT_ID")
	public long getUnitId() {
		return unitId;
	}

	public void setUnitId(long unitId) {
		this.unitId = unitId;
	}

	@Id
	@Column(name = "SEGMENT_ID")
	public long getSegmentId() {
		return segmentId;
	}

	public void setSegmentId(long segmentId) {
		this.segmentId = segmentId;
	}

	public Integer getRank() {
		return rank;
	}

	public void setRank(Integer rank) {
		this.rank = rank;
	}

	@Column(name = "SEGMENT_VERSION")
	public Integer getReportVersion() {
		return reportVersion;
	}

	public void setReportVersion(Integer segVersion) {
		this.reportVersion = segVersion;
	}

	@Column(name = "SEGMENT_QUEUED_VERSION")
	public Integer getReportQueuedVersion() {
		return reportQueuedVersion;
	}

	public void setReportQueuedVersion(Integer reportQueuedVersion) {
		this.reportQueuedVersion = reportQueuedVersion;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String toString() {
		return "unitId " + unitId + " seg " + segmentId + " v." + reportVersion
				+ " status " + status + " (rank " + rank + ")";
	}

	@Column(name = "VERSION")
	public Integer getLatestVersion() {
		return latestVersion;
	}

	public void setLatestVersion(Integer latestVersion) {
		this.latestVersion = latestVersion;
	}

}
