package jp.co.nec.aim.sm.modules.sys.postgres.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OrderBy;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import jp.co.nec.aim.sm.modules.sys.postgres.pojo.mapping.DictPojo;

import org.codehaus.jackson.annotate.JsonIgnore;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.google.common.collect.Lists;

@Entity
@Table(name = "\"USER\"", schema = "public")
@DynamicInsert
@DynamicUpdate
public class UserEntity implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -8418226003764764841L;

	private Long id;
	private String loginName;
	private String password;
	private String name;
	private String email;
	private String phone;
	private String mobile;
	private String loginIp;
	private Date loginDate;

	@Transient
	private List<DictPojo> userTypeList = Lists.newArrayList();
	private List<RoleEntity> roleList = Lists.newArrayList();

	public UserEntity() {
	}

	public UserEntity(Long id) {
		this();
		this.id = id;
	}

	@Id
	@Column(name = "\"ID\"")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_sys_user")
	@SequenceGenerator(name = "seq_sys_user", sequenceName = "user_seq_id")
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	@Column(name = "\"LOGIN_NAME\"")
	@Length(min = 1, max = 100)
	public String getLoginName() {
		return loginName;
	}

	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}

	@Column(name = "\"PASSWORD\"")
	@JsonIgnore
	@Length(min = 1, max = 100)
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Column(name = "\"NAME\"")
	@Length(min = 1, max = 100)
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Column(name = "\"EMAIL\"")
	@Email
	@Length(min = 0, max = 200)
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Column(name = "\"PHONE\"")
	@Length(min = 0, max = 200)
	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	@Column(name = "\"MOBILE\"")
	@Length(min = 0, max = 200)
	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(name = "\"USER_ROLE\"", joinColumns = { @JoinColumn(name = "\"USER_ID\"") }, inverseJoinColumns = { @JoinColumn(name = "\"ROLE_ID\"") })
	@OrderBy("id")
	@Fetch(FetchMode.SUBSELECT)
	@NotFound(action = NotFoundAction.IGNORE)
	@JsonIgnore
	public List<RoleEntity> getRoleList() {
		return roleList;
	}

	public void setRoleList(List<RoleEntity> roleList) {
		this.roleList = roleList;
	}

	@Transient
	@JsonIgnore
	public List<Long> getRoleIdList() {
		List<Long> roleIdList = Lists.newArrayList();
		for (RoleEntity role : roleList) {
			roleIdList.add(role.getRoleId());
		}
		return roleIdList;
	}

	@Transient
	public void setRoleIdList(List<Long> roleIdList) {
		roleList = Lists.newArrayList();
		for (Long roleId : roleIdList) {
			RoleEntity role = new RoleEntity();
			role.setRoleId(roleId);
			roleList.add(role);
		}
	}

	@Transient
	public String getRoleNames() {
		StringBuilder sb = new StringBuilder();
		final int size = roleList.size();
		for (int index = 0; index < size; index++) {
			sb.append(roleList.get(index).getName());
			if (index != size - 1) {
				sb.append("<br>");
			}
		}
		return sb.toString();
	}

	@Transient
	public boolean isAdmin() {
		return isAdmin(this.id);
	}

	@Transient
	public static boolean isAdmin(Long id) {
		return id != null && id.equals(1L);
	}

	@Transient
	public List<DictPojo> getUserTypeList() {
		return userTypeList;
	}

	@Column(name = "\"LOGIN_IP\"")
	public String getLoginIp() {
		return loginIp;
	}

	public void setLoginIp(String loginIp) {
		this.loginIp = loginIp;
	}

	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@Column(name = "\"LOGIN_DATE\"")
	public Date getLoginDate() {
		return this.loginDate;
	}

	public void setLoginDate(Date loginDate) {
		this.loginDate = loginDate;
	}
}