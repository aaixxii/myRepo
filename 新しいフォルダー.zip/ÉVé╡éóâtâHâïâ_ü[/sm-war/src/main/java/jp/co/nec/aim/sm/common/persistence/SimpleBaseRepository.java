package jp.co.nec.aim.sm.common.persistence;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.persistence.Column;
import javax.persistence.EntityManager;

import jp.co.nec.aim.sm.common.annocation.FieldMapped;
import jp.co.nec.aim.sm.common.annocation.InquiryMapping;
import jp.co.nec.aim.sm.common.utils.SMUtil;

import org.apache.commons.lang.StringUtils;
import org.apache.lucene.search.BooleanClause;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.QueryWrapperFilter;
import org.apache.lucene.search.Sort;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.internal.CriteriaImpl;
import org.hibernate.search.FullTextQuery;
import org.hibernate.search.FullTextSession;
import org.hibernate.search.Search;
import org.hibernate.search.filter.impl.CachingWrapperFilter;
import org.hibernate.search.query.DatabaseRetrievalMethod;
import org.hibernate.search.query.ObjectLookupMethod;
import org.hibernate.transform.ResultTransformer;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StandardBasicTypes;
import org.jfree.util.Log;
import org.springframework.data.jpa.repository.support.JpaEntityInformation;
import org.springframework.data.jpa.repository.support.SimpleJpaRepository;

/**
 * Repository implements class <br>
 */
public class SimpleBaseRepository<M, ID extends Serializable> extends
		SimpleJpaRepository<M, ID> implements BaseRepository<M, ID> {

	/** The Entity Manager **/
	private final EntityManager em;

	/**
	 * getEntityManager
	 */
	public EntityManager getEntityManager() {
		return this.em;
	}

	/**
	 * the entity class type
	 */
	private Class<M> entityClass;

	/**
	 * the default constructor <br>
	 * used for set the T type
	 */
	public SimpleBaseRepository(
			final JpaEntityInformation<M, ID> entityInformation,
			final EntityManager entityManager) {
		super(entityInformation, entityManager);
		this.entityClass = entityInformation.getJavaType();
		this.em = entityManager;
	}

	/**
	 * get the Session
	 */
	public Session getSession() {
		return (Session) getEntityManager().getDelegate();
	}

	/**
	 * flush the session
	 */
	public void flush() {
		getSession().flush();
	}

	/**
	 * clear the session
	 */
	public void clear() {
		getSession().clear();
	}

	// -----------------------------------------------------------
	// ------------------------ HQL Query ------------------------
	// -----------------------------------------------------------

	/**
	 * QL inquiry
	 * 
	 * @param page
	 *            the page instance
	 * @param qlString
	 * @param parameter
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public <E> Page<E> find(Page<E> page, String qlString, Object... parameter) {
		// get count
		if (!page.isDisabled() && !page.isNotCount()) {
			String countQlString = countSql(qlString);
			// page.setCount(Long.valueOf(createQuery(countQlString,
			// parameter).uniqueResult().toString()));
			Query query = createQuery(countQlString, parameter);
			List<Object> list = query.list();
			if (list.size() > 0) {
				page.setCount(Long.valueOf(list.get(0).toString()));
			} else {
				page.setCount(list.size());
			}
			if (page.getCount() < 1) {
				return page;
			}
		}
		// order by
		String ql = qlString;
		if (StringUtils.isNotBlank(page.getOrderBy())) {
			ql += " order by " + page.getOrderBy();
		}
		Query query = createQuery(ql, parameter);
		// set page
		if (!page.isDisabled()) {
			query.setFirstResult(page.getFirstResult());
			query.setMaxResults(page.getMaxResults());
		}
		page.setList(query.list());
		return page;
	}

	/**
	 * QL inquiry
	 * 
	 * @param qlString
	 *            sql string instance
	 * @param parameter
	 *            the parameter instance
	 * @return the List instance(records)
	 */
	@SuppressWarnings("unchecked")
	public <E> List<E> find(String qlString, Object... parameter) {
		Query query = createQuery(qlString, parameter);
		return query.list();
	}

	/**
	 * QL update
	 * 
	 * @param qlString
	 * @param parameter
	 * @return
	 */
	public int update(String qlString, Object... parameter) {
		return createQuery(qlString, parameter).executeUpdate();
	}

	/**
	 * create ql inquiry instance
	 * 
	 * @param qlString
	 * @param parameter
	 * @return
	 */
	public Query createQuery(String qlString, Object... parameter) {
		Query query = getSession().createQuery(qlString);
		setParameter(query, parameter);
		return query;
	}

	// -------------- SQL Query --------------

	/**
	 * inquiry with SQL
	 * 
	 * @param page
	 * @param sqlString
	 * @param parameter
	 * @return
	 */
	public <E> Page<E> findBySql(Page<E> page, String sqlString,
			Object... parameter) {
		return findBySql(page, sqlString, null, parameter);
	}

	/**
	 * inquiry with SQL
	 * 
	 * @param page
	 * @param sqlString
	 * @param resultClass
	 * @param parameter
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public <E> Page<E> findBySql(Page<E> page, String sqlString,
			Class<?> resultClass, Object... parameter) {
		// get count
		if (!page.isDisabled() && !page.isNotCount()) {
			String countSqlString = countSql(sqlString);
			// page.setCount(Long.valueOf(createSqlQuery(countSqlString,
			// parameter).uniqueResult().toString()));
			Query query = createSqlQuery(countSqlString, parameter);
			List<Object> list = query.list();
			if (list.size() > 0) {
				page.setCount(Long.valueOf(list.get(0).toString()));
			} else {
				page.setCount(list.size());
			}
			if (page.getCount() < 1) {
				return page;
			}
		}
		// order by
		String sql = sqlString;
		if (StringUtils.isNotBlank(page.getOrderBy())) {
			sql += " order by " + page.getOrderBy();
		}
		SQLQuery query = createSqlQuery(sql, parameter);
		// set page
		if (!page.isDisabled()) {
			query.setFirstResult(page.getFirstResult());
			query.setMaxResults(page.getMaxResults());
		}
		setResultTransformer(query, resultClass);
		page.setList(query.list());
		return page;
	}

	/**
	 * SQL inquiry
	 * 
	 * @param sqlString
	 * @param parameter
	 * @return
	 */
	public <E> List<E> findBySql(String sqlString, Object... parameter) {
		return findBySql(sqlString, null, parameter);
	}

	/**
	 * SQL inquiry
	 * 
	 * @param sqlString
	 * @param resultClass
	 * @param parameter
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public <E> List<E> findBySql(String sqlString, Class<?> resultClass,
			Object... parameter) {
		SQLQuery query = createSqlQuery(sqlString, parameter);
		setResultTransformer(query, resultClass);
		return query.list();
	}

	/**
	 * SQL update
	 * 
	 * @param sqlString
	 * @param parameter
	 * @return
	 */
	public int updateBySql(String sqlString, Object... parameter) {
		return createSqlQuery(sqlString, parameter).executeUpdate();
	}

	/**
	 * create SQL inquiry instance
	 * 
	 * @param sqlString
	 * @param parameter
	 * @return
	 */
	public SQLQuery createSqlQuery(String sqlString, Object... parameter) {
		SQLQuery query = getSession().createSQLQuery(sqlString);
		setParameter(query, parameter);
		return query;
	}

	// -------------- Query Tools --------------

	/**
	 * setResult Transformer class
	 * 
	 * @param query
	 * 
	 * @param resultClass
	 */
	private void setResultTransformer(SQLQuery query, Class<?> resultClass) {
		if (resultClass != null) {
			if (resultClass == Map.class) {
				query.setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
			} else if (resultClass == List.class) {
				query.setResultTransformer(Transformers.TO_LIST);
			} else if (isMappingNormalBean(resultClass)) {
				mappingNormalBean(query, resultClass);
			} else {
				query.addEntity(resultClass);
			}
		}
	}

	/**
	 * confirm that is Mapping to the Normal Bean
	 * 
	 * @param resultClass
	 * @return the class that with Annotation InquiryMapping
	 */
	private boolean isMappingNormalBean(Class<?> resultClass) {
		return (!SMUtil.isObjectNull(resultClass
				.getAnnotation(InquiryMapping.class)));
	}

	/**
	 * mapping the sQL {@link Column} to the normal bean
	 * 
	 * @param query
	 *            the SQLQuery instance
	 * @param resultClass
	 *            the normal bean class type
	 */
	private void mappingNormalBean(SQLQuery query, Class<?> resultClass) {
		query.setResultTransformer(Transformers.aliasToBean(resultClass));
		Field[] fields = resultClass.getDeclaredFields();
		for (Field field : fields) {
			final FieldMapped fieldMapped = field
					.getAnnotation(FieldMapped.class);
			if (!SMUtil.isObjectNull(fieldMapped)) {
				final String fieldName = field.getName();
				final Class<?> type = field.getType();
				if (type.isAssignableFrom(Long.class)) {
					query.addScalar(fieldName, StandardBasicTypes.LONG);
				} else if (type.isAssignableFrom(Integer.class)) {
					query.addScalar(fieldName, StandardBasicTypes.INTEGER);
				} else if (type.isAssignableFrom(Double.class)) {
					query.addScalar(fieldName, StandardBasicTypes.DOUBLE);
				} else if (type.isAssignableFrom(String.class)) {
					query.addScalar(fieldName, StandardBasicTypes.STRING);
				} else if (type.isAssignableFrom(Timestamp.class)) {
					query.addScalar(fieldName, StandardBasicTypes.TIMESTAMP);
				} else if (type.isAssignableFrom(Date.class)) {
					query.addScalar(fieldName, StandardBasicTypes.DATE);
				} else {
					Log.warn("the class type:" + type.getName()
							+ " is not supported..");
				}
			}
		}
	}

	/**
	 * 
	 * 
	 * @param query
	 * @param parameter
	 */
	private void setParameter(Query query, Object... parameter) {
		if (parameter != null) {
			for (int i = 0; i < parameter.length; i++) {
				query.setParameter(i, parameter[i]);
			}
		}
	}

	public String countSql(String qlString) {
		String countSqlString = "select count(*) from (" + qlString + ") tmp ";
		return countSqlString;
	}

	// -------------- Criteria --------------

	/**
	 * 
	 * 
	 * @param page
	 * @return
	 */
	public Page<M> findPage(Page<M> page) {
		return findPage(page, createDetachedCriteria());
	}

	/**
	 * 
	 * 
	 * @param page
	 * @param detachedCriteria
	 * @param resultTransformer
	 * @return
	 */
	public Page<M> findPage(Page<M> page, DetachedCriteria detachedCriteria) {
		return findPage(page, detachedCriteria, Criteria.DISTINCT_ROOT_ENTITY);
	}

	/**
	 * 
	 * 
	 * @param page
	 * @param detachedCriteria
	 * @param resultTransformer
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public Page<M> findPage(Page<M> page, DetachedCriteria detachedCriteria,
			ResultTransformer resultTransformer) {
		// get count
		if (!page.isDisabled() && !page.isNotCount()) {
			page.setCount(count(detachedCriteria));
			if (page.getCount() < 1) {
				return page;
			}
		}
		Criteria criteria = detachedCriteria
				.getExecutableCriteria(getSession());
		criteria.setResultTransformer(resultTransformer);
		// set page
		if (!page.isDisabled()) {
			criteria.setFirstResult(page.getFirstResult());
			criteria.setMaxResults(page.getMaxResults());
		}
		// order by
		if (StringUtils.isNotBlank(page.getOrderBy())) {
			for (String order : StringUtils.split(page.getOrderBy(), ",")) {
				String[] o = StringUtils.split(order, " ");
				if (o.length == 1) {
					criteria.addOrder(Order.asc(o[0]));
				} else if (o.length == 2) {
					if ("DESC".equals(o[1].toUpperCase())) {
						criteria.addOrder(Order.desc(o[0]));
					} else {
						criteria.addOrder(Order.asc(o[0]));
					}
				}
			}
		}
		page.setList(criteria.list());
		return page;
	}

	/**
	 * 
	 * 
	 * @param detachedCriteria
	 * @return
	 */
	public List<M> find(DetachedCriteria detachedCriteria) {
		return find(detachedCriteria, Criteria.DISTINCT_ROOT_ENTITY);
	}

	@SuppressWarnings("unchecked")
	public <T> List<T> findAndCast(DetachedCriteria detachedCriteria) {
		Criteria criteria = detachedCriteria
				.getExecutableCriteria(getSession());
		return criteria.list();
	}

	/**
	 * 
	 * 
	 * @param detachedCriteria
	 * @param resultTransformer
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<M> find(DetachedCriteria detachedCriteria,
			ResultTransformer resultTransformer) {
		Criteria criteria = detachedCriteria
				.getExecutableCriteria(getSession());
		criteria.setResultTransformer(resultTransformer);
		return criteria.list();
	}

	/**
	 * 
	 * 
	 * @param detachedCriteria
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public long count(DetachedCriteria detachedCriteria) {
		Criteria criteria = detachedCriteria
				.getExecutableCriteria(getSession());
		long totalCount = 0;
		try {
			// Get orders
			Field field = CriteriaImpl.class.getDeclaredField("orderEntries");
			field.setAccessible(true);
			List orderEntrys = (List) field.get(criteria);
			// Remove orders
			field.set(criteria, new ArrayList());
			// Get count
			criteria.setProjection(Projections.rowCount());
			totalCount = Long.valueOf(criteria.uniqueResult().toString());
			// Clean count
			criteria.setProjection(null);
			// Restore orders
			field.set(criteria, orderEntrys);
		} catch (NoSuchFieldException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}
		return totalCount;
	}

	/**
	 * 
	 * 
	 * @param criterions
	 *            Restrictions.eq("name", value);
	 * @return
	 */
	public DetachedCriteria createDetachedCriteria(Criterion... criterions) {
		DetachedCriteria dc = DetachedCriteria.forClass(entityClass);
		for (Criterion c : criterions) {
			dc.add(c);
		}
		return dc;
	}

	// -------------- Hibernate search --------------

	/**
	 * 
	 */
	public FullTextSession getFullTextSession() {
		return Search.getFullTextSession(getSession());
	}

	/**
	 * 
	 */
	public void createIndex() {
		try {
			getFullTextSession().createIndexer(entityClass).startAndWait();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	@SuppressWarnings("unchecked")
	public Page<M> search(Page<M> page, BooleanQuery query,
			BooleanQuery queryFilter, Sort sort) {

		FullTextQuery fullTextQuery = getFullTextSession().createFullTextQuery(
				query, entityClass);

		fullTextQuery.setFilter(new CachingWrapperFilter(
				new QueryWrapperFilter(queryFilter)));

		page.setCount(fullTextQuery.getResultSize());
		fullTextQuery.setFirstResult(page.getFirstResult());
		fullTextQuery.setMaxResults(page.getMaxResults());

		fullTextQuery.initializeObjectsWith(
				ObjectLookupMethod.SECOND_LEVEL_CACHE,
				DatabaseRetrievalMethod.QUERY);

		page.setList(fullTextQuery.list());

		return page;
	}

	public BooleanQuery getFullTextQuery(BooleanClause... booleanClauses) {
		BooleanQuery booleanQuery = new BooleanQuery();
		for (BooleanClause booleanClause : booleanClauses) {
			booleanQuery.add(booleanClause);
		}
		return booleanQuery;
	}

}