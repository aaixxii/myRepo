package jp.co.nec.aim.sm.modules.sys.oracle.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the FE_LOT_JOBS database table.
 * 
 */
@Entity
@Table(name = "FE_LOT_JOBS")
public class FeLotJobEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "fe_lot_jobs_generator", sequenceName = "FE_LOT_JOB_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "fe_lot_jobs_generator")
	@Column(name = "LOT_JOB_ID")
	private long lotJobId;

	@Column(name = "ASSIGNED_TS")
	private Long assignedTs;

	@Column(name = "MU_ID")
	private int muId;

	private long timeouts;

	public FeLotJobEntity() {
	}

	public long getLotJobId() {
		return this.lotJobId;
	}

	public void setLotJobId(long lotJobId) {
		this.lotJobId = lotJobId;
	}

	public Long getAssignedTs() {
		return assignedTs;
	}

	public void setAssignedTs(Long assignedTs) {
		this.assignedTs = assignedTs;
	}

	public int getMuId() {
		return muId;
	}

	public void setMuId(int muId) {
		this.muId = muId;
	}

	public long getTimeouts() {
		return timeouts;
	}

	public void setTimeouts(long timeouts) {
		this.timeouts = timeouts;
	}

}