package jp.co.nec.aim.sm.modules.sys.web.register;

import jp.co.nec.aim.sm.common.constant.SMConstant;
import jp.co.nec.aim.sm.common.properties.SMProperties;
import jp.co.nec.aim.sm.common.utils.SMUtil;
import jp.co.nec.aim.sm.mm.listener.MMQueueListener;
import jp.co.nec.aim.sm.mm.listener.MatchManagerQueueListener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CommunicationThread {

	/** the log instance **/
	private static Logger logger = LoggerFactory
			.getLogger(CommunicationThread.class);

	private static boolean isStop = false;
	private static boolean isRunning = false;

	/**
	 * SM Report Interval
	 */
	private final static Long smInterval = SMProperties.getSmInterval();

	private final static RegisterRequest registerRequest = new RegisterRequest();

	public static void doStart() {
		Thread thread = new Thread() {
			public void run() {
				isRunning = true;
				do {
					try {
						if (SMUtil.isObjectNull(SMConstant.getSM_ID())) {
							if (registerRequest.sendEnter() != null) {
								startMMListener();
							}
						} else {
							if (registerRequest.sendHeartbeat() == null) {
								shutdownMMListener();
							}
						}
					} catch (Exception e) {
						SMConstant.setSM_ID(null);
						shutdownMMListener();
						logger.error("Exception: " + e.getMessage());
					}

					try {
						Thread.sleep(smInterval);
					} catch (InterruptedException e) {
						logger.error("InterruptedException when Thread Sleep: "
								+ e.getMessage());
					}
				} while (!isStop);

				registerRequest.sendExit();
				isRunning = false;
			}
		};

		thread.start();
	}

	public static void doStop() {
		isStop = true;
		while (isRunning) {
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {

			}
		}
		shutdownMMListener();
	}

	private static void startMMListener() {
		logger.info("start queue Listener and queue connection");
		MatchManagerQueueListener listener = MMQueueListener.getInstance()
				.getListener();
		if (listener != null) {
			listener.startupQueueListener();
			listener.startQueueNotifier();
		}
	}

	private static void shutdownMMListener() {
		logger.info("Shutdown queue Listener and queue connection");
		MatchManagerQueueListener listener = MMQueueListener.getInstance()
				.getListener();
		if (listener != null) {
			listener.shutdownQueueNotifier();
			listener.shutdownQueueListener();
			MMQueueListener.getInstance().setListener(null);
		}
	}
}
