package jp.co.nec.aim.sm.modules.sys.oracle.repository;

import jp.co.nec.aim.sm.common.persistence.BaseRepository;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.ContainerJobEntity;

public interface ContainerJobRepository extends
		BaseRepository<ContainerJobEntity, Long> {
	// public Page<MuJobQueueEntity> findMuJobPage(
	// Page<MuJobQueueEntity> page, MuJobQueueEntity mujob);
	//
	// public List<MuJobQueueEntity> findMuJobList(MuJobQueueEntity mujob);
	//
	// public List<MuJobsPojo> findMuJobsSummary(Long muid,
	// String startTime, String endTime);
	//
	// public List<String> findJobsFunctionType();
	//
	// public List<Long> findMuIdList();
	//
	// public List<Long> findMuIdPage(Page<MuJobsPojo> page);
	//
	// public String findResultsByMuJobId(Long muJobId, String field);
	//
	// public List<MuJobFailureReasonEntity> getFailureReason(Long muJobId);
	//
	// public List<MuJobQueueEntity> getCompleted(Long jobId);
}
