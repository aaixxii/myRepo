package jp.co.nec.aim.sm.modules.sys.oracle.repository;

import java.util.List;

import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.common.utils.SMUtil;
import jp.co.nec.aim.sm.exception.SMServiceException;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.MuSegReportEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.SegmentWithReport;

import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;

public class MatchUnitSegmentReportRepositoryImpl {

	@Autowired
	MatchUnitSegmentReportRepository repository;

	private String getSegWithReportSQL(MuSegReportEntity segwithreport) {
		String sql = "SELECT msr.MU_ID as pidUnitId,"
				+ " msr.SEGMENT_ID as segmentId,"
				+ " msr.STATUS as state,"
				+ " msr.SEGMENT_VERSION as segmentVersion,"
				+ " msr.SEGMENT_QUEUED_VERSION as segmentQueuedVersion,"
				+ " msr.RANK as rank,"
				+ " msr.ASSIGNED_TS as assignedTimestamp,"
				+ " ss.VERSION as version  FROM (SELECT * FROM  mu_seg_reports full outer join mu_segments"
				+ "				USING (mu_id, segment_id) ";

		String sqltemp = "";
		final Long pidUnitId = segwithreport.getMuId();
		if (!SMUtil.isObjectNull(pidUnitId)) {
			sqltemp = gainSqlTemp(sqltemp);
			sqltemp += " MU_ID=" + pidUnitId;
		}
		final Long segmentId = segwithreport.getSegmentId();
		if (!SMUtil.isObjectNull(segmentId)) {
			sqltemp = gainSqlTemp(sqltemp);
			sqltemp += " SEGMENT_ID=" + segmentId;
		}

		final Integer state = segwithreport.getStatus();
		if (!SMUtil.isObjectNull(state)) {
			sqltemp = gainSqlTemp(sqltemp);
			sqltemp += " STATUS=" + state;
		}
		sql += sqltemp;
		sql += " ) msr  LEFT JOIN segments ss ON  msr.segment_id = ss.segment_id";
		return sql;
	}

	public String gainSqlTemp(String sqltemp) {
		if (sqltemp == "") {
			sqltemp += " where ";
		} else {
			sqltemp += " and ";
		}
		return sqltemp;
	}

	public Page<SegmentWithReport> gainSegWithReport(
			Page<SegmentWithReport> page, MuSegReportEntity segwithreport) {
		String sql = getSegWithReportSQL(segwithreport);
		if (!StringUtils.isNotBlank(page.getOrderBy())) {
			sql += " order by pidUnitId, segmentId asc ";
		}
		return repository.findBySql(page, sql, SegmentWithReport.class);
	}

	public Page<MuSegReportEntity> findMuSegRepPage(
			Page<MuSegReportEntity> page, MuSegReportEntity muSegRep) {
		try {
			DetachedCriteria dc = getDetachedCriteria(muSegRep);
			if (StringUtils.isBlank(page.getOrderBy())) {
				dc.addOrder(Order.asc("id.matchUnitId"));
				dc.addOrder(Order.asc("id.segmentId"));
			}
			return repository.findPage(page, dc);
		} catch (Exception ex) {
			throw new SMServiceException(ex);
		}
	}

	private DetachedCriteria getDetachedCriteria(MuSegReportEntity muSegRep) {
		// create the DetachedCriteria instance without session
		final DetachedCriteria dc = DetachedCriteria
				.forClass(MuSegReportEntity.class);

		// add the unit id condition
		final Long unitId = muSegRep.getMuId();
		if (!SMUtil.isObjectNull(unitId)) {
			dc.add(Restrictions.eq("id.matchUnitId", unitId));
		}

		// add condition unit Segment
		final Long segmentId = muSegRep.getSegmentId();
		if (!SMUtil.isObjectNull(segmentId)) {
			dc.add(Restrictions.eq("id.segmentId", segmentId));
		}

		// add condition unit state
		final int status = muSegRep.getStatus();
		if (!SMUtil.isObjectNull(status)) {
			dc.add(Restrictions.eq("status", status));
		}
		return dc;
	}

	public List<MuSegReportEntity> ListMuSegRep(MuSegReportEntity muSegRep) {
		try {
			DetachedCriteria dc = getDetachedCriteria(muSegRep);

			dc.addOrder(Order.asc("id.matchUnitId"));
			dc.addOrder(Order.asc("id.segmentId"));

			return repository.find(dc);
		} catch (Exception ex) {
			throw new SMServiceException(ex);
		}
	}

	public List<SegmentWithReport> ListSegWithReport(
			MuSegReportEntity segwithreport) {
		String sql = getSegWithReportSQL(segwithreport);
		sql += " order by pidUnitId, segmentId asc ";
		return repository.findBySql(sql, SegmentWithReport.class);
	}

}
