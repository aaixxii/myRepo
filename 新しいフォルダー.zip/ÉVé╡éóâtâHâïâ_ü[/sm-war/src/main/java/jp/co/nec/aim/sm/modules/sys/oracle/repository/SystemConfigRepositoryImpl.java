package jp.co.nec.aim.sm.modules.sys.oracle.repository;

import java.util.List;

import jp.co.nec.aim.sm.common.constant.MMConfigProperty;
import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.common.utils.SMUtil;
import jp.co.nec.aim.sm.exception.SMDaoException;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.SystemConfigEntity;

import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

public class SystemConfigRepositoryImpl {
	/** the log instance **/
	private static Logger logger = LoggerFactory
			.getLogger(SystemConfigRepositoryImpl.class);

	@Autowired
	SystemConfigRepository repository;

	/**
	 * get Detached Criteria
	 * 
	 * @param systemConfig
	 * @return
	 */
	private DetachedCriteria getDetachedCriteria(SystemConfigEntity systemConfig) {
		// create the DetachedCriteria instance without session
		final DetachedCriteria dc = DetachedCriteria
				.forClass(SystemConfigEntity.class);

		// add condition configId
		final Integer configId = systemConfig.getConfigId();
		if (!SMUtil.isObjectNull(configId)) {
			logger.debug("add condition configId = {}", configId);
			dc.add(Restrictions.eq("configId", configId));
		}

		// add condition propertyName
		final String propertyName = systemConfig.getPropertyName();
		if (StringUtils.isNotBlank(propertyName)) {
			logger.debug("add condition propertyName = {}", propertyName);
			dc.add(Restrictions.eq("propertyName", propertyName));
		}
		return dc;
	}

	/**
	 * find System Configure Page
	 * 
	 * @param page
	 * @param systemConfig
	 * @return
	 */
	public Page<SystemConfigEntity> findSystemConfigPage(
			Page<SystemConfigEntity> page, SystemConfigEntity systemConfig) {
		final DetachedCriteria dc = getDetachedCriteria(systemConfig);
		// add order by condition
		if (!StringUtils.isNotBlank(page.getOrderBy())) {
			logger.debug("add Order configId");
			dc.addOrder(Order.asc("configId"));
		}
		logger.debug("findPage for SystemConfigEntity");
		return repository.findPage(page, dc);
	}

	/**
	 * find System Configure List
	 * 
	 * @param page
	 * @param systemConfig
	 * @return
	 */
	public List<SystemConfigEntity> findSystemConfig(
			SystemConfigEntity systemConfig) {
		final DetachedCriteria dc = getDetachedCriteria(systemConfig);
		// add order by condition
		logger.debug("add Order configId");
		dc.addOrder(Order.asc("configId"));

		logger.debug("findPage for SystemConfigEntity");
		return repository.find(dc);
	}

	/**
	 * find By PropertyName
	 * 
	 * @param propertyName
	 * @return
	 */
	public SystemConfigEntity findByPropertyName(String propertyName) {
		DetachedCriteria dc = DetachedCriteria
				.forClass(SystemConfigEntity.class);
		logger.debug("add condition propertyName = {}", propertyName);
		dc.add(Restrictions.eq("propertyName", propertyName));
		List<SystemConfigEntity> list = repository.find(dc);
		if (list.size() == 0) {
			String message = "Can not find Property = " + propertyName;
			throw new SMDaoException(message);
		}
		return list.get(0);
	}

	/**
	 * find By property
	 * 
	 * @param property
	 * @return
	 */
	public SystemConfigEntity findByProperty(MMConfigProperty property) {
		return findByPropertyName(property.getName());
	}

	/**
	 * update System Configure
	 * 
	 * @param configId
	 * @param propertyName
	 * @param propertyValue
	 * @return
	 */
	public int updateSystemConfig(Integer configId, String propertyName,
			String propertyValue) {
		String sql = "update SYSTEM_CONFIG set PROPERTY_VALUE = '"
				+ propertyValue + "' where ";

		if (!SMUtil.isObjectNull(configId)
				&& StringUtils.isNotBlank(propertyName)) {
			sql += " CONFIG_ID = " + configId + " AND PROPERTY_NAME = '"
					+ propertyName + "'";
			return repository.updateBySql(sql);
		} else if (!SMUtil.isObjectNull(configId)) {
			sql += " CONFIG_ID = " + configId;
			return repository.updateBySql(sql);
		} else if (StringUtils.isNotBlank(propertyName)) {
			sql += " PROPERTY_NAME = '" + propertyName + "'";
			return repository.updateBySql(sql);
		} else {
			return 0;
		}
	}

	/**
	 * get String Property
	 * 
	 * @param property
	 * @return
	 */
	public String getProperty(MMConfigProperty property) {
		SystemConfigEntity entity = findByProperty(property);
		return entity.getPropertyValue();
	}

	/**
	 * get Long Property
	 * 
	 * @param property
	 * @return
	 */
	public long getLongProperty(MMConfigProperty property) {
		SystemConfigEntity entity = findByProperty(property);
		return Long.parseLong(entity.getPropertyValue());
	}

	/**
	 * get Integer Property
	 * 
	 * @param property
	 * @return
	 */
	public int getIntProperty(MMConfigProperty property) {
		SystemConfigEntity entity = findByProperty(property);
		return Integer.parseInt(entity.getPropertyValue());
	}

	/**
	 * get Boolean Property
	 * 
	 * @param property
	 * @return
	 */
	public boolean getBooleanProperty(MMConfigProperty property) {
		SystemConfigEntity entity = findByProperty(property);
		return Boolean.parseBoolean(entity.getPropertyValue());
	}
}
