package jp.co.nec.aim.sm.modules.sys.postgres.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "\"USER_RELATIONS\"", schema = "public")
public class UserRelation {

	/**
	 * @return the userId
	 */
	public Long getUserId() {
		return userId;
	}

	/**
	 * @param userId
	 *            the userId to set
	 */
	public void setUserId(Long userId) {
		this.userId = userId;
	}

	/**
	 * @return the associatedUserId
	 */
	public Long getAssociatedUserId() {
		return associatedUserId;
	}

	/**
	 * @param associatedUserId
	 *            the associatedUserId to set
	 */
	public void setAssociatedUserId(Long associatedUserId) {
		this.associatedUserId = associatedUserId;
	}

	@SequenceGenerator(name = "seq_stat", sequenceName = "userRelation_seq_id")
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_stat")
	@Column(name = "\"USER_RELATION_ID\"")
	private Long userRelationId;

	@Column(name = "\"USER_ID\"")
	private Long userId;

	@Column(name = "\"ASSOCIATED_USER_ID\"")
	private Long associatedUserId;

}
