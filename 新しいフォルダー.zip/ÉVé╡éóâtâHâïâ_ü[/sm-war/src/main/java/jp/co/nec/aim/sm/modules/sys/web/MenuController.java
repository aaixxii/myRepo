package jp.co.nec.aim.sm.modules.sys.web;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import jp.co.nec.aim.sm.common.constant.Constants;
import jp.co.nec.aim.sm.modules.sys.postgres.entity.MenuEntity;
import jp.co.nec.aim.sm.modules.sys.util.MenuUtils;
import jp.co.nec.aim.sm.modules.sys.web.base.BaseController;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.apache.shiro.authz.annotation.RequiresUser;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

@Controller
@RequestMapping(value = "/menu")
@RequiresPermissions(Constants.PERMISSION_VIEWER)
public class MenuController extends BaseController {

	@RequiresUser
	@RequestMapping(value = "tree")
	public String tree(
			@RequestParam(value = "parentId", required = false) Long parentId) {
		MenuEntity parentMenu = MenuUtils.findOne(parentId);

		String href = parentMenu.getChildList().get(0).getChildList().get(0)
				.getHref();

		return "redirect:" + href;
	}

	@RequiresUser
	@ResponseBody
	@RequestMapping(value = "treeData")
	public List<Map<String, Object>> treeData(
			@RequestParam(required = false) Long extId,
			HttpServletResponse response) {
		response.setContentType("application/json; charset=UTF-8");
		List<Map<String, Object>> mapList = Lists.newArrayList();
		List<MenuEntity> list = MenuUtils.getMenuList();
		for (int i = 0; i < list.size(); i++) {
			MenuEntity e = list.get(i);
			if (extId == null
					|| (extId != null && !extId.equals(e.getId()) && e
							.getParentIds().indexOf("," + extId + ",") == -1)) {
				Map<String, Object> map = Maps.newHashMap();
				map.put("id", e.getId());
				map.put("pId", e.getParent() != null ? e.getParent().getId()
						: 0);
				map.put("name", e.getName());
				mapList.add(map);
			}
		}
		return mapList;
	}
}
