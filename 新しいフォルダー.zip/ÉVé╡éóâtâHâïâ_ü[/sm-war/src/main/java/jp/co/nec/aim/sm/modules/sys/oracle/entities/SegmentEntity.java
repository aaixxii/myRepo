package jp.co.nec.aim.sm.modules.sys.oracle.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the SEGMENTS database table.
 * 
 */
@Entity
@Table(name = "SEGMENTS")
@NamedQuery(name = "SegmentEntity.findAll", query = "SELECT s FROM SegmentEntity s")
public class SegmentEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "SEGMENTS_SEGMENTID_GENERATOR", sequenceName = "SEGMENTS", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEGMENTS_SEGMENTID_GENERATOR")
	@Column(name = "SEGMENT_ID")
	private Long segmentId;

	@Column(name = "BINARY_LENGTH_COMPACTED")
	private long binaryLengthCompacted;

	@Column(name = "BINARY_LENGTH_UNCOMPACTED")
	private long binaryLengthUncompacted;

	@Column(name = "BIO_ID_END")
	private long bioIdEnd;

	@Column(name = "BIO_ID_START")
	private long bioIdStart;

	@Column(name = "CONTAINER_ID")
	private Long containerId;

	@Column(name = "RECORD_COUNT")
	private long recordCount;

	private long revision;

	@Column(name = "\"VERSION\"")
	private long version;

	public SegmentEntity() {
	}

	public Long getSegmentId() {
		return this.segmentId;
	}

	public void setSegmentId(Long segmentId) {
		this.segmentId = segmentId;
	}

	public long getBinaryLengthCompacted() {
		return this.binaryLengthCompacted;
	}

	public void setBinaryLengthCompacted(long binaryLengthCompacted) {
		this.binaryLengthCompacted = binaryLengthCompacted;
	}

	public long getBinaryLengthUncompacted() {
		return this.binaryLengthUncompacted;
	}

	public void setBinaryLengthUncompacted(long binaryLengthUncompacted) {
		this.binaryLengthUncompacted = binaryLengthUncompacted;
	}

	public long getBioIdEnd() {
		return this.bioIdEnd;
	}

	public void setBioIdEnd(long bioIdEnd) {
		this.bioIdEnd = bioIdEnd;
	}

	public long getBioIdStart() {
		return this.bioIdStart;
	}

	public void setBioIdStart(long bioIdStart) {
		this.bioIdStart = bioIdStart;
	}

	public Long getContainerId() {
		return this.containerId;
	}

	public void setContainerId(Long containerId) {
		this.containerId = containerId;
	}

	public long getRecordCount() {
		return this.recordCount;
	}

	public void setRecordCount(long recordCount) {
		this.recordCount = recordCount;
	}

	public long getRevision() {
		return this.revision;
	}

	public void setRevision(long revision) {
		this.revision = revision;
	}

	public long getVersion() {
		return this.version;
	}

	public void setVersion(long version) {
		this.version = version;
	}

}