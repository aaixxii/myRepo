package jp.co.nec.aim.sm.common.constant;

public enum BinActionType {
	Update, Filter;
}
