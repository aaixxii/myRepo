package jp.co.nec.aim.sm.common.async.agent;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * the Agent between from the manage thread <br>
 * and thread pool thread, it include the input <br>
 * parameter that will transfer to the each thread <br>
 * and the complete event that will callback to manage <br>
 * thread. it also contain the result object that the <br>
 * thread returned.
 * 
 * @author liuyq
 * 
 */
public final class AsyncAgent implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -9020282249667645176L;

	/**
	 * this locker used to create the Condition doneEvent <br>
	 * 1, get method will be locked by this locker and wait <br>
	 * for condition doneEvent notify. <br>
	 * 2, the thread will locked by this locker and notify <br>
	 * the doneEvent to release the above get method <br>
	 */
	private final ReentrantLock locker = new ReentrantLock(false);

	/**
	 * the locker condition instance <br>
	 * the get method will held this condition until the <br>
	 * thread finish to do the log task <br>
	 */
	private final Condition doneEvent = locker.newCondition();

	/** the current thread instance **/
	private Thread t;

	/** exception instance that thread occurred **/
	private Throwable ex;

	/** the result object that the thread returned **/
	private Object resultObject;

	/** task method used parameter **/
	private final List<Object> parameter = new ArrayList<Object>();

	/**
	 * is the thread done
	 */
	private AtomicBoolean isDone = new AtomicBoolean(false);
	private AtomicBoolean isRunning = new AtomicBoolean(false);

	/**
	 * this method will block until the task is finished
	 * 
	 * @return the return object
	 * @throws InterruptedException
	 */
	@SuppressWarnings("unchecked")
	public <T> T get() throws InterruptedException {
		locker.lock();
		try {
			while (isRunning()) {
				doneEvent.await();
			}
			return (T) resultObject;
		} finally {
			locker.unlock();
		}
	}

	/**
	 * get the instance of ReentrantLock
	 * 
	 * @return the locker
	 */
	public Lock getLock() {
		return this.locker;
	}

	/**
	 * get the Condition
	 * 
	 * @return the instance of Condition
	 */
	public Condition getCondition() {
		return this.doneEvent;
	}

	/**
	 * set the running
	 * 
	 * @param running
	 */
	public void setRunning(boolean running) {
		isRunning.set(running);
	}

	/**
	 * the constuctor with parameter array
	 * 
	 * @param paras
	 *            the parameter array
	 */
	private AsyncAgent(final Object[] paras) {
		parameter.addAll(Arrays.asList(paras));
	}

	/**
	 * get the parameter
	 * 
	 * @return the parameter
	 */
	public Object[] getParameters() {
		return parameter.toArray();
	}

	/**
	 * set the done event
	 */
	public void setDone() {
		isDone.set(true);
	}

	/**
	 * return the thread is done
	 * 
	 * @return the thread is done
	 */
	public boolean isDone() {
		return isDone.get();
	}

	/**
	 * is the operation running
	 * 
	 * @return the operation running or not
	 */
	public boolean isRunning() {
		return (isRunning.get());
	}

	public Thread getThread() {
		return t;
	}

	public void setThread(Thread t) {
		this.t = t;
	}

	public Throwable getException() {
		return ex;
	}

	public void setException(Throwable ex) {
		this.ex = ex;
	}

	@SuppressWarnings("unchecked")
	public <T> T getResultObject() {
		return (T) resultObject;
	}

	public void setResultObject(Object resultObject) {
		this.resultObject = resultObject;
	}

	/**
	 * hasResult or not
	 * 
	 * @return hasResult or not
	 */
	public boolean hasResult() {
		return (resultObject != null);
	}

	/**
	 * create new instance of AsyncResult
	 * 
	 * @return the instance of AsyncResult
	 */
	public static AsyncAgent newInstance(final Object[] paras) {
		return new AsyncAgent(paras);
	}

}
