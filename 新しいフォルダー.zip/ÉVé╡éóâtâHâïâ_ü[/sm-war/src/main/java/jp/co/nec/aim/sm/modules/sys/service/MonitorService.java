package jp.co.nec.aim.sm.modules.sys.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.nec.aim.sm.common.properties.SMProperties;
import jp.co.nec.aim.sm.modules.sys.BaseService;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.ComponentStatus;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.DBMonitorData;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.MuLoadPojo;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.TransactionMonitorData;
import jp.co.nec.aim.sm.modules.sys.oracle.repository.MonitorRepository;
import jp.co.nec.aim.sm.modules.sys.postgres.repository.EventLogRepository;
import jp.co.nec.aim.sm.modules.sys.util.MonitorUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional(value = "oracleTXManager")
public class MonitorService extends BaseService {
	@Autowired
	private EventLogRepository eventLogRepository;
	
	@Autowired
	private MonitorRepository monitorRepository;
	private MonitorUtil util = new MonitorUtil();
	private static Logger logger = LoggerFactory
			.getLogger(MonitorService.class);

	public Map<String, Map<String, Integer>> getComponentStatusData() {
		Map<String, Map<String, Integer>> results = null;
		List<ComponentStatus> componentStatusData = monitorRepository
				.getComponentStatusList();
		if (componentStatusData != null && componentStatusData.size() > 0) {
			results = util.convertStatusListToMap(componentStatusData);
		} else {
			String warning = "Got a empty data from database!";
			logger.warn(warning);		
		}
		return results;
	}

	public Map<String, Map<String, Integer>> getDBMonitorData(Integer scopeId) {
		Map<String, Map<String, Integer>> results = null;
		List<DBMonitorData> dBMonitorData = monitorRepository
				.getDBMonitorList(scopeId);
		if (dBMonitorData != null && dBMonitorData.size() > 0) {
			results = util.convertDBMonitorListToMap(dBMonitorData);
		} else {
			String warning = "Got a empty data from database!";
			logger.warn(warning);			
		}
		return results;
	}
	
	public Map<String, Map<String, Long>> getTransactionMonitorData() {
		Map<String, Map<String, Long>> results = null;
		List<TransactionMonitorData> transactionMonitorData = monitorRepository
				.getTransactionMonitorDataList();
		if (transactionMonitorData != null && transactionMonitorData.size() > 0) {
			results = util
					.convertTransactionMonitorToMap(transactionMonitorData);
		} else {
			String warning = "Got a empty data from database!";
			logger.warn(warning);			
		}
		return results;
	}

	public Map<String, Long> getMuInquiryLoadData() {
		Map<String, Long> results = null;
		List<MuLoadPojo> muLoadData = monitorRepository.getMuInquiryLoadDataList();
		if (muLoadData != null && muLoadData.size() > 0) {
			results = util.convertMuLoadListToMap(muLoadData);
		}
		return results;
	}

	public Map<String, Long> getMuExtractLoadData() {
		Map<String, Long> results = null;
		List<MuLoadPojo> muLoadData = monitorRepository.getMuExtractLoadDataList();
		if (muLoadData != null && muLoadData.size() > 0) {
			results = util.convertMuLoadListToMap(muLoadData);
		}
		return results;
	}		
	

	public Map<String,Boolean> getSlbStatus() {
		String slbStr = monitorRepository.getSlbStatus();
		
		Map<String,Boolean> slbMap = new HashMap<>();
		slbMap.put("slb", new Boolean(slbStr));		
		return slbMap;	
	}
	
	public Map<String ,String> getMonitorSetting() {
		Map<String ,String> monitorMap = new HashMap<>();
		monitorMap.put("slbCheckInterval", SMProperties.getSlbCheckInterval());
		monitorMap.put("alarmCheckInterval", SMProperties.getAlarmCheckInterval());
		monitorMap.put("pieChartInterval", SMProperties.getPieChartInterval());
		monitorMap.put("lineChartInterval", SMProperties.getLineChartInterval());
		monitorMap.put("barChartInterval", SMProperties.getBarChartInterval());
		monitorMap.put("muLoadChartInterval", SMProperties.getMuLoadChartInterval());
		monitorMap.put("scopeId", SMProperties.getScopeId());
		monitorMap.put("alarmTimeSetting", SMProperties.getAlarmTimeSetting());		
		return monitorMap;		
	}
}
