package jp.co.nec.aim.sm.modules.sys.postgres.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "\"FUNCTION_TYPES\"", schema = "public")
public class FunctionEntity {

	@Column(name = "\"FUNCTION_ID\"")
	@Id
	private Integer functionTypeId;

	@Column(name = "\"FUNCTION_NAME\"")
	private String functionName;

	@Column(name = "\"FUNCTION_FAMILY\"")
	private Integer functionFamily;

	@Column(name = "\"TARGET_FORMAT_ID\"")
	private Long targetFormatId;

	public Integer getFunctionTypeId() {
		return functionTypeId;
	}

	public void setFunctionTypeId(Integer functionTypeId) {
		this.functionTypeId = functionTypeId;
	}

	public Long getTargetFormatId() {
		return targetFormatId;
	}

	public void setTargetFormatId(Long targetFormatId) {
		this.targetFormatId = targetFormatId;
	}

	public void setFunctionName(String functionName) {
		this.functionName = functionName;
	}

	public String getFunctionName() {
		return functionName;
	}

	public void setFunctionFamily(Integer functionFamily) {
		this.functionFamily = functionFamily;
	}

	public Integer getFunctionFamily() {
		return functionFamily;
	}

}
