package jp.co.nec.aim.sm.common.worker;

import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;

import jp.co.nec.aim.sm.common.async.agent.AsyncAgent;
import jp.co.nec.aim.sm.common.properties.MMProperties;
import jp.co.nec.aim.sm.common.utils.SMUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * This class is the worker of MatchUnitGetConfig execution <br>
 * create a new thread to invoke the MatchUnitGetConfig <br>
 * get addition url and Connect to get smConfig context.<br>
 * 
 * @author jinxl
 * 
 */
public class MatchUnitConfigGetWorker extends AbstractWorker {

	/** the log instance **/
	private static Logger logger = LoggerFactory
			.getLogger(MatchUnitConfigGetWorker.class);
	/**
	 * the mu ip address
	 */
	private String ipAddress;
	/**
	 * the mu port
	 */
	private Integer muPort;

	/**
	 * smConfig mu Ip name
	 */
	private String muIpName;

	/**
	 * config's Url name
	 */
	private String urlName;

	/**
	 * Is MR
	 */
	private boolean isMR;

	/**
	 * the number of input correct parameter
	 */
	private final static int CORRECT_PARA_NUMBER = 2;

	/**
	 * connection timeout
	 */
	private final static int CONNECT_TIMEOUT = 1000;

	/**
	 * read timeout
	 */
	private final static int READ_TIMEOUT = 5000;

	/**
	 * get method
	 */
	private final static String GET_METHOD = "GET";

	/**
	 * the default constructor
	 * 
	 * @param result
	 *            the instance of AsyncAgent
	 */
	public MatchUnitConfigGetWorker(AsyncAgent result) {
		super(result);
		// get the parameter array
		Object[] paras = result.getParameters();

		// save each field
		URI ipPort = SMUtil.cast(paras[0]);

		// resolve URI ipPort
		this.ipAddress = ipPort.getHost();
		this.muPort = ipPort.getPort();
		this.isMR = SMUtil.cast(paras[1]);
		if (isMR) {
			urlName = MMProperties.getMRConfig();
		} else {
			urlName = MMProperties.getMUConfig();
		}
		String UnitName = isMR ? "MR" : "MU";
		this.muIpName = UnitName + "(" + ipAddress + ":" + muPort + ")";
	}

	@Override
	protected Object doTask(Object[] paras) throws Exception {
		// save sf to smConfig file
		getUnitConfiguration();
		return true;
	}

	/**
	 * Connect to Mu and get SmConfig
	 * 
	 * @param dirname
	 * @return
	 */
	private void getUnitConfiguration() {
		// make up geturl string
		// String urlname = MMProperties.gerMMConfig();
		String urlLocation = "http://" + ipAddress + ":" + muPort + urlName;
		logger.info("MU Configuration Location : " + urlLocation);

		HttpURLConnection connection = null;
		InputStreamReader isR = null;
		try {
			// Open Connection
			URL url = new URL(urlLocation);
			connection = (HttpURLConnection) url.openConnection();
			connection.setConnectTimeout(CONNECT_TIMEOUT);
			connection.setRequestMethod(GET_METHOD);
			/**
			 * Output to the connection. Default is false. set to true because
			 * post method must write something to the connection.
			 */
			connection.setDoOutput(true);
			connection.setReadTimeout(READ_TIMEOUT);
			Long totalTime = System.currentTimeMillis();
			connection.connect();
			isR = new InputStreamReader(connection.getInputStream());

			logger.info("Called, match unit HTTP URL=" + urlLocation);

			MatchUnitParameterDictionary.addMatchUnitList(isR, muIpName, isMR);

			logger.info(muIpName
					+ " >>> Total time for mu configure reading = "
					+ (System.currentTimeMillis() - totalTime));

		} catch (IOException e) {
			logger.error(
					"Unable to establish connection for access IP Address "
							+ urlLocation + ", error message = "
							+ e.getLocalizedMessage(), e);
		} finally {
			SMUtil.close(isR);
			SMUtil.close(connection);
		}
	}

	@Override
	protected void checkParameter(Object[] paras)
			throws IllegalArgumentException {
		if (SMUtil.isNullOrEmpty(paras)) {
			throw new IllegalArgumentException("the parameter is incorrect..");
		}

		if (paras.length != CORRECT_PARA_NUMBER) {
			throw new IllegalArgumentException("the parameter length is not "
					+ CORRECT_PARA_NUMBER + "..");
		}
	}
}
