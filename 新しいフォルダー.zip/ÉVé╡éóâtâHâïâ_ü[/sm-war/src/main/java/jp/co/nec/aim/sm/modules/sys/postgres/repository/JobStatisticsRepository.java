package jp.co.nec.aim.sm.modules.sys.postgres.repository;

import java.util.List;

import jp.co.nec.aim.sm.common.persistence.BaseRepository;
import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.modules.sys.postgres.entity.JobStatistics;
import jp.co.nec.aim.sm.modules.sys.postgres.pojo.mapping.CardQualityPojo;

/**
 * JobStatisticsRepository interface
 */
public interface JobStatisticsRepository extends
		BaseRepository<JobStatistics, Integer> {

	/** get data from JOB_STATISTICS for Unit Job AMR **/
	public Page<JobStatistics> getUnitJobAMR(Page<JobStatistics> page,
			JobStatistics jobStatEntity);

	/** get data from JOB_STATISTICS for Unit Job AMR **/
	public List<JobStatistics> getUnitJobAMR(JobStatistics jobStatEntity);

	/** get data from JOB_STATISTICS for Unit Job Elapse **/
	public Page<JobStatistics> getUnitJobElapse(Page<JobStatistics> page,
			JobStatistics jobStatEntity);

	/** get data from JOB_STATISTICS for Unit Job Elapse **/
	public List<JobStatistics> getUnitJobElapse(JobStatistics jobStatEntity);

	/** get Function List from JOB_STATISTICS **/
	public List<String> getFunctionList();

	/** get MuId List from JOB_STATISTICS **/
	public List<Long> getMuIdList();

	/** get qualityType(Roll), card quality data from JOB_STATISTICS **/
	public Page<CardQualityPojo> getCardQualityRoll(
			Page<CardQualityPojo> page, JobStatistics jobStatEntity);

	/** get qualityType(Roll), card quality data from JOB_STATISTICS **/
	public List<CardQualityPojo> getCardQualityRoll(JobStatistics jobStatEntity);

	/** get qualityType(Slap), card quality data from JOB_STATISTICS **/
	public Page<CardQualityPojo> getCardQualitySlap(
			Page<CardQualityPojo> page, JobStatistics jobStatEntity);

	/** get qualityType(Slap), card quality data from JOB_STATISTICS **/
	public List<CardQualityPojo> getCardQualitySlap(JobStatistics jobStatEntity);

	/** get qualityType(All), card quality data from JOB_STATISTICS **/
	public Page<CardQualityPojo> getCardQuality(Page<CardQualityPojo> page,
			JobStatistics jobStatEntity);

	/** get qualityType(All), card quality data from JOB_STATISTICS **/
	public List<CardQualityPojo> getCardQuality(JobStatistics jobStatEntity);

}
