package jp.co.nec.aim.sm.modules.sys.service;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import jp.co.nec.aim.sm.common.utils.MuConfigItemUtils;
import jp.co.nec.aim.sm.common.utils.MuConfigUtils;
import jp.co.nec.aim.sm.common.utils.SMUtil;
import jp.co.nec.aim.sm.common.worker.MatchUnitParameterDictionary;
import jp.co.nec.aim.sm.exception.SMServiceException;
import jp.co.nec.aim.sm.modules.sys.BaseService;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.UnitPojo;
import jp.co.nec.aim.sm.modules.sys.oracle.repository.MatchUnitRepository;
import jp.co.nec.aim.sm.unitparameter.constant.MatchUnitDisableParam;
import jp.co.nec.aim.sm.unitparameter.dispatcher.MatchUnitConfigGrouptasks;
import jp.co.nec.aim.sm.unitparameter.dispatcher.MatchUnitEditConfigGrouptasks;
import jp.co.nec.aim.sm.unitparameter.model.MatchUnitConfig;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.gson.Gson;

/**
 * Unit Parameter Service
 * 
 * @author jinxl
 * 
 */
@Service
@Transactional(value = "oracleTXManager")
public class UnitParameterService extends BaseService {

	/** the log instance **/
	private static Logger logger = LoggerFactory
			.getLogger(UnitParameterService.class);

	@Autowired
	private MatchUnitRepository matchUnitDao;

	/**
	 * get all WORKING MU in System
	 * 
	 * @return
	 */
	public List<UnitPojo> findAllMUUnitsList() {
		try {
			return matchUnitDao.getAllWorkingMUUnits();
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			throw new SMServiceException(ex);
		}
	}

	/**
	 * get all WORKING MR in System
	 * 
	 * @return
	 */
	public List<UnitPojo> findAllMRUnitsList() {
		try {
			return matchUnitDao.getAllWorkingMRUnits();
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			throw new SMServiceException(ex);
		}
	}

	/**
	 * get all WORKING MU's URI in System
	 * 
	 * @return
	 */
	public List<URI> findMUURI(boolean isMR) {
		List<UnitPojo> unitlist = null;
		String url = null;
		String UnitName = null;
		if (isMR) {
			unitlist = findAllMRUnitsList();
			url = "/mapreducer";
			UnitName = "MR";
		} else {
			unitlist = findAllMUUnitsList();
			url = "/matchunit";
			UnitName = "MU";
		}

		int unitSize = unitlist.size();
		List<URI> unitIpList = new ArrayList<URI>(unitSize);
		for (UnitPojo unit : unitlist) {
			try {
				final URI ipPort = new URI(unit.getContactURL() + url);
				if (!SMUtil.isObjectNull(ipPort)) {
					logger.info("Excecuting " + UnitName + " IPAddress="
							+ ipPort.getHost() + ", " + UnitName + "  port="
							+ ipPort.getPort());
					unitIpList.add(ipPort);
				} else {
					logger.warn("this mu:" + unit.getUniqueId()
							+ " contact url with some error. "
							+ "skip do edite this" + UnitName + " Config..");
				}
			} catch (URISyntaxException e) {
				logger.error("ContactURL Convert to URI Failed..", e);
				throw new SMServiceException(e);
			}
		}
		return unitIpList;
	}

	/**
	 * get Match Unit Parameters Data
	 * 
	 * @return
	 */
	public List<MuConfigUtils> getMatchUnitParameterMap(boolean isMR) {
		List<MuConfigUtils> matchUnitParameterMap;
		MatchUnitParameterDictionary.resetMatchUnitParameterMap(isMR);

		matchUnitParameterMap = MatchUnitParameterDictionary
				.getMatchUnitParameterMap(isMR);

		for (int index = 0; index < matchUnitParameterMap.size(); index++) {
			for (int idx = 0; idx < matchUnitParameterMap.get(index)
					.getMuConfigSection().size(); idx++) {
				Collections.sort(matchUnitParameterMap.get(index)
						.getMuConfigSection().get(idx).getMuConfigItems(),
						new Comparator<MuConfigItemUtils>() {
							@Override
							public int compare(MuConfigItemUtils arg0,
									MuConfigItemUtils arg1) {
								int rtn = arg0.getMuIpName().compareTo(
										arg1.getMuIpName());
								return rtn;
							}
						});
			}
		}
		return matchUnitParameterMap;
	}

	/**
	 * run threads to set matchUnitParameterMap
	 */
	public void ExecuteMatchUnitConfigThread(boolean isMR) {
		List<URI> uriIpList = findMUURI(isMR);
		MatchUnitParameterDictionary.clearMulist(isMR);
		new MatchUnitConfigGrouptasks(uriIpList, isMR).executeGetMuConfig();
	}

	/**
	 * get Actived MU IP List
	 * 
	 * @return
	 */
	public List<String> getActivedUnitIPList(boolean isMR) {
		List<String> mulist = null;
		mulist = MatchUnitParameterDictionary.getUnitlist(isMR);
		return mulist;
	}

	/**
	 * get disable System parameterkeys
	 * 
	 * @return
	 */
	public String getdisableSystem() {
		String system = MatchUnitDisableParam.getSystemConfig();
		return system;
	}

	/**
	 * get disable Mumgr parameterkeys
	 * 
	 * @return
	 */
	public String getdisableMumgr() {
		String mumgr = MatchUnitDisableParam.getMumgrConfig();
		return mumgr;
	}

	/**
	 * get disable Paths parameterkeys
	 * 
	 * @return
	 */
	public String getdisablePaths() {
		String paths = MatchUnitDisableParam.getPathsConfig();
		return paths;
	}

	/**
	 * get disable Childproc parameterkeys
	 * 
	 * @return
	 */
	public String getdisableChildproc() {
		String childproc = MatchUnitDisableParam.getChildprocConfig();
		return childproc;
	}

	/**
	 * get disable Statistics parameterkeys
	 * 
	 * @return
	 */
	public String getdisableStatistics() {
		String Statistics = MatchUnitDisableParam.getStatisticsConfig();
		return Statistics;
	}

	/**
	 * 
	 * run threads to update matchUnitParameter send to MU SmConfig
	 * 
	 * @param matchUnitConfigList
	 * @return
	 */
	public List<String> updateThreadPool(
			List<MatchUnitConfig> matchUnitConfigList, boolean isMR) {
		MatchUnitEditConfigGrouptasks matchUnitEditConfigGrouptasks = new MatchUnitEditConfigGrouptasks(
				matchUnitConfigList, isMR);
		matchUnitEditConfigGrouptasks.executeUpdateMuConfig();
		return matchUnitEditConfigGrouptasks.getResult();
	}

	public void removeDisableConfig(
			Map<String, LinkedHashMap<String, LinkedHashMap<String, String>>> matchUnitParameterMap,
			String permission) {
		// TODO
	}

	/**
	 * Get MuConfig section list
	 * 
	 * @return sectionlist
	 */
	public String getMuConfigSectionList(boolean isMR) {

		List<String> list = null;
		if (isMR) {
			list = MatchUnitParameterDictionary.getMrConfigSectionList();
		} else {
			list = MatchUnitParameterDictionary.getMuConfigSectionList();
		}
		Gson gson = new Gson();
		String sectionlist = gson.toJson(list);
		return sectionlist;
	}
}
