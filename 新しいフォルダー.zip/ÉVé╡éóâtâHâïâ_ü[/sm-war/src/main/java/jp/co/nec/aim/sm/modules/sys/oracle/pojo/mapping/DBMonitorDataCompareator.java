package jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping;

import java.util.Comparator;

public class DBMonitorDataCompareator implements Comparator<DBMonitorData> {

	@Override
	public int compare(DBMonitorData o1, DBMonitorData o2) {
		if (o1 == null || o2 == null || o1.getFunction() == null
				|| o2.getFunction() == null) {
			String errMsg = "There are null object in parameters,can't to compare two object!";
			throw new RuntimeException(errMsg);
		}
		int first = o1.getFunction().compareTo(o2.getFunction());
		int second = o1.getTemplateFormat().compareTo(o2.getTemplateFormat());
		int three = o1.getRecordCount().compareTo(o2.getRecordCount());
		return first != 0 ? first : (second != 0 ? second : three);
	}
}
