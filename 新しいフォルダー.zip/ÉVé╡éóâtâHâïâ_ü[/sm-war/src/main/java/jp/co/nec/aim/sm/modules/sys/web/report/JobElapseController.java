package jp.co.nec.aim.sm.modules.sys.web.report;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.nec.aim.sm.common.constant.Constants;
import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.modules.sys.postgres.entity.JobQueueEntity;
import jp.co.nec.aim.sm.modules.sys.postgres.pojo.mapping.JobElapsePojo;
import jp.co.nec.aim.sm.modules.sys.service.JobQueueService;
import jp.co.nec.aim.sm.modules.sys.web.base.BaseController;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping(value = "/jobElapseReport")
@RequiresPermissions(Constants.PERMISSION_VIEWER)
public class JobElapseController extends BaseController {
	/** the log instance **/
	private static Logger logger = LoggerFactory
			.getLogger(JobElapseController.class);

	@Autowired
	private JobQueueService jobService;

	/**
	 * 
	 * @param id
	 * @return
	 */
	@ModelAttribute("job")
	public JobQueueEntity get(@RequestParam(required = false) String id) {
		return new JobQueueEntity();
	}

	/**
	 * 
	 * @param JobQueueEntity
	 * @param request
	 * @param response
	 * @param model
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = { "list", "" })
	public String list(JobQueueEntity JobQueueEntity,
			HttpServletRequest request, HttpServletResponse response,
			Model model) throws IOException {
		// get Job Elapse Report
		logger.info("get Job Elapse Report");
		Page<JobElapsePojo> jobElapsePage = jobService.getJobElapse(
				new Page<JobElapsePojo>(request, response, -1), JobQueueEntity);
		jobElapsePage.setCount(jobElapsePage.getList().size());

		logger.info("page count:{}, list size:{}", jobElapsePage.getCount(),
				jobElapsePage.getList().size());

		List<String> functionList = jobService.findInquiryFunctionList();

		// add Attribute
		model.addAttribute("page", jobElapsePage);
		model.addAttribute("job", JobQueueEntity);
		model.addAttribute("functionList", functionList);
		model.addAttribute("dateType", request.getParameter("dateType"));

		logger.info("show Job Elapse Report");

		saveCurrentPageInfo(request, "/jobElapseReport/list", model);
		return "modules/report/jobelapsereport";
	}
}
