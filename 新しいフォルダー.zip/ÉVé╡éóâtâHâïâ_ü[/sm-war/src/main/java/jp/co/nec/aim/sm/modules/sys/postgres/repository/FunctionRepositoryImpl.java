package jp.co.nec.aim.sm.modules.sys.postgres.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * Function Type Repository interface
 */
public class FunctionRepositoryImpl {

	@Autowired
	private FunctionRepository repository;

	public List<String> findFunctionNameList() {
		return repository.find("select functionName from FunctionEntity");
	}

}
