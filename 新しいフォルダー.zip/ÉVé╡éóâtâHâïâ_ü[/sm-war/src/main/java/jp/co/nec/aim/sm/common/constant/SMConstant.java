package jp.co.nec.aim.sm.common.constant;

import java.text.DecimalFormat;

public class SMConstant {
	/** the format type of double **/
	private static final String FORMAT_TYPE = "0.00000000";

	/** the format instance **/
	public static final DecimalFormat FORMAT = new DecimalFormat(FORMAT_TYPE);

	/** the length of segment header **/
	public static final int SEGMENT_HEADER_LENGTH = 26;

	public static final int FIRST_INDEX = 0;

	/** default max segment different range **/
	public static final int DEFAULT_MAX_SEGMENT_DIFFS = 1000;

	/** String empty **/
	public static final String STRING_EMPTY = "";

	public static final String NOT_FOUND = "Nothing found to display.";

	public static final String CONTENT_TYPE = "text/xml";

	public static final String CHAR_SET = "UTF-8";

	/**
	 * LOGGER
	 */
	public static final String POSTLOGGER = "#%s , Post URL : %s Post Context : %s";

	/**
	 * Exception Message.
	 */
	public static final String ExceptionLogger = "#%s , Post URL : %s , Exception Message: %s";
	/**
	 * ERROR Message
	 */
	public static final String ERRORLOGGER = "#%s , Post URL : %s , Response Staus : %d, Response Error Message: {}";

	public static final String SUCCESSLOGGER = "#%s , Post URL : %s , Response Staus : %d .";

	private static Long SM_ID = null;

	public static Long getSM_ID() {
		return SM_ID;
	}

	public static void setSM_ID(Long sM_ID) {
		SM_ID = sM_ID;
	}

}
