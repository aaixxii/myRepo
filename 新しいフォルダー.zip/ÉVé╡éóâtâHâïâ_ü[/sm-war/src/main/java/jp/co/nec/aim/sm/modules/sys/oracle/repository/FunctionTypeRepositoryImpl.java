package jp.co.nec.aim.sm.modules.sys.oracle.repository;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.common.utils.SMUtil;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.FunctionTypeEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.FunctionTypeTrafficPojo;

import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

public class FunctionTypeRepositoryImpl {
	/** the log instance **/
	private static Logger logger = LoggerFactory
			.getLogger(FunctionTypeRepositoryImpl.class);

	@Autowired
	FunctionTypeRepository repository;

	/**
	 * get Detached Criteria
	 * 
	 * @param functionTypeEntity
	 * @return
	 */
	private DetachedCriteria getDetachedCriteria(
			FunctionTypeEntity functionTypeEntity) {
		// create the DetachedCriteria instance without session
		final DetachedCriteria dc = DetachedCriteria
				.forClass(FunctionTypeEntity.class);

		// add condition functionTypeId
		final Integer id = functionTypeEntity.getId();
		if (!SMUtil.isObjectNull(id)) {
			logger.debug("add condition functionTypeId = {}", id);
			dc.add(Restrictions.eq("id", id));
		}

		// add condition functionType
		final String functionName = functionTypeEntity.getFunctionName();
		if (StringUtils.isNotBlank(functionName)) {
			logger.debug("add condition functionName = {}", functionName);
			dc.add(Restrictions.eq("functionName", functionName));
		}

		return dc;
	}

	/**
	 * find Function Type Page
	 * 
	 * @param page
	 * @param functionType
	 * @return
	 */
	public Page<FunctionTypeEntity> findFunctionTypePage(
			Page<FunctionTypeEntity> page, FunctionTypeEntity functionType) {
		final DetachedCriteria dc = getDetachedCriteria(functionType);
		// add order by condition
		if (!StringUtils.isNotBlank(page.getOrderBy())) {
			logger.debug("add Order functionTypeId");
			dc.addOrder(Order.asc("id"));
		}
		logger.debug("find Page for FunctionTypeEntity");
		return repository.findPage(page, dc);
	}

	/**
	 * find Function Type Page
	 * 
	 * @param page
	 * @param functionType
	 * @return
	 */
	public Page<FunctionTypeTrafficPojo> findFunctionTypePage1(
			Page<FunctionTypeTrafficPojo> page,
			FunctionTypeTrafficPojo functionTypePojo) {
		
		String sql = "select ft.function_id as id, ft.function_name as functionType,"
				+ " ft.target_format_id as targetFormatId , it.job_limit_count as jobLimit ,"
				+ " ft.top_level_job_timeouts as topLevelJobTimeouts, "
				+ "ft.container_job_timeouts as containerJobTimeouts,"
				+ " ft.internal_candidate_size as internalCandidateSize from function_types ft , "
				+ "inquiry_traffic it where ft.family_id=it.family_id ";
		
		/*
		 * final DetachedCriteria dc = getDetachedCriteria(functionType); // add
		 * order by condition if (!StringUtils.isNotBlank(page.getOrderBy())) {
		 * logger.debug("add Order functionTypeId");
		 * dc.addOrder(Order.asc("id")); }
		 * logger.debug("find Page for FunctionTypeEntity"); return
		 * repository.findPage(page, dc);
		 */
		if (functionTypePojo.getId() != null) {
           sql+=" and ft.function_id ="+functionTypePojo.getId();
		}
		
		sql+=" order by function_id";
		
		List<FunctionTypeTrafficPojo> fts = repository.findBySql(sql,
				FunctionTypeTrafficPojo.class);
		Page<FunctionTypeTrafficPojo> pageFT = setPageList(fts, page);
		return pageFT;
	}

	/**
	 * find Function Type List
	 * 
	 * @param page
	 * @param functionType
	 * @return
	 */
	public List<FunctionTypeEntity> findFunctionType(
			FunctionTypeEntity functionType) {
		final DetachedCriteria dc = getDetachedCriteria(functionType);
		// add order by condition
		logger.debug("add Order functionTypeId");
		dc.addOrder(Order.asc("id"));

		logger.debug("find Page for FunctionTypeEntity");
		return repository.find(dc);
	}

	/**
	 * get all function type
	 * 
	 * @return
	 */
	public List<String> getAllFunctionType() {
		String sql1 = "select FUNCTION_NAME from FUNCTION_TYPES order by FUNCTION_ID";
		logger.debug("get All Function Type: {}", sql1);
		return repository.findBySql(sql1);
	}

	/**
	 * get format id by name
	 * 
	 * @param formatName
	 * @return
	 */
	public Integer getFunctionId(String formatName) {
		String sql1 = "select FUNCTION_ID from FUNCTION_TYPES where FUNCTION_NAME = '"
				+ formatName + "'";
		logger.debug("get Function Id where FUNCTION_NAME = {}", formatName);
		List<BigDecimal> ids = repository.findBySql(sql1);
		if (ids.size() != 1) {
			return null;
		}
		return ids.get(0).intValue();
	}

	/**
	 * update Function Type
	 * 
	 * @param functionType
	 * @return
	 */
	public int updateFunctionType(Integer functionId, Integer jobLimit,
			Long timeouts, Long muJobTimeouts, Long internalCandidateSize) {
		String setValue = "";
		int i = 0;
		if (jobLimit != null) {
			if (jobLimit <= -1) {
				jobLimit = null;
			}
			String sql1 = "update inquiry_traffic set job_limit_count ="
					+ jobLimit
					+ " where family_id =(select family_id from function_types ft where ft.function_id="
					+ functionId + ")";	
			i = repository.updateBySql(sql1);

		}
		if (timeouts != null) {

			setValue += "TOP_LEVEL_JOB_TIMEOUTS = " + timeouts;

		}
		if (muJobTimeouts != null) {
			if (StringUtils.isNotBlank(setValue)) {
				setValue += ", CONTAINER_JOB_TIMEOUTS = " + muJobTimeouts;
			} else {
				setValue += " CONTAINER_JOB_TIMEOUTS = " + muJobTimeouts;
			}
		}
		if (internalCandidateSize != null) {
			if (internalCandidateSize <= -1) {
				internalCandidateSize = null;
			}
			if (StringUtils.isNotBlank(setValue)) {
				setValue += ", INTERNAL_CANDIDATE_SIZE = "
						+ internalCandidateSize;
			} else {
				setValue += " INTERNAL_CANDIDATE_SIZE = "
						+ internalCandidateSize;
			}
		}
		String sql2 = "update FUNCTION_TYPES set " + setValue
				+ " where FUNCTION_ID = " + functionId;
		
		
		if (StringUtils.isNotBlank(setValue)) {
			return repository.updateBySql(sql2);
		}else {
			return i;
		}
		
	}

	public static void main(String[] args) {
		String sql1 = "update inquiry_traffic set job_limit_count ="
				+ 1
				+ "where family_id =(select family_id from function_types ft where ft.function_id="
				+ 2 + ")";
		System.out.print(sql1);
	}

	/**
	 * Set pagination
	 * 
	 * @param list
	 * @param page
	 * @return
	 */
	private <T> Page<T> setPageList(List<T> list, Page<T> page) {
		int size = list.size();
		// get count
		if (!page.isDisabled() && !page.isNotCount()) {
			page.setCount(size);
			if (page.getCount() < 1) {
				return page;
			}
		}

		List<T> tmp = new ArrayList<T>();
		if (!page.isDisabled()) {
			int firstResult = page.getFirstResult();
			int maxResult = page.getMaxResults();
			int lastResult = (firstResult + maxResult) > size ? size
					: (firstResult + maxResult);
			tmp = list.subList(firstResult, lastResult);
			page.setList(tmp);
		} else {
			page.setList(list);
		}

		return page;
	}

}
