package jp.co.nec.aim.sm.modules.sys.oracle.entities;

import java.io.Serializable;

/**
 * UnitSegReport
 * 
 * @author liuyq
 * 
 */
public interface UnitSegReport extends Serializable {

	long getUnitId();

	long getSegmentId();

	int getStatus();

	Long getQueuedVersion();

	Long getVersion();

	void setSegmentId(long segmentId);

	void setStatus(int status);

	void setUnitId(long unitId);

	void setVersion(Long version);

	void setQueuedVersion(Long queuedVersion);
}
