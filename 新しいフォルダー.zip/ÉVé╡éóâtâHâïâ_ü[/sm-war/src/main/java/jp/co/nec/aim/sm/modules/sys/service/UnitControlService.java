package jp.co.nec.aim.sm.modules.sys.service;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import jp.co.nec.aim.sm.common.constant.ProcessType;
import jp.co.nec.aim.sm.common.constant.UnitType;
import jp.co.nec.aim.sm.common.threadpool.ProcessMsg;
import jp.co.nec.aim.sm.exception.SMServiceException;
import jp.co.nec.aim.sm.modules.sys.BaseService;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.UnitPojo;
import jp.co.nec.aim.sm.modules.sys.oracle.repository.MatchUnitRepository;
import jp.co.nec.aim.sm.unitcontrol.dispatcher.MessageManager;
import jp.co.nec.aim.sm.unitcontrol.dispatcher.RemoteTasksDispatcher;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * the service of unit Control
 * 
 * @author liuyq
 * 
 */
@Service
public class UnitControlService extends BaseService {

	/**
	 * the log instance
	 */
	private static Logger logger = LoggerFactory
			.getLogger(UnitControlService.class);

	@Autowired
	private MatchUnitRepository matchUnitDao;

	private static Comparator<UnitPojo> unitComp = new Comparator<UnitPojo>() {
		@Override
		public int compare(UnitPojo unit1, UnitPojo unit2) {
			UnitType type1 = UnitType.valueOf(unit1.getType());
			UnitType type2 = UnitType.valueOf(unit2.getType());
			if (type1.ordinal() < type2.ordinal()) {
				return -1;
			}
			return 1;
		}
	};

	/**
	 * the message manager instance
	 */
	private final MessageManager manager = MessageManager.newInstance();

	/**
	 * unitsExecute by mutip-Threads
	 * 
	 * @param filteredList
	 *            selected unit lists
	 * @param action
	 *            the process type
	 */
	public void unitsExecute(final List<UnitPojo> filteredList,
			final ProcessType action) {
		try {
			Collections.sort(filteredList, unitComp);

			final RemoteTasksDispatcher dispatcher = new RemoteTasksDispatcher(
					filteredList, action, manager);
			dispatcher.execute();
		} catch (Exception ex) {
			logger.error("exception occurred when "
					+ "invoke method unitsExecute.", ex);
			throw new SMServiceException(ex);
		}
	}

	/**
	 * get the message form message vector
	 * 
	 * @return the instance of ProcessMsg
	 */
	public ProcessMsg getMessage() {
		try {
			return manager.getpMsg();
		} catch (Exception ex) {
			logger.error("exception occurred when "
					+ "invoke method getMessage.", ex);
			throw new SMServiceException(ex);
		}
	}
}
