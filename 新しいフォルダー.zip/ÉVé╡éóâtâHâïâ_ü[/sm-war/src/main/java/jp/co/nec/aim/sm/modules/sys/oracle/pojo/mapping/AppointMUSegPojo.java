package jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping;

public class AppointMUSegPojo {

	private Long muId;

	private String segmentIds;

	private String action;

	public void setMuId(Long muId) {
		this.muId = muId;
	}

	public Long getMuId() {
		return muId;
	}

	public void setSegmentIds(String segmentIds) {
		this.segmentIds = segmentIds;
	}

	public String getSegmentIds() {
		return segmentIds;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getAction() {
		return action;
	}
}
