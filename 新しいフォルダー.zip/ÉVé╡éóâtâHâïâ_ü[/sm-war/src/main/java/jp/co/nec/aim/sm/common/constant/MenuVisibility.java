package jp.co.nec.aim.sm.common.constant;

public enum MenuVisibility {
	DISPLAY(1L, "Display", "1", 10), HIDE(2L, "Hide", "0", 10);

	private Long id;
	private String label;
	private String value;
	private Integer sort;
	

	private MenuVisibility(Long index, String label, String value, Integer sort) {
		this.id = index;
		this.label = label;
		this.value = value;
		this.sort = sort;
	}

	public Long getId() {
		return id;
	}

	public String getLabel() {
		return label;
	}

	public String getValue() {
		return value;
	}

	public Integer getSort() {
		return sort;
	}

}
