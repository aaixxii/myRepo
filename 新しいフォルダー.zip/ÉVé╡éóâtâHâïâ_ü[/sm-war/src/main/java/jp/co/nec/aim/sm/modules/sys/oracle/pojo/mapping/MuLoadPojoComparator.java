package jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping;

import java.util.Comparator;

public class MuLoadPojoComparator implements Comparator<MuLoadPojo> {

	@Override
	public int compare(MuLoadPojo o1, MuLoadPojo o2) {
		if (o1 == null || o2 == null) {
			String errMsg = "There are null object in parameters,can't to compare two object!";
			throw new RuntimeException(errMsg);
		}
		int first = o1.getMuId().compareTo(o2.getMuId());
		int second = o1.getPressure().compareTo(o2.getPressure());
		return first != 0 ? first : second;
	}
}
