package jp.co.nec.aim.sm.common.worker;

import java.util.concurrent.locks.Lock;

import jp.co.nec.aim.sm.common.async.agent.AsyncAgent;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * the abstract worker class <br>
 * 
 * 
 * @author liuyq
 * 
 */
public abstract class AbstractWorker implements Runnable {

	/**
	 * the log instance
	 */
	private static final Logger log = LoggerFactory
			.getLogger(AbstractWorker.class);

	/**
	 * the instance of AsyncAgent <br>
	 * include the object that will be returned <br>
	 * whether that the flag of thread is finish completely <br>
	 * it also include the input parameter that will transfer <br>
	 * to each worker, the agent between each threads and main <br>
	 * thread
	 */
	private final AsyncAgent agent;

	/**
	 * is log debug enabled
	 */
	private final static boolean DEBUG = log.isDebugEnabled();

	/**
	 * the default constuctor with parameter AsyncResult
	 * 
	 * @param agent
	 *            the instance of AsyncResult
	 */
	public AbstractWorker(final AsyncAgent agent) {
		// check the given parameter
		// if not match, throw the IllegalArgumentException
		checkParameter(agent.getParameters());

		this.agent = agent;
	}

	@Override
	public void run() {
		final Thread t = Thread.currentThread();
		if (DEBUG) {
			log.debug("thread: " + t.getName() + " start..");
		}

		// if the thread is already interrupted
		// skip do anything
		if (t.isInterrupted()) {
			log.warn("The thread is interrupted, thread name :{}", t.getName());
			return;
		}

		// set the current thread to
		// the AsyncAgent instance
		agent.setThread(t);

		// lock this thread due to after the task done
		// it will realease the condition doneEvent
		// and the get method will returned immediately
		final Lock locker = agent.getLock();
		locker.lock();

		try {
			if (DEBUG) {
				log.debug("thread: " + t.getName()
						+ " begin to do logic task..");
			}

			// set the status to running
			agent.setRunning(true);

			// do the real task logic
			final Object o = doTask(agent.getParameters());

			// set the result object that above method returned
			// if any exception occurred, the object is null
			agent.setResultObject(o);

		} catch (Exception ex) {
			log.error("exception occurred while thread:" + t.getName()
					+ " do task logic..", ex);
			agent.setException(ex);
		} finally {
			if (DEBUG) {
				log.debug("thread: " + t.getName() + " end to do logic task..");
			}

			// set the status to finished
			agent.setRunning(false);

			// callback the done flag to agent instance
			agent.setDone();

			// notify the condition instance doneEvent
			agent.getCondition().signal();

			// at last release the locker
			locker.unlock();
		}
	}

	/**
	 * check the parameter
	 * 
	 * @param paras
	 *            the specified parameter
	 */
	protected abstract void checkParameter(final Object[] paras)
			throws IllegalArgumentException;

	/**
	 * do the logic Task
	 * 
	 * @param result
	 * @throws Throwable
	 */
	protected abstract Object doTask(final Object[] paras) throws Exception;
}
