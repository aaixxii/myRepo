package jp.co.nec.aim.sm.modules.sys.oracle.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * The primary key class for the DM_SEG_REPORTS database table.
 * 
 */
@Embeddable
public class DmSegReportPK implements Serializable {
	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 3793876091642250587L;
	private long dmId;
	private long segmentId;

	@Column(name = "DM_ID")
	public long getDmId() {
		return dmId;
	}

	public void setDmId(long dmId) {
		this.dmId = dmId;
	}

	@Column(name = "SEGMENT_ID")
	public long getSegmentId() {
		return segmentId;
	}

	public void setSegmentId(long segmentId) {
		this.segmentId = segmentId;
	}

	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (obj == null || obj.getClass() != this.getClass())
			return false;
		MuSegReportPK other = (MuSegReportPK) obj;
		return other.getMuId() == getDmId()
				&& other.getSegmentId() == getSegmentId();
	}

	public int hashCode() {
		return (int) dmId + (int) segmentId;
	}
}