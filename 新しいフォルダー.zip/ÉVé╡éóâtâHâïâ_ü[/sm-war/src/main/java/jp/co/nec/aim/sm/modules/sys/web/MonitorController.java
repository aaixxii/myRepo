package jp.co.nec.aim.sm.modules.sys.web;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.nec.aim.sm.common.constant.Constants;
import jp.co.nec.aim.sm.modules.sys.service.EventLogService;
import jp.co.nec.aim.sm.modules.sys.service.MonitorService;
import jp.co.nec.aim.sm.modules.sys.web.base.BaseController;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value = "/chart")
public class MonitorController extends BaseController {

	private static Logger logger = LoggerFactory
			.getLogger(MonitorController.class);

	@Autowired
	MonitorService monitorService;

	@Autowired
	EventLogService eventLogService;
	private String warning = "Got a empty data from system manager!";

	@RequiresPermissions(Constants.PERMISSION_VIEWER)
	@RequestMapping(value = { "init", "" })
	public String listJobs(HttpServletRequest request,
			HttpServletResponse response, Model model) {		
		saveCurrentPageInfo(request, "/chart/init", model);		
		return "modules/sys/home";
	}

	@RequiresPermissions(Constants.PERMISSION_USER)
	@RequestMapping(value = "status", method = RequestMethod.GET)
	@ResponseBody
	public Map<String, Map<String, Integer>> getComponentStatusChartData(
			HttpServletResponse response, Model model) {
		response.setContentType("application/json; charset=UTF-8");
		Map<String, Map<String, Integer>> componentStatusMap = monitorService
				.getComponentStatusData();		
		if (componentStatusMap != null && componentStatusMap.size() > 0) {			
			return componentStatusMap;
		} else {
			logger.warn(warning, "getComponentStatusChartData");
			//addMessage(model, warning);			
			return createEmptyResponseMap("ComponentStatusChart");
		}
	}

	@RequiresPermissions(Constants.PERMISSION_USER)
	@RequestMapping(value = "database", method = RequestMethod.GET)
	@ResponseBody
	public Map<String, Map<String, Integer>> getDBMonitorChartData(
			@RequestParam(value = "scopeId", required = true) Integer scopeId,
			HttpServletResponse response, Model model) {
		response.setContentType("application/json; charset=UTF-8");
		Map<String, Map<String, Integer>> dBMonitorChartMap = monitorService
				.getDBMonitorData(scopeId);		
		if (dBMonitorChartMap != null && dBMonitorChartMap.size() > 0) {			
			return dBMonitorChartMap;
		} else {
			logger.warn(warning , "getDBMonitorChartData");
			//addMessage(model, warning);			
			return createEmptyResponseMap("DBMonitorChart");
		}
	}

	@RequiresPermissions(Constants.PERMISSION_USER)
	@RequestMapping(value = "transactions", method = RequestMethod.GET)
	@ResponseBody
	public Map<String, Map<String, Long>> getTransactionMonitorChartData(
			HttpServletResponse response, Model model) {
		response.setContentType("application/json; charset=UTF-8");
		Map<String, Map<String, Long>> transactionMonitorChartMap = monitorService
				.getTransactionMonitorData();		
		if (transactionMonitorChartMap != null && transactionMonitorChartMap.size() > 0) {			
			return transactionMonitorChartMap;
		} else {
			logger.warn(warning , "getTransactionMonitorChartData");
			//addMessage(model, warning);				
			return createEmptyLongResponseMap("LineChart");
		}
	}

	@RequiresPermissions(Constants.PERMISSION_USER)
	@RequestMapping(value = "muInquiryloads", method = RequestMethod.GET)
	@ResponseBody
	public Map<String, Long> getMuInquiryLoadChartData(HttpServletResponse response,
			Model model) {
		response.setContentType("application/json; charset=UTF-8");
		Map<String, Long> muLoadChartMap = monitorService.getMuInquiryLoadData();
		if (muLoadChartMap != null && muLoadChartMap.size() > 0) {			
			return muLoadChartMap;
		} else {
			logger.warn(warning , "getMuLoadChartData");
			//addMessage(model, warning);
			return creatEmptyMxLoadChartMap();	
		}
	}
	
	@RequiresPermissions(Constants.PERMISSION_USER)
	@RequestMapping(value = "muExtractloads", method = RequestMethod.GET)
	@ResponseBody
	public Map<String, Long> getMuExtractLoadChartData(HttpServletResponse response,
			Model model) {
		response.setContentType("application/json; charset=UTF-8");
		Map<String, Long> muLoadChartMap = monitorService.getMuExtractLoadData();
		if (muLoadChartMap != null && muLoadChartMap.size() > 0) {			
			return muLoadChartMap;
		} else {
			logger.warn(warning , "getMuLoadChartData");
			//addMessage(model, warning);
			return creatEmptyMxLoadChartMap();	
		}
	}	

	@RequiresPermissions(Constants.PERMISSION_USER)
	@RequestMapping(value = "slb", method = RequestMethod.GET)
	@ResponseBody
	public Map<String, Boolean> getSlbSetting(HttpServletResponse response) {
		response.setContentType("application/json; charset=UTF-8");
		return monitorService.getSlbStatus();
	}

	@RequiresPermissions(Constants.PERMISSION_USER)
	@RequestMapping(value = "event", method = RequestMethod.GET)
	@ResponseBody
	public Map<String, String> getAlarmInfo(
			HttpServletResponse response,
			@RequestParam(value = "alarmTimeBefore", required = true) Integer alarmTimeBefore) {
		response.setContentType("application/json; charset=UTF-8");
		return eventLogService.getAlarmInfo(alarmTimeBefore);
	}
	
	@RequiresPermissions(Constants.PERMISSION_USER)
	@RequestMapping(value = "time", method = RequestMethod.GET)
	@ResponseBody	
	private  Map<String,String> getCurrentDbTime(HttpServletResponse response) {
		response.setContentType("application/json; charset=UTF-8");
		return eventLogService.getCurrentTimeFromDB();
	}
	
	private Map<String, Map<String, Long>> createEmptyLongResponseMap(String type) {
		Map<String, Map<String, Long>> EmptyResponse = new HashMap<String, Map<String, Long>>();	
		Map<String, Long> tenprintFunction = new HashMap<String, Long>();
		Map<String, Long> latentFunction = new HashMap<String, Long>();
		Map<String, Long> extract = new HashMap<String, Long>();
		tenprintFunction.put("TLI", 0L);
		tenprintFunction.put("II", 0L);
		tenprintFunction.put("TI", 0L);
		tenprintFunction.put("TLIP", 0L);
		tenprintFunction.put("FI", 0L);
		
		latentFunction.put("LLIP", 0L);
		latentFunction.put("LI", 0L);
		latentFunction.put("LLI", 0L);
		latentFunction.put("LIP", 0L);			
		
		extract.put("EXTRACT", 0L);
		
		EmptyResponse.put("tenprintFunction", tenprintFunction);
		EmptyResponse.put("latentFunction", tenprintFunction);
		EmptyResponse.put("extract", tenprintFunction);	
		return EmptyResponse;
		
	}
	
	private Map<String, Map<String, Integer>> createEmptyResponseMap(String type) {
		Map<String, Map<String, Integer>> EmptyResponse = new HashMap<String, Map<String, Integer>>();		
		
		switch (type) {
		case "ComponentStatusChart":
			Map<String, Integer> emptyMap = new HashMap<String, Integer>();
			emptyMap.put("WORKING", 0);
			emptyMap.put("TIMED_OUT", 0);
			emptyMap.put("EXITED", 0);
			EmptyResponse.put("mm", emptyMap);
			EmptyResponse.put("mr", emptyMap);
			EmptyResponse.put("dm", emptyMap);
			EmptyResponse.put("mu", emptyMap);			
			break;

		case "DBMonitorChart":
			Map<String, Integer> latentMonitorMap = new HashMap<String, Integer>();
			Map<String, Integer> tenprintMonitor = new HashMap<String, Integer>();
			latentMonitorMap.put("PLDB", 0);
			latentMonitorMap.put("RDBLM", 0);
			latentMonitorMap.put("LDBM", 0);
			latentMonitorMap.put("SDBLM", 0);
			latentMonitorMap.put("SDBL", 0);
			latentMonitorMap.put("RDBLS", 0);
			latentMonitorMap.put("PDB", 0);
			latentMonitorMap.put("LDBX", 0);
			latentMonitorMap.put("XDBL", 0);
			latentMonitorMap.put("RDBL", 0);
			latentMonitorMap.put("LDBS", 0);
			latentMonitorMap.put("LDB", 0);
			latentMonitorMap.put("SDBLS", 0);
			
			tenprintMonitor.put("PLDB", 0);
			tenprintMonitor.put("LDBM", 0);
			tenprintMonitor.put("LDBX", 0);
			tenprintMonitor.put("SDBTM", 0);
			tenprintMonitor.put("IDB", 0);
			tenprintMonitor.put("RDBT", 0);
			tenprintMonitor.put("SDBT", 0);
			tenprintMonitor.put("RDBTM", 0);
			tenprintMonitor.put("LDBS", 0);
			tenprintMonitor.put("LDB", 0);
			tenprintMonitor.put("FDB", 0);
			
			EmptyResponse.put("latentMonitor", latentMonitorMap);
			EmptyResponse.put("tenprintMonitor", tenprintMonitor);			
			break;
		}
		return EmptyResponse;
	}
	
	private  Map<String, Long> creatEmptyMxLoadChartMap() {
		 Map<String, Long> emptyMap = new HashMap<>();
		 emptyMap.put("mu", 0L);
		 return emptyMap;
	}
}
