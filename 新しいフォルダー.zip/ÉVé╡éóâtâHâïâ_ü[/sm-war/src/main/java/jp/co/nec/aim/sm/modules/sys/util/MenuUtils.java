package jp.co.nec.aim.sm.modules.sys.util;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeSet;

import jp.co.nec.aim.sm.common.constant.Constants;
import jp.co.nec.aim.sm.common.constant.Permission;
import jp.co.nec.aim.sm.common.utils.SMUtil;
import jp.co.nec.aim.sm.modules.sys.postgres.entity.MenuEntity;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * MenuUtils create menu data
 */
public class MenuUtils {
	/** the log instance **/
	private static Logger logger = LoggerFactory.getLogger(MenuUtils.class);

	// ////////////////////The Menu Relation Detail////////////////////////////
	// This displayed the relationship of each menu, there are 4 types of menu.
	// Modify the relationship of menu that you want.
	// Split the each menu of level with specified flag like."->"
	// The menu of level3, split the children menu with comma.
	// The main relation is : (parent menu id) -> (children menu id)
	// /////////////////////////////////////////////////////////////////////////
	private static final String[] MENU_RELATION_TREE = { "1->9->111->1049",
			"1->10->100->1001,1002,1003,1050",
			// "1->11->101->1004,1005,1006,1007,1008,1009",
			// "1->11->101->1004,1005,1006,1007,1009",
			// "1->12->102->1010,1011,1012,1013,1014,1035,1036",
			"1->12->102->1010,1014",
			// "1->13->103->1021,1022,1023,1024,1025",
			// "1->13->104->1015,1016,1017,1018,1019,1020",
			"1->13->104->1015,1016",
			// "1->14->105->1032",
			"1->15->106->1026,1027,1028,1029,1030,1031", "1->16->107->1033",
			// "1->17->108->1037,1038,1039,1040",
			"1->18->109->1041",
	// "1->15->110->1042,1043,1044,1045,1046,1047,1048" //
	};

	// ////////////////////The Menu Column Detail////////////////////////////
	// |== Menu Id ==|== Menu Name ==|== Menu Href ==|== Menu Permission ==|
	// //////////////////////////////////////////////////////////////////////

	// The menu is catalog by 4 level
	// TOP_MENU_NAMES is fixed, do not modify this menu attribution
	private static final String[][] TOP_MENU_NAMES = { { "1", "Top Menu", "",
			Constants.PERMISSION_VIEWER } };
	// The other menu, you can modify them by yourself..
	private static final String[][] LEVEL1_MENU_NAMES = {
			{ "9", "Home", "", Constants.PERMISSION_VIEWER },
			{ "10", "Units", "", Constants.PERMISSION_VIEWER },
			{ "11", "Segments", "", Constants.PERMISSION_VIEWER },
			{ "12", "Jobs", "", Constants.PERMISSION_VIEWER },
			{ "18", "Event Logs", "", Constants.PERMISSION_VIEWER },
			{ "13", "Reports", "", Constants.PERMISSION_VIEWER },
			{ "14", "Defragment", "", Constants.PERMISSION_USER },
			{ "15", "System Configurations", "", Constants.PERMISSION_USER },
			{ "17", "SLB", "", Constants.PERMISSION_VIEWER },
			{ "16", "User Management", "", Constants.PERMISSION_ADMIN }, };
	private static final String[][] LEVEL2_MENU_NAMES = {
			{ "100", "Units", "", Constants.PERMISSION_VIEWER },
			{ "101", "Segments", "", Constants.PERMISSION_VIEWER },
			{ "102", "Jobs", "", Constants.PERMISSION_VIEWER },
			{ "109", "Events", "", Constants.PERMISSION_VIEWER },
			{ "103", "Event Reports", "", Constants.PERMISSION_VIEWER },
			{ "104", "Advance Reports", "", Constants.PERMISSION_VIEWER },
			{ "105", "Defragment", "", Constants.PERMISSION_USER },
			{ "106", "System Configurations", "", Constants.PERMISSION_USER },
			{ "108", "Load Balance", "", Constants.PERMISSION_VIEWER },
			{ "107", "User Management", "", Constants.PERMISSION_ADMIN },
			{ "110", "Operation Tool", "", Constants.PERMISSION_USER },
			{ "111", "Home", "", Constants.PERMISSION_USER } };
	private static final String[][] LEVEL3_MENU_NAMES = {
			// The Units related children menu list
			{ "1001", "Units Status", "/unitState/list",
					Constants.PERMISSION_VIEWER },
			{ "1002", "Units Control", "/unitState/controller",
					Constants.PERMISSION_USER },
			{ "1003", "MatchUnit [ParameterControl]", "/unitState/parameter/MU",
					Constants.PERMISSION_USER },
			// The Segments related children menu list
			{ "1004", "Segments with segment reports",
					"/segments/segmentswithreport/list",
					Constants.PERMISSION_VIEWER },
			{ "1005", "Segment Reports", "/segments/musegreport/list",
					Constants.PERMISSION_VIEWER },
			{ "1006", "Segments", "/segments/segment/list",
					Constants.PERMISSION_VIEWER },
			{ "1007", "Segment Sets", "/segments/segmentset/list",
					Constants.PERMISSION_VIEWER },
			{ "1008", "Segment Allocation", "/segments/segmentallocation/list",
					Constants.PERMISSION_VIEWER },
			{ "1009", "Person Biometrics", "/segments/personbiometrics/list",
					Constants.PERMISSION_VIEWER },
			// The Jobs related children menu list
			{ "1010", "Jobs", "/jobs/jobs/list", Constants.PERMISSION_VIEWER },
			{ "1011", "Fusion Jobs", "/jobs/fusionjob/list",
					Constants.PERMISSION_VIEWER },
			{ "1012", "Segment Set Jobs", "/jobs/segsetjob/list",
					Constants.PERMISSION_VIEWER },
			{ "1013", "Mu Jobs", "/jobs/mujob/list",
					Constants.PERMISSION_VIEWER },
			{ "1014", "Feature Extraction Jobs", "/jobs/fejob/list",
					Constants.PERMISSION_VIEWER },
			{ "1035", "Top Level Jobs Summary", "/jobs/topleveljob/list",
					Constants.PERMISSION_VIEWER },
			{ "1036", "Mu Jobs Summary", "/jobs/mujobsummary/list",
					Constants.PERMISSION_VIEWER },
			// The Advance Reports related children menu list
			{ "1015", "AMR Report", "/jobAMRReport/list",
					Constants.PERMISSION_VIEWER },
			{ "1016", "Job Elapsed Time Report", "/jobElapseReport/list",
					Constants.PERMISSION_VIEWER },
			{ "1017", "Match Unit Job Elapse Report",
					"/unitJobElapseReport/list", Constants.PERMISSION_VIEWER },
			{ "1018", "Match Unit Job AMR Report", "/unitJobAMRReport/list",
					Constants.PERMISSION_VIEWER },
			{ "1019", "Extract Card Quality Type Report",
					"/cardQualityReport/list", Constants.PERMISSION_VIEWER },
			{ "1020", "Match Unit MuJobs Report", "/muJobsReport/list",
					Constants.PERMISSION_VIEWER },
			// The Event Reports related children menu list
			{ "1021", "Total Event Count Report", "/eventCountReport/list",
					Constants.PERMISSION_VIEWER },
			{ "1022", "Unit Based Event Report", "/unitEventReport/list",
					Constants.PERMISSION_VIEWER },
			{ "1023", "Message Code Based Event Report",
					"/messageEventReport/list", Constants.PERMISSION_VIEWER },
			{ "1024", "Event Unit Matrix Report", "/eventMatrixReport/list",
					Constants.PERMISSION_VIEWER },
			{ "1025", "Event Detailed Report", "/eventDetailReport/list",
					Constants.PERMISSION_VIEWER },
			// The System Configuration related children menu list
			{ "1026", "Biometric Containers", "/systemConfig/containers/list",
					Constants.PERMISSION_USER },
			{ "1027", "Eligible Functions",
					"/systemConfig/eligibleFunctions/list",
					Constants.PERMISSION_USER },
			{ "1028", "Eligible Biometric Containers",
					"/systemConfig/eligibleContainers/list",
					Constants.PERMISSION_USER },
			{ "1029", "Functions", "/systemConfig/functions/list",
					Constants.PERMISSION_USER },
			{ "1030", "System Initialization", "/systemConfig/systemInit/list",
					Constants.PERMISSION_USER },
			{ "1031", "System Settings", "/systemConfig/systemSettings/list",
					Constants.PERMISSION_USER },
			// The DeFragment related children menu list
			{ "1032", "Defragment Management", "/defragment/initialize",
					Constants.PERMISSION_USER },
			// The User related children menu list
			{ "1033", "User Management", "/user/list",
					Constants.PERMISSION_ADMIN },
			// The Load balance children menu list
			{ "1037", "Segment Distribution Map by MU",
					"/loadBalance/muSegments/list", Constants.PERMISSION_VIEWER },
			{ "1038", "Segment Count Map", "/loadBalance/segmentsMus/list",
					Constants.PERMISSION_VIEWER },
			{ "1039", "SLB Status", "/loadBalance/status/list",
					Constants.PERMISSION_USER },
			{ "1040", "Appointed Mu Segments",
					"/loadBalance/appointedMuSeg/list",
					Constants.PERMISSION_USER },
			// Event log
			{ "1041", "Events", "/eventLogs/event/list",
					Constants.PERMISSION_VIEWER },
			// Operation Tool
			{ "1042", "Re-Segment", "/systemConfig/resegment/reset",
					Constants.PERMISSION_USER },
			{ "1043", "Scope Addition", "/systemConfig/scopeaddition/list",
					Constants.PERMISSION_USER },
			{ "1044", "Segments Deletion", "/systemConfig/delsegment/list",
					Constants.PERMISSION_USER },
			{ "1045", "Fragmentation Status",
					"/systemConfig/fragmentation/list",
					Constants.PERMISSION_USER },
			{ "1046", "Correspondence of Eligible Bins to Functions",
					"/systemConfig/correspondence/list",
					Constants.PERMISSION_USER },
			{ "1047", "Job Management", "/systemConfig/jobmanagement/list",
					Constants.PERMISSION_USER },
			{ "1048", "Feature Extraction Job Management",
					"/systemConfig/fejobmanagement/list",
					Constants.PERMISSION_USER },
			// Home
			{ "1049", "Home", "/chart/init", Constants.PERMISSION_USER } ,
					
			//
			{ "1050", "MapReducer [ParameterControl]", "/unitState/parameter/MR",
				Constants.PERMISSION_USER } 
	};

	/** The register of each menu **/
	private static final Map<Permission, Map<Long, MenuEntity>> PERMISSION_MAP = new LinkedHashMap<Permission, Map<Long, MenuEntity>>();
	private static final Map<Long, MenuEntity> ALL_MAP = new LinkedHashMap<Long, MenuEntity>();

	private static final String ISSHOW = "1";
	private static final String COMMA = ",";
	private static final String TOP_MENU_PARENT_ID = "0";
	private static final String RELATION_SPLIT = "->";
	private static final String ICON_FILE_NAME = "circle-arrow-right";

	static {
		initPermissionMap();
		createMenu(TOP_MENU_NAMES);
		createMenu(LEVEL1_MENU_NAMES);
		createMenu(LEVEL2_MENU_NAMES);
		createMenu(LEVEL3_MENU_NAMES);
		arrangeRelationship(getAllMaps());
	}

	/**
	 * get All Maps from PERMISSION_MAP
	 * 
	 * @return the Map<Long, MenuEntity> instance
	 */
	private static Map<Long, MenuEntity> getAllMaps() {
		for (final Map<Long, MenuEntity> map : PERMISSION_MAP.values()) {
			ALL_MAP.putAll(map);
		}
		return ALL_MAP;
	}

	/**
	 * Arrange the each menu relationship base on relation
	 * tree[MENU_RELATION_TREE]
	 */
	private static void arrangeRelationship(Map<Long, MenuEntity> menuMap) {
		// loop the each relation tree and parse it
		for (final String relation : MENU_RELATION_TREE) {
			final String[] idStrs = relation.split(RELATION_SPLIT);
			final Set<Long> trackTree = new TreeSet<Long>();

			// parse the each menu relationship
			for (int i = 0; i < idStrs.length; i++) {
				final String idStrCurrent = idStrs[i];
				if (isNotLastMenu(i) && !idStrs[i].equals("00")) {
					// not the last menu
					long currentId = Long.parseLong(idStrCurrent);
					final MenuEntity currentMenu = menuMap.get(currentId);

					// add them to current menu children menu list
					if (currentMenu != null) {
						appendChildList(currentMenu, idStrs[i + 1], menuMap);
					}
					appendParentIdAndList(i, idStrs, trackTree, menuMap);
				} else {
					// the last menu, i will split by the comma
					// add each menu's parent menu
					appendParentIdAndList(i, idStrs, trackTree, menuMap);
				}
			}
		}
	}

	/**
	 * check is not the top menu
	 * 
	 * @param i
	 *            the menu loop index
	 * @return is not the top menu
	 */
	private static boolean isNotTopMenu(int i) {
		return (i > 0);
	}

	/**
	 * check is not the last menu
	 * 
	 * @param i
	 *            the menu loop index
	 * @return is not the last menu
	 */
	private static boolean isNotLastMenu(int i) {
		return (i != 3);
	}

	/**
	 * append the child menu instance to the current menu
	 * 
	 * @param currentMenu
	 *            the current menu instance
	 * @param idStrChild
	 *            the ids of the children menu
	 */
	private static void appendChildList(final MenuEntity currentMenu,
			final String idStrChild, Map<Long, MenuEntity> menuMap) {
		final String[] idStrChildArray = idStrChild.split(COMMA);
		for (final String idStr : idStrChildArray) {
			try {
				final MenuEntity childrenMenu = menuMap.get(Long
						.parseLong(idStr));
				if (SMUtil.isObjectNull(childrenMenu)) {
					logger.warn("the childrenMenu is null, the id string is:"
							+ idStr);
					continue;
				}
				currentMenu.appendChildList(childrenMenu);
			} catch (Exception ex) {
				logger.error("Current Menu append child menu error", ex);
				continue;
			}
		}
	}

	/**
	 * append the parent menu ids and instance to the current menu
	 * 
	 * @param index
	 *            the menu loop index
	 * @param idStrs
	 *            the relationship of the menu tree
	 * @param trackTree
	 *            the parent ids track tree of the menu
	 */
	private static void appendParentIdAndList(final int index,
			final String[] idStrs, final Set<Long> trackTree,
			Map<Long, MenuEntity> menuMap) {
		String idStrParent = TOP_MENU_PARENT_ID;
		final String idStrCurrent = idStrs[index];
		if (isNotTopMenu(index)) {
			idStrParent = idStrs[index - 1];
		}

		final String[] idStrCurrentArray = idStrCurrent.split(COMMA);
		for (final String idStr : idStrCurrentArray) {
			try {
				final MenuEntity currentMenu = menuMap.get(Long
						.parseLong(idStr));

				// null object checker
				if (SMUtil.isObjectNull(currentMenu)) {
					logger.warn("the current Menu is null "
							+ "while append ParentId And List");
					continue;
				}

				currentMenu.setParent(menuMap.get(Long.parseLong(idStrParent)));
				trackTree.add(Long.parseLong(idStrParent));
				currentMenu.appendParentIds(trackTree);
			} catch (Exception ex) {
				logger.error("Current Menu append parent menu error", ex);
				continue;
			}
		}
	}

	/**
	 * loop each level menu and catalog by the permission
	 * 
	 * @param menuArrays
	 *            the arrays of the emnu
	 * @return List<MenuEntity> instance
	 */
	private static void createMenu(final String[][] menuArrays) {
		// loop each level menu and catalog by the permission
		for (String[] menuArray : menuArrays) {
			try {
				// get the permission and catalog by the permission
				final String permission = menuArray[3];
				final Permission p = getPermission(permission);

				// add the the menu information to map menuRet
				final Map<Long, MenuEntity> menuRet = PERMISSION_MAP.get(p);
				final long id = Long.parseLong(menuArray[0]);
				final String menuName = menuArray[1];
				final String href = menuArray[2];
				final int sort = Integer.parseInt(menuArray[0]);

				if (menuRet.containsKey(id)) {
					logger.warn("The menu has alreay contain the menu id: "
							+ id);
				} else {
					menuRet.put(id, new MenuEntity(id, menuName, href,
							ICON_FILE_NAME, sort, ISSHOW, permission));
				}
			} catch (Exception ex) {
				logger.error("parse the menu incorrect..", ex);
				continue;
			}
		}
	}

	/**
	 * PermissionMap initialization
	 */
	private static void initPermissionMap() {
		for (final Permission p : Permission.values()) {
			PERMISSION_MAP.put(p, new LinkedHashMap<Long, MenuEntity>());
		}
	}

	/**
	 * convert the permission string to enum
	 * 
	 * @param permission
	 * @return Permission enum instance
	 * @throws Exception
	 */
	private static Permission getPermission(final String permission) {
		return Permission.findByPermissionStr(permission);
	}

	/**
	 * get all the menu list
	 * 
	 * @return all the menu list instance
	 */
	public static List<MenuEntity> getMenuList() {
		return getMenuList(Constants.PERMISSION_ADMIN);
	}

	/**
	 * get the menu list base on the role permission
	 * 
	 * @return the menu list instance
	 */
	public static List<MenuEntity> getMenuList(String permission) {
		List<MenuEntity> menus = new ArrayList<MenuEntity>();
		try {
			final Permission p = getPermission(permission);
			for (final Permission i : PERMISSION_MAP.keySet()) {
				if (compare(p, i)) {
					menus.addAll(PERMISSION_MAP.get(i).values());
				}
			}
		} catch (Exception ex) {
			logger.error("exception occurred while getMenuList", ex);
		}
		return menus;
	}

	/**
	 * 
	 * @param first
	 * @param second
	 * @return
	 */
	private static boolean compare(final Permission first,
			final Permission second) {
		return (first.compareTo(second) >= 0);
	}

	/**
	 * find one menu instance using specified id
	 * 
	 * @param id
	 *            the menu id
	 * @return menu instance
	 */
	public static MenuEntity findOne(Long id) {
		return ALL_MAP.get(id);
	}

	/**
	 * find one menu instance using specified href
	 * 
	 * @param url
	 *            the menu href
	 * @return menu instance
	 */
	public static MenuEntity findOneByURL(String href) {
		MenuEntity m = null;
		for (MenuEntity menu : ALL_MAP.values()) {
			if (menu.getHref().equals(href)) {
				m = menu;
				break;
			}
		}
		return m;
	}

	/**
	 * the method is only for test
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		for (final Permission p : PERMISSION_MAP.keySet()) {
			final Map<Long, MenuEntity> map = PERMISSION_MAP.get(p);
			Set<Entry<Long, MenuEntity>> sets = map.entrySet();
			for (final Entry<Long, MenuEntity> entry : sets) {
				final MenuEntity menu = entry.getValue();
				logger.info("");
				logger.info("Permission:" + p.getName());
				logger.info("=================================================");
				logger.info("MenuEntity information display:");
				StringBuffer sb = new StringBuffer();
				sb.append("id=");
				sb.append(menu.getId());
				sb.append(", name=");
				sb.append(menu.getName());
				sb.append(", href=");
				sb.append(menu.getHref());
				sb.append(", sort=");
				sb.append(menu.getSort());
				sb.append(", isShow=");
				sb.append(menu.getIsShow());
				sb.append(", permission=");
				sb.append(menu.getPermission());
				logger.info("MenuEntity basic information display:"
						+ sb.toString());

				logger.info("============== parent instance===================");
				final MenuEntity parent = menu.getParent();
				if (parent != null) {
					logger.info("parent instance id:" + parent.getId());
					logger.info("parent instance name:" + parent.getName());
				} else {
					logger.info("parent instance is null");
				}

				logger.info("============== parent ids===================");
				logger.info("parent Ids:" + menu.getParentIds());

				logger.info("============== child instance===================");
				for (final MenuEntity child : menu.getChildList()) {
					logger.info("child instance id:" + child.getId());
					logger.info("child instance name:" + child.getName());
				}
			}
		}

		List<MenuEntity> roleMenu = MenuUtils.getMenuList("SMUser");
		for (final MenuEntity m : roleMenu) {
			logger.info("SMUser: id=" + m.getId());
		}

		roleMenu = MenuUtils.getMenuList("Viewer");
		for (final MenuEntity m : roleMenu) {
			logger.info("Viewer: id=" + m.getId());
		}

		roleMenu = MenuUtils.getMenuList("Operator");
		for (final MenuEntity m : roleMenu) {
			logger.info("Operator: id=" + m.getId());
		}

		roleMenu = MenuUtils.getMenuList("Administrator");
		for (final MenuEntity m : roleMenu) {
			logger.info("Administrator: id=" + m.getId());
		}

	}
}
