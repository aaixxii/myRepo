package jp.co.nec.aim.sm.modules.sys.web;

import java.util.Collections;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.nec.aim.sm.common.constant.Constants;
import jp.co.nec.aim.sm.common.constant.ProcessType;
import jp.co.nec.aim.sm.common.constant.UnitState;
import jp.co.nec.aim.sm.common.constant.UnitType;
import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.common.threadpool.ProcessMsg;
import jp.co.nec.aim.sm.common.utils.EnumUtil;
import jp.co.nec.aim.sm.common.utils.MuConfigUtils;
import jp.co.nec.aim.sm.common.utils.SMUtil;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.MatchManagerEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.MatchUnitEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.UnitPojo;
import jp.co.nec.aim.sm.modules.sys.service.UnitControlService;
import jp.co.nec.aim.sm.modules.sys.service.UnitParameterService;
import jp.co.nec.aim.sm.modules.sys.service.UnitService;
import jp.co.nec.aim.sm.modules.sys.web.base.BaseController;
import jp.co.nec.aim.sm.unitparameter.model.MatchUnitConfig;

import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/**
 * UnitController
 * 
 * @author jinxl
 * 
 */
@Controller
@RequestMapping(value = "/unitState")
public class UnitStateController extends BaseController {

	@Autowired
	private UnitService matchUnitService;

	@Autowired
	private UnitControlService unitControlService;

	@Autowired
	private UnitParameterService unitParameterService;

	private static final String title = "unitsStatus";

	@ModelAttribute("unit")
	public MatchUnitEntity get(@RequestParam(required = false) Long id) {
		if (id != null) {
			return matchUnitService.getUnit(id);
		} else {
			return new MatchUnitEntity();
		}
	}

	@RequiresPermissions(Constants.PERMISSION_VIEWER)
	@RequestMapping(value = { "list", "" })
	public String list(
			@RequestParam(value = "muId", required = false) Long muId,
			@RequestParam(value = "type", required = false) String type,
			MatchUnitEntity unit, HttpServletRequest request,
			HttpServletResponse response, Model model) {
		if (!SMUtil.isObjectNull(muId))
			unit.setMuId(muId);

		if (!SMUtil.isNullOrEmpty(type))
			unit.setType(UnitType.valueOf(type));

		// add unitTypes and unitStates to select options
		final List<String> unitTypes = EnumUtil.getUnitTypelist();
		model.addAttribute("typeList", unitTypes);

		final List<String> unitStates = EnumUtil.getUnitStatelist();
		model.addAttribute("stateList", unitStates);

		List<UnitPojo> list = matchUnitService.findAllUnitsList(unit, true);

		Page<UnitPojo> page = matchUnitService.setPageList(list,
				new Page<UnitPojo>(request, response));

		model.addAttribute("page", page);
		model.addAttribute("unit", unit);

		saveCurrentPageInfo(request, "/unitState/list", model);

		return "modules/units/unitlist";
	}

	@RequiresPermissions(Constants.PERMISSION_VIEWER)
	@RequestMapping(value = "form")
	public String form(MatchUnitEntity unit, Model model) {
		model.addAttribute("unit", unit);
		return "modules/units/unitlist";
	}

	@RequiresPermissions(Constants.PERMISSION_VIEWER)
	@RequestMapping(value = "export", method = RequestMethod.POST)
	public String exportFile(MatchUnitEntity unit, HttpServletRequest request,
			HttpServletResponse response, RedirectAttributes redirectAttributes) {
		// try {
		// String fileName = "unitsStatus_"
		// + DateUtils.getDate("yyyyMMddHHmmss") + ".xlsx";
		// List<UnitPojo> list = matchUnitService.findAllUnitsList(unit, true);
		//
		// new ExportExcel("units Status", UnitPojo.class).setDataList(list)
		// .write(response, fileName).dispose();
		// return null;
		// } catch (Exception e) {
		// addMessage(
		// redirectAttributes,
		// "export the data failure, the error message is:"
		// + e.getMessage());
		// }
		return "redirect:/unitState/list";
	}

	@RequiresPermissions(Constants.PERMISSION_VIEWER)
	@RequestMapping(value = "exportPdf", method = RequestMethod.POST)
	public String exportPdf(MatchUnitEntity unit, HttpServletRequest request,
			HttpServletResponse response, RedirectAttributes redirectAttributes) {
		// try {
		// String fileName = "unitsStatus_"
		// + DateUtils.getDate("yyyyMMddHHmmss") + ".pdf";
		// List<UnitPojo> list = matchUnitService.findAllUnitsList(unit, true);
		//
		// ExportData exportdata = ExportData.getInstance();
		// exportdata.gettableList(list);
		//
		// String picpath = request.getSession().getServletContext()
		// .getRealPath("/");
		// HeaderInfo headerinfo = new HeaderInfo(title, null, null, picpath,
		// null, null);
		// ExportPdf pdf = new ExportPdf(exportdata, fileName, null,
		// headerinfo, response);
		// pdf.createPdf();
		// return null;
		// } catch (Exception e) {
		// addMessage(
		// redirectAttributes,
		// "export the data failure, the error message is:"
		// + e.getMessage());
		// }
		return "redirect:/unitState/list";
	}

	@RequiresPermissions(Constants.PERMISSION_USER)
	@RequestMapping(value = { "controller", "" })
	public String Controllerlist(MatchUnitEntity unit,
			HttpServletRequest request, HttpServletResponse response,
			Model model) {

		final List<String> unitActions = EnumUtil.getProcessTypelist();
		model.addAttribute("actionList", unitActions);
		final List<String> unitTypes = EnumUtil.getUnitCtrlTypelist();
		model.addAttribute("typeList", unitTypes);

		final List<String> unitStates = EnumUtil.getUnitStatelist();
		model.addAttribute("stateList", unitStates);

		List<UnitPojo> list = matchUnitService.findAllUnitsList(unit, false);

		Page<UnitPojo> page = matchUnitService.setPageList(list,
				new Page<UnitPojo>(request, response));

		model.addAttribute("page", page);
		model.addAttribute("unit", unit);

		saveCurrentPageInfo(request, "/unitState/controller", model);
		return "modules/units/unitcontroller";
	}

	@RequiresPermissions(Constants.PERMISSION_USER)
	@RequestMapping(value = { "controller/done", "" })
	public void doneController(@RequestParam(required = false) Long muId,
			@RequestParam(required = false) String state,
			@RequestParam(required = false) UnitType type,
			@RequestParam("action") String action,
			@RequestBody(required = false) List<UnitPojo> unitlist,
			HttpServletRequest request, HttpServletResponse response,
			Model model) {
		// when All selected ,reset unitlist
		if (SMUtil.isListNullOrEmpty(unitlist)) {
			MatchUnitEntity unit = new MatchUnitEntity();
			unit.setMuId(muId);
			unit.setState(UnitState.getUnitState(state));
			unit.setType(type);
			unitlist = matchUnitService.findAllUnitsList(unit, false);
		}

		// execute the specified command on each remote unit machine
		// use mutip-threads pool, (min core size -> 20)
		// max size -> 200
			unitControlService.unitsExecute(unitlist,
					ProcessType.valueOf(action));
	}

	@RequiresPermissions(Constants.PERMISSION_USER)
	@RequestMapping(value = { "controller/flush", "" })
	public @ResponseBody Page<UnitPojo> flushUnitList(MatchUnitEntity unit,
			HttpServletRequest request, HttpServletResponse response) {
		String unitId = request.getParameter("unitID");
		if (StringUtils.isNotBlank(unitId)) {
			unit.setMuId(Long.valueOf(unitId));
		}
		String unitType = request.getParameter("unitType");
		if (StringUtils.isNotBlank(unitType)) {
			unit.setType(UnitType.valueOf(unitType));
		}
		String unitState = request.getParameter("unitState");
		if (StringUtils.isNotBlank(unitState)) {
			unit.setState(UnitState.getUnitState(unitState));
		}
		List<UnitPojo> list = matchUnitService.findAllUnitsList(unit, false);
		Page<UnitPojo> page = matchUnitService.setPageList(list,
				new Page<UnitPojo>(request, response));
		page.setPageString(page.toString());
		return page;
	}

	@RequiresPermissions(Constants.PERMISSION_USER)
	@RequestMapping(value = { "parameter/{type}", "" })
	public String Parameterlist(@PathVariable("type") String type,
			HttpServletRequest request, HttpServletResponse response,
			Model model) {
		boolean isMR = type.equals("MR") ? true : false;

		List<MuConfigUtils> matchUnitParameterMap;
		matchUnitParameterMap = unitParameterService
				.getMatchUnitParameterMap(isMR);
		unitParameterService.ExecuteMatchUnitConfigThread(isMR);

		List<String> mulist = unitParameterService.getActivedUnitIPList(isMR);
		Collections.sort(mulist);
		String sectionlist = unitParameterService.getMuConfigSectionList(isMR);

		model.addAttribute("showTuning", request.getParameter("showTuning"));
		model.addAttribute("showGroup", request.getParameter("showGroup"));
		model.addAttribute("matchUnitParameterMap", matchUnitParameterMap);
		model.addAttribute("mulist", mulist);
		model.addAttribute("sectionlist", sectionlist);

		saveCurrentPageInfo(request, "/unitState/parameter/" + type, model);
		return "modules/units/unitparam";
	}

	@RequiresPermissions(Constants.PERMISSION_USER)
	@RequestMapping(value = { "parameter/{type}/confirm", "" })
	public @ResponseBody List<String> confirmParameterlist(
			@PathVariable("type") String type,
			@RequestBody(required = false) List<MatchUnitConfig> matchUnitConfigList,
			HttpServletRequest request, HttpServletResponse response,
			Model model) {
		boolean isMR = type.equals("MR") ? true : false;		
		return unitParameterService.updateThreadPool(matchUnitConfigList, isMR);
		
	}

	@RequiresPermissions(Constants.PERMISSION_VIEWER)
	@RequestMapping(value = "controller/getMessage")
	public @ResponseBody ProcessMsg getMessage() {
		return unitControlService.getMessage();
	}

	@RequiresPermissions(Constants.PERMISSION_VIEWER)
	@RequestMapping(value = { "unitdetail/{muId}/{type}", "" })
	public String getUnitDetail(@PathVariable("muId") Long muId,
			@PathVariable("type") String type, HttpServletRequest request,
			HttpServletResponse response, Model model) {

		Object obj = matchUnitService.findUnitDetail(muId, type);
		model.addAttribute("muId", muId);
		model.addAttribute("pidUnit", obj);

		saveCurrentPageInfo(request, "/unitState/unitdetail", model);

		if (obj.getClass().equals(MatchManagerEntity.class)) {
			return "modules/units/mmunitdetail";
		} else {
			return "modules/units/notmmunitdetail";
		}
	}
}
