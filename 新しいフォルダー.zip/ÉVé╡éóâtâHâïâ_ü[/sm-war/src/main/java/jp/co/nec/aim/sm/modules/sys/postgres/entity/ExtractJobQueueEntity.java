package jp.co.nec.aim.sm.modules.sys.postgres.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/*import jp.co.nec.aim.baton.ExtractJobFailedReasonMessage;*/

/**
 * @author nbhupendra
 */

@Entity
@Table(name = "\"EXTRACT_JOB_QUEUE\"", schema = "public")
// @Table(name="EXTRACT_JOB_QUEUE")
public class ExtractJobQueueEntity {

	@SequenceGenerator(name="seq_stat", sequenceName="extract_job_queue_id")
	@Id	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="seq_stat")
	@Column(name = "\"EXTRACT_JOB_QUEUE_ID\"")
	private Long extractJobQueueId;

	@Column(name = "\"EXTRACT_JOB_ID\"")
	private Long extractJobId;

	@Column(name = "\"FUNCTION_TYPE_ID\"")
	private Long functionTypeId;

	@Column(name = "\"PRIORITY\"")
	private Integer priority;

	@Column(name = "\"STATUS\"")
	private Integer status;

	@Column(name = "\"FAILED\"")
	private Integer failed;

	@Column(name = "\"RESULT_XML\"")
	private String resultsXML;

	@Column(name = "\"SUBMISSION_TIME\"")
	private Timestamp submissionTime;

	@Column(name = "\"RESULT_TIME\"")
	private Timestamp resultTime;

	@Column(name = "\"PROCESSING_TIME\"")
	private Timestamp processStartTime;

	@Column(name = "\"FAILURE_COUNT\"")
	private Integer failureCount;

	@Column(name = "\"POSITION\"")
	private Integer position;

	@Column(name = "\"PAUSED\"")
	private Integer paused;

	@Column(name = "\"MU_ID\"")
	private Long muId;

	@Column(name = "\"CALLBACK_URL\"")
	private String callbackURL;

	@Column(name = "\"NIST_FILE_PATH\"")
	private String nistFilePath;
	
	@Column(name = "\"REASION_ID\"")
	private String reasionId;

	/* private List<ExtractJobQueueReasonEntity> extractReasons; */
	// private Set<ExtractJobQueueReasonEntity> extractReasons = new HashSet();

	/*
	 * @OneToMany(mappedBy="job", fetch=FetchType.EAGER) public
	 * List<ExtractJobQueueReasonEntity> getExtractReasons() { return
	 * extractReasons; }
	 * 
	 * public void setExtractReasons(List<ExtractJobQueueReasonEntity>
	 * extractReasons) { this.extractReasons = extractReasons; }
	 */

	/**
	 * @return the submissionTime
	 */
	public Timestamp getSubmissionTime() {
		return submissionTime;
	}

	/**
	 * @param submissionTime
	 *            the submissionTime to set
	 */
	public void setSubmissionTime(Timestamp submissionTime) {
		this.submissionTime = submissionTime;
	}

	/**
	 * @return the resultTime
	 */
	public Timestamp getResultTime() {
		return resultTime;
	}

	/**
	 * @param resultTime
	 *            the resultTime to set
	 */
	public void setResultTime(Timestamp resultTime) {
		this.resultTime = resultTime;
	}

	/**
	 * @return the processStartTime
	 */
	public Timestamp getProcessStartTime() {
		return processStartTime;
	}

	/**
	 * @param processStartTime
	 *            the processStartTime to set
	 */
	public void setProcessStartTime(Timestamp processStartTime) {
		this.processStartTime = processStartTime;
	}

	/**
	 * @return the extractJobQueueId
	 */
	public Long getExtractJobQueueId() {
		return extractJobQueueId;
	}

	/**
	 * @param extractJobQueueId
	 *            the extractJobQueueId to set
	 */
	public void setExtractJobQueueId(Long extractJobQueueId) {
		this.extractJobQueueId = extractJobQueueId;
	}

	/**
	 * @return the extractJobId
	 */
	public Long getExtractJobId() {
		return extractJobId;
	}

	/**
	 * @param extractJobId
	 *            the extractJobId to set
	 */
	public void setExtractJobId(Long extractJobId) {
		this.extractJobId = extractJobId;
	}

	/**
	 * @return the functionTypeId
	 */
	public Long getFunctionTypeId() {
		return functionTypeId;
	}

	/**
	 * @param functionTypeId
	 *            the functionTypeId to set
	 */
	public void setFunctionTypeId(Long functionTypeId) {
		this.functionTypeId = functionTypeId;
	}

	/**
	 * @return the priority
	 */
	public Integer getPriority() {
		return priority;
	}

	/**
	 * @param priority
	 *            the priority to set
	 */
	public void setPriority(Integer priority) {
		this.priority = priority;
	}

	/**
	 * @return the status
	 */
	public Integer getStatus() {
		return status;
	}

	/**
	 * @param status
	 *            the status to set
	 */
	public void setStatus(Integer status) {
		this.status = status;
	}

	/**
	 * @return the failed
	 */
	public Integer getFailed() {
		return failed;
	}

	/**
	 * @param failed
	 *            the failed to set
	 */
	public void setFailed(Integer failed) {
		this.failed = failed;
	}

	/**
	 * @return the resultsXML
	 */
	public String getResultsXML() {
		return resultsXML;
	}

	/**
	 * @param resultsXML
	 *            the resultsXML to set
	 */
	public void setResultsXML(String resultsXML) {
		this.resultsXML = resultsXML;
	}

	/**
	 * @return the failureCount
	 */
	public Integer getFailureCount() {
		return failureCount;
	}

	/**
	 * @param failureCount
	 *            the failureCount to set
	 */
	public void setFailureCount(Integer failureCount) {
		this.failureCount = failureCount;
	}

	/**
	 * @return the position
	 */
	public Integer getPosition() {
		return position;
	}

	/**
	 * @param position
	 *            the position to set
	 */
	public void setPosition(Integer position) {
		this.position = position;
	}

	/**
	 * @return the paused
	 */
	public Integer getPaused() {
		return paused;
	}

	/**
	 * @param paused
	 *            the paused to set
	 */
	public void setPaused(Integer paused) {
		this.paused = paused;
	}

	/**
	 * @return the muId
	 */
	public Long getMuId() {
		return muId;
	}

	/**
	 * @param muId
	 *            the muId to set
	 */
	public void setMuId(Long muId) {
		this.muId = muId;
	}

	/**
	 * @return the callbackURL
	 */
	public String getCallbackURL() {
		return callbackURL;
	}

	/**
	 * @param callbackURL
	 *            the callbackURL to set
	 */
	public void setCallbackURL(String callbackURL) {
		this.callbackURL = callbackURL;
	}

	/**
	 * @return the nistFilePath
	 */
	public String getNistFilePath() {
		return nistFilePath;
	}

	/**
	 * @param nistFilePath
	 *            the nistFilePath to set
	 */
	public void setNistFilePath(String nistFilePath) {
		this.nistFilePath = nistFilePath;
	}

	public void setReasionId(String reasionId) {
		this.reasionId = reasionId;
	}

	public String getReasionId() {
		return reasionId;
	}

	/**
	 * @return the reasonId
	 */
	/*
	 * @OneToMany(mappedBy="job", fetch=FetchType.EAGER) //@OneToMany(cascade =
	 * CascadeType.ALL) //@JoinTable(name = "FE_QUEUE_REASON", joinColumns = {
	 * @JoinColumn(name = "EXTRACT_JOB_ID") }, inverseJoinColumns = {
	 * @JoinColumn(name = "EXTRACT_JOB_ID") }) public
	 * Set<ExtractJobQueueReasonEntity> getReasons() {
	 * 
	 * return extractReasons; }
	 *//**
	 * @param reasonId
	 *            the reasonId to set
	 */
	/*
	 * public void setReasons(Set<ExtractJobQueueReasonEntity> extractReasons) {
	 * this.extractReasons = extractReasons; }
	 */

}
