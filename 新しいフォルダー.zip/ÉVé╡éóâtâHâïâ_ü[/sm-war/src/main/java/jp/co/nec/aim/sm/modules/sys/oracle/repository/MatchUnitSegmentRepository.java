package jp.co.nec.aim.sm.modules.sys.oracle.repository;

import java.util.List;

import jp.co.nec.aim.sm.common.persistence.BaseRepository;
import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.MuSegmentEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.MUSegmentsSLBPojo;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.SegmentsMUsSLBPojo;

public interface MatchUnitSegmentRepository extends
		BaseRepository<MuSegmentEntity, Long> {
	public Page<MuSegmentEntity> findSegmentAllocation(
			Page<MuSegmentEntity> page, MuSegmentEntity muSeg);

	public List<MuSegmentEntity> ListSegmentAllocation(MuSegmentEntity muSeg);

	public boolean saveSegmentAllocation(MuSegmentEntity muSeg);

	public boolean deleteSegmentAllocation(MuSegmentEntity muSeg);

	/** get MU-Segments list for LoadBalancer **/
	public List<MUSegmentsSLBPojo> listMUSegmentsSLB(String muIds,
			String formatNames);

	/** get Segments-MUs list for LoadBalancer **/
	public List<SegmentsMUsSLBPojo> listSegmentsMUsSLBPojo(String formatNames);
}
