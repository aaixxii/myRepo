package jp.co.nec.aim.sm.modules.sys.service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import jp.co.nec.aim.sm.common.constant.UnitState;
import jp.co.nec.aim.sm.common.constant.UnitType;
import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.exception.SMServiceException;
import jp.co.nec.aim.sm.modules.sys.BaseService;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.MatchUnitEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.UnitPojo;
import jp.co.nec.aim.sm.modules.sys.oracle.repository.MatchUnitRepository;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * MatchUnit Service
 * 
 */
@Service
@Transactional(value = "oracleTXManager")
public class UnitService extends BaseService {

	/** the log instance **/
	private static Logger logger = LoggerFactory.getLogger(UnitService.class);

	@Autowired
	private MatchUnitRepository matchUnitDao;

	private static Comparator<UnitPojo> comp = new Comparator<UnitPojo>() {
		@Override
		public int compare(UnitPojo unit1, UnitPojo unit2) {
			UnitType type1 = UnitType.valueOf(unit1.getType());
			UnitType type2 = UnitType.valueOf(unit2.getType());
			if (type1.ordinal() < type2.ordinal()) {
				return 1;
			}
			if (type1.ordinal() == type2.ordinal()
					&& unit1.getId() > unit2.getId()) {
				return 1;
			}
			return -1;
		}
	};

	private static Comparator<List<UnitPojo>> complist = new Comparator<List<UnitPojo>>() {
		@Override
		public int compare(List<UnitPojo> unit1, List<UnitPojo> unit2) {
			UnitType type1 = UnitType.valueOf(unit1.get(0).getType());
			UnitType type2 = UnitType.valueOf(unit2.get(0).getType());
			if (type1.ordinal() < type2.ordinal()) {
				return 1;
			}
			if (type1.ordinal() == type2.ordinal()
					&& unit1.get(0).getId() > unit2.get(0).getId()) {
				return 1;
			}
			return -1;
		}
	};

	/**
	 * find a unit with id
	 * 
	 * @param id
	 *            the unit id
	 * @return MatchUnitEntity instance
	 */
	public MatchUnitEntity getUnit(Long id) {
		try {
			return matchUnitDao.findOne(id);
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			throw new SMServiceException(ex);
		}
	}

	/**
	 * find the result base on the conditions
	 * 
	 * @param page
	 *            the page instance
	 * @param unit
	 *            the unit condition
	 * @return the result that was been filtered
	 */
	public Page<UnitPojo> find(Page<UnitPojo> page, MatchUnitEntity unit) {
		try {
			List<UnitPojo> units = findAllUnitsList(unit, false);
			return setPageList(units, page);
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			throw new SMServiceException(ex);
		}
	}

	public Page<UnitPojo> findAllUnits(Page<UnitPojo> page,
			MatchUnitEntity unit, boolean hasSM) {
		// try {
		// return matchUnitDao.findAllUnitsList(unit, hasSM);
		// } catch (Exception ex) {
		// logger.error(ex.getMessage());
		// throw new SMServiceException(ex);
		// }
		return null;
	}

	public List<UnitPojo> findAllUnitsList(MatchUnitEntity unit, boolean hasSM) {
		try {
			// List<UnitPojo> dmList = findModifyPIDUnit(unit);
			List<UnitPojo> unitList = matchUnitDao.findPIDUnitPojolist(unit,
					hasSM);
			// mergeList(unit, dmList, unitList);
			return unitList;
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			throw new SMServiceException(ex);
		}
	}

	public Object findUnitDetail(Long muId, String type) {
		if (type.equals(UnitType.MM.name())) {
			return matchUnitDao.getMMbyMuId(muId);
		} else {
			return matchUnitDao.getUnitbyMuId(muId, type);
		}
	}

	// public List<UnitPojo> convertList(List<UnitPojo> unitList) {
	// Map<String, List<UnitPojo>> map = new LinkedHashMap<String,
	// List<UnitPojo>>();
	// for (UnitPojo unit : unitList) {
	// UnitType type = UnitType.valueOf(unit.getType());
	// if (type == UnitType.MM || type == UnitType.DM
	// || type == UnitType.MU || type == UnitType.MR) {
	// String url = unit.getContactURL();
	// String ipPort = ToolUtil.getIpPort(url);
	// List<UnitPojo> list = map.get(ipPort);
	// if (list != null) {
	// list.add(unit);
	// } else {
	// list = new ArrayList<UnitPojo>();
	// list.add(unit);
	// map.put(ipPort, list);
	// }
	// }
	// }
	//
	// List<List<UnitPojo>> newList = new ArrayList<List<UnitPojo>>();
	// for (String ip : map.keySet()) {
	// List<UnitPojo> list = map.get(ip);
	// if (list.size() > 1) {
	// Collections.sort(list, comp);
	// }
	// newList.add(list);
	// }
	// Collections.sort(newList, complist);
	//
	// List<UnitPojo> pageList = new ArrayList<UnitPojo>();
	// for (List<UnitPojo> subList : newList) {
	// UnitPojo unit = subList.get(0);
	// if (subList.size() > 1) {
	// String component = unit.getType();
	// String contactUrl = unit.getContactURL();
	// for (int i = 1; i < subList.size(); i++) {
	// component += "_" + subList.get(i).getType();
	// contactUrl += "<br>" + subList.get(i).getContactURL();
	// }
	// unit.setType(component);
	// unit.setContactURL(contactUrl);
	// }
	// pageList.add(unit);
	// }
	//
	// return pageList;
	// }

	/**
	 * Set pagination
	 * 
	 * @param list
	 * @param page
	 * @return
	 */
	public Page<UnitPojo> setPageList(List<UnitPojo> list, Page<UnitPojo> page) {
		int size = list.size();
		// get count
		if (!page.isDisabled() && !page.isNotCount()) {
			page.setCount(size);
			if (page.getCount() < 1) {
				return page;
			}
		}

		List<UnitPojo> tmp = new ArrayList<UnitPojo>();
		if (!page.isDisabled()) {
			int firstResult = page.getFirstResult();
			int maxResult = page.getMaxResults();
			int lastResult = (firstResult + maxResult) > size ? size
					: (firstResult + maxResult);
			tmp = list.subList(firstResult, lastResult);
		}

		page.setList(tmp);
		return page;
	}

	private void mergeList(MatchUnitEntity unitEntity, List<UnitPojo> dmList,
			List<UnitPojo> unitList) {
		String status = unitEntity.getState().name();
		for (UnitPojo dm : dmList) {
			String dmStatus = dm.getState();
			boolean isFound = false;
			for (UnitPojo unit : unitList) {
				if (unit.getId() == dm.getId()) {
					if (StringUtils.isBlank(status) || dmStatus.equals(status)) {
						unit.setState(dmStatus);
					} else {
						unitList.remove(unit);
					}
					isFound = true;
					break;
				}
			}
			if (!isFound
					&& (StringUtils.isBlank(status) || dmStatus.equals(status))) {
				unitList.add(dm);
			}
		}
	}

	/**
	 * findModifyPIDUnit
	 * 
	 * @param unitEntity
	 * @return the list of UnitPojo
	 */
	private List<UnitPojo> findModifyPIDUnit(MatchUnitEntity unitEntity) {
		List<UnitPojo> mmList = null;
		List<UnitPojo> dmList = null;
		// UnitType type = unitEntity.getType();
		List<UnitPojo> pidModifyList = new ArrayList<UnitPojo>();
		// if (type == null || type == UnitType.DM) {
		// MatchUnitEntity entity = new MatchUnitEntity();
		// entity.setType(UnitType.MM);
		// mmList = matchUnitDao.findPIDUnitPojolist(entity, false);
		//
		// entity.setManagedUnitId(unitEntity.getManagedUnitId());
		// entity.setType(UnitType.DM);
		// dmList = matchUnitDao.findPIDUnitPojolist(entity, false);
		// for (UnitPojo dm : dmList) {
		// String ipPort = ToolUtil.getIpPort(dm.getContactURL());
		// for (UnitPojo mm : mmList) {
		// String mmIpPort = ToolUtil.getIpPort(mm.getContactURL());
		// if (mmIpPort.equals(ipPort)) {
		// dm.setState(mm.getState());
		// pidModifyList.add(dm);
		// break;
		// }
		// }
		// }
		// }
		return pidModifyList;
	}

	public void changeUnitState(List<UnitPojo> unitList) {
		boolean hasWorkingMM = false;
		for (UnitPojo unit : unitList) {
			if (UnitType.MM.name().equals(unit.getType())
					&& UnitState.WORKING.name().equals(unit.getState())) {
				hasWorkingMM = true;
				break;
			}
		}

		if (!hasWorkingMM) {
			for (UnitPojo unit : unitList) {
				if (!UnitType.MM.name().equals(unit.getType())) {
					unit.setState("Indeterminate");
				}
			}
		}
	}
}
