package jp.co.nec.aim.sm.modules.sys.oracle.repository;

import java.util.List;

import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.common.utils.SMUtil;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.MuEligibleFunctionEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.CorrespondencePojo;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.EligibleFunctionsPojo;

import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

public class EligibleFunctionRepositoryImpl {
	/** the log instance **/
	private static Logger logger = LoggerFactory
			.getLogger(EligibleFunctionRepositoryImpl.class);

	@Autowired
	private EligibleFunctionRepository repository;

	/**
	 * get Detached Criteria
	 * 
	 * @param eligibleFunction
	 * @return
	 */
	private DetachedCriteria getDetachedCriteria(
			MuEligibleFunctionEntity eligibleFunction) {
		// create the DetachedCriteria instance without session
		final DetachedCriteria dc = DetachedCriteria
				.forClass(MuEligibleFunctionEntity.class);

		// add condition matchUnitId
		final Long matchUnitId = eligibleFunction.getMuId();
		if (!SMUtil.isObjectNull(matchUnitId)) {
			logger.debug("add condition muId = {}", matchUnitId);
			dc.add(Restrictions.eq("id.muId", matchUnitId));
		}

		// add condition functionTypeId
		final Integer functionTypeId = eligibleFunction.getFunctionId();
		if (!SMUtil.isObjectNull(functionTypeId)) {
			logger.debug("add condition functionId = {}", functionTypeId);
			dc.add(Restrictions.eq("id.functionId", functionTypeId));
		}

		return dc;
	}

	/**
	 * find eligible function page
	 * 
	 * @param page
	 * @param eligibleFunction
	 * @return
	 */
	public Page<MuEligibleFunctionEntity> findEligibleFunctionPage(
			Page<MuEligibleFunctionEntity> page,
			MuEligibleFunctionEntity eligibleFunction) {
		final DetachedCriteria dc = getDetachedCriteria(eligibleFunction);
		// add order by condition
		if (!StringUtils.isNotBlank(page.getOrderBy())) {
			logger.debug("add Order id.muId");
			dc.addOrder(Order.asc("id.muId"));
		}
		logger.debug("find Page for MuEligibleFunctionEntity");
		return repository.findPage(page, dc);
	}

	private String getAssignedFunctionSql(EligibleFunctionsPojo eligibleFunction) {

		String sql = " SELECT tmp.mu_id AS matchUnitId,"
				+ "MAX(tmp.function_name) AS functions  FROM"
				+ "(SELECT a.mu_ID,"
				+ "  ltrim(MAX(sys_connect_by_path(a.function_name, ',')), ',') AS function_name FROM"
				+ "(SELECT row_number() over(partition BY mef.mu_id order by mef.function_id) AS rn,"
				+ " mef.mu_id," + " ft.function_id,"
				+ " ft.function_name FROM MU_ELIGIBLE_FUNCTIONS mef,"
				+ "  function_types ft"
				+ " WHERE  mef.function_id     = ft.function_id";

		Long matchUnitId = eligibleFunction.getMatchUnitId();
		if (!SMUtil.isObjectNull(matchUnitId)) {
			sql += " AND MU_ID=" + matchUnitId;
		}
		sql += " ) a" + " START WITH rn       = 1"
				+ " CONNECT BY PRIOR rn = rn - 1"
				+ " AND a.mu_Id = PRIOR a.MU_ID ";
		String functions = eligibleFunction.getFunctions();
		if (StringUtils.isNotBlank(functions) && !functions.equals("All")) {
			sql += " AND MU_ID in(select MU_ID from MU_ELIGIBLE_FUNCTIONS mef,"
					+ " FUNCTION_TYPES ft WHERE ft.function_id=mef.function_id"
					// + " and FUNCTION_NAME='" + functions + "'"
					+ ")";
		}

		sql += " GROUP BY a.mu_id) tmp GROUP BY tmp.mu_id order by MU_ID";		
		return sql;
	}

	public static void main(String[] args) {
		String sql = " SELECT tmp.mu_id AS matchUnitId,"
				+ "MAX(tmp.function_name) AS functions  FROM"
				+ "(SELECT a.mu_ID,"
				+ "  ltrim(MAX(sys_connect_by_path(a.function_name, ',')), ',') AS function_name FROM"
				+ "(SELECT row_number() over(partition BY mef.mu_id order by mef.function_id) AS rn,"
				+ " mef.mu_id," + " ft.function_id,"
				+ " ft.function_name FROM MU_ELIGIBLE_FUNCTIONS mef,"
				+ "  function_types ft"
				+ " WHERE  mef.function_id     = ft.function_id" + " ) a"
				+ " START WITH rn       = 1" + " CONNECT BY PRIOR rn = rn - 1"
				+ " AND a.mu_Id = PRIOR a.MU_ID ";

		sql += " GROUP BY a.mu_id) tmp GROUP BY tmp.mu_id order by MU_ID";		
	}

	/**
	 * find Assigned Function page
	 * 
	 * @param eligibleFunction
	 * @return
	 */
	public Page<EligibleFunctionsPojo> findAssignedFunctionPage(
			Page<EligibleFunctionsPojo> page,
			EligibleFunctionsPojo eligibleFunction) {
		String sql = getAssignedFunctionSql(eligibleFunction);		
		return repository.findBySql(page, sql, EligibleFunctionsPojo.class);
	}

	/**
	 * find eligible function List
	 * 
	 * @param page
	 * @param eligibleFunction
	 * @return
	 */
	public List<MuEligibleFunctionEntity> findEligibleFunction(
			MuEligibleFunctionEntity eligibleFunction) {
		final DetachedCriteria dc = getDetachedCriteria(eligibleFunction);
		// add order by condition
		logger.debug("add Order id.muId");
		dc.addOrder(Order.asc("id.muId"));

		logger.debug("find Page for MuEligibleFunctionEntity");
		return repository.find(dc);
	}

	/**
	 * find Assigned Function List
	 * 
	 * @param eligibleFunction
	 * @return
	 */
	public List<EligibleFunctionsPojo> findAssignedFunction(
			EligibleFunctionsPojo eligibleFunction) {
		String sql = getAssignedFunctionSql(eligibleFunction);
		
		return repository.findBySql(sql, EligibleFunctionsPojo.class);
	}

	/**
	 * assign Match Unit Eligible Function
	 * 
	 * @param eligibleFunction
	 * @return
	 */
	public void assignFunction(MuEligibleFunctionEntity eligibleFunction) {
		Long matchUnitId = eligibleFunction.getId().getMuId();
		Integer typeId = eligibleFunction.getId().getFunctionId();
		logger.debug("assign Function: muId = {}, functionId = {}",
				matchUnitId, typeId);
		String sql = "insert into MU_ELIGIBLE_FUNCTIONS(MU_ID, FUNCTION_ID) select "
				+ matchUnitId
				+ ", FUNCTION_ID from FUNCTION_TYPES where FUNCTION_ID not in ("
				+ "select FUNCTION_ID from MU_ELIGIBLE_FUNCTIONS where MU_ID ="
				+ matchUnitId + ")";
		if (typeId != 0) {
			sql += " and FUNCTION_ID=" + typeId;
		}
		repository.updateBySql(sql);
		repository.flush();
	}

	/**
	 * unAssign Match Unit Eligible Function
	 * 
	 * @param eligibleFunction
	 */
	public void unAssignFunction(MuEligibleFunctionEntity eligibleFunction) {

		Long matchUnitId = eligibleFunction.getId().getMuId();
		Integer functionTypeId = eligibleFunction.getId().getFunctionId();
		logger.debug("unAssign Function: muId = {}, functionId = {}",
				matchUnitId, functionTypeId);
		String sql = "delete from MU_ELIGIBLE_FUNCTIONS where MU_ID="
				+ matchUnitId;
		if (functionTypeId != 0) {
			sql += " and FUNCTION_ID=" + functionTypeId;
		}
		repository.updateBySql(sql);
		repository.flush();
	}

	private String getCorrespondenceSql(CorrespondencePojo correspondence) {
		Long muId = correspondence.getMuId();
		String conditionF = "";
		String conditionB = "";
		if (!SMUtil.isObjectNull(muId)) {
			conditionF = "and mef.mu_id=" + muId;
			conditionB = "and mec.mu_id = " + muId;
		}

		String sql = "SELECT mu_id as muId,function_id as functionId,ef.function_name as eligibleFun, "
				+ " ef.containers as binsEliFun, "
				+ "eb.function_name as funOfEliBins,"
				+ "eb.containers2 as eligibleBins "
				+ "FROM "
				+ " (SELECT tmp.mu_id, "
				+ " tmp.function_id,"
				+ " tmp.function_name, "
				+ " MAX(tmp.containers) AS containers"
				+ "FROM"
				+ " (SELECT a.mu_ID,"
				+ "   a.function_id, "
				+ "     a.function_name, "
				+ "      ltrim(MAX(sys_connect_by_path(a.container_id, ',')), ',') AS containers "
				+ "   FROM"
				+ "   (SELECT row_number() over(partition BY mef.mu_id, ft.function_id order by cc.container_id) AS rn,"
				+ "      mef.mu_id,"
				+ "      ft.function_id,"
				+ "     ft.function_name,"
				+ "   cc.container_id"
				+ "  FROM MU_ELIGIBLE_FUNCTIONS mef, "
				+ "  function_types ft,"
				+ "  containers cc"
				+ "   WHERE  "
				+ " mef.function_id     = ft.function_id"
				+ " AND ft.target_format_id = cc.format_id"
				+ conditionF
				+ " ) a"
				+ "START WITH rn       = 1"
				+ "CONNECT BY PRIOR rn = rn - 1"
				+ "AND a.mu_Id           = PRIOR a.MU_ID"
				+ "AND a.function_id     = PRIOR a.function_id "
				+ "GROUP BY a.mu_id,"
				+ "a.function_id,"
				+ "  a.function_name"
				+ ")tmp"
				+ " GROUP BY tmp.mu_id,"
				+ "  tmp.function_id,"
				+ "  tmp.function_name "
				+ " )ef "
				+ "FULL JOIN "
				+ "(SELECT tmp.mu_id, "
				+ "tmp.function_id,"
				+ "  tmp.function_name,"
				+ " MAX(tmp.containers) AS containers2"
				+ "  FROM "
				+ " (SELECT a.mu_ID, "
				+ "  a.function_id,"
				+ "  a.function_name, "
				+ "  ltrim(MAX(sys_connect_by_path(a.container_id, ',')), ',') AS containers"
				+ " FROM"
				+ " (SELECT row_number() over(partition BY mec.mu_id, ft.function_id order by mec.container_id) AS rn, "
				+ "   mec.mu_id,"
				+ "  ft.function_id,"
				+ "  ft.function_name,"
				+ "  mec.container_id"
				+ " FROM MU_ELIGIBLE_containers mec,"
				+ "   function_types ft, "
				+ "  containers "
				+ " WHERE"
				+ " containers.format_id = ft.target_format_id "
				+ " AND mec.container_id     = containers.container_id"
				+ conditionB
				+ " ) a"
				+ " START WITH rn       = 1"
				+ " CONNECT BY PRIOR rn = rn - 1 "
				+ "AND a.mu_Id           = PRIOR a.MU_ID"
				+ "  AND a.function_id     = PRIOR a.function_id "
				+ " GROUP BY a.mu_id, "
				+ " a.function_id,"
				+ "  a.function_name"
				+ "  )tmp"
				+ " GROUP BY tmp.mu_id,"
				+ "tmp.function_id, "
				+ "tmp.function_name"
				+ ") eb "
				+ " USING(mu_id,function_id)"
				+ "ORDER BY mu_id,"
				+ "function_id,ef.function_name, containers,"
				+ "  eb.function_name," + " containers2";
		return sql;
	}

	/**
	 * Check correspondence of Eligible Bins to Functions
	 * 
	 * @param page
	 * @param muId
	 * @return
	 */
	public Page<CorrespondencePojo> findCorrespondencePage(
			Page<CorrespondencePojo> page, CorrespondencePojo correspondence) {
		String sql = getCorrespondenceSql(correspondence);
		return repository.findBySql(page, sql, CorrespondencePojo.class);
	}

	/**
	 * Check correspondence of Eligible Bins to Functions
	 * 
	 * @param page
	 * @param muId
	 * @return
	 */
	public List<CorrespondencePojo> findCorrespondenceList(
			CorrespondencePojo correspondence) {
		String sql = getCorrespondenceSql(correspondence);
		return repository.findBySql(sql, CorrespondencePojo.class);
	}
}
