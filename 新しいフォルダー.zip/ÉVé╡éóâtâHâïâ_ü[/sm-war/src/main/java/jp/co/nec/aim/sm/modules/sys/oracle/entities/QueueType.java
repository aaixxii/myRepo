package jp.co.nec.aim.sm.modules.sys.oracle.entities;

public enum QueueType {
	INQUIRY, EXTRACT
}
