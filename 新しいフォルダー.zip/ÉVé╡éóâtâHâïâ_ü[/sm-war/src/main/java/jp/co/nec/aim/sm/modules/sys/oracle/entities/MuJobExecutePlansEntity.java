package jp.co.nec.aim.sm.modules.sys.oracle.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "MU_JOB_EXECUTE_PLANS")
public class MuJobExecutePlansEntity implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 9049441372979215151L;

	@Id
	@Column(name = "PLAN_ID")
	private long planId;

	@Column(name = "JOB_ID")
	private long jobId;

	@Column(name = "FUNCTION_ID")
	private int functionId;

	@Column(name = "CONTAINER_ID")
	private int containerId;

	@Column(name = "PLAN")
	private String plan;

	@Column(name = "PLANED_COUNT")
	private int planed_count;

	@Column(name = "PLANED_TS")
	private long planedTs;

	public long getPlanId() {
		return planId;
	}

	public void setPlanId(long planId) {
		this.planId = planId;
	}

	public long getJobId() {
		return jobId;
	}

	public void setJobId(long jobId) {
		this.jobId = jobId;
	}

	public int getFunctionId() {
		return functionId;
	}

	public void setFunctionId(int functionId) {
		this.functionId = functionId;
	}

	public int getContainerId() {
		return containerId;
	}

	public void setContainerId(int containerId) {
		this.containerId = containerId;
	}

	public String getPlan() {
		return plan;
	}

	public void setPlan(String plan) {
		this.plan = plan;
	}

	public int getPlaned_count() {
		return planed_count;
	}

	public void setPlaned_count(int planed_count) {
		this.planed_count = planed_count;
	}

	public long getPlanedTs() {
		return planedTs;
	}

	public void setPlanedTs(long planedTs) {
		this.planedTs = planedTs;
	}

}
