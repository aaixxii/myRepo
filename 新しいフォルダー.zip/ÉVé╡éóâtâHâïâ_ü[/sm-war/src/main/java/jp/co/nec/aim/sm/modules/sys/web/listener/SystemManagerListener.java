package jp.co.nec.aim.sm.modules.sys.web.listener;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import jp.co.nec.aim.sm.common.threadpool.SMExecutor;
import jp.co.nec.aim.sm.common.threadpool.StandardThreadExecutor;
import jp.co.nec.aim.sm.common.utils.CmdUtils;
import jp.co.nec.aim.sm.modules.sys.web.register.CommunicationThread;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SystemManagerListener implements ServletContextListener {
	/** the log instance **/
	private static Logger logger = LoggerFactory
			.getLogger(SystemManagerListener.class);

	@Override
	public void contextInitialized(ServletContextEvent sce) {
		
	}

	@Override
	public void contextDestroyed(ServletContextEvent sce) {
		logger.info("SM Exit");
		CommunicationThread.doStop();

		// delete all PNG image in the directory
		String cmdPath = sce.getServletContext().getRealPath("/");
		CmdUtils.DeleteAll(cmdPath);

		SMExecutor executor = StandardThreadExecutor.getInstance();
		executor.stopInternal();
	}
}
