package jp.co.nec.aim.sm.modules.sys.oracle.entities;

import java.io.Serializable;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the MU_SEGMENTS database table.
 * 
 */
@Entity
@Table(name = "MU_SEGMENTS")
@NamedQuery(name = "MuSegmentEntity.findAll", query = "SELECT m FROM MuSegmentEntity m")
public class MuSegmentEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private MuSegmentEntityPK id;

	private int rank;

	public MuSegmentEntity() {
	}

	public MuSegmentEntityPK getId() {
		return this.id;
	}

	public void setId(MuSegmentEntityPK id) {
		this.id = id;
	}

	public int getRank() {
		return this.rank;
	}

	public void setRank(int rank) {
		this.rank = rank;
	}

}