package jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping;

import jp.co.nec.aim.sm.common.annocation.FieldMapped;
import jp.co.nec.aim.sm.common.annocation.InquiryMapping;

//import jp.co.nec.aim.sm.common.utils.excel.annocation.ExcelField;

@InquiryMapping
public class FunctionTypeTrafficPojo {
	@FieldMapped
	// @ExcelField(title = "Unit ID", type = 1, align = 2, sort = 1)
	private Integer id;

	@FieldMapped
	// @ExcelField(title = "Function", type = 1, align = 1, sort = 10)
	private String functionType;
	@FieldMapped
	private Integer targetFormatId;
	@FieldMapped
	private Integer jobLimit;
	@FieldMapped
	private Long topLevelJobTimeouts;
	@FieldMapped
	private Long containerJobTimeouts;
	@FieldMapped
	private Long internalCandidateSize;
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getFunctionType() {
		return functionType;
	}

	public void setFunctionType(String functionType) {
		this.functionType = functionType;
	}

	public Integer getTargetFormatId() {
		return targetFormatId;
	}

	public void setTargetFormatId(Integer targetFormatId) {
		this.targetFormatId = targetFormatId;
	}

	public Integer getJobLimit() {
		return jobLimit;
	}

	public void setJobLimit(Integer jobLimit) {
		this.jobLimit = jobLimit;
	}

	public Long getTopLevelJobTimeouts() {
		return topLevelJobTimeouts;
	}

	public void setTopLevelJobTimeouts(Long topLevelJobTimeouts) {
		this.topLevelJobTimeouts = topLevelJobTimeouts;
	}

	public Long getContainerJobTimeouts() {
		return containerJobTimeouts;
	}

	public void setContainerJobTimeouts(Long containerJobTimeouts) {
		this.containerJobTimeouts = containerJobTimeouts;
	}

	public Long getInternalCandidateSize() {
		return internalCandidateSize;
	}

	public void setInternalCandidateSize(Long internalCandidateSize) {
		this.internalCandidateSize = internalCandidateSize;
	}

}
