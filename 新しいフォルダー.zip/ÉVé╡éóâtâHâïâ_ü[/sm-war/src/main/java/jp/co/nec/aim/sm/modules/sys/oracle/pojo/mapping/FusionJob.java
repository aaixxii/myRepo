package jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping;

import java.io.Serializable;

import jp.co.nec.aim.sm.common.annocation.FieldMapped;
import jp.co.nec.aim.sm.common.annocation.InquiryMapping;

/**
 * The persistent class for the FUSION_JOBS database table.
 * 
 */
@InquiryMapping
public class FusionJob implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -587035786806121646L;
	@FieldMapped
	private Long fusionJobId;
	private Integer functionId;
	@FieldMapped
	private byte[] inquiryJobData;
	@FieldMapped
	private Long jobId;
	@FieldMapped
	private Integer searchRequestIndex;
	@FieldMapped
	private String functiontype;

	public FusionJob() {
	}

	public Long getFusionJobId() {
		return this.fusionJobId;
	}

	public void setFusionJobId(Long fusionJobId) {
		this.fusionJobId = fusionJobId;
	}

	public Integer getFunctionId() {
		return this.functionId;
	}

	public void setFunctionId(Integer functionId) {
		this.functionId = functionId;
	}

	public byte[] getInquiryJobData() {
		return this.inquiryJobData;
	}

	public void setInquiryJobData(byte[] inquiryJobData) {
		this.inquiryJobData = inquiryJobData;
	}

	public Long getJobId() {
		return this.jobId;
	}

	public void setJobId(Long jobId) {
		this.jobId = jobId;
	}

	public Integer getSearchRequestIndex() {
		return this.searchRequestIndex;
	}

	public void setSearchRequestIndex(Integer searchRequestIndex) {
		this.searchRequestIndex = searchRequestIndex;
	}

	public String getFunctiontype() {
		return functiontype;
	}

	public void setFunctiontype(String functiontype) {
		this.functiontype = functiontype;
	}

}