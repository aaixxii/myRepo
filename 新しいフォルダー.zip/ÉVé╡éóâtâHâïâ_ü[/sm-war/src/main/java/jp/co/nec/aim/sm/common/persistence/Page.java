package jp.co.nec.aim.sm.common.persistence;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.nec.aim.sm.common.constant.Constants;
import jp.co.nec.aim.sm.common.properties.SMProperties;
import jp.co.nec.aim.sm.common.utils.CookieUtils;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.domain.Sort.Order;

/**
 * Page Util
 */
public class Page<T> {
	/** the current page number **/
	private int pageNo = 1;

	/** the number of item per page **/
	private int pageSize = Integer.valueOf(SMProperties
			.getConfig("page.pageSize"));

	/** the total number of item **/
	private long count;

	private int first;
	private int last;
	private int prev;
	private int next;

	/** is the current the first page **/
	private boolean firstPage;
	/** is the current the last page **/
	private boolean lastPage;

	private int length = 8;
	private int slider = 1;

	/** the table list used to save all table item **/
	private List<T> list = new ArrayList<T>();

	/** order by **/
	private String orderBy = "";

	private String funcName = "page";

	private String pageString;

	private int firstResult;

	/**
	 * constructor with request and response <br>
	 * get pageNo, pageSize, orderBy from request parameter
	 * 
	 * @param request
	 *            the http request
	 * @param response
	 *            the http response
	 */
	public Page(HttpServletRequest request, HttpServletResponse response) {
		this(request, response, -2);
	}

	/**
	 * constructor with request, response and page size <br>
	 * get pageNo, pageSize, orderBy from request parameter
	 * 
	 * @param request
	 *            the http request
	 * @param response
	 *            the http response
	 * @param pageSize
	 *            the page size
	 */
	public Page(HttpServletRequest request, HttpServletResponse response,
			int pageSize) {
		String no = request.getParameter("pageNo");
		if (StringUtils.isNumeric(no)) {
			CookieUtils.setCookie(response, "pageNo", no);
			this.setPageNo(Integer.parseInt(no));
		} else if (request.getParameter("repage") != null) {
			no = CookieUtils.getCookie(request, "pageNo");
			if (StringUtils.isNumeric(no)) {
				this.setPageNo(Integer.parseInt(no));
			}
		}

		String size = request.getParameter("pageSize");
		if (StringUtils.isNumeric(size)) {
			CookieUtils.setCookie(response, "pageSize", size);
			this.setPageSize(Integer.parseInt(size));
		} else if (request.getParameter("repage") != null) {
			no = CookieUtils.getCookie(request, "pageSize");
			if (StringUtils.isNumeric(size)) {
				this.setPageSize(Integer.parseInt(size));
			}
		}
		if (pageSize != -2) {
			this.pageSize = pageSize;
		}

		String orderBy = request.getParameter("orderBy");
		if (StringUtils.isNotBlank(orderBy)) {
			this.setOrderBy(orderBy);
		}
	}

	/**
	 * constructor with pageNo and pageSize
	 * 
	 * @param pageNo
	 *            the number of page
	 * @param pageSize
	 *            the size of page
	 */
	public Page(int pageNo, int pageSize) {
		this(pageNo, pageSize, 0);
	}

	/**
	 * 
	 * @param pageNo
	 * @param pageSize
	 * @param count
	 */
	public Page(int pageNo, int pageSize, long count) {
		this(pageNo, pageSize, count, new ArrayList<T>());
	}

	/**
	 * 
	 * @param pageNo
	 * @param pageSize
	 * @param count
	 * @param list
	 */
	public Page(int pageNo, int pageSize, long count, List<T> list) {
		this.setCount(count);
		this.setPageNo(pageNo);
		this.pageSize = pageSize;
		this.setList(list);
	}

	/**
	 * initialize
	 */
	public void initialize() {
		this.first = 1;
		this.last = (int) (count
				/ (this.pageSize < 1 ? (count < 1 ? 1 : count) : this.pageSize)
				+ first - 1);

		if (this.count % this.pageSize != 0 || this.last == 0) {
			this.last++;
		}

		if (this.last < this.first) {
			this.last = this.first;
		}

		if (this.pageNo <= 1) {
			this.pageNo = this.first;
			this.firstPage = true;
		}

		if (this.pageNo >= this.last) {
			this.pageNo = this.last;
			this.lastPage = true;
		}

		if (this.pageNo < this.last - 1) {
			this.next = this.pageNo + 1;
		} else {
			this.next = this.last;
		}

		if (this.pageNo > 1) {
			this.prev = this.pageNo - 1;
		} else {
			this.prev = this.first;
		}
	}

	@Override
	public String toString() {
		initialize();
		StringBuilder sb = new StringBuilder();
		if (pageNo == first) {
			sb
					.append("<li class=\"disabled\"><a href=\"javascript:\">&#171; prev</a></li>\n");
		} else {
			sb.append("<li><a href=\"javascript:" + funcName + "(" + prev + ","
					+ pageSize + ");\">&#171; prev</a></li>\n");
		}

		int begin = pageNo - (length / 2);
		if (begin < first) {
			begin = first;
		}

		int end = begin + length - 1;
		if (end >= last) {
			end = last;
			begin = end - length + 1;
			if (begin < first) {
				begin = first;
			}
		}

		if (begin > first) {
			int i = 0;
			for (i = first; i < first + slider && i < begin; i++) {
				sb.append("<li><a href=\"javascript:" + funcName + "(" + i
						+ "," + pageSize + ");\">" + (i + 1 - first)
						+ "</a></li>\n");
			}
			if (i < begin) {
				sb
						.append("<li class=\"disabled\"><a href=\"javascript:\">...</a></li>\n");
			}
		}

		for (int i = begin; i <= end; i++) {
			if (i == pageNo) {
				sb.append("<li class=\"active\"><a href=\"javascript:\">"
						+ (i + 1 - first) + "</a></li>\n");
			} else {
				sb.append("<li><a href=\"javascript:" + funcName + "(" + i
						+ "," + pageSize + ");\">" + (i + 1 - first)
						+ "</a></li>\n");
			}
		}

		if (last - end > slider) {
			sb
					.append("<li class=\"disabled\"><a href=\"javascript:\">...</a></li>\n");
			end = last - slider;
		}

		for (int i = end + 1; i <= last; i++) {
			sb.append("<li><a href=\"javascript:" + funcName + "(" + i + ","
					+ pageSize + ");\">" + (i + 1 - first) + "</a></li>\n");
		}

		if (pageNo == last) {
			sb
					.append("<li class=\"disabled\"><a href=\"javascript:\">next &#187;</a></li>\n");
		} else {
			sb.append("<li><a href=\"javascript:" + funcName + "(" + next + ","
					+ pageSize + ");\">" + "next &#187;</a></li>\n");
		}

		sb
				.append("<li class=\"disabled controls\"><a href=\"javascript:\">current ");
		sb
				.append("<input type=\"text\" value=\""
						+ pageNo
						+ "\" onkeypress=\"var e=window.event||this;var c=e.keyCode||e.which;if(c==13)");
		sb.append(funcName + "(this.value," + pageSize
				+ ");\" onclick=\"this.select();\"/> / ");
		sb
				.append("<input type=\"text\" value=\""
						+ (pageSize < 0 ? 1
								: ((count + pageSize - 1) / pageSize))
						+ "\" onkeypress=\"var e=window.event||this;var c=e.keyCode||e.which;if(c==13)");
		sb.append(funcName + "(" + pageNo
				+ ",this.value);\" onclick=\"this.select();\"/>count");
		sb.append("&nbsp;&nbsp;&nbsp;Total Count:" + count + "</a><li>\n");
		sb.insert(0, "<ul>\n").append("</ul>\n");
		sb.append("<div style=\"clear:both;\"></div>");
		return sb.toString();
	}

	/**
	 * getCount
	 * 
	 * @return
	 */
	public long getCount() {
		return count;
	}

	public void setCount(long count) {
		if (this.count == 0 && count > 0 || count < this.count) {
			this.count = count;
			if (pageSize >= count) {
				pageNo = 1;
			}
		}
	}

	public int getPageNo() {
		return pageNo;
	}

	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		int defNum = Constants.DEFAULT_PAGE_RECORD_NUM;
		int maxNum = Constants.MAX_PAGE_RECORD_NUM;
		this.pageSize = pageSize <= 0 ? defNum : pageSize > maxNum ? maxNum
				: pageSize;
	}

	public int getFirst() {
		return first;
	}

	public int getLast() {
		return last;
	}

	public int getTotalPage() {
		return getLast();
	}

	public boolean isFirstPage() {
		return firstPage;
	}

	public boolean isLastPage() {
		return lastPage;
	}

	public int getPrev() {
		if (isFirstPage()) {
			return pageNo;
		} else {
			return pageNo - 1;
		}
	}

	public int getNext() {
		if (isLastPage()) {
			return pageNo;
		} else {
			return pageNo + 1;
		}
	}

	public List<T> getList() {
		return list;
	}

	public void setList(List<T> list) {
		this.list = list;
	}

	public String getOrderBy() {
		return orderBy;
	}

	public void setOrderBy(String orderBy) {
		this.orderBy = orderBy;
	}

	public String getFuncName() {
		return funcName;
	}

	public void setFuncName(String funcName) {
		this.funcName = funcName;
	}

	/**
	 * @param pageString the pageString to set
	 */
	public void setPageString(String pageString) {
		this.pageString = pageString;
	}

	/**
	 * @return the pageString
	 */
	public String getPageString() {
		return pageString;
	}

	public boolean isDisabled() {
		return this.pageSize == -1;
	}

	public boolean isNotCount() {
		return this.count == -1;
	}

	public int getFirstResult() {
		firstResult = (getPageNo() - 1) * getPageSize();
		while (firstResult > 0 && firstResult >= getCount()) {
			pageNo = pageNo - 1;
			firstResult = (getPageNo() - 1) * getPageSize();
		}
		return firstResult;
	}

	public int getMaxResults() {
		if (firstResult + pageSize > count) {
			return (int) (count - firstResult);
		}
		return getPageSize();
	}

	public Pageable getSpringPage() {
		List<Order> orders = new ArrayList<Order>();
		if (orderBy != null) {
			for (String order : StringUtils.split(orderBy, ",")) {
				String[] o = StringUtils.split(order, " ");
				if (o.length == 1) {
					orders.add(new Order(Direction.ASC, o[0]));
				} else if (o.length == 2) {
					if ("DESC".equals(o[1].toUpperCase())) {
						orders.add(new Order(Direction.DESC, o[0]));
					} else {
						orders.add(new Order(Direction.ASC, o[0]));
					}
				}
			}
		}
		return new PageRequest(this.pageNo - 1, this.pageSize, new Sort(orders));
	}

	public void setSpringPage(org.springframework.data.domain.Page<T> page) {
		this.pageNo = page.getNumber();
		this.setPageSize(page.getSize());
		this.count = page.getTotalElements();
		this.list = page.getContent();
	}
}
