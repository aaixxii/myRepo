package jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping;

import jp.co.nec.aim.sm.common.annocation.FieldMapped;
import jp.co.nec.aim.sm.common.annocation.InquiryMapping;

@InquiryMapping
public class MUSegmentsSLBPojo {

	@FieldMapped
	private Long muId;

	@FieldMapped
	private String status;

	@FieldMapped
	private Long binId;

	@FieldMapped
	private String binName;

	@FieldMapped
	private Integer segCount;

	@FieldMapped
	private Integer redundancy;

	private Integer segTotal;

	private String matchUnitIds;

	private String formats;

	public void setMuId(Long muId) {
		this.muId = muId;
	}

	public Long getMuId() {
		return muId;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStatus() {
		return status;
	}

	public void setSegCount(Integer segCount) {
		this.segCount = segCount;
	}

	public Integer getSegCount() {
		return segCount;
	}

	public void setSegTotal(Integer segTotal) {
		this.segTotal = segTotal;
	}

	public Integer getSegTotal() {
		return segTotal;
	}

	public void setRedundancy(Integer redundancy) {
		this.redundancy = redundancy;
	}

	public Integer getRedundancy() {
		return redundancy;
	}

	public void setFormats(String formats) {
		this.formats = formats;
	}

	public String getFormats() {
		return formats;
	}

	public void setMatchUnitIds(String matchUnitIds) {
		this.matchUnitIds = matchUnitIds;
	}

	public String getMatchUnitIds() {
		return matchUnitIds;
	}

	public void setBinName(String binName) {
		this.binName = binName;
	}

	public String getBinName() {
		return binName;
	}

	public void setBinId(Long binId) {
		this.binId = binId;
	}

	public Long getBinId() {
		return binId;
	}
}
