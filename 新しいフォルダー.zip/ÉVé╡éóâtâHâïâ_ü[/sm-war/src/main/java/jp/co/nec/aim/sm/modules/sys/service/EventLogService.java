package jp.co.nec.aim.sm.modules.sys.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.exception.SMServiceException;
import jp.co.nec.aim.sm.modules.sys.BaseService;
import jp.co.nec.aim.sm.modules.sys.postgres.entity.EventLogEntity;
import jp.co.nec.aim.sm.modules.sys.postgres.pojo.mapping.EventDetailPojo;
import jp.co.nec.aim.sm.modules.sys.postgres.pojo.mapping.EventLogPojo;
import jp.co.nec.aim.sm.modules.sys.postgres.pojo.mapping.MessageEventPojo;
import jp.co.nec.aim.sm.modules.sys.postgres.pojo.mapping.UnitEventPojo;
import jp.co.nec.aim.sm.modules.sys.postgres.repository.EventLogRepository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Lists;

@Service
@Transactional(value = "postgresTXManager")
public class EventLogService extends BaseService {
	/** the log instance **/
	private static Logger logger = LoggerFactory
			.getLogger(EventLogService.class);

	@Autowired
	private EventLogRepository eventLogDao;

	public EventLogService() {
	}

	/**
	 * get messageType, messageCount from the table EVENT_LOG
	 * 
	 * @param eventLog
	 * @return
	 */
	public List<EventLogPojo> getEvents(EventLogEntity eventLog) {
		try {
			return eventLogDao.getEvents(eventLog);
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			throw new SMServiceException(ex);
		}
	}

	/**
	 * get unitId, messageType, messageCount from the table EVENT_LOG
	 * 
	 * @param eventLog
	 * @return
	 */
	public List<UnitEventPojo> getUnitEvents(EventLogEntity eventLog) {
		try {
			return eventLogDao.getUnitEvents(eventLog);
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			throw new SMServiceException(ex);
		}
	}

	/**
	 * get unitId, messageType, messageCode, messageCount from EVENT_LOG
	 * 
	 * @param eventLog
	 * @return
	 */
	public List<MessageEventPojo> getMessageEvents(EventLogEntity eventLog) {
		try {
			return eventLogDao.getMessageEvents(eventLog);
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			throw new SMServiceException(ex);
		}
	}

	/**
	 * get unitId, messageType, messageCode, messageCount from EVENT_LOG
	 * 
	 * @param page
	 * @param eventLog
	 * @return
	 */
	public Page<MessageEventPojo> getMessageEvents(Page<MessageEventPojo> page,
			EventLogEntity eventLog) {
		try {
			return eventLogDao.getMessageEvents(page, eventLog);
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			throw new SMServiceException(ex);
		}
	}

	/**
	 * get unitId, messageType, messageCode, message from the table EVENT_LOG
	 * 
	 * @param eventLog
	 * @return
	 */
	public List<EventDetailPojo> getEventDetail(EventLogEntity eventLog) {
		try {
			return eventLogDao.getEventDetail(eventLog);
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			throw new SMServiceException(ex);
		}
	}

	/**
	 * get unitId, messageType, messageCode, message from the table EVENT_LOG
	 * 
	 * @param page
	 * @param eventLog
	 * @return
	 */
	public Page<EventDetailPojo> getEventDetail(Page<EventDetailPojo> page,
			EventLogEntity eventLog) {
		try {
			return eventLogDao.getEventDetail(page, eventLog);
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			throw new SMServiceException(ex);
		}
	}

	/**
	 * get eventId, unitId, messageType, messageCode, message from the table
	 * EVENT_LOG
	 * 
	 * @param eventLog
	 * @return
	 */
	public List<EventLogEntity> getEventLogs(EventLogEntity eventLog) {
		try {
			return eventLogDao.getEventLogs(eventLog);
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			throw new SMServiceException(ex);
		}
	}

	/**
	 * get eventId, unitId, messageType, messageCode, message from the table
	 * EVENT_LOG
	 * 
	 * @param eventLog
	 * @return
	 */
	public Page<EventLogEntity> getEventLogs(Page<EventLogEntity> page,
			EventLogEntity eventLog) {
		try {
			return eventLogDao.getEventLogs(page, eventLog);
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			throw new SMServiceException(ex);
		}
	}

	/**
	 * get Header List from UnitEventPojo
	 * 
	 * @param evnetsList
	 * @return
	 */
	public List<String> getHeaderList(List<UnitEventPojo> evnetsList) {
		List<String> headerList = new ArrayList<String>();
		headerList.add("Unit ID");
		logger.info("get Header List from UnitEventPojo");
		for (int i = 0; i < evnetsList.size(); i++) {
			if (!headerList.contains(evnetsList.get(i).getMessageType())) {
				headerList.add(evnetsList.get(i).getMessageType());
			}
		}
		return headerList;
	}

	/**
	 * get Table Array from UnitEventPojo
	 * 
	 * @param headerList
	 * @param evnetsList
	 * @return
	 */
	private List<String[]> getTableArray(List<String> headerList,
			List<UnitEventPojo> evnetsList) {
		int rowId = -1;
		String muId = "";
		List<String[]> tableArray = new ArrayList<String[]>();

		logger.info("get Table Array from UnitEventPojo");
		for (int i = 0; i < evnetsList.size(); i++) {
			String unitId = evnetsList.get(i).getUnitId().toString();
			// new row data
			if (!muId.equals(unitId)) {
				muId = unitId;
				rowId++;
				String[] array = new String[headerList.size()];
				for (int j = 1; j < array.length; j++) {
					array[j] = "";
				}
				tableArray.add(array);
				tableArray.get(rowId)[0] = muId;
			}
			// set cell value
			int index = headerList.indexOf(evnetsList.get(i).getMessageType());
			tableArray.get(rowId)[index] = evnetsList.get(i).getMessageCount()
					.toString();

		}
		return tableArray;
	}

	/**
	 * get Table List(List<List<String>>) from UnitEventPojo
	 * 
	 * @param headerList
	 * @param evnetsList
	 * @return
	 */
	public List<List<String>> getLists(List<String> headerList,
			List<UnitEventPojo> evnetsList) {
		// get Table Array from UnitEventPojo
		List<String[]> tableArray = getTableArray(headerList, evnetsList);

		// convert to Table List(List<List<String>>)
		List<List<String>> tableList = new ArrayList<List<String>>();
		for (int i = 0; i < tableArray.size(); i++) {
			tableList.add(Lists.newArrayList(tableArray.get(i)));
		}
		logger.info("get Table List(List<List<String>>) from UnitEventPojo");
		return tableList;
	}

	/**
	 * get Table List(List<String>) from UnitEventPojo
	 * 
	 * @param headerList
	 * @param evnetsList
	 * @return
	 */
	public List<String> getTableList(List<String> headerList,
			List<UnitEventPojo> evnetsList) {
		// get Table Array from UnitEventPojo
		List<String[]> tableArray = getTableArray(headerList, evnetsList);

		// convert to Table List(List<String>)
		List<String> tableList = new ArrayList<String>();
		for (int i = 0; i < tableArray.size(); i++) {
			tableList.addAll(Lists.newArrayList(tableArray.get(i)));
		}
		logger.info("get Table List(List<String>) from UnitEventPojo");
		return tableList;
	}
	
	public Map<String,String> getAlarmInfo(int value) {		
		String lastAlm = eventLogDao.getAlarmInfo(value);
		if (lastAlm != null) {
			Map<String,String> alarmMap = new HashMap<>();
			alarmMap.put("lastAlm", lastAlm);
			return alarmMap;
		} else {
			return null;
		}

	}
	
	public Map<String,String> getCurrentTimeFromDB() {
		String timeStamp =  eventLogDao.getDBTime();
		Map<String,String> slbMap = new HashMap<>();
		slbMap.put("time", timeStamp);		
		return slbMap;
	}
}
