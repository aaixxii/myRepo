package jp.co.nec.aim.sm.modules.sys.util;

import static jp.co.nec.aim.sm.common.constant.MonitorConstants.COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.DATA;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.DATASETS;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.EXIT_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.FILL_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.LABEL;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.LABELS;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.MU_LOAD_FILL_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.MU_LOAD_STROKE_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.STROKE_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.TIME_OUT_COLOR;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.VALUE;
import static jp.co.nec.aim.sm.common.constant.MonitorConstants.WORKING_COLOR;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.nec.aim.sm.common.constant.ChartColorEnum;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.ComponentStatus;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.ComponentStatusComparator;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.DBMonitorData;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.DBMonitorDataCompareator;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.MuLoadPojo;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.TransactionMonitorData;

public class MonitorHelper {	
	public MonitorHelper() {}

	public Map<String , Object[]> convertStatusListToMap(List<ComponentStatus> toBeConvertedList) {	
		Map<String , Object[]> statusMaps = new HashMap<String , Object[]>();
		Collections.sort(toBeConvertedList, new ComponentStatusComparator());
		String componetName  = toBeConvertedList.get(0).getComponentName();
		Object[] tmpArray = new Object[3];
		int arrayIndex = 0;
		for (int i = 0; i < toBeConvertedList.size(); i++) {
			if (toBeConvertedList.get(i).getComponentName().equals(componetName)) {
				tmpArray[arrayIndex] = 	processOneComponetStatusRecord(toBeConvertedList.get(i));
				arrayIndex++;
			} else {
				statusMaps.put(componetName, tmpArray);
				tmpArray = null;				
				arrayIndex = 0;
				tmpArray = new Object[3];	
				componetName  = toBeConvertedList.get(i).getComponentName();
				tmpArray[arrayIndex] = 	processOneComponetStatusRecord(toBeConvertedList.get(i));
			}		
		}
		if (tmpArray != null) {
			statusMaps.put(componetName, tmpArray);
		}		
		return statusMaps;
	}

	public Map<String , Map<String,Integer>> convertTransactionMonitorToMap(List<TransactionMonitorData> toBeConvertedList) {
		return null;	
		
	}
	
	public Map<String , Map<String,Object[]>> convertDBMonitorListToMap(List<DBMonitorData> toBeConvertedList) {		
		Map<String ,  Map<String,Object[]>> resultsMaps = new HashMap<String ,  Map<String,Object[]>>();
		Collections.sort(toBeConvertedList, new DBMonitorDataCompareator());
		String function  = toBeConvertedList.get(0).getFunction();
		List<DBMonitorData> tmpList = new ArrayList<>();
		for (int i = 0; i < toBeConvertedList.size(); i++) {
			if (toBeConvertedList.get(i).getFunction().equals(function)) {
				tmpList.add(toBeConvertedList.get(i));
			} else {
				Map<String,Object[]> subMap = processOnePrintType(function,tmpList);
				resultsMaps.put(function, subMap);
				function  = toBeConvertedList.get(i).getFunction();				
			}
		}		
		return resultsMaps;			
	}
	
	public Map<String,Object[]> convertMuLoadListToMap(List<MuLoadPojo> toBeConvertedList) {
		Map<String,Object[]> results = new HashMap<String,Object[]>();
		String[] labelsArray = new String[toBeConvertedList.size()];
		Long[] dataArray = new Long[toBeConvertedList.size()];
		for (int i = 0 ; i < toBeConvertedList.size(); i++) {
			labelsArray[i] = String.valueOf(toBeConvertedList.get(i).getMuId());
			dataArray[i] = toBeConvertedList.get(i).getPressure();
		}
		Map<String ,Object> detaSetMap = new HashMap<String ,Object>();
		detaSetMap.put(FILL_COLOR, ChartColorEnum.getChartColorValue(MU_LOAD_FILL_COLOR));
		detaSetMap.put(STROKE_COLOR, ChartColorEnum.getChartColorValue(MU_LOAD_STROKE_COLOR));
		detaSetMap.put(DATA,dataArray);
		
		results.put(LABELS, labelsArray);
		results.put(DATASETS, new Object[] {detaSetMap});		
		return results;			
	}
	
	private Map<String,Object[]> processOnePrintType(String function, List<DBMonitorData> tmpList) {
		Map<String,Object[]> results = new HashMap<String,Object[]>();		
		String[] dbNameList = new String[tmpList.size()];
		Integer[] dataValueList = new Integer[tmpList.size()];
		for (int i = 0 ; i < tmpList.size(); i++) {
			dbNameList[i] = tmpList.get(i).getTemplateFormat();
			dataValueList[i] = tmpList.get(i).getRecordCount();			
		}
		Map<String , Object> datasetsMap = new HashMap<String , Object>();
		datasetsMap.put(LABELS, function);
		datasetsMap.put(FILL_COLOR,ChartColorEnum.getChartColorValue(function).getStrokeColor());
		datasetsMap.put(STROKE_COLOR,ChartColorEnum.getChartColorValue(function).getPointColor());
		datasetsMap.put(DATA ,dataValueList);
		results.put(LABELS, dbNameList);
		results.put(DATASETS,new Object[]{datasetsMap});
		return results; 
		
	}	
	
	private Map<String,Object> processOneComponetStatusRecord(ComponentStatus oneRecord) {
		Map<String,Object> results = new HashMap<>();		
		results.put(LABEL, oneRecord.getState());
		results.put(VALUE, oneRecord.getCount());
		switch (oneRecord.getState().toLowerCase()){
		case "working":
			results.put(COLOR,WORKING_COLOR);
			break;
		case "timeout":
			results.put(COLOR,TIME_OUT_COLOR);
			break;	
		case "exited":
			results.put(COLOR,EXIT_COLOR);
			break;
		}
		return results;		
	}
	

}
