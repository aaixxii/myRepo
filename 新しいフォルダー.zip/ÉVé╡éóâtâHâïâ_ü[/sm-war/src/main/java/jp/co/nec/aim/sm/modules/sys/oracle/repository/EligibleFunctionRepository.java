package jp.co.nec.aim.sm.modules.sys.oracle.repository;

import java.util.List;

import jp.co.nec.aim.sm.common.persistence.BaseRepository;
import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.MuEligibleFunctionEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.MuEligibleFunctionEntityPK;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.CorrespondencePojo;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.EligibleFunctionsPojo;

public interface EligibleFunctionRepository extends
		BaseRepository<MuEligibleFunctionEntity, MuEligibleFunctionEntityPK> {
	/** find eligible function page **/
	public Page<MuEligibleFunctionEntity> findEligibleFunctionPage(
			Page<MuEligibleFunctionEntity> page,
			MuEligibleFunctionEntity eligibleFunction);

	/** find Assigned Function page **/
	public Page<EligibleFunctionsPojo> findAssignedFunctionPage(
			Page<EligibleFunctionsPojo> page,
			EligibleFunctionsPojo eligibleFunction);

	/** find eligible function List **/
	public List<MuEligibleFunctionEntity> findEligibleFunction(
			MuEligibleFunctionEntity eligibleFunction);

	/** find Assigned Function List **/
	public List<EligibleFunctionsPojo> findAssignedFunction(
			EligibleFunctionsPojo eligibleFunction);

	/** assign Match Unit Eligible Function **/
	public void assignFunction(MuEligibleFunctionEntity eligibleFunction);

	/** unAssign Match Unit Eligible Function **/
	public void unAssignFunction(MuEligibleFunctionEntity eligibleFunction);

	/** Check correspondence of Eligible Bins to Functions **/
	public Page<CorrespondencePojo> findCorrespondencePage(
			Page<CorrespondencePojo> page, CorrespondencePojo correspondence);

	/** Check correspondence of Eligible Bins to Functions **/
	public List<CorrespondencePojo> findCorrespondenceList(
			CorrespondencePojo correspondence);
}
