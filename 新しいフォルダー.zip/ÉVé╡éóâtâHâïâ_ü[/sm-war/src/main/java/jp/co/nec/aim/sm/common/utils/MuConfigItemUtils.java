package jp.co.nec.aim.sm.common.utils;

public class MuConfigItemUtils {
	private String muIpName;
	private String value;
	
	public String getMuIpName() {
		return muIpName;
	}
	public void setMuIpName(String muIpName) {
		this.muIpName = muIpName;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
}
