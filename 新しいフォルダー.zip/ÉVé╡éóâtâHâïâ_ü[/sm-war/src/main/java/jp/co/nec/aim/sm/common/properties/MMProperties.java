package jp.co.nec.aim.sm.common.properties;

import jp.co.nec.aim.sm.common.utils.PropertiesUtil;

public class MMProperties {

	private static PropertiesUtil mmLoader;

	private static String getConfig(String key) {
		if (mmLoader == null) {
			mmLoader = new PropertiesUtil("MM.properties");
		}
		return mmLoader.getProperty(key);
	}

	public static String getMMIp() {
		return getConfig("MM.IP_ADDRESS");
	}

	public static String getMMPort() {
		return getConfig("MM.WEB_PORT_NUM");
	}

	public static String getMMTrafficAddr() {
		return getConfig("MM.ADDS");
	}

	public static String getMMCare() {
		return getConfig("MM.CARE");
	}

	public static String getMMWebSerAddr() {
		return getConfig("MM.WEBSERVICE");
	}

	public static String getMMContext() {
		return getConfig("MM.CONTEXT");
	}

	public static String getMMEnter() {
		return getConfig("MM.ENTER");
	}

	public static String getMMExit() {
		return getConfig("MM.EXIT");
	}

	public static String getMMHeartbeat() {
		return getConfig("MM.HEARTBEAT");
	}

	public static String getMUConfig() {
		return getConfig("MU.CONFIG");
	}

	public static String getMRConfig() {
		return getConfig("MR.CONFIG");
	}
	
	public static String getMUUpdateConfig() {
		return getConfig("MU.UPDATE.CONFIG");
	}

	public static String getMRUpdateConfig() {
		return getConfig("MR.UPDATE.CONFIG");
	}
}
