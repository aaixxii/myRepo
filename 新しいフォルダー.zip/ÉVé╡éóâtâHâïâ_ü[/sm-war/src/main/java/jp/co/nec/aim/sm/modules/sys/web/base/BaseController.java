package jp.co.nec.aim.sm.modules.sys.web.base;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.validation.ConstraintViolationException;
import javax.validation.Validator;

import jp.co.nec.aim.sm.common.validator.BeanValidators;
import jp.co.nec.aim.sm.modules.sys.postgres.entity.MenuEntity;
import jp.co.nec.aim.sm.modules.sys.util.MenuUtils;
import jp.co.nec.aim.sm.modules.sys.util.PageInfoUtils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

public abstract class BaseController {

	@Autowired
	protected Validator validator;

	/**
	 * add the message to page
	 * 
	 * @param message
	 */
	protected void addMessage(RedirectAttributes redirectAttributes,
			String... messages) {
		StringBuilder sb = new StringBuilder();
		for (String message : messages) {
			message = message.replaceAll("\"", "'");
			message = message.replaceAll("\n", "");
			message = message.replaceAll("\r", "");
			sb.append(message).append(messages.length > 1 ? "<br/>" : "");
		}
		redirectAttributes.addFlashAttribute("message", sb.toString());
	}

	protected void addMessage(Model model, String... messages) {
		StringBuilder sb = new StringBuilder();
		for (String message : messages) {
			message = message.replaceAll("\"", "'");
			message = message.replaceAll("\n", "");
			message = message.replaceAll("\r", "");
			sb.append(message).append(messages.length > 1 ? "<br/>" : "");
		}
		model.addAttribute("message", sb.toString());
	}

	protected boolean beanValidator(Model model, Object object,
			Class<?>... groups) {
		try {
			BeanValidators.validateWithException(validator, object, groups);
		} catch (ConstraintViolationException ex) {
			List<String> list = BeanValidators.extractPropertyAndMessageAsList(
					ex, ": ");
			list.add(0, "Data validation error.");
			addMessage(model, list.toArray(new String[] {}));
			return false;
		}
		return true;
	}

	protected void saveCurrentPageInfo(HttpServletRequest request, String href,
			Model model) {
		String sessionId = request.getSession().getId();

		MenuEntity menu = MenuUtils.findOneByURL(href);
		if (menu != null) {
			try {
				Long leve1_Id = menu.getParent().getParent().getId();
				Long leve2_Id = menu.getParent().getId();
				Long leve3_Id = menu.getId();
				model.addAttribute("leve1_Id", leve1_Id);
				model.addAttribute("leve2_Id", leve2_Id);
				model.addAttribute("leve3_Id", leve3_Id);

				PageInfoUtils.savePageInfo(sessionId, leve1_Id, leve2_Id,
						leve3_Id);
			} catch (Exception ex) {
				Map<String, Long> map = PageInfoUtils.getModel(sessionId);
				if (map != null) {
					model.addAllAttributes(map);
				}
			}
		} else {
			Map<String, Long> map = PageInfoUtils.getModel(sessionId);
			if (map != null) {
				model.addAllAttributes(map);
			}
		}
	}
}
