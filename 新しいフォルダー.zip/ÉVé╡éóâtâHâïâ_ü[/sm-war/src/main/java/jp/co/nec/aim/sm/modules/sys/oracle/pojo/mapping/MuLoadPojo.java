package jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping;

import java.io.Serializable;

public class MuLoadPojo implements Serializable {
	private static final long serialVersionUID = 1427316632608774237L;
	private Long muId;
	private Long pressure;

	public MuLoadPojo() {
	}

	public Long getMuId() {
		return muId;
	}

	public void setMuId(Long muId) {
		this.muId = muId;
	}

	public Long getPressure() {
		return pressure;
	}

	public void setPressure(Long pressure) {
		this.pressure = pressure;
	}

}
