package jp.co.nec.aim.sm.modules.sys.postgres.repository;

import java.util.List;

import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.common.utils.SMUtil;
import jp.co.nec.aim.sm.modules.sys.postgres.entity.JobQueueEntity;
import jp.co.nec.aim.sm.modules.sys.postgres.pojo.mapping.JobAMRPojo;
import jp.co.nec.aim.sm.modules.sys.postgres.pojo.mapping.JobElapsePojo;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * JobRepository interface
 */
public class JobQueueRepositoryImpl {
	/** the log instance **/
	@Autowired
	private JobQueueRepository jobRepository;

	/**
	 * get time Condition string
	 * 
	 * @param JobQueueEntity
	 * @return
	 */
	private String getCondition(JobQueueEntity JobQueueEntity) {
		String condition = "";
		final String startTime = JobQueueEntity.getStartTime();
		if (StringUtils.isNotEmpty(startTime)) {
			condition += " AND a.\"SUBMISSION_TIME\" >= (timestamp '"
					+ startTime + "') ";
		}

		final String endTime = JobQueueEntity.getEndTime();
		if (StringUtils.isNotEmpty(endTime)) {
			condition += " AND a.\"SUBMISSION_TIME\" <= (timestamp '" + endTime
					+ ".999') ";
		}

		condition += getFuncCondition(JobQueueEntity);		
		return condition;
	}

	private String getFuncCondition(JobQueueEntity JobQueueEntity) {
		String condition = "";
		List<String> funtions = JobQueueEntity.getFunctions();
		if (!SMUtil.isListNullOrEmpty(funtions)) {
			for (String fun : funtions) {
				if (fun.trim().isEmpty()) {
					funtions.remove(fun);
				}
			}

			if (funtions.isEmpty()) {
				return condition;
			}

			condition += " AND \"FUNCTION_NAME\" in (";
			for (int i = 0; i < funtions.size(); i++) {
				condition += "'" + funtions.get(i) + "'";
				if (i != funtions.size() - 1) {
					condition += ",";
				}
			}
			condition += ") ";
		}
		return condition;
	}

	/**
	 * get Job AMR string
	 * 
	 * @param JobQueueEntity
	 * @return
	 */
	private String getJobAMRSql(JobQueueEntity JobQueueEntity) {
		String job_amr_sql = "select \"FUNCTION_NAME\" as \"functionName\","
				+ " CASE WHEN SUM(\"JOB_COUNT\") is null THEN 0"
				+ "    ELSE SUM(\"JOB_COUNT\") END as \"jobCountSum\","
				+ " CASE WHEN SUM(\"RCOUNT\") is null THEN 0"
				+ "    ELSE SUM(\"RCOUNT\") END as \"readCountSum\","
				+ " CASE WHEN SUM(\"MCOUNT\") is null THEN 0"
				+ "    ELSE SUM(\"MCOUNT\") END as \"matchCountSum\","
				+ " ((CASE WHEN SUM(\"JOB_COUNT\") is null THEN 0"
				+ "    WHEN SUM(\"RCOUNT\")=0 THEN 1"
				+ "   ELSE SUM(\"MCOUNT\")/SUM(\"RCOUNT\") END)*100) as \"amrAvg\""
				+ " from ( "
				+ "    select a.\"FUNCTION_ID\", \"JOB_COUNT\","
				+ "        CASE WHEN COALESCE(\"READ_COUNT\",\"READ_COUNT\",-1)=-1 THEN 0"
				+ "            ELSE \"READ_COUNT\" END as \"RCOUNT\","
				+ "        CASE WHEN COALESCE(\"MATCH_COUNT\",\"MATCH_COUNT\",-1)=-1 THEN 0 "
				+ "            ELSE \"MATCH_COUNT\" END as \"MCOUNT\","
				+ "         \"SUBMISSION_TIME\" "
				+ "    from \"JOB_QUEUE\" a, \"FUNCTION_TYPES\" b "
				+ "    where a.\"FUNCTION_ID\"=b.\"FUNCTION_ID\"";

		job_amr_sql += getCondition(JobQueueEntity);
		job_amr_sql += " ) as job right join ("
				+ "    select \"FUNCTION_ID\", \"FUNCTION_NAME\""
				+ "    from \"FUNCTION_TYPES\""
				+ "    where \"FUNCTION_NAME\" <> 'EXTRACTION'"
				+ getFuncCondition(JobQueueEntity)
				+ ") as ft on job.\"FUNCTION_ID\"=ft.\"FUNCTION_ID\""
				+ " GROUP by \"FUNCTION_NAME\", ft.\"FUNCTION_ID\""
				+ " order by ft.\"FUNCTION_ID\"";		
		return job_amr_sql;
	}
	
	
	

	/**
	 * get JobAMRPojo form JOB_QUEUE, FUNCTION_TYPES
	 * 
	 * @param page
	 * @param JobQueueEntity
	 * @return
	 */
	public Page<JobAMRPojo> getJobAMR(Page<JobAMRPojo> page,
			JobQueueEntity JobQueueEntity) {
		String sql = getJobAMRSql(JobQueueEntity);		
		return jobRepository.findBySql(page, sql, JobAMRPojo.class);
	}

	/**
	 * get JobAMRPojo form JOB_QUEUE, FUNCTION_TYPES
	 * 
	 * @param JobQueueEntity
	 * @return
	 */
	public List<JobAMRPojo> getJobAMR(JobQueueEntity JobQueueEntity) {
		String sql = getJobAMRSql(JobQueueEntity);		
		return jobRepository.findBySql(sql, JobAMRPojo.class);
	}

	/**
	 * get Job Elapse Sql string
	 * 
	 * @param JobQueueEntity
	 * @return
	 */
	private String getJobElapseSql(JobQueueEntity JobQueueEntity) {
		String job_elapse_sql = "select \"FUNCTION_NAME\" as \"functionName\","
				+ " CASE WHEN SUM(\"JOB_COUNT\") is null THEN 0"
				+ "     ELSE SUM(\"JOB_COUNT\") END as \"jobCountSum\","
				+ " to_char((CASE WHEN SUM(\"JOB_COUNT\") is null THEN 0"
				+ "     ELSE MIN(\"ELAPSE_TIME_MIN\") END) * INTERVAL '1 millisecond',"
				+ "     'HH24:MI:SS.MS') as \"elapseMin\","
				+ " to_char((CASE WHEN SUM(\"JOB_COUNT\") is null THEN 0"
				+ "     ELSE SUM(\"ELAPSE_TIME_SUM\")/ SUM(\"JOB_COUNT\") END) *"
				+ "     INTERVAL '1 millisecond', 'HH24:MI:SS.MS') as \"elapseAvg\","
				+ " CASE WHEN SUM(\"JOB_COUNT\") is null THEN 0"
				+ "     ELSE SUM(\"MULTI_JOBS_HIT_COUNT\") END as \"hitCountSum\","
				+ " CASE WHEN SUM(\"JOB_COUNT\") is null THEN 0"
				+ "     ELSE SUM(\"MULTI_JOBS_FAILED_COUNT\") END as \"failedCountSum\","
				+ " to_char((CASE WHEN SUM(\"JOB_COUNT\") is null THEN 0"
				+ "     ELSE MAX(\"ELAPSE_TIME_MAX\") END) * INTERVAL '1 millisecond',"
				+ "     'HH24:MI:SS.MS') as \"elapseMax\""
				+ " from ( "
				+ "    select a.\"FUNCTION_ID\", \"JOB_COUNT\", \"ELAPSE_TIME_MIN\","
				+ "        \"ELAPSE_TIME_SUM\", \"ELAPSE_TIME_MAX\","
				+ "        \"MULTI_JOBS_HIT_COUNT\", \"MULTI_JOBS_FAILED_COUNT\""
				+ "    from \"JOB_QUEUE\" a, \"FUNCTION_TYPES\" b "
				+ "    where a.\"FUNCTION_ID\"=b.\"FUNCTION_ID\"";

		job_elapse_sql += getCondition(JobQueueEntity);

		job_elapse_sql += " ) as job right join ("
				+ "    select \"FUNCTION_ID\", \"FUNCTION_NAME\""
				+ "    from \"FUNCTION_TYPES\""
				+ "    where \"FUNCTION_NAME\" <> 'EXTRACTION'"
				+ getFuncCondition(JobQueueEntity)
				+ ") as ft on job.\"FUNCTION_ID\"=ft.\"FUNCTION_ID\""
				+ " GROUP by \"FUNCTION_NAME\", ft.\"FUNCTION_ID\""
				+ " order by ft.\"FUNCTION_ID\"";		
		return job_elapse_sql;
	}

	/**
	 * get JobElapsePojo form JOB_QUEUE, FUNCTION_TYPES
	 * 
	 * @param page
	 * @param JobQueueEntity
	 * @return
	 */
	public Page<JobElapsePojo> getJobElapse(Page<JobElapsePojo> page,
			JobQueueEntity JobQueueEntity) {
		String sql = getJobElapseSql(JobQueueEntity);
		return jobRepository.findBySql(page, sql, JobElapsePojo.class);
	}

	/**
	 * get JobElapsePojo form JOB_QUEUE, FUNCTION_TYPES
	 * 
	 * @param JobQueueEntity
	 * @return
	 */
	public List<JobElapsePojo> getJobElapse(JobQueueEntity JobQueueEntity) {
		String sql = getJobElapseSql(JobQueueEntity);
		return jobRepository.findBySql(sql, JobElapsePojo.class);
	}
}
