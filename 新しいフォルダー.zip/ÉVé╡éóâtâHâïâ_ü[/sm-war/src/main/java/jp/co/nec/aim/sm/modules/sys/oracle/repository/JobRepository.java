package jp.co.nec.aim.sm.modules.sys.oracle.repository;

import java.util.List;

import jp.co.nec.aim.sm.common.persistence.BaseRepository;
import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.TopJobQueueEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.JobPojo;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.TopJobQueue;

public interface JobRepository extends BaseRepository<TopJobQueueEntity, Long> {
	public Page<TopJobQueue> findJobPage(Page<TopJobQueue> page, JobPojo job);

	public List<TopJobQueue> findJobList(JobPojo job);

	// public Page<TopLevelJobPojo> findTopLevelJobPojo(
	// Page<TopLevelJobPojo> paramPage, TopLevelJobPojo topLevelJobPojo);

	// public List<TopLevelJobPojo> findTopLevelJoblist(
	// TopLevelJobPojo topLevelJobPojo);

	public String findResultsByjobId(Long jobId, String field);

	public int updatePriority(JobPojo job);

	public int completeJobs(List<Long> jobIdList);

	public int restartJobs(List<Long> jobIdList);
}
