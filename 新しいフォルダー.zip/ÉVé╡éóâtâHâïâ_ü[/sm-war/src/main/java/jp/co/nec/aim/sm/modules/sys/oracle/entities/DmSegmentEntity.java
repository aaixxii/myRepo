package jp.co.nec.aim.sm.modules.sys.oracle.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;

/**
 * The persistent class for the DM_SEGMENTS database table.
 * 
 */
@Entity
@Table(name = "DM_SEGMENTS")
public class DmSegmentEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private DmSegmentEntityPK id;

	@Column(name = "RANK")
	@Enumerated(EnumType.ORDINAL)
	private SegAssignmentRank rank;

	public DmSegmentEntity() {
	}

	public DmSegmentEntityPK getId() {
		return this.id;
	}

	public void setId(DmSegmentEntityPK id) {
		this.id = id;
	}

	public SegAssignmentRank getRank() {
		return this.rank;
	}

	public void setRank(SegAssignmentRank rank) {
		this.rank = rank;
	}

}