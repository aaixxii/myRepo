package jp.co.nec.aim.sm.modules.sys.service;

import java.util.List;

import jp.co.nec.aim.sm.common.constant.MMConfigProperty;
import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.modules.sys.BaseService;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.SystemConfigEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.BiometricContainerPojo;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.EligibleBinsPojo;
import jp.co.nec.aim.sm.modules.sys.oracle.repository.DmEligibleBiometricContainerRepository;
import jp.co.nec.aim.sm.modules.sys.oracle.repository.SystemConfigRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional(value = "oracleTXManager")
public class DmEligibleBiometricContainerService extends BaseService {	
	@Autowired
	private DmEligibleBiometricContainerRepository dmEligbleDao;
	
	@Autowired
	private SystemConfigRepository systemConfigDao;
	
	 public Page<EligibleBinsPojo> findDmEligibleBinPage(Page<EligibleBinsPojo> page, EligibleBinsPojo pojo ) {
		 Page<EligibleBinsPojo> ebList = dmEligbleDao.findEligibleBinsPage(page, pojo);	
		 setDefaultMinRedundancy(ebList.getList());
		 return ebList;
	}
	
	@SuppressWarnings("unchecked")
	public Page<EligibleBinsPojo> findDmEligibleBinsList(EligibleBinsPojo pojo ) {			
		List<EligibleBinsPojo> ebLists =dmEligbleDao.findEligibleBins(pojo);
		setDefaultMinRedundancy(ebLists);
		return (Page<EligibleBinsPojo>) ebLists;
	}
	
	private <T> void setDefaultMinRedundancy(List<T> list) {
		SystemConfigEntity sce = systemConfigDao
				.findByProperty(MMConfigProperty.DEFAULT_MIN_REDUNDANCY);
		for (T iterm : list) {
			if (iterm.getClass().equals(EligibleBinsPojo.class)) {
				if (((EligibleBinsPojo) iterm).getMinimumRedundancy() == null) {
					((EligibleBinsPojo) iterm).setMinimumRedundancy(Long
							.valueOf(sce.getPropertyValue()));
				}
			} else if (iterm.getClass().equals(BiometricContainerPojo.class)) {
				if (((BiometricContainerPojo) iterm).getMinimumRedundancy() == null) {
					((BiometricContainerPojo) iterm).setMinimumRedundancy(Long
							.valueOf(sce.getPropertyValue()));
				}
			}
		}
	}
	
}
