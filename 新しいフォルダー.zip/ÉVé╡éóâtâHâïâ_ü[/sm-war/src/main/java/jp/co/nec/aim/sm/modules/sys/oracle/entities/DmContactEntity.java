package jp.co.nec.aim.sm.modules.sys.oracle.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The persistent class for the DM_CONTACTS database table.
 * 
 */
@Entity
@Table(name = "DM_CONTACTS")
public class DmContactEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "DM_ID")
	private long dmId;

	@Column(name = "CONTACT_TS")
	private Long contactTs;

	public DmContactEntity() {
	}

	public long getDmId() {
		return this.dmId;
	}

	public void setDmId(long dmId) {
		this.dmId = dmId;
	}

	public Long getContactTs() {
		return this.contactTs;
	}

	public void setContactTs(Long contactTs) {
		this.contactTs = contactTs;
	}

}