package jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping;

import java.io.Serializable;

public class TransactionMonitorData implements Serializable {
	private static final long serialVersionUID = 5389386965871981626L;
	private String functionType;
	private String family;
	private Long count;

	public TransactionMonitorData() {
	};

	public String getFunctionType() {
		return functionType;
	}

	public TransactionMonitorData(String functionType, String family,
			Long count) {
		this.functionType = functionType;
		this.family = family;
		this.count = count;
	}

	public void setFunctionType(String functionType) {
		this.functionType = functionType;
	}

	public String getFamily() {
		return family;
	}

	public void setFamily(String family) {
		this.family = family;
	}

	

	public Long getCount() {
		return count;
	}

	public void setCount(Long count) {
		this.count = count;
	}

	@Override
	public int hashCode() {
		return this.functionType.hashCode() + this.family.hashCode()
				+ this.count.hashCode() + this.hashCode();
	}

	@Override
	public boolean equals(Object other) {
		if (other != null
				&& other instanceof TransactionMonitorData
				&& this.functionType
						.equals(((TransactionMonitorData) other).functionType)
				&& this.family.equals(((TransactionMonitorData) other).family)
				&& this.count.longValue() == ((TransactionMonitorData) other).count
						.longValue()) {
			return true;
		} else {
			return false;
		}
	}
}
