package jp.co.nec.aim.sm.modules.sys.web.listener;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.nec.aim.sm.modules.sys.postgres.entity.ExtractJobQueueEntity;
import jp.co.nec.aim.sm.modules.sys.service.ExtractjobQueueService;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

/**
 * Listener JobQueue listener and data files records data into jobQueue table.
 * 
 */
public class MMExtractJobQueueHttpListener extends HttpServlet {

	private static final long serialVersionUID = 970000232925594099L;
	private static Logger log = Logger
			.getLogger(MMExtractJobQueueHttpListener.class);

	public MMExtractJobQueueHttpListener() {
		super();
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		ApplicationContext applicationContext = WebApplicationContextUtils
				.getWebApplicationContext(this.getServletContext());
		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(
					request.getInputStream()));
			String line;

			/** Validating received data */
			while ((line = br.readLine()) != null) {
				try {
					String splitLine[] = line.split(",");

					ExtractjobQueueService ejqService = (ExtractjobQueueService) applicationContext
							.getBean("extractjobQueueService");

					saveAndFlush(ejqService, splitLine);

				} catch (HibernateException ex) {
					log.error(ex.getMessage(), ex);
					log.info("MMJobQueueHttpListener:doPost(),"
							+ " extractJobQueue, invalid data, "
							+ "skipping record : " + line);
				} catch (Exception ex) {
					log.error(ex.getMessage(), ex);
					log.info("MMJobQueueHttpListener:doPost(),"
							+ " extractJobQueue, invalid data, "
							+ "skipping record : " + line);
				}
			}
		} catch (Exception ex) {
			log.error("MMExtractJobQueueHttpListener:doPost(), "
					+ "recieving file error : " + ex.getMessage(), ex);
			response.getWriter().println("ERROR");
			return;
		}
		log.info("MMExtractJobQueueHttpListener:doPost(),"
				+ " mm job extract file has been saved successfully");
		response.getWriter().println("SUCCESS");
	}

	public void saveAndFlush(ExtractjobQueueService ejqService,
			String splitLine[]) throws ParseException {

		ExtractJobQueueEntity extractJobQueueEntity = new ExtractJobQueueEntity();

		/** EXTRACT_JOB_ID column */
		if (!IsNull(splitLine[0])) {
			extractJobQueueEntity.setExtractJobId(new Long(splitLine[0]));			
		}

		/** FUNCTION_TYPE_ID column */
		if (!IsNull(splitLine[1])) {
			extractJobQueueEntity.setFunctionTypeId(new Long(splitLine[1]));			
		}
		/** PRIORITY column */
		if (!IsNull(splitLine[2])) {
			extractJobQueueEntity.setPriority(Integer.parseInt(splitLine[2]));			
		}
		/** STATUS column */
		if (!IsNull(splitLine[3])) {
			extractJobQueueEntity.setStatus(new Integer(splitLine[3]));			
		}
		/** FAILED_FLAG column */
		if (!IsNull(splitLine[4])) {
			if ("false".equalsIgnoreCase(splitLine[4])) {
				extractJobQueueEntity.setFailed(0);
			} else {
				extractJobQueueEntity.setFailed(1);
			}			
		}
		/** MU_ID column */
		if (!IsNull(splitLine[5])) {
			extractJobQueueEntity.setMuId(new Long(splitLine[5]));			
		}

		DateFormat formatter = new SimpleDateFormat("yyyy/MM/dd kk:mm:ss.SSS");
		Date date;
		/** PROCESSING_TIME column */
		if (!IsNull(splitLine[6])) {
			formatter = new SimpleDateFormat("yyyy/MM/dd kk:mm:ss.SSS");
			date = (Date) formatter.parse(splitLine[6]);
			Timestamp processStartTime = new Timestamp(date.getTime());
			extractJobQueueEntity.setProcessStartTime(processStartTime);			
		}

		/** RESULT_TIME column */
		if (!IsNull(splitLine[7])) {
			date = (Date) formatter.parse(splitLine[7]);
			Timestamp resultTimestamp = new Timestamp(date.getTime());
			extractJobQueueEntity.setResultTime(resultTimestamp);			
		}

		/** SUBMISSION_TIME column */
		if (!IsNull(splitLine[8])) {
			date = (Date) formatter.parse(splitLine[8]);
			Timestamp submissionTimestamp = new Timestamp(date.getTime());
			extractJobQueueEntity.setSubmissionTime(submissionTimestamp);			
		}

		/** FAILURE_COUNT column */
		if (!IsNull(splitLine[9])) {
			extractJobQueueEntity.setFailureCount(Integer
					.parseInt(splitLine[9]));			
		}

//		/** CALLBACKURL column */
//		if (!IsNull(splitLine[10])) {
//			extractJobQueueEntity.setCallbackURL(String.valueOf(splitLine[10]));
//			log.info(" callbackURL .... "
//					+ extractJobQueueEntity.getCallbackURL());
//		}
//
//		/** CALLBACKURL column */
//		if (!IsNull(splitLine[11])) {
//			String callBackType = (String) splitLine[11];
//			if (callBackType.equalsIgnoreCase("XML")) {
//				extractJobQueueEntity.set
//			}
//			
//			
//			extractJobQueueEntity.setCallbackURL(String.valueOf(splitLine[10]));
//			log.info(" callbackURL .... "
//					+ extractJobQueueEntity.getCallbackURL());
//		}

		ejqService.saveAndFlush(extractJobQueueEntity);
	}

	private boolean IsNull(String str) {
		if (str == null || "".equals(str)) {
			return true;
		}
		return false;
	}
}
