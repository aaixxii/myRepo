package jp.co.nec.aim.sm.modules.sys.web.listener;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.nec.aim.sm.modules.sys.postgres.entity.JobQueueEntity;
import jp.co.nec.aim.sm.modules.sys.service.JobQueueService;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

public class MMJobQueueHttpListener extends HttpServlet {

	private static final long serialVersionUID = -8030407207827103308L;
	private static Logger log = Logger.getLogger(MMJobQueueHttpListener.class);
	private static Integer fieldCount = 17;

	public MMJobQueueHttpListener() {
		super();
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		log.info("JobQueue [GET METHOD] called.");
		log.info("JobQueue [GET METHOD] calling [POST METHOD].");
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		log.info("JobQueue [POST METHOD] called.");
		// System.out.println("Called for POST method");
		ApplicationContext applicationContext = WebApplicationContextUtils
				.getWebApplicationContext(this.getServletContext());
		log.info("JobQueue [POST METHOD], reading statistics reportor file.");

		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(
					request.getInputStream()));
			String line;
			Integer counter = 0;
			/** Validating received data */
			while ((line = br.readLine()) != null) {
				counter++;
				try {
					String splitLine[] = line.split(",");
					if (splitLine.length < fieldCount) {
						response.getWriter().println(
								"Record count " + counter
										+ "# invalid record data struture,"
										+ " field count is less than expected");

						continue;
					}
					log.info("Record... " + line);

					JobQueueService service = (JobQueueService) applicationContext
							.getBean("jobQueueService");

					saveAndFlush(service, splitLine);

				} catch (HibernateException ex) {
					log.error(ex.getMessage(), ex);
					log.info("JobQueue [POST METHOD], invalid data,"
							+ " skipping record: " + line);

				} catch (Exception ex) {
					log.error(ex.getMessage(), ex);
					log.info("JobQueue [POST METHOD], invalid data,"
							+ " skipping record: " + line);
				}
			}

		} catch (Exception ex) {
			log.error("JobQueue, File recieving error: " + ex.getMessage(), ex);

			response.getWriter().println("JobQueue, Error :" + ex.toString());

			return;
		}
		log.info("JobQueue, file recieved successfully");

		response.getWriter().println("SUCCESS");
	}

	public void saveAndFlush(JobQueueService service, String splitLine[])
			throws ParseException {

		JobQueueEntity jobQueueEntity = new JobQueueEntity();

		/** JOB_ID column */
		if (!IsNull(splitLine[0])) {
			jobQueueEntity.setJobId(new Long(splitLine[0]));			
		}

		/** FUNCTION_ID column */
		if (!IsNull(splitLine[1])) {
			jobQueueEntity.setFunctionId((new Long(splitLine[1])));			
		}

		/** PRIORITY column */
		if (!IsNull(splitLine[2])) {
			jobQueueEntity.setPriority(Integer.parseInt(splitLine[2]));			
		}
		/** JOB STATE column */
		if (!IsNull(splitLine[3])) {
			jobQueueEntity.setState(Integer.parseInt(splitLine[3]));			
		}

		/** READ COUNT column */
		if (!IsNull(splitLine[4])) {
			jobQueueEntity.setReadCount(Long.valueOf(splitLine[4]));			
		}

		/** MATCH COUNT column */
		if (!IsNull(splitLine[5])) {
			jobQueueEntity.setMatchCount(Long.valueOf(splitLine[5]));			
		}

		/** HIT FLAG column */
		if (!IsNull(splitLine[6])) {
			if ("false".equalsIgnoreCase(splitLine[6])) {
				jobQueueEntity.setHitFlag(0);
			} else {
				jobQueueEntity.setHitFlag(1);
			}
			// jobQueueEntity.setHitflag(Integer.parseInt(splitLine[5]));
			log.info(" hitFlag... " + jobQueueEntity.getHitFlag());
		}

		/** RESULT TS column */
		DateFormat formatter = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSS");
		Date date;
		if (!IsNull(splitLine[7])) {
			date = (Date) formatter.parse(splitLine[7]);
			Timestamp resultTime = new Timestamp(date.getTime());
			jobQueueEntity.setResultTime(resultTime);			
		}
		/** SUBMISSION TS column */
		if (!IsNull(splitLine[8])) {
			date = (Date) formatter.parse(splitLine[8]);
			Timestamp submissionTime = new Timestamp(date.getTime());
			jobQueueEntity.setSubmissionTime(submissionTime);			
		}
		/** FAILED FLAG column */
		if (!IsNull(splitLine[9])) {
			if ("false".equalsIgnoreCase(splitLine[9])) {
				jobQueueEntity.setFailed(0);
			} else {
				jobQueueEntity.setFailed(1);
			}			
		}

		/** PAUSED FLAG column */
		if (!IsNull(splitLine[10])) {
			if ("false".equalsIgnoreCase(splitLine[10])) {
				jobQueueEntity.setPaused(0);
			} else {
				jobQueueEntity.setPaused(1);
			}			
		}

		/** MAX CANDIDATES column */
		if (!IsNull(splitLine[11])) {
			jobQueueEntity.setMaxCandidates(Integer.parseInt(splitLine[11]));			
		}

		/** MIN SCORE column */
		if (!IsNull(splitLine[12])) {
			jobQueueEntity.setMinScore(Integer.parseInt(splitLine[12]));
			
		}

		/** REVISION column */
		if (!IsNull(splitLine[13])) {
			jobQueueEntity.setRevision(Integer.parseInt(splitLine[13]));			
		}

		/** CONSOLIDATED BY CONTAINER column */
		if (!IsNull(splitLine[14])) {
			if ("false".equalsIgnoreCase(splitLine[14])) {
				jobQueueEntity.setConsolidatedByContainer(0);
			} else {
				jobQueueEntity.setConsolidatedByContainer(1);
			}
			log.info(" consolidatedByContainer .. "
					+ jobQueueEntity.getConsolidatedByContainer());
		}

		/** MULTI RECORD CANDIDATES column */
		if (!IsNull(splitLine[15])) {
			if ("false".equalsIgnoreCase(splitLine[15])) {
				jobQueueEntity.setMultiRecordCandidates(0);
			} else {
				jobQueueEntity.setMultiRecordCandidates(1);
			}			
		}

		/** PERCENTAGE POINT column */
		if (!IsNull(splitLine[16])) {
			jobQueueEntity
					.setPercentagePoint(Double.parseDouble(splitLine[16]));			
		}

		/** HIT_THRESHOLD column */
		if (!IsNull(splitLine[17])) {
			jobQueueEntity.setHitThreshhold(Integer.parseInt(splitLine[17]));			
		}

		jobQueueEntity.setJobCount(new Integer(1));
		jobQueueEntity
				.setMultiJobsHitCount(jobQueueEntity.getHitFlag() != null ? jobQueueEntity
						.getHitFlag() : 0);
		jobQueueEntity
				.setMultiJobsFailedCount(jobQueueEntity.getFailed() != null ? jobQueueEntity
						.getFailed() : 0);
		Long elapseTime = (jobQueueEntity.getResultTime().getTime() - jobQueueEntity
				.getSubmissionTime().getTime());
		jobQueueEntity.setElapseTimeSum(elapseTime);
		jobQueueEntity.setElapseTimeMax(elapseTime);
		jobQueueEntity.setElapseTimeMin(elapseTime);
		jobQueueEntity.setSummaryFlag(0);

		service.saveAndFlush(jobQueueEntity);
	}

	private boolean IsNull(String str) {
		if (str == null || "".equals(str)) {
			return true;
		}
		return false;
	}

	public static void main(String[] args) throws ParseException {
		DateFormat formatter = new SimpleDateFormat("yyyy/MM/dd hh:mm:ss.SSS");
		Timestamp submissionTime = new Timestamp(formatter.parse(
				"2015/06/17 12:59:52.191").getTime());
		System.out.println(submissionTime.toString());
	}
}
