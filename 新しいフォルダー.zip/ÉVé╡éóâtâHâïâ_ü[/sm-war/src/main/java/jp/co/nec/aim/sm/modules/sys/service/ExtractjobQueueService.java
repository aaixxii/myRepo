package jp.co.nec.aim.sm.modules.sys.service;

import jp.co.nec.aim.sm.modules.sys.postgres.entity.ExtractJobQueueEntity;
import jp.co.nec.aim.sm.modules.sys.postgres.repository.ExtractjobQueueRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional(value = "postgresTXManager")
public class ExtractjobQueueService {

	@Autowired
	private ExtractjobQueueRepository extractJobDao;

	/**
	 * save And Flush ExtractJobQueueEntity
	 * 
	 * @param extractJob
	 */
	public void saveAndFlush(ExtractJobQueueEntity extractJob) {
		extractJobDao.saveAndFlush(extractJob);
	}
}
