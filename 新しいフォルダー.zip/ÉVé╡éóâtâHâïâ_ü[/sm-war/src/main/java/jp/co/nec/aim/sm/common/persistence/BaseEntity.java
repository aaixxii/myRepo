package jp.co.nec.aim.sm.common.persistence;

import java.io.Serializable;

import javax.persistence.MappedSuperclass;

/**
 * the base class of Entity
 */
@MappedSuperclass
public abstract class BaseEntity implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1742570874971678344L;

}
