package jp.co.nec.aim.sm.common.constant;

public enum UnitType {
	MU("muagentd"), UNKNOWN(""), DM("dm"), MM("mm"), MR("mragentd"), SM("sm");

	/**
	 * the service Name of each unit
	 */
	private String serviceName;

	/**
	 * the default constructor
	 * 
	 * @param serviceName
	 */
	private UnitType(final String serviceName) {
		this.serviceName = serviceName;
	}

	/**
	 * get the service name
	 * 
	 * @return service name
	 */
	public String getServiceName() {
		return serviceName;
	}
}
