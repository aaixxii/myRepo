package jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping;

import java.util.Comparator;

public class ComponentStatusComparator implements Comparator<ComponentStatus> {

	@Override
	public int compare(ComponentStatus o1, ComponentStatus o2) {
		if (o1 == null || o2 == null || o1.getComponentName() == null
				|| o2.getComponentName() == null || o1.getState() == null
				|| o2.getState() == null) {
			String errMsg = "There are null object in parameters,can't to compare two object! ";
			throw new RuntimeException(errMsg);
		}
		int first = o1.getComponentName().compareTo(o2.getComponentName());
		int second = o1.getState().compareTo(o2.getState());
		int three = o1.getCount().compareTo(o2.getCount());
		return first != 0 ? first : (second != 0 ? second : three);
	}
}
