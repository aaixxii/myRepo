package jp.co.nec.aim.sm.modules.sys.oracle.repository;

import java.math.BigDecimal;
import java.util.List;

import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.common.utils.SMUtil;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.FormatTypeEntity;

import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

public class FormatTypeRepositoryImpl {
	/** the log instance **/
	private static Logger logger = LoggerFactory
			.getLogger(FormatTypeRepositoryImpl.class);

	@Autowired
	FormatTypeRepository repository;

	/**
	 * get Detached Criteria
	 * 
	 * @param formatType
	 * @return
	 */
	private DetachedCriteria getDetachedCriteria(FormatTypeEntity formatType) {
		// create the DetachedCriteria instance without session
		final DetachedCriteria dc = DetachedCriteria
				.forClass(FormatTypeEntity.class);

		// add condition formatId
		final Long formatId = formatType.getFormatId();
		if (!SMUtil.isObjectNull(formatId)) {
			logger.debug("add condition formatId = {}", formatId);
			dc.add(Restrictions.eq("formatId", formatId));
		}

		// add condition formatName
		final String formatName = formatType.getFormatName();
		if (StringUtils.isNotBlank(formatName)) {
			logger.debug("add condition formatName = {}", formatName);
			dc.add(Restrictions.eq("formatName", formatName));
		}

		return dc;
	}

	/**
	 * find Format Type Page
	 * 
	 * @param page
	 * @param formatType
	 * @return
	 */
	public Page<FormatTypeEntity> findFormatTypePage(
			Page<FormatTypeEntity> page, FormatTypeEntity formatType) {
		final DetachedCriteria dc = getDetachedCriteria(formatType);
		// add order by condition
		if (!StringUtils.isNotBlank(page.getOrderBy())) {
			logger.debug("add Order formatId");
			dc.addOrder(Order.asc("formatId"));
		}
		logger.debug("find Page for FormatTypeEntity");
		return repository.findPage(page, dc);
	}

	/**
	 * get all format type
	 * 
	 * @return
	 */
	public List<String> getAllFormatType() {
		String sql = "select FORMAT_NAME from FORMAT_TYPES order by FORMAT_ID";
		//logger.debug("get All Format Type: {}", sql);
		return repository.findBySql(sql);
	}

	/**
	 * get format id by name
	 * 
	 * @param formatName
	 * @return
	 */
	public Integer getFormatId(String formatName) {
		String sql = "select FORMAT_ID from FORMAT_TYPES where FORMAT_NAME = '"
				+ formatName + "'";
		logger.debug("get Format Id where FORMAT_NAME = '{}'", formatName);
		List<BigDecimal> ids = repository.findBySql(sql);
		if (ids.size() != 1) {
			return null;
		}
		return ids.get(0).intValue();

	}
}
