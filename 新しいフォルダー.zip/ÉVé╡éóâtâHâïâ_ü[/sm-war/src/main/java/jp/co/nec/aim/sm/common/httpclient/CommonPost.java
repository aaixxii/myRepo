package jp.co.nec.aim.sm.common.httpclient;

import jp.co.nec.aim.sm.common.constant.Constants;
import jp.co.nec.aim.sm.common.constant.SMConstant;
import jp.co.nec.aim.sm.common.utils.SMUtil;
import jp.co.nec.aim.sm.exception.SMUtilException;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.ByteArrayRequestEntity;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.RequestEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * CommonPost
 * 
 * @author liuyq
 *
 */
public class CommonPost {
	/**
	 * new Instance
	 */
	private static Logger logger = LoggerFactory.getLogger(CommonPost.class);
	private String postUrl;
	private byte[] bytes;
	private String excutingMethod;

	public CommonPost(String postUrl, byte[] bytes, String excutingMethod) {
		super();
		this.postUrl = postUrl;
		this.bytes = bytes;
	}

	/**
	 * postContext
	 * 
	 * @return the instance of HttpResponseInfo
	 */
	public HttpResponseInfo postContext() {
		PostMethod post = null;
		int status;
		byte[] objectBytes = null;
		try {
			HttpClient httpclient = new HttpClient();
			httpclient.getHttpConnectionManager().getParams()
					.setConnectionTimeout(Constants.HTTP_CLIENT_TIMEOUT);
			httpclient.getHttpConnectionManager().getParams()
					.setSoTimeout(Constants.HTTP_CLIENT_TIMEOUT);

			post = new PostMethod(postUrl);
			RequestEntity requestEntity = new ByteArrayRequestEntity(bytes,
					"application/octet-stream");
			post.setRequestEntity(requestEntity);
			status = httpclient.executeMethod(post);
			objectBytes = post.getResponseBody();
		} catch (Exception e) {
			logger.error(String.format(SMConstant.ExceptionLogger,
					excutingMethod, postUrl, e.getMessage()), e);
			throw new SMUtilException("Exception occurred while post to url "
					+ postUrl, e);
		} finally {
			SMUtil.close(post);
		}
		return new HttpResponseInfo(status, objectBytes);
	}

}
