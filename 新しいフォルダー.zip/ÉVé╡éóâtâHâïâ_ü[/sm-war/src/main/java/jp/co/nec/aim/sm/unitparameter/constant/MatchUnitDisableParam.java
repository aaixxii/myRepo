package jp.co.nec.aim.sm.unitparameter.constant;

import java.util.Arrays;
import java.util.List;

import com.google.gson.Gson;
/**
 * Disable Edit Unit Parameter
 * @author jinxl
 *
 */
public class MatchUnitDisableParam {
	private final static String[] systemdisableMuConfig = { "AppPath",
			"MaxCacheSize", "CachePercent", "BatchSize","Region" };
	private final static String[] mumgrdisableMuConfig = { "MMAddress",
			"MMPort", "MUAddress", "MUPort", "BootMatcher", "BootExtractor",
			"NumProcMatcher", "NumProcExtractor", "SizeQueueJob",
			"CountQueueJob", "CountLockShared", "QueueMinSizeFactor",
			"MaxSearchJobReports", "MaxExtractJobReports", "MinJobReports",
			"URLHeartbeat", "URLEnter", "URLExit", "URLReport", "URLComplete",
			"URLLogEvent", "MatcherApp", "ExtractorApp", "CompressMsg",
			"EncryptedTemplate" };

	private final static String[] childprocdisableMuConfig = { "SlapMFRThumbs",
			"FingerNoConfidenceThreshold", "PalmAlgorithm" };

	private final static String[] pathsdisableMuConfig = { "Log", "Data",
			"Segments", "Tmp", "Jobs", "Matcher", "Extractor" };

	private final static String[] StatisticsdisableMuConfig = { "PathFileEdit",
			"PathFileSend", "PathFileError" };
	private final static String systemConfig;
	private final static String mumgrConfig;
	private final static String childprocConfig;
	private final static String pathsConfig;
	private final static String StatisticsConfig;
	static {
		List<String> system = listDisableMuConfig(systemdisableMuConfig);
		Gson gson = new Gson();
		systemConfig = gson.toJson(system);
		system = listDisableMuConfig(mumgrdisableMuConfig);
		mumgrConfig = gson.toJson(system);
		system = listDisableMuConfig(childprocdisableMuConfig);
		childprocConfig = gson.toJson(system);
		system = listDisableMuConfig(pathsdisableMuConfig);
		pathsConfig = gson.toJson(system);
		system = listDisableMuConfig(StatisticsdisableMuConfig);
		StatisticsConfig = gson.toJson(system);
	}

	private static List<String> listDisableMuConfig(String[] disableMuConfig) {
		List<String> list = Arrays.asList(disableMuConfig);
		return list;
	}

	public static String getSystemConfig() {
		return systemConfig;
	}

	public static String getMumgrConfig() {
		return mumgrConfig;
	}

	public static String getChildprocConfig() {
		return childprocConfig;
	}

	public static String getPathsConfig() {
		return pathsConfig;
	}

	public static String getStatisticsConfig() {
		return StatisticsConfig;
	}
}
