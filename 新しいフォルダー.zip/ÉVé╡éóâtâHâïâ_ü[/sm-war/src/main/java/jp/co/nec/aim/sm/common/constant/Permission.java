package jp.co.nec.aim.sm.common.constant;


public enum Permission {
	Guest(""), Viewer(Constants.PERMISSION_VIEWER), User(
			Constants.PERMISSION_USER), Admin(Constants.PERMISSION_ADMIN);

	private String name;

	private Permission(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	/**
	 * findByPermissionStr
	 * 
	 * @param name
	 * @return Permission instance
	 */
	public static Permission findByPermissionStr(String name) {
		for (Permission per : Permission.values()) {
			if (per.getName().equals(name)) {
				return per;
			}
		}
		return Guest;
	}
}
