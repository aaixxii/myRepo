package jp.co.nec.aim.sm.modules.sys.oracle.repository;

import java.util.List;

import jp.co.nec.aim.sm.common.persistence.BaseRepository;
import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.FormatTypeEntity;

public interface FormatTypeRepository extends
		BaseRepository<FormatTypeEntity, Long> {
	/** find Format Type Page **/
	public Page<FormatTypeEntity> findFormatTypePage(
			Page<FormatTypeEntity> page, FormatTypeEntity formatType);

	/** get all format type **/
	public List<String> getAllFormatType();

	/** get format id by name **/
	public Integer getFormatId(String formatName);
}
