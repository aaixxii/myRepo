package jp.co.nec.aim.sm.modules.sys.service;

import java.util.List;

import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.modules.sys.BaseService;
import jp.co.nec.aim.sm.modules.sys.postgres.entity.RoleEntity;
import jp.co.nec.aim.sm.modules.sys.postgres.entity.UserEntity;
import jp.co.nec.aim.sm.modules.sys.postgres.repository.RoleRepository;
import jp.co.nec.aim.sm.modules.sys.security.SystemAuthorizingRealm;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class RoleService extends BaseService {

	@Autowired
	private RoleRepository roleRepository;
	@Autowired
	private UserService userService;

	@Autowired
	private SystemAuthorizingRealm systemRealm;

	public RoleEntity getRole(Long id) {
		return roleRepository.findOne(id);
	}

	public List<RoleEntity> findAllRole() {
		DetachedCriteria dc = roleRepository.createDetachedCriteria();
		dc.addOrder(Order.asc("name"));
		return roleRepository.find(dc);
	}

	public Page<RoleEntity> findAllRole(Page<RoleEntity> page) {
		DetachedCriteria dc = roleRepository.createDetachedCriteria();
		if (!StringUtils.isNotEmpty(page.getOrderBy())) {
			dc.addOrder(Order.asc("name"));
		}
		return roleRepository.findPage(page, dc);
	}

	public RoleEntity findRoleByName(String name) {
		return roleRepository.findByName(name);
	}

	@Transactional(readOnly = false)
	public void saveRole(RoleEntity role) {
		roleRepository.clear();
		roleRepository.save(role);
		systemRealm.clearAllCachedAuthorizationInfo();
	}

	@Transactional(readOnly = false)
	public void deleteRole(Long id) {
		roleRepository.deleteById(id);
		systemRealm.clearAllCachedAuthorizationInfo();
	}

	@Transactional(readOnly = false)
	public UserEntity assignUserToRole(RoleEntity role, Long userId) {
		UserEntity user = userService.getUser(userId);
		List<Long> roleIds = user.getRoleIdList();
		if (roleIds.contains(role.getRoleId())) {
			return null;
		}
		user.getRoleList().add(role);
		userService.saveUser(user);
		return user;
	}

	@Transactional(readOnly = false)
	public Boolean outUserInRole(RoleEntity role, Long userId) {
		UserEntity user = userService.getUser(userId);
		List<Long> roleIds = user.getRoleIdList();
		List<RoleEntity> roles = user.getRoleList();
		if (roleIds.contains(role.getRoleId())) {
			roles.remove(role);
			userService.saveUser(user);
			return true;
		}
		return false;
	}

}
