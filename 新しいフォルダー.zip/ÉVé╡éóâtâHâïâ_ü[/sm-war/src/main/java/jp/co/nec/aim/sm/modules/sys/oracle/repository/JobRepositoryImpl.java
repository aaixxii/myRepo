package jp.co.nec.aim.sm.modules.sys.oracle.repository;

import java.util.List;

import jp.co.nec.aim.message.proto.InquiryService.PBInquiryJobResult;
import jp.co.nec.aim.sm.common.constant.JobState;
import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.common.utils.DateUtils;
import jp.co.nec.aim.sm.common.utils.SMUtil;
import jp.co.nec.aim.sm.exception.SMDaoException;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.TopJobQueueEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.JobPojo;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.TopJobQueue;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;

import com.google.protobuf.InvalidProtocolBufferException;

public class JobRepositoryImpl {
	@Autowired
	private JobRepository repository;

	// @Autowired
	// private FusionJobRepository fusionJobDao;

	@Autowired
	private SystemConfigRepository sysConfigDao;

	// @Autowired
	// private MuJobRepository muJobDao;
	@Autowired
	private PersonBiometricsRepository personBiometricsDao;
	// @Autowired
	// private SegmentSetJobRepository segSetJobDao;

	private static String FAILED_REASON = "Completed Jobs by System Manage.";

	private final static String jobsql = "SELECT jq.JOB_ID    AS jobId,"
			+ "   jq.JOB_STATE      AS jobStatus,"
			+ "   functions         AS functions,"
			+ "   jq.FAILED_FLAG    AS failedFlag,"
			+ "   jq.RESULT_TS      AS resultsTS,"
			+ "   jq.SUBMISSION_TS  AS submissionTS,"
			+ "   jq.ASSIGNED_TS  	AS assignedTs,"
			+ "   jq.RESULT         AS results,"
			+ "   jq.PRIORITY       AS priority,"
			+ "   jq.MAX_CANDIDATES AS maxCandidates,"
			+ "   jq.FAILURE_COUNT  AS failureCount,"
			+ "   jq.REMAIN_JOBS    AS remainJobs,"
			+ "   jq.CALLBACK_STYLE AS callbackStyle,"
			+ "   jq.CALLBACK_URL   AS callbackUrl"
			+ " FROM JOB_QUEUE jq,"
			+ "   (SELECT tmp.JOB_ID,"
			+ "     MAX(tmp.FUNCTIONS) AS FUNCTIONS"
			+ "   FROM"
			+ "     (SELECT a.JOB_ID,"
			+ "       ltrim(MAX(sys_connect_by_path(a.function_name, ',')), ',') AS functions"
			+ "     FROM"
			+ "       (SELECT row_number() over(partition BY fj.JOB_ID order by ft.FUNCTION_ID) AS rn,"
			+ "         ft.function_name," + "         fj.JOB_ID,"
			+ "         ft.FUNCTION_ID" + "       FROM function_types ft,"
			+ "         fusion_jobs fj"
			+ "       WHERE ft.FUNCTION_ID = fj.FUNCTION_ID" + "       ) a"
			+ "       START WITH rn = 1 CONNECT BY PRIOR rn = rn - 1"
			+ "     AND a.JOB_ID    = PRIOR a.JOB_ID"
			+ "     GROUP BY a.function_name," + "       a.JOB_ID"
			+ "     ) tmp" + "   GROUP BY tmp.JOB_ID" + "   ) fn"
			+ " WHERE fn.JOB_ID = jq.JOB_ID" + " AND jq.JOB_ID  IN"
			+ "   (SELECT DISTINCT fj.JOB_ID" + "   FROM FUSION_JOBS fj,"
			+ "     FUNCTION_TYPES ft"
			+ "   WHERE fj.FUNCTION_ID = ft.FUNCTION_ID";

	private final static String muJobsSql_restart = "DELETE from mu_jobs"
			+ "  WHERE mu_job_id in"
			+ " (select MU_JOB_ID from MU_JOBS mj, SEGMENT_SET_JOBS"
			+ " ssj, FUSION_JOBS fj, JOB_QUEUE jq where jq.job_id = fj.job_id"
			+ " and ssj.segment_set_job_id = mj.segment_set_job_id and "
			+ " fj.fusion_job_id = ssj.fusion_job_id and jq.job_id = ?)";
	private final static String jobSql_restart = "UPDATE JOB_QUEUE"
			+ " SET JOB_STATE = 0, RESULTS_XML = null, RESULTS_TS = null,"
			+ " FAILED_FLAG = null, FAILURE_COUNT = 0, REMAIN_JOBS = 0"
			+ " where JOB_ID = ?";

	private final static String muJobsSql_complete = "UPDATE mu_jobs"
			+ " SET job_state = 2, results_ts = systimestamp, "
			+ " WHERE job_state != 2 and mu_job_id in ( select "
			+ " MU_JOB_ID from MU_JOBS mj, SEGMENT_SET_JOBS ssj,"
			+ " FUSION_JOBS fj, JOB_QUEUE jq where jq.job_id = fj.job_id "
			+ " and ssj.segment_set_job_id = mj.segment_set_job_id and "
			+ " fj.fusion_job_id = ssj.fusion_job_id and jq.job_id = ?)";
	private final static String muJobsReasonSql_complete = "INSERT INTO"
			+ " mu_job_failure_reasons( failure_id, mu_id, reason,"
			+ " mu_job_id, failure_ts) select failure_id_seq.NEXTVAL,"
			+ " MU_ID, '" + FAILED_REASON + "', MU_JOB_ID, systimestamp"
			+ " from MU_JOBS where job_state != 2 and mu_job_id in ("
			+ " select MU_JOB_ID from MU_JOBS mj, FUSION_JOBS fj,"
			+ " SEGMENT_SET_JOBS ssj, JOB_QUEUE jq where jq.job_id = ? and"
			+ " jq.job_id = fj.job_id and fj.fusion_job_id = ssj.fusion_job_id"
			+ " and ssj.segment_set_job_id = mj.segment_set_job_id)";

	/**
	 * findJobPage
	 * 
	 * @param page
	 * @param job
	 * @return
	 */
	public Page<TopJobQueue> findJobPage(Page<TopJobQueue> page, JobPojo job) {
		String sql = jobsql;
		sql += getDetachedCriteria(job);
		if (!StringUtils.isNotBlank(page.getOrderBy())) {
			sql += " order by jobId desc ";
		}
		return repository.findBySql(page, sql, TopJobQueue.class);
	}

	private String getDetachedCriteria(JobPojo job) {
		// create the DetachedCriteria instance without session
		String sql = "";

		final String functiontype = job.getFunctiontype();
		if (StringUtils.isNotEmpty(functiontype)) {
			sql += " and ft.FUNCTION_NAME=" + "'" + functiontype + "'";
		}
		sql += " )";
		// add the job id condition
		final Long jobId = job.getJobid();
		if (!SMUtil.isObjectNull(jobId)) {
			sql += " and jq.JOB_ID =" + jobId;
		}

		// add the job status condition
		final JobState jobStatus = job.getJobStatus();
		if (!SMUtil.isObjectNull(jobStatus)) {
			sql += " and jq.JOB_STATE=" + jobStatus.ordinal();
		}

		List<JobState> statusList = job.getStatusList();
		if (!SMUtil.isListNullOrEmpty(statusList)) {
			for (int i = statusList.size() - 1; i >= 0; i--) {
				if (statusList.get(i) == null) {
					statusList.remove(i);
				}
			}

			for (int i = 0; i < statusList.size(); i++) {
				if (i == 0) {
					sql += " and jq.JOB_STATE in ("
							+ statusList.get(i).ordinal();
				} else {
					sql += "," + statusList.get(i).ordinal();
				}
			}
			sql += " )";
		}

		// add condition unit Segment
		final Integer failedFlag = job.getFailedFlag();
		if (!SMUtil.isObjectNull(failedFlag)) {
			if (failedFlag == 1) {
				sql += " and jq.FAILED_FLAG=1";
			} else {
				sql += " and (jq.FAILED_FLAG is null or jq.FAILED_FLAG = 0)";
			}
		}

		String submissionTS = job.getSubmissionTS();
		if (StringUtils.isNotEmpty(submissionTS)) {
			long epoch = DateUtils.parseDate(submissionTS).getTime();
			sql += " and jq.SUBMISSION_TS >=" + epoch;
		}
		return sql;
	}

	public List<TopJobQueue> findJobList(JobPojo job) {
		String sql = jobsql;
		sql += getDetachedCriteria(job);
		sql += " order by jobId asc ";
		return repository.findBySql(sql, TopJobQueue.class);
	}

	public String findResultsByjobId(Long jobId, String field) {
		DetachedCriteria dc = DetachedCriteria
				.forClass(TopJobQueueEntity.class);
		if (!SMUtil.isObjectNull(jobId)) {
			dc.add(Restrictions.eq("jobId", jobId));
		}
		dc.setProjection(Projections.property(field));
		List<byte[]> results = this.repository.findAndCast(dc);
		if (results.size() != 1) {
			return null;
		}
		byte[] bytes = results.get(0);
		if (bytes == null || bytes.length <= 0) {
			return "No results was found..";
		}

		PBInquiryJobResult result;
		try {
			result = PBInquiryJobResult.parseFrom(bytes);
		} catch (InvalidProtocolBufferException e) {
			throw new SMDaoException("InvalidProtocolBufferException occurred "
					+ "when parseFrom job result bytes.", e);
		}

		return result.toString();
	}

	public int updatePriority(JobPojo job) {
		String sql = "update JOB_QUEUE set PRIORITY = " + job.getPriority()
				+ " where JOB_ID = " + job.getJobid();

		return repository.updateBySql(sql);
	}

	public int completeJobs(List<Long> jobIdList) {
		int count = 0;
		for (Long id : jobIdList) {
			TopJobQueueEntity job = repository.findOne(id);
			if (job.getJobStatus() != JobState.COMPLETED) {
				int muJobsCount = repository.updateBySql(
						muJobsReasonSql_complete, id);
				if (muJobsCount != 0) {
					repository.updateBySql(muJobsSql_complete, id);
				}
			} else {
				count++;
			}
		}

		return count;
	}

	public int restartJobs(List<Long> jobIdList) {
		int restartCount = 0;
		for (Long id : jobIdList) {
			int muJobsCount = repository.updateBySql(muJobsSql_restart, id);
			if (muJobsCount != 0) {
				restartCount += repository.updateBySql(jobSql_restart, id);
			}
		}
		return restartCount;
	}
}
