package jp.co.nec.aim.sm.common.constant;


public enum UnitState {
	WORKING, TIMED_OUT, EXITED;
	
	public static UnitState getUnitState(String value) {
		for (UnitState u : UnitState.values()) {
			if (value.equals(u.name()))
				return u;
		}
		throw new IllegalArgumentException("Unknown UnitState: " + value);

	}
}
