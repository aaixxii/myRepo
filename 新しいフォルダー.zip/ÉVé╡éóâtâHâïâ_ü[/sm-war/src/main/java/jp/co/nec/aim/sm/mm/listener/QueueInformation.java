package jp.co.nec.aim.sm.mm.listener;

import javax.jms.ExceptionListener;
import javax.jms.MessageListener;

/**
 * 
 * 
 */
public class QueueInformation {
	private String queueID;
	private int queuePort;
	private String queueHostname;
	private String queueProtocol;
	private int timeout;
	private int reattemptCount;
	private int reattemptRunCount;
	private String queueName;
	private String queueType;
	private MessageListener messageListener;
	private ExceptionListener exceptionListener;

	private String userName;
	private String password;

	/**
	 * @return the reattemptRunCount
	 */
	public int getReattemptRunCount() {
		return reattemptRunCount;
	}

	/**
	 * @param reattemptRunCount
	 *            the reattemptRunCount to set
	 */
	public void setReattemptRunCount(int reattemptRunCount) {
		this.reattemptRunCount = reattemptRunCount;
	}

	/**
	 * @return the queuePort
	 */
	public int getQueuePort() {
		return queuePort;
	}

	/**
	 * @return the queueID
	 */
	public String getQueueID() {
		return queueID;
	}

	/**
	 * @param queueID
	 *            the queueID to set
	 */
	public void setQueueID(String queueID) {
		this.queueID = queueID;
	}

	/**
	 * @param queuePort
	 *            the queuePort to set
	 */
	public void setQueuePort(int queuePort) {
		this.queuePort = queuePort;
	}

	/**
	 * @return the queueProtocol
	 */
	public String getQueueProtocol() {
		return queueProtocol;
	}

	/**
	 * @param queueProtocol
	 *            the queueProtocol to set
	 */
	public void setQueueProtocol(String queueProtocol) {
		this.queueProtocol = queueProtocol;
	}

	/**
	 * @return the queueName
	 */
	public String getQueueName() {
		return queueName;
	}

	/**
	 * @param queueName
	 *            the queueName to set
	 */
	public void setQueueName(String queueName) {
		this.queueName = queueName;
	}

	/**
	 * @return the timeout
	 */
	public int getTimeout() {
		return timeout;
	}

	/**
	 * @param timeout
	 *            the timeout to set
	 */
	public void setTimeout(int timeout) {
		this.timeout = timeout;
	}

	/**
	 * @return the reattemptCount
	 */
	public int getReattemptCount() {
		return reattemptCount;
	}

	/**
	 * @param reattemptCount
	 *            the reattemptCount to set
	 */
	public void setReattemptCount(int reattemptCount) {
		this.reattemptCount = reattemptCount;
	}

	/**
	 * @return the queueHostname
	 */
	public String getQueueHostname() {
		return queueHostname;
	}

	/**
	 * @param queueHostname
	 *            the queueHostname to set
	 */
	public void setQueueHostname(String queueHostname) {
		this.queueHostname = queueHostname;
	}

	/**
	 * @return the messageListener
	 */
	public MessageListener getMessageListener() {
		return messageListener;
	}

	/**
	 * @param messageListener
	 *            the messageListener to set
	 */
	public void setMessageListener(MessageListener messageListener) {
		this.messageListener = messageListener;
	}

	/**
	 * @return the exceptionListener
	 */
	public ExceptionListener getExceptionListener() {
		return exceptionListener;
	}

	/**
	 * @param exceptionListener
	 *            the exceptionListener to set
	 */
	public void setExceptionListener(ExceptionListener exceptionListener) {
		this.exceptionListener = exceptionListener;
	}

	public String getQueueType() {
		return queueType;
	}

	public void setQueueType(String queueType) {
		this.queueType = queueType;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
}
