package jp.co.nec.aim.sm.exception;

/**
 * Remote Connect By SSH Exception
 * 
 * @author liuyq
 */
public class RemoteConnectBySSHException extends RuntimeException {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -335026656751093927L;

	/**
	 * @param message
	 */
	public RemoteConnectBySSHException(String message) {
		super(message);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public RemoteConnectBySSHException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * @param cause
	 */
	public RemoteConnectBySSHException(Throwable cause) {
		super(cause);
	}
}
