package jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping;

import jp.co.nec.aim.sm.common.annocation.FieldMapped;
import jp.co.nec.aim.sm.common.annocation.InquiryMapping;

@InquiryMapping
public class BiometricContainerPojo {

	@FieldMapped
	private Long binId;

	public String getContainerName() {
		return containerName;
	}

	public void setContainerName(String containerName) {
		this.containerName = containerName;
	}

	public Long getScopeId() {
		return scopeId;
	}

	public void setScopeId(Long scopeId) {
		this.scopeId = scopeId;
	}

	public Long getMinMuNumForSlb() {
		return minMuNumForSlb;
	}

	public void setMinMuNumForSlb(Long minMuNumForSlb) {
		this.minMuNumForSlb = minMuNumForSlb;
	}

	public Long getMaxSegmentSize() {
		return maxSegmentSize;
	}

	public void setMaxSegmentSize(Long maxSegmentSize) {
		this.maxSegmentSize = maxSegmentSize;
	}

	@FieldMapped
	private String containerName;
	@FieldMapped
	private Long scopeId;

	@FieldMapped
	private String format;

	@FieldMapped
	private Long minimumRedundancy;
	@FieldMapped
	private Long minMuNumForSlb;
	@FieldMapped
	private Long maxSegmentSize;

	private String action;

	public void setBinId(Long binId) {
		this.binId = binId;
	}

	public Long getBinId() {
		return binId;
	}

	public void setFormat(String format) {
		this.format = format;
	}

	public String getFormat() {
		return format;
	}

	public void setMinimumRedundancy(Long minimumRedundancy) {
		this.minimumRedundancy = minimumRedundancy;
	}

	public Long getMinimumRedundancy() {
		return minimumRedundancy;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getAction() {
		return action;
	}

}
