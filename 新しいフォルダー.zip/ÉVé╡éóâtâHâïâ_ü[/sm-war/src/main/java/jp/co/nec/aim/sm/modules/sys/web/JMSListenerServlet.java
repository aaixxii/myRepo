package jp.co.nec.aim.sm.modules.sys.web;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import jp.co.nec.aim.sm.mm.listener.MMQueueListener;
import jp.co.nec.aim.sm.mm.listener.MatchManagerQueueListener;
import jp.co.nec.aim.sm.modules.sys.web.register.CommunicationThread;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.context.WebApplicationContext;

public class JMSListenerServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5630397740413981007L;

	/** the log instance **/
	private static Logger logger = LoggerFactory
			.getLogger(JMSListenerServlet.class);

	public void init(ServletConfig config) throws ServletException {
		try {
			ServletContext servletContext = config.getServletContext();
			WebApplicationContext context = (WebApplicationContext) servletContext
					.getAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE);
			MatchManagerQueueListener queueListener = (MatchManagerQueueListener) context
					.getBean("queueListener");

			// save the matchManagerQueueListener instance
			MMQueueListener.getInstance().setListener(queueListener);

			logger.info("SM Enter");
			CommunicationThread.doStart();

		} catch (Exception e) {
			logger.error("JMS Listener Servlet init error.", e);
		}
	}
}
