package jp.co.nec.aim.sm.modules.sys.oracle.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Immutable;

/**
 * The persistent class for the SYSTEM_CONFIG database table.
 * 
 */
@Entity
@Table(name = "SYSTEM_CONFIG")
@Immutable
public class SystemConfigEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "SYSTEM_CONFIG_CONFIGID_GENERATOR", sequenceName = "SYSTEM_CONFIG_SEQ", initialValue = 1, allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SYSTEM_CONFIG_CONFIGID_GENERATOR")
	@Column(name = "CONFIG_ID")
	private Integer configId;

	@Column(name = "PROPERTY_NAME")
	private String propertyName;

	@Column(name = "PROPERTY_VALUE")
	private String propertyValue;

	public SystemConfigEntity() {
	}

	public Integer getConfigId() {
		return configId;
	}

	public void setConfigId(Integer configId) {
		this.configId = configId;
	}

	public String getPropertyName() {
		return propertyName;
	}

	public void setPropertyName(String propertyName) {
		this.propertyName = propertyName;
	}

	public String getPropertyValue() {
		return propertyValue;
	}

	public void setPropertyValue(String propertyValue) {
		this.propertyValue = propertyValue;
	}

}