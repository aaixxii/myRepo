package jp.co.nec.aim.sm.modules.sys.oracle.entities;

import java.io.Serializable;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * The persistent class for the DM_ELIGIBLE_CONTAINERS database table.
 * 
 */
@Entity
@Table(name = "DM_ELIGIBLE_CONTAINERS")
public class DmEligibleContainerEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private DmEligibleContainerEntityPK id;

	public DmEligibleContainerEntity() {
	}

	public DmEligibleContainerEntityPK getId() {
		return this.id;
	}

	public void setId(DmEligibleContainerEntityPK id) {
		this.id = id;
	}

}