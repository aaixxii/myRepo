package jp.co.nec.aim.sm.modules.sys.web.base;

import java.beans.PropertyEditorSupport;
import java.lang.reflect.Field;

import jp.co.nec.aim.sm.common.utils.Reflections;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.UnitPojo;

public class ControllerFormEditor extends PropertyEditorSupport {

	@Override
	public String getAsText() {
		return super.getAsText();
	}

	@Override
	public void setAsText(String text) throws IllegalArgumentException {
		if (text != null) {
			UnitPojo pidunitpojo = new UnitPojo();
			String[] strs = text.split(",");
			for (int i = 0; i < strs.length; i++) {
				String tmp = strs[i];
				String[] tmps = tmp.split("=");
				Field field = Reflections.getAccessibleField(pidunitpojo,
						tmps[0].trim());
				Class<?> type = field.getType();
				if (type.equals(Long.class)) {
					Reflections.setFieldValue(pidunitpojo, tmps[0].trim(),
							Long.valueOf(tmps[1]));
				} else if (type.equals(String.class)) {
					Reflections.setFieldValue(pidunitpojo, tmps[0].trim(),
							String.valueOf(tmps[1]));
				}
			}
			setValue(pidunitpojo);
		} else {
			setValue(null);
		}
	}

}
