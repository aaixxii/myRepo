package jp.co.nec.aim.sm.modules.sys.oracle.repository;

import java.util.List;

import jp.co.nec.aim.sm.common.persistence.BaseRepository;
import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.MuSegReportEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.MuSegReportEntityPK;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.SegmentWithReport;

public interface MatchUnitSegmentReportRepository extends
		BaseRepository<MuSegReportEntity, MuSegReportEntityPK> {
	public Page<SegmentWithReport> gainSegWithReport(
			Page<SegmentWithReport> page, MuSegReportEntity segwithreport);

	public Page<MuSegReportEntity> findMuSegRepPage(
			Page<MuSegReportEntity> page, MuSegReportEntity muSegRep);

	public List<MuSegReportEntity> ListMuSegRep(MuSegReportEntity muSegRep);

	public List<SegmentWithReport> ListSegWithReport(
			MuSegReportEntity segwithreport);
}
