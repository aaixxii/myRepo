package jp.co.nec.aim.sm.modules.sys.oracle.repository;

import java.util.List;

import jp.co.nec.aim.sm.common.persistence.BaseRepository;
import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.PersonBiometricEntity;

public interface PersonBiometricsRepository extends
		BaseRepository<PersonBiometricEntity, Long> {

	public Page<PersonBiometricEntity> findPersonBiometricsPage(
			Page<PersonBiometricEntity> page, PersonBiometricEntity personbio);

	public List<PersonBiometricEntity> ListPersonBiometrics(
			PersonBiometricEntity personbio);

	// public List<CandidateIdsKey> getCandidateIds(Set<Long> bioIds);
}
