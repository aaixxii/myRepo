package jp.co.nec.aim.sm.modules.sys.oracle.repository;

import java.util.List;

import jp.co.nec.aim.sm.common.constant.MMConfigProperty;
import jp.co.nec.aim.sm.common.persistence.BaseRepository;
import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.SystemConfigEntity;

/**
 * SystemConfigRepository interface
 */
public interface SystemConfigRepository extends
		BaseRepository<SystemConfigEntity, Integer> {
	/** find System Config Page **/
	public Page<SystemConfigEntity> findSystemConfigPage(
			Page<SystemConfigEntity> page, SystemConfigEntity systemConfig);

	/** find System Config Page **/
	public List<SystemConfigEntity> findSystemConfig(
			SystemConfigEntity systemConfig);

	/** find By PropertyName **/
	public SystemConfigEntity findByPropertyName(String propertyName);

	/** find By Property **/
	public SystemConfigEntity findByProperty(MMConfigProperty property);

	/** update System Config **/
	public int updateSystemConfig(Integer configId, String propertyName,
			String propertyValue);

	/** get By Property **/
	public String getProperty(MMConfigProperty property);

	/** get By Property **/
	public long getLongProperty(MMConfigProperty property);

	/** get By Property **/
	public int getIntProperty(MMConfigProperty property);

	/** get By Property **/
	public boolean getBooleanProperty(MMConfigProperty property);
}
