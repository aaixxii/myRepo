package jp.co.nec.aim.sm.modules.sys.oracle.repository;

import java.util.List;

import jp.co.nec.aim.sm.common.persistence.BaseRepository;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.MatchManagerEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.MatchUnitEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.MatchUnitUnionMatchUnitContact;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.UnitPojo;

/**
 * MatchUnitDao interface
 */
public interface MatchUnitRepository extends
		BaseRepository<MatchUnitEntity, Long> {
	
	 /** get MU Units that match the condition **/
	 public List<UnitPojo> getAllMUUnits();
	
	/** get Working MU Units that match the condition **/
	public List<UnitPojo> getAllWorkingMUUnits();
	
	/** get Working MU Units that match the condition **/
	public List<UnitPojo> getAllWorkingMRUnits();

	/** get all matchUnits that match the condition **/
	public List<UnitPojo> findPIDUnitPojolist(MatchUnitEntity unit,
			boolean hasSM);

	/** get Unit **/
	public MatchUnitUnionMatchUnitContact getUnitbyMuId(Long muId, String type);

	/** get MM **/
	public MatchManagerEntity getMMbyMuId(Long muId);
}
