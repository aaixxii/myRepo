package jp.co.nec.aim.sm.modules.sys.util;

import java.io.Serializable;

/**
 * Theme class
 */
public final class Theme implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -3122319984600309530L;

	private int themeId;
	private String label;
	private String value;
	private int sortNumber;

	/**
	 * the constructor of Theme
	 * 
	 * @param themeId
	 * @param label
	 * @param value
	 * @param sortNumber
	 */
	public Theme(final int themeId, final String label, final String value,
			final int sortNumber) {
		this.themeId = themeId;
		this.label = label;
		this.value = value;
		this.sortNumber = sortNumber;
	}

	public int getThemeId() {
		return themeId;
	}

	public void setThemeId(int themeId) {
		this.themeId = themeId;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public int getSortNumber() {
		return sortNumber;
	}

	public void setSortNumber(int sortNumber) {
		this.sortNumber = sortNumber;
	}

}
