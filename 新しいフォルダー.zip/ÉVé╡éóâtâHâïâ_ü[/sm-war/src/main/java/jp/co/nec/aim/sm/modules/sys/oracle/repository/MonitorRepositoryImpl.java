package jp.co.nec.aim.sm.modules.sys.oracle.repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import jp.co.nec.aim.sm.modules.sys.oracle.entities.PreviousCompletedJobCounter;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.SystemConfigEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.ComponentStatus;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.DBMonitorData;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.MuLoadPojo;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.TransactionMonitorData;

import org.hibernate.SQLQuery;
import org.hibernate.transform.Transformers;
import org.hibernate.type.IntegerType;
import org.hibernate.type.LongType;
import org.hibernate.type.StringType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

public class MonitorRepositoryImpl {
	@Autowired
	MonitorRepository repository;
	@Autowired
	SystemConfigRepository systemConfigRepository;	

	private static Logger logger = LoggerFactory
			.getLogger(MonitorRepositoryImpl.class);
	public final static String ComponentSql = ""
			+ "select 'mm' as componentName, state as state,NVL(count(mm_id),0) as count from match_managers group by state "
			+ "union all "
			+ "select 'mr' as componentName, state as state, NVL(count(mr_id),0) as count from map_reducers group by state "
			+ "union all "
			+ "select 'dm' as componentName, state as state ,NVL(count(dm_id),0) as count from data_managers group by state "
			+ "union all "
			+ "select 'mu' as componentName, state as state,NVL(count(mu_id),0) as count from match_units group by state";

	public final static String databaseSql = ""
			+ " with base as (select c.container_name as templateFormat, NVL(sum(s.record_count),0) as recordCount "
			+ " from segments s, containers c where s.container_id (+) = c.container_id"
			+ " and c.scope_id = :scopeId"
			+ " group by c.container_name, s.container_id) "
			+ " select 'tenprintMonitor' as function, templateFormat, recordCount "
			+ " from base"
			+ " where templateFormat in ('RDBT','SDBT','RDBTM','SDBTM','LDB','LDBS','LDBM','LDBX','PLDB','FDB','IDB')"
			+ " union all"
			+ " select 'latentMonitor' as function, templateFormat, recordCount "
			+ " from base "
			+ " where templateFormat in('RDBL','SDBL','RDBLS','SDBLS','RDBLM','SDBL','XDBL','LDB','LDBS','LDBM','LDBX','PDB','PLDB','SDBLM') ";

	public final static String transactionSql = ""
			+ "select 'tenprintFunction' as functionType,it.family_name as family ,NVL(it.job_complete_count- ("
			+  "CASE it.family_name"
			+  "  	WHEN 'TI' THEN :ti "	
			+  "  	WHEN 'TLI' THEN :tli "	
			+  " 	WHEN 'TLIP' THEN :tlip "	
			+  "  	WHEN 'FI' THEN :fi "	
			+  "  	WHEN 'II' THEN :ii "
			+  " END "			
			+ "),0) as count from inquiry_traffic it "			
			+ "where  it.family_name in('TI','TLI','TLIP','FI','II') "		
			+ "union all "
			+ "select 'latentFunction' as functionType,it.family_name as family ,NVL(it.job_complete_count-("
			+  "CASE it.family_name"	
			+  "  	WHEN 'LI' THEN :li "		
			+  " 	WHEN 'LLI' THEN :lli "
			+  "  	WHEN 'LIP' THEN :lip "		
			+  "  	WHEN 'LLIP' THEN :llip "	
			+  " END "	
			+ "),0) as count from inquiry_traffic it "
			+ "where it.family_name in('LI','LLI','LIP','LLIP') "			
			+ "union all "
			+ "select 'extract' as functionType, 'EXTRACT' as family,NVL(complete_count- :ext,0) as count from extract_complete_count ";	

	public final static String muExtractLoadSql = ""
			+ "select me.mu_id as muId ,NVL(me.pressure,0) as pressure from MU_EXTRACT_LOAD me,MATCH_UNITS mu "
			+ "where me.mu_id = mu.mu_id and mu.state ='WORKING'";
	
	public final static String muInquiryLoadSql = ""
			+ "select ml.mu_id as muId ,NVL(ml.pressure,0) as pressure from MU_INQUIRY_LOAD ml,MATCH_UNITS mu "
			+ "where ml.mu_id = mu.mu_id and mu.state ='WORKING'";	
	
	private Object lock = new Object();
	

	@SuppressWarnings("unchecked")
	public List<ComponentStatus> getComponentStatusList() {
		List<ComponentStatus> results = null;
		try {
			EntityManager entityManager = repository.getEntityManager();
			Query query = entityManager.createNativeQuery(ComponentSql);

			query.unwrap(SQLQuery.class)
					.addScalar("componentName", StringType.INSTANCE)
					.addScalar("state", StringType.INSTANCE)
					.addScalar("count", IntegerType.INSTANCE)
					.setResultTransformer(
							Transformers.aliasToBean(ComponentStatus.class));
			results = query.getResultList();
		} catch (Exception e) {
			logger.error(e.getMessage(), e);			
		}
		return results;
	}

	@SuppressWarnings("unchecked")
	public List<DBMonitorData> getDBMonitorList(Integer scopeId) {
		List<DBMonitorData> results = null;
		try {
			EntityManager entityManager = repository.getEntityManager();
			Query query = entityManager.createNativeQuery(databaseSql);
			query.setParameter("scopeId", scopeId);
			query.unwrap(SQLQuery.class)
					.addScalar("function", StringType.INSTANCE)
					.addScalar("templateFormat", StringType.INSTANCE)
					.addScalar("recordCount", IntegerType.INSTANCE)
					.setResultTransformer(
							Transformers.aliasToBean(DBMonitorData.class));
			results = query.getResultList();
		} catch (Exception e) {
			logger.error(e.getMessage(), e);			
		}
		return results;
	}

	@SuppressWarnings("unchecked")
	public  List<TransactionMonitorData> getTransactionMonitorDataList() {
		List<TransactionMonitorData> results = new ArrayList<>();	
		PreviousCompletedJobCounter preJobCounter = PreviousCompletedJobCounter.getInstance();		
		synchronized(lock) {
			 Map<String, Long> preMap = preJobCounter.getPreCompleteJobMap();
		try {
			EntityManager entityManager = repository.getEntityManager();
			Query query = entityManager.createNativeQuery(transactionSql);
			query.setParameter("ti", preMap.get("TI"))	       
	        .setParameter("tli", preMap.get("TLI"))
	        .setParameter("tlip", preMap.get("TLIP"))
	        .setParameter("fi", preMap.get("FI"))
	        .setParameter("ii", preMap.get("II"))
	        .setParameter("li", preMap.get("LI"))
	        .setParameter("lli", preMap.get("LLI"))
	        .setParameter("lip", preMap.get("LIP"))
	        .setParameter("llip", preMap.get("LLIP"))
	        .setParameter("ext", preMap.get("EXTRACT"));	       	        
			query.unwrap(SQLQuery.class)
					.addScalar("functionType", StringType.INSTANCE)
					.addScalar("family", StringType.INSTANCE)
					.addScalar("count", LongType.INSTANCE)
					.setResultTransformer(
							Transformers
									.aliasToBean(TransactionMonitorData.class));
			results = query.getResultList();			
				if (results != null && results.size() >= 0) {
					for (int i = 0; i < results.size(); i++) {
						String tmp = results.get(i).getFamily();
						if (results.get(i).getCount().intValue() >= 0) {
							long value = preMap.get(tmp)
									+ results.get(i).getCount();
							preMap.remove(tmp);
							preMap.put(tmp, new Long(value));
						} else {
							preMap.remove(tmp);
							preMap.put(tmp, new Long(0L));
							results.get(i).setCount(0L);
						}
					}
				}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);			
		}
		return results;
		}
	}
	
	@SuppressWarnings("unchecked")
	public List<MuLoadPojo> getMuInquiryLoadDataList() {
		List<MuLoadPojo> results = null;
		try {
			EntityManager entityManager = repository.getEntityManager();
			Query query = entityManager.createNativeQuery(muInquiryLoadSql);
			query.unwrap(SQLQuery.class)
					.addScalar("muId", LongType.INSTANCE)
					.addScalar("pressure", LongType.INSTANCE)
					.setResultTransformer(
							Transformers.aliasToBean(MuLoadPojo.class));
			results = query.getResultList();

		} catch (Exception e) {
			logger.error(e.getMessage(), e);			
		}
		return results;
	}

	@SuppressWarnings("unchecked")
	public List<MuLoadPojo> getMuExtractLoadDataList() {
		List<MuLoadPojo> results = null;
		try {
			EntityManager entityManager = repository.getEntityManager();
			Query query = entityManager.createNativeQuery(muExtractLoadSql);
			query.unwrap(SQLQuery.class)
					.addScalar("muId", LongType.INSTANCE)
					.addScalar("pressure", LongType.INSTANCE)
					.setResultTransformer(
							Transformers.aliasToBean(MuLoadPojo.class));
			results = query.getResultList();

		} catch (Exception e) {
			logger.error(e.getMessage(), e);			
		}
		return results;
	}	

	public String getSlbStatus() {
		String propertyName = "LOAD_BALANCER.ENABLED";
		SystemConfigEntity sysEntity = systemConfigRepository
				.findByPropertyName(propertyName);
		return sysEntity.getPropertyValue();
	}
}
