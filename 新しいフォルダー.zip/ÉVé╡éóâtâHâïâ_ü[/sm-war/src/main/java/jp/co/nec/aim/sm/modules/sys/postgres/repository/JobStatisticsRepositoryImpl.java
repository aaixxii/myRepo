package jp.co.nec.aim.sm.modules.sys.postgres.repository;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import jp.co.nec.aim.sm.common.constant.CardQualityType;
import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.modules.sys.postgres.entity.JobStatistics;
import jp.co.nec.aim.sm.modules.sys.postgres.pojo.mapping.CardQualityPojo;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * JobJobStatisticsRepository interface
 */
public class JobStatisticsRepositoryImpl {
	/** the log instance **/
	private static Logger logger = LoggerFactory
			.getLogger(JobStatisticsRepositoryImpl.class);

	@Autowired
	private JobStatisticsRepository jobRepository;

	private final String FUNCTION_SQL = "select distinct(\"FUNCTION\") from"
			+ " \"JOB_STATISTICS\" order by \"FUNCTION\"";
	private final String MUID_SQL = "select distinct(\"MU_ID\") as \"muId\""
			+ " from \"JOB_STATISTICS\" order by \"muId\"";

	/**
	 * get Function List from JOB_STATISTICS
	 * 
	 * @return
	 */
	public List<String> getFunctionList() {		
		return jobRepository.findBySql(FUNCTION_SQL);
	}

	/**
	 * get MuId List from JOB_STATISTICS
	 * 
	 * @return
	 */
	public List<Long> getMuIdList() {		
		List<BigDecimal> list = jobRepository.findBySql(MUID_SQL);
		logger.debug("change MuId List from BigDecimal to Long");
		List<Long> longList = new ArrayList<Long>();
		for (int i = 0; i < list.size(); i++) {
			longList.add(list.get(i).longValue());
		}
		return longList;
	}

	/**
	 * get Condition string
	 * 
	 * @param jobStatEntity
	 * @return
	 */
	private String getCondition(JobStatistics jobStatEntity) {
		String condition = "";
		final String startTime = jobStatEntity.getSqlStartTime();
		if (StringUtils.isNotEmpty(startTime)) {
			condition += " AND \"START_TIME\" >= (timestamp '" + startTime
					+ "') ";
		}

		final String endTime = jobStatEntity.getSqlEndTime();
		if (StringUtils.isNotEmpty(endTime)) {
			condition += " AND \"START_TIME\" <= (timestamp '" + endTime
					+ ".999') ";
		}

		final String muIds = jobStatEntity.getMuIdList();
		if (StringUtils.isNotEmpty(muIds)) {
			condition += " AND \"MU_ID\" in (" + muIds + ") ";
		}

		final String functions = jobStatEntity.getFunction();
		if (StringUtils.isNotEmpty(functions)) {
			condition += " AND \"FUNCTION\" in ('";
			String[] funArray = functions.split(",");
			for (int i = 0; i < funArray.length; i++) {
				if (i == 0) {
					condition += funArray[i];
				} else {
					condition += "','" + funArray[i];
				}
			}
			condition += "') ";
		}		
		return condition;
	}

	/**
	 * get Unit Job AMR Sql string
	 * 
	 * @param jobStatEntity
	 * @return
	 */
	private String getUnitJobAMRSql(JobStatistics jobStatEntity) {
		String job_amr_sql = "select * from \"JOB_STATISTICS\" "
				+ " where \"FUNCTION\" <> 'EXTRACT'";

		job_amr_sql += getCondition(jobStatEntity);

		job_amr_sql += " order by \"MU_ID\"";		
		return job_amr_sql;
	}

	/**
	 * get data from JOB_STATISTICS for Unit Job AMR
	 * 
	 * @param page
	 * @param jobStatEntity
	 * @return
	 */
	public Page<JobStatistics> getUnitJobAMR(Page<JobStatistics> page,
			JobStatistics jobStatEntity) {
		String sql = getUnitJobAMRSql(jobStatEntity);		
		return jobRepository.findBySql(page, sql, JobStatistics.class);
	}

	/**
	 * get data from JOB_STATISTICS for Unit Job AMR
	 * 
	 * @param jobStatEntity
	 * @return
	 */
	public List<JobStatistics> getUnitJobAMR(JobStatistics jobStatEntity) {
		String sql = getUnitJobAMRSql(jobStatEntity);		
		return jobRepository.findBySql(sql, JobStatistics.class);
	}

	/**
	 * get Unit Job Elapse Sql string
	 * 
	 * @param jobStatEntity
	 * @return
	 */
	private String getUnitJobElapseSql(JobStatistics jobStatEntity) {
		String job_elapse_sql = "select * from \"JOB_STATISTICS\" "
				+ " where 1 = 1";

		job_elapse_sql += getCondition(jobStatEntity);

		job_elapse_sql += " order by \"MU_ID\"";		
		return job_elapse_sql;
	}

	/**
	 * get data from JOB_STATISTICS for Unit Job Elapse
	 * 
	 * @param page
	 * @param jobStatEntity
	 * @return
	 */
	public Page<JobStatistics> getUnitJobElapse(Page<JobStatistics> page,
			JobStatistics jobStatEntity) {
		String sql = getUnitJobElapseSql(jobStatEntity);		
		return jobRepository.findBySql(page, sql, JobStatistics.class);
	}

	/**
	 * get data from JOB_STATISTICS for Unit Job Elapse
	 * 
	 * @param jobStatEntity
	 * @return
	 */
	public List<JobStatistics> getUnitJobElapse(JobStatistics jobStatEntity) {
		String sql = getUnitJobElapseSql(jobStatEntity);		
		return jobRepository.findBySql(sql, JobStatistics.class);
	}

	/**
	 * get Card Quality Sql String
	 * 
	 * @param jobStatEntity
	 * @param type
	 * @return
	 */
	private String getCardQualitySql(JobStatistics jobStatEntity,
			CardQualityType type) {
		String card_quality_sql = "select \"CARD_QUALITY_TYPE\" as \"qualityType\", "
				+ "sum(\"CARD_QUALITY_UNDER_100\") AS \"count100\", "
				+ "sum(\"CARD_QUALITY_UNDER_200\") AS \"count200\", "
				+ "sum(\"CARD_QUALITY_UNDER_300\") AS \"count300\", "
				+ "sum(\"CARD_QUALITY_UNDER_400\") AS \"count400\", "
				+ "sum(\"CARD_QUALITY_UNDER_500\") AS \"count500\", "
				+ "sum(\"CARD_QUALITY_UNDER_600\") AS \"count600\", "
				+ "sum(\"CARD_QUALITY_UNDER_700\") AS \"count700\", "
				+ "sum(\"CARD_QUALITY_UNDER_800\") AS \"count800\" "
				+ "from \"JOB_STATISTICS\" "
				+ "where \"CARD_QUALITY_TYPE\" != '' ";

		if (type == CardQualityType.Roll) {
			card_quality_sql += " and (\"CARD_QUALITY_TYPE\" = 'ROLL' or"
					+ " \"CARD_QUALITY_TYPE\" = 'Roll') ";
		} else if (type == CardQualityType.Slap) {
			card_quality_sql += " and (\"CARD_QUALITY_TYPE\" = 'SLAP' or"
					+ " \"CARD_QUALITY_TYPE\" = 'Slap') ";
		}
		card_quality_sql += getCondition(jobStatEntity);
		card_quality_sql += " group by \"CARD_QUALITY_TYPE\""
				+ " order by \"CARD_QUALITY_TYPE\"";
		
		return card_quality_sql;
	}

	/**
	 * get qualityType(Roll), card quality data from JOB_STATISTICS
	 * 
	 * @param page
	 * @param jobStatEntity
	 * @return
	 */
	public Page<CardQualityPojo> getCardQualityRoll(Page<CardQualityPojo> page,
			JobStatistics jobStatEntity) {
		String sql = getCardQualitySql(jobStatEntity, CardQualityType.Roll);		
		return jobRepository.findBySql(page, sql, CardQualityPojo.class);
	}

	/**
	 * get qualityType(Roll), card quality data from JOB_STATISTICS
	 * 
	 * @param jobStatEntity
	 * @return
	 */
	public List<CardQualityPojo> getCardQualityRoll(JobStatistics jobStatEntity) {
		String sql = getCardQualitySql(jobStatEntity, CardQualityType.Roll);		
		return jobRepository.findBySql(sql, CardQualityPojo.class);
	}

	/**
	 * get qualityType(Slap), card quality data from JOB_STATISTICS
	 * 
	 * @param page
	 * @param jobStatEntity
	 * @return
	 */
	public Page<CardQualityPojo> getCardQualitySlap(Page<CardQualityPojo> page,
			JobStatistics jobStatEntity) {
		String sql = getCardQualitySql(jobStatEntity, CardQualityType.Slap);		
		return jobRepository.findBySql(page, sql, CardQualityPojo.class);
	}

	/**
	 * get qualityType(Slap), card quality data from JOB_STATISTICS
	 * 
	 * @param jobStatEntity
	 * @return
	 */
	public List<CardQualityPojo> getCardQualitySlap(JobStatistics jobStatEntity) {
		String sql = getCardQualitySql(jobStatEntity, CardQualityType.Slap);		
		return jobRepository.findBySql(sql, CardQualityPojo.class);
	}

	/**
	 * get qualityType(All), card quality data from JOB_STATISTICS
	 * 
	 * @param page
	 * @param jobStatEntity
	 * @return
	 */
	public Page<CardQualityPojo> getCardQuality(Page<CardQualityPojo> page,
			JobStatistics jobStatEntity) {
		String sql = getCardQualitySql(jobStatEntity, CardQualityType.All);		
		return jobRepository.findBySql(page, sql, CardQualityPojo.class);
	}

	/**
	 * get qualityType(All), card quality data from JOB_STATISTICS
	 * 
	 * @param jobStatEntity
	 * @return
	 */
	public List<CardQualityPojo> getCardQuality(JobStatistics jobStatEntity) {
		String sql = getCardQualitySql(jobStatEntity, CardQualityType.All);		
		return jobRepository.findBySql(sql, CardQualityPojo.class);
	}

}
