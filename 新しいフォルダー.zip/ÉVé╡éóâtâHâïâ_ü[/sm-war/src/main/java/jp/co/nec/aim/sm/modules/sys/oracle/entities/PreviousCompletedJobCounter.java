package jp.co.nec.aim.sm.modules.sys.oracle.entities;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class PreviousCompletedJobCounter {
	public static final ConcurrentHashMap<String , Long> preCompleteJobMap = new ConcurrentHashMap<String , Long>();
	private static final PreviousCompletedJobCounter INSTANCE = new PreviousCompletedJobCounter();
	
	public PreviousCompletedJobCounter() {		
		initMap();
	}
	public static PreviousCompletedJobCounter getInstance() {
		if (preCompleteJobMap == null || preCompleteJobMap.size() == 0) {
			initMap();
		}
		return INSTANCE;		
	}
	
	private static void initMap() {
		preCompleteJobMap.put("TI", 0L);
		preCompleteJobMap.put("LI", 0L);
		preCompleteJobMap.put("TLI", 0L);
		preCompleteJobMap.put("LLI", 0L);
		preCompleteJobMap.put("LIP", 0L);
		preCompleteJobMap.put("TLIP", 0L);
		preCompleteJobMap.put("LLIP", 0L);
		preCompleteJobMap.put("FI", 0L);
		preCompleteJobMap.put("II", 0L);
		preCompleteJobMap.put("EXTRACT", 0L);
	}
	
	public synchronized Map<String , Long>  getPreCompleteJobMap() {
		if (preCompleteJobMap == null || preCompleteJobMap.size() == 0) {
			initMap();
		}
		return preCompleteJobMap;		
	}
}
