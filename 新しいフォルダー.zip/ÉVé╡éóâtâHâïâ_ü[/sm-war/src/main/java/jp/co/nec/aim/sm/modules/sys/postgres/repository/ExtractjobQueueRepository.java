package jp.co.nec.aim.sm.modules.sys.postgres.repository;

import jp.co.nec.aim.sm.common.persistence.BaseRepository;
import jp.co.nec.aim.sm.modules.sys.postgres.entity.ExtractJobQueueEntity;

/**
 * ExtractjobQueueRepository interface
 */
public interface ExtractjobQueueRepository extends
		BaseRepository<ExtractJobQueueEntity, String> {

}
