package jp.co.nec.aim.sm.exception;

public class SMSecurityException extends RuntimeException {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -335026656751093927L;

	/**
	 * @param message
	 */
	public SMSecurityException(String message) {
		super(message);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public SMSecurityException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * @param cause
	 */
	public SMSecurityException(Throwable cause) {
		super(cause);
	}
}
