package jp.co.nec.aim.sm.common.utils;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.concurrent.ConcurrentLinkedQueue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CmdUtils {
	private static Logger logger = LoggerFactory.getLogger(CmdUtils.class);
	private static boolean isWindowsOS = isWindowsOS();
	private static boolean isRunning = false;
	private static boolean isDeleteAll = false;
	private static int waitTime = 60000;
	private static ConcurrentLinkedQueue<DeleteFileInfo> queue = new ConcurrentLinkedQueue<DeleteFileInfo>();

	public static void DeleteFile(String fileName) {
		DeleteFileInfo newInfo = new DeleteFileInfo(fileName);
		synchronized (queue) {
			if (queue.isEmpty()) {
				queue.add(newInfo);
			} else {
				queue.add(newInfo);
				return;
			}
		}

		Thread thread = new Thread() {
			@Override
			public void run() {
				boolean isEmpty = true;
				isRunning = true;
				do {
					DeleteFileInfo info = queue.peek();

					try {
						while (info.time + waitTime > new Date().getTime()) {
							Thread.sleep(100);
						}
					} catch (InterruptedException e) {
						logger.error("InterruptedException when deleting file",
								e);
					}

					if (isDeleteAll) {
						break;
					}

					logger.debug("deleting file: " + info.fileName);
					ExecCmd(info.fileName);

					synchronized (queue) {
						queue.poll();
						isEmpty = queue.isEmpty();
					}
				} while (!isEmpty);
				isRunning = false;
			}
		};

		thread.start();
	}

	public static void DeleteAll(String path) {
		waitTime = 0;
		isDeleteAll = true;

		while (isRunning) {
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				logger.error("InterruptedException when deleting file", e);
			}
		}

		String cmdPath = path;
		if (!cmdPath.endsWith(File.separator)) {
			cmdPath = cmdPath + File.separator;
		}
		cmdPath = cmdPath + "static" + File.separator + "reportPNG"
				+ File.separator + "*.png";

		ExecCmd(cmdPath);
	}

	/**
	 * exec a cmd with wildcard.
	 * 
	 * @param cmd
	 */
	public static void ExecCmd(String cmdfile) {
		String cmd;
		String[] commands = new String[3];
		if (isWindowsOS) {
			commands[0] = "cmd";
			commands[1] = "/c";
			cmd = "del /f \"" + cmdfile + "\"";
			commands[2] = cmd;
		} else {
			cmdfile.replace(" ", "\\ ");
			commands[0] = "/bin/sh";
			commands[1] = "-c";
			cmd = "rm -f " + cmdfile;
			commands[2] = cmd;
		}

		Process ps = null;
		Runtime rt = Runtime.getRuntime();
		try {
			ps = rt.exec(commands);
			int status = ps.waitFor();
			if (status == 0) {
				logger.debug(cmd + ": run successful.");
			} else {
				logger.error(cmd + ": run failed.");
			}
		} catch (IOException e) {
			logger.error("IOException occurred.", e);
		} catch (InterruptedException e) {
			logger.error("InterruptedException occurred.", e);
		}
		if (ps != null) {
			ps.destroy();
			ps = null;
		}
		return;
	}

	private static boolean isWindowsOS() {
		boolean isWindowsOS = false;
		String osName = System.getProperty("os.name");
		if (osName.toLowerCase().indexOf("windows") > -1) {
			isWindowsOS = true;
		}
		return isWindowsOS;
	}

	public static void setWaitTime(int milliSecond) {
		waitTime = milliSecond;
	}
}

class DeleteFileInfo {
	long time = new Date().getTime();
	String fileName;

	public DeleteFileInfo(String fileName) {
		this.fileName = fileName;
	}
}
