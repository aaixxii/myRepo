package jp.co.nec.aim.sm.common.utils;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import org.springframework.core.io.Resource;

public class ConfigReader {
	/**
	 * iniファイル参照
	 */
	private LinkedHashMap<String, LinkedHashMap<String, List<String>>> map = null;
	/**
	 * 現在のセクションを参照する
	 */
	private String currentSection = null;

	/**
	 * リード
	 * 
	 * @param path
	 */
	public ConfigReader(Resource resource) {
		map = new LinkedHashMap<String, LinkedHashMap<String, List<String>>>();
		try {
			BufferedReader reader = new BufferedReader(new FileReader(resource.getFile()));
			read(reader);
		} catch (IOException e) {
			e.printStackTrace();
			throw new RuntimeException("IO Exception:" + e);
		}

	}

	/**
	 * リードファイル
	 * 
	 * @param reader
	 * @throws IOException
	 */
	private void read(BufferedReader reader) throws IOException {
		String line = null;
		while ((line = reader.readLine()) != null) {
			parseLine(line);
		}
	}

	/**
	 * 変換
	 * 
	 * @param line
	 */
	private void parseLine(String line) {
		line = line.trim();
		// コメント
		if (line.matches("^\\#.*$")) {
			return;
		} else if (line.matches("^\\[\\S+\\]$")) {
			// section
			String section = line.replaceFirst("^\\[(\\S+)\\]$", "$1");
			addSection(map, section);
		} else if (line.matches("^\\S+=.*$")) {
			// key ,value
			int i = line.indexOf("=");
			String key = line.substring(0, i).trim();
			String value = line.substring(i + 1).trim();
			addKeyValue(map, currentSection, key, value);
		}
	}

	/**
	 * 新しいキーと値を追加する
	 * 
	 * @param map
	 * @param currentSection
	 * @param key
	 * @param value
	 */
	private void addKeyValue(
			LinkedHashMap<String, LinkedHashMap<String, List<String>>> map,
			String currentSection, String key, String value) {
		if (!map.containsKey(currentSection)) {
			return;
		}

		LinkedHashMap<String, List<String>> childMap = map.get(currentSection);

		if (!childMap.containsKey(key)) {
			List<String> list = new ArrayList<String>();
			list.add(value);
			childMap.put(key, list);
		} else {
			childMap.get(key).add(value);
		}
	}

	/**
	 * 新しいセクションを追加する
	 * 
	 * @param map
	 * @param section
	 */
	private void addSection(
			LinkedHashMap<String, LinkedHashMap<String, List<String>>> map,
			String section) {
		if (!map.containsKey(section)) {
			currentSection = section;
			LinkedHashMap<String, List<String>> childMap = new LinkedHashMap<String, List<String>>();
			map.put(section, childMap);
		}
	}

	/**
	 * セクションおよびサブキーを指定する
	 * 
	 * @param section
	 * @param key
	 * @return
	 */
	public List<String> get(String section, String key) {
		if (map.containsKey(section)) {
			return get(section).containsKey(key) ? get(section).get(key) : null;
		}
		return null;
	}

	/**
	 * セクションのサブ·キーと値を指定する
	 * 
	 * @param section
	 * @return
	 */
	public LinkedHashMap<String, List<String>> get(String section) {
		return map.containsKey(section) ? map.get(section) : null;
	}

	/**
	 * iniファイルの値を取得します
	 * 
	 * @return
	 */
	public LinkedHashMap<String, LinkedHashMap<String, List<String>>> get() {
		return map;
	}
}
