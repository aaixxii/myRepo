/**
 * Licensed under the Apache License, Version 2.0 (the "License");
 */
package jp.co.nec.aim.sm.modules.sys.util;

import java.util.List;
import java.util.Map;

import jp.co.nec.aim.sm.common.utils.SpringContextHolder;
import jp.co.nec.aim.sm.modules.sys.postgres.entity.MenuEntity;
import jp.co.nec.aim.sm.modules.sys.postgres.entity.UserEntity;
import jp.co.nec.aim.sm.modules.sys.postgres.repository.UserRepository;
import jp.co.nec.aim.sm.modules.sys.security.SystemAuthorizingRealm.Principal;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.UnavailableSecurityManagerException;
import org.apache.shiro.subject.Subject;

import com.google.common.collect.Maps;

/**
 * the user utility class
 */
public class UserUtils {

	/** the user Repository **/
	private static UserRepository userRepository = SpringContextHolder
			.getBean(UserRepository.class);

	/** the user cache name **/
	public static final String CACHE_USER = "user";
	/** the menu cache name **/
	public static final String CACHE_MENU_LIST = "menuList";

	/**
	 * get user from database if cache not exist
	 * 
	 * @return the userEntity instance
	 */
	public static UserEntity getUser() {
		UserEntity user = (UserEntity) getCache(CACHE_USER);
		if (user == null) {
			Principal principal = (Principal) SecurityUtils.getSubject()
					.getPrincipal();
			if (principal != null) {
				user = userRepository.findOne(principal.getId());
				putCache(CACHE_USER, user);
			}
		}
		if (user == null) {
			user = new UserEntity();
			SecurityUtils.getSubject().logout();
		}
		return user;
	}

	/**
	 * remove the cache if flag isRefresh is true <br>
	 * then get the user instance
	 * 
	 * @param isRefresh
	 *            is Refresh flag
	 * @return the UserEntity instance
	 */
	public static UserEntity getUser(boolean isRefresh) {
		if (isRefresh) {
			removeCache(CACHE_USER);
		}
		return getUser();
	}

	/**
	 * get menu from database if cache not exist
	 * 
	 * @return the list of menu
	 */
	public static List<MenuEntity> getMenuList() {
		@SuppressWarnings("unchecked")
		List<MenuEntity> menuList = (List<MenuEntity>) getCache(CACHE_MENU_LIST);
		if (menuList == null) {
			UserEntity user = getUser();
			// if (user.isAdmin()) {
			menuList = MenuUtils.getMenuList(user.getRoleNames());
			// } /*else {
			// menuList = menuRepository.findByUserId(user.getId());
			// }*/
			putCache(CACHE_MENU_LIST, menuList);
		}
		return menuList;
	}

	// ============== User Cache ==============

	public static Object getCache(String key) {
		return getCache(key, null);
	}

	public static Object getCache(String key, Object defaultValue) {
		Object obj = getCacheMap().get(key);
		return obj == null ? defaultValue : obj;
	}

	public static void putCache(String key, Object value) {
		getCacheMap().put(key, value);
	}

	public static void removeCache(String key) {
		getCacheMap().remove(key);
	}

	public static Map<String, Object> getCacheMap() {
		Map<String, Object> map = Maps.newHashMap();
		try {
			Subject subject = SecurityUtils.getSubject();
			Principal principal = (Principal) subject.getPrincipal();
			return principal != null ? principal.getCacheMap() : map;
		} catch (UnavailableSecurityManagerException e) {
			return map;
		}
	}
}
