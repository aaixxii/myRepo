package jp.co.nec.aim.sm.modules.sys.oracle.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import jp.co.nec.aim.sm.common.constant.JobState;

/**
 * The persistent class for the CONTAINER_JOBS database table.
 * 
 */
@Entity
@Table(name = "CONTAINER_JOBS")
public class ContainerJobEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "container_jobs_generator", sequenceName = "CONTAINER_JOB_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "container_jobs_generator")
	@Column(name = "CONTAINER_JOB_ID")
	private long containerJobId;

	@Column(name = "ASSIGNED_TS")
	private Long assignedTs;

	@Column(name = "CONTAINER_ID")
	private int containerId;

	@Column(name = "CONTAINER_JOB_RESULT")
	private byte[] containerJobResult;

	@Column(name = "FUSION_JOB_ID")
	private long fusionJobId;

	@Column(name = "JOB_STATE")
	@Enumerated(EnumType.ORDINAL)
	private JobState jobState;

	@Column(name = "MR_ID")
	private Long mrId;

	@Column(name = "PLAN_ID")
	private Long planId;

	@Column(name = "RESULT_TS")
	private Long resultTs;

	public ContainerJobEntity() {
	}

	public long getContainerJobId() {
		return containerJobId;
	}

	public void setContainerJobId(long containerJobId) {
		this.containerJobId = containerJobId;
	}

	public Long getAssignedTs() {
		return assignedTs;
	}

	public void setAssignedTs(Long assignedTs) {
		this.assignedTs = assignedTs;
	}

	public int getContainerId() {
		return containerId;
	}

	public void setContainerId(int containerId) {
		this.containerId = containerId;
	}

	public byte[] getContainerJobResult() {
		return containerJobResult;
	}

	public void setContainerJobResult(byte[] containerJobResult) {
		this.containerJobResult = containerJobResult;
	}

	public long getFusionJobId() {
		return fusionJobId;
	}

	public void setFusionJobId(long fusionJobId) {
		this.fusionJobId = fusionJobId;
	}

	public JobState getJobState() {
		return jobState;
	}

	public void setJobState(JobState jobState) {
		this.jobState = jobState;
	}

	public Long getMrId() {
		return mrId;
	}

	public void setMrId(Long mrId) {
		this.mrId = mrId;
	}

	public Long getPlanId() {
		return planId;
	}

	public void setPlanId(Long planId) {
		this.planId = planId;
	}

	public Long getResultTs() {
		return resultTs;
	}

	public void setResultTs(Long resultTs) {
		this.resultTs = resultTs;
	}

}