package jp.co.nec.aim.sm.common.constant;

public enum SegmentAllocationAction {
	Allocation,DeAllocation
}
