package jp.co.nec.aim.sm.modules.sys.postgres.pojo.mapping;

import java.io.Serializable;

import jp.co.nec.aim.sm.common.annocation.FieldMapped;
import jp.co.nec.aim.sm.common.annocation.InquiryMapping;

@InquiryMapping
public class UserFrequencyPojo implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -4820367917880397249L;

	public UserFrequencyPojo() {

	}

	public UserFrequencyPojo(String userName, Integer loginFrequency) {
		this.userName = userName;
		this.loginFrequency = loginFrequency;
	}

	@FieldMapped
	private String userName;

	@FieldMapped
	private Integer loginFrequency;

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserName() {
		return userName;
	}

	public void setLoginFrequency(Integer loginFrequency) {
		this.loginFrequency = loginFrequency;
	}

	public Integer getLoginFrequency() {
		return loginFrequency;
	}

}
