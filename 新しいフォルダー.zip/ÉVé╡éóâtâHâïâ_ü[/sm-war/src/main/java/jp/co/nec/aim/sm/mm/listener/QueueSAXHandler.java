package jp.co.nec.aim.sm.mm.listener;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import jp.co.nec.aim.sm.common.properties.MMProperties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

/**
 * 
 * 
 */
public class QueueSAXHandler {
	private static Logger log = LoggerFactory.getLogger(QueueSAXHandler.class);
	private QueueInformation qinfo = new QueueInformation();
	private List<QueueInformation> lstQueues = new ArrayList<QueueInformation>();
	Document dom;

	public List<QueueInformation> getListQueues() {
		return lstQueues;
	}

	public void parse(InputSource is) {
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

		try {
			DocumentBuilder db = dbf.newDocumentBuilder();
			dom = db.parse(is);
			parseDocument();
		} catch (ParserConfigurationException pce) {
			pce.printStackTrace();
		} catch (SAXException se) {
			se.printStackTrace();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}

	private void parseDocument() {
		Element docEle = dom.getDocumentElement();
		NodeList nl = docEle.getElementsByTagName("queue");
		if (nl != null && nl.getLength() > 0) {
			for (int i = 0; i < nl.getLength(); i++) {
				Element el = (Element) nl.item(i);
				qinfo = new QueueInformation();
				loadQueues(el);
				lstQueues.add(qinfo);
			}
		}
	}

	private void loadQueues(Element empEl) {

		log.info("->loadQueues()");
		StringBuffer buff = new StringBuffer();
		String queueId = getTextValue(empEl, "queue-id");
		qinfo.setQueueID(queueId);
		buff.append(" Queue ID : " + queueId);

		String queueName = getTextValue(empEl, "queue-name");
		qinfo.setQueueName(queueName);
		buff.append(" queueName : " + queueName);

		String queueType = getTextValue(empEl, "queue-type");
		qinfo.setQueueType(queueType);
		buff.append(" queueType : " + queueType);

		String queueProtocol = getTextValue(empEl, "queue-protocol");
		qinfo.setQueueProtocol(queueProtocol);
		buff.append(" queueProtocol : " + queueProtocol);

		String queueHostname = getTextValue(empEl, "queue-hostname");
		if (queueHostname == null || queueHostname.isEmpty()) {
			queueHostname = MMProperties.getMMIp();
		}
		qinfo.setQueueHostname(queueHostname);
		buff.append(" queueHostname : " + queueHostname);

		String queuePort = getTextValue(empEl, "queue-port");
		qinfo.setQueuePort(Integer.parseInt(queuePort));
		buff.append(" queuePort : " + queuePort);

		String queueReattempt = getTextValue(empEl, "queue-reattempt");
		qinfo.setReattemptCount(Integer.parseInt(queueReattempt));
		buff.append(" queueReattempt : " + queueReattempt);

		String queueReattemptRunCount = getTextValue(empEl,
				"queue-reattempt-run-count");
		qinfo.setReattemptRunCount(qinfo.getReattemptCount());
		buff.append(" queueReattemptRunCount : " + queueReattemptRunCount);

		String queueTimeout = getTextValue(empEl, "queue-timeout");
		qinfo.setTimeout(Integer.parseInt(queueTimeout));
		buff.append(" queueTimeout : " + queueTimeout);

		String queueUserName = getTextValue(empEl, "queue-username");
		qinfo.setUserName(queueUserName);
		buff.append(" queueUserName : " + queueUserName);

		String queuePassword = getTextValue(empEl, "queue-password");
		qinfo.setPassword(queuePassword);
		buff.append(" queuePassword : " + queuePassword);

		log.info("#loadQueues() queue information " + buff.toString());
		log.info("<-loadQueues()");
	}

	private String getTextValue(Element ele, String tagName) {
		String textVal = null;
		NodeList nl = ele.getElementsByTagName(tagName);
		if ((nl.item(0) != null) && (nl.item(0).getFirstChild() != null)) {
			textVal = nl.item(0).getFirstChild().getNodeValue();
		}
		return textVal;
	}
}
