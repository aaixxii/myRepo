package jp.co.nec.aim.sm.modules.sys.oracle.entities;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import jp.co.nec.aim.sm.common.constant.UnitState;

/**
 * The persistent class for the DATA_MANAGERS database table.
 * 
 */
@Entity
@Table(name = "DATA_MANAGERS")
public class DataManagerEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "data_managers_generator", sequenceName = "SERVER_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "data_managers_generator")
	@Column(name = "DM_ID")
	private long dmId;

	@Column(name = "CONTACT_URL")
	private String contactUrl;

	@Column(name = "\"STATE\"")
	@Enumerated(EnumType.STRING)
	private UnitState state;

	@Column(name = "UNIQUE_ID")
	private String uniqueId;

	@Column(name = "\"VERSION\"")
	private String version;

	@OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name = "DM_ID")
	private DmContactEntity times;

	public DataManagerEntity() {
	}

	public long getDmId() {
		return this.dmId;
	}

	public void setDmId(long dmId) {
		this.dmId = dmId;
	}

	public String getContactUrl() {
		return this.contactUrl;
	}

	public void setContactUrl(String contactUrl) {
		this.contactUrl = contactUrl;
	}

	public UnitState getState() {
		return state;
	}

	public void setState(UnitState state) {
		this.state = state;
	}

	public String getUniqueId() {
		return this.uniqueId;
	}

	public void setUniqueId(String uniqueId) {
		this.uniqueId = uniqueId;
	}

	public String getVersion() {
		return this.version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public DmContactEntity getTimes() {
		return times;
	}

	public void setTimes(DmContactEntity times) {
		this.times = times;
	}

}