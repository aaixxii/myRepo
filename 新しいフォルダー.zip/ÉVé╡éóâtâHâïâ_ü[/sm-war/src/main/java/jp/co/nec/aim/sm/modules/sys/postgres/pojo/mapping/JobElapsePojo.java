package jp.co.nec.aim.sm.modules.sys.postgres.pojo.mapping;

import java.io.Serializable;

import jp.co.nec.aim.sm.common.annocation.FieldMapped;
import jp.co.nec.aim.sm.common.annocation.InquiryMapping;

@InquiryMapping
public class JobElapsePojo implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 2678652351511217828L;

	@FieldMapped
	private String functionName;

	@FieldMapped
	private Long jobCountSum;

	@FieldMapped
	private Long hitCountSum;

	@FieldMapped
	private Long failedCountSum;

	@FieldMapped
	private String elapseMin;

	@FieldMapped
	private String elapseAvg;

	@FieldMapped
	private String elapseMax;

	public void setFunctionName(String functionName) {
		this.functionName = functionName;
	}

	public String getFunctionName() {
		return functionName;
	}

	public void setJobCountSum(Long jobCountSum) {
		this.jobCountSum = jobCountSum;
	}

	public Long getJobCountSum() {
		return jobCountSum;
	}

	public void setHitCountSum(Long hitCountSum) {
		this.hitCountSum = hitCountSum;
	}

	public Long getHitCountSum() {
		return hitCountSum;
	}

	public void setFailedCountSum(Long failedCountSum) {
		this.failedCountSum = failedCountSum;
	}

	public Long getFailedCountSum() {
		return failedCountSum;
	}

	public void setElapseMin(String elapseMin) {
		this.elapseMin = elapseMin;
	}

	public String getElapseMin() {
		return elapseMin;
	}

	public void setElapseAvg(String elapseAvg) {
		this.elapseAvg = elapseAvg;
	}

	public String getElapseAvg() {
		return elapseAvg;
	}

	public void setElapseMax(String elapseMax) {
		this.elapseMax = elapseMax;
	}

	public String getElapseMax() {
		return elapseMax;
	}
}
