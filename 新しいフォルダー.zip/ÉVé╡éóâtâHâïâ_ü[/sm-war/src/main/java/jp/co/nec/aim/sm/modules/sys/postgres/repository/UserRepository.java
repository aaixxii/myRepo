package jp.co.nec.aim.sm.modules.sys.postgres.repository;

import java.util.Date;

import jp.co.nec.aim.sm.common.persistence.BaseRepository;
import jp.co.nec.aim.sm.modules.sys.postgres.entity.UserEntity;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

/**
 * UserRepository interface
 */
public interface UserRepository extends BaseRepository<UserEntity, Long> {
	@Query("from UserEntity where loginName = ?1")
	public UserEntity findByLoginName(String loginName);

	@Modifying
	@Query("update UserEntity set loginIp=?1, loginDate=?2 where id = ?3")
	public int updateLoginInfo(String loginIp, Date loginDate, Long id);

	@Modifying
	@Query("delete from UserEntity where id = ?1")
	public int deleteById(Long id);

	@Modifying
	@Query("update UserEntity set password=?1 where id = ?2")
	public int updatePasswordById(String newPassword, Long id);
}
