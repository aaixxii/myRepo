package jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping;

import jp.co.nec.aim.sm.common.annocation.FieldMapped;
import jp.co.nec.aim.sm.common.annocation.InquiryMapping;
import jp.co.nec.aim.sm.common.constant.SegmentReportState;

@InquiryMapping
public class DmAsignedSegmentReport {
	@FieldMapped
	private Long segmentId;
	@FieldMapped
	private Long containerId;
	@FieldMapped
	private Long bioIdStart;
	@FieldMapped
	private Long bioIdEnd;
	@FieldMapped
	private Integer binaryLengthCompacted;
	@FieldMapped
	private Integer recordCount;
	@FieldMapped
	private Integer version;
	@FieldMapped
	private Integer binaryLengthUncompacted;
	@FieldMapped
	private Long dmId;
	@FieldMapped
	private Integer status;
	@FieldMapped
	private Integer segmentVersion;

	public Long getSegmentId() {
		return segmentId;
	}

	public void setSegmentId(Long segmentId) {
		this.segmentId = segmentId;
	}
	

	public Long getContainerId() {
		return containerId;
	}

	public void setContainerId(Long containerId) {
		this.containerId = containerId;
	}

	public Long getBioIdStart() {
		return bioIdStart;
	}

	public void setBioIdStart(Long bioIdStart) {
		this.bioIdStart = bioIdStart;
	}

	public Long getBioIdEnd() {
		return bioIdEnd;
	}

	public void setBioIdEnd(Long bioIdEnd) {
		this.bioIdEnd = bioIdEnd;
	}

	public Integer getBinaryLengthCompacted() {
		return binaryLengthCompacted;
	}

	public void setBinaryLengthCompacted(Integer binaryLengthCompacted) {
		this.binaryLengthCompacted = binaryLengthCompacted;
	}

	public Integer getRecordCount() {
		return recordCount;
	}

	public void setRecordCount(Integer recordCount) {
		this.recordCount = recordCount;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	public Integer getBinaryLengthUncompacted() {
		return binaryLengthUncompacted;
	}

	public void setBinaryLengthUncompacted(Integer binaryLengthUncompacted) {
		this.binaryLengthUncompacted = binaryLengthUncompacted;
	}

	public Long getManagedUnitId() {
		return dmId;
	}

	public void setManagedUnitId(Long dmId) {
		this.dmId = dmId;
	}

	public String getStatus() {
		SegmentReportState segmentReportState = SegmentReportState.values()[status];
		return segmentReportState.name();
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Integer getSegmentVersion() {
		return segmentVersion;
	}

	public void setSegmentVersion(Integer segmentVersion) {
		this.segmentVersion = segmentVersion;
	}

}
