package jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping;

import java.util.Date;

import jp.co.nec.aim.sm.common.annocation.FieldMapped;
import jp.co.nec.aim.sm.common.annocation.InquiryMapping;
import jp.co.nec.aim.sm.common.utils.DateUtils;

import org.apache.commons.lang3.StringUtils;

@InquiryMapping
public class MatchUnitUnionMatchUnitContact {

	@FieldMapped
	private Long muId;

	@FieldMapped
	private String uniqueId;

	@FieldMapped
	private String contactURL;

	@FieldMapped
	private String state;

	@FieldMapped
	private String type;

	@FieldMapped
	private Long primarySize;

	@FieldMapped
	private Long secondarySize;

	@FieldMapped
	private Double reportedPerformanceFactor;

	@FieldMapped
	private Integer numberOfExtractors;

	@FieldMapped
	private Integer numberOfMatchers;

	@FieldMapped
	private String version;

	@FieldMapped
	private Long contact_ts;

	public void setVersion(String version) {
		this.version = version;
	}

	public String getContactURL() {
		return contactURL;
	}

	public void setContactURL(String contactURL) {
		this.contactURL = contactURL;
	}

	public Long getPrimarySize() {
		return primarySize;
	}

	public Double getReportedPerformanceFactor() {
		return reportedPerformanceFactor;
	}

	public Long getSecondarySize() {
		return secondarySize;
	}

	public String getState() {
		return state;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getUniqueId() {
		return uniqueId;
	}

	public void setUniqueId(String uniqueId) {
		this.uniqueId = uniqueId;
	}

	/**
	 * @return the version
	 */
	public String getVersion() {
		return version;
	}

	/**
	 * @param state
	 *            The state to set.
	 */
	public void setState(String state) {
		this.state = state;
	}

	public void setPrimarySize(Long primarySize) {
		this.primarySize = primarySize;
	}

	public void setSecondarySize(Long secondarySize) {
		this.secondarySize = secondarySize;
	}

	public void setReportedPerformanceFactor(Double reportedPerformanceFactor) {
		this.reportedPerformanceFactor = reportedPerformanceFactor;
	}

	public Long getMuId() {
		return muId;
	}

	public void setMuId(Long muId) {
		this.muId = muId;
	}

	public Integer getNumberOfExtractors() {
		return numberOfExtractors;
	}

	public void setNumberOfExtractors(Integer numberOfExtractors) {
		this.numberOfExtractors = numberOfExtractors;
	}

	public Integer getNumberOfMatchers() {
		return numberOfMatchers;
	}

	public void setNumberOfMatchers(Integer numberOfMatchers) {
		this.numberOfMatchers = numberOfMatchers;
	}

	public String getContact_ts() {
		if (null == contact_ts) {
			return StringUtils.EMPTY;
		}

		return DateUtils.formatDate(new Date(contact_ts),
				new Object[] { "yyyy-MM-dd HH:mm:ss" });
	}

	public void setContact_ts(Long contact_ts) {
		this.contact_ts = contact_ts;
	}

}
