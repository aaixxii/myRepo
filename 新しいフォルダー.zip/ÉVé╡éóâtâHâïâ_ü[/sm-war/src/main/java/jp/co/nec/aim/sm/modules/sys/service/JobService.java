package jp.co.nec.aim.sm.modules.sys.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractFaceInput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractInputImage;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractInputPayload;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractIrisInput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractLatentInput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractTenprintInput;
import jp.co.nec.aim.message.proto.ExtractService.PBExtractJobRequest;
import jp.co.nec.aim.sm.common.constant.JobManageType;
import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.exception.SMDaoException;
import jp.co.nec.aim.sm.exception.SMServiceException;
import jp.co.nec.aim.sm.modules.sys.BaseService;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.FeJobQueueEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.FusionJobEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.ContainerJob;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.FusionJob;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.JobPojo;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.MuJobsPojo;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.TopJobQueue;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.TopLevelJobPojo;
import jp.co.nec.aim.sm.modules.sys.oracle.repository.ContainerJobRepositoryImpl;
import jp.co.nec.aim.sm.modules.sys.oracle.repository.FEJobQueueRepository;
import jp.co.nec.aim.sm.modules.sys.oracle.repository.FunctionTypeRepository;
import jp.co.nec.aim.sm.modules.sys.oracle.repository.FusionJobRepositoryImpl;
import jp.co.nec.aim.sm.modules.sys.oracle.repository.JobRepository;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;

@Service
@Transactional(value = "oracleTXManager")
public class JobService extends BaseService {
	/** the log instance **/
	private static Logger logger = LoggerFactory.getLogger(JobService.class);
	private static final String GET_EXT_REQ_SQL = "select payload from fe_job_payloads where job_id = %s";

	@Autowired
	private JobRepository jobrepository;

	@Autowired
	private FusionJobRepositoryImpl fusionjobrepository;

	@Autowired
	private ContainerJobRepositoryImpl mujobrepository;

	@Autowired
	private FEJobQueueRepository fejobqueuerepository;

	@Autowired
	private FunctionTypeRepository functiontyperepository;

	@Autowired
	@Qualifier("oracleDataSource")
	DataSource datasource;
	JdbcTemplate jdbcTemplate;

	public Page<TopJobQueue> findJobPage(Page<TopJobQueue> page, JobPojo job) {
		try {
			return jobrepository.findJobPage(page, job);
		} catch (Exception ex) {
			logger.error("Find Jobs Page Failed..", ex);
			throw new SMServiceException(ex);
		}
	}

	public Page<FusionJob> findFusionJobPage(Page<FusionJob> page,
			FusionJob fusionjob) {
		try {

			return fusionjobrepository.findFusionJobPage(page, fusionjob);
		} catch (Exception ex) {
			logger.error("Find Fusion Jobs Page Failed..", ex);
			throw new SMServiceException(ex);
		}
	}

	public Page<ContainerJob> findContainerJobPage(Page<ContainerJob> page,
			ContainerJob containerJob) {
		try {

			return mujobrepository.findContainerJobPage(page, containerJob);
		} catch (Exception ex) {
			logger.error("Find Mu Jobs Page Failed:", ex);
			throw new SMServiceException(ex);
		}
	}

	public Page<FeJobQueueEntity> findFEJobQueuePage(
			Page<FeJobQueueEntity> page, FeJobQueueEntity fejob) {
		try {
			return fejobqueuerepository.findFEJobQueuePage(page, fejob);
		} catch (Exception ex) {
			logger.error("Find FEJobs Queue Page Failed..", ex);
			throw new SMServiceException(ex);
		}
	}

	public Long[][] findMuJobsSummary(List<String> functionlist,
			List<Long> muidlist, String startTime, String endTime) {
		try {
			Long[][] dataset = setdata(muidlist, functionlist, startTime,
					endTime);
			return dataset;
		} catch (Exception ex) {
			logger.error("Find Mu Jobs Summary List Failed..", ex);
			throw new SMServiceException(ex);
		}
	}

	public List<String> getAllFunctionName() {
		try {
			List<String> listFunction = functiontyperepository
					.getAllFunctionType();
			for (String fun : listFunction) {
				if (fun.toUpperCase().equals("EXTRACTION")) {
					listFunction.remove(fun);
					break;
				}
			}
			return listFunction;
		} catch (Exception ex) {
			logger.error("Get All Function Type Failed..", ex);
			throw new SMServiceException(ex);
		}
	}

	@SuppressWarnings("unchecked")
	public <T> List<T> getListByClass(Class<?> clazz, Object obj) {
		if (clazz.equals(TopJobQueue.class)) {
			return (List<T>) jobrepository.findJobList((JobPojo) obj);
		} else if (clazz.equals(FusionJobEntity.class)) {
			return (List<T>) fusionjobrepository
					.findFusionJobList((FusionJob) obj);
		} else if (clazz.equals(FeJobQueueEntity.class)) {
			return (List<T>) fejobqueuerepository
					.findFEJobQueueList((FeJobQueueEntity) obj);
		}
		return null;
	}

	public String getResultByClass(String clazz, Long Id, String field) {
		String result = null;
		if (clazz.equals("JobQueueEntity")) {
			result = jobrepository.findResultsByjobId(Id, field);
		} else if (clazz.equals("FusionJobEntity")) {
			result = fusionjobrepository.findResultsByfusionJobId(Id, field);
		} else if (clazz.equals("ContainerJobEntity")) {
			result = mujobrepository.findResultsByContainerJobId(Id, field);
		} else if (clazz.equals("FEJobQueueEntity")) {
			result = fejobqueuerepository.findResultsByjobId(Id, field);
		} else if (clazz.equals("FeJobPayloadEntity")) {
			result = getExtractionReqest(Id);
		}
		return result;
	}

	private String getExtractionReqest(Long Id) {
		jdbcTemplate = new JdbcTemplate(datasource);
		String sql = String.format(GET_EXT_REQ_SQL, Id);
		List<Map<String, Object>> reqList = jdbcTemplate.queryForList(sql);
		if (reqList.size() != 1 || reqList == null) {
			return "No extraction reqest was found..";
		}
		byte[] req = (byte[]) reqList.get(0).get("PAYLOAD");
		PBExtractJobRequest pbExtReq;
		try {
			pbExtReq = convertBinaryInInputPayload(PBExtractJobRequest
					.parseFrom(req));
		} catch (InvalidProtocolBufferException e) {
			throw new SMDaoException("InvalidProtocolBufferException occurred "
					+ "when parseFrom extarction job request bytes.", e);
		}
		return pbExtReq.toString();
	}

	public PBExtractJobRequest convertBinaryInInputPayload(
			PBExtractJobRequest req) {
		PBExtractJobRequest.Builder builder = req.toBuilder();
		PBExtractInputPayload.Builder extInputBuilder = builder
				.getInputPayloadBuilder();
		if (extInputBuilder.hasTenprintInput()) {
			extInputBuilder = convertBinaryInTempImageData(extInputBuilder);
		} else if (extInputBuilder.hasLatentInput()) {
			extInputBuilder = convertBinaryInLatentImageData(extInputBuilder);
		} else if (extInputBuilder.hasFaceInput()) {
			extInputBuilder = convertBinaryInFaceImageData(extInputBuilder);
		} else if (extInputBuilder.hasIrisInput()) {
			extInputBuilder = convertBinaryInIrisImageData(extInputBuilder);
		}
		builder = builder.setInputPayload(extInputBuilder.build());
		PBExtractJobRequest cReq = builder.build();
		return cReq;
	}

	private PBExtractInputPayload.Builder convertBinaryInTempImageData(
			PBExtractInputPayload.Builder extInputBuilder) {
		PBExtractTenprintInput.Builder tenpBuilder = extInputBuilder
				.getTenprintInputBuilder();
		for (int i = 0; i < tenpBuilder.getImagesBuilderList().size(); i++) {
			tenpBuilder = tenpBuilder.setImages(i,
					convertBinaryToBase64orEmpty(tenpBuilder
							.getImagesBuilder(i)));
		}
		return extInputBuilder.setTenprintInput(tenpBuilder.build());
	}

	private PBExtractInputPayload.Builder convertBinaryInLatentImageData(
			PBExtractInputPayload.Builder extInputBuilder) {
		PBExtractLatentInput.Builder latentBuilder = extInputBuilder
				.getLatentInputBuilder();
		latentBuilder = latentBuilder
				.setImage(convertBinaryToBase64orEmpty(latentBuilder
						.getImageBuilder()));
		return extInputBuilder.setLatentInput(latentBuilder.build());
	}

	private PBExtractInputPayload.Builder convertBinaryInFaceImageData(
			PBExtractInputPayload.Builder extInputBuilder) {
		PBExtractFaceInput.Builder faceBuilder = extInputBuilder
				.getFaceInputBuilder();
		faceBuilder = faceBuilder
				.setImage(convertBinaryToBase64orEmpty(faceBuilder
						.getImageBuilder()));
		return extInputBuilder.setFaceInput(faceBuilder.build());
	}

	private PBExtractInputPayload.Builder convertBinaryInIrisImageData(
			PBExtractInputPayload.Builder extInputBuilder) {
		PBExtractIrisInput.Builder irisBuilder = extInputBuilder
				.getIrisInputBuilder();
		for (int i = 0; i < irisBuilder.getImageBuilderList().size(); i++) {
			irisBuilder = irisBuilder
					.setImage(i, convertBinaryToBase64orEmpty(irisBuilder
							.getImageBuilder(i)));
		}
		return extInputBuilder.setIrisInput(irisBuilder.build());
	}

	private PBExtractInputImage convertBinaryToBase64orEmpty(
			PBExtractInputImage.Builder imgBuilder) {
		if (imgBuilder.hasData()) {
			if (System.getenv("BINARY_EMPTY") != null) {
				imgBuilder = imgBuilder.setData(ByteString
						.copyFrom(new byte[0]));
			} else {
				imgBuilder = imgBuilder.setData(ByteString.copyFrom(Base64
						.encodeBase64(imgBuilder.getData().toByteArray())));
			}
		}
		return imgBuilder.build();
	}

	private Long[][] setdata(List<Long> muidlist, List<String> functionlist,
			String startTime, String endTime) {
		int total = muidlist.size();

		int funcsize = functionlist.size();
		int length = funcsize * 2 + 1;
		Long[][] dataset = new Long[total][];
		int i = 0;
		for (Long muid : muidlist) {
			dataset[i] = new Long[length];
			dataset[i][0] = muid;
			// List<MuJobsPojo> list = mujobrepository.findMuJobsSummary(muid,
			// startTime, endTime);

			List<MuJobsPojo> list = new ArrayList<MuJobsPojo>();
			for (MuJobsPojo mujobspojo : list) {
				int m = 1;
				for (String function : functionlist) {
					if (function.equals(mujobspojo.getFunctiontype())) {
						Long assignd = mujobspojo.getAssigned();
						Long completed = mujobspojo.getCompleted();
						if (assignd != null && assignd.longValue() != 0) {
							dataset[i][m] = mujobspojo.getAssigned();
						}
						if (completed != null && completed.longValue() != 0) {
							dataset[i][m + 1] = mujobspojo.getCompleted();
						}
						break;
					}
					m += 2;
				}
			}
			i++;
		}
		return dataset;
	}

	public int updatePriority(JobPojo job) {
		try {
			return jobrepository.updatePriority(job);
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			throw new SMServiceException(ex);
		}
	}

	public int executeAction(String action, List<Long> jobIdList) {
		try {
			int resultCount = 0;
			if (action.equals(JobManageType.COMPLETE.name())) {
				resultCount = jobrepository.completeJobs(jobIdList);
			} else if (action.equals(JobManageType.RESTART.name())) {
				resultCount = jobrepository.restartJobs(jobIdList);
			} else if (action.equals(JobManageType.DELETE.name())) {
				for (Long id : jobIdList) {
					jobrepository.delete(id);
					resultCount++;
				}
			}

			return resultCount;
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new SMServiceException(e);
		}
	}

	public int executeFeJobsAction(String action, List<Long> fejobIdlist) {
		try {
			int resultCount = 0;
			if (action.equals(JobManageType.COMPLETE.name())) {
				resultCount = fejobqueuerepository.completeJobs(fejobIdlist);
			} else if (action.equals(JobManageType.RESTART.name())) {
				resultCount = fejobqueuerepository.restartJobs(fejobIdlist);
			} else if (action.equals(JobManageType.DELETE.name())) {
				for (Long id : fejobIdlist) {
					fejobqueuerepository.delete(id);
					resultCount++;
				}
			}

			return resultCount;
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new SMServiceException(e);
		}
	}

	public int updateFEPriority(FeJobQueueEntity fejob) {
		try {
			return fejobqueuerepository.updateFEPriority(fejob);
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			throw new SMServiceException(ex);
		}
	}

	public List<TopLevelJobPojo> convert2TLJList(String parameter) {
		List<TopLevelJobPojo> list = new ArrayList<TopLevelJobPojo>();
		if (StringUtils.isBlank(parameter)) {
			return list;
		}
		String[] tljStringList = parameter.split(",");
		for (String tljString : tljStringList) {
			String[] attr = tljString.split("_");
			TopLevelJobPojo tlj = new TopLevelJobPojo();
			tlj.setFunction(attr[0]);
			tlj.setWait(StringUtils.isBlank(attr[1]) ? null : Long
					.valueOf(attr[1]));
			tlj.setExec(StringUtils.isBlank(attr[2]) ? null : Long
					.valueOf(attr[2]));
			tlj.setDone(StringUtils.isBlank(attr[3]) ? null : Long
					.valueOf(attr[3]));

			list.add(tlj);
		}
		return list;
	}

	public String convert2String(List<TopLevelJobPojo> tljPojoList) {
		StringBuffer sb = new StringBuffer();
		for (TopLevelJobPojo tlj : tljPojoList) {
			sb.append(tlj.getFunction());
			sb.append("_");
			sb.append(tlj.getWait() == null ? " " : tlj.getWait());
			sb.append("_");
			sb.append(tlj.getExec() == null ? " " : tlj.getExec());
			sb.append("_");
			sb.append(tlj.getDone() == null ? " " : tlj.getDone());
			sb.append(",");
		}
		return sb.toString();
	}

	public Long[][] convert2DataSet(String preDataString) {
		if (StringUtils.isBlank(preDataString)) {
			return new Long[0][0];
		}
		String[] muStrArr = preDataString.split(",");
		Long[][] preDataSet = new Long[muStrArr.length][];
		int i = 0;
		for (String muStr : muStrArr) {
			String[] arr = muStr.split("_");
			preDataSet[i] = new Long[arr.length];
			for (int j = 0; j < arr.length; j++) {
				preDataSet[i][j] = StringUtils.isBlank(arr[j]) ? null : Long
						.valueOf(arr[j]);
			}
			i++;
		}
		return preDataSet;
	}

	public String convert2String(Long[][] allDataSet) {
		StringBuffer sb = new StringBuffer();
		for (Long[] dataSet : allDataSet) {
			for (Long data : dataSet) {
				sb.append(data == null ? " " : data);
				sb.append("_");
			}
			sb.append(",");
		}
		return sb.toString();
	}

}
