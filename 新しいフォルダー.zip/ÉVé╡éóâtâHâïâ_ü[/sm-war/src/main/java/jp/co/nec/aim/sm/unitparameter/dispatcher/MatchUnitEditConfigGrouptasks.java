package jp.co.nec.aim.sm.unitparameter.dispatcher;

import java.util.ArrayList;
import java.util.List;

import jp.co.nec.aim.sm.common.async.agent.AsyncAgent;
import jp.co.nec.aim.sm.common.threadpool.SMExecutor;
import jp.co.nec.aim.sm.common.threadpool.StandardThreadExecutor;
import jp.co.nec.aim.sm.common.worker.MatchUnitConfigUpdatorWorker;
import jp.co.nec.aim.sm.unitparameter.model.MatchUnitConfig;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MatchUnitEditConfigGrouptasks {
	/** the log instance **/
	private static Logger logger = LoggerFactory
			.getLogger(MatchUnitEditConfigGrouptasks.class);
	private SMExecutor executor = StandardThreadExecutor.getInstance();
	private List<MatchUnitConfig> matchUnitConfiglist;
	private List<AsyncAgent> asyncAgents;
	private boolean isMR;

	public MatchUnitEditConfigGrouptasks(List<MatchUnitConfig> list,
			boolean isMR) {
		this.matchUnitConfiglist = list;
		this.isMR = isMR;
	}

	public void executeUpdateMuConfig() {
		asyncAgents = new ArrayList<AsyncAgent>(matchUnitConfiglist.size());
		for (MatchUnitConfig matchUnitConfig : matchUnitConfiglist) {
			logger.info("Executing Matchunit IPADDRESS="
					+ matchUnitConfig.getIpAddress());
			AsyncAgent agent = AsyncAgent.newInstance(new Object[] {
					matchUnitConfig, new StringBuffer(), isMR });
			asyncAgents.add(agent);
			agent.setRunning(true);
			executor.execute(new MatchUnitConfigUpdatorWorker(agent));
		}
		// wait for threads all done
		for (AsyncAgent a : asyncAgents) {
			try {
				a.get();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	public List<String> getResult() {
		List<String> results = new ArrayList<String>();
		for (AsyncAgent a : asyncAgents) {
			String result = a.getResultObject();
			results.add(result);
		}
		return results;
	}
}
