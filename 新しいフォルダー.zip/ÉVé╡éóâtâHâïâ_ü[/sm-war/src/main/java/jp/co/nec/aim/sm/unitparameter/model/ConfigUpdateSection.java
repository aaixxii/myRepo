package jp.co.nec.aim.sm.unitparameter.model;

import java.util.List;

public class ConfigUpdateSection {

	private String name;
	List<ConfigUpdateItem> items;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<ConfigUpdateItem> getItems() {
		return items;
	}
	public void setItems(List<ConfigUpdateItem> items) {
		this.items = items;
	}		
}
