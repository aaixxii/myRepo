package jp.co.nec.aim.sm.modules.sys.postgres.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "\"JOB_STATISTICS\"", schema = "public")
public class JobStatistics {

	@SequenceGenerator(name="seq_stat", sequenceName="job_statistics_id")
	@Id	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="seq_stat")
	@Column(name = "\"STATISTICS_ID\"")
	private Integer statistics_id;

	@Column(name = "\"MU_ID\"")
	private Integer muid;

	@Column(name = "\"FUNCTION\"")
	private String function;

	@Column(name = "\"SEGMENT_ID\"")
	private Integer segmentId;

	@Column(name = "\"JOB_COUNT\"")
	private Integer jobCount;

	@Column(name = "\"START_TIME\"")
	private Timestamp startTime;

	@Column(name = "\"END_TIME\"")
	private Timestamp endTime;

	@Column(name = "\"AVG_OF_ELAPS\"")
	private Integer avgOfElaps;

	@Column(name = "\"AMR\"")
	private Double amr;

	@Column(name = "\"ANF\"")
	private Double anf;

	@Column(name = "\"CARD_QUALITY_TYPE\"")
	private String cardQualityType;

	@Column(name = "\"CARD_QUALITY_UNDER_100\"")
	private Integer cardQualityUnder100;

	@Column(name = "\"CARD_QUALITY_UNDER_200\"")
	private Integer cardQualityUnder200;

	@Column(name = "\"CARD_QUALITY_UNDER_300\"")
	private Integer cardQualityUnder300;

	@Column(name = "\"CARD_QUALITY_UNDER_400\"")
	private Integer cardQualityUnder400;

	@Column(name = "\"CARD_QUALITY_UNDER_500\"")
	private Integer cardQualityUnder500;

	@Column(name = "\"CARD_QUALITY_UNDER_600\"")
	private Integer cardQualityUnder600;

	@Column(name = "\"CARD_QUALITY_UNDER_700\"")
	private Integer cardQualityUnder700;

	@Column(name = "\"CARD_QUALITY_UNDER_800\"")
	private Integer cardQualityUnder800;
	
	@Transient
	private String muIdList;

	@Transient
	private String sqlStartTime;

	@Transient
	private String sqlEndTime;

	/**
	 * @return the statistics_id
	 */
	public Integer getStatistics_id() {
		return statistics_id;
	}

	/**
	 * @return the muid
	 */
	public Integer getMuid() {
		return muid;
	}

	/**
	 * @param muid
	 *            the muid to set
	 */
	public void setMuid(Integer muid) {
		this.muid = muid;
	}

	/**
	 * @return the function
	 */
	public String getFunction() {
		return function;
	}

	/**
	 * @param function
	 *            the function to set
	 */
	public void setFunction(String function) {
		this.function = function;
	}

	/**
	 * @return the segmentId
	 */
	public Integer getSegmentId() {
		return segmentId;
	}

	/**
	 * @param segmentId
	 *            the segmentId to set
	 */
	public void setSegmentId(Integer segmentId) {
		this.segmentId = segmentId;
	}

	/**
	 * @return the jobCount
	 */
	public Integer getJobCount() {
		return jobCount;
	}

	/**
	 * @param jobCount
	 *            the jobCount to set
	 */
	public void setJobCount(Integer jobCount) {
		this.jobCount = jobCount;
	}

	/**
	 * @return the startTime
	 */
	public Timestamp getStartTime() {
		return startTime;
	}

	/**
	 * @param startTime
	 *            the startTime to set
	 */
	public void setStartTime(Timestamp startTime) {
		this.startTime = startTime;
	}

	/**
	 * @return the endTime
	 */
	public Timestamp getEndTime() {
		return endTime;
	}

	/**
	 * @param endTime
	 *            the endTime to set
	 */
	public void setEndTime(Timestamp endTime) {
		this.endTime = endTime;
	}

	/**
	 * @return the avgOfElaps
	 */
	public Integer getAvgOfElaps() {
		return avgOfElaps;
	}

	/**
	 * @param avgOfElaps
	 *            the avgOfElaps to set
	 */
	public void setAvgOfElaps(Integer avgOfElaps) {
		this.avgOfElaps = avgOfElaps;
	}

	/**
	 * @return the amr
	 */
	public Double getAmr() {
		return amr;
	}

	/**
	 * @param amr
	 *            the amr to set
	 */
	public void setAmr(Double amr) {
		this.amr = amr;
	}

	/**
	 * @return the anf
	 */
	public Double getAnf() {
		return anf;
	}

	/**
	 * @param anf
	 *            the anf to set
	 */
	public void setAnf(Double anf) {
		this.anf = anf;
	}

	/**
	 * @return the cardQualityType
	 */
	public String getCardQualityType() {
		return cardQualityType;
	}

	/**
	 * @param cardQualityType
	 *            the cardQualityType to set
	 */
	public void setCardQualityType(String cardQualityType) {
		this.cardQualityType = cardQualityType;
	}

	/**
	 * @return the cardQualityUnder100
	 */
	public Integer getCardQualityUnder100() {
		return cardQualityUnder100;
	}

	/**
	 * @param cardQualityUnder100
	 *            the cardQualityUnder100 to set
	 */
	public void setCardQualityUnder100(Integer cardQualityUnder100) {
		this.cardQualityUnder100 = cardQualityUnder100;
	}

	/**
	 * @return the cardQualityUnder200
	 */
	public Integer getCardQualityUnder200() {
		return cardQualityUnder200;
	}

	/**
	 * @param cardQualityUnder200
	 *            the cardQualityUnder200 to set
	 */
	public void setCardQualityUnder200(Integer cardQualityUnder200) {
		this.cardQualityUnder200 = cardQualityUnder200;
	}

	/**
	 * @return the cardQualityUnder300
	 */
	public Integer getCardQualityUnder300() {
		return cardQualityUnder300;
	}

	/**
	 * @param cardQualityUnder300
	 *            the cardQualityUnder300 to set
	 */
	public void setCardQualityUnder300(Integer cardQualityUnder300) {
		this.cardQualityUnder300 = cardQualityUnder300;
	}

	/**
	 * @return the cardQualityUnder400
	 */
	public Integer getCardQualityUnder400() {
		return cardQualityUnder400;
	}

	/**
	 * @param cardQualityUnder400
	 *            the cardQualityUnder400 to set
	 */
	public void setCardQualityUnder400(Integer cardQualityUnder400) {
		this.cardQualityUnder400 = cardQualityUnder400;
	}

	/**
	 * @return the cardQualityUnder500
	 */
	public Integer getCardQualityUnder500() {
		return cardQualityUnder500;
	}

	/**
	 * @param cardQualityUnder500
	 *            the cardQualityUnder500 to set
	 */
	public void setCardQualityUnder500(Integer cardQualityUnder500) {
		this.cardQualityUnder500 = cardQualityUnder500;
	}

	/**
	 * @return the cardQualityUnder600
	 */
	public Integer getCardQualityUnder600() {
		return cardQualityUnder600;
	}

	/**
	 * @param cardQualityUnder600
	 *            the cardQualityUnder600 to set
	 */
	public void setCardQualityUnder600(Integer cardQualityUnder600) {
		this.cardQualityUnder600 = cardQualityUnder600;
	}

	/**
	 * @return the cardQualityUnder700
	 */
	public Integer getCardQualityUnder700() {
		return cardQualityUnder700;
	}

	/**
	 * @param cardQualityUnder700
	 *            the cardQualityUnder700 to set
	 */
	public void setCardQualityUnder700(Integer cardQualityUnder700) {
		this.cardQualityUnder700 = cardQualityUnder700;
	}

	/**
	 * @return the cardQualityUnder800
	 */
	public Integer getCardQualityUnder800() {
		return cardQualityUnder800;
	}

	/**
	 * @param cardQualityUnder800
	 *            the cardQualityUnder800 to set
	 */
	public void setCardQualityUnder800(Integer cardQualityUnder800) {
		this.cardQualityUnder800 = cardQualityUnder800;
	}

	public void setSqlStartTime(String sqlStartTime) {
		this.sqlStartTime = sqlStartTime;
	}

	public String getSqlStartTime() {
		return sqlStartTime;
	}

	public void setSqlEndTime(String sqlEndTime) {
		this.sqlEndTime = sqlEndTime;
	}

	public String getSqlEndTime() {
		return sqlEndTime;
	}

	/**
	 * @param muIdList the muIdList to set
	 */
	public void setMuIdList(String muIdList) {
		this.muIdList = muIdList;
	}

	/**
	 * @return the muIdList
	 */
	public String getMuIdList() {
		return muIdList;
	}

}
