package jp.co.nec.aim.sm.modules.sys.oracle.repository;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;

import jp.co.nec.aim.message.proto.AIMMessages.PBInquiryJobResultInternal;
import jp.co.nec.aim.sm.common.constant.ContainerJobState;
import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.common.utils.DateUtils;
import jp.co.nec.aim.sm.common.utils.SMUtil;
import jp.co.nec.aim.sm.exception.SMDaoException;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.ContainerJobEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.ContainerJobFailureReasonEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.MuJobExecutePlansEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.ContainerJob;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.MuJobsPojo;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;

import com.google.protobuf.InvalidProtocolBufferException;

public class ContainerJobRepositoryImpl {

	@Autowired
	ContainerJobRepository repository;

	private final static String containerjobsql = "select cj.CONTAINER_JOB_ID as containerJobId,"
			+ "  cj.FUSION_JOB_ID as fusionJobId,"
			+ "  cjf.failedFlag as failedFlag,"
			+ "  cj.JOB_STATE as jobState,"
			+ "  cj.MR_ID as mrId,"
			+ "  mjep.PLAN as targetSegments,"
			+ "  cj.RESULT_TS as resultTs,"
			+ "  cj.CONTAINER_JOB_RESULT as containerJobResult,"
			+ "  cj.PLAN_ID as planId"
			+ " from CONTAINER_JOBS cj left join ("
			+ "select CONTAINER_JOB_ID, 1 as failedFlag from CONTAINER_JOB_FAILURE_REASONS"
			+ ") cjf on cj.CONTAINER_JOB_ID = cjf.CONTAINER_JOB_ID "
			+ " left join MU_JOB_EXECUTE_PLANS mjep on cj.PLAN_ID = mjep.PLAN_ID ";

	private final static String containerjobsummarysql = "select"
			+ "    mj.MU_ID as matchUnitId, ft.FUNCTION_NAME as functiontype,"
			+ "    count(case when mj.JOB_STATE=1 then 'a' END) assigned,"
			+ "    count(case when mj.JOB_STATE=2 then 'c' END) completed "
			+ " from MU_JOBS mj, SEGMENT_SET_JOBS ssj, FUSION_JOBS fj,"
			+ "    FUNCTION_TYPES ft, JOB_QUEUE jq "
			+ " where mj.SEGMENT_SET_JOB_ID=ssj.SEGMENT_SET_JOB_ID "
			+ "    and ssj.FUSION_JOB_ID=fj.FUSION_JOB_ID "
			+ "    and ft.FUNCTION_ID=fj.FUNCTION_ID and jq.JOB_ID=fj.JOB_ID";

	private final static String jobfunctionsql = "SELECT ft.FUNCTION_NAME as functiontype "
			+ "FROM   MU_JOBS mj, SEGMENT_SET_JOBS ssj, FUSION_JOBS fj,"
			+ "       FUNCTION_TYPES ft "
			+ "WHERE  mj.SEGMENT_SET_JOB_ID = ssj.SEGMENT_SET_JOB_ID"
			+ "       AND ssj.FUSION_JOB_ID = fj.FUSION_JOB_ID"
			+ "       AND ft.FUNCTION_ID = fj.FUNCTION_ID "
			+ "       AND mj.MU_ID is not null "
			+ "GROUP BY fj.FUNCTION_ID, ft.FUNCTION_NAME "
			+ "order by fj.FUNCTION_ID";

	private final static String jobmuidsql = "SELECT DISTINCT mj.MU_ID AS matchUnitId"
			+ "        FROM   MU_JOBS mj"
			+ "        WHERE  mj.MU_ID IS NOT NULL"
			+ "        ORDER  BY mj.MU_ID";

	/**
	 * findContainerJobPage
	 * 
	 * @param page
	 * @param containerJob
	 * @return
	 */
	public Page<ContainerJob> findContainerJobPage(Page<ContainerJob> page,
			ContainerJob containerJob) {
		String sql = containerjobsql;
		sql += getSql(containerJob);
		if (!StringUtils.isNotBlank(page.getOrderBy())) {
			sql += " order by containerJobId asc ";
		}
		Page<ContainerJob> pageResult = repository.findBySql(page, sql,
				ContainerJob.class);
		return pageResult;
	}

	public List<ContainerJobEntity> findMuJobList(ContainerJob containerJob) {
		String sql = containerjobsql;
		sql += getSql(containerJob);
		sql += " order by muJobId asc ";
		List<ContainerJobEntity> list = repository.findBySql(sql,
				ContainerJobEntity.class);

		return list;
	}

	private String getSql(ContainerJob containerJob) {
		String sqltemp = "";

		// add the jobId condition
		final String containerjobid = containerJob.getContainerJobId();
		if (StringUtils.isNotBlank(containerjobid)) {
			sqltemp = gainSqlTemp(sqltemp);
			sqltemp += " cj.CONTAINER_JOB_ID=" + containerjobid;
		}

		// add condition segmentSetId
		final String fusionJobId = containerJob.getFusionJobId();
		if (StringUtils.isNotBlank(fusionJobId)) {
			sqltemp = gainSqlTemp(sqltemp);
			sqltemp += " cj.FUSION_JOB_ID=" + fusionJobId;
		}

		final List<ContainerJobState> statusList = containerJob.getStatusList();
		if (!SMUtil.isListNullOrEmpty(statusList)) {
			for (int i = statusList.size() - 1; i >= 0; i--) {
				if (statusList.get(i) == null) {
					statusList.remove(i);
				}
			}

			String statusCondition = "";
			for (int i = 0; i < statusList.size(); i++) {
				if (i == 0) {
					statusCondition += "(";
				} else {
					statusCondition += " or ";
				}
				ContainerJobState jobstate = statusList.get(i);
				statusCondition += " cj.JOB_STATE=" + jobstate.ordinal();
			}

			if (!statusCondition.isEmpty()) {
				statusCondition += ")";
				sqltemp = gainSqlTemp(sqltemp);
				sqltemp += statusCondition;
			}
		}

		final String failedFlag = containerJob.getFailedFlag();
		if (StringUtils.isNotBlank(failedFlag)) {
			sqltemp = gainSqlTemp(sqltemp);
			if (failedFlag.equals("1")) {
				sqltemp += " cjf.failedFlag=1";
			} else {
				sqltemp += " (cjf.failedFlag is null or cjf.failedFlag = 0)";
			}
		}

		final String mrid = containerJob.getMrId();
		if (StringUtils.isNotBlank(mrid)) {
			sqltemp = gainSqlTemp(sqltemp);
			sqltemp += " cj.MR_ID=" + mrid;

		}
		return sqltemp;
	}

	public String gainSqlTemp(String sqltemp) {
		if (sqltemp == "") {
			sqltemp += " where ";
		} else {
			sqltemp += " and ";
		}
		return sqltemp;
	}

	public List<MuJobsPojo> findMuJobsSummary(Long muid, String startTime,
			String endTime) {
		String sql = containerjobsummarysql;
		String timeCondition = "";
		if (!SMUtil.isNullOrEmpty(startTime)) {
			long epoch = DateUtils.parseDate(startTime).getTime();
			timeCondition += " and jq.SUBMISSION_TS >= " + epoch;
		}
		if (!SMUtil.isNullOrEmpty(endTime)) {
			long epoch = DateUtils.parseDate(endTime).getTime();
			timeCondition += " and jq.SUBMISSION_TS <= " + epoch;
		}
		sql += timeCondition + "       AND mj.MU_ID=" + muid
				+ " GROUP BY mj.MU_ID, ft.FUNCTION_NAME ";
		return repository.findBySql(sql, MuJobsPojo.class);
	}

	public List<String> findJobsFunctionType() {
		String sql = jobfunctionsql;

		return repository.findBySql(sql);
	}

	public List<Long> findMuIdPage(Page<MuJobsPojo> page) {
		String sql = jobmuidsql;
		List<BigDecimal> list = repository.findBySql(sql);
		List<BigDecimal> tmplist = new ArrayList<BigDecimal>();
		if (!page.isDisabled()) {
			int total = list.size();
			int firstResult = page.getFirstResult();
			int maxResult = page.getMaxResults();
			page.setCount(total);
			int lastResult = (firstResult + maxResult) > total ? total
					: (firstResult + maxResult);
			tmplist = list.subList(firstResult, lastResult);
		}
		List<Long> tmp = new ArrayList<Long>();
		for (BigDecimal t : tmplist) {
			tmp.add(t.longValue());
		}
		return tmp;
	}

	public List<Long> findMuIdList() {
		String sql = jobmuidsql;
		List<BigDecimal> list = repository.findBySql(sql);

		List<Long> tmp = new ArrayList<Long>();
		for (BigDecimal t : list) {
			tmp.add(t.longValue());
		}
		return tmp;
	}

	public String findResultsByContainerJobId(Long containerJobId, String field) {
		EntityManager manager = repository.getEntityManager();

		String containerRet = "";
		DetachedCriteria dc = null;
		switch (field) {
		case "reason":
			dc = DetachedCriteria
					.forClass(ContainerJobFailureReasonEntity.class);
			if (!SMUtil.isObjectNull(containerJobId)) {
				dc.add(Restrictions.eq("containerJobId", containerJobId));
			}
			dc.setProjection(Projections.property("reason"));
			List<String> results = this.repository.findAndCast(dc);
			if (results == null || results.isEmpty()) {
				return "This container job has no failure reason..";
			}
			containerRet = results.get(0);
			break;
		case "targetSegments":
			ContainerJobEntity entity = manager.find(ContainerJobEntity.class,
					containerJobId);
			Long planId = entity.getPlanId();
			if (planId == null) {
				return "This container job has no plan information..";
			}

			MuJobExecutePlansEntity plansEntity = manager.find(
					MuJobExecutePlansEntity.class, planId);
			if (plansEntity == null) {
				return "This container job has no target Segments information..";
			}

			containerRet = plansEntity.getPlan();
			break;

		case "result":
			ContainerJobEntity job = manager.find(ContainerJobEntity.class,
					containerJobId);

			byte[] resultBytes = job.getContainerJobResult();
			if (resultBytes == null || resultBytes.length == 0) {
				return "This container job has no result information..";
			}

			PBInquiryJobResultInternal result;
			try {
				result = PBInquiryJobResultInternal.parseFrom(resultBytes);
			} catch (InvalidProtocolBufferException e) {
				throw new SMDaoException(
						"InvalidProtocolBufferException occurred "
								+ "when parseFrom fusion job request bytes.", e);
			}
			containerRet = result.toString();
			break;
		default:
			throw new SMDaoException("The field: " + field
					+ " was not support!");
		}

		return containerRet;
	}

	public List<ContainerJobFailureReasonEntity> getFailureReason(
			Long containerJobId) {
		DetachedCriteria dc = DetachedCriteria
				.forClass(ContainerJobFailureReasonEntity.class);
		dc.add(Restrictions.eq("containerJobId", containerJobId));
		return repository.findAndCast(dc);
	}

	public List<ContainerJobEntity> getCompleted(Long jobId) {
		String sql = "select mj.MU_JOB_ID as muJobId,"
				+ " mj.SEGMENT_SET_JOB_ID as segmentSetJobId,"
				+ " mj.SEGMENT_ID as segmentId, mj.JOB_STATE as jobState,"
				+ " mj.MU_ID as matchUnitId, mj.RESULTS_XML as result,"
				+ " mj.RESULTS_TS as resultsTimestamp,"
				+ " mj.TARGET_SEGMENTS as targetSegments"
				+ " FROM MU_JOBS mj, SEGMENT_SET_JOBS ssj, FUSION_JOBS fj"
				+ " WHERE mj.SEGMENT_SET_JOB_ID = ssj.SEGMENT_SET_JOB_ID AND"
				+ " ssj.FUSION_JOB_ID = fj.FUSION_JOB_ID AND fj.JOB_ID = ?";

		return repository.findBySql(sql, ContainerJobEntity.class, jobId);
	}
}
