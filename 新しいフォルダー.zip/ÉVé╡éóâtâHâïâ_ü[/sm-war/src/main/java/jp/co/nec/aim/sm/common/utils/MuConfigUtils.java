package jp.co.nec.aim.sm.common.utils;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class MuConfigUtils {
	private String section;
    private List<MuConfigSectionUtils> muConfigSection;
	public Map<String, Integer> itemPos = new LinkedHashMap<String, Integer>();
	
	public String getSection() {
		return section;
	}

	public void setSection(String section) {
		this.section = section;
	}

	public List<MuConfigSectionUtils> getMuConfigSection() {
		return muConfigSection;
	}

	public void setMuConfigSection(List<MuConfigSectionUtils> muConfigSection) {
		this.muConfigSection = muConfigSection;
	}
}
