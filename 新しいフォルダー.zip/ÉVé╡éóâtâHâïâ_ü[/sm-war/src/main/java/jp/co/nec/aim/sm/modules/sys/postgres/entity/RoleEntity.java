package jp.co.nec.aim.sm.modules.sys.postgres.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OrderBy;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

import com.google.common.collect.Lists;

@Entity
@Table(name = "\"ROLES\"", schema = "public")
@DynamicInsert
@DynamicUpdate
public class RoleEntity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6144541421164504150L;

	@ManyToMany(mappedBy = "roleList", fetch = FetchType.LAZY)
	@OrderBy("id")
	@Fetch(FetchMode.SUBSELECT)
	@NotFound(action = NotFoundAction.IGNORE)
	private List<UserEntity> userList = Lists.newArrayList();

	// @ManyToMany(fetch = FetchType.LAZY)
	// @JoinTable(name = "\"ROLE_MENU\"", joinColumns = { @JoinColumn(name =
	// "\"ROLE_ID\"") }, inverseJoinColumns = { @JoinColumn(name =
	// "\"MENU_ID\"") })
	// @OrderBy("id")
	// @Fetch(FetchMode.SUBSELECT)
	// @NotFound(action = NotFoundAction.IGNORE)
	@Transient
	private List<MenuEntity> menuList = Lists.newArrayList();

	@Id
	@Column(name = "\"ROLE_ID\"")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_sys_role")
	@SequenceGenerator(name = "seq_sys_role", sequenceName = "role_seg_id")
	private Long roleId;

	@Column(name = "\"NAME\"")
	private String name;

	@Transient
	private String userNames;

	@Transient
	public String getUserNames() {
		List<String> nameIdList = Lists.newArrayList();
		for (UserEntity user : userList) {
			nameIdList.add(user.getName());
		}
		return StringUtils.join(nameIdList, ",");
	}

	/**
	 * @return the roleId
	 */
	public Long getRoleId() {
		return roleId;
	}

	/**
	 * @param roleId
	 *            the roleId to set
	 */
	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	public List<UserEntity> getUserList() {
		return userList;
	}

	public void setUserList(List<UserEntity> userList) {
		this.userList = userList;
	}

	@Transient
	public List<Long> getUserIdList() {
		List<Long> nameIdList = Lists.newArrayList();
		for (UserEntity user : userList) {
			nameIdList.add(user.getId());
		}
		return nameIdList;
	}

	@Transient
	public String getUserIds() {
		List<Long> nameIdList = Lists.newArrayList();
		for (UserEntity user : userList) {
			nameIdList.add(user.getId());
		}
		return StringUtils.join(nameIdList, ",");
	}

	public List<MenuEntity> getMenuList() {
		return menuList;
	}

	public void setMenuList(List<MenuEntity> menuList) {
		this.menuList = menuList;
	}

	@Transient
	public List<Long> getMenuIdList() {
		List<Long> menuIdList = Lists.newArrayList();
		for (MenuEntity menu : menuList) {
			menuIdList.add(menu.getId());
		}
		return menuIdList;
	}

	@Transient
	public void setMenuIdList(List<Long> menuIdList) {
		menuList = Lists.newArrayList();
		for (Long menuId : menuIdList) {
			MenuEntity menu = new MenuEntity();
			menu.setId(menuId);
			menuList.add(menu);
		}
	}

	@Transient
	public String getMenuIds() {
		List<Long> nameIdList = Lists.newArrayList();
		for (MenuEntity menu : menuList) {
			nameIdList.add(menu.getId());
		}
		return StringUtils.join(nameIdList, ",");
	}

	@Transient
	public void setMenuIds(String menuIds) {
		menuList = Lists.newArrayList();
		if (menuIds != null) {
			String[] ids = StringUtils.split(menuIds, ",");
			for (String menuId : ids) {
				MenuEntity menu = new MenuEntity();
				menu.setId(new Long(menuId));
				menuList.add(menu);
			}
		}
	}
}
