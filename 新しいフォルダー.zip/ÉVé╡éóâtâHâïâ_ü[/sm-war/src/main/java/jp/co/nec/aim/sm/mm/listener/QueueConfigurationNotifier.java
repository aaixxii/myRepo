package jp.co.nec.aim.sm.mm.listener;

import java.io.File;

import jp.co.nec.aim.sm.common.constant.Constants;
import jp.co.nec.aim.sm.common.properties.SMProperties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;

/**
 * 
 * 
 */
public class QueueConfigurationNotifier implements Runnable {

	private Long lastModifiedDate = null;
	private static final Logger log = LoggerFactory
			.getLogger(QueueConfigurationNotifier.class);
	private MatchManagerQueueListener mmqueuelistener;

	private static boolean needStop = false;

	@SuppressWarnings("unused")
	private QueueConfigurationNotifier() {
	}

	public QueueConfigurationNotifier(MatchManagerQueueListener mmql) {
		mmqueuelistener = mmql;
	}

	public static void setNeedStop(boolean needStop) {
		QueueConfigurationNotifier.needStop = needStop;
	}

	@Override
	public void run() {
		try {
			log.info("->run()");
			ResourceLoader resourceLoader = new DefaultResourceLoader();

			while (!needStop) {
				Thread.sleep(Constants.QUEUE_FILE_INTERVAL);

				log.info("->needStop:{}", needStop ? "true" : "false");
				
				Resource resource = resourceLoader.getResource(SMProperties
						.getQueueFileName());

				log.info("->QueueFileName:{}", SMProperties.getQueueFileName());

				if (lastModifiedDate == null) {
					File f = resource.getFile();
					lastModifiedDate = f.lastModified();
				} else {
					File f = resource.getFile();
					if (lastModifiedDate != f.lastModified()) {
						log.info("#run() Queue configuration notifier,"
								+ " queue file has been notified."
								+ " Restarting all listeners");
						mmqueuelistener.shutdownQueueListener();
						mmqueuelistener.startupQueueListener();
						lastModifiedDate = f.lastModified();
					}
				}
			}
		} catch (InterruptedException e) {
			log.info("#run() Queue configuration notifier,"
					+ " thread has been interupted, exception description: "
					+ e.toString());
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		log.info("<-run()");
	}

}
