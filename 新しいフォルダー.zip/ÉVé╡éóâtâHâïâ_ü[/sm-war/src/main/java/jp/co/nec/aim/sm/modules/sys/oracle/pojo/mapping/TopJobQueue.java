package jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping;

import java.io.Serializable;
import java.util.Date;

import jp.co.nec.aim.sm.common.annocation.FieldMapped;
import jp.co.nec.aim.sm.common.annocation.InquiryMapping;
import jp.co.nec.aim.sm.common.constant.CallbackStyle;
import jp.co.nec.aim.sm.common.constant.JobState;
import jp.co.nec.aim.sm.common.utils.DateUtils;

import org.apache.commons.lang3.StringUtils;

@InquiryMapping
public class TopJobQueue implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -7171835171865557995L;

	@FieldMapped
	private Long jobId;
	@FieldMapped
	private String jobStatus;
	@FieldMapped
	private String functions;
	@FieldMapped
	private String failedFlag;
	@FieldMapped
	private Long assignedTs;
	@FieldMapped
	private Long resultsTS;

	@FieldMapped
	private Long submissionTS;
	@FieldMapped
	private byte[] results;
	@FieldMapped
	private String priority;
	@FieldMapped
	private Integer maxCandidates;
	@FieldMapped
	private Integer failureCount;
	@FieldMapped
	private Integer remainJobs;
	@FieldMapped
	private Integer callbackStyle;
	@FieldMapped
	private String callbackUrl;

	@SuppressWarnings("unused")
	private String assignedTsStr;
	@SuppressWarnings("unused")
	private String resultTSStr;
	@SuppressWarnings("unused")
	private String submissionTSStr;
	@SuppressWarnings("unused")
	private String callbackStyleStr;

	public Long getJobId() {
		return jobId;
	}

	public void setJobId(Long jobId) {
		this.jobId = jobId;
	}

	public String getJobStatus() {
		if (StringUtils.isBlank(jobStatus)) {
			return StringUtils.EMPTY;
		}
		return JobState.values()[Integer.valueOf(jobStatus)].name();
	}

	public void setJobStatus(String jobStatus) {
		this.jobStatus = jobStatus;
	}

	public String getFunctions() {
		return functions;
	}

	public void setFunctions(String functions) {
		this.functions = functions;
	}

	public String getFailedFlag() {
		if (StringUtils.isBlank(failedFlag)) {
			return StringUtils.EMPTY;
		}

		return failedFlag;
	}

	public void setFailedFlag(String failedFlag) {
		this.failedFlag = failedFlag;
	}

	public String getAssignedTs() {
		return convertDateFormat(assignedTs);
	}

	public void setAssignedTs(Long assignedTs) {
		this.assignedTs = assignedTs;
	}

	public Long getResultsTS() {
		return resultsTS;
	}

	public void setResultsTS(Long resultsTS) {
		this.resultsTS = resultsTS;
	}

	public Long getSubmissionTS() {
		return submissionTS;
	}

	public void setSubmissionTS(Long submissionTS) {
		this.submissionTS = submissionTS;
	}

	public byte[] getResults() {
		return results;
	}

	public void setResults(byte[] results) {
		this.results = results;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public Integer getMaxCandidates() {
		return maxCandidates;
	}

	public void setMaxCandidates(Integer maxCandidates) {
		this.maxCandidates = maxCandidates;
	}

	public Integer getFailureCount() {
		return failureCount;
	}

	public void setFailureCount(Integer failureCount) {
		this.failureCount = failureCount;
	}

	public Integer getRemainJobs() {
		return remainJobs;
	}

	public void setRemainJobs(Integer remainJobs) {
		this.remainJobs = remainJobs;
	}

	public Integer getCallbackStyle() {
		return callbackStyle;
	}

	public void setCallbackStyle(Integer callbackStyle) {
		this.callbackStyle = callbackStyle;
	}

	public String getCallbackUrl() {
		return callbackUrl;
	}

	public void setCallbackUrl(String callbackUrl) {
		this.callbackUrl = callbackUrl;
	}

	public String getResultTSStr() {
		return convertDateFormat(resultsTS);
	}

	public String getSubmissionTSStr() {
		return convertDateFormat(submissionTS);
	}
	
	public String getAssignedTsStr() {
		return convertDateFormat(assignedTs);
	}

	public String getCallbackStyleStr() {
		if (callbackStyle == null) {
			return StringUtils.EMPTY;
		}
		return CallbackStyle.values()[callbackStyle].name();
	}

	private String convertDateFormat(Long longDateData){
		if (longDateData == null) {
			return StringUtils.EMPTY;
		}

		return DateUtils.formatDate(new Date(longDateData),
				new Object[] { "yyyy-MM-dd HH:mm:ss" });		
	}
	
}
