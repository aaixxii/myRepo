package jp.co.nec.aim.sm.modules.sys.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.nec.aim.sm.common.constant.Constants;
import jp.co.nec.aim.sm.common.constant.UnitType;
import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.common.utils.SMUtil;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.MuSegmentEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.MuSegmentEntityPK;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.SegmentSegmentReport;
import jp.co.nec.aim.sm.modules.sys.service.SegmentsService;
import jp.co.nec.aim.sm.modules.sys.web.base.BaseController;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping(value = "/segments")
public class SegmentsController extends BaseController {

	/** the log instance **/
	private static Logger logger = LoggerFactory
			.getLogger(SegmentsController.class);
	@Autowired
	SegmentsService segmentsService;


	@RequiresPermissions(Constants.PERMISSION_VIEWER)
	@RequestMapping(value = { "segmentassigned/list", "" })
	public String listSegmentAllocation(
			@RequestParam(value = "segmentId", required = false) Long segmentId,
			MuSegmentEntity muSeg, HttpServletRequest request,
			HttpServletResponse response, Model model) {
		if (!SMUtil.isObjectNull(segmentId)) {
			MuSegmentEntityPK id = new MuSegmentEntityPK();
			id.setSegmentId(segmentId);
			muSeg.setId(id);
		}
		Page<MuSegmentEntity> page = segmentsService.findSegmentAllocation(
				new Page<MuSegmentEntity>(request, response), muSeg);
		model.addAttribute("page", page);
		model.addAttribute("segmentId", segmentId);		

		saveCurrentPageInfo(request, "/segments/segmentassigned/list", model);
		return "modules/segments/segmentassigndetail";
	}

	@RequiresPermissions(Constants.PERMISSION_VIEWER)
	@RequestMapping(value = { "segmentsegmentreport/list", "" })
	public String listSegmentSegmentReport(
			@RequestParam(value = "type", required = true) String unitType,
			@RequestParam(value = "muId") Long muId,
			HttpServletRequest request, HttpServletResponse response,
			Model model) {
		Page<SegmentSegmentReport> page = null;
		if (UnitType.MU.name().equals(unitType)) {
			page = segmentsService
					.getSegmentSegmentReports(new Page<SegmentSegmentReport>(
							request, response), muId);
		} else if (UnitType.DM.name().equals(unitType)) {
			page = segmentsService
					.getDmSegmentSegmentReports(new Page<SegmentSegmentReport>(
							request, response), muId);
		}	
		model.addAttribute("page", page);
		model.addAttribute("muId", muId);
		if (UnitType.DM.name().equals(unitType)) {
			model.addAttribute("type", UnitType.DM.name());
		} else {
			model.addAttribute("type", UnitType.MU.name());
		}
		
		saveCurrentPageInfo(request, "/segments/segmentsegmentreport/list",
				model);
		return "modules/segments/segmentsegmentreportlist";
	}	

}	

