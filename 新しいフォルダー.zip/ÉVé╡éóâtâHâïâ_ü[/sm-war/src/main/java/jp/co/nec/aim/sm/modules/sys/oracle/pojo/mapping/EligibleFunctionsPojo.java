package jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping;

import jp.co.nec.aim.sm.common.annocation.FieldMapped;
import jp.co.nec.aim.sm.common.annocation.InquiryMapping;

@InquiryMapping
public class EligibleFunctionsPojo {

	@FieldMapped
	private Long matchUnitId;

	@FieldMapped
	private String functions;

	private String action;

	public void setMatchUnitId(Long matchUnitId) {
		this.matchUnitId = matchUnitId;
	}

	public Long getMatchUnitId() {
		return matchUnitId;
	}

	public void setFunctions(String functions) {
		this.functions = functions;
	}

	public String getFunctions() {
		return functions;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getAction() {
		return action;
	}

}
