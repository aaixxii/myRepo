package jp.co.nec.aim.sm.modules.sys.postgres.repository;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import jp.co.nec.aim.sm.common.constant.MessageType;
import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.common.utils.SMUtil;
import jp.co.nec.aim.sm.exception.SMDaoException;
import jp.co.nec.aim.sm.modules.sys.postgres.entity.EventLogEntity;
import jp.co.nec.aim.sm.modules.sys.postgres.pojo.mapping.EventDetailPojo;
import jp.co.nec.aim.sm.modules.sys.postgres.pojo.mapping.EventLogPojo;
import jp.co.nec.aim.sm.modules.sys.postgres.pojo.mapping.MessageEventPojo;
import jp.co.nec.aim.sm.modules.sys.postgres.pojo.mapping.UnitEventPojo;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.SQLQuery;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.type.TimestampType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * EventLogRepositoryImpl interface
 */
public class EventLogRepositoryImpl {
	/** the log instance **/
	private static Logger logger = LoggerFactory
			.getLogger(EventLogRepositoryImpl.class);

	private static String EVENTS_SQL = "SELECT CASE Trim(\"MESSAGE_TYPE\") "
			+ "WHEN '120000' THEN 'SERVICES_STOPPED' "
			+ "WHEN '110000' THEN 'SERVICES_STARTED' "
			+ "WHEN '100000' THEN 'INFORMATION' "
			+ "WHEN '200000' THEN 'WARNING' " + "WHEN '300000' THEN 'ALERT' "
			+ "WHEN '400000' THEN 'ERROR' " + "WHEN '500000' THEN 'EMERGENCY' "
			+ "ELSE 'UNKNWON' " + "END      AS \"messageType\", "
			+ "Count(*) AS \"messageCount\" " + "FROM   \"EVENT_LOG\" "
			+ "WHERE 1 = 1";
	private static String EVENTS_GROUP_SQL = " GROUP BY \"messageType\" order BY \"messageType\"";

	private static String UNITEVENTS_SQL = "SELECT \"UNIT_ID\" AS \"unitId\", "
			+ "CASE Trim(\"MESSAGE_TYPE\") "
			+ "WHEN '120000' THEN 'SERVICES_STOPPED' "
			+ "WHEN '110000' THEN 'SERVICES_STARTED' "
			+ "WHEN '100000' THEN 'INFORMATION' "
			+ "WHEN '200000' THEN 'WARNING' " + "WHEN '300000' THEN 'ALERT' "
			+ "WHEN '400000' THEN 'ERROR' " + "WHEN '500000' THEN 'EMERGENCY' "
			+ "ELSE 'UNKNWON' " + "END      AS \"messageType\", "
			+ "count(\"MESSAGE_TYPE\") AS \"messageCount\" "
			+ "FROM   \"EVENT_LOG\" " + "WHERE 1 = 1";
	private static String UNITEVENTS_GROUP_SQL = " GROUP BY \"unitId\",\"messageType\""
			+ " order by \"unitId\",\"messageType\"";

	private static String MSGEEVENTS_SQL = "SELECT \"UNIT_ID\" AS \"unitId\", "
			+ "CASE Trim(\"MESSAGE_TYPE\") "
			+ "WHEN '120000' THEN 'SERVICES_STOPPED' "
			+ "WHEN '110000' THEN 'SERVICES_STARTED' "
			+ "WHEN '100000' THEN 'INFORMATION' "
			+ "WHEN '200000' THEN 'WARNING' " + "WHEN '300000' THEN 'ALERT' "
			+ "WHEN '400000' THEN 'ERROR' " + "WHEN '500000' THEN 'EMERGENCY' "
			+ "ELSE 'UNKNWON' " + "END      AS \"messageType\", "
			+ "\"MESSAGE_CODE\" AS \"messageCode\", "
			+ "count(\"MESSAGE_CODE\") AS \"messageCount\" "
			+ "FROM   \"EVENT_LOG\" " + "WHERE 1 = 1";
	private static String MSGEEVENTS_GROUP_SQL = " GROUP BY \"unitId\",\"messageType\", \"messageCode\""
			+ " order by \"unitId\",\"messageType\", \"messageCode\" ASC";

	private static String EVENTDETAIL_SQL = "SELECT \"UNIT_ID\" AS \"unitId\","
			+ " CASE Trim(\"MESSAGE_TYPE\") "
			+ "WHEN '120000' THEN 'SERVICES_STOPPED' "
			+ "WHEN '110000' THEN 'SERVICES_STARTED' "
			+ "WHEN '100000' THEN 'INFORMATION' "
			+ "WHEN '200000' THEN 'WARNING' " + "WHEN '300000' THEN 'ALERT' "
			+ "WHEN '400000' THEN 'ERROR' " + "WHEN '500000' THEN 'EMERGENCY' "
			+ "ELSE 'UNKNWON' " + "END      AS \"messageType\", "
			+ "\"MESSAGE_CODE\" AS \"messageCode\", "
			+ "\"MESSAGE\" AS \"message\", "
			+ "to_char(\"TIMESTAMP\", 'YYYY/MM/DD HH24:MI:SS.MS')"
			+ " as \"timestamp\" " + "FROM   \"EVENT_LOG\" " + "WHERE 1 = 1";
	
	private static String ALARM_SQL ="select MAX(e1.\"TIMESTAMP\") as lastAlm from \"EVENT_LOG\" e1,"
			+ "(select \"EVENT_ID\", EXTRACT(EPOCH FROM now()) - EXTRACT(EPOCH FROM \"TIMESTAMP\") as diff  from \"EVENT_LOG\") e2 "
			+ "where e1.\"EVENT_ID\" = e2.\"EVENT_ID\" "
			+ "and e1.\"MESSAGE_TYPE\" in ('200000','300000','400000','500000') "
			+ "and e2.diff < ?";
	
	private static String GET_DB_TIME_STAMP_SQL = "SELECT CURRENT_TIMESTAMP(2) as time";		


	@Autowired
	private EventLogRepository repository;

	/**
	 * get time Condition string
	 * 
	 * @param eventLog
	 * @return
	 */
	private String getCondition(EventLogEntity eventLog) {
		String condition = "";
		final String startTime = eventLog.getStartTime();
		if (StringUtils.isNotEmpty(startTime)) {
			condition += " AND \"TIMESTAMP\" >= (timestamp '" + startTime
					+ "') ";
		}

		final String endTime = eventLog.getEndTime();
		if (StringUtils.isNotEmpty(endTime)) {
			condition += " AND \"TIMESTAMP\" <= (timestamp '" + endTime
					+ ".999') ";
		}		
		return condition;
	}

	/**
	 * get messageType, messageCount from the table EVENT_LOG
	 * 
	 * @param eventLog
	 * @return
	 */
	public List<EventLogPojo> getEvents(final EventLogEntity eventLog) {
		try {
			String category_event_sql = EVENTS_SQL;
			category_event_sql += getCondition(eventLog);
			category_event_sql += EVENTS_GROUP_SQL;		
			return repository.findBySql(category_event_sql, EventLogPojo.class);
		} catch (Exception ex) {
			throw new SMDaoException(ex);
		}
	}

	/**
	 * get unitId, messageType, messageCount from the table EVENT_LOG
	 * 
	 * @param eventLog
	 * @return
	 */
	public List<UnitEventPojo> getUnitEvents(EventLogEntity eventLog) {
		String category_event_sql = UNITEVENTS_SQL;
		category_event_sql += getCondition(eventLog);
		category_event_sql += UNITEVENTS_GROUP_SQL;		
		return repository.findBySql(category_event_sql, UnitEventPojo.class);
	}

	/**
	 * get unitId, messageType, messageCode, messageCount from EVENT_LOG
	 * 
	 * @param eventLog
	 * @return
	 */
	public List<MessageEventPojo> getMessageEvents(EventLogEntity eventLog) {
		String category_event_sql = MSGEEVENTS_SQL;
		category_event_sql += getCondition(eventLog);
		category_event_sql += MSGEEVENTS_GROUP_SQL;
		return repository.findBySql(category_event_sql, MessageEventPojo.class);
	}

	/**
	 * get unitId, messageType, messageCode, messageCount from EVENT_LOG
	 * 
	 * @param page
	 * @param eventLog
	 * @return
	 */
	public Page<MessageEventPojo> getMessageEvents(Page<MessageEventPojo> page,
			EventLogEntity eventLog) {
		String category_event_sql = MSGEEVENTS_SQL;
		category_event_sql += getCondition(eventLog);
		category_event_sql += MSGEEVENTS_GROUP_SQL;	
		return repository.findBySql(page, category_event_sql,
				MessageEventPojo.class);
	}

	/**
	 * get unitId, messageType, messageCode, message from the table EVENT_LOG
	 * 
	 * @param eventLog
	 * @return
	 */
	public List<EventDetailPojo> getEventDetail(EventLogEntity eventLog) {
		String category_event_sql = EVENTDETAIL_SQL;
		category_event_sql += getCondition(eventLog);
		category_event_sql += " order by \"unitId\", \"messageCode\"";
		return repository.findBySql(category_event_sql, EventDetailPojo.class);
	}

	/**
	 * get unitId, messageType, messageCode, message from the table EVENT_LOG
	 * 
	 * @param page
	 * @param eventLog
	 * @return
	 */
	public Page<EventDetailPojo> getEventDetail(Page<EventDetailPojo> page,
			EventLogEntity eventLog) {
		String category_event_sql = EVENTDETAIL_SQL;
		category_event_sql += getCondition(eventLog);
		category_event_sql += " order by \"unitId\", \"messageCode\"";
		return repository.findBySql(page, category_event_sql,
				EventDetailPojo.class);
	}

	/**
	 * get Detached Criteria for EventLogEntity
	 * 
	 * @param eventLog
	 * @return
	 */
	private DetachedCriteria getDetachedCriteria(EventLogEntity eventLog) {
		DetachedCriteria dc = DetachedCriteria.forClass(EventLogEntity.class);
		// add condition eventId
		Integer eventId = eventLog.getEventId();
		if (!SMUtil.isObjectNull(eventId)) {
			logger.debug("add condition eventId = {}", eventId);
			dc.add(Restrictions.eq("eventId", eventId));
		}
		// add condition unitId
		Long unitId = eventLog.getUnitId();
		if (!SMUtil.isObjectNull(unitId)) {
			logger.debug("add condition unitId = {}", unitId);
			dc.add(Restrictions.eq("unitId", unitId));
		}
		// add condition eventId
		String messageType = eventLog.getMessageType();
		if (StringUtils.isNotBlank(messageType)) {
			logger.debug("add condition messageType = {}", messageType);
			dc.add(Restrictions.eq("messageType", MessageType
					.getMessageCode(messageType)));
		}
		List<String> msgTypeList = eventLog.getMsgTypeList();
		if (!SMUtil.isListNullOrEmpty(msgTypeList)) {
			List<String> codeList = new ArrayList<String>();
			for (String msgType : msgTypeList) {
				codeList.add(MessageType.getMessageCode(msgType));
			}
			dc.add(Restrictions.in("messageType", codeList));
		}

		// add condition startTime
		String startTime = eventLog.getStartTime();
		if (StringUtils.isNotBlank(startTime)) {
			logger.debug("add condition startTime = {}", startTime);
			Timestamp st = Timestamp.valueOf(startTime);
			dc.add(Restrictions.ge("timestamp", st));
		}
		// add condition endTime
		String endTime = eventLog.getEndTime();
		if (StringUtils.isNotBlank(endTime)) {
			logger.debug("add condition endTime = {}", endTime);
			Timestamp et = Timestamp.valueOf(endTime + ".999");
			dc.add(Restrictions.le("timestamp", et));
		}

		return dc;
	}

	/**
	 * get eventId, unitId, messageType, messageCode, message from EVENT_LOG
	 * 
	 * @param eventLog
	 * @return
	 */
	public List<EventLogEntity> getEventLogs(EventLogEntity eventLog) {
		DetachedCriteria dc = getDetachedCriteria(eventLog);

		logger.debug("add Order eventId");
		dc.addOrder(Order.asc("eventId"));

		logger.info("get EventLogEntity list form EVENT_LOG");
		List<EventLogEntity> list = repository.find(dc);
		for (EventLogEntity ele : list) {
			ele.setMsgTypeName(MessageType.getMessageTypeName(ele
					.getMessageType()));
		}
		return list;
	}

	/**
	 * get eventId, unitId, messageType, messageCode, message from EVENT_LOG
	 * 
	 * @param page
	 * @param eventLog
	 * @return
	 */
	public Page<EventLogEntity> getEventLogs(Page<EventLogEntity> page,
			EventLogEntity eventLog) {
		DetachedCriteria dc = getDetachedCriteria(eventLog);

		// add Order eventId
		if (!StringUtils.isNotBlank(page.getOrderBy())) {
			logger.debug("add Order eventId");
			dc.addOrder(Order.asc("eventId"));
		}

		logger.info("get EventLogEntity page form EVENT_LOG");
		Page<EventLogEntity> pageResult = repository.findPage(page, dc);
		
		List<EventLogEntity> list = pageResult.getList();
		for (EventLogEntity ele : list) {
			ele.setMsgTypeName(MessageType.getMessageTypeName(ele
					.getMessageType()));
		}
		return pageResult;
	}	
	
	public String getAlarmInfo(int timeValue) {
		String results = null;
		try {
			EntityManager entityManager = repository.getEntityManager();
			Query query = entityManager.createNativeQuery(ALARM_SQL);
			query.setParameter(1, timeValue);
			query.unwrap(SQLQuery.class)
					.addScalar("lastAlm", TimestampType.INSTANCE);					
			results =  query.getSingleResult().toString();
		} catch (Exception e) {			
			results = null;
		}
		return results;		
	}	
	
	public String getDBTime() {
		String dbTimeStamp = null;
		try {
			EntityManager entityManager = repository.getEntityManager();
			Query query = entityManager.createNativeQuery(GET_DB_TIME_STAMP_SQL);			
			query.unwrap(SQLQuery.class)
					.addScalar("time", TimestampType.INSTANCE);					
			dbTimeStamp = String.valueOf(query.getSingleResult());
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			dbTimeStamp = null;
		}
		return dbTimeStamp;	
		
	}
}
