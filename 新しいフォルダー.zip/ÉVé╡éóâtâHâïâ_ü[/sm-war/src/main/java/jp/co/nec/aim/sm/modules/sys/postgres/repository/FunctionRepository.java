package jp.co.nec.aim.sm.modules.sys.postgres.repository;

import java.util.List;

import jp.co.nec.aim.sm.common.persistence.BaseRepository;
import jp.co.nec.aim.sm.modules.sys.postgres.entity.FunctionEntity;

/**
 * Function Type Repository interface
 */
public interface FunctionRepository extends
		BaseRepository<FunctionEntity, Integer> {
	public List<String> findFunctionNameList();
}
