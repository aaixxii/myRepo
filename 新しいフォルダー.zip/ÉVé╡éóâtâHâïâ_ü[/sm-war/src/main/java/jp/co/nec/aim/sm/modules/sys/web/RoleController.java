package jp.co.nec.aim.sm.modules.sys.web;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.nec.aim.sm.common.constant.Constants;
import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.modules.sys.postgres.entity.RoleEntity;
import jp.co.nec.aim.sm.modules.sys.postgres.entity.UserEntity;
import jp.co.nec.aim.sm.modules.sys.service.RoleService;
import jp.co.nec.aim.sm.modules.sys.service.UserService;
import jp.co.nec.aim.sm.modules.sys.util.MenuUtils;
import jp.co.nec.aim.sm.modules.sys.util.UserUtils;
import jp.co.nec.aim.sm.modules.sys.web.base.BaseController;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.apache.shiro.authz.annotation.RequiresUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/**
 * RoleController
 */
@Controller
@RequestMapping(value = "/role")
@RequiresPermissions(Constants.PERMISSION_ADMIN)
public class RoleController extends BaseController {

	@Autowired
	private RoleService roleService;

	// @Autowired
	// private MenuService menuService;

	@Autowired
	private UserService userService;

	@ModelAttribute("roleEntity")
	public RoleEntity get(@RequestParam(required = false) Long id) {
		if (id != null) {
			return roleService.getRole(id);
		} else {
			return new RoleEntity();
		}
	}

	@RequestMapping(value = { "list", "" })
	public String list(RoleEntity role, HttpServletRequest request,
			HttpServletResponse response, Model model) {
		Page<RoleEntity> pageList = roleService
				.findAllRole(new Page<RoleEntity>(request, response));
		model.addAttribute("page", pageList);
		return "modules/sys/roleList";
	}

	@RequestMapping(value = "form")
	public String form(RoleEntity role, Model model) {
		model.addAttribute("role", role);
		model.addAttribute("menuList", MenuUtils.getMenuList());
		return "modules/sys/roleForm";
	}

	@RequestMapping(value = "save")
	public String save(RoleEntity role, Model model, String oldName,
			RedirectAttributes redirectAttributes) {
		if (!beanValidator(model, role)) {
			return form(role, model);
		}
		if (!"true".equals(checkName(oldName, role.getName()))) {
			addMessage(model, "Save Role'" + role.getName()
					+ "'failure, Role name has already exist.");
			return form(role, model);
		}
		roleService.saveRole(role);
		addMessage(redirectAttributes, "Save Role'" + role.getName()
				+ "' successfully.");
		return "redirect:/role/?repage";
	}

	@RequestMapping(value = "delete")
	public String delete(@RequestParam Long id,
			RedirectAttributes redirectAttributes) {
		if (UserEntity.isAdmin(id)) {
			addMessage(redirectAttributes, "Delete Role fialure.");
		} else {
			roleService.deleteRole(id);
			addMessage(redirectAttributes, "Delete Role successfully.");
		}
		return "redirect:/role/?repage";
	}

	@RequestMapping(value = "assign")
	public String assign(RoleEntity role, Model model) {
		List<UserEntity> users = role.getUserList();
		model.addAttribute("users", users);
		return "modules/sys/roleAssign";
	}

	@RequestMapping(value = "usertorole")
	public String selectUserToRole(RoleEntity role, Model model) {
		model.addAttribute("role", role);
		model.addAttribute("selectIds", role.getUserIds());
		return "modules/sys/selectUserToRole";
	}

	@RequestMapping(value = "outrole")
	public String outrole(Long userId, Long roleId,
			RedirectAttributes redirectAttributes) {
		RoleEntity role = roleService.getRole(roleId);
		UserEntity user = userService.getUser(userId);
		if (user.equals(UserUtils.getUser())) {
			addMessage(redirectAttributes, "Can not Remove user itself: "
					+ user.getName() + " from the role: " + role.getName());
		} else {
			Boolean flag = roleService.outUserInRole(role, userId);
			if (!flag) {
				addMessage(redirectAttributes,
						"Remove the User: " + user.getName() + " from Role:"
								+ role.getName() + " failure!");
			} else {
				addMessage(redirectAttributes,
						"Remove the User: " + user.getName() + " from Role:"
								+ role.getName() + " successfully!");
			}
		}
		return "redirect:/role/assign?id=" + role.getRoleId();
	}

	@RequestMapping(value = "assignrole")
	public String assignRole(RoleEntity role, Long[] idsArr,
			RedirectAttributes redirectAttributes) {
		StringBuilder msg = new StringBuilder();
		int newNum = 0;
		for (int i = 0; i < idsArr.length; i++) {
			UserEntity user = roleService.assignUserToRole(role, idsArr[i]);
			if (null != user) {
				msg.append("<br/>Add user:" + user.getName() + " to Role:"
						+ role.getName() + ".");
				newNum++;
			}
		}
		addMessage(redirectAttributes, "Alreay assigned " + newNum + " user(s)"
				+ msg);
		return "redirect:/role/assign?id=" + role.getRoleId();
	}

	@RequiresUser
	@ResponseBody
	@RequestMapping(value = "checkName")
	public String checkName(String oldName, String name) {
		if (name != null && name.equals(oldName)) {
			return "true";
		} else if (name != null && roleService.findRoleByName(name) == null) {
			return "true";
		}
		return "false";
	}

}
