package jp.co.nec.aim.sm.modules.sys.oracle.repository;

import java.util.List;

import jp.co.nec.aim.sm.common.persistence.BaseRepository;
import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.FeJobQueueEntity;

public interface FEJobQueueRepository extends
		BaseRepository<FeJobQueueEntity, Long> {
	public Page<FeJobQueueEntity> findFEJobQueuePage(
			Page<FeJobQueueEntity> page, FeJobQueueEntity fusionjob);

	public List<FeJobQueueEntity> findFEJobQueueList(FeJobQueueEntity fusionjob);

	public String findResultsByjobId(Long jobId, String field);

	public int restartJobs(List<Long> fejobIdlist);

	public int completeJobs(List<Long> fejobIdlist);

	public int updateFEPriority(FeJobQueueEntity fejob);
}
