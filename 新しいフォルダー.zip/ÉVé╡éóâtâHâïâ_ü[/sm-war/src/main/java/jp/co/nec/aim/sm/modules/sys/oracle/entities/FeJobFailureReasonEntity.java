package jp.co.nec.aim.sm.modules.sys.oracle.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the FE_JOB_FAILURE_REASONS database table.
 * 
 */
@Entity
@Table(name = "FE_JOB_FAILURE_REASONS")
public class FeJobFailureReasonEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "fe_job_failure_reasons_generator", sequenceName = "FAILURE_ID_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "fe_job_failure_reasons_generator")
	@Column(name = "FAILURE_ID")
	private long failureId;

	private String code;

	@Column(name = "FAILURE_TIME")
	private String failureTime;

	@Column(name = "JOB_ID")
	private long jobId;

	@Column(name = "MU_ID")
	private int muId;

	private String reason;

	public FeJobFailureReasonEntity() {
	}

	public long getFailureId() {
		return this.failureId;
	}

	public void setFailureId(long failureId) {
		this.failureId = failureId;
	}

	public String getCode() {
		return this.code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getFailureTime() {
		return this.failureTime;
	}

	public void setFailureTime(String failureTime) {
		this.failureTime = failureTime;
	}

	public long getJobId() {
		return this.jobId;
	}

	public void setJobId(long jobId) {
		this.jobId = jobId;
	}

	public int getMuId() {
		return this.muId;
	}

	public void setMuId(int muId) {
		this.muId = muId;
	}

	public String getReason() {
		return this.reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

}