package jp.co.nec.aim.sm.modules.sys.postgres.pojo.mapping;

import java.io.Serializable;

import jp.co.nec.aim.sm.common.annocation.FieldMapped;
import jp.co.nec.aim.sm.common.annocation.InquiryMapping;

@InquiryMapping
public class UnitEventPojo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4554848062372975345L;

	public UnitEventPojo() {

	}

	public UnitEventPojo(Long unitId, String messageType, Long messageCount) {
		this.unitId = unitId;
		this.messageType = messageType;
		this.messageCount = messageCount;
	}

	@FieldMapped
	private Long unitId;

	@FieldMapped
	private String messageType;

	@FieldMapped
	private Long messageCount;

	public String getMessageType() {
		return messageType;
	}

	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	public Long getMessageCount() {
		return messageCount;
	}

	public void setMessageCount(Long messageCount) {
		this.messageCount = messageCount;
	}

	public void setUnitId(Long unitId) {
		this.unitId = unitId;
	}

	public Long getUnitId() {
		return unitId;
	}

}
