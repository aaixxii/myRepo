package jp.co.nec.aim.sm.mm.listener;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;

import javax.jms.ExceptionListener;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;

import jp.co.nec.aim.baton.EventLogMessage;
import jp.co.nec.aim.baton.ExtractJobQueueMessage;
import jp.co.nec.aim.baton.JobQueueMessage;
import jp.co.nec.aim.baton.constant.LogKey;
import jp.co.nec.aim.baton.constant.LogType;
import jp.co.nec.aim.sm.modules.sys.postgres.entity.EventLogEntity;
import jp.co.nec.aim.sm.modules.sys.postgres.entity.ExtractJobQueueEntity;
import jp.co.nec.aim.sm.modules.sys.postgres.entity.JobQueueEntity;
import jp.co.nec.aim.sm.modules.sys.postgres.repository.EventLogRepository;
import jp.co.nec.aim.sm.modules.sys.postgres.repository.ExtractjobQueueRepository;
import jp.co.nec.aim.sm.modules.sys.postgres.repository.JobQueueRepository;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * 
 */
public class InfoMessageListener implements MessageListener, ExceptionListener,
		SystemManagerIfc {

	@SuppressWarnings("unused")
	private InfoMessageListener() {
	}

	private EventLogRepository eventLogDao;
	private JobQueueRepository jobRepository;
	private ExtractjobQueueRepository extractjobQueueDao;

	private MatchManagerQueueListener matchManagerQueryListener;
	private String queueId;
	private static Log log = LogFactory.getLog(InfoMessageListener.class);

	public InfoMessageListener(EventLogRepository eventLogDao,
			JobQueueRepository jobRepository,
			ExtractjobQueueRepository extractjobQueueDao,
			MatchManagerQueueListener matchManagerQueryListener, String queueId) {
		this.eventLogDao = eventLogDao;
		this.jobRepository = jobRepository;
		this.extractjobQueueDao = extractjobQueueDao;
		this.matchManagerQueryListener = matchManagerQueryListener;
		this.queueId = queueId;
	}

	public void onMessage(Message message) {
		log.debug("->onMessage()");
		log.debug("#onMessage() match managers (info) event log recived");
		if (message instanceof ObjectMessage) {
			log.debug("#onMessage() event call executed");

			final ClassLoader old = Thread.currentThread()
					.getContextClassLoader();

			try {
				Thread.currentThread().setContextClassLoader(
						this.getClass().getClassLoader());

				ObjectMessage objectMessage = (ObjectMessage) message;

				@SuppressWarnings("unchecked")
				Map<String, Object> map = (Map<String, Object>) objectMessage
						.getBody(Map.class);
				Integer type = (Integer) map.get(LogKey.TYPE.getKey());
				if (type == LogType.EVENT_LOG.getType()) {
					persistEventLog(map);

					log.debug("#onMessage() event call finished, type: "
							+ LogType.EVENT_LOG.getType());
				} else if (type == LogType.JOB_QUEUE.getType()) {
					persistJobQueue(map);

					log.debug("#onMessage() event call finished, type: "
							+ LogType.JOB_QUEUE.getType());
				} else if (type == LogType.EXTRACT_JOB_QUEUE.getType()) {
					persistExtractJobQueue(map);

					log.debug("#onMessage() event call finished, type: "
							+ LogType.EXTRACT_JOB_QUEUE.getType());
				}
			} catch (Exception e) {
				log.error("#onMessage() error message listerner, "
						+ "exception description: " + e.toString(), e);
			} finally {
				Thread.currentThread().setContextClassLoader(old);
			}
			log.debug("#onMessage() event call finished");
		} else {
			log.warn("message is not instanceof ObjectMessage");
		}
		log.debug("<-onMessage()");
	}

	/**
	 * 
	 * @param map
	 * @throws ParseException
	 */
	private void persistEventLog(Map<String, Object> map) throws ParseException {

		EventLogMessage eventLogMsg = (EventLogMessage) map
				.get(LogKey.EVENT_LOG.getKey());
		EventLogEntity eventLogEntity = new EventLogEntity();
		if (eventLogMsg.getDescription() != null) {
			eventLogEntity.setMessage(eventLogMsg.getDescription().replace(
					REPLACE_CHARS[0], REPLACE_BY_CHARS[0]));
		}
		String reasonCode = (String) map.get(LogKey.REASON_CODE.getKey());
		if (reasonCode != null) {
			if ("9".equals(reasonCode.substring(0, 1))) {
				eventLogEntity.setMessageType(EVENTCODE_EMERGENCY);
			} else if ("8".equals(reasonCode.substring(0, 1))) {
				eventLogEntity.setMessageType(EVENTCODE_ERROR);
			} else if ("5".equals(reasonCode.substring(0, 1))) {
				eventLogEntity.setMessageType(EVENTCODE_ALERT);
			} else if ("1".equals(reasonCode.substring(0, 1))) {
				eventLogEntity.setMessageType(EVENTCODE_WARN);
			} else if ("0".equals(reasonCode.substring(0, 1))) {
				eventLogEntity.setMessageType(EVENTCODE_INFO);
			} else {
				eventLogEntity.setMessageType(EVENTCODE_INFO);
			}
		} else {
			eventLogEntity.setMessageType(EVENTCODE_INFO);
		}
		eventLogEntity.setMessageCode(reasonCode);
		if (eventLogMsg.getTime() == null) {
			eventLogEntity.setTimestamp(null);
		} else {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date dt = sdf.parse(sdf.format(eventLogMsg.getTime()));
			eventLogEntity.setTimestamp(new Timestamp(dt.getTime()));
		}
		Long muId = eventLogMsg.getMuId();
		if (muId == null || muId == -1L) {
			eventLogEntity.setUnitId(UNKNOWN_MUID);
		} else {
			eventLogEntity.setUnitId(muId);
		}
		eventLogEntity.setUnitId(eventLogMsg.getMuId());

		eventLogDao.saveAndFlush(eventLogEntity);
	}

	/**
	 * 
	 * @param map
	 */
	private void persistJobQueue(Map<String, Object> map) {
		JobQueueMessage jqm = (JobQueueMessage) map.get(LogKey.JOB_QUEUE
				.getKey());
		JobQueueEntity jq = new JobQueueEntity();
		jq.setJobId(jqm.getId());
		jq.setState(jqm.getState());

		if (jqm.getTimeOfSubmission() == null) {
			jq.setSubmissionTime(null);
		} else {
			jq.setSubmissionTime(new Timestamp(jqm.getTimeOfSubmission()
					.getTime()));
		}

		if (jqm.getTimeOfResults() == null) {
			jq.setResultTime(null);
		} else {
			jq.setResultTime(new Timestamp(jqm.getTimeOfResults().getTime()));
		}

		if (jqm.getFailed() == null) {
			jq.setFailed(0);
		} else {
			jq.setFailed(jqm.getFailed() == true ? 1 : 0);
		}

		jq.setMaxCandidates(jqm.getMaxCandidates());
		jq.setMinScore(jqm.getMinScore());
		jq.setRevision(jqm.getRevision());
		jq.setPercentagePoint(jqm.getPercentagePoint());
		jq.setHitThreshhold(jqm.getHitThreshold());

		jobRepository.saveAndFlush(jq);
	}

	/**
	 * 
	 * @param map
	 */
	private void persistExtractJobQueue(Map<String, Object> map) {
		ExtractJobQueueMessage ejqm = (ExtractJobQueueMessage) map
				.get(LogKey.EXTRACT_JOB_QUEUE.getKey());

		ExtractJobQueueEntity ejq = new ExtractJobQueueEntity();
		ejq.setExtractJobId(ejqm.getId());
		ejq.setFunctionTypeId(ejqm.getFunctionTypeId());
		ejq.setPriority(ejqm.getPriority());
		ejq.setStatus(ejqm.getStatus());
		ejq.setFailed(0);
		ejq.setResultsXML(ejqm.getResultsXML());

		if (ejqm.getTimeOfSubmission() == null) {
			ejq.setSubmissionTime(null);
		} else {
			ejq.setSubmissionTime(new Timestamp(ejqm.getTimeOfSubmission()
					.getTime()));
		}

		if (ejqm.getTimeOfResults() == null) {
			ejq.setResultTime(null);
		} else {
			ejq.setResultTime(new Timestamp(ejqm.getTimeOfResults().getTime()));
		}

		ejq.setProcessStartTime(new Timestamp((new Date()).getTime()));
		ejq.setFailureCount(ejqm.getFailureCount());
		ejq.setPosition(ejqm.getPosition());
		/* Field paused information not received. */
		ejq.setMuId(ejqm.getMuId());
		ejq.setCallbackURL(ejqm.getCallbackURL());
		ejq.setNistFilePath(ejqm.getNistFilePath());

		extractjobQueueDao.saveAndFlush(ejq);
	}

	public String printJMSObject(ObjectMessage objectMessage) {

		StringBuilder sb = new StringBuilder("");
		try {

			sb.append("Proxy ObjectName :"
					+ objectMessage.getObject().getClass().getName() + "/n");

			@SuppressWarnings("unchecked")
			Map<String, Object> map = (Map<String, Object>) objectMessage
					.getObject();
			sb.append("Proxy MapObject  :" + map + "/n");
			Integer type = (Integer) map.get(LogKey.TYPE.getKey());
			sb.append("Map TypeObject :" + type + "/n");
			Iterator<Object> iter = map.values().iterator();

			while (iter.hasNext()) {
				Object obj = iter.next();
				sb.append("MapObject#Names " + obj.getClass().getName() + "/n");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return sb.toString();
	}

	public void onException(JMSException exception) {
		exception.printStackTrace();
		matchManagerQueryListener.notifyStatus(queueId, "ERROR");
		log.error("#onMessage() error message listener, message recieved,"
				+ " jms failure description: " + exception.toString());
	}

}
