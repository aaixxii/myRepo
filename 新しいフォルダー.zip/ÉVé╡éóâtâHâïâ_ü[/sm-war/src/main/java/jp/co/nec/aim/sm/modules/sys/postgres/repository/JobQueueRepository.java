package jp.co.nec.aim.sm.modules.sys.postgres.repository;

import java.util.List;

import jp.co.nec.aim.sm.common.persistence.BaseRepository;
import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.modules.sys.postgres.entity.JobQueueEntity;
import jp.co.nec.aim.sm.modules.sys.postgres.pojo.mapping.JobAMRPojo;
import jp.co.nec.aim.sm.modules.sys.postgres.pojo.mapping.JobElapsePojo;

/**
 * JobRepository interface
 */
public interface JobQueueRepository extends
		BaseRepository<JobQueueEntity, Long> {

	/** get JobAMRPojo form JOB_QUEUE, FUNCTION_TYPES **/
	public Page<JobAMRPojo> getJobAMR(Page<JobAMRPojo> page,
			JobQueueEntity JobQueueEntity);

	/** get JobAMRPojo form JOB_QUEUE, FUNCTION_TYPES **/
	public List<JobAMRPojo> getJobAMR(JobQueueEntity JobQueueEntity);

	/** get JobElapsePojo form JOB_QUEUE, FUNCTION_TYPES **/
	public Page<JobElapsePojo> getJobElapse(Page<JobElapsePojo> page,
			JobQueueEntity JobQueueEntity);

	/** get JobElapsePojo form JOB_QUEUE, FUNCTION_TYPES **/
	public List<JobElapsePojo> getJobElapse(JobQueueEntity JobQueueEntity);

}
