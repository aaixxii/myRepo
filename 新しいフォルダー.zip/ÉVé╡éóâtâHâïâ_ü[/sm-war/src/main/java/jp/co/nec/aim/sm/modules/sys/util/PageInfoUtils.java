package jp.co.nec.aim.sm.modules.sys.util;

import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

class PageTimeModel {
	long leve1_Id;
	long leve2_Id;
	long leve3_Id;
	long date;

	PageTimeModel(long leve1_Id, long leve2_Id, long leve3_Id) {
		this.leve1_Id = leve1_Id;
		this.leve2_Id = leve2_Id;
		this.leve3_Id = leve3_Id;
		this.date = new Date().getTime();
	}
}

public class PageInfoUtils {

	private static Map<String, PageTimeModel> infoMap = new HashMap<String, PageTimeModel>();

	public static void savePageInfo(String sessionId, long leve1_Id,
			long leve2_Id, long leve3_Id) {
		PageTimeModel model = infoMap.get(sessionId);
		if (model != null) {
			model.leve1_Id = leve1_Id;
			model.leve2_Id = leve2_Id;
			model.leve3_Id = leve3_Id;
			model.date = new Date().getTime();
		} else {
			infoMap.put(sessionId, new PageTimeModel(leve1_Id, leve2_Id,
					leve3_Id));
		}

		removeTimeOutPageInfo(1200000l);
	}

	public static Map<String, Long> getModel(String sessionId) {
		PageTimeModel model = infoMap.get(sessionId);
		if (model != null) {
			model.date = new Date().getTime();

			Map<String, Long> map = new HashMap<String, Long>();
			map.put("leve1_Id", model.leve1_Id);
			map.put("leve2_Id", model.leve2_Id);
			map.put("leve3_Id", model.leve3_Id);

			return map;
		} else {
			return null;
		}
	}

	public static void removeTimeOutPageInfo(Long timeOut) {
		long now = new Date().getTime();
		Iterator<String> sessionIds = infoMap.keySet().iterator();
		while (sessionIds.hasNext()) {
			String session = sessionIds.next();
			if (infoMap.get(session).date + timeOut < now) {
				sessionIds.remove();
			}
		}
	}
}