package jp.co.nec.aim.sm.modules.sys.oracle.repository;

import java.util.List;

import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.common.utils.SMUtil;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.MuSegmentEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.MUSegmentsSLBPojo;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.SegmentsMUsSLBPojo;

import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;

public class MatchUnitSegmentRepositoryImpl {

	@Autowired
	MatchUnitSegmentRepository repository;

	private static final int MANUAL_RANK = 3;

	public Page<MuSegmentEntity> findSegmentAllocation(
			Page<MuSegmentEntity> page, MuSegmentEntity muSeg) {
		DetachedCriteria dc = getDetachedCriteria(muSeg);
		if (!StringUtils.isNotBlank(page.getOrderBy())) {
			dc.addOrder(Order.asc("id.muId"));
			dc.addOrder(Order.asc("id.segmentId"));
		}
		return repository.findPage(page, dc);
	}

	private DetachedCriteria getDetachedCriteria(MuSegmentEntity muSeg) {
		// create the DetachedCriteria instance without session
		final DetachedCriteria dc = DetachedCriteria
				.forClass(MuSegmentEntity.class);

		if (muSeg.getId() != null) {
			// add the unit id condition
			final Long unitId = muSeg.getId().getMuId();
			if (!SMUtil.isObjectNull(unitId)) {
				dc.add(Restrictions.eq("id.muId", unitId));
			}

			// add condition unit Segment
			final Long segmentId = muSeg.getId().getSegmentId();
			if (!SMUtil.isObjectNull(segmentId)) {
				dc.add(Restrictions.eq("id.segmentId", segmentId));
			}
		}

		return dc;
	}

	public boolean saveSegmentAllocation(MuSegmentEntity muSeg) {
		if (muSeg.getId() == null) {
			return false;
		} else if (muSeg.getId().getMuId() == 0
				|| muSeg.getId().getSegmentId() == 0) {
			return false;
		} else {
			MuSegmentEntity entity = new MuSegmentEntity();
			entity.setId(muSeg.getId());
			entity.setRank(MANUAL_RANK);
			repository.save(entity);
			return true;
		}
	}

	public boolean deleteSegmentAllocation(MuSegmentEntity muSeg) {
		if (muSeg.getId() == null) {
			return false;
		} else if (muSeg.getId().getMuId() == 0
				|| muSeg.getId().getSegmentId() == 0) {
			return false;
		} else {
			DetachedCriteria dc = getDetachedCriteria(muSeg);
			List<MuSegmentEntity> list = repository.find(dc);
			repository.delete(list);
			return true;
		}
	}

	public List<MuSegmentEntity> ListSegmentAllocation(MuSegmentEntity muSeg) {
		DetachedCriteria dc = getDetachedCriteria(muSeg);
		dc.addOrder(Order.asc("id.muId"));
		dc.addOrder(Order.asc("id.segmentId"));
		return repository.find(dc);
	}

	/**
	 * get MU-Segments list for LoadBalancer
	 * 
	 * @param muIds
	 * @param formatNames
	 * @return
	 */
	public List<MUSegmentsSLBPojo> listMUSegmentsSLB(String muIds,
			String formatNames) {
		String sql = "select mu.MU_ID as muId, mu.STATE as status,"
				+ "    btem.segCount, btem.BIN_ID as binId,"
				+ "    case when btem.BIN_ID is null then null"
				+ "       else btem.BIN_ID||'('||btem.FORMAT_NAME||')'"
				+ "    end as binName, btem.MIN_REDUNDANCY as redundancy "
				+ " from MATCH_UNITS mu left join ("
				+ "    select count(ms.SEGMENT_ID) as segCount, b.BIN_ID,"
				+ "        ft.FORMAT_NAME, ms.MU_ID, b.MIN_REDUNDANCY"
				+ "    from FORMAT_TYPES ft, BINS b, SEGMENT_SETS ss,"
				+ "        SEGMENTS s, MU_SEGMENTS ms, MU_ELIGIBLE_CONTAINERS meb"
				+ "    where ms.MU_ID=meb.MU_ID and meb.BIN_ID=ss.BIN_ID"
				+ "        and ss.SEGMENT_SET_ID=s.SEGMENT_SET_ID and"
				+ "        s.SEGMENT_ID=ms.SEGMENT_ID and ss.BIN_ID=b.BIN_ID"
				+ "        and b.FORMAT_ID=ft.FORMAT_ID ";

		if (StringUtils.isNotBlank(formatNames)) {
			String condition = "";
			condition += "        and ft.FORMAT_NAME in ('";
			String[] formatArray = formatNames.split(",");
			for (int i = 0; i < formatArray.length; i++) {
				if (i == 0) {
					condition += formatArray[i];
				} else {
					condition += "','" + formatArray[i];
				}
			}
			condition += "') ";
			sql += condition;
		}
		sql = sql + "    group by b.BIN_ID, ft.FORMAT_NAME, b.MIN_REDUNDANCY,"
				+ "        ms.MU_ID) btem on mu.MU_ID=btem.MU_ID "
				+ "    where (mu.TYPE = 0 or mu.TYPE = 2) ";

		if (StringUtils.isNotBlank(muIds)) {
			sql += " and mu.MU_ID in (" + muIds + ") ";
		}

		sql += " order by mu.MU_ID, btem.BIN_ID";

		return repository.findBySql(sql, MUSegmentsSLBPojo.class);
	}

	/**
	 * get Segments-MUs list for LoadBalancer
	 * 
	 * @param muIds
	 * @param formatNames
	 * @return
	 */
	public List<SegmentsMUsSLBPojo> listSegmentsMUsSLBPojo(String formatNames) {
		String condition = "";
		if (StringUtils.isNotBlank(formatNames)) {
			condition += " and ft.FORMAT_NAME in ('";
			String[] formatArray = formatNames.split(",");
			for (int i = 0; i < formatArray.length; i++) {
				if (i == 0) {
					condition += formatArray[i];
				} else {
					condition += "','" + formatArray[i];
				}
			}
			condition += "') ";
		}
		String sql = "select segs.BIN_ID as binId, mus.muCount, segs.segCount, mus.muSegSum,"
				+ "        mus.muSegSum/mus.muCount as avgSeg"
				+ "    from ("
				+ "        select count(s.SEGMENT_ID) as segCount, b.BIN_ID"
				+ "        from FORMAT_TYPES ft, BINS b, SEGMENT_SETS ss, SEGMENTS s"
				+ "	       where ss.SEGMENT_SET_ID=s.SEGMENT_SET_ID"
				+ "	           and ss.BIN_ID=b.BIN_ID and b.FORMAT_ID=ft.FORMAT_ID"
				+ condition
				+ "	       group by b.BIN_ID"
				+ "	   ) segs left join ("
				+ "	       select BIN_ID, count(MU_ID) as muCount, sum(muSegCount) as muSegSum from ("
				+ "	           select ms.MU_ID, ss.BIN_ID, count(ms.SEGMENT_ID) as muSegCount"
				+ "	           from FORMAT_TYPES ft, BINS b, MU_SEGMENTS ms, SEGMENT_SETS ss,"
				+ "	               SEGMENTS s, MU_ELIGIBLE_CONTAINERS meb"
				+ "	           where ss.SEGMENT_SET_ID=s.SEGMENT_SET_ID and s.SEGMENT_ID=ms.SEGMENT_ID"
				+ "	               and ss.BIN_ID=meb.BIN_ID and ms.MU_ID=meb.MU_ID"
				+ "	               and ss.BIN_ID=b.BIN_ID and b.FORMAT_ID=ft.FORMAT_ID"
				+ condition
				+ "  	         group by ms.MU_ID, ss.BIN_ID"
				+ "	        ) group by BIN_ID"
				+ "	   ) mus on mus.BIN_ID=segs.BIN_ID"
				+ "	   order by segs.BIN_ID";

		return repository.findBySql(sql, SegmentsMUsSLBPojo.class);
	}
}
