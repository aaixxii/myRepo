package jp.co.nec.aim.sm.modules.sys.postgres.pojo.mapping;

import java.io.Serializable;

import jp.co.nec.aim.sm.common.annocation.FieldMapped;
import jp.co.nec.aim.sm.common.annocation.InquiryMapping;

@InquiryMapping
public class MessageEventPojo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8605762399003804331L;

	public MessageEventPojo() {

	}

	public MessageEventPojo(Long unitId, String messageType,
			String messageCode, Long messageCount) {
		this.unitId = unitId;
		this.messageType = messageType;
		this.messageCode = messageCode;
		this.messageCount = messageCount;
	}

	@FieldMapped
	private Long unitId;

	@FieldMapped
	private String messageType;

	@FieldMapped
	private String messageCode;

	@FieldMapped
	private Long messageCount;

	public String getMessageType() {
		return messageType;
	}

	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	public Long getMessageCount() {
		return messageCount;
	}

	public void setMessageCount(Long messageCount) {
		this.messageCount = messageCount;
	}

	public void setUnitId(Long unitId) {
		this.unitId = unitId;
	}

	public Long getUnitId() {
		return unitId;
	}

	public void setMessageCode(String messageCode) {
		this.messageCode = messageCode;
	}

	public String getMessageCode() {
		return messageCode;
	}

}
