package jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping;

import java.util.Comparator;

public class TransactionMonitorDataComparator implements
		Comparator<TransactionMonitorData> {

	@Override
	public int compare(TransactionMonitorData o1, TransactionMonitorData o2) {
		if (o1 == null || o2 == null || o1.getFunctionType() == null
				|| o2.getFunctionType() == null) {
			String errMsg = "There are null object in parameters,can't to compare two object!";
			throw new RuntimeException(errMsg);
		}
		int first = o1.getFunctionType().compareTo(o2.getFunctionType());
		int second = o1.getFamily().compareTo(o2.getFamily());
		int three = o1.getCount().compareTo(o2.getCount());
		return first != 0 ? first : (second != 0 ? second : three);
	}

}
