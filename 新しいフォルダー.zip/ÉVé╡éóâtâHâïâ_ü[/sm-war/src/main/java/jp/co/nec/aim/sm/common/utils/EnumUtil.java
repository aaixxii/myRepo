package jp.co.nec.aim.sm.common.utils;

import java.util.ArrayList;
import java.util.List;

import jp.co.nec.aim.sm.common.constant.BinActionType;
import jp.co.nec.aim.sm.common.constant.ContainerJobState;
import jp.co.nec.aim.sm.common.constant.EligibleAssignAction;
import jp.co.nec.aim.sm.common.constant.FeJobStatus;
import jp.co.nec.aim.sm.common.constant.JobManageType;
import jp.co.nec.aim.sm.common.constant.JobState;
import jp.co.nec.aim.sm.common.constant.MessageType;
import jp.co.nec.aim.sm.common.constant.ProcessType;
import jp.co.nec.aim.sm.common.constant.SegmentAllocationAction;
import jp.co.nec.aim.sm.common.constant.SegmentReportState;
import jp.co.nec.aim.sm.common.constant.UnitState;
import jp.co.nec.aim.sm.common.constant.UnitType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class EnumUtil {
	protected static Logger logger = LoggerFactory.getLogger(EnumUtil.class);
	private static List<String> segmentReportStatelist;
	private static List<String> segmentAllocationlist;
	private static List<String> jobStatelist;
	private static List<String> jobStatuslist;
	private static List<String> processTypelist;
	private static List<String> unitTypelist;
	private static List<String> unitCtrlTypelist;
	private static List<String> unitStatelist;
	private static List<String> muJobStatelist;
	private static List<String> assignActionlist;
	private static List<String> binActionlist;
	private static List<String> logLevelList;
	private static List<String> msgTypeList;
	private static List<String> jobManageTypeList;

	static {
		segmentReportStatelist = getAllSegmentReportState();
		segmentAllocationlist = getAllAction();
		jobStatelist = getAllJobState();
		jobStatuslist = getAllJobStatus();
		processTypelist = findAllUtilAction();
		unitTypelist = findAllUnitType();
		unitCtrlTypelist = findAllUnitCtrlType();
		unitStatelist = findAllUnitState();
		muJobStatelist = getAllMuJobState();
		assignActionlist = getAssignActions();
		binActionlist = getBinActions();
		msgTypeList = getMessageTypes();
		jobManageTypeList = getJobManageType();
	}

	private static List<String> getAllMuJobState() {
		try {
			return getAllEnumList(ContainerJobState.class);
		} catch (Exception ex) {
			logger.error("Get All ProcessType Failed..", ex);
			return null;
		}
	}

	/**
	 * findAllUnitType
	 * 
	 * @return all Unit Type String
	 */
	private static List<String> findAllUtilAction() {
		try {
			return getAllEnumList(ProcessType.class);
		} catch (Exception ex) {
			logger.error("Get All ProcessType Failed..", ex);
			return null;
		}
	}

	/**
	 * findAllUnitType
	 * 
	 * @return all Unit Type String
	 */
	private static List<String> findAllUnitType() {
		try {
			return getAllEnumList(UnitType.class);
		} catch (Exception ex) {
			logger.error("Get All UnitType Failed..", ex);
			return null;
		}
	}

	/**
	 * findAllUnitCtrlType
	 * 
	 * @return all Unit Type String
	 */
	private static List<String> findAllUnitCtrlType() {
		try {
			List<String> list = new ArrayList<String>();
			for (UnitType type : UnitType.values()) {
				if (type != UnitType.UNKNOWN && type != UnitType.SM)
					list.add(type.name());
			}

			return list;
		} catch (Exception ex) {
			logger.error("Get All UnitType Failed..", ex);
			return null;
		}
	}

	/**
	 * findAllUnitState
	 * 
	 * @return all Unit state
	 */
	private static List<String> findAllUnitState() {
		try {
			return getAllEnumList(UnitState.class);
		} catch (Exception ex) {
			logger.error("Get All UnitState Failed..", ex);
			return null;
		}
	}

	private static List<String> getAllSegmentReportState() {
		try {
			return getAllEnumList(SegmentReportState.class);
		} catch (Exception ex) {
			logger.error("Get All SegmentReportState Failed..", ex);
			return null;
		}
	}

	private static List<String> getAllAction() {
		try {
			return getAllEnumList(SegmentAllocationAction.class);
		} catch (Exception ex) {
			logger.error("Get All SegmentAllocationAction Failed..", ex);
			return null;
		}
	}

	private static List<String> getAllJobState() {
		try {
			return getAllEnumList(JobState.class);
		} catch (Exception ex) {
			logger.error("Get All JobState Failed..", ex);
			return null;
		}
	}

	private static List<String> getAllJobStatus() {
		try {
			return getAllEnumList(FeJobStatus.class);
		} catch (Exception ex) {
			logger.error("Get All JobStatus Failed..", ex);
			return null;
		}
	}

	/**
	 * get Assign Actions: "Assign", "Unassign"
	 * 
	 * @return
	 */
	private static List<String> getAssignActions() {
		try {
			return getAllEnumList(EligibleAssignAction.class);
		} catch (Exception ex) {
			logger.error("Get All Assign Actions Failed..", ex);
			return null;
		}
	}

	/**
	 * get Bin Actions
	 * 
	 * @return
	 */
	private static List<String> getBinActions() {
		try {
			return getAllEnumList(BinActionType.class);
		} catch (Exception ex) {
			logger.error("Get All Bin Actions Failed..", ex);
			return null;
		}
	}

	/**
	 * get Message Type
	 * 
	 * @return
	 */
	private static List<String> getMessageTypes() {
		try {
			return getAllEnumList(MessageType.class);
		} catch (Exception ex) {
			logger.error("Get All Message Type Failed..", ex);
			return null;
		}
	}

	/**
	 * get Job Manage Type
	 * 
	 * @return
	 */
	private static List<String> getJobManageType() {
		try {
			return getAllEnumList(JobManageType.class);
		} catch (Exception ex) {
			logger.error("Get All Message Type Failed..", ex);
			return null;
		}
	}

	private static List<String> getAllEnumList(Class<?> clazz) {
		try {
			Object[] objs = clazz.getEnumConstants();
			List<String> list = new ArrayList<String>();
			for (int i = 0; i < objs.length; i++) {
				if (objs[i] != UnitType.UNKNOWN) {
					list.add(objs[i].toString());
				}
			}
			return list;
		} catch (Exception ex) {
			logger.error("Get All Enum Failed..", ex);
			return null;
		}
	}

	public static List<String> getSegmentReportStatelist() {
		return segmentReportStatelist;
	}

	public static List<String> getSegmentAllocationlist() {
		return segmentAllocationlist;
	}

	public static List<String> getJobStatelist() {
		return jobStatelist;
	}

	public static List<String> getJobStatuslist() {
		return jobStatuslist;
	}

	public static List<String> getProcessTypelist() {
		return processTypelist;
	}

	public static List<String> getUnitTypelist() {
		return unitTypelist;
	}

	public static List<String> getUnitCtrlTypelist() {
		return unitCtrlTypelist;
	}

	public static List<String> getUnitStatelist() {
		return unitStatelist;
	}

	public static List<String> getMuJobStatelist() {
		return muJobStatelist;
	}

	public static List<String> getLogLevelList() {
		return logLevelList;
	}

	/**
	 * get Assign Actions: "Assign", "Unassign"
	 * 
	 * @return
	 */
	public static List<String> getAssignActionList() {
		return assignActionlist;
	}

	/**
	 * get Bin Actions
	 * 
	 * @return
	 */
	public static List<String> getBinActionList() {
		return binActionlist;
	}

	/**
	 * get Bin Actions
	 * 
	 * @return
	 */
	public static List<String> getMassegeTypeList() {
		return msgTypeList;
	}

	/**
	 * get Bin Actions
	 * 
	 * @return
	 */
	public static List<String> getJobManageTypeList() {
		return jobManageTypeList;
	}
}
