package jp.co.nec.aim.sm.mm.listener.reattempt;

import jp.co.nec.aim.sm.mm.listener.QueueInformation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * 
 */
public class MatchManagerReattempt {
	private static Logger log = LoggerFactory
			.getLogger(MatchManagerReattempt.class);

	public synchronized void notifyStatusListenerStopped(
			QueueInformation queueInfo) {
		log.info("#MatchManagerReattempt|notifyStatusListenerStopped()"
				+ " queueId : " + queueInfo.getQueueID() + "has been stopped");
	}

	public synchronized void notifyStatusQueueStopped(QueueInformation queueInfo) {
		log.info("#MatchManagerReattempt|notifyStatusQueueStopped()"
				+ " queueId : " + queueInfo.getQueueID()
				+ " is unable to listen "
				+ "the queue, please check with administrator mm queue "
				+ "might be stopped.");
	}

	public synchronized void queueReattempt(QueueInformation queueInfo) {
		log.info("#MatchManagerReattempt|queueReattempt() "
				+ "re-attempting queue queueId = " + queueInfo.getQueueID());
	}

	public synchronized void queueUnlimitedReattempt(QueueInformation queueInfo) {
		log.info("#MatchManagerReattempt|queueUnlimitedReattempt() invoking"
				+ " unlimited queue reattempt, queueId = "
				+ queueInfo.getQueueID());
	}

	public synchronized void queueLimitedReattempt(QueueInformation queueInfo) {
		log.info("#MatchManagerReattempt|queueLimitedReattempt() invoking "
				+ "limited queue reattempt, queueId = "
				+ queueInfo.getQueueID());
	}

	public synchronized void queueReattemptFailed(QueueInformation queueInfo) {
		log.info("#MatchManagerReattempt|queueReattemptFailed() re-attempt, "
				+ "unable to connect to queueId = " + queueInfo.getQueueID());
	}

	public synchronized void logInfo(String logString) {
		log.info(logString);
	}

	public synchronized void logError(String logString) {
		log.error(logString);
	}
}
