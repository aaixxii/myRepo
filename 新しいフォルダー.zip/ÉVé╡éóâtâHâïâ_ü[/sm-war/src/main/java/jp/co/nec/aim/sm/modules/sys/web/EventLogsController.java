package jp.co.nec.aim.sm.modules.sys.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.nec.aim.sm.common.constant.Constants;
import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.common.utils.EnumUtil;
import jp.co.nec.aim.sm.common.utils.SMUtil;
import jp.co.nec.aim.sm.modules.sys.postgres.entity.EventLogEntity;
import jp.co.nec.aim.sm.modules.sys.service.EventLogService;
import jp.co.nec.aim.sm.modules.sys.web.base.BaseController;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.google.common.collect.Lists;

@Controller
@RequestMapping(value = "/eventLogs")
@RequiresPermissions(Constants.PERMISSION_VIEWER)
public class EventLogsController extends BaseController {
	/** the log instance **/
	private static Logger logger = LoggerFactory
			.getLogger(EventLogsController.class);

	@Autowired
	private EventLogService eventLogService;
	private String title = "Event Logs";

	/**
	 * 
	 * @param eventLog
	 * @param request
	 * @param response
	 * @param model
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = { "event/list", "" })
	public String list(
			@RequestParam(value = "unitId", required = false) Long unitId,
			@RequestParam(value = "msgType", required = false) String msgType,
			EventLogEntity eventLog, HttpServletRequest request,
			HttpServletResponse response, Model model) throws IOException {
		if (!SMUtil.isObjectNull(unitId))
			eventLog.setUnitId(unitId);
		if (!SMUtil.isNullOrEmpty(msgType)) {
			String[] msgTypes = msgType.split(",");
			List<String> msgTypeList = Lists.newArrayList(msgTypes);
			eventLog.setMsgTypeList(msgTypeList);
		}

		Page<EventLogEntity> page = new Page<EventLogEntity>(request, response);
		// get Event Logs
		logger.info("get Event Logs");
		Page<EventLogEntity> events = eventLogService.getEventLogs(page,
				eventLog);
		logger.info("page count:{}, list size:{}", events.getCount(), events
				.getList().size());

		List<String> typeList = EnumUtil.getMassegeTypeList();

		// add Attribute
		model.addAttribute("page", events);
		model.addAttribute("typeList", typeList);
		model.addAttribute("eventLog", eventLog);

		logger.info("show Event Logs");
		saveCurrentPageInfo(request, "/eventLogs/event/list", model);
		return "modules/eventlogs/eventlog";
	}

}
