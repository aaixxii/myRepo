package jp.co.nec.aim.sm.common.constant;

/**
 * 
 * @author liuyq
 * 
 */
public enum CallbackStyle {
	XML(0), PROTOBUF(1);

	private int style;

	CallbackStyle(int style) {
		this.setStyle(style);
	}

	public int getStyle() {
		return style;
	}

	public void setStyle(int style) {
		this.style = style;
	}
}
