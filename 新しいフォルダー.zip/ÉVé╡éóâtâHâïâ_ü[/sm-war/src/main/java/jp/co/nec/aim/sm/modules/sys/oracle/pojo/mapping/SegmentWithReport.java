package jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping;

import java.io.Serializable;
import java.sql.Timestamp;

import jp.co.nec.aim.sm.common.annocation.FieldMapped;
import jp.co.nec.aim.sm.common.annocation.InquiryMapping;
import jp.co.nec.aim.sm.common.constant.SegmentReportState;

@InquiryMapping
public class SegmentWithReport implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -8407642857657998744L;
	@FieldMapped
	private Long pidUnitId;
	@FieldMapped
	private Long segmentId;
	@FieldMapped
	private Integer state;
	@FieldMapped
	private Integer segmentVersion;
	@FieldMapped
	private Integer segmentQueuedVersion;
	@FieldMapped
	private Integer rank;
	@FieldMapped
	private Timestamp assignedTimestamp;
	@FieldMapped
	private Integer version;

	public SegmentWithReport() {

	}

	public SegmentWithReport(Long pidUnitId, Long segmentId, Integer status,
			Integer segmentVersion, Integer segmentQueuedVersion, Integer rank,
			Timestamp assignedTimestamp, Integer version) {

		this.pidUnitId = pidUnitId;
		this.segmentId = segmentId;
		this.state = status;
		this.segmentVersion = segmentVersion;
		this.segmentQueuedVersion = segmentQueuedVersion;
		this.rank = rank;
		this.assignedTimestamp = assignedTimestamp;
		this.version = version;
	}

	/**
	 * @return Returns the assignedTimestamp.
	 */
	public Timestamp getAssignedTimestamp() {
		return assignedTimestamp;
	}

	/**
	 * @return Returns the pidUnitId.
	 */
	public Long getPidUnitId() {
		return pidUnitId;
	}

	/**
	 * @return Returns the rank.
	 */
	public Integer getRank() {
		return rank;
	}

	/**
	 * @return Returns the segmentId.
	 */
	public Long getSegmentId() {
		return segmentId;
	}

	/**
	 * @return Returns the segmentQueuedVersion.
	 */
	public Integer getSegmentQueuedVersion() {
		return segmentQueuedVersion;
	}

	/**
	 * @return Returns the segmentVersion.
	 */
	public Integer getSegmentVersion() {
		return segmentVersion;
	}

	/**
	 * @return Returns the state.
	 */
	public SegmentReportState getState() {
		SegmentReportState status;
		status = (state != null) ? SegmentReportState
				.getSegmentReportState(state) : null;
		return status;
	}

	/**
	 * @return Returns the version.
	 */
	public Integer getVersion() {
		return version;
	}

	public void setPidUnitId(Long pidUnitId) {
		this.pidUnitId = pidUnitId;
	}

	public void setSegmentId(Long segmentId) {
		this.segmentId = segmentId;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public void setSegmentVersion(Integer segmentVersion) {
		this.segmentVersion = segmentVersion;
	}

	public void setSegmentQueuedVersion(Integer segmentQueuedVersion) {
		this.segmentQueuedVersion = segmentQueuedVersion;
	}

	public void setRank(Integer rank) {
		this.rank = rank;
	}

	public void setAssignedTimestamp(Timestamp assignedTimestamp) {
		this.assignedTimestamp = assignedTimestamp;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

}
