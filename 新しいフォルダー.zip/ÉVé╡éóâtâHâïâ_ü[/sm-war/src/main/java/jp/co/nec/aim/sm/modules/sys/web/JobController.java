package jp.co.nec.aim.sm.modules.sys.web;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.nec.aim.sm.common.constant.Constants;
import jp.co.nec.aim.sm.common.constant.FeJobStatus;
import jp.co.nec.aim.sm.common.constant.JobState;
import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.common.utils.EnumUtil;
import jp.co.nec.aim.sm.common.utils.SMUtil;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.FeJobQueueEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.ContainerJob;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.FusionJob;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.JobPojo;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.TopJobQueue;
import jp.co.nec.aim.sm.modules.sys.service.JobService;
import jp.co.nec.aim.sm.modules.sys.util.UserUtils;
import jp.co.nec.aim.sm.modules.sys.web.base.BaseController;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.google.common.collect.Lists;

@Controller
@RequestMapping(value = "/jobs")
public class JobController extends BaseController {
	/** the log instance **/
	private static Logger logger = LoggerFactory.getLogger(JobController.class);

	@Autowired
	JobService jobService;


	@RequiresPermissions(Constants.PERMISSION_VIEWER)
	@RequestMapping(value = { "jobs/list", "" })
	public String listJobs(
			@RequestParam(value = "jobId", required = false) Long jobId,
			@RequestParam(value = "function", required = false) String function,
			@RequestParam(value = "status", required = false) String status,
			JobPojo job, HttpServletRequest request,
			HttpServletResponse response, Model model) {
		try {
			if (!(SMUtil.isObjectNull(job.getJobid()) || SMUtil
					.isObjectNull(job.getPriority()))) {
				logger.debug("update job {} Priority to {}",
						new Object[] { job.getJobid(), job.getPriority() });
				int result = jobService.updatePriority(job);
				if (result == 0) {
					String message = "can not find Job: Id = " + job.getJobid();
					logger.error(message);
					addMessage(model, message);
				}
			}
		} catch (Exception e) {
			String message = e.getMessage();
			logger.error(message, e);
			addMessage(model, message);
		}

		if (!SMUtil.isObjectNull(jobId))
			job.setJobid(jobId);

		if (!SMUtil.isNullOrEmpty(function))
			job.setFunctiontype(function);

		if (!SMUtil.isNullOrEmpty(status)) {
			String[] states = status.split(",");
			List<JobState> statusList = Lists.newArrayList();
			for (String state : states) {
				JobState jobState = JobState.valueOf(state);
				statusList.add(jobState);
			}
			job.setStatusList(statusList);
		}
		Page<TopJobQueue> page = jobService.findJobPage(new Page<TopJobQueue>(
				request, response), job);
		List<String> functionNameList = jobService.getAllFunctionName();
		List<String> jobStatelist = EnumUtil.getJobStatelist();
		model.addAttribute("functionnamelist", functionNameList);
		model.addAttribute("jobstatelist", jobStatelist);
		model.addAttribute("page", page);
		model.addAttribute("job", job);
		model.addAttribute("permission", UserUtils.getUser().getRoleNames());

		saveCurrentPageInfo(request, "/jobs/jobs/list", model);

		return "modules/jobs/jobslist";
	}

	@RequiresPermissions(Constants.PERMISSION_VIEWER)
	@RequestMapping(value = { "fusionjob/list", "" })
	public String listFusionJobs(
			@RequestParam(value = "jobId", required = false) Long jobId,
			FusionJob fusionjob, HttpServletRequest request,
			HttpServletResponse response, Model model) {
		if (!SMUtil.isObjectNull(jobId))
			fusionjob.setJobId(jobId);
		List<String> functionNameList = jobService.getAllFunctionName();
		model.addAttribute("functionnamelist", functionNameList);
		Page<FusionJob> page = jobService.findFusionJobPage(
				new Page<FusionJob>(request, response), fusionjob);

		model.addAttribute("page", page);
		model.addAttribute("fusionjob", fusionjob);

		saveCurrentPageInfo(request, "/jobs/fusionjob/list", model);
		return "modules/jobs/fusionjoblist";
	}

	@RequiresPermissions(Constants.PERMISSION_VIEWER)
	@RequestMapping(value = { "containerjob/list", "" })
	public String listMuJobs(
			@RequestParam(value = "fusionJobId", required = false) Long fusionJobId,
			@RequestParam(value = "mrId", required = false) Long mrId,
			@RequestParam(value = "containerJobState", required = false) String containerJobState,
			ContainerJob containerJob, HttpServletRequest request,
			HttpServletResponse response, Model model) {
		if (!SMUtil.isObjectNull(fusionJobId))
			containerJob.setFusionJobId(String.valueOf(fusionJobId));
		if (!SMUtil.isObjectNull(mrId))
			containerJob.setMrId(String.valueOf(mrId));
		if (!SMUtil.isObjectNull(containerJobState))
			containerJob.setJobState(containerJobState);
		List<String> typeMap = EnumUtil.getMuJobStatelist();
		String state = containerJob.getJobState();
		if (!SMUtil.isObjectNull(state)) {
			containerJob.setJobState(state);
		}
		Page<ContainerJob> page = jobService.findContainerJobPage(
				new Page<ContainerJob>(request, response), containerJob);
		model.addAttribute("page", page);
		model.addAttribute("containerjob", containerJob);
		model.addAttribute("typeMap", typeMap);

		saveCurrentPageInfo(request, "/jobs/containerjob/list", model);
		return "modules/jobs/containerjoblist";
	}

	@RequiresPermissions(Constants.PERMISSION_VIEWER)
	@RequestMapping(value = { "fejob/list", "" })
	public String listFEJobQueue(
			@RequestParam(value = "status", required = false) String status,
			FeJobQueueEntity fejob, HttpServletRequest request,
			HttpServletResponse response, Model model) {
		try {
			if (!(SMUtil.isObjectNull(fejob.getJobId()) || SMUtil
					.isObjectNull(fejob.getPriority()))) {
				logger.debug("update job {} Priority to {}", new Object[] {
						fejob.getJobId(), fejob.getPriority() });
				int result = jobService.updateFEPriority(fejob);
				if (result == 0) {
					String message = "Can not find Featrue Extract Job: Id = "
							+ fejob.getJobId();
					logger.error(message);
					addMessage(model, message);
				}
			}
		} catch (Exception e) {
			String message = e.getMessage();
			logger.error(message, e);
			addMessage(model, message);
		}

		if (!SMUtil.isNullOrEmpty(status)) {
			String[] states = status.split(",");
			List<FeJobStatus> statusList = Lists.newArrayList();
			for (String state : states) {
				FeJobStatus jobState = FeJobStatus.valueOf(state);
				statusList.add(jobState);
			}
			fejob.setStatusList(statusList);
		}

		Page<FeJobQueueEntity> page = jobService.findFEJobQueuePage(
				new Page<FeJobQueueEntity>(request, response), fejob);
		List<String> functionNameList = jobService.getAllFunctionName();
		List<String> jobstateList = EnumUtil.getJobStatuslist();
		model.addAttribute("functionnamelist", functionNameList);
		model.addAttribute("jobstatelist", jobstateList);
		model.addAttribute("page", page);
		model.addAttribute("fejob", fejob);
		model.addAttribute("permission", UserUtils.getUser().getRoleNames());

		saveCurrentPageInfo(request, "/jobs/fejob/list", model);
		return "modules/jobs/fejobqueuelist";
	}

	@RequiresPermissions(Constants.PERMISSION_VIEWER)
	@RequestMapping(value = { "jobresult", "" })
	public String JobResultlist(@RequestParam("clazz") String clazz,
			@RequestParam("jobId") Long jobId,
			@RequestParam("field") String field, HttpServletRequest request,
			Model model) {
		String result = this.jobService.getResultByClass(clazz, jobId, field);
		model.addAttribute("result", result);
		request.setAttribute("contentType", "text/xml");
		return "modules/jobs/jobresult";
	}

	public static void main(String[] args) {
		System.out.println(new Date().getTime());
		long epoch = System.currentTimeMillis() ;
		System.out.println(epoch);
	}
}
