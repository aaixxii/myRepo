package jp.co.nec.aim.sm.exception;

public class SMDaoException extends RuntimeException {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -335026656751093927L;

	/**
	 * @param message
	 */
	public SMDaoException(String message) {
		super(message);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public SMDaoException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * @param cause
	 */
	public SMDaoException(Throwable cause) {
		super(cause);
	}
}
