package jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping;

import static jp.co.nec.aim.sm.common.constant.SMConstant.FORMAT;

import java.io.Serializable;

import jp.co.nec.aim.sm.common.annocation.FieldMapped;
import jp.co.nec.aim.sm.common.annocation.InquiryMapping;

/**
 * The information of segment
 */
@InquiryMapping
public final class SegmentSummary implements Serializable {

	/** serialVersionUID */
	private static final long serialVersionUID = -8980569411496621366L;

	public SegmentSummary() {
	}

	public Integer getBinId() {
		return binId;
	}

	public void setBinId(Integer binId) {
		this.binId = binId;
	}

	public Long getSegId() {
		return segId;
	}

	public void setSegId(Long segId) {
		this.segId = segId;
	}

	public Double getDataRadio() {
		return dataRadio;
	}

	public void setDataRadio(Double dataRadio) {
		this.dataRadio = dataRadio;
	}

	public Double getFragmentRadio() {
		return fragmentRadio;
	}

	public void setFragmentRadio(Double fragmentRadio) {
		this.fragmentRadio = fragmentRadio;
	}

	public Long getStartId() {
		return startId;
	}

	public void setStartId(Long startId) {
		this.startId = startId;
	}

	public Long getEndId() {
		return endId;
	}

	public void setEndId(Long endId) {
		this.endId = endId;
	}

	public Integer getRecordCount() {
		return recordCount;
	}

	public void setRecordCount(int recordCount) {
		this.recordCount = recordCount;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	public void increaseVersion(int versionPara) {
		this.version += versionPara;
	}

	public Integer getReVersion() {
		return reVersion;
	}

	public void setReVersion(int reVersion) {
		this.reVersion = reVersion;
	}

	public void increaseReVersion(int reVersionPara) {
		this.reVersion += reVersionPara;
	}

	public Integer getBlCompacted() {
		return blCompacted;
	}

	public void setBlCompacted(Integer blCompacted) {
		this.blCompacted = blCompacted;
	}

	public Integer getBlunCompacted() {
		return blunCompacted;
	}

	public void setBlunCompacted(Integer blunCompacted) {
		this.blunCompacted = blunCompacted;
	}

	public boolean willbeDeleted() {
		return willbeDeleted;
	}

	public void setWillbeDeleted(boolean willbeDeleted) {
		this.willbeDeleted = willbeDeleted;
	}

	public Integer getVersionBackUp() {
		return versionBackUp;
	}

	public void setVersionBackUp(Integer versionBackUp) {
		this.versionBackUp = versionBackUp;
	}

	public Integer getReVersionBackUp() {
		return reVersionBackUp;
	}

	public void setReVersionBackUp(Integer reVersionBackUp) {
		this.reVersionBackUp = reVersionBackUp;
	}

	/**
	 * the another constructor
	 * 
	 * @param binId
	 * @param segmentId
	 * @param startId
	 * @param endId
	 * @param recordCount
	 * @param version
	 * @param reVersion
	 * @param blCompacted
	 * @param blunCompacted
	 * @param willbeDeleted
	 * @param dataRadio
	 */
	public SegmentSummary(int binId, long segmentId, long startId, long endId,
			int recordCount, int version, int reVersion, int blCompacted,
			int blunCompacted, boolean willbeDeleted, Double dataRadio) {
		this.binId = binId;
		this.segId = segmentId;
		this.startId = startId;
		this.endId = endId;
		this.recordCount = recordCount;
		this.version = version;
		this.reVersion = reVersion;
		this.versionBackUp = version;
		this.reVersionBackUp = reVersion;
		this.blCompacted = blCompacted;
		this.blunCompacted = blunCompacted;
		this.willbeDeleted = willbeDeleted;
		this.dataRadio = Double.valueOf(FORMAT.format(dataRadio));
		this.fragmentRadio = Double.valueOf(FORMAT.format(1 - dataRadio));
	}

	@FieldMapped
	private Integer binId;
	@FieldMapped
	private Long segId;
	@FieldMapped
	private Double dataRadio;
	@FieldMapped
	private Double fragmentRadio;
	@FieldMapped
	private Long startId;
	@FieldMapped
	private Long endId;
	@FieldMapped
	private Integer recordCount;
	@FieldMapped
	private Integer version;
	@FieldMapped
	private Integer reVersion;
	@FieldMapped
	private Integer blCompacted;
	@FieldMapped
	private Integer blunCompacted;
	@FieldMapped
	private boolean willbeDeleted;
	@FieldMapped
	private Integer versionBackUp;
	@FieldMapped
	private Integer reVersionBackUp;
}
