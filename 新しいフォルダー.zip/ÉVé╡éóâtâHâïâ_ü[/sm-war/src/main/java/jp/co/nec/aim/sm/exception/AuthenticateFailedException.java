package jp.co.nec.aim.sm.exception;

/**
 * Remote Connect By SSH Exception
 * 
 * @author liuyq
 */
public class AuthenticateFailedException extends RuntimeException {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -335026656751093927L;

	/**
	 * @param message
	 */
	public AuthenticateFailedException(String message) {
		super(message);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public AuthenticateFailedException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * @param cause
	 */
	public AuthenticateFailedException(Throwable cause) {
		super(cause);
	}
}
