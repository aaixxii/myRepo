package jp.co.nec.aim.sm.modules.sys.oracle.repository;

import java.util.List;

import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.common.utils.SMUtil;
import jp.co.nec.aim.sm.exception.SMServiceException;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.SegmentEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.SegmentDeletion;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.SegmentSegmentReport;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;

public class SegmentRepositoryImpl {

	@Autowired
	private SegmentRepository repository;
	private final static String segmentSegmentReportSql = "select s.segment_id as segmentId "
			+ "      ,s.container_id as containerId"
			+ "      ,s.bio_id_start as bioIdStart"
			+ "      ,s.bio_id_end as bioIdEnd"
			+ "      ,s.binary_length_compacted as binaryLengthCompacted"
			+ "      ,s.record_count as recordCount"
			+ "      ,s.version as version"
			+ "      ,s.binary_length_uncompacted as binaryLengthUncompacted"
			+ "      ,msr.mu_id as muId"
			+ "      ,msr.status as status"
			+ "      ,msr.segment_version as segmentVersion"
			+ "      ,msr.segment_queued_version as segmentQueuedVersion"
			+ "  from segments s"
			+ "      ,mu_seg_reports msr"
			+ " where s.segment_id in("
			+ "select ms.segment_id"
			+ "  from mu_segments ms"
			+ " where ms.mu_id = ?)"
			+ "   and s.segment_id = msr.segment_id" + "   and msr.mu_id = ?";

	private static String segmentForDelSql = "select SEGMENT_ID as segmentId,"
			+ " s.SEGMENT_SET_ID as segmentSetId, RECORD_COUNT as recordCount,"
			+ " BINARY_LENGTH_COMPACTED as binaryLengthCompacted,"
			+ " BINARY_LENGTH_UNCOMPACTED as binaryLengthUncompacted,"
			+ " b.BIN_ID as binId, ft.FORMAT_NAME as formatName"
			+ " from SEGMENTS s, SEGMENT_SETS ss, BINS b, FORMAT_TYPES ft"
			+ " where s.SEGMENT_SET_ID = ss.SEGMENT_SET_ID"
			+ " and ss.BIN_ID = b.BIN_ID and b.FORMAT_ID = ft.FORMAT_ID";
	
	private final static String dmsegmentReportSql = "select s.segment_id as segmentId "
			+ "      ,s.container_id as containerId"
			+ "      ,s.bio_id_start as bioIdStart"
			+ "      ,s.bio_id_end as bioIdEnd"
			+ "      ,s.binary_length_compacted as binaryLengthCompacted"
			+ "      ,s.record_count as recordCount"
			+ "      ,s.version as version"
			+ "      ,s.binary_length_uncompacted as binaryLengthUncompacted"
			+ "      ,msr.dm_id as muId"
			+ "      ,msr.status as status"
			+ "      ,msr.segment_version as segmentVersion"
			+ "      ,0 as segmentQueuedVersion"
			+ "  from segments s"
			+ "      ,dm_seg_reports msr"
			+ " where s.segment_id in("
			+ "select ms.segment_id"
			+ "  from dm_segments ms"
			+ " where ms.dm_id = ?)"
			+ "   and s.segment_id = msr.segment_id" + "   and msr.dm_id = ?";		

	public Page<SegmentEntity> findSegment(Page<SegmentEntity> page,
			SegmentEntity seg) {
		try {
			DetachedCriteria dc = getDetachedCriteria(seg);
			if (StringUtils.isBlank(page.getOrderBy())) {
				dc.addOrder(Order.asc("segmentId"));
			}
			return repository.findPage(page, dc);
		} catch (Exception ex) {
			throw new SMServiceException(ex);
		}
	}
	
	public List<SegmentEntity> findSegmentsList(Page<SegmentEntity> page,List<Long> segmentIds) {			
		try {
			DetachedCriteria dc = DetachedCriteria.forClass(SegmentEntity.class);
			if (StringUtils.isBlank(page.getOrderBy())) {
				dc.addOrder(Order.asc("segmentId"));
			}
			dc.add(Restrictions.in("segmentId", segmentIds.toArray()));
			return repository.find(dc);			
		} catch (Exception ex) {
			throw new SMServiceException(ex);
		}
	}	

	private DetachedCriteria getDetachedCriteria(SegmentEntity seg) {
		// create the DetachedCriteria instance without session
		final DetachedCriteria dc = DetachedCriteria
				.forClass(SegmentEntity.class);

		// add the segment id condition
		final Long segmentId = seg.getSegmentId();
		if (!SMUtil.isObjectNull(segmentId)) {
			dc.add(Restrictions.eq("segmentId", segmentId));
		}

		// add the segment Set id condition
		final Long containerId = seg.getContainerId();
		if (!SMUtil.isObjectNull(containerId)) {
			dc.add(Restrictions.eq("containerId", containerId));
		}

		return dc;
	}

	public List<SegmentEntity> ListSegment(SegmentEntity seg) {
		try {
			DetachedCriteria dc = getDetachedCriteria(seg);

			dc.addOrder(Order.asc("segmentId"));

			return repository.find(dc);
		} catch (Exception ex) {
			throw new SMServiceException(ex);
		}
	}

	/**
	 * get All SegmentIds
	 * 
	 * @return
	 */
	public List<Long> getAllSegmentIds() {
		DetachedCriteria dc = DetachedCriteria.forClass(SegmentEntity.class);
		dc.setProjection(Projections.property("segmentId"));
		dc.addOrder(Order.asc("segmentId"));
		return repository.findAndCast(dc);
	}

	/**
	 * get Segment And SegmentReports
	 * 
	 * @param muId
	 * @return
	 */
	public Page<SegmentSegmentReport> getSegmentSegmentReports(
			Page<SegmentSegmentReport> page, Long muId) {
		String sqlString = segmentSegmentReportSql;
		if (StringUtils.isBlank(page.getOrderBy())) {
			sqlString += " order by s.SEGMENT_ID";
		}
		return repository.findBySql(page, sqlString,
				SegmentSegmentReport.class, muId, muId);
	}
	
	public Page<SegmentSegmentReport> getDmSegmentSegmentReports(Page<SegmentSegmentReport> page, Long dmId) {
		String sqlString = dmsegmentReportSql;
		if (StringUtils.isBlank(page.getOrderBy())) {
			sqlString += " order by s.SEGMENT_ID";
			
		}
		return repository.findBySql(page, sqlString,
				SegmentSegmentReport.class, dmId, dmId);
		
	}

	/**
	 * find segment info for deletion
	 * 
	 * @param page
	 * @param seg
	 * @return
	 */
	public Page<SegmentDeletion> findSegmentForDel(Page<SegmentDeletion> page,
			SegmentEntity seg) {
		String sqlString = segmentForDelSql;
		// add the segment id condition
		final Long segmentId = seg.getSegmentId();
		if (!SMUtil.isObjectNull(segmentId)) {
			sqlString += " and SEGMENT_ID = " + segmentId;
		}

		// add the segment Set id condition
		final Long containerId = seg.getContainerId();
		if (!SMUtil.isObjectNull(containerId)) {
			sqlString += " and s.CONTAINER_ID =" + containerId;
		}

		if (StringUtils.isBlank(page.getOrderBy())) {
			sqlString += " order by SEGMENT_ID";
		}

		return repository.findBySql(page, sqlString, SegmentDeletion.class);
	}

	/**
	 * delete segments
	 * 
	 * @param binIdList
	 */
	public void deleteSegment(List<Long> binIdList) {
		for (Long binId : binIdList) {
			repository.delete(binId);
		}
	}
}
