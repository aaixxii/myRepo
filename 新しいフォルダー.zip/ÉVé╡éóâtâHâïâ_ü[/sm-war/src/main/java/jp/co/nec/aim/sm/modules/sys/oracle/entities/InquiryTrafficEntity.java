package jp.co.nec.aim.sm.modules.sys.oracle.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the INQUIRY_TRAFFIC database table.
 * 
 */
@Entity
@Table(name = "INQUIRY_TRAFFIC")
@NamedQuery(name = "InquiryTrafficEntity.findAll", query = "SELECT i FROM InquiryTrafficEntity i")
public class InquiryTrafficEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
/*	@SequenceGenerator(name = "INQUIRY_TRAFFIC_FAMILYID_GENERATOR", sequenceName = "INQUIRY_TRAFFIC", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "INQUIRY_TRAFFIC_FAMILYID_GENERATOR")*/
	@Column(name = "FAMILY_ID")
	private int familyId;

	@Column(name = "FAMILY_NAME")
	private String familyName;

	@Column(name = "JOB_EXEC_COUNT")
	private Long jobExecCount;

	@Column(name = "JOB_LIMIT_COUNT")
	private Long jobLimitCount;

	public InquiryTrafficEntity() {
	}

	public int getFamilyId() {
		return this.familyId;
	}

	public void setFamilyId(int familyId) {
		this.familyId = familyId;
	}

	public String getFamilyName() {
		return this.familyName;
	}

	public void setFamilyName(String familyName) {
		this.familyName = familyName;
	}

	public Long getJobExecCount() {
		return this.jobExecCount;
	}

	public void setJobExecCount(Long jobExecCount) {
		this.jobExecCount = jobExecCount;
	}

	public Long getJobLimitCount() {
		return this.jobLimitCount;
	}

	public void setJobLimitCount(Long jobLimitCount) {
		this.jobLimitCount = jobLimitCount;
	}

}