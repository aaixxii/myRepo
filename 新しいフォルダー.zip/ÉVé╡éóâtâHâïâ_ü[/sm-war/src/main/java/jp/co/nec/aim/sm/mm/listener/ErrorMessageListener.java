package jp.co.nec.aim.sm.mm.listener;

import java.sql.Timestamp;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;

import javax.jms.ExceptionListener;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;

import jp.co.nec.aim.baton.AimException;
import jp.co.nec.aim.baton.constant.LogKey;
import jp.co.nec.aim.baton.constant.LogType;
import jp.co.nec.aim.sm.modules.sys.postgres.entity.EventLogEntity;
import jp.co.nec.aim.sm.modules.sys.postgres.repository.EventLogRepository;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * 
 */
public class ErrorMessageListener implements MessageListener,
		ExceptionListener, SystemManagerIfc {
	private static Log log = LogFactory.getLog(ErrorMessageListener.class);
	private EventLogRepository eventLogDao;
	private MatchManagerQueueListener matchManagerQueryListener;
	private String queueId;

	@SuppressWarnings("unused")
	private ErrorMessageListener() {
	}

	public ErrorMessageListener(EventLogRepository eventLogDao,
			MatchManagerQueueListener matchManagerQueryListener, String queueId) {
		this.eventLogDao = eventLogDao;
		this.matchManagerQueryListener = matchManagerQueryListener;
		this.queueId = queueId;
	}

	public void onMessage(Message message) {
		log.debug("->onMessage()");
		log.debug("#onMessage() match managers (error) event recieved");
		if (message instanceof ObjectMessage) {
			log.debug("#onMessage() executing event message");
			final ClassLoader ctxThreadLoader = Thread.currentThread()
					.getContextClassLoader();
			try {
				ObjectMessage objectMessage = (ObjectMessage) message;
				Thread.currentThread().setContextClassLoader(
						this.getClass().getClassLoader());
				//log.info(printJMSObject(objectMessage));

				@SuppressWarnings("unchecked")
				Map<String, Object> map = (Map<String, Object>) objectMessage
						.getObject();
				Integer type = (Integer) map.get(LogKey.TYPE.getKey());

				if (type == LogType.EXCEPTION.getType()) {
					persistEventLog(map);
				}
			} catch (JMSException e) {
				log.error("#onMessage() error message listerner,"
						+ " jms failure description: " + e.toString());
				e.printStackTrace();
			} catch (Exception e) {
				log.error("#onMessage() error message listerner,"
						+ " exception description: " + e.toString());
				e.printStackTrace();
			} finally {
				Thread.currentThread().setContextClassLoader(ctxThreadLoader);
			}
			log.debug("#onMessage() finished event log execution");
		} else {
			log.warn("message is not instanceof ObjectMessage");
		}
		log.debug("<-onMessage()");
	}

	private void persistEventLog(Map<String, Object> map) {
		// AimException aimException = (AimException) map.get(LogKey.EXCEPTION
		// .getKey());

		AimException aimException = (AimException) map.get(LogKey.EXCEPTION
				.getKey());

		String reasonCode = (String) map.get(LogKey.REASON_CODE.getKey());
		EventLogEntity eventLogEntity = new EventLogEntity();
		Long muId = aimException.getMuId();
		if (muId == null) {
			eventLogEntity.setUnitId(UNKNOWN_MUID);
		} else {
			eventLogEntity.setUnitId(muId);
		}
		if (aimException.getLocalizedMessage() != null) {
			eventLogEntity.setMessage(aimException.getLocalizedMessage()
					.replace(REPLACE_CHARS[0], REPLACE_BY_CHARS[0]));
		}
		eventLogEntity.setTimestamp(new Timestamp((new Date()).getTime()));
		if (reasonCode != null) {
			if ("9".equals(reasonCode.substring(0, 1))) {
				eventLogEntity.setMessageType(EVENTCODE_EMERGENCY);
			} else if ("8".equals(reasonCode.substring(0, 1))) {
				eventLogEntity.setMessageType(EVENTCODE_ERROR);
			} else if ("5".equals(reasonCode.substring(0, 1))) {
				eventLogEntity.setMessageType(EVENTCODE_ALERT);
			} else if ("1".equals(reasonCode.substring(0, 1))) {
				eventLogEntity.setMessageType(EVENTCODE_WARN);
			} else if ("0".equals(reasonCode.substring(0, 1))) {
				eventLogEntity.setMessageType(EVENTCODE_INFO);
			} else {
				eventLogEntity.setMessageType(EVENTCODE_INFO);
			}
		} else {
			eventLogEntity.setMessageType(EVENTCODE_INFO);
		}
		eventLogEntity.setMessageCode(reasonCode);

		eventLogDao.saveAndFlush(eventLogEntity);
	}

	public String printJMSObject(ObjectMessage objectMessage) {
		StringBuilder sb = new StringBuilder("");
		try {
			sb.append("Proxy ObjectName :"
					+ objectMessage.getObject().getClass().getName() + "/n");

			@SuppressWarnings("unchecked")
			Map<String, Object> map = (Map<String, Object>) objectMessage
					.getObject();
			sb.append("Proxy#MapObject  :" + map + "/n");
			Integer type = (Integer) map.get(LogKey.TYPE.getKey());
			sb.append("Map#TypeObject :" + type + "/n");
			Iterator<Object> iter = map.values().iterator();

			while (iter.hasNext()) {
				Object obj = iter.next();
				sb.append("MapObject#Names " + obj.getClass().getName() + "/n");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return sb.toString();
	}

	public void onException(JMSException exception) {
		exception.printStackTrace();
		matchManagerQueryListener.notifyStatus(queueId, "ERROR");
		log.error("#onMessage() error message listener, message recieved, jms failure description: "
				+ exception.toString());
	}

}
