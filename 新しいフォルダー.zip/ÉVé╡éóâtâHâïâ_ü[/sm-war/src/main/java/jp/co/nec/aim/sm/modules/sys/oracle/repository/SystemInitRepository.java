package jp.co.nec.aim.sm.modules.sys.oracle.repository;

import java.util.List;

import jp.co.nec.aim.sm.common.persistence.BaseRepository;
import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.SystemInitEntity;

public interface SystemInitRepository extends
		BaseRepository<SystemInitEntity, Long> {
	/** find System Init Page **/
	public Page<SystemInitEntity> findSystemInitPage(
			Page<SystemInitEntity> page, SystemInitEntity systemInit);

	/** find System Init List **/
	public List<SystemInitEntity> findSystemInit(SystemInitEntity systemInit);

	/** update System Init **/
	public int updateSystemInit(Long initId, String value);

	/** find System Init List **/

	/** get int Property **/
	public int getIntProperty(String name);

	/** get boolean Property **/
	public boolean getBooleanProperty(String name);

	/** get String Property **/
	public String getProperty(String name);
}
