package jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping;

import java.io.Serializable;

public class DBMonitorData implements Serializable {
	private static final long serialVersionUID = -632658054059312246L;
	private String function;
	private String templateFormat;
	private Integer recordCount;

	public DBMonitorData() {
	};

	public DBMonitorData(String function, String templateFormat,
			Integer recordCount) {
		this.function = function;
		this.templateFormat = templateFormat;
		this.recordCount = recordCount;
	}

	public String getFunction() {
		return function;
	}

	public void setFunction(String function) {
		this.function = function;
	}

	public String getTemplateFormat() {
		return templateFormat;
	}

	public void setTemplateFormat(String templateFormat) {
		this.templateFormat = templateFormat;
	}

	public Integer getRecordCount() {
		return recordCount;
	}

	public void setRecordCount(Integer recordCount) {
		this.recordCount = recordCount;
	}

}
