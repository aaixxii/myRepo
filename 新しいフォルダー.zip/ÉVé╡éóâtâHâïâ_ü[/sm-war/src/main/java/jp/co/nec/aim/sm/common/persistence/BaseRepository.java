package jp.co.nec.aim.sm.common.persistence;

import java.io.Serializable;
import java.util.List;

import javax.persistence.EntityManager;

import org.apache.lucene.search.BooleanClause;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.Sort;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.search.FullTextSession;
import org.hibernate.transform.ResultTransformer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.NoRepositoryBean;

@NoRepositoryBean
public interface BaseRepository<M, ID extends Serializable> extends
		JpaRepository<M, ID> {

	/**
	 * get EntityManager
	 */
	public EntityManager getEntityManager();

	/**
	 * get session
	 */
	public Session getSession();

	/**
	 * flush
	 */
	public void flush();

	/**
	 * clear
	 */
	public void clear();

	// -------------- QL Query --------------

	/**
	 * find the entity with page
	 * 
	 * @param page
	 * @param qlString
	 * @param parameter
	 * @return
	 */
	public <E> Page<E> find(Page<E> page, String qlString, Object... parameter);

	/**
	 * QL Query
	 * 
	 * @param qlString
	 * @param parameter
	 * @return
	 */
	public <E> List<E> find(String qlString, Object... parameter);

	/**
	 * QL update
	 * 
	 * @param sqlString
	 * @param parameter
	 * @return
	 */
	public int update(String qlString, Object... parameter);

	/**
	 * create Query
	 * 
	 * @param qlString
	 * @param parameter
	 * @return Query instance
	 */
	public Query createQuery(String qlString, Object... parameter);

	// -------------- SQL Query --------------

	/**
	 * 
	 * @param page
	 * @param qlString
	 * @param parameter
	 * @return
	 */
	public <E> Page<E> findBySql(Page<E> page, String sqlString,
			Object... parameter);

	/**
	 * query with sql
	 * 
	 * @param page
	 * @param qlString
	 * @param resultClass
	 * @param parameter
	 * @return
	 */
	public <E> Page<E> findBySql(Page<E> page, String sqlString,
			Class<?> resultClass, Object... parameter);

	/**
	 * query with sql
	 * 
	 * @param sqlString
	 * @param parameter
	 * @return
	 */
	public <E> List<E> findBySql(String sqlString, Object... parameter);

	/**
	 * query with sql
	 * 
	 * @param sqlString
	 * @param resultClass
	 * @param parameter
	 * @return
	 */
	public <E> List<E> findBySql(String sqlString, Class<?> resultClass,
			Object... parameter);

	/**
	 * SQL update
	 * 
	 * @param sqlString
	 * @param parameter
	 * @return
	 */
	public int updateBySql(String sqlString, Object... parameter);

	/**
	 * create sQL query instance
	 * 
	 * @param sqlString
	 * @param parameter
	 * @return
	 */
	public Query createSqlQuery(String sqlString, Object... parameter);

	// -------------- Criteria --------------

	/**
	 * find the page
	 * 
	 * @param page
	 * @return
	 */
	public Page<M> findPage(Page<M> page);

	/**
	 * find records the with DetachedCriteria
	 * 
	 * @param page
	 * @param detachedCriteria
	 * @return Page instance
	 */
	public Page<M> findPage(Page<M> page, DetachedCriteria detachedCriteria);

	/**
	 * find records the with DetachedCriteria
	 * 
	 * @param page
	 * @param detachedCriteria
	 * @param resultTransformer
	 * @return Page instance
	 */
	public Page<M> findPage(Page<M> page, DetachedCriteria detachedCriteria,
			ResultTransformer resultTransformer);

	/**
	 * find the records with DetachedCriteria
	 * 
	 * @param detachedCriteria
	 * @return the list instance
	 */
	public List<M> find(DetachedCriteria detachedCriteria);

	public <T> List<T> findAndCast(DetachedCriteria detachedCriteria);
	/**
	 * find the records with DetachedCriteria
	 * 
	 * @param detachedCriteria
	 * @param resultTransformer
	 * @return the list instance(the records)
	 */
	public List<M> find(DetachedCriteria detachedCriteria,
			ResultTransformer resultTransformer);

	/**
	 * find the record count
	 * 
	 * @param detachedCriteria
	 * @return the record count
	 */
	public long count(DetachedCriteria detachedCriteria);

	/**
	 * create the DetachedCriteria instance without session
	 * 
	 * @param criterions
	 *            Restrictions.eq("name", value);
	 * @return DetachedCriteria instance
	 */
	public DetachedCriteria createDetachedCriteria(Criterion... criterions);

	// -------------- Hibernate search --------------

	/**
	 * get the full text session
	 */
	public FullTextSession getFullTextSession();

	/**
	 * create the index
	 */
	public void createIndex();

	/**
	 * search
	 * 
	 * @param page
	 *            page instance
	 * @param query
	 * 
	 * @param queryFilter
	 * 
	 * @param sort
	 * 
	 * @return page instance
	 */
	public Page<M> search(Page<M> page, BooleanQuery query,
			BooleanQuery queryFilter, Sort sort);

	/**
	 * getFullTextQuery
	 */
	public BooleanQuery getFullTextQuery(BooleanClause... booleanClauses);
}