package jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping;

import jp.co.nec.aim.sm.common.annocation.FieldMapped;
import jp.co.nec.aim.sm.common.annocation.InquiryMapping;

@InquiryMapping
public class CorrespondencePojo {
	@FieldMapped
	private Long muId;

	@FieldMapped
	// @ExcelField(title = "Function ID", type = 1, align = 2, sort = 10)
	private Long functionId;

	@FieldMapped
	private String eligibleFun;

	@FieldMapped
	private String binsEliFun;

	@FieldMapped
	private String funOfEliBins;

	@FieldMapped
	private String eligibleBins;

	public void setMuId(Long muId) {
		this.muId = muId;
	}

	public Long getMuId() {
		return muId;
	}

	public void setFunctionId(Long functionId) {
		this.functionId = functionId;
	}

	public Long getFunctionId() {
		return functionId;
	}

	public void setEligibleFun(String eligibleFun) {
		this.eligibleFun = eligibleFun;
	}

	public String getEligibleFun() {
		return eligibleFun;
	}

	public void setBinsEliFun(String binsEliFun) {
		this.binsEliFun = binsEliFun;
	}

	public String getBinsEliFun() {
		return binsEliFun;
	}

	public void setFunOfEliBins(String funOfEliBins) {
		this.funOfEliBins = funOfEliBins;
	}

	public String getFunOfEliBins() {
		return funOfEliBins;
	}

	public void setEligibleBins(String eligibleBins) {
		this.eligibleBins = eligibleBins;
	}

	public String getEligibleBins() {
		return eligibleBins;
	}
}
