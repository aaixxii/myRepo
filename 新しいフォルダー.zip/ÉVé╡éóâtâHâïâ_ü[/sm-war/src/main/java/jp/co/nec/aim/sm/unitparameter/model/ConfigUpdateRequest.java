package jp.co.nec.aim.sm.unitparameter.model;

import java.util.List;

public class ConfigUpdateRequest {
	List<ConfigUpdateSection> section;	
	
	
	public List<ConfigUpdateSection> getSection() {
		return section;
	}
	public void setSection(List<ConfigUpdateSection> section) {
		this.section = section;
	}
}

