package jp.co.nec.aim.sm.modules.sys.oracle.repository;

import java.util.List;

import jp.co.nec.aim.sm.common.persistence.BaseRepository;
import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.MuEligibleContainerEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.MuEligibleContainerEntityPK;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.EligibleBinsPojo;

public interface EligibleBiometricContainerRepository extends
		BaseRepository<MuEligibleContainerEntity, MuEligibleContainerEntityPK> {
	/** find Eligible Biometric Container page **/
	public Page<MuEligibleContainerEntity> findEligibleBinsPage(
			Page<MuEligibleContainerEntity> page,
			MuEligibleContainerEntity eligibleBins);

	/** find Eligible Biometric Container List **/
	public Page<EligibleBinsPojo> findEligibleBinsPage(
			Page<EligibleBinsPojo> page, EligibleBinsPojo eligibleBins);

	/** find Eligible Biometric Container page **/
	public List<MuEligibleContainerEntity> findEligibleBins(MuEligibleContainerEntity eligibleBins);

	

	/** find Eligible Biometric Container List **/
	public List<EligibleBinsPojo> findEligibleBins(EligibleBinsPojo eligibleBins);

	/** assign Match Unit Eligible Biometric Container **/
	public void assignBin(Long matchUnitId, String binIds);

	/** unAssign Match Unit Eligible Biometric Container **/
	public void unAssignBin(Long matchUnitId, String binIds);

}
