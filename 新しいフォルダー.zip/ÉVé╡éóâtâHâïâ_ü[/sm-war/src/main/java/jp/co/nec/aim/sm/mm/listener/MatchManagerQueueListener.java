package jp.co.nec.aim.sm.mm.listener;

import java.util.Map;

/**
 * 
 * 
 */
public interface MatchManagerQueueListener extends SystemManagerIfc {

	public void shutdownQueueListener();

	public void shutdownQueueNotifier();

	public void startupQueueListener();

	public void notifyStatus(String queueID, String status);

	public void startQueueNotifier();

	public Map<String, QueueInformation> getLstQueueInfo();

	public Map<String, QueueRunner> getLstThread();
}
