package jp.co.nec.aim.sm.modules.sys.service;

import java.util.Date;
import java.util.List;

import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.common.security.Digests;
import jp.co.nec.aim.sm.common.utils.Encodes;
import jp.co.nec.aim.sm.modules.sys.BaseService;
import jp.co.nec.aim.sm.modules.sys.postgres.entity.RoleEntity;
import jp.co.nec.aim.sm.modules.sys.postgres.entity.UserEntity;
import jp.co.nec.aim.sm.modules.sys.postgres.repository.RoleRepository;
import jp.co.nec.aim.sm.modules.sys.postgres.repository.UserRepository;
import jp.co.nec.aim.sm.modules.sys.security.SystemAuthorizingRealm;
import jp.co.nec.aim.sm.modules.sys.util.UserUtils;

import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.SecurityUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class UserService extends BaseService {

	public static final String HASH_ALGORITHM = "SHA-1";
	public static final int HASH_INTERATIONS = 1024;
	public static final int SALT_SIZE = 8;

	@Autowired
	private UserRepository userRepository;
	@Autowired
	private RoleRepository roleRepository;
	@Autowired
	private SystemAuthorizingRealm systemRealm;

	public UserEntity getUser(Long id) {
		return userRepository.findOne(id);
	}

	public UserEntity getUserByLoginName(String loginName) {
		return userRepository.findByLoginName(loginName);
	}

	@Transactional(readOnly = false)
	public void updateUserLoginInfo(Long id) {
		userRepository.updateLoginInfo(SecurityUtils.getSubject().getSession()
				.getHost(), new Date(), id);
	}

	public Page<UserEntity> findUser(Page<UserEntity> page, UserEntity user) {
		DetachedCriteria dc = userRepository.createDetachedCriteria();
		UserEntity currentUser = UserUtils.getUser();

		if (!currentUser.isAdmin()) {
			dc.add(Restrictions.ne("id", 1L));
		}

		if (StringUtils.isNotEmpty(user.getLoginName())) {
			dc.add(Restrictions.like("loginName", "%" + user.getLoginName()
					+ "%"));
		}
		if (StringUtils.isNotEmpty(user.getName())) {
			dc.add(Restrictions.like("name", "%" + user.getName() + "%"));
		}

		if (!StringUtils.isNotEmpty(page.getOrderBy())) {
			dc.addOrder(Order.desc("id"));
		}
		return userRepository.findPage(page, dc);
	}

	public List<RoleEntity> findAllRole() {
		DetachedCriteria dc = roleRepository.createDetachedCriteria();
		dc.createAlias("userList", "userList", JoinType.LEFT_OUTER_JOIN);
		dc.addOrder(Order.asc("name"));
		return roleRepository.find(dc);
	}

	public static String entryptPassword(String plainPassword) {
		byte[] salt = Digests.generateSalt(SALT_SIZE);
		byte[] hashPassword = Digests.sha1(plainPassword.getBytes(), salt,
				HASH_INTERATIONS);
		return Encodes.encodeHex(salt) + Encodes.encodeHex(hashPassword);
	}

	public static boolean validatePassword(String plainPassword, String password) {
		byte[] salt = Encodes.decodeHex(password.substring(0, 16));
		byte[] hashPassword = Digests.sha1(plainPassword.getBytes(), salt,
				HASH_INTERATIONS);
		return password.equals(Encodes.encodeHex(salt)
				+ Encodes.encodeHex(hashPassword));
	}

	@Transactional(readOnly = false)
	public void saveUser(UserEntity user) {
		userRepository.clear();
		userRepository.save(user);
		systemRealm.clearAllCachedAuthorizationInfo();
	}

	@Transactional(readOnly = false)
	public void deleteUser(Long id) {
		userRepository.deleteById(id);
	}

	@Transactional(readOnly = false)
	public void updatePasswordById(Long id, String loginName, String newPassword) {
		userRepository.updatePasswordById(entryptPassword(newPassword), id);
		systemRealm.clearCachedAuthorizationInfo(loginName);
	}
}
