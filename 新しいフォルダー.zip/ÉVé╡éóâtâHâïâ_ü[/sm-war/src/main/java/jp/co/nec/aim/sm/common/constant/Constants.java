package jp.co.nec.aim.sm.common.constant;

public class Constants {
	public static final String PERMISSION_ADMIN = "Administrator";
	public static final String PERMISSION_USER = "Operator";
	public static final String PERMISSION_VIEWER = "Viewer";

	public static final int MAX_PAGE_RECORD_NUM = 500;
	public static final int DEFAULT_PAGE_RECORD_NUM = 10;
	
	public static final int HTTP_CLIENT_TIMEOUT = 5000;
	public static final int QUEUE_FILE_INTERVAL= 10000;
	
	public static final int CHART_IMAAGE_WIDTH = 750;
	public static final int CHART_IMAAGE_HEIGHT = 500;
}
