package jp.co.nec.aim.sm.modules.sys.postgres.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "\"USER_PRIVILEDGES\"", schema = "public")
public class UserPriviledge {

	/**
	 * @return the userId
	 */
	public Long getUserId() {
		return userId;
	}

	/**
	 * @param userId
	 *            the userId to set
	 */
	public void setUserId(Long userId) {
		this.userId = userId;
	}

	/**
	 * @return the priviledgeId
	 */
	public Long getPriviledgeId() {
		return priviledgeId;
	}

	/**
	 * @param priviledgeId
	 *            the priviledgeId to set
	 */
	public void setPriviledgeId(Long priviledgeId) {
		this.priviledgeId = priviledgeId;
	}

	@SequenceGenerator(name = "seq_stat", sequenceName = "userPriviledge_seq_id")
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_stat")
	@Column(name = "\"USER_PRIVILEDGE_ID\"")
	private Long userPriviledgeId;

	@Column(name = "\"USER_ID\"")
	private Long userId;

	@Column(name = "\"PRIVILEDGE_ID\"")
	private Long priviledgeId;
}
