package jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping;

import jp.co.nec.aim.sm.common.annocation.FieldMapped;
import jp.co.nec.aim.sm.common.annocation.InquiryMapping;

@InquiryMapping
public class ScopePojo {
	@FieldMapped
	private Long scopeId;

	@FieldMapped
	private String binIds;

	public void setScopeId(Long scopeId) {
		this.scopeId = scopeId;
	}

	public Long getScopeId() {
		return scopeId;
	}

	public void setBinIds(String binIds) {
		this.binIds = binIds;
	}

	public String getBinIds() {
		return binIds;
	}
}
