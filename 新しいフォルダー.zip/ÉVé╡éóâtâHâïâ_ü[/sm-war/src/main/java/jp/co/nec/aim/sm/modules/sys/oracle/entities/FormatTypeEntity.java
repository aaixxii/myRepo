package jp.co.nec.aim.sm.modules.sys.oracle.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The persistent class for the FORMAT_TYPES database table.
 * 
 */
@Entity
@Table(name = "FORMAT_TYPES")
public class FormatTypeEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "FORMAT_ID")
	private long formatId;

	private String details;

	@Column(name = "FORMAT_NAME")
	private String formatName;

	public FormatTypeEntity() {
	}

	public long getFormatId() {
		return this.formatId;
	}

	public void setFormatId(long formatId) {
		this.formatId = formatId;
	}

	public String getDetails() {
		return this.details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

	public String getFormatName() {
		return this.formatName;
	}

	public void setFormatName(String formatName) {
		this.formatName = formatName;
	}

}