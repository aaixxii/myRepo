package jp.co.nec.aim.sm.mm.listener;


/**
 * MMQueueListener instance memory storage
 */
public final class MMQueueListener {

	private static MMQueueListener instance;

	private MMQueueListener() {
	}

	public static synchronized MMQueueListener getInstance() {
		if (instance == null) {
			instance = new MMQueueListener();
		}
		return instance;
	}

	private MatchManagerQueueListener listener;

	/**
	 * getListener
	 * 
	 * @return
	 */
	public MatchManagerQueueListener getListener() {
		return listener;
	}

	/**
	 * setListener
	 * 
	 * @param listener
	 */
	public void setListener(MatchManagerQueueListener listener) {
		this.listener = listener;
	}
}
