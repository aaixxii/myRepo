package jp.co.nec.aim.sm.modules.sys.web.register;

import java.io.IOException;

import jp.co.nec.aim.message.proto.AIMEnumTypes.ComponentType;
import jp.co.nec.aim.message.proto.AIMMessages.PBComponentInfo;
import jp.co.nec.aim.message.proto.AIMMessages.PBEnterResponse;
import jp.co.nec.aim.message.proto.AIMMessages.PBExitRequest;
import jp.co.nec.aim.message.proto.AIMMessages.PBHeartBeatResponse;
import jp.co.nec.aim.sm.common.constant.SMConstant;
import jp.co.nec.aim.sm.common.httpclient.CommonPost;
import jp.co.nec.aim.sm.common.httpclient.HttpResponseInfo;
import jp.co.nec.aim.sm.common.properties.ApplicationProperties;
import jp.co.nec.aim.sm.common.properties.MMProperties;
import jp.co.nec.aim.sm.common.properties.SMProperties;
import jp.co.nec.aim.sm.common.utils.SMUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RegisterRequest {

	/**
	 * SM Host Name
	 */
	private final static String smHostName = SMProperties.getSmIp();
	/**
	 * SM Port No
	 */
	private final static String smPortNo = SMProperties.getSmPort();

	/**
	 * SM UniqueId
	 */
	private final static String smUniqueId = "SM:" + smHostName;
	/**
	 * SM ContactURL
	 */
	private final static String smContactURL = "http://" + smHostName + ":"
			+ smPortNo + "/systemmanager";
	/**
	 * SM　Version
	 */
	private final static String smVersion = ApplicationProperties
			.getSmVersion();
	/**
	 * mm Host Name
	 */
	private final static String mmHostName = MMProperties.getMMIp();

	/**
	 * mm Port No
	 */
	private final static String mmPortNo = MMProperties.getMMPort();

	/**
	 * mm Context
	 */
	private final static String mmContext = MMProperties.getMMContext();

	/**
	 * mm Enter Command
	 */
	private final static String mmEnterCommand = MMProperties.getMMEnter();
	/**
	 * mm Exit Command
	 */
	private final static String mmExitCommand = MMProperties.getMMExit();
	/**
	 * mm Heartbeat Command
	 */
	private final static String mmHeartbeatCommand = MMProperties
			.getMMHeartbeat();

	private final static String postURL = "http://" + mmHostName + ":"
			+ mmPortNo + "/" + mmContext;

	private static Logger log = LoggerFactory.getLogger(RegisterRequest.class);

	/**
	 * create ComponentInfo instance
	 * 
	 * @return the instance of PBComponentInfo
	 */
	public PBComponentInfo createComponentInfo() {
		final PBComponentInfo.Builder info = PBComponentInfo.newBuilder();
		info.setComponent(ComponentType.SYSTEM_MANAGER); // SYSTEM_MANAGER
		info.setUniqueId(smUniqueId); // uniqueId
		info.setContactUrl(smContactURL); // contactURL
		info.setVersion(smVersion); // version
		// segmentMapChanged is always false when enter
		info.getResourceInfoBuilder().setSegmentMapChanged(false);
		return info.build();
	}

	/**
	 * send Enter to MM
	 * 
	 * @return SM id
	 */
	public Long sendEnter() {
		final PBComponentInfo info = createComponentInfo();
		final String url = postURL + mmEnterCommand;
		try {
			CommonPost commonPost = new CommonPost(url, info.toByteArray(),
					"sendEnter");
			HttpResponseInfo response = commonPost.postContext();
			if (response.isOK()) {
				if (log.isDebugEnabled()) {
					log.debug("Successful enter() call" + url);
				}
				PBEnterResponse enterResponse = PBEnterResponse
						.parseFrom(response.getBytes());

				if (SMUtil.isObjectNull(enterResponse)) {
					SMConstant.setSM_ID(null);
					return null;
				}
				SMConstant.setSM_ID(enterResponse.getId());
				return enterResponse.getId();
			} else {
				log.error("Bad HTTP return code from MM: "
						+ response.getStatusCode());
			}
		} catch (IOException e) {
			log.error("IOException in SM sendHeartbeat", e);
		} catch (Exception e) {
			log.error("Exception in SM sendHeartbeat", e);
		}
		return null;
	}

	/**
	 * send the heartBeat to MM
	 * 
	 * @return SM id
	 */
	public Long sendHeartbeat() {
		final String url = postURL + mmHeartbeatCommand;
		final PBComponentInfo info = createComponentInfo();

		try {
			CommonPost commonPost = new CommonPost(url, info.toByteArray(),
					"sendHeartbeat");
			HttpResponseInfo httpResponse = commonPost.postContext();

			if (httpResponse.isOK()) {
				if (log.isDebugEnabled()) {
					log.debug("Successful heartbeat() call" + url);
				}
				PBHeartBeatResponse response = PBHeartBeatResponse
						.parseFrom(httpResponse.getBytes());

				if (response.getWrongState()) {
					log.error("Received WRONG STATE error, re-entering...");
					SMConstant.setSM_ID(null);
					return null;
				}

				return SMConstant.getSM_ID();
			} else {
				log.error("Bad HTTP return code from MM: "
						+ httpResponse.getStatusCode());
			}
			return SMConstant.getSM_ID();
		} catch (IOException e) {
			log.error("IOException in SM sendHeartbeat", e);
		} catch (Exception e) {
			log.error("Exception in SM sendHeartbeat", e);
		}
		return null;
	}

	/**
	 * send Exit to MM
	 */
	public void sendExit() {
		final String url = postURL + mmExitCommand;
		PBExitRequest.Builder builder = PBExitRequest.newBuilder();
		builder.setComponent(ComponentType.SYSTEM_MANAGER);
		builder.setId(SMConstant.getSM_ID());
		CommonPost commonPost = new CommonPost(url, builder.build()
				.toByteArray(), "sendExit");
		HttpResponseInfo responseInfo = commonPost.postContext();
		if (responseInfo.isOK()) {
			log.info("Successful Exit() call " + url);
		} else {
			log.error("Bad HTTP return code from MM: "
					+ responseInfo.getStatusCode());
		}
		return;
	}
}
