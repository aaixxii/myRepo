package jp.co.nec.aim.sm.modules.sys.oracle.repository;

import java.util.List;

import jp.co.nec.aim.sm.common.persistence.BaseRepository;
import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.SegmentEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.SegmentSegmentReport;

public interface SegmentRepository extends BaseRepository<SegmentEntity, Long> {
	public Page<SegmentEntity> findSegment(Page<SegmentEntity> page,
			SegmentEntity seg);
	
	public Page<SegmentSegmentReport> getSegmentSegmentReports(
			Page<SegmentSegmentReport> page, Long muId);
	
	public Page<SegmentSegmentReport> getDmSegmentSegmentReports(
			Page<SegmentSegmentReport> page, Long dmId);
	
	public List<SegmentEntity> findSegmentsList(Page<SegmentEntity> page,List<Long> segmentIds);
}
