package jp.co.nec.aim.sm.modules.sys.oracle.repository;

import java.util.List;

import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.common.utils.SMUtil;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.PersonBiometricEntity;

import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;

public class PersonBiometricsRepositoryImpl {

	@Autowired
	PersonBiometricsRepository repository;

	private DetachedCriteria getDetachedCriteria(PersonBiometricEntity personbio) {
		DetachedCriteria dc = DetachedCriteria
				.forClass(PersonBiometricEntity.class);

		String externalId = personbio.getExternalId();
		if (StringUtils.isNotBlank(externalId)) {
			// dc.add(Restrictions.eq("externalId", externalId));
			dc.add(Restrictions.ge("externalId", externalId));
		}

		Long biometricId = personbio.getBiometricsId();
		if (!SMUtil.isObjectNull(biometricId)) {
			dc.add(Restrictions.ge("biometricId", biometricId));
		}

		return dc;
	}

	public Page<PersonBiometricEntity> findPersonBiometricsPage(
			Page<PersonBiometricEntity> page, PersonBiometricEntity personbio) {
		DetachedCriteria dc = getDetachedCriteria(personbio);
		if (!StringUtils.isNotBlank(page.getOrderBy())) {
			dc.addOrder(Order.asc("biometricId"));
		}
		return repository.findPage(page, dc);
	}

	public List<PersonBiometricEntity> ListPersonBiometrics(
			PersonBiometricEntity personbio) {
		DetachedCriteria dc = getDetachedCriteria(personbio);
		dc.addOrder(Order.asc("biometricId"));
		return repository.find(dc);
	}

	// public List<CandidateIdsKey> getCandidateIds(Set<Long> bioIds) {
	// String sql = "SELECT biometrics_id as bioId, bin_id as binId,"
	// + " external_id as externalId, event_id as eventId"
	// + " FROM person_biometrics where biometrics_id IN (";
	//
	// StringBuffer sb = new StringBuffer();
	// Object[] bioIdsArray = bioIds.toArray();
	// for (int i = 0; i < bioIdsArray.length; i++) {
	// sb.append(bioIdsArray[i]);
	// if (i < bioIdsArray.length - 1) {
	// sb.append(",");
	// }
	// }
	// sql += sb.toString() + ")";
	//
	// return repository.findBySql(sql, CandidateIdsKey.class);
	// }
}
