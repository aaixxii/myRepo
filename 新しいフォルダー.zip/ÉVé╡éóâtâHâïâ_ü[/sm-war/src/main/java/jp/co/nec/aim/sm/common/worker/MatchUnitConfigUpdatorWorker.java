package jp.co.nec.aim.sm.common.worker;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

import jp.co.nec.aim.message.proto.AIMMessages.PBConfigUpdateItem;
import jp.co.nec.aim.message.proto.AIMMessages.PBConfigUpdateRequest;
import jp.co.nec.aim.message.proto.AIMMessages.PBConfigUpdateSection;
import jp.co.nec.aim.sm.common.async.agent.AsyncAgent;
import jp.co.nec.aim.sm.common.properties.MMProperties;
import jp.co.nec.aim.sm.common.utils.SMUtil;
import jp.co.nec.aim.sm.unitparameter.model.ConfigUpdateItem;
import jp.co.nec.aim.sm.unitparameter.model.ConfigUpdateRequest;
import jp.co.nec.aim.sm.unitparameter.model.ConfigUpdateSection;
import jp.co.nec.aim.sm.unitparameter.model.MatchUnitConfig;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.ByteArrayRequestEntity;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.RequestEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * This class is the worker of MatchUnitConfigUpdate execution <br>
 * 
 * @author jinxl
 * 
 */
public class MatchUnitConfigUpdatorWorker extends AbstractWorker {

	/** the log instance **/
	private static Logger logger = LoggerFactory
			.getLogger(MatchUnitConfigUpdatorWorker.class);
	private final static int CORRECT_PARA_NUMBER = 3;
	private String matchunitkey;
	private String ipAndPort;
	private MatchUnitConfig matchUnitConfig;
	private HttpClient httpclient = null;
	private PostMethod post = null;
	private StringBuffer message;
	private boolean isMR;
	private String urlName;

	public MatchUnitConfigUpdatorWorker(AsyncAgent agent) {
		super(agent);
		final Object[] paras = agent.getParameters();
		matchUnitConfig = SMUtil.cast(paras[0]);
		ipAndPort = getIpAndPort(matchUnitConfig.getIpAddress());
		message = SMUtil.cast(paras[1]);
		this.isMR = SMUtil.cast(paras[2]);
		if (isMR) {
			urlName = MMProperties.getMRUpdateConfig();
		} else {
			urlName = MMProperties.getMUUpdateConfig();
		}
	}

	@Override
	protected void checkParameter(Object[] paras)
			throws IllegalArgumentException {
		if (SMUtil.isNullOrEmpty(paras)) {
			throw new IllegalArgumentException("the parameter is incorrect..");
		}

		if (paras.length != CORRECT_PARA_NUMBER) {
			throw new IllegalArgumentException("the parameter length is not "
					+ CORRECT_PARA_NUMBER + "..");
		}
	}

	@Override
	protected Object doTask(Object[] paras) throws Exception {
		connectIp();
		String message = postConfigContext();
		closeConnect();
		return message;
	}

	/**
	 * Connect to MU IP
	 */
	public void connectIp() {
		httpclient = new HttpClient();
		String postUrl = "http://" + ipAndPort + urlName;
		logger.info("MU Configuration Post Location : " + postUrl);
		post = new PostMethod(postUrl);
	}

	/**
	 * Close the Connection
	 */
	public void closeConnect() {
		if (post != null)
			post.releaseConnection();
	}

	/**
	 * Integrate xml to MU
	 * 
	 * @param matchUnitConfigList
	 * @return
	 */
	public String postConfigContext() {
		PBConfigUpdateRequest request = convertJavaBeanToProtobuf(matchUnitConfig
				.getMuConfigurations());
		logger.info("POST protobuf message=" + request.toString());
		return postExecute(request.toByteArray());
	}

	/**
	 * 
	 */
	public PBConfigUpdateRequest convertJavaBeanToProtobuf(
			ConfigUpdateRequest request) {
		PBConfigUpdateRequest.Builder builder = PBConfigUpdateRequest
				.newBuilder();
		for (ConfigUpdateSection section : request.getSection()) {
			PBConfigUpdateSection.Builder configSection = PBConfigUpdateSection
					.newBuilder();
			configSection.setName(section.getName());
			for (ConfigUpdateItem item : section.getItems()) {
				PBConfigUpdateItem.Builder configItem = PBConfigUpdateItem
						.newBuilder();
				configItem.setKey(item.getKey());
				configItem.setValue(item.getValue());
				configSection.addItems(configItem);
			}
			builder.addSection(configSection);
		}
		return builder.build();
	}

	/**
	 * Execute post operation
	 * 
	 * @param requestString
	 */
	public String postExecute(byte[] requestByte) {

		final RequestEntity requestEntity;
		try {
			requestEntity = new ByteArrayRequestEntity(requestByte);
			post.setRequestEntity(requestEntity);
			int status = httpclient.executeMethod(post);
			if (status == HttpStatus.SC_OK
					|| status == HttpStatus.SC_NOT_MODIFIED) {

				// InputStream is = post.getResponseBodyAsStream();
				//
				// PBConfigUpdateResponse response = PBConfigUpdateResponse
				// .parseFrom(is);
				// if (null != response) {
				// if (response.getErrorsList().isEmpty()) {
				//
				// } else {
				// StringBuffer msg = null;
				// for (PBConfigUpdateErrorInfo errorInfo : response
				// .getErrorsList()) {
				// msg.append(String.format("level:%s,message=%s",
				// errorInfo.getLevel(),
				// errorInfo.getMessage()));
				// }
				// message.append(msg.toString());
				// return String.format(FailedMsgBoxInfo, matchunitkey,
				// ipAndPort);
				// }
				// }

				message.append(String.format(SuccessMsgBoxInfo, matchunitkey,
						ipAndPort));
				return String
						.format(SuccessMsgBoxInfo, matchunitkey, ipAndPort);
			} else {
				message.append(String.format(FailedMsgBoxInfo, matchunitkey,
						ipAndPort));
				return String.format(FailedMsgBoxInfo, matchunitkey, ipAndPort);
			}
		} catch (UnsupportedEncodingException e) {
			message.append(String.format(FailedMsgBoxInfo, matchunitkey, null));
			logger.error(String.format(FailedMsgBoxInfo, matchunitkey, null), e);

		} catch (HttpException e) {
			message.append(String.format(FailedMsgBoxInfo, matchunitkey, null));
			logger.error(String.format(FailedMsgBoxInfo, matchunitkey, null), e);
		} catch (IOException e) {
			message.append(String.format(FailedMsgBoxInfo, matchunitkey, null));
			e.printStackTrace();
			logger.error(String.format(FailedMsgBoxInfo, matchunitkey, null), e);
		}
		return String.format(FailedMsgBoxInfo, matchunitkey, null);
	}

	/**
	 * Success Msg
	 */
	private static String SuccessMsgBoxInfo = "SUCCESS|Matchunit parameter successfully submitted, [Matchunit= %s"
			+ " Matchunit IpAddress= %s" + " Response Message= SUCCESS]";

	/**
	 * Failed Msg
	 */
	private static String FailedMsgBoxInfo = "FAILED|Failed to submit parameters, [Matchunit= %s"
			+ " Matchunit IpAddress= %s" + " Response Message= FAILED]";

	/**
	 * get ip and port
	 * 
	 * @param matchunitkey
	 * @return
	 */
	private String getIpAndPort(String matchunitkey) {
		final int firstidx = matchunitkey.indexOf("(");
		final int lastidx = matchunitkey.lastIndexOf(")");
		return matchunitkey.substring(firstidx + 1, lastidx);
	}
}
