package jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping;

import jp.co.nec.aim.sm.common.annocation.FieldMapped;
import jp.co.nec.aim.sm.common.annocation.InquiryMapping;

@InquiryMapping
public class SegmentDeletion {

	@FieldMapped
	private Long segmentId;

	@FieldMapped
	private Long segmentSetId;

	@FieldMapped
	private Integer recordCount;

	@FieldMapped
	private Integer binaryLengthCompacted;

	@FieldMapped
	private Integer binaryLengthUncompacted;

	@FieldMapped
	private Long binId;

	@FieldMapped
	private String formatName;

	public void setSegmentId(Long segmentId) {
		this.segmentId = segmentId;
	}

	public Long getSegmentId() {
		return segmentId;
	}

	public void setSegmentSetId(Long segmentSetId) {
		this.segmentSetId = segmentSetId;
	}

	public Long getSegmentSetId() {
		return segmentSetId;
	}

	public void setRecordCount(Integer recordCount) {
		this.recordCount = recordCount;
	}

	public Integer getRecordCount() {
		return recordCount;
	}

	public void setBinaryLengthCompacted(Integer binaryLengthCompacted) {
		this.binaryLengthCompacted = binaryLengthCompacted;
	}

	public Integer getBinaryLengthCompacted() {
		return binaryLengthCompacted;
	}

	public void setBinaryLengthUncompacted(Integer binaryLengthUncompacted) {
		this.binaryLengthUncompacted = binaryLengthUncompacted;
	}

	public Integer getBinaryLengthUncompacted() {
		return binaryLengthUncompacted;
	}

	public void setBinId(Long binId) {
		this.binId = binId;
	}

	public Long getBinId() {
		return binId;
	}

	public void setFormatName(String formatName) {
		this.formatName = formatName;
	}

	public String getFormatName() {
		return formatName;
	}

}
