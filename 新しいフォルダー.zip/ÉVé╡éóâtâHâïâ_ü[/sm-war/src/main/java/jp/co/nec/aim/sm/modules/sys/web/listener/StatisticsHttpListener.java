package jp.co.nec.aim.sm.modules.sys.web.listener;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.nec.aim.sm.modules.sys.postgres.entity.JobStatistics;
import jp.co.nec.aim.sm.modules.sys.service.JobStatisticsService;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

/**
 * Receives Match unit statistics data file and record table.
 * 
 */
public class StatisticsHttpListener extends HttpServlet {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -5628270623127489524L;
	private static Logger log = Logger.getLogger(StatisticsHttpListener.class);
	private static final String FILL_ZERO = "0";
	private static final Integer MILLISECONDS_IN_SECOND = 1000;
	private static final Integer SECONDS_IN_MINUTE = 60;
	private static final Integer MINUTES_IN_HOUR = 60;

	public StatisticsHttpListener() {
		super();
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		ApplicationContext applicationContext = WebApplicationContextUtils
				.getWebApplicationContext(this.getServletContext());
		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(
					request.getInputStream()));
			String line;

			/** Validating received data */
			while ((line = br.readLine()) != null) {
				line = line + "~";
				String splitColumnValues[] = line.split(",");
				if (splitColumnValues.length < 17) {
					for (int c = splitColumnValues.length; c < 17; c++) {
						line = line + ",0";
					}
					splitColumnValues = line.split(",");
				}

				if ("".equals(splitColumnValues[2])) {
					splitColumnValues[2] = FILL_ZERO;
				}
				if ("".equals(splitColumnValues[3])) {
					splitColumnValues[3] = FILL_ZERO;
				}
				if ("".equals(splitColumnValues[6])) {
					splitColumnValues[6] = FILL_ZERO;
				} else {

					/** Conversion of time to milliseconds */
					splitColumnValues[6] = splitColumnValues[6].replace(".",
							":");
					String splitValues[] = splitColumnValues[6].split(":");

					if (splitValues[splitValues.length - 1].length() == 3) {
						int ms = Integer
								.parseInt(splitValues[splitValues.length - 1]);
						int ss = Integer
								.parseInt(splitValues[splitValues.length - 2])
								* MILLISECONDS_IN_SECOND;
						int mm = Integer
								.parseInt(splitValues[splitValues.length - 3])
								* SECONDS_IN_MINUTE * MILLISECONDS_IN_SECOND;
						int hh = Integer
								.parseInt(splitValues[splitValues.length - 4])
								* MINUTES_IN_HOUR * SECONDS_IN_MINUTE * 1000;
						int totalms = ms + ss + mm + hh;
						splitColumnValues[6] = "" + totalms;
					} else {
						splitColumnValues[6] = FILL_ZERO;
					}
				}

				if ("".equals(splitColumnValues[7])) {
					splitColumnValues[7] = FILL_ZERO;
				}
				if ("".equals(splitColumnValues[8])) {
					splitColumnValues[8] = FILL_ZERO;
				}
				if ("".equals(splitColumnValues[10])) {
					splitColumnValues[10] = FILL_ZERO;
				}
				if ("".equals(splitColumnValues[11])) {
					splitColumnValues[11] = FILL_ZERO;
				}
				if ("".equals(splitColumnValues[12])) {
					splitColumnValues[12] = FILL_ZERO;
				}
				if ("".equals(splitColumnValues[13])) {
					splitColumnValues[13] = FILL_ZERO;
				}
				if ("".equals(splitColumnValues[14])) {
					splitColumnValues[14] = FILL_ZERO;
				}
				if ("".equals(splitColumnValues[15])) {
					splitColumnValues[15] = FILL_ZERO;
				}
				if ("".equals(splitColumnValues[16])) {
					splitColumnValues[16] = FILL_ZERO;
				}
				splitColumnValues[17] = splitColumnValues[17].substring(0,
						(splitColumnValues[17].length() - 1));
				if ("".equals(splitColumnValues[17])) {
					splitColumnValues[17] = FILL_ZERO;
				}

				JobStatisticsService service = (JobStatisticsService) applicationContext
						.getBean("jobStatisticsService");

				saveAndFlush(service, splitColumnValues);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		log
				.info("StatisticsHttpListener:doPost(), mu statistics file has been saved successfully");
		response.getWriter().println("SUCCESS");

	}

	public void saveAndFlush(JobStatisticsService service,
			String splitColumnValues[]) throws ParseException {

		JobStatistics jobStatistics = new JobStatistics();
		jobStatistics.setMuid(Integer.parseInt(splitColumnValues[0]));
		jobStatistics.setFunction(splitColumnValues[1]);
		jobStatistics.setSegmentId(Integer.parseInt(splitColumnValues[2]));
		jobStatistics.setJobCount(Integer.parseInt(splitColumnValues[3]));

		/** Sample Date Format: 2010/03/17 16:12:50.959 */
		DateFormat formatter = new SimpleDateFormat("yyyy/MM/dd kk:mm:ss.SSS");
		Date date = (Date) formatter.parse(splitColumnValues[4]);
		Timestamp startTime = new Timestamp(date.getTime());

		jobStatistics.setStartTime(startTime);
		date = (Date) formatter.parse(splitColumnValues[5]);
		Timestamp endTime = new Timestamp(date.getTime());
		jobStatistics.setEndTime(endTime);
		jobStatistics.setAvgOfElaps(Integer.parseInt(splitColumnValues[6]));
		jobStatistics.setAmr(Double.parseDouble(splitColumnValues[7]));
		jobStatistics.setAnf(Double.parseDouble(splitColumnValues[8]));
		jobStatistics.setCardQualityType(splitColumnValues[9]);
		jobStatistics.setCardQualityUnder100(Integer
				.parseInt(splitColumnValues[10]));
		jobStatistics.setCardQualityUnder200(Integer
				.parseInt(splitColumnValues[11]));
		jobStatistics.setCardQualityUnder300(Integer
				.parseInt(splitColumnValues[12]));
		jobStatistics.setCardQualityUnder400(Integer
				.parseInt(splitColumnValues[13]));
		jobStatistics.setCardQualityUnder500(Integer
				.parseInt(splitColumnValues[14]));
		jobStatistics.setCardQualityUnder600(Integer
				.parseInt(splitColumnValues[15]));
		jobStatistics.setCardQualityUnder700(Integer
				.parseInt(splitColumnValues[16]));
		jobStatistics.setCardQualityUnder800(Integer
				.parseInt(splitColumnValues[17]));

		service.saveAndFlush(jobStatistics);
	}
}
