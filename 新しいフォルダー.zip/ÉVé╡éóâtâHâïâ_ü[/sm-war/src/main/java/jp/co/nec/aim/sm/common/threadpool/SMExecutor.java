package jp.co.nec.aim.sm.common.threadpool;

import java.util.concurrent.Executor;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.TimeUnit;

/**
 * the interface of SMExecutor
 * 
 * @author liuyq
 * 
 */
public interface SMExecutor extends Executor {

	/**
	 * Executes the given command at some time in the future. The command may
	 * execute in a new thread, in a pooled thread, or in the calling thread, at
	 * the discretion of the <tt>Executor</tt> implementation. If no threads are
	 * available, it will be added to the work queue. If the work queue is full,
	 * the system will wait for the specified time and it throw a
	 * RejectedExecutionException if the queue is still full after that.
	 * 
	 * @param command
	 *            the runnable task
	 * @throws RejectedExecutionException
	 *             if this task cannot be accepted for execution - the queue is
	 *             full
	 * @throws NullPointerException
	 *             if command or unit is null
	 */
	public void execute(Runnable command, long timeout, TimeUnit unit);

	/**
	 * {@inheritDoc}
	 */
	public void execute(Runnable command);

	/**
	 * get thread pool max threads
	 * 
	 * @return max threads
	 */
	public int getMaxThreads();

	/**
	 * Returns the approximate number of threads that are actively executing
	 * tasks.
	 * 
	 * @return the number of threads
	 */
	public int getActiveCount();

	/**
	 * Returns the approximate total number of tasks that have completed
	 * execution. Because the states of tasks and threads may change dynamically
	 * during computation, the returned value is only an approximation, but one
	 * that does not ever decrease across successive calls.
	 * 
	 * @return the number of tasks
	 */
	public long getCompletedTaskCount();

	/**
	 * Stop the thread pool
	 */
	public void stopInternal();

	/**
	 * contextStopping
	 */
	public void contextStopping();

}
