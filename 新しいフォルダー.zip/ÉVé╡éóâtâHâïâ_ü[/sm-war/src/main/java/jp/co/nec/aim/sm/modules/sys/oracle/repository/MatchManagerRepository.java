package jp.co.nec.aim.sm.modules.sys.oracle.repository;

import jp.co.nec.aim.sm.common.persistence.BaseRepository;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.MatchManagerEntity;

public interface MatchManagerRepository extends
		BaseRepository<MatchManagerEntity, Long> {
	
}
