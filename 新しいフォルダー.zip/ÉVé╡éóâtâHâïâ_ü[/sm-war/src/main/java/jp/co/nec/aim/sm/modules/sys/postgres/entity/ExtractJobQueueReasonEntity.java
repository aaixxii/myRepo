package jp.co.nec.aim.sm.modules.sys.postgres.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author nbhupendra
 */

@Entity
@Table(name = "\"EXTRACT_JOB_QUEUE_REASON\"", schema = "public")
// @Table(name = "\"EXTRACT_JOB_QUEUE_REASON\"")
public class ExtractJobQueueReasonEntity {
	private Long id;
	private String reason;
	private Long muId;
	private Timestamp timeFailed;
	private String extractJobQueueId;

	/* private ExtractJobQueueEntity job; */

	public String toString() {
		return reason;
	}

	@Id
	@Column(name = "\"FAILURE_ID\"")
	public long getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	@Column(name = "\"MU_ID\"")
	public long getMuId() {
		return muId;
	}

	public void setMuId(long muId) {
		this.muId = muId;
	}

	@Column(name = "\"REASON\"")
	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	@Column(name = "\"FAILURE_TIMESTAMP\"")
	public Timestamp getTimeFailed() {
		return timeFailed;
	}

	public void setTimeFailed(Timestamp timeFailed) {
		this.timeFailed = timeFailed;
	}

	/**
	 * @return the extractJobQueueId
	 */
	@Column(name = "\"EXTRACT_JOB_QUEUE_ID\"")
	public String getExtractJobQueueId() {
		return extractJobQueueId;
	}

	/**
	 * @param extractJobQueueId
	 *            the extractJobQueueId to set
	 */
	public void setExtractJobQueueId(String extractJobQueueId) {
		this.extractJobQueueId = extractJobQueueId;
	}

	/*
	 * @ManyToOne
	 * 
	 * @JoinColumn(name = "EXTRACT_JOB_QUEUE_ID", nullable = false) public
	 * ExtractJobQueueEntity getJob() { return job; }
	 * 
	 * public void setJob(ExtractJobQueueEntity job) { this.job = job; }
	 */
}
