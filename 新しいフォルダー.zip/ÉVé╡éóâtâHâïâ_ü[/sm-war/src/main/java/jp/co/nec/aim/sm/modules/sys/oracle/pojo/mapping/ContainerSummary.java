package jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import jp.co.nec.aim.sm.common.annocation.FieldMapped;
import jp.co.nec.aim.sm.common.annocation.InquiryMapping;
import jp.co.nec.aim.sm.common.utils.SMUtil;

/**
 * ContainerSummary include the Container information and the segment <br>
 * that belong to this container.
 */
@InquiryMapping
public final class ContainerSummary implements Serializable {
	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -8893634749675041314L;
	private static final String RADIO_FORMAT_TYPE = "%.0f%%";
	private static final String COMMA = ",";
	private static final int THREE = 3;
	private static final String NOTHING = "-";
	private static final String EMPTY = "";

	public ContainerSummary() {
	}

	public ContainerSummary(int binId, int scope, String formatName,
			int SegmentNumber, double fragmentRadio) {
		this.binId = binId;
		this.scope = scope;
		this.formatName = formatName;
		this.segmentNumber = SegmentNumber;
		this.fragmentRadioDouble = fragmentRadio;
		this.setFragmentRadio(String.format(RADIO_FORMAT_TYPE,
				fragmentRadio * 100));
		this.segmentList = new ArrayList<SegmentSummary>();
	}

	@FieldMapped
	private Integer binId;

	@FieldMapped
	private Integer scope;

	@FieldMapped
	private String formatName;

	@FieldMapped
	private Integer segmentNumber;

	private Double fragmentRadioDouble;

	public String getWorstThreeSegment() {
		return worstThreeSegment;
	}

	public void setWorstThreeSegment(String worstThreeSegment) {
		this.worstThreeSegment = worstThreeSegment;
	}

	private String fragmentRadio;

	private String worstThreeSegment;

	private ArrayList<SegmentSummary> segmentList;

	// ////////////////////////////////////////////////////////////
	// /////////////////// segment_set related////////////////////
	// ///////////////////////////////////////////////////////////
	@FieldMapped
	private Integer segmentSetId;
	@FieldMapped
	private Integer maxSegmentSize;

	public Integer getSegmentSetId() {
		return segmentSetId;
	}

	public void setSegmentSetId(Integer segmentSetId) {
		this.segmentSetId = segmentSetId;
	}

	public Integer getMaxSegmentSize() {
		return maxSegmentSize;
	}

	public void setMaxSegmetSize(Integer maxSegmentSize) {
		this.maxSegmentSize = maxSegmentSize;
	}

	// ////////////////////////////////////////////////////////////
	// /////////////////// DM download related/////////////////////
	// ///////////////////////////////////////////////////////////
	private int maxSegmentDiffs;

	public int getMaxSegmentDiffs() {
		return maxSegmentDiffs;
	}

	public void setMaxSegmentDiffs(int maxSegmentDiffs) {
		this.maxSegmentDiffs = maxSegmentDiffs;
	}

	/**
	 * set worst three segment information
	 */
	@SuppressWarnings("unchecked")
	public final ContainerSummary setSegmentParameter() {
		List<SegmentSummary> segments = (ArrayList<SegmentSummary>) (this.segmentList)
				.clone();
		return setSegmentParameter(segments);
	}

	public final ContainerSummary setSegmentParameter(
			List<SegmentSummary> segments) {
		segments.remove(segments.size() - 1);
		Collections.sort(segments, new Comparator<SegmentSummary>() {
			public int compare(SegmentSummary o1, SegmentSummary o2) {
				if (SMUtil.isObjectNull(o1.getFragmentRadio())
						|| SMUtil.isObjectNull(o2.getFragmentRadio())) {
					return 0;
				}

				final double compare = o1.getFragmentRadio()
						- o2.getFragmentRadio();
				if (compare > 0) {
					return -1;
				} else if (compare == 0) {
					return 0;
				} else {
					return 1;
				}
			}
		});

		final StringBuilder sb = new StringBuilder();
		final int tsize = segments.size();
		final int size = tsize > THREE ? THREE : tsize;
		double total = 0.0;
		int totalCount = 0;

		for (int index = 0; index < size; index++) {
			final SegmentSummary segment = segments.get(index);
			final Long segmentId = segment.getSegId();
			final Double radio = segment.getFragmentRadio();

			// set Segment Average Radio
			total += segment.getFragmentRadio();
			totalCount++;

			sb.append(String.format("[%s](%2$.0f%%)", segmentId,
					(radio == null ? 0 : radio * 100)));
			if (index != size - 1) {
				sb.append(COMMA);
			}
		}

		// set fragmentRadioDouble and fragmentRadio attribute
		final boolean isSegmentEmpty = segments.isEmpty();
		this.fragmentRadioDouble = isSegmentEmpty ? 0.0d : (total / totalCount);
		this.setFragmentRadio(isSegmentEmpty ? NOTHING : String.format(
				"%.0f%%", (total / totalCount) * 100));
		this.worstThreeSegment = (sb.toString().equals(EMPTY) ? NOTHING : sb
				.toString());
		return this;
	}

	/**
	 * getTotalFragRadio
	 * 
	 * @return add each segment defragment radio in container
	 */
	public double getTotalFragRadio() {
		double totalRadio = 0d;
		for (SegmentSummary segment : segmentList) {
			totalRadio += segment.getFragmentRadio();
		}
		return totalRadio;
	}

	public long getMaxSegmentId() {
		long maxSegmentId = 0l;
		for (SegmentSummary segment : segmentList) {
			maxSegmentId = segment.getSegId() > maxSegmentId ? segment
					.getSegId() : maxSegmentId;
		}
		return maxSegmentId;
	}

	public Integer getBinId() {
		return binId;
	}

	public void setBinId(Integer binId) {
		this.binId = binId;
	}

	public String getFormatName() {
		return formatName;
	}

	public void setFormatName(String formatName) {
		this.formatName = formatName;
	}

	public Integer getSegmentNumber() {
		return segmentNumber;
	}

	public void setSegmentNumber(Integer segmentNumber) {
		this.segmentNumber = segmentNumber;
	}

	public String getFragmentRadio() {
		return fragmentRadio;
	}

	public Double getFragmentRadioDouble() {
		return fragmentRadioDouble;
	}

	public void setFragmentRadio(Double fragmentRadio) {
		this.fragmentRadioDouble = fragmentRadio;
		this.fragmentRadio = String.format("%.0f%%", fragmentRadio * 100);
	}

	public List<SegmentSummary> getSegmentList() {
		return segmentList;
	}

	/**
	 * addSegmentList
	 * 
	 * @param segmentList
	 */
	public ContainerSummary addSegmentList(List<SegmentSummary> segmentList) {
		if (this.segmentList == null) {
			this.segmentList = new ArrayList<SegmentSummary>();
		}
		this.segmentList.clear();
		this.segmentList.addAll(segmentList);
		return this;
	}

	public void setScope(Integer scope) {
		this.scope = scope;
	}

	public Integer getScope() {
		return scope;
	}

	public void setFragmentRadio(String fragmentRadio) {
		this.fragmentRadio = fragmentRadio;
	}
}
