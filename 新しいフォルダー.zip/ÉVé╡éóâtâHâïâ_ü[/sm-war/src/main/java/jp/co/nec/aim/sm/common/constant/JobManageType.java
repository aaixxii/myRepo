package jp.co.nec.aim.sm.common.constant;

public enum JobManageType {
	COMPLETE, RESTART, DELETE;
}
