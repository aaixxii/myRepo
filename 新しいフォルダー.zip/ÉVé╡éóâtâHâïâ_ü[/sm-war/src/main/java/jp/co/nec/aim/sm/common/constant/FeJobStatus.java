package jp.co.nec.aim.sm.common.constant;

public enum FeJobStatus {
	QUEUED, WORKING, COMPLETED;
}
