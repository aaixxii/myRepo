package jp.co.nec.aim.sm.modules.sys.postgres.pojo.mapping;

import java.io.Serializable;

public class DictPojo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4320192807263679L;
	private Long id;
	private String label;
	private String value;
	private String type;
	private String description;
	private Integer sort;

	public DictPojo() {
	}

	public DictPojo(Long id) {
		this();
		this.id = id;
	}

	public DictPojo(Long id, String label, String value, String type,
			String description, Integer sort) {
		this.id = id;
		this.label = label;
		this.value = value;
		this.type = type;
		this.description = description;
		this.sort = sort;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getSort() {
		return sort;
	}

	public void setSort(Integer sort) {
		this.sort = sort;
	}
}