package jp.co.nec.aim.sm.modules.sys.postgres.entity;

import static jp.co.nec.aim.sm.common.constant.SMConstant.STRING_EMPTY;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import javax.persistence.Transient;

import jp.co.nec.aim.sm.common.constant.MenuVisibility;
import jp.co.nec.aim.sm.modules.sys.postgres.pojo.mapping.DictPojo;

import org.apache.commons.lang3.StringUtils;

import com.google.common.collect.Lists;

public class MenuEntity implements Comparable<Long>, Serializable {

	private static final long serialVersionUID = -199428843706835034L;

	private Long id;

	private MenuEntity parent;

	// private String parentIds;
	private Set<Long> parentIds = new TreeSet<Long>();

	private String name;

	private String href;

	// private String target;
	//
	private String icon;

	private Integer sort;

	private String isShow;

	private String permission;

	@Transient
	private List<DictPojo> visibilityType = Lists.newArrayList();

	/** the child menu **/
	private Map<Long, MenuEntity> childList = new TreeMap<Long, MenuEntity>();

	public MenuEntity() {
		super();
		this.sort = 30;
		setVisibilityType();
	}

	public MenuEntity(Long id) {
		this();
		this.id = id;
	}

	public MenuEntity(final Long id, final String name, final String href,
			final String icon, final Integer sort, final String isShow,
			final String permission) {
		this.id = id;
		this.name = name;
		this.href = href;
		this.icon = icon;
		this.sort = sort;
		this.isShow = isShow;
		this.permission = permission;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public MenuEntity getParent() {
		return parent;
	}

	public void setParent(MenuEntity parent) {
		this.parent = parent;
	}

	public void appendParentIds(Long parentId) {
		parentIds.add(parentId);
	}

	public void appendParentIds(Set<Long> parentId) {
		parentIds.addAll(parentId);
	}

	public String getParentIds() {
		return StringUtils.join(parentIds, ",");
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getHref() {
		return href;
	}

	public void setHref(String href) {
		this.href = href;
	}

	public Integer getSort() {
		return sort;
	}

	public void setSort(Integer sort) {
		this.sort = sort;
	}

	public String getIsShow() {
		return isShow;
	}

	public void setIsShow(String isShow) {
		this.isShow = isShow;
	}

	public String getPermission() {
		return permission;
	}

	public void setPermission(String permission) {
		this.permission = permission;
	}

	public List<MenuEntity> getChildList() {
		return new ArrayList<MenuEntity>(childList.values());
	}

	public void appendChildList(final MenuEntity e) {

		if (!this.childList.containsKey(e.getId())) {
			this.childList.put(e.getId(), e);
		}
	}

	@Transient
	public boolean isRoot() {
		return isRoot(this.id);
	}

	@Transient
	public static boolean isRoot(Long id) {
		return id != null && id.equals(1L);
	}

	@Transient
	public List<DictPojo> getVisibilityType() {
		return visibilityType;
	}

	/**
	 * set menu Visibility Type
	 */
	private void setVisibilityType() {
		for (final MenuVisibility item : MenuVisibility.values()) {
			visibilityType.add(new DictPojo(item.getId(), item.getLabel(), item
					.getValue(), STRING_EMPTY, STRING_EMPTY, item.getSort()));
		}
	}

	@Override
	public int compareTo(Long o) {
		return 0;
	}

	public String getIcon() {
		return icon;
	}

	public void setIcon(String icon) {
		this.icon = icon;
	}
}