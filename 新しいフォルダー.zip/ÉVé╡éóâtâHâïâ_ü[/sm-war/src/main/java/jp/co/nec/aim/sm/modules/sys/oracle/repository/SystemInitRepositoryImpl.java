package jp.co.nec.aim.sm.modules.sys.oracle.repository;

import java.util.List;

import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.common.utils.SMUtil;
import jp.co.nec.aim.sm.exception.SMDaoException;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.SystemInitEntity;

import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

public class SystemInitRepositoryImpl {
	/** the log instance **/
	private static Logger logger = LoggerFactory
			.getLogger(SystemInitRepositoryImpl.class);

	@Autowired
	SystemInitRepository repository;

	/**
	 * get Detached Criteria
	 * 
	 * @param systemInit
	 * @return
	 */
	private DetachedCriteria getDetachedCriteria(SystemInitEntity systemInit) {
		// create the DetachedCriteria instance without session
		final DetachedCriteria dc = DetachedCriteria
				.forClass(SystemInitEntity.class);

		// add condition initId
		final Long initId = systemInit.getInitId();
		if (!SMUtil.isObjectNull(initId)) {
			logger.debug("add condition initId = {}", initId);
			dc.add(Restrictions.eq("initId", initId));
		}

		// add condition keyName
		final String keyName = systemInit.getKeyName();
		if (StringUtils.isNotBlank(keyName)) {
			logger.debug("add condition keyName = {}", keyName);
			dc.add(Restrictions.eq("keyName", keyName));
		}
		return dc;
	}

	/**
	 * find System Init Page
	 * 
	 * @param page
	 * @param systemInit
	 * @return
	 */
	public Page<SystemInitEntity> findSystemInitPage(
			Page<SystemInitEntity> page, SystemInitEntity systemInit) {
		final DetachedCriteria dc = getDetachedCriteria(systemInit);
		// add order by condition
		if (!StringUtils.isNotBlank(page.getOrderBy())) {
			logger.debug("add Order initId");
			dc.addOrder(Order.asc("initId"));
		}
		logger.debug("findPage for SystemInitEntity");
		return repository.findPage(page, dc);
	}

	/**
	 * find System Init List
	 * 
	 * @param page
	 * @param systemInit
	 * @return
	 */
	public List<SystemInitEntity> findSystemInit(SystemInitEntity systemInit) {
		final DetachedCriteria dc = getDetachedCriteria(systemInit);
		// add order by condition
		logger.debug("add Order initId");
		dc.addOrder(Order.asc("initId"));

		logger.debug("findPage for SystemInitEntity");
		return repository.find(dc);
	}

	/**
	 * update System Init
	 * 
	 * @param initId
	 * @param value
	 * @return
	 */
	public int updateSystemInit(Long initId, String value) {
		String sql = "update SYSTEM_INIT set KEY_VALUE = '" + value
				+ "' where INIT_ID = " + initId;
		logger.debug("update System Init: KEY_VALUE = '{}'"
				+ " where INIT_ID = {}", value, initId);
		return repository.updateBySql(sql);
	}

	/**
	 * get Integer Property
	 * 
	 * @param name
	 * @return
	 */
	public int getIntProperty(String name) {
		SystemInitEntity entity = findByName(name);
		return Integer.parseInt(entity.getKeyValue());
	}

	/**
	 * get Boolean Property
	 * 
	 * @param name
	 * @return
	 */
	public boolean getBooleanProperty(String name) {
		SystemInitEntity entity = findByName(name);
		return Boolean.parseBoolean(entity.getKeyValue());
	}

	/**
	 * get String Property
	 * 
	 * @param name
	 * @return
	 */
	public String getProperty(String name) {
		SystemInitEntity entity = findByName(name);
		return entity.getKeyValue();
	}

	/**
	 * find System Init Entity By Name
	 * 
	 * @param Name
	 * @return
	 */
	private SystemInitEntity findByName(String name) {
		DetachedCriteria dc = DetachedCriteria.forClass(SystemInitEntity.class);
		logger.debug("add condition keyName = {}", name);
		dc.add(Restrictions.eq("keyName", name));
		List<SystemInitEntity> list = repository.find(dc);
		if (list.size() == 0) {
			String message = "Can not find Property: keyName = " + name;
			throw new SMDaoException(message);
		}
		return list.get(0);
	}
}
