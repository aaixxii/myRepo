package jp.co.nec.aim.sm.common.worker;

import java.io.File;
import java.io.IOException;

import jp.co.nec.aim.sm.common.async.agent.AsyncAgent;
import jp.co.nec.aim.sm.common.constant.ProcessType;
import jp.co.nec.aim.sm.common.properties.SMProperties;
import jp.co.nec.aim.sm.common.threadpool.TaskThreadFactory;
import jp.co.nec.aim.sm.common.utils.SMUtil;
import jp.co.nec.aim.sm.exception.AuthenticateFailedException;
import jp.co.nec.aim.sm.exception.RSAFileIncorrectException;
import jp.co.nec.aim.sm.exception.SessionExecCommandFailedException;
import jp.co.nec.aim.sm.unitcontrol.dispatcher.MessageManager;
import jp.co.nec.aim.sm.unitcontrol.message.UnitControlMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ch.ethz.ssh2.ChannelCondition;
import ch.ethz.ssh2.Connection;
import ch.ethz.ssh2.ProxyData;
import ch.ethz.ssh2.Session;

/**
 * workflow
 * 1 sm:ssh-keygen -t rsa
 * 2 sm: ssh-copy-id -i ~/.ssh/id_rsa.pub root@IP
 */
/**
 * this class is the worker that connect to the remote unit<br>
 * and execute the specified command example like following <br>
 * <code>/sbin/service serviceName start</code> <br>
 * <code>/sbin/service serviceName restart</code> and so on <br>
 * it will also send the process message to front page synchronously <br>
 */
public final class OperateRemoteServiceWorker extends AbstractWorker {

	/** the log instance **/
	private static Logger logger = LoggerFactory
			.getLogger(OperateRemoteServiceWorker.class);

	/**
	 * the full path of the command <code>service</code> <br>
	 * add the prefix path sbin
	 */
	private final static String SERVICE_FULL_PATH = "/sbin/service";

	/**
	 * String space
	 */
	private final static String SPACE = " ";

	/**
	 * the number of input correct parameter
	 */
	private final static int CORRECT_PARA_NUMBER = 4;

	/**
	 * the unit remote ip addres
	 */
	private final String unitIpAddress;

	/**
	 * the specified script name that exist in /etc/init.d
	 */
	private final String serviceName;

	/**
	 * the server os name
	 */
	private final static String SERVER_OSUSER = "root";

	/**
	 * the current user name
	 */
	private final static String USER_NAME = System.getProperty("user.name");

	/**
	 * the process type
	 */
	private final ProcessType processType;

	/**
	 * the process message will be send to front page synchronously
	 */
	private final MessageManager manager;

	/**
	 * the current user home directory
	 */
	private final static String USER_HOME = System.getProperty("user.home");

	/**
	 * the suffix path of the rsa file
	 */
	private final static String RSA_FILE_SUFFIX = "/.ssh/id_rsa";

	/**
	 * Connect the underlying TCP socket to the server with the given timeout
	 * value (non-negative, in milliseconds). Zero means no timeout. If a proxy
	 * is being used (see {@link #setProxyData(ProxyData)}), then this timeout
	 * is used for the connection establishment to the proxy.
	 */
	private  int CONNECT_TIMEOUT  ;

	/**
	 * Timeout for complete connection establishment (non-negative, in
	 * milliseconds). Zero means no timeout. The timeout counts from the moment
	 * you invoke the connect() method and is cancelled as soon as the first
	 * key-exchange round has finished. It is possible that the timeout event
	 * will be fired during the invocation of the <code>verifier</code>
	 * callback, but it will only have an effect after the <code>verifier</code>
	 * returns.
	 */
	private  int KEX_TIMEOUT ;

	/**
	 * Timeout for complete the thread of message capture
	 */
	private static final int SESSION_STREAM_TIMEOUT = 20000;

	/**
	 * default rsa password is empty
	 */
	private static final String DEFAULT_RSA_PASSWORD = "";

	/**
	 * the specified thread factory with <br>
	 * thread name prefix <code>Message-Capture-</code> <br>
	 * daemon thread and normal priority <br>
	 */
	private static final TaskThreadFactory THREAD_FACTORY = new TaskThreadFactory(
			"Message-Capture-", true, Thread.NORM_PRIORITY);

	/**
	 * the message tracker
	 */
	private final UnitControlMessage tracker;

	private boolean isSleep = false;

	/**
	 * the default constructor
	 * 
	 * @param result
	 *            the instance of AsyncAgent
	 */
	public OperateRemoteServiceWorker(AsyncAgent result, boolean isSleep) {
		super(result);

		// get the parameter array
		final Object[] paras = result.getParameters();

		// save each field
		unitIpAddress = SMUtil.cast(paras[0]);
		serviceName = SMUtil.cast(paras[1]);
		processType = SMUtil.cast(paras[2]);
		manager = SMUtil.cast(paras[3]);
		this.isSleep = isSleep;
		CONNECT_TIMEOUT = Integer.valueOf(SMProperties.getSmUnitConnectTimeoutSetting()).intValue();
		KEX_TIMEOUT = Integer.valueOf(SMProperties.getSmUnitKexTimeoutSetting()).intValue();

		// create message track instance
		tracker = new UnitControlMessage(unitIpAddress, serviceName, USER_NAME,
				processType, manager, logger);
		
	}

	@Override
	protected Object doTask(Object[] paras) throws Exception {
		// do logic task include connect and execute command
		Connection conn = null;

		try {
			if (isSleep && ProcessType.STOP.equals(processType)) {
				Thread.sleep(5000);
			}
			tracker.push("create new instance of Connection.");

			// first connect to the remote server use ras private key file
			// it is necessary that the public key has already added to
			// the remote server in specified directory named authorized_keys
			// create the Connection instance
			conn = new Connection(unitIpAddress);

			// connect to unit server with specified timeout
			tracker.push("connect to remote server with connect timeout:"
					+ CONNECT_TIMEOUT + ", kex timeout:" + KEX_TIMEOUT);
			conn.connect(null, CONNECT_TIMEOUT, KEX_TIMEOUT);

			// if connect successfully, get the key file
			// if file not found or read denied, throw
			// RSAFileIncorrectException
			authenticate(conn);

			String command = null;
			if (!processType.equals(ProcessType.RESTART)) {
				command = generateCommand(processType);
				doCmd(conn, command);
			} else {
				command = generateCommand(ProcessType.STOP);
				doCmd(conn, command);
				command = generateCommand(ProcessType.START);
				doCmd(conn, command);
			}

		} catch (RSAFileIncorrectException ex) {
			tracker.pushError(ex.getMessage(), ex);
			throw ex;
		} catch (AuthenticateFailedException ex) {
			tracker.pushError(ex.getMessage(), ex);
			throw ex;
		} catch (SessionExecCommandFailedException ex) {
			tracker.pushError(ex.getMessage(), ex);
			throw ex;
		} catch (InterruptedException ex) {
			tracker.pushError("the message capture thread is Interrupted", ex);
			throw ex;
		} catch (IOException ex) {
			tracker.pushError("IOException occurred when connect to remote", ex);
			throw ex;
		} catch (Exception ex) {
			tracker.pushError("Unknown exception occurred"
					+ " when connect to remote", ex);
			throw ex;
		} finally {
			SMUtil.close(conn);
		}

		// nothing to return
		return null;
	}

	private void doCmd(Connection conn, String command)
			throws InterruptedException, IOException {

		Session session = null;

		// authenticate successfully
		tracker.push("authenticate with rsa key file successfully,"
				+ " ready to execute the command.");
		try {
			// third if authenticate passed, open session for execute
			// the specified command on the remote server
			session = conn.openSession();

			try {
				session.execCommand(command);
			} catch (IOException ex) {
				throw new SessionExecCommandFailedException(
						"execute the command failed "
								+ "when session execute command", ex);
			}

			// execute the command successfully
			tracker.push("execute the command successfully, command:" + command);

			// at last create two threads to listen all
			// the execute information
			// thread t1 used to capture the normal message
			// thread t2 capture the error message
			captureSeesionMessage(session);

			session.waitForCondition(ChannelCondition.EXIT_STATUS,
					SESSION_STREAM_TIMEOUT);

			if (session.getExitStatus() == 0) {
				// at last
				tracker.push("Done: execute the command Successfully.");
			} else {
				// at last
				tracker.push("Done: fail to execute the command.");
			}
		} finally {
			SMUtil.close(session);
		}
	}

	/**
	 * authenticate with public rsa key
	 * 
	 * @param conn
	 *            the connection instance
	 * @throws AuthenticateFailedException
	 */
	private void authenticate(Connection conn)
			throws AuthenticateFailedException {
		final File rsaFile = getRSAFile();
		tracker.push("prepare rsa key file successfully, file path:"
				+ rsaFile.getAbsolutePath());

		try {
			// secondly authenticate with the public key
			boolean isAuthenticated = conn.authenticateWithPublicKey(
					SERVER_OSUSER, rsaFile, DEFAULT_RSA_PASSWORD);
			if (!isAuthenticated) {
				throw new AuthenticateFailedException(
						"Authenticated failed, userName: " + SERVER_OSUSER
								+ ",rsaFile path:" + rsaFile.getAbsolutePath()
								+ ", default rsa password:"
								+ DEFAULT_RSA_PASSWORD);
			}
		} catch (IOException ex) {
			throw new AuthenticateFailedException(
					"IOException occurred while authenticate With Public Key.",
					ex);
		}
	}

	/**
	 * create two threads to listen all execution information
	 * 
	 * @param session
	 *            the ssh session
	 * @throws InterruptedException
	 */
	private void captureSeesionMessage(Session session)
			throws InterruptedException {
		final Thread t1 = THREAD_FACTORY
				.newThread(new CollectStreamMessageWorker(AsyncAgent
						.newInstance(new Object[] { manager,
								session.getStdout() })));
		final Thread t2 = THREAD_FACTORY
				.newThread(new CollectStreamMessageWorker(AsyncAgent
						.newInstance(new Object[] { manager,
								session.getStderr() })));

		// start and join to current thread
		t1.start();
		t2.start();

		// if the timeout is readched,
		// throw InterruptedException
		// add timeout to avoid the thread is alway block
		t1.join(SESSION_STREAM_TIMEOUT);
		t2.join(SESSION_STREAM_TIMEOUT);
	}

	/**
	 * Get the ssh rsa file full path
	 * 
	 * @return the rsa file instance
	 */
	private File getRSAFile() {
		final File rsaFile = new File(USER_HOME + RSA_FILE_SUFFIX);
		if (!rsaFile.exists() || !rsaFile.canRead()) {
			throw new RSAFileIncorrectException(
					"the rsa file is incorrect(not exist or "
							+ "read denied), rsa file path:"
							+ rsaFile.getAbsolutePath());
		}
		return rsaFile;
	}

	/**
	 * generate command that will be execute in the remote server
	 * 
	 * @param processType
	 *            the execute type
	 * @return command string
	 */
	private String generateCommand(ProcessType processTypeLocal) {
		return (SERVICE_FULL_PATH + SPACE + serviceName + SPACE + processTypeLocal
				.getOperationType());
	}

	@Override
	protected void checkParameter(Object[] paras)
			throws IllegalArgumentException {
		if (SMUtil.isNullOrEmpty(paras)) {
			throw new IllegalArgumentException("the parameter is incorrect..");
		}

		if (paras.length != CORRECT_PARA_NUMBER) {
			throw new IllegalArgumentException("the parameter length is not "
					+ CORRECT_PARA_NUMBER + "..");
		}
	}
}
