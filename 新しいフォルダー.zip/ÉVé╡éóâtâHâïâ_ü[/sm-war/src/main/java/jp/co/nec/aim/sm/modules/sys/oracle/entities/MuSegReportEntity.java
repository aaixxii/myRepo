package jp.co.nec.aim.sm.modules.sys.oracle.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@IdClass(jp.co.nec.aim.sm.modules.sys.oracle.entities.MuSegReportPK.class)
@Table(name = "MU_SEG_REPORTS")
public class MuSegReportEntity implements UnitSegReport {
	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -5622098190791133953L;
	private long muId;
	private long segmentId;
	private Long version;
	private Long queuedVersion;
	private int status;

	@Id
	@Column(name = "MU_ID")
	public long getMuId() {
		return muId;
	}

	public void setMuId(long muId) {
		this.muId = muId;
	}

	@Id
	@Column(name = "SEGMENT_ID")
	public long getSegmentId() {
		return segmentId;
	}

	public void setSegmentId(long segmentId) {
		this.segmentId = segmentId;
	}

	@Column(name = "STATUS")
	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	private boolean versionMatches(Long otherVersion) {
		if (version == null)
			return otherVersion == null;
		return version.equals(otherVersion);
	}

	private boolean queuedVersionMatches(Long otherQueuedVersion) {
		if (queuedVersion == null)
			return otherQueuedVersion == null;
		return queuedVersion.equals(otherQueuedVersion);
	}

	@Override
	public boolean equals(Object o) {
		if (o instanceof MuSegReportEntity) {
			MuSegReportEntity other = (MuSegReportEntity) o;
			return versionMatches(other.getVersion())
					&& queuedVersionMatches(other.getQueuedVersion())
					&& new Integer(status).equals(other.getStatus());
		}
		return false;
	}

	@Override
	public int hashCode() {
		int result = 17;
		if (version != null) {
			long val = version.longValue();
			result = 37 * result + (int) (val ^ (val >>> 32));
		}
		if (queuedVersion != null) {
			long val = queuedVersion.longValue();
			result = 37 * result + (int) (val ^ (val >>> 32));
		}
		result = 37 * result + status;
		return result;
	}

	public String toString() {
		return "{ " + muId + " => seg " + segmentId + " (v." + version + ", q."
				+ queuedVersion + ") [" + status + "] }";
	}

	@Column(name = "SEGMENT_QUEUED_VERSION")
	public Long getQueuedVersion() {
		return queuedVersion;
	}

	public void setQueuedVersion(Long queuedVersion) {
		this.queuedVersion = queuedVersion;
	}

	@Column(name = "SEGMENT_VERSION")
	public Long getVersion() {
		return version;
	}

	public void setVersion(Long version) {
		this.version = version;
	}

	@Transient
	@Override
	public long getUnitId() {
		return this.muId;
	}

	public void setUnitId(long unitId) {
		this.muId = unitId;
	}

}
