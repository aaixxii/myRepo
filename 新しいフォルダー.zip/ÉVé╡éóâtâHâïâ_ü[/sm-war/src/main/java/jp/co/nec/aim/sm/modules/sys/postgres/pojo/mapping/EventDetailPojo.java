package jp.co.nec.aim.sm.modules.sys.postgres.pojo.mapping;

import java.io.Serializable;

import jp.co.nec.aim.sm.common.annocation.FieldMapped;
import jp.co.nec.aim.sm.common.annocation.InquiryMapping;

@InquiryMapping
public class EventDetailPojo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2951774114245499947L;

	@FieldMapped
	private Long unitId;

	@FieldMapped
	private String messageType;

	@FieldMapped
	private String messageCode;

	@FieldMapped
	private String timestamp;

	@FieldMapped
	private String message;

	public String getMessageType() {
		return messageType;
	}

	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	public void setUnitId(Long unitId) {
		this.unitId = unitId;
	}

	public Long getUnitId() {
		return unitId;
	}

	public void setMessageCode(String messageCode) {
		this.messageCode = messageCode;
	}

	public String getMessageCode() {
		return messageCode;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	public String getTimestamp() {
		return timestamp;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

}
