package jp.co.nec.aim.sm.common.constant;

public enum CardQualityType {
	Roll, Slap, All;
}
