package jp.co.nec.aim.sm.modules.sys.web;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.nec.aim.sm.common.constant.BinActionType;
import jp.co.nec.aim.sm.common.constant.Constants;
import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.common.utils.EnumUtil;
import jp.co.nec.aim.sm.common.utils.SMUtil;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.DataManagerEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.FunctionTypeEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.MatchUnitEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.MuEligibleContainerEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.MuEligibleFunctionEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.SystemConfigEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.SystemInitEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.BiometricContainerPojo;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.EligibleBinsPojo;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.EligibleFunctionsPojo;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.FunctionTypeTrafficPojo;
import jp.co.nec.aim.sm.modules.sys.service.DmEligibleBiometricContainerService;
import jp.co.nec.aim.sm.modules.sys.service.SystemConfigService;
import jp.co.nec.aim.sm.modules.sys.service.UnitService;
import jp.co.nec.aim.sm.modules.sys.web.base.BaseController;

import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping(value = "/systemConfig")
public class SystemConfigController extends BaseController {

	/** the log instance **/
	private static Logger logger = LoggerFactory
			.getLogger(SystemConfigController.class);

	@Autowired
	private SystemConfigService sysConfigService;
	@Autowired
	private UnitService matchUnitService;
	
	@Autowired
	DmEligibleBiometricContainerService dmService;
	
	
	/**
	 * 
	 * @param bin
	 * @param request
	 * @param response
	 * @param model
	 * @return
	 */
	@RequiresPermissions(Constants.PERMISSION_USER)
	@RequestMapping(value = { "containers/list", "" })
	public String listBiometricContainers(
			@RequestParam(value = "binId", required = false) Long biometricContainerEntityId,
			BiometricContainerPojo bin, HttpServletRequest request,
			HttpServletResponse response, Model model) {
		try {
			// update Biometric Container
			logger.info("update Biometric Container");
			if (!SMUtil.isObjectNull(biometricContainerEntityId))
				bin.setBinId(biometricContainerEntityId);
			Long binId = bin.getBinId();
			String format = bin.getFormat();
			Long redundancy = bin.getMinimumRedundancy();
			Long minMuNumForSlb = bin.getMinMuNumForSlb();
			Long maxSegmentSize = bin.getMaxSegmentSize();
			if (BinActionType.Update.name().equals(bin.getAction())) {
				logger.info("update Container: containerId = {}, format = {},"
						+ " MinimumRedundancy = {}", new Object[] { binId,
						format, redundancy });
				int result = sysConfigService.updateDBByClass(
						BiometricContainerPojo.class, binId, format,
						redundancy, minMuNumForSlb, maxSegmentSize);

				// int result = 0;
				if (result == 0) {
					String message = "can not find Contanier: containerId = "
							+ binId + ", format = " + format;
					if (binId == null) {
						message = "can not find Contanier: containerId is not found";
					}

					logger.error(message);
					addMessage(model, message);
				}
			}
		} catch (Exception e) {
			String message = e.getMessage();
			logger.error(message, e);
			addMessage(model, message);
		}

		// get BiometricContainers
		logger.info("get Biometric Containers");
		Page<BiometricContainerPojo> page = sysConfigService.getPageByClass(
				new Page<BiometricContainerPojo>(request, response), bin,
				BiometricContainerPojo.class);
		logger.info("page count:{}, list size:{}", page.getCount(), page
				.getList().size());

		// get format List and action List
		List<String> formatList = sysConfigService.getAllFormatType();
		List<String> actionList = EnumUtil.getBinActionList();

		// add Attribute
		model.addAttribute("formatList", formatList);
		model.addAttribute("actionList", actionList);
		model.addAttribute("page", page);
		model.addAttribute("bin", bin);

		logger.info("show Biometric Containers");
		saveCurrentPageInfo(request, "/systemConfig/containers/list", model);
		return "modules/configure/containers";
	}

	/**
	 * 
	 * @param eligibleFunctions
	 * @param request
	 * @param response
	 * @param model
	 * @return
	 */
	@RequiresPermissions(Constants.PERMISSION_USER)
	@RequestMapping(value = { "eligibleFunctions/list", "" })
	public String listEligibleFunctions(
			@RequestParam(value = "matchUnitId", required = false) Long matchUnitId,
			EligibleFunctionsPojo eligibleFunctions,
			HttpServletRequest request, HttpServletResponse response,
			Model model) {
		try {
			// execute Assign Action
			logger.info("execute Eligible Functions Assign Action");
			if (!SMUtil.isObjectNull(matchUnitId))
				eligibleFunctions.setMatchUnitId(matchUnitId);
			String action = eligibleFunctions.getAction();
			Long muId = eligibleFunctions.getMatchUnitId();
			String functions = eligibleFunctions.getFunctions();
			if (StringUtils.isNotBlank(action)
					&& StringUtils.isNotBlank(functions)
					&& !SMUtil.isObjectNull(muId)) {
				logger.info("execute Assign Action: action = {}, Unit ID = {},"
						+ " Function = {}", new Object[] { action, muId,
						functions });

				MatchUnitEntity matchUnit = matchUnitService.getUnit(muId);
				boolean result = false;
				if (matchUnit != null) {
					result = sysConfigService.executeAssignAction(
							MuEligibleFunctionEntity.class, action, muId,
							functions);
					if (!result) {
						String message = "Assign Action: action = " + action
								+ " is not support.";
						logger.error(message);
						addMessage(model, message);
					}
				} else if (matchUnit == null) {
					String message = "Assign Action: Unit ID = " + muId
							+ " is not existed.";
					logger.error(message);
					addMessage(model, message);
				}
			}
		} catch (Exception e) {
			String message = e.getMessage();
			logger.error(message, e);
			addMessage(model, message);
		}

		// get Eligible Functions
		logger.info("get Eligible Functions");
		Page<EligibleFunctionsPojo> page = sysConfigService.getPageByClass(
				new Page<EligibleFunctionsPojo>(request, response),
				eligibleFunctions, EligibleFunctionsPojo.class);
		logger.info("page count:{}, list size:{}", page.getCount(), page
				.getList().size());

		// get function List and action List
		List<String> functionList = sysConfigService.getAllFunctionType();
		List<String> actionList = EnumUtil.getAssignActionList();

		// add Attribute
		model.addAttribute("functionList", functionList);
		model.addAttribute("actionList", actionList);
		model.addAttribute("page", page);
		model.addAttribute("eligibleFunctions", eligibleFunctions);

		logger.info("show Eligible Functions");
		saveCurrentPageInfo(request, "/systemConfig/eligibleFunctions/list",
				model);
		return "modules/configure/eligiblefunctions";
	}

	/**
	 * 
	 * @param eligibleBins
	 * @param request
	 * @param response
	 * @param model
	 * @return
	 */
	@RequiresPermissions(Constants.PERMISSION_USER)
	@RequestMapping(value = { "eligibleContainers/list/dm", "" })
	public String listDmEligibleBins(
			@RequestParam(value = "matchUnitId", required = false) Long matchUnitId,
			EligibleBinsPojo eligibleBins, HttpServletRequest request,
			HttpServletResponse response, Model model) {
		try {
			// execute Assign Action
			logger.info("execute Eligible Bins Assign Action");
			if (!SMUtil.isObjectNull(matchUnitId))
				eligibleBins.setMatchUnitId(matchUnitId);
			String action = eligibleBins.getAction();
			Long muId = eligibleBins.getMatchUnitId();
			String bins = eligibleBins.getBinIds();
			if (StringUtils.isNotBlank(action) && StringUtils.isNotBlank(bins)
					&& !SMUtil.isObjectNull(muId)) {
				logger.info("execute Assign Action: action = {}, Unit ID = {},"
						+ " BinIds = {}", new Object[] { action, muId, bins });
				DataManagerEntity dmUnit = sysConfigService.findDmEtifyById(muId);
				boolean result = false;
				if (dmUnit != null) {
					result = sysConfigService
							.executeAssignAction(
									MuEligibleContainerEntity.class, action,
									muId, bins);
					if (!result) {
						String message = "Assign Action: action = " + action
								+ " is not support.";
						logger.error(message);
						addMessage(model, message);
					}
				} else if (dmUnit == null) {
					String message = "Assign Action: Unit ID = " + muId
							+ " is not existed.";
					logger.error(message);
					addMessage(model, message);
				}
			}
		} catch (Exception e) {
			String message = e.getMessage();
			logger.error(message, e);
			addMessage(model, message);
		}

		// get Eligible Bins
		logger.info("get Eligible Bins");
		
		Page<EligibleBinsPojo> page =
				dmService.findDmEligibleBinPage(new Page<EligibleBinsPojo>(request, response), eligibleBins);	
		logger.info("page count:{}, list size:{}", page.getCount(), page
				.getList().size());

		// get bin List and action List
		List<Long> binList = sysConfigService.getAllContainers();
		List<String> actionList = EnumUtil.getAssignActionList();

		// add Attribute
		model.addAttribute("binList", binList);
		// model.addAttribute("binList", binList);
		model.addAttribute("actionList", actionList);
		model.addAttribute("page", page);
		model.addAttribute("eligibleBins", eligibleBins);

		logger.info("show Eligible Bins");
		saveCurrentPageInfo(request, "/systemConfig/eligibleContainers/list",
				model);
		return "modules/configure/eligibleContainers";
	}
	
	@RequiresPermissions(Constants.PERMISSION_USER)
	@RequestMapping(value = { "eligibleContainers/list", "" })
	public String listEligibleBins(
			@RequestParam(value = "matchUnitId", required = false) Long matchUnitId,
			EligibleBinsPojo eligibleBins, HttpServletRequest request,
			HttpServletResponse response, Model model) {
		try {
			// execute Assign Action
			logger.info("execute Eligible Bins Assign Action");
			if (!SMUtil.isObjectNull(matchUnitId))
				eligibleBins.setMatchUnitId(matchUnitId);
			String action = eligibleBins.getAction();
			Long muId = eligibleBins.getMatchUnitId();
			String bins = eligibleBins.getBinIds();
			if (StringUtils.isNotBlank(action) && StringUtils.isNotBlank(bins)
					&& !SMUtil.isObjectNull(muId)) {
				logger.info("execute Assign Action: action = {}, Unit ID = {},"
						+ " BinIds = {}", new Object[] { action, muId, bins });
				MatchUnitEntity matchUnit = matchUnitService.getUnit(muId);
				boolean result = false;
				if (matchUnit != null) {
					result = sysConfigService
							.executeAssignAction(
									MuEligibleContainerEntity.class, action,
									muId, bins);
					if (!result) {
						String message = "Assign Action: action = " + action
								+ " is not support.";
						logger.error(message);
						addMessage(model, message);
					}
				} else if (matchUnit == null) {
					String message = "Assign Action: Unit ID = " + muId
							+ " is not existed.";
					logger.error(message);
					addMessage(model, message);
				}
			}
		} catch (Exception e) {
			String message = e.getMessage();
			logger.error(message, e);
			addMessage(model, message);
		}

		// get Eligible Bins
		logger.info("get Eligible Bins");
		Page<EligibleBinsPojo> page = sysConfigService.getPageByClass(
				new Page<EligibleBinsPojo>(request, response), eligibleBins,
				EligibleBinsPojo.class);
		logger.info("page count:{}, list size:{}", page.getCount(), page
				.getList().size());

		// get bin List and action List
		List<Long> binList = sysConfigService.getAllContainers();
		List<String> actionList = EnumUtil.getAssignActionList();

		// add Attribute
		model.addAttribute("binList", binList);
		// model.addAttribute("binList", binList);
		model.addAttribute("actionList", actionList);
		model.addAttribute("page", page);
		model.addAttribute("eligibleBins", eligibleBins);

		logger.info("show Eligible Bins");
		saveCurrentPageInfo(request, "/systemConfig/eligibleContainers/list",
				model);
		return "modules/configure/eligibleContainers";
	}	
	
	


	/**
	 * 
	 * @param function
	 * @param request
	 * @param response
	 * @param model
	 * @return
	 */
	@RequiresPermissions(Constants.PERMISSION_USER)
	@RequestMapping(value = { "functions/list", "" })
	public String listFunctions(FunctionTypeTrafficPojo function,
			HttpServletRequest request, HttpServletResponse response,
			Model model) {
		try {
			// update TargetAllocation of Function Type
			logger.info("update TargetAllocation of Function Type");
			Integer typeId = function.getId();
			Integer jobLimit = function.getJobLimit();

			//Long jobLimit = 1L;

			Long timeouts = function.getTopLevelJobTimeouts();
			Long muJobTimeouts = function.getContainerJobTimeouts();
			Long internalCandidateSize = function.getInternalCandidateSize();
			if (!SMUtil.isObjectNull(typeId)
					&& (!SMUtil.isObjectNull(jobLimit)
							|| !SMUtil.isObjectNull(timeouts)
							|| !SMUtil.isObjectNull(muJobTimeouts) || !SMUtil
								.isObjectNull(internalCandidateSize))) {
				int result = sysConfigService.updateDBByClass(
						FunctionTypeTrafficPojo.class, typeId, jobLimit,
						timeouts, muJobTimeouts, internalCandidateSize);
				if (result == 0) {
					String message = "can not find Function Type: FunctionTypeId = "
							+ typeId;
					logger.error(message);
					addMessage(model, message);
				}
			}
		} catch (Exception e) {
			String message = e.getMessage();
			logger.error(message, e);
			addMessage(model, message);
		}

		//FunctionTypeTrafficPojo newEntity = new FunctionTypeTrafficPojo();
		// get Function Type
		logger.info("get Function Type");
		Page<FunctionTypeEntity> page = sysConfigService.getPageByClass(
				new Page<FunctionTypeTrafficPojo>(request, response, -1),
				function, FunctionTypeTrafficPojo.class);
		page.setCount(page.getList().size());
		logger.info("page count:{}, list size:{}", page.getCount(), page
				.getList().size());

		// add Attribute
		model.addAttribute("page", page);
		model.addAttribute("function", function);

		logger.info("show Function Type");
		saveCurrentPageInfo(request, "/systemConfig/functions/list", model);
		return "modules/configure/functions";
	}

	/**
	 * 
	 * @param systemInit
	 * @param request
	 * @param response
	 * @param model
	 * @return
	 */
	@RequiresPermissions(Constants.PERMISSION_USER)
	@RequestMapping(value = { "systemInit/list", "" })
	public String listSystemInitialization(SystemInitEntity systemInit,
			HttpServletRequest request, HttpServletResponse response,
			Model model) {
		try {
			// update System Initialization
			logger.info("update System Initialization");
			Long initId = systemInit.getInitId();
			String keyValue = systemInit.getKeyValue();
			if (StringUtils.isNotBlank(keyValue)
					&& !SMUtil.isObjectNull(initId)) {
				logger.info("update System Init: InitId = {}, KeyValue = {}",
						initId, keyValue);
				int result = sysConfigService.updateDBByClass(
						SystemInitEntity.class, initId, keyValue);
				if (result == 0) {
					String message = "can not find System Init: InitId = "
							+ initId;
					logger.error(message);
					addMessage(model, message);
				}
			}
		} catch (Exception e) {
			String message = e.getMessage();
			logger.error(message, e);
			addMessage(model, message);
		}

		//SystemInitEntity newEntity = new SystemInitEntity();
		// get System Initialization
		logger.info("get System Initialization");
		Page<SystemInitEntity> page = sysConfigService.getPageByClass(
				new Page<SystemInitEntity>(request, response, -1), systemInit,
				SystemInitEntity.class);
		page.setCount(page.getList().size());
		logger.info("page count:{}, list size:{}", page.getCount(), page
				.getList().size());

		// add Attribute
		model.addAttribute("page", page);
		model.addAttribute("systemInit", systemInit);

		logger.info("show System Initialization");
		saveCurrentPageInfo(request, "/systemConfig/systemInit/list", model);
		return "modules/configure/systeminit";
	}

	/**
	 * 
	 * @param systemConfig
	 * @param request
	 * @param response
	 * @param model
	 * @return
	 */
	@RequiresPermissions(Constants.PERMISSION_USER)
	@RequestMapping(value = { "systemSettings/list", "" })
	public String listSystemConfig(SystemConfigEntity systemConfig,
			HttpServletRequest request, HttpServletResponse response,
			Model model) {
		try {
			// update System Configure
			logger.info("update System Configure");
			Integer configId = systemConfig.getConfigId();
			String propertyName = systemConfig.getPropertyName();
			String propertyValue = systemConfig.getPropertyValue();
			if ((!SMUtil.isObjectNull(configId) || StringUtils
					.isNotBlank(propertyName))
					&& StringUtils.isNotBlank(propertyValue)) {
				logger.info("update System Configure: ConfigId = {},"
						+ " PropertyName = {}, PropertyValue = {}",
						new Object[] { configId, propertyName, propertyValue });
				int result = sysConfigService.updateDBByClass(
						SystemConfigEntity.class, configId, propertyName,
						propertyValue);
				if (result == 0) {
					String message = "can not find System Config: ConfigId = "
							+ configId + " PropertyName = " + propertyName;
					logger.error(message);
					addMessage(model, message);
				}
			}
		} catch (Exception e) {
			String message = e.getMessage();
			logger.error(message, e);
			addMessage(model, message);
		}

		// get System Configure
		logger.info("get System Configure");
		Page<SystemConfigEntity> page = sysConfigService.getPageByClass(
				new Page<SystemConfigEntity>(request, response, -1),
				systemConfig, SystemConfigEntity.class);
		page.setCount(page.getList().size());
		logger.info("page count:{}, list size:{}", page.getCount(), page
				.getList().size());

		// add Attribute
		model.addAttribute("page", page);
		model.addAttribute("systemConfig", systemConfig);

		logger.info("show System Configure");
		saveCurrentPageInfo(request, "/systemConfig/systemSettings/list", model);
		return "modules/configure/systemconfig";
	}
	
}
