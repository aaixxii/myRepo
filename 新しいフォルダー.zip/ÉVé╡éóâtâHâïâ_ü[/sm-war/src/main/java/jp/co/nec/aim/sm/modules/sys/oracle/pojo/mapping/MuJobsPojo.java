package jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Transient;

import jp.co.nec.aim.sm.common.annocation.FieldMapped;
import jp.co.nec.aim.sm.common.annocation.InquiryMapping;

@InquiryMapping
public class MuJobsPojo implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 5212350646210703647L;

	@FieldMapped
	private Long matchUnitId;
	@FieldMapped
	private String functiontype;
	@FieldMapped
	private Long assigned;
	@FieldMapped
	private Long completed;

	private List<Long> unitList;

	private List<String> functionList;

	@Transient
	private String startTime;

	@Transient
	private String endTime;

	public Long getMatchUnitId() {
		return matchUnitId;
	}

	public void setMatchUnitId(Long matchUnitId) {
		this.matchUnitId = matchUnitId;
	}

	public String getFunctiontype() {
		return functiontype;
	}

	public void setFunctiontype(String functiontype) {
		this.functiontype = functiontype;
	}

	public Long getAssigned() {
		return assigned;
	}

	public void setAssignd(Long assigned) {
		this.assigned = assigned;
	}

	public Long getCompleted() {
		return completed;
	}

	public void setCompleted(Long completed) {
		this.completed = completed;
	}

	public void setUnitList(List<Long> unitList) {
		this.unitList = unitList;
	}

	public List<Long> getUnitList() {
		return unitList;
	}

	public void setFunctionList(List<String> functionList) {
		this.functionList = functionList;
	}

	public List<String> getFunctionList() {
		return functionList;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public String getEndTime() {
		return endTime;
	}
}
