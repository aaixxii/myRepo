package jp.co.nec.aim.sm.modules.sys.postgres.pojo.mapping;

import java.io.Serializable;

import jp.co.nec.aim.sm.common.annocation.FieldMapped;
import jp.co.nec.aim.sm.common.annocation.InquiryMapping;

@InquiryMapping
public class EventLogPojo implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 3236440508458768293L;

	public EventLogPojo() {
	}

	public EventLogPojo(String type, Long count) {
		this.messageType = type;
		this.messageCount = count;
	}

	@FieldMapped
	private String messageType;
	@FieldMapped
	private Long messageCount;

	public String getMessageType() {
		return messageType;
	}

	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	public Long getMessageCount() {
		return messageCount;
	}

	public void setMessageCount(Long messageCount) {
		this.messageCount = messageCount;
	}

}
