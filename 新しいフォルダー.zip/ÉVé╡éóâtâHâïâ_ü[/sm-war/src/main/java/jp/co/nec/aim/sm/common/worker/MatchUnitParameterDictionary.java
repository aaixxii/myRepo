package jp.co.nec.aim.sm.common.worker;

import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import jp.co.nec.aim.sm.common.utils.ConfigReader;
import jp.co.nec.aim.sm.common.utils.MuConfigItemUtils;
import jp.co.nec.aim.sm.common.utils.MuConfigSectionUtils;
import jp.co.nec.aim.sm.common.utils.MuConfigUtils;

import org.ini4j.InvalidFileFormatException;
import org.ini4j.Profile.Section;
import org.ini4j.Wini;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;

public class MatchUnitParameterDictionary {
	/**
	 * matchUnitParameterMap Map<String,LinkedHashMap<String,
	 * LinkedHashMap<String, String>>><br>
	 * key:Ini Section(Ex.System)<br>
	 * LinkedHashMap<String, LinkedHashMap<String, String>><br>
	 * key:Ini ParameterKey(Ex.AppPath)<br>
	 * LinkedHashMap<String, String><br>
	 * key:MuIp(Ex.MU(XXX.XXX.XXX.XXX:XXXX))<br>
	 * value:ParameterValue<br>
	 */
	private static List<MuConfigUtils> matchUnitParameterlist = new ArrayList<MuConfigUtils>();
	private static List<MuConfigUtils> mapReducerParameterlist = new ArrayList<MuConfigUtils>();
	private static Map<String, Integer> muSectionPos = new LinkedHashMap<String, Integer>();
	private static Integer muPosSection = 0;
	private static Map<String, Integer> mrSectionPos = new LinkedHashMap<String, Integer>();
	private static Integer mrPosSection = 0;
	private static final String MU_DIC_PATH = "MuConfig.dic";
	private static final String MR_DIC_PATH = "MrConfig.dic";	

	/**
	 * Actived MU
	 */
	private static List<String> mulist = new ArrayList<String>();
	private static List<String> mrlist = new ArrayList<String>();

	/**
	 * get ini section and parameterkey
	 */
	static {
		ResourceLoader resourceLoader = new DefaultResourceLoader();
		Resource resource = resourceLoader.getResource(MU_DIC_PATH);

		ConfigReader config = new ConfigReader(resource);

		LinkedHashMap<String, LinkedHashMap<String, List<String>>> iniparameter = config
				.get();
		Set<String> sectionNames = iniparameter.keySet();
		Iterator<String> it = sectionNames.iterator();
		while (it.hasNext()) {
			Integer posItem = 0;
			MuConfigUtils muConfigsection = new MuConfigUtils();
			List<MuConfigSectionUtils> muConfigSections = new ArrayList<MuConfigSectionUtils>();
			String section = (String) it.next();
			LinkedHashMap<String, List<String>> sec = iniparameter.get(section);
			Set<Entry<String, List<String>>> parameter = sec.entrySet();
			Iterator<Entry<String, List<String>>> its = parameter.iterator();
			while (its.hasNext()) {
				MuConfigSectionUtils muConfigSection = new MuConfigSectionUtils();
				List<MuConfigItemUtils> muConfigItems = new ArrayList<MuConfigItemUtils>();
				Entry<String, List<String>> param = its.next();
				muConfigSection.setKey(param.getKey());
				muConfigSection.setMuConfigItems(muConfigItems);
				String[] strarray = param.getValue().get(0).split(";");
				muConfigSection.setRule(strarray[0]);				
				muConfigSection.setType(strarray[1]);
				muConfigSections.add(posItem, muConfigSection);
				muConfigsection.itemPos.put(param.getKey(), posItem);
				posItem++;
			}
			muConfigsection.setSection(section);
			muConfigsection.setMuConfigSection(muConfigSections);
			matchUnitParameterlist.add(muPosSection, muConfigsection);
			muSectionPos.put(section, muPosSection);
			muPosSection++;
		}

		ResourceLoader mrResourceLoader = new DefaultResourceLoader();
		Resource mrResource = mrResourceLoader.getResource(MR_DIC_PATH);

		ConfigReader mrConfig = new ConfigReader(mrResource);

		LinkedHashMap<String, LinkedHashMap<String, List<String>>> mrIniparameter = mrConfig
				.get();
		Set<String> mrSectionNames = mrIniparameter.keySet();
		Iterator<String> mrIt = mrSectionNames.iterator();
		while (mrIt.hasNext()) {
			Integer mrPosItem = 0;
			MuConfigUtils mrConfigsection = new MuConfigUtils();
			List<MuConfigSectionUtils> mrConfigSections = new ArrayList<MuConfigSectionUtils>();
			String mrSection = (String) mrIt.next();
			LinkedHashMap<String, List<String>> mrSec = mrIniparameter
					.get(mrSection);
			Set<Entry<String, List<String>>> mrParameter = mrSec.entrySet();
			Iterator<Entry<String, List<String>>> mrIts = mrParameter
					.iterator();
			while (mrIts.hasNext()) {
				MuConfigSectionUtils mrConfigSection = new MuConfigSectionUtils();
				List<MuConfigItemUtils> mrConfigItems = new ArrayList<MuConfigItemUtils>();
				Entry<String, List<String>> mrParam = mrIts.next();
				mrConfigSection.setKey(mrParam.getKey());
				mrConfigSection.setMuConfigItems(mrConfigItems);
				String[] strarray = mrParam.getValue().get(0).split(";");
				mrConfigSection.setRule(strarray[0]);
				mrConfigSection.setType(strarray[1]);
				mrConfigSections.add(mrPosItem, mrConfigSection);
				mrConfigsection.itemPos.put(mrParam.getKey(), mrPosItem);
				mrPosItem++;
			}
			mrConfigsection.setSection(mrSection);
			mrConfigsection.setMuConfigSection(mrConfigSections);
			mapReducerParameterlist.add(mrPosSection, mrConfigsection);
			mrSectionPos.put(mrSection, mrPosSection);
			mrPosSection++;			
		}		
	}

	/**
	 * get matchUnitParameterMap
	 * 
	 * @return
	 */
	public static List<MuConfigUtils> getMatchUnitParameterMap(boolean isMR) {
		if (isMR) {
			return mapReducerParameterlist;
		} else {
			return matchUnitParameterlist;
		}
	}

	/**
	 * get Actived MU List
	 * 
	 * @return
	 */
	public static List<String> getUnitlist(boolean isMR) {
		if (isMR) {
			return mrlist;
		} else {
			return mulist;
		}

	}

	/**
	 * clear Actived MU List
	 * 
	 * @return
	 */
	public static void clearMulist(boolean isMR) {
		if (isMR) {
			mrlist.clear();
		} else {
			mulist.clear();
		}
	}

	/**
	 * reset Match Unit Parameter Map
	 */
	public static void resetMatchUnitParameterMap(boolean isMR) {
		Integer posSection = 0;
		List<MuConfigUtils> list = null;
		if (isMR) {
			posSection = mrPosSection;
			list = mapReducerParameterlist;
		} else {
			posSection = muPosSection;
			list = matchUnitParameterlist;
		}
		for (int index = 0; index < posSection; index++) {
			Integer posItem = list.get(index).getMuConfigSection().size();
			for (int idx = 0; idx < posItem; idx++) {
				list.get(index).getMuConfigSection().get(idx)
						.getMuConfigItems().clear();
				list.get(index).getMuConfigSection().get(idx).ipPos.clear();
			}
		}
	}

	/**
	 * Set value ( known section and known param and known muIpname )
	 * 
	 * @param section
	 * @param param
	 * @param muIpname
	 * @param value
	 */
	private static void addMatchUnitParameterList(String section, String param,
			String muIpName, String value, boolean isMR) {
		Map<String, Integer> sectionPos = null;
		Integer posSection = 0;
		List<MuConfigUtils> unitParameterlist = null;
		if (isMR) {
			sectionPos = mrSectionPos;
			posSection = mrPosSection;
			unitParameterlist = mapReducerParameterlist;
		} else {
			sectionPos = muSectionPos;
			posSection = muPosSection;
			unitParameterlist = matchUnitParameterlist;
		}

		Integer sectionIndex;
		Integer itemIndex;
		Integer ipIndex;
		if ((sectionIndex = sectionPos.get(section)) == null) {
			return;
		} else if ((itemIndex = unitParameterlist.get(sectionIndex).itemPos
				.get(param)) == null) {
			return;
		} else if ((ipIndex = unitParameterlist.get(sectionIndex)
				.getMuConfigSection().get(itemIndex).ipPos.get(muIpName)) == null) {
			Integer posIp = unitParameterlist.get(sectionIndex)
					.getMuConfigSection().get(itemIndex).getMuConfigItems()
					.size();
			MuConfigItemUtils muConfigItemUtils = new MuConfigItemUtils();
			muConfigItemUtils.setMuIpName(muIpName);
			muConfigItemUtils.setValue(value);
			unitParameterlist.get(sectionIndex).getMuConfigSection()
					.get(itemIndex).getMuConfigItems()
					.add(posIp, muConfigItemUtils);
			unitParameterlist.get(sectionIndex).getMuConfigSection()
					.get(itemIndex).ipPos.put(muIpName, posIp);
		} else {
			unitParameterlist.get(sectionIndex).getMuConfigSection()
					.get(itemIndex).getMuConfigItems().get(ipIndex)
					.setValue(value);
		}
	}

	/**
	 * add actived MU
	 * 
	 * @param muIpname
	 */
	private static void addMuList(String muIpname) {
		boolean flag = false;
		if (mulist.size() > 0) {
			for (final String mu : mulist) {
				if (!mu.equals(muIpname)) {
					continue;
				} else {
					flag = true;
				}
			}
			if (!flag) {
				mulist.add(muIpname);
			}
		} else {
			mulist.add(muIpname);
		}
	}

	/**
	 * add actived Mr
	 * 
	 * @param muIpname
	 */
	private static void addMrList(String mrIpname) {
		boolean flag = false;
		if (mrlist.size() > 0) {
			for (final String mu : mrlist) {
				if (!mu.equals(mrIpname)) {
					continue;
				} else {
					flag = true;
				}
			}
			if (!flag) {
				mrlist.add(mrIpname);
			}
		} else {
			mrlist.add(mrIpname);
		}
	}

	/**
	 * read Ini and set value to map
	 * 
	 * @param filename
	 * @param smConfigfile
	 */
	public static synchronized void addMatchUnitList(InputStreamReader is,
			String muIpName, boolean isMR) {
		Wini iniparameter;
		if (isMR) {
			addMrList(muIpName);
		} else {
			addMuList(muIpName);
		}

		try {
			iniparameter = new Wini(is);
			Set<String> sectionNames = iniparameter.keySet();
			Iterator<String> it = sectionNames.iterator();
			while (it.hasNext()) {
				String section = (String) it.next();
				Section sec = iniparameter.get(section);
				Set<Entry<String, String>> parameter = sec.entrySet();
				Iterator<Entry<String, String>> its = parameter.iterator();
				while (its.hasNext()) {
					Entry<String, String> param = its.next();
					addMatchUnitParameterList(section, param.getKey(),
							muIpName, param.getValue(), isMR);
				}
			}
		} catch (InvalidFileFormatException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static List<String> getMuConfigSectionList() {
		List<String> sectionlist = new ArrayList<String>();
		for (int index = 0; index < matchUnitParameterlist.size(); index++) {
			sectionlist.add(matchUnitParameterlist.get(index).getSection());
		}
		return sectionlist;
	}

	public static List<String> getMrConfigSectionList() {
		List<String> sectionlist = new ArrayList<String>();
		for (int index = 0; index < mapReducerParameterlist.size(); index++) {
			sectionlist.add(mapReducerParameterlist.get(index).getSection());
		}
		return sectionlist;
	}
}
