package jp.co.nec.aim.sm.common.constant;

public class MonitorConstants {
	
	public static final String 	TI = "TI";
	public static final String 	TIM = "TIM"; 
	public static final String 	TLI = "TLI";
	public static final String 	TLIS = "TLIS";
	public static final String 	TLIX = "TLIX";
	public static final String 	TLIM = "TLIM";
	public static final String 	TLIXR = "TLIXR";
	public static final String 	TLIP = "TLIP";
	public static final String 	FI = "FI";
	public static final String 	II = "II";
	public static final String 	LI = "LI";
	public static final String 	LIS = "LIS";
	public static final String 	LIM = "LIM";
	public static final String 	LIX = "LIX";
	public static final String 	LLI = "LLI";
	public static final String 	LLIS = "LLIS";
	public static final String 	LLIM = "LLIM";
	public static final String 	LLIX = "LLIX";
	public static final String 	LIP = "LIP";
	public static final String 	LLIP = "LLIP";
	public static final String 	EXTRACT = "EXTRACT";
	
	public static final String 	LDBX = "LDBX";
	public static final String 	PLDB = "PLDB";
	public static final String 	FDB = "FDB";
	public static final String 	IDB = "IDB";
	public static final String 	RDBL = "RDBL";
	public static final String 	SDBL = "SDBL";
	public static final String 	RDBLS = "RDBLS";
	public static final String 	SDBLS = "SDBLS";
	public static final String 	RDBLM = "RDBLM";
	public static final String 	SDBLM = "SDBLM";
	public static final String 	XDBL = "XDBL";
	public static final String 	LDB = "LDB";
	public static final String 	LDBS = "LDBS";
	public static final String 	LDBM = "LDBM";
	public static final String 	PDB = "PDB";
	
	
	public static final String  LABEL = "label";
	public static final String  COLOR = "color";
	public static final String  VALUE = "value";
	
	public static final String  LABELS = "labels";	
	public static final String  DATASETS = "datasets";	
	public static final String  DATA = "data";
	public static final String  STROKE_COLOR = "strokeColor";
	public static final String  POINT_COLOR = "pointColor";
	public static final String  FILL_COLOR = "fillColor";
	
	public static final String  PRINT_FUNCTION = "tenprintFunction";
	public static final String  LATENT_FUNCTION = "latentFunction";
	
	public static final String WORKING_COLOR = "#2e8b57";
	public static final String TIME_OUT_COLOR = "yellow";
	public static final String EXIT_COLOR = "gray";	
	
	public static final String LINE_PRINT_POINT_COLOR = "";
	public static final String LINE_LATENT_POINT_COLOR = "";
	
	public static final String MU_LOAD_STROKE_COLOR = "";	
	public static final String MU_LOAD_FILL_COLOR = "";
	
	public static final String 	TI_LINE_STROKE_COLOR = "";
	public static final String 	TIM_LINE_STROKE_COLOR = ""; 
	public static final String 	TLI_LINE_STROKE_COLOR = "";
	public static final String 	TLIS_LINE_STROKE_COLOR = "";
	public static final String 	TLIM_LINE_STROKE_COLOR = "";
	public static final String 	TLIX_LINE_STROKE_COLOR = "";
	public static final String 	TLIP_LINE_STROKE_COLOR = "";
	public static final String 	FI_LINE_STROKE_COLOR = "";
	public static final String 	II_LINE_STROKE_COLOR = "";
	public static final String 	LI_LINE_STROKE_COLOR = "";
	public static final String 	LIS_LINE_STROKE_COLOR = "";
	public static final String 	LIM_LINE_STROKE_COLOR = "";
	public static final String 	LIX_LINE_STROKE_COLOR = "";
	public static final String 	LLI_LINE_STROKE_COLOR = "";
	public static final String 	LLIS_LINE_STROKE_COLOR = "";
	public static final String 	LLIM_LINE_STROKE_COLOR = "";
	public static final String 	LLIX_LINE_STROKE_COLOR = "";
	public static final String 	LIP_LINE_STROKE_COLOR = "";
	public static final String 	LLIP_LINE_STROKE_COLOR = "";
	public static final String 	EXTRACT_LINE_STROKE_COLOR = "";
	
	public static final String 	TI_LINE_POINT_COLOR = "";
	public static final String 	TIM_LINE_POINT_COLOR = ""; 
	public static final String 	TLI_LINE_POINT_COLOR = "";
	public static final String 	TLIS_LINE_POINT_COLOR = "";
	public static final String 	TLIM_LINE_POINT_COLOR = "";
	public static final String 	TLIX_LINE_POINT_COLOR = "";
	public static final String 	TLIP_LINE_POINT_COLOR = "";
	public static final String 	FI_LINE_POINT_COLOR = "";
	public static final String 	II_LINE_POINT_COLOR = "";
	public static final String 	LI_LINE_POINT_COLOR = "";
	public static final String 	LIS_LINE_POINT_COLOR = "";
	public static final String 	LIM_LINE_POINT_COLOR = "";
	public static final String 	LIX_LINE_POINT_COLOR = "";
	public static final String 	LLI_LINE_POINT_COLOR = "";
	public static final String 	LLIS_LINE_POINT_COLOR = "";
	public static final String 	LLIM_LINE_POINT_COLOR = "";
	public static final String 	LLIX_LINE_POINT_COLOR = "";
	public static final String 	LIP_LINE_POINT_COLOR = "";
	public static final String 	LLIP_LINE_POINT_COLOR = "";	
	public static final String 	EXTRACT_LINE_POINT_COLOR = "";
	
	public static final String PRINT_FUNCTION_FILL_COLOR = "";
	public static final String LATENT_FUNCTION_FILL_COLOR = "";	
	public static final String 	LDBX_BAR_FILL_COLOR = "";
	public static final String 	PLDB_BAR_FILL_COLOR = "";
	public static final String 	FDB_BAR_FILL_COLOR = "";
	public static final String 	IDB_BAR_FILL_COLOR = "";
	public static final String 	RDBL_BAR_FILL_COLOR = "";
	public static final String 	SDBL_BAR_FILL_COLOR = "";
	public static final String 	RDBLS_BAR_FILL_COLOR = "";
	public static final String 	SDBLS_BAR_FILL_COLOR = "";
	public static final String 	RDBLM_BAR_FILL_COLOR = "";
	public static final String 	SDBLM_BAR_FILL_COLOR = "";
	public static final String 	XDBL_BAR_FILL_COLOR = "";
	public static final String 	LDB_BAR_FILL_COLOR = "";
	public static final String 	LDBS_BAR_FILL_COLOR = "";
	public static final String 	LDBM_BAR_FILL_COLOR = "";	
	public static final String 	PDB_BAR_FILL_COLOR = "";

	public static final String 	PRINT_FUNCTION_STROKE_COLOR = "";
	public static final String 	LATENT_FUNCTION_STROKE_COLOR = "";
	public static final String 	LDBX_BAR_STROKE_COLOR = "";
	public static final String 	PLDB_BAR_STROKE_COLOR = "";
	public static final String 	FDB_BAR_STROKE_COLOR = "";
	public static final String 	IDB_BAR_STROKE_COLOR = "";
	public static final String 	RDBL_BAR_STROKE_COLOR = "";
	public static final String 	SDBL_BAR_STROKE_COLOR = "";
	public static final String 	RDBLS_BAR_STROKE_COLOR = "";
	public static final String 	SDBLS_BAR_STROKE_COLOR = "";
	public static final String 	RDBLM_BAR_STROKE_COLOR = "";
	public static final String 	SDBLM_BAR_STROKE_COLOR = "";
	public static final String 	XDBL_BAR_STROKE_COLOR = "";
	public static final String 	LDB_BAR_STROKE_COLOR = "";
	public static final String 	LDBS_BAR_STROKE_COLOR = "";
	public static final String 	LDBM_BAR_STROKE_COLOR = "";	
	public static final String 	PDB_BAR_STROKE_COLOR = "";
	
	public static final String  BEZIERCURE = "bezierCurve";
	public static final String  DATASET_FILL = "datasetFill";
	
}
