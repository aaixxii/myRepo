package jp.co.nec.aim.sm.modules.sys.postgres.repository;

import java.util.List;

import jp.co.nec.aim.sm.common.persistence.BaseRepository;
import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.modules.sys.postgres.entity.EventLogEntity;
import jp.co.nec.aim.sm.modules.sys.postgres.pojo.mapping.EventDetailPojo;
import jp.co.nec.aim.sm.modules.sys.postgres.pojo.mapping.EventLogPojo;
import jp.co.nec.aim.sm.modules.sys.postgres.pojo.mapping.MessageEventPojo;
import jp.co.nec.aim.sm.modules.sys.postgres.pojo.mapping.UnitEventPojo;

/**
 * EventLogRepository interface
 */
public interface EventLogRepository extends
		BaseRepository<EventLogEntity, Integer> {
	/** get messageType, messageCount from the table EVENT_LOG **/
	public List<EventLogPojo> getEvents(final EventLogEntity eventLog);

	/** get unitId, messageType, messageCount from the table EVENT_LOG **/
	public List<UnitEventPojo> getUnitEvents(EventLogEntity eventLog);

	/** get unitId, messageType, messageCode, messageCount from EVENT_LOG **/
	public List<MessageEventPojo> getMessageEvents(EventLogEntity eventLog);

	/** get unitId, messageType, messageCode, messageCount from EVENT_LOG **/
	public Page<MessageEventPojo> getMessageEvents(Page<MessageEventPojo> page,
			EventLogEntity eventLog);

	/** get unitId, messageType, messageCode, message from the table EVENT_LOG **/
	public List<EventDetailPojo> getEventDetail(EventLogEntity eventLog);

	/** get unitId, messageType, messageCode, message from the table EVENT_LOG **/
	public Page<EventDetailPojo> getEventDetail(Page<EventDetailPojo> page,
			EventLogEntity eventLog);

	/** get eventId, unitId, messageType, messageCode, message from EVENT_LOG **/
	public List<EventLogEntity> getEventLogs(EventLogEntity eventLog);

	/** get eventId, unitId, messageType, messageCode, message from EVENT_LOG **/
	public Page<EventLogEntity> getEventLogs(Page<EventLogEntity> page,
			EventLogEntity eventLog);
	
	/** get alarm info from postgres db**/
	public String getAlarmInfo(int timeValue);
	
	public String getDBTime() ;
}
