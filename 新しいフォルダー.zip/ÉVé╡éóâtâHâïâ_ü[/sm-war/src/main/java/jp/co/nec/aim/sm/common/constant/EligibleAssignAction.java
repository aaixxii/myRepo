package jp.co.nec.aim.sm.common.constant;

public enum EligibleAssignAction {
	Assign, Unassign;
}
