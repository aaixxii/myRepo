package jp.co.nec.aim.sm.modules.sys.oracle.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the LAST_ASSIGNED_MR database table.
 * 
 */
@Entity
@Table(name = "LAST_ASSIGNED_MR")
@NamedQuery(name = "LastAssignedMrEntity.findAll", query = "SELECT l FROM LastAssignedMrEntity l")
public class LastAssignedMrEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "ASSIGNED_LOCATION")
	private long assignedLocation;

	@Column(name = "ASSIGNED_TS")
	private long assignedTs;

	public LastAssignedMrEntity() {
	}

	public long getAssignedLocation() {
		return this.assignedLocation;
	}

	public void setAssignedLocation(long assignedLocation) {
		this.assignedLocation = assignedLocation;
	}

	public long getAssignedTs() {
		return this.assignedTs;
	}

	public void setAssignedTs(long assignedTs) {
		this.assignedTs = assignedTs;
	}

}