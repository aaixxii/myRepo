package jp.co.nec.aim.sm.common.worker;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

import jp.co.nec.aim.sm.common.async.agent.AsyncAgent;
import jp.co.nec.aim.sm.common.utils.SMUtil;
import jp.co.nec.aim.sm.unitcontrol.dispatcher.MessageManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class CollectStreamMessageWorker extends AbstractWorker {

	/** the log instance **/
	private static Logger logger = LoggerFactory
			.getLogger(CollectStreamMessageWorker.class);

	/**
	 * the message vector
	 */
	private final MessageManager manager;

	/**
	 * the std or error inputStream from the session
	 */
	private final InputStream is;

	/**
	 * the correct number of parameter
	 */
	private static final int CORRECT_PARA_NUMBER = 2;

	/**
	 * the default constructor
	 * 
	 * @param agent
	 */
	public CollectStreamMessageWorker(AsyncAgent agent) {
		super(agent);

		// get the parameter and cast to spefified type
		final Object[] paras = agent.getParameters();
		// the message vector used to collect
		// the message that output
		manager = SMUtil.cast(paras[0]);
		// the std or error inputStream from the session
		is = SMUtil.cast(paras[1]);
	}

	@Override
	protected void checkParameter(Object[] paras)
			throws IllegalArgumentException {
		if (SMUtil.isNullOrEmpty(paras)) {
			throw new IllegalArgumentException("the parameter is incorrect..");
		}

		if (paras.length != CORRECT_PARA_NUMBER) {
			throw new IllegalArgumentException(
					"the parameter length is not 2..");
		}
	}

	@Override
	protected Object doTask(Object[] paras) throws Exception {
		BufferedReader br = null;
		try {
			br = new BufferedReader(new InputStreamReader(is));

			String line = null;
			while ((line = br.readLine()) != null) {
				manager.appendMessages(line + "<br/>");
				if (logger.isInfoEnabled()) {
					logger.info(line);
				}
			}
		} catch (Exception ex) {
			throw ex;
		} finally {
			SMUtil.close(br);
		}
		return null;
	}
}
