package jp.co.nec.aim.sm.unitcontrol.dispatcher;

import java.util.ArrayList;
import java.util.List;

import jp.co.nec.aim.sm.common.async.agent.AsyncAgent;
import jp.co.nec.aim.sm.common.threadpool.ProcessMsg;
import jp.co.nec.aim.sm.common.utils.SMUtil;

/**
 * MessageManager supply the interface to the service <br>
 * the service will get the message and display in the page <br>
 * until the message vector is empty
 * 
 * @author liuyq
 * 
 */
public final class MessageManager {

	/**
	 * the agents of the selected unit list <br>
	 * all the result that thread executed <br>
	 * will be saved in this object list <br>
	 */
	private final List<AsyncAgent> agents;

	/**
	 * the instance of ProcessMsg
	 */
	private final ProcessMsg pMsg;

	/**
	 * the message during the post interval
	 */
	private final StringBuffer messages;

	/**
	 * create new instance of MessageManager
	 * 
	 * @return new instance of MessageManager
	 */
	public static MessageManager newInstance() {
		return new MessageManager();
	}

	/**
	 * the private default constructor
	 */
	private MessageManager() {
		this.agents = new ArrayList<AsyncAgent>();
		this.pMsg = new ProcessMsg();
		this.messages = new StringBuffer();
	}

	/**
	 * get the Agents lists
	 * 
	 * @return the Agents lists
	 */
	public List<AsyncAgent> getAgents() {
		return this.agents;
	}

	/**
	 * getMessages
	 * 
	 * @return StringBuffer instance
	 */
	public void appendMessages(String msg) {
		synchronized (messages) {
			messages.append(msg);
		}
	}

	/**
	 * get the message
	 * 
	 * @return the instance of ProcessMsg
	 */
	public ProcessMsg getpMsg() {
		if (SMUtil.isListNullOrEmpty(agents)) {
			return null;
		}

		if (SMUtil.isObjectNull(pMsg)) {
			return null;
		}

		pMsg.setFlag(isAllTasksDone());

		String msgStr;
		synchronized (messages) {
			msgStr = messages.toString();
			messages.setLength(0);
		}
		msgStr = msgStr.replace("\n", "<br/>");
		pMsg.setTmpMessage(msgStr);
		pMsg.setMessage(msgStr);
		return pMsg;
	}

	/**
	 * is all the tasks done
	 * 
	 * @return is all the tasks done
	 */
	private boolean isAllTasksDone() {
		boolean isAllDone = true;
		for (AsyncAgent agent : agents) {
			if (!agent.isDone()) {
				isAllDone = false;
				break;
			}
		}
		return isAllDone;
	}

}
