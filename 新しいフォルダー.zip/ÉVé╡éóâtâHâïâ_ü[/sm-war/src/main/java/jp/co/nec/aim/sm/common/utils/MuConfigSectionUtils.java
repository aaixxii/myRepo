package jp.co.nec.aim.sm.common.utils;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class MuConfigSectionUtils {
	private String key;
	private List<MuConfigItemUtils> muConfigItems;	
	private String rule;
	private String type;
	public Map<String, Integer> ipPos = new LinkedHashMap<String, Integer>();
	
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public List<MuConfigItemUtils> getMuConfigItems() {
		return muConfigItems;
	}
	public void setMuConfigItems(List<MuConfigItemUtils> muConfigItems) {
		this.muConfigItems = muConfigItems;
	}
	public String getRule() {
		return rule;
	}
	public void setRule(String rule) {
		this.rule = rule;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}	
}
