package jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import jp.co.nec.aim.sm.common.annocation.FieldMapped;
import jp.co.nec.aim.sm.common.annocation.InquiryMapping;
import jp.co.nec.aim.sm.common.constant.ContainerJobState;
import jp.co.nec.aim.sm.common.constant.JobState;
import jp.co.nec.aim.sm.common.utils.DateUtils;

import org.apache.commons.lang3.StringUtils;

/**
 * The persistent class for the CONTAINER_JOBS database table.
 * 
 */
@InquiryMapping
public class ContainerJob implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -1990840101293364021L;

	@FieldMapped
	private String containerJobId;
	@FieldMapped
	private String fusionJobId;
	@FieldMapped
	private String failedFlag;
	@FieldMapped
	private String jobState;
	@FieldMapped
	private String mrId;
	@FieldMapped
	private String targetSegments;
	@FieldMapped
	private String resultTs;
	@FieldMapped
	private byte[] containerJobResult;
	@FieldMapped
	private String planId;

	@SuppressWarnings("unused")
	private String resultTSStr;

	// @FieldMapped
	private String assignedTs;
	// @FieldMapped
	private String containerId;
	// private Byte[] containerJobResult;

	private List<ContainerJobState> statusList;

	public ContainerJob() {
	}

	public String getContainerJobId() {
		return containerJobId;
	}

	public void setContainerJobId(String containerJobId) {
		this.containerJobId = containerJobId;
	}

	public String getAssignedTs() {
		return assignedTs;
	}

	public void setAssignedTs(String assignedTs) {
		this.assignedTs = assignedTs;
	}

	public String getContainerId() {
		return containerId;
	}

	public void setContainerId(String containerId) {
		this.containerId = containerId;
	}

	public String getFusionJobId() {
		return fusionJobId;
	}

	public void setFusionJobId(String fusionJobId) {
		this.fusionJobId = fusionJobId;
	}

	public String getJobState() {
		if (StringUtils.isBlank(jobState)) {
			return StringUtils.EMPTY;
		}
		return JobState.values()[Integer.valueOf(jobState)].name();
	}

	public void setJobState(String jobState) {
		this.jobState = jobState;
	}

	public String getMrId() {
		return mrId;
	}

	public void setMrId(String mrId) {
		this.mrId = mrId;
	}

	public String getPlanId() {
		return planId;
	}

	public void setPlanId(String planId) {
		this.planId = planId;
	}

	public String getResultTs() {
		return resultTs;
	}

	public void setResultTs(String resultTs) {
		this.resultTs = resultTs;
	}

	public String getFailedFlag() {
		return failedFlag;
	}

	public void setFailedFlag(String failedFlag) {
		this.failedFlag = failedFlag;
	}

	public String getTargetSegments() {
		return targetSegments;
	}

	public void setTargetSegments(String targetSegments) {
		this.targetSegments = targetSegments;
	}

	public List<ContainerJobState> getStatusList() {
		if (statusList == null) {
			statusList = new ArrayList<ContainerJobState>();
		}

		return statusList;
	}

	public void setStatusList(List<ContainerJobState> statusList) {
		this.statusList = statusList;
	}

	public String getResultTSStr() {
		if (StringUtils.isBlank(resultTs)) {
			return StringUtils.EMPTY;
		}

		return DateUtils.formatDate(new Date(Long.valueOf(resultTs)),
				new Object[] { "yyyy-MM-dd HH:mm:ss" });
	}

}