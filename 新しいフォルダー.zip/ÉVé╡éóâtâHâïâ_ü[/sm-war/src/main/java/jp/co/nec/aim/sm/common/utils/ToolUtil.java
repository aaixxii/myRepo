package jp.co.nec.aim.sm.common.utils;

public class ToolUtil {
	private static final String IpPort_regex = ".*?((\\d{0,3}\\.){3}\\d{0,3}:{0,1}\\d{0,5}).*";
	private static final String IP_regex = ".*?((\\d{0,3}\\.){3}\\d{0,3}).*";
	private static final String replacement = "$1";

	public static String getIpAddress(String uniqueIp, String url) {
		if (url != null) {
			String ipPort = url.replaceAll(IP_regex, replacement);
			return ipPort;
		}
		if (uniqueIp != null) {
			String ipPort = uniqueIp.replaceAll(IP_regex, replacement);
			return ipPort;
		}
		return null;
	}

	public static String getIpPort(String url) {
		if (url != null) {
			String ipPort = url.replaceAll(IpPort_regex, replacement);
			return ipPort;
		}
		return null;
	}
}
