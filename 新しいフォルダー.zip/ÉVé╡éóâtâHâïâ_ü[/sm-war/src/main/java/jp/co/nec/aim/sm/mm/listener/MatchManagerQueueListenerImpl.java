package jp.co.nec.aim.sm.mm.listener;

import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import jp.co.nec.aim.sm.common.properties.SMProperties;
import jp.co.nec.aim.sm.mm.listener.reattempt.MatchManagerReattempt;
import jp.co.nec.aim.sm.modules.sys.postgres.repository.EventLogRepository;
import jp.co.nec.aim.sm.modules.sys.postgres.repository.ExtractjobQueueRepository;
import jp.co.nec.aim.sm.modules.sys.postgres.repository.JobQueueRepository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.xml.sax.InputSource;

/**
 *
 * 
 */
public class MatchManagerQueueListenerImpl implements MatchManagerQueueListener {

	@Autowired
	private EventLogRepository eventLogDao;
	@Autowired
	private JobQueueRepository jobRepository;
	@Autowired
	private ExtractjobQueueRepository extractjobQueueDao;

	private static final Logger log = LoggerFactory
			.getLogger(MatchManagerQueueListenerImpl.class);
	private MatchManagerReattempt matchManagerReattempt = new MatchManagerReattempt();
	private Map<String, QueueInformation> lstQueueInfo = new HashMap<String, QueueInformation>();
	private Map<String, QueueRunner> lstThread = new HashMap<String, QueueRunner>();
	private Thread queueNotifierThread = null;
	private static int STATUS = STOPPED;

	private void initializeQueueListener() {
		log.info("->initializeQueueListener()");
		log.info("#initializeQueueListener() initialized"
				+ " match manager queue listener");
		QueueSAXHandler handler = new QueueSAXHandler();
		log.info("#initializeQueueListener() parsing queue"
				+ " configuration file");

		try {
			String filename = SMProperties.getQueueFileName();
			log.info("->filename: " + filename);
			ResourceLoader resourceLoader = new DefaultResourceLoader();
			Resource resource = resourceLoader.getResource(filename);

			InputSource in = new InputSource(resource.getInputStream());
			log.info("->Resource: " + resource + ",  InputSource: " + in);
			handler.parse(in);
			log.info("#initializeQueueListener() queue configuration "
					+ "file parsing finished");

			List<QueueInformation> lst = handler.getListQueues();
			Iterator<QueueInformation> iter = lst.iterator();
			while (iter.hasNext()) {
				QueueInformation queueInfo = (QueueInformation) iter.next();
				log.info("#initializeQueueListener() Queue Information:"
						+ " queueId= " + queueInfo.getQueueID()
						+ " Queue-Type= " + queueInfo.getQueueType()
						+ " queueName= " + queueInfo.getQueueName()
						+ " queueHostname= " + queueInfo.getQueueHostname()
						+ " queuePort= " + queueInfo.getQueuePort()
						+ " queueProtocol= " + queueInfo.getQueueProtocol()
						+ " reattemptCount= " + queueInfo.getReattemptCount()
						+ " timeout= " + queueInfo.getTimeout());

				if (QUEUE_TYPE_ERROR.equals(queueInfo.getQueueType().trim())) {
					ErrorMessageListener errorQueue = new ErrorMessageListener(
							eventLogDao, this, queueInfo.getQueueID());
					queueInfo.setMessageListener(errorQueue);
					queueInfo.setExceptionListener(errorQueue);
				} else if (QUEUE_TYPE_INFO.equals(queueInfo.getQueueType()
						.trim())) {
					InfoMessageListener infoQueue = new InfoMessageListener(
							eventLogDao, jobRepository, extractjobQueueDao,
							this, queueInfo.getQueueID());
					queueInfo.setMessageListener(infoQueue);
					queueInfo.setExceptionListener(infoQueue);
				} else {
					log.error("#initializeQueueListener() unable to"
							+ " parse queue configuration file");
				}
				lstQueueInfo.put(queueInfo.getQueueID(), queueInfo);
			}
		} catch (FileNotFoundException e) {
			log.error("#initializeQueueListener() FileNotFoundException: "
					+ e.toString());
		} catch (Exception e) {
			log.error("#initializeQueueListener() unable to parse queue"
					+ " configuration file, exception description: "
					+ e.toString());
		}
	}

	@Override
	public void shutdownQueueListener() {
		log.info("->shutdownQueueListener()");
		log.info("#shutdownQueueListener() shutdown queue listener,"
				+ " invoked queue service: " + STATUS);
		if (STATUS == STOPPED) {
			log.info("#shutdownQueueListener() match manger queue listener(s)"
					+ " are already stopped");
			return;
		}
		Iterator<String> iterator = lstThread.keySet().iterator();
		while (iterator.hasNext()) {
			QueueRunner queueRunner = lstThread.get(iterator.next());
			if (queueRunner != null) {
				queueRunner.shut();
				queueRunner.interrupt();
				log.info("#shutdownQueueListener() queueID : "
						+ queueRunner.getQueueInformation().getQueueID()
						+ " has been stopped");
			}
		}
		STATUS = STOPPED;

		lstQueueInfo.clear();
		lstThread.clear();

		log.info("<-shutdownQueueListener()");
	}

	public void shutdownQueueNotifier() {
		if (queueNotifierThread != null) {
			QueueConfigurationNotifier.setNeedStop(true);
			queueNotifierThread.interrupt();
			queueNotifierThread = null;
		}
	}

	@Override
	public void startupQueueListener() {
		log.info("->startupQueueListener()");
		log.info("#startupQueueListener() startup queue listener,"
				+ " invoked queue service: " + STATUS);
		if (STATUS == STOPPED) {
			lstQueueInfo.clear();
			initializeQueueListener();
			STATUS = WORKING;
			Iterator<String> iterator = lstQueueInfo.keySet().iterator();
			while (iterator.hasNext()) {
				QueueInformation queueInformation = (QueueInformation) lstQueueInfo
						.get(iterator.next());
				QueueRunner queueRunner = new QueueRunner(queueInformation,
						this);
				queueRunner.start();
				lstThread.put(queueInformation.getQueueID(), queueRunner);
				if (queueRunner.getQueueStatus() == 1) {
					log.info("#startupQueueListener() queueID = "
							+ queueInformation.getQueueID()
							+ " has been started: STATUS = " + STATUS);
				} else if (queueRunner.getQueueStatus() == 0) {
					log.info("#startupQueueListener() queueID = "
							+ queueInformation.getQueueID()
							+ " is unable to start, Queue is "
							+ "reattemepting to establish the connection.");
				}
			}
		}
		log.info("<-startupQueueListener()");
	}

	public void startQueueNotifier() {
		if (queueNotifierThread != null) {
			QueueConfigurationNotifier.setNeedStop(true);
			queueNotifierThread.interrupt();
		}
		queueNotifierThread = new Thread(new QueueConfigurationNotifier(this));
		queueNotifierThread.start();
	}

	public synchronized void notifyStatus(String queueId, String status) {
		if (NOTIFY_STATUS_ERROR.equals(status)) {
			try {
				Thread.sleep(10000);
			} catch (InterruptedException e) {
				log.error("InterruptedException: " + e.getMessage());
			}

			QueueInformation queueInfo = (QueueInformation) lstQueueInfo
					.get(queueId);
			QueueRunner th = lstThread.get(queueId);
			th.shut();
			th.interrupt();
			QueueRunner queueRunner = reattempt(queueInfo);
			if ((queueRunner == null) & (STATUS == STOPPED)) {
				matchManagerReattempt.notifyStatusListenerStopped(queueInfo);
			} else if ((queueRunner != null) & (STATUS != STOPPED)) {
				matchManagerReattempt.notifyStatusQueueStopped(queueInfo);
			}
			lstThread.put(queueId, queueRunner);
			lstQueueInfo.put(queueId, queueInfo);
		}
	}

	private synchronized QueueRunner reattempt(QueueInformation queueInfo) {
		matchManagerReattempt.queueReattempt(queueInfo);
		// syslog.info("MatchManagerQueueListenerImpl:reattempt ! Reattempting queue queueId = "
		// + queueInfo.getQueueID());
		if ((STATUS == WORKING)
				& (queueInfo.getReattemptCount() == UNLIMITED_REATTEMPT)) {
			matchManagerReattempt.queueUnlimitedReattempt(queueInfo);
			// syslog.info("MatchManagerQueueListenerImpl:reattempt ! Invoked unlimited reattempt queueId = "
			// + queueInfo.getQueueID());
			QueueRunner queueRunner = new QueueRunner(queueInfo, this);
			queueRunner.start();
			return queueRunner;
		} else if (STATUS == STOPPED) {
			return null;
		} else {
			matchManagerReattempt.queueLimitedReattempt(queueInfo);
			// syslog.info("MatchManagerQueueListenerImpl:reattempt ! Invoked limited reattempt queueId = "
			// + queueInfo.getQueueID());
			if (queueInfo.getReattemptRunCount() > 0) {
				queueInfo
						.setReattemptRunCount(queueInfo.getReattemptRunCount() - 1);
				/* Implementation of Queue Runner thread */
				QueueRunner queueRunner = new QueueRunner(queueInfo, this);
				queueRunner.start();
				return queueRunner;
			} else {
				matchManagerReattempt.queueReattemptFailed(queueInfo);
				// syslog.error("MatchManagerQueueListenerImpl:reattempt ! Reattempt unable to connect to queueId = "
				// + queueInfo.getQueueID());
				return null;
			}
		}
	}

	/**
	 * @return the lstQueueInfo
	 */
	public Map<String, QueueInformation> getLstQueueInfo() {
		return lstQueueInfo;
	}

	/**
	 * @return the lstThread
	 */
	public Map<String, QueueRunner> getLstThread() {
		return lstThread;
	}
}
