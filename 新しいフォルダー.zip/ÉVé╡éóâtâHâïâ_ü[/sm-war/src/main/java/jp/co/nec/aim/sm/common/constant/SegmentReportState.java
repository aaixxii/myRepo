package jp.co.nec.aim.sm.common.constant;

/**
 * @author rkumarak
 * 
 */
public enum SegmentReportState {

	IN_MEMORY(0), ON_DISK(1), CURRENTLY_DOWNLOADING(2), IN_DOWNLOAD_QUEUE(3), ERROR(
			4);

	private int state;

	private SegmentReportState(int state) {
		this.state = state;
	}

	public static SegmentReportState getSegmentReportState(int state) {
		for (SegmentReportState s : SegmentReportState.values()) {
			if (s.state == state)
				return s;
		}
		throw new IllegalArgumentException("Unknown SegmentReportState: "
				+ state);

	}

}
