package jp.co.nec.aim.sm.modules.sys.postgres.entity;

import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * @author nbhupendra
 */

@Entity
@Table(name = "\"JOB_QUEUE\"", schema = "public")
// @Table(name="JOB_QUEUE")
public class JobQueueEntity {

	@SequenceGenerator(name="seq_stat", sequenceName="job_queue_id")
	@Id	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="seq_stat")
	@Column(name = "\"JOB_QUEUE_ID\"")
	private Long jobQueueId;

	@Column(name = "\"JOB_ID\"")
	private Long jobId;

	@Column(name = "\"FUNCTION_ID\"")
	private Long functionId;

	@Column(name = "\"PRIORITY\"")
	private Integer priority;

	@Column(name = "\"STATE\"")
	private Integer state;

	@Column(name = "\"MATCH_COUNT\"")
	private Long matchCount;

	@Column(name = "\"READ_COUNT\"")
	private Long readCount;

	@Column(name = "\"HIT_FLAG\"")
	private Integer hitFlag;

	@Column(name = "\"SUBMISSION_TIME\"")
	private Timestamp submissionTime;

	@Column(name = "\"RESULT_TIME\"")
	private Timestamp resultTime;

	@Column(name = "\"FAILED\"")
	private Integer failed;

	@Column(name = "\"PAUSED\"")
	private Integer paused;

	@Column(name = "\"MAX_CANDIDATES\"")
	private Integer maxCandidates;

	@Column(name = "\"MIN_SCORE\"")
	private Integer minScore;

	@Column(name = "\"REVISION\"")
	private Integer revision;

	@Column(name = "\"CONSOLIDATED_BY_CONTAINER\"")
	private Integer consolidatedByContainer;

	@Column(name = "\"MULTI_RECORD_CANDIDATES\"")
	private Integer multiRecordCandidates;

	@Column(name = "\"PERCENTAGE_POINT\"")
	private Double percentagePoint;

	@Column(name = "\"HIT_THRESHOLD\"")
	private Integer hitThreshhold;

	@Column(name = "\"JOB_COUNT\"")
	private Integer jobCount;

	@Column(name = "\"MULTI_JOBS_HIT_COUNT\"")
	private Integer multiJobsHitCount;

	@Column(name = "\"MULTI_JOBS_FAILED_COUNT\"")
	private Integer multiJobsFailedCount;

	@Column(name = "\"ELAPSE_TIME_SUM\"")
	private Long elapseTimeSum;

	@Column(name = "\"ELAPSE_TIME_MAX\"")
	private Long elapseTimeMax;

	@Column(name = "\"ELAPSE_TIME_MIN\"")
	private Long elapseTimeMin;

	@Column(name = "\"SUMMARY_FLAG\"")
	private Integer summaryFlag;

	@Transient
	private String startTime;

	@Transient
	private String endTime;

	@Transient
	private List<String> functions;

	/**
	 * @return the hitThreshhold
	 */
	public Integer getHitThreshhold() {
		return hitThreshhold;
	}

	/**
	 * @param hitThreshhold
	 *            the hitThreshhold to set
	 */
	public void setHitThreshhold(Integer hitThreshhold) {
		this.hitThreshhold = hitThreshhold;
	}

	/**
	 * @return the percentagePoint
	 */
	public Double getPercentagePoint() {
		return percentagePoint;
	}

	/**
	 * @param percentagePoint
	 *            the percentagePoint to set
	 */
	public void setPercentagePoint(Double percentagePoint) {
		this.percentagePoint = percentagePoint;
	}

	/**
	 * @return the jobId
	 */
	public Long getJobId() {
		return jobId;
	}

	/**
	 * @param jobId
	 *            the jobId to set
	 */
	public void setJobId(Long jobId) {
		this.jobId = jobId;
	}

	/**
	 * @return the jobQueueId
	 */
	public Long getJobQueueId() {
		return jobQueueId;
	}

	/**
	 * @param jobQueueId
	 *            the jobQueueId to set
	 */
	public void setJobQueueId(Long jobQueueId) {
		this.jobQueueId = jobQueueId;
	}

	/**
	 * @return the state
	 */
	public Integer getState() {
		return state;
	}

	/**
	 * @param state
	 *            the state to set
	 */
	public void setState(Integer state) {
		this.state = state;
	}

	/**
	 * @return the submissionTime
	 */
	public Timestamp getSubmissionTime() {
		return submissionTime;
	}

	/**
	 * @param submissionTime
	 *            the submissionTime to set
	 */
	public void setSubmissionTime(Timestamp submissionTime) {
		this.submissionTime = submissionTime;
	}

	/**
	 * @return the resultTime
	 */
	public Timestamp getResultTime() {
		return resultTime;
	}

	/**
	 * @param resultTime
	 *            the resultTime to set
	 */
	public void setResultTime(Timestamp resultTime) {
		this.resultTime = resultTime;
	}

	/**
	 * @return the failed
	 */
	public Integer getFailed() {
		return failed;
	}

	/**
	 * @param failed
	 *            the failed to set
	 */
	public void setFailed(Integer failed) {
		this.failed = failed;
	}

	/**
	 * @return the paused
	 */
	public Integer getPaused() {
		return paused;
	}

	/**
	 * @param paused
	 *            the paused to set
	 */
	public void setPaused(Integer paused) {
		this.paused = paused;
	}

	/**
	 * @return the maxCandidates
	 */
	public Integer getMaxCandidates() {
		return maxCandidates;
	}

	/**
	 * @param maxCandidates
	 *            the maxCandidates to set
	 */
	public void setMaxCandidates(Integer maxCandidates) {
		this.maxCandidates = maxCandidates;
	}

	/**
	 * @return the minScore
	 */
	public Integer getMinScore() {
		return minScore;
	}

	/**
	 * @param minScore
	 *            the minScore to set
	 */
	public void setMinScore(Integer minScore) {
		this.minScore = minScore;
	}

	/**
	 * @return the revision
	 */
	public Integer getRevision() {
		return revision;
	}

	/**
	 * @param revision
	 *            the revision to set
	 */
	public void setRevision(Integer revision) {
		this.revision = revision;
	}

	/**
	 * @return the consolidatedByContainer
	 */
	public Integer getConsolidatedByContainer() {
		return consolidatedByContainer;
	}

	/**
	 * @param consolidatedByContainer
	 *            the consolidatedByContainer to set
	 */
	public void setConsolidatedByContainer(Integer consolidatedByContainer) {
		this.consolidatedByContainer = consolidatedByContainer;
	}

	/**
	 * @return the multiRecordCandidates
	 */
	public Integer getMultiRecordCandidates() {
		return multiRecordCandidates;
	}

	/**
	 * @param multiRecordCandidates
	 *            the multiRecordCandidates to set
	 */
	public void setMultiRecordCandidates(Integer multiRecordCandidates) {
		this.multiRecordCandidates = multiRecordCandidates;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setFunctionId(Long functionId) {
		this.functionId = functionId;
	}

	public Long getFunctionId() {
		return functionId;
	}

	public void setPriority(Integer priority) {
		this.priority = priority;
	}

	public Integer getPriority() {
		return priority;
	}

	public void setMatchCount(Long matchCount) {
		this.matchCount = matchCount;
	}

	public Long getMatchCount() {
		return matchCount;
	}

	public void setReadCount(Long readCount) {
		this.readCount = readCount;
	}

	public Long getReadCount() {
		return readCount;
	}

	public void setHitFlag(Integer hitFlag) {
		this.hitFlag = hitFlag;
	}

	public Integer getHitFlag() {
		return hitFlag;
	}

	public void setJobCount(Integer jobCount) {
		this.jobCount = jobCount;
	}

	public Integer getJobCount() {
		return jobCount;
	}

	public void setMultiJobsHitCount(Integer multiJobsHitCount) {
		this.multiJobsHitCount = multiJobsHitCount;
	}

	public Integer getMultiJobsHitCount() {
		return multiJobsHitCount;
	}

	public void setMultiJobsFailedCount(Integer multiJobsFailedCount) {
		this.multiJobsFailedCount = multiJobsFailedCount;
	}

	public Integer getMultiJobsFailedCount() {
		return multiJobsFailedCount;
	}

	public void setElapseTimeSum(Long elapseTimeSum) {
		this.elapseTimeSum = elapseTimeSum;
	}

	public Long getElapseTimeSum() {
		return elapseTimeSum;
	}

	public void setElapseTimeMax(Long elapseTimeMax) {
		this.elapseTimeMax = elapseTimeMax;
	}

	public Long getElapseTimeMax() {
		return elapseTimeMax;
	}

	public void setElapseTimeMin(Long elapseTimeMin) {
		this.elapseTimeMin = elapseTimeMin;
	}

	public Long getElapseTimeMin() {
		return elapseTimeMin;
	}

	public void setSummaryFlag(Integer summaryFlag) {
		this.summaryFlag = summaryFlag;
	}

	public Integer getSummaryFlag() {
		return summaryFlag;
	}

	public void setFunctions(List<String> functions) {
		this.functions = functions;
	}

	public List<String> getFunctions() {
		return functions;
	}

}
