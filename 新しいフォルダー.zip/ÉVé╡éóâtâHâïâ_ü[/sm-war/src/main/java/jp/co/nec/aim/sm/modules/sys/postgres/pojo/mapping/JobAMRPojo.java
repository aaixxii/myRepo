package jp.co.nec.aim.sm.modules.sys.postgres.pojo.mapping;

import java.io.Serializable;

import jp.co.nec.aim.sm.common.annocation.FieldMapped;
import jp.co.nec.aim.sm.common.annocation.InquiryMapping;

@InquiryMapping
public class JobAMRPojo implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 5852727087530972185L;

	@FieldMapped
	private String functionName;

	@FieldMapped
	private Long jobCountSum;

	@FieldMapped
	private Long readCountSum;

	@FieldMapped
	private Long matchCountSum;

	@FieldMapped
	private Double amrAvg;

	public void setFunctionName(String functionName) {
		this.functionName = functionName;
	}

	public String getFunctionName() {
		return functionName;
	}

	public void setJobCountSum(Long jobCountSum) {
		this.jobCountSum = jobCountSum;
	}

	public Long getJobCountSum() {
		return jobCountSum;
	}

	public void setReadCountSum(Long readCountSum) {
		this.readCountSum = readCountSum;
	}

	public Long getReadCountSum() {
		return readCountSum;
	}

	public void setMatchCountSum(Long matchCountSum) {
		this.matchCountSum = matchCountSum;
	}

	public Long getMatchCountSum() {
		return matchCountSum;
	}

	public void setAmrAvg(Double amrAvg) {
		this.amrAvg = amrAvg;
	}

	public Double getAmrAvg() {
		return amrAvg;
	}

}
