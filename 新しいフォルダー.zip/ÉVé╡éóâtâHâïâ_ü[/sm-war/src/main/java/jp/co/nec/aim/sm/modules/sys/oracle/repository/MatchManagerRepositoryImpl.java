package jp.co.nec.aim.sm.modules.sys.oracle.repository;

import org.springframework.beans.factory.annotation.Autowired;

public class MatchManagerRepositoryImpl {
	@Autowired
	private MatchManagerRepository repository;
}
