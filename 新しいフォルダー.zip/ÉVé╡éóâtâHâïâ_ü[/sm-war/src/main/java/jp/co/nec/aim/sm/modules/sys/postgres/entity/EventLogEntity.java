package jp.co.nec.aim.sm.modules.sys.postgres.entity;

import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * @author nbhupendra
 */

@Entity
@Table(name = "\"EVENT_LOG\"", schema = "public")
// @Table(name="EVENT_LOG")
public class EventLogEntity {

	/**
	 * @return the eventId
	 */
	public Integer getEventId() {
		return eventId;
	}

	/**
	 * @param eventId
	 *            the eventId to set
	 */
	public void setEventId(Integer eventId) {
		this.eventId = eventId;
	}

	/**
	 * @return the timestamp
	 */
	public Timestamp getTimestamp() {
		return timestamp;
	}

	/**
	 * @param timestamp
	 *            the timestamp to set
	 */
	public void setTimestamp(Timestamp timestamp) {
		this.timestamp = timestamp;
	}

	/**
	 * @return the unitId
	 */
	public Long getUnitId() {
		return unitId;
	}

	/**
	 * @param unitId
	 *            the unitId to set
	 */
	public void setUnitId(Long unitId) {
		this.unitId = unitId;
	}

	/**
	 * @return the messageCode
	 */
	public String getMessageCode() {
		return messageCode;
	}

	/**
	 * @param messageCode
	 *            the messageCode to set
	 */
	public void setMessageCode(String messageCode) {
		this.messageCode = messageCode;
	}

	/**
	 * @return the messageType
	 */
	public String getMessageType() {
		return messageType;
	}

	/**
	 * @param messageType
	 *            the messageType to set
	 */
	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * @param message
	 *            the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}

	/**
	 * @return the cls
	 */
	public String getCls() {
		return cls;
	}

	/**
	 * @param cls
	 *            the cls to set
	 */
	public void setCls(String cls) {
		this.cls = cls;
	}

	public int getMessageCount() {
		return messageCount;
	}

	public void setMessageCount(int messageCount) {
		this.messageCount = messageCount;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	@SequenceGenerator(name = "seq_stat", sequenceName = "event_log_id")
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_stat")
	@Column(name = "\"EVENT_ID\"")
	private Integer eventId;

	@Column(name = "\"UNIT_ID\"")
	private Long unitId;

	@Column(name = "\"TIMESTAMP\"", nullable = false, length = 19)
	private Timestamp timestamp;

	@Column(name = "\"MESSAGE_CODE\"")
	private String messageCode;

	@Column(name = "\"MESSAGE_TYPE\"")
	private String messageType;

	@Column(name = "\"MESSAGE\"")
	private String message;

	@Column(name = "\"CLASS\"")
	private String cls;

	@Transient
	private int messageCount;

	@Transient
	private String startTime;

	@Transient
	private String endTime;
	@Transient
	private List<String> msgTypeList;

	@Transient
	private String msgTypeName;

	@Override
	public String toString() {
		StringBuffer sbuff = new StringBuffer();
		sbuff.append("EventId=" + eventId);
		sbuff.append(",unitId=" + unitId);
		sbuff.append(",messageCode=" + messageCode);
		sbuff.append(",messageType=" + messageType);
		sbuff.append(",timestamp=" + timestamp);
		sbuff.append(",message=" + message);
		sbuff.append(",class=" + cls);
		return sbuff.toString();
	}

	public void setMsgTypeList(List<String> msgTypeList) {
		this.msgTypeList = msgTypeList;
	}

	public List<String> getMsgTypeList() {
		return msgTypeList;
	}

	/**
	 * @param msgTypeName
	 *            the msgTypeName to set
	 */
	public void setMsgTypeName(String msgTypeName) {
		this.msgTypeName = msgTypeName;
	}

	/**
	 * @return the msgTypeName
	 */
	public String getMsgTypeName() {
		return msgTypeName;
	}

}
