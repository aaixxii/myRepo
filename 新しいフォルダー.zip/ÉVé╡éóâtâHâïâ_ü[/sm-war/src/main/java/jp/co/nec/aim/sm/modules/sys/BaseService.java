package jp.co.nec.aim.sm.modules.sys;

import java.io.StringReader;
import java.io.StringWriter;

import javax.xml.transform.OutputKeys;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import jp.co.nec.aim.sm.common.constant.SMConstant;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class BaseService {

	private String XML_HEADER = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";

	protected Logger logger = LoggerFactory.getLogger(getClass());

	public String setField(String result) {
		String str = null;
		String xmlHead = "";
		if (!StringUtils.isNotBlank(result)) {
			return SMConstant.NOT_FOUND;
		} else {
			if (result.toLowerCase().contains("<?xml")) {
				int off = result.indexOf("?>") + 2;
				xmlHead = result.substring(0, off);
				result = result.substring(off);
			}
			str = prettyFormat(result);
		}
		return str.replace(XML_HEADER, xmlHead);
	}

	private String prettyFormat(String input, int indent) {
		try {
			Source xmlInput = new StreamSource(new StringReader(input));
			StringWriter stringWriter = new StringWriter();
			StreamResult xmlOutput = new StreamResult(stringWriter);
			TransformerFactory transformerFactory = TransformerFactory
					.newInstance();
			transformerFactory.setAttribute("indent-number", indent);
			Transformer transformer = transformerFactory.newTransformer();
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.transform(xmlInput, xmlOutput);
			return xmlOutput.getWriter().toString();
		} catch (Exception e) {
			logger.error(e.getMessage());
			return input;
		}
	}

	private String prettyFormat(String input) {
		return prettyFormat(input, 4);
	}

}
