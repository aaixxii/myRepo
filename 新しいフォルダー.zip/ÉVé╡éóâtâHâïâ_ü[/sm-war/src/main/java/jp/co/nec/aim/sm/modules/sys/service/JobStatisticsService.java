package jp.co.nec.aim.sm.modules.sys.service;

import java.util.ArrayList;
import java.util.List;

import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.exception.SMServiceException;
import jp.co.nec.aim.sm.modules.sys.BaseService;
import jp.co.nec.aim.sm.modules.sys.postgres.entity.JobStatistics;
import jp.co.nec.aim.sm.modules.sys.postgres.pojo.mapping.CardQualityPojo;
import jp.co.nec.aim.sm.modules.sys.postgres.repository.JobStatisticsRepository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Lists;

@Service
@Transactional(value = "postgresTXManager")
public class JobStatisticsService extends BaseService {
	/** the log instance **/
	private static Logger logger = LoggerFactory
			.getLogger(JobStatisticsService.class);

	@Autowired
	private JobStatisticsRepository jobRepository;

	public static int UNIT_AMR = 0;
	public static int UNIT_ELAPSE = 1;
	public static int SEGMNET_COUNT = 2;

	/**
	 * get data from JOB_STATISTICS for Unit Job AMR
	 * 
	 * @param page
	 * @param JobQueueEntity
	 * @return
	 */
	public Page<JobStatistics> getUnitJobAMR(Page<JobStatistics> page,
			JobStatistics JobQueueEntity) {
		try {
			return jobRepository.getUnitJobAMR(page, JobQueueEntity);
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			throw new SMServiceException(ex);
		}
	}

	/**
	 * get data from JOB_STATISTICS for Unit Job AMR
	 * 
	 * @param JobQueueEntity
	 * @return
	 */
	public List<JobStatistics> getUnitJobAMR(JobStatistics JobQueueEntity) {
		try {
			return jobRepository.getUnitJobAMR(JobQueueEntity);
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			throw new SMServiceException(ex);
		}
	}

	/**
	 * get data from JOB_STATISTICS for Unit Job Elapse
	 * 
	 * @param JobQueueEntity
	 * @return
	 */
	public List<JobStatistics> getUnitJobElapse(JobStatistics JobQueueEntity) {
		try {
			return jobRepository.getUnitJobElapse(JobQueueEntity);
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			throw new SMServiceException(ex);
		}
	}

	/**
	 * get data from JOB_STATISTICS for Unit Job Elapse
	 * 
	 * @param page
	 * @param JobQueueEntity
	 * @return
	 */
	public Page<JobStatistics> getUnitJobElapse(Page<JobStatistics> page,
			JobStatistics JobQueueEntity) {
		try {
			return jobRepository.getUnitJobElapse(page, JobQueueEntity);
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			throw new SMServiceException(ex);
		}
	}

	/**
	 * get Function List from JOB_STATISTICS
	 * 
	 * @return
	 */
	public List<String> getFunctionList() {
		try {
			return jobRepository.getFunctionList();
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			throw new SMServiceException(ex);
		}
	}

	/**
	 * get MuId List from JOB_STATISTICS
	 * 
	 * @return
	 */
	public List<Long> getMuIdList() {
		try {
			return jobRepository.getMuIdList();
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			throw new SMServiceException(ex);
		}
	}

	/**
	 * get qualityType(Roll), card quality data from JOB_STATISTICS
	 * 
	 * @param page
	 * @param jobStatEntity
	 * @return
	 */
	public Page<CardQualityPojo> getCardQualityRoll(Page<CardQualityPojo> page,
			JobStatistics jobStatEntity) {
		try {
			return jobRepository.getCardQualityRoll(page, jobStatEntity);
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			throw new SMServiceException(ex);
		}
	}

	/**
	 * get qualityType(Roll), card quality data from JOB_STATISTICS
	 * 
	 * @param jobStatEntity
	 * @return
	 */
	public List<CardQualityPojo> getCardQualityRoll(JobStatistics jobStatEntity) {
		try {
			return jobRepository.getCardQualityRoll(jobStatEntity);
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			throw new SMServiceException(ex);
		}
	}

	/**
	 * get qualityType(Slap), card quality data from JOB_STATISTICS
	 * 
	 * @param page
	 * @param jobStatEntity
	 * @return
	 */
	public Page<CardQualityPojo> getCardQualitySlap(Page<CardQualityPojo> page,
			JobStatistics jobStatEntity) {
		try {
			return jobRepository.getCardQualitySlap(page, jobStatEntity);
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			throw new SMServiceException(ex);
		}
	}

	/**
	 * get qualityType(Slap), card quality data from JOB_STATISTICS
	 * 
	 * @param jobStatEntity
	 * @return
	 */
	public List<CardQualityPojo> getCardQualitySlap(JobStatistics jobStatEntity) {
		try {
			return jobRepository.getCardQualitySlap(jobStatEntity);
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			throw new SMServiceException(ex);
		}
	}

	/**
	 * get qualityType(All), card quality data from JOB_STATISTICS
	 * 
	 * @param page
	 * @param jobStatEntity
	 * @return
	 */
	public Page<CardQualityPojo> getCardQuality(Page<CardQualityPojo> page,
			JobStatistics jobStatEntity) {
		try {
			return jobRepository.getCardQuality(page, jobStatEntity);
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			throw new SMServiceException(ex);
		}
	}

	/**
	 * get qualityType(All), card quality data from JOB_STATISTICS
	 * 
	 * @param jobStatEntity
	 * @return
	 */
	public List<CardQualityPojo> getCardQuality(JobStatistics jobStatEntity) {
		try {
			return jobRepository.getCardQuality(jobStatEntity);
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			throw new SMServiceException(ex);
		}
	}

	/**
	 * get Header List
	 * 
	 * @param jobList
	 * @param headers
	 * @return
	 */
	public List<String> getHeaderList(List<JobStatistics> jobList,
			String... headers) {
		List<String> headerList = new ArrayList<String>();
		headerList.add("Match Unit ID");

		// get Header List from UnitEventPojo
		for (int i = 0; i < jobList.size(); i++) {
			if (!headerList.contains(jobList.get(i).getFunction())) {
				headerList.add(jobList.get(i).getFunction());
			}
		}
		// add headers to Header List
		for (String head : headers) {
			headerList.add(head);
		}
		logger.info("get Header List");
		return headerList;
	}

	/**
	 * get Table Array from JobStatistics
	 * 
	 * @param headerList
	 * @param jobList
	 * @param flag
	 * @return
	 */
	private List<String[]> getTableArray(List<String> headerList,
			List<JobStatistics> jobList, int flag) {
		int rowId = -1;
		String muId = "";
		List<String[]> tableArray = new ArrayList<String[]>();
		Integer total = 0;

		logger.info("get Table Array from JobStatistics");
		for (int i = 0; i < jobList.size(); i++) {
			// new row data
			if (!muId.equals(jobList.get(i).getMuid())) {
				muId = jobList.get(i).getMuid().toString();
				rowId++;
				String[] array = new String[headerList.size()];
				for (int j = 1; j < array.length; j++) {
					if (flag == SEGMNET_COUNT) {
						array[j] = "";
					} else {
						array[j] = new Double(0).toString();
					}
				}
				tableArray.add(array);
				tableArray.get(rowId)[0] = muId;
				total = 0;
			}

			// set cell value
			int index = headerList.indexOf(jobList.get(i).getFunction());
			if (flag == UNIT_AMR) {
				tableArray.get(rowId)[index] = jobList.get(i).getAmr()
						.toString();
			} else if (flag == UNIT_ELAPSE) {
				tableArray.get(rowId)[index] = new Double(jobList.get(i)
						.getAvgOfElaps()).toString();
			} else if (flag == SEGMNET_COUNT) {
				tableArray.get(rowId)[index] = jobList.get(i).getJobCount()
						.toString();

				total += jobList.get(i).getJobCount();
				tableArray.get(rowId)[headerList.size() - 1] = total.toString();
			}
		}

		return tableArray;
	}

	/**
	 * get Table List(List<String>) from JobStatistics
	 * 
	 * @param headerList
	 * @param jobList
	 * @param flag
	 * @return
	 */
	public List<String> getTableList(List<String> headerList,
			List<JobStatistics> jobList, int flag) {
		// get Table Array from JobStatistics
		List<String[]> tableArray = getTableArray(headerList, jobList, flag);

		// convert to Table List(List<String>)
		List<String> tableList = new ArrayList<String>();
		for (int i = 0; i < tableArray.size(); i++) {
			tableList.addAll(Lists.newArrayList(tableArray.get(i)));
		}
		logger.info("get Table List(List<String>) from JobStatistics");
		return tableList;
	}

	/**
	 * get Table List(List<List<String>>) from JobStatistics
	 * 
	 * @param headerList
	 * @param jobList
	 * @param flag
	 * @return
	 */
	public List<List<String>> getLists(List<String> headerList,
			List<JobStatistics> jobList, int flag) {
		// get Table Array from JobStatistics
		List<String[]> tableArray = getTableArray(headerList, jobList, flag);

		// convert to Table List(List<List<String>>)
		List<List<String>> tableList = new ArrayList<List<String>>();
		for (int i = 0; i < tableArray.size(); i++) {
			tableList.add(Lists.newArrayList(tableArray.get(i)));
		}
		logger.info("get Table List(List<List<String>>) from JobStatistics");
		return tableList;
	}

	/**
	 * save And Flush JobStatistics
	 * 
	 * @param job
	 */
	public void saveAndFlush(JobStatistics job) {
		jobRepository.saveAndFlush(job);
	}
}
