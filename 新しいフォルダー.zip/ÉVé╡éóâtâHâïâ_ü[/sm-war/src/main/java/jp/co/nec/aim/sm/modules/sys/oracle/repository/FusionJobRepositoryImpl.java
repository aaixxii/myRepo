package jp.co.nec.aim.sm.modules.sys.oracle.repository;

import java.math.BigDecimal;
import java.util.List;

import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplate;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplateData;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBFusionJobInput;
import jp.co.nec.aim.message.proto.InquiryService.PBInquiryJobRequest;
import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.common.utils.SMUtil;
import jp.co.nec.aim.sm.exception.SMDaoException;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.FusionJobEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.FusionJob;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.jfree.util.Log;
import org.springframework.beans.factory.annotation.Autowired;

import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;

public class FusionJobRepositoryImpl {

	@Autowired
	FusionJobRepository repository;

	private final static String fusionjobsql = "select fj.FUSION_JOB_ID as fusionJobId,"
			+ "       ft.FUNCTION_NAME as functiontype,"
			+ "       fj.JOB_ID as jobId,"
			+ "       fj.SEARCH_REQUEST_INDEX as searchRequestIndex "
			+ "from FUNCTION_TYPES ft,"
			+ "     FUSION_JOBS fj "
			+ "where ft.FUNCTION_ID=fj.FUNCTION_ID";

	public Page<FusionJob> findFusionJobPage(Page<FusionJob> page,
			FusionJob fusionjob) {
		String sql = fusionjobsql;
		sql += getSql(fusionjob);
		if (!StringUtils.isNotBlank(page.getOrderBy())) {
			sql += " order by fusionJobId asc ";
		}
		return repository.findBySql(page, sql, FusionJob.class);
	}

	public List<FusionJob> findFusionJobList(FusionJob fusionjob) {
		String sql = fusionjobsql;
		sql += getSql(fusionjob);
		sql += " order by fusionJobId asc ";
		return repository.findBySql(sql, FusionJob.class);
	}

	private String getSql(FusionJob fusionjob) {
		String sql = "";
		final Long fusionJobId = fusionjob.getFusionJobId();
		Log.info(fusionJobId);
		if (!SMUtil.isObjectNull(fusionJobId)) {
			sql += " and fj.FUSION_JOB_ID=" + fusionJobId;
		}

		final Integer functionId = fusionjob.getFunctionId();
		if (!SMUtil.isObjectNull(functionId)) {
			sql += " and fj.FUNCTION_ID=" + functionId;
		}

		final String functionType = fusionjob.getFunctiontype();
		if (StringUtils.isNotBlank(functionType)) {
			sql += " and ft.FUNCTION_NAME=" + "'" + functionType + "'";
		}

		final Long jobId = fusionjob.getJobId();
		if (!SMUtil.isObjectNull(jobId)) {
			sql += " and fj.JOB_ID=" + jobId;
		}
		return sql;
	}

	public String findResultsByfusionJobId(Long fusionJobId, String field) {
		DetachedCriteria dc = DetachedCriteria.forClass(FusionJobEntity.class);
		if (!SMUtil.isObjectNull(fusionJobId)) {
			dc.add(Restrictions.eq("fusionJobId", fusionJobId));
		}
		dc.setProjection(Projections.property(field));
		List<byte[]> results = this.repository.findAndCast(dc);
		if (results.size() != 1) {
			return null;
		}
		byte[] bytes = results.get(0);

		if (bytes == null || bytes.length <= 0) {
			return "No Inquiry request data was found..";
		}

		PBInquiryJobRequest result;
		try {
			result = convertBinaryInKt(PBInquiryJobRequest.parseFrom(bytes));
		} catch (InvalidProtocolBufferException e) {
			throw new SMDaoException("InvalidProtocolBufferException occurred "
					+ "when parseFrom fusion job request bytes.", e);
		}
		return result.toString();
	}

	public PBInquiryJobRequest convertBinaryInKt(PBInquiryJobRequest req) {
		PBInquiryJobRequest.Builder builder = req.toBuilder();
		for (int i = 0; i < builder.getFusionJobInputBuilderList().size(); i++) {
			PBFusionJobInput.Builder fbuilder = builder.getFusionJobInput(i)
					.toBuilder();
			PBKeyedTemplateData.Builder ktdbuilder = fbuilder
					.getKeyedTemplateDataBuilder();
			PBKeyedTemplate.Builder ktbuilder = ktdbuilder
					.getKeyedTemplateBuilder().setTemplateBinary(
							convertBinaryToBase64orEmpty(ktdbuilder
									.getKeyedTemplate().getTemplateBinary()));
			ktdbuilder = ktdbuilder.setKeyedTemplate(ktbuilder.build());
			fbuilder = fbuilder.setKeyedTemplateData(ktdbuilder.build());
			builder = builder.setFusionJobInput(i, fbuilder.build());
		}
		PBInquiryJobRequest cReq = builder.build();
		return cReq;
	}

	public ByteString convertBinaryToBase64orEmpty(ByteString bs) {
		if (System.getenv("BINARY_EMPTY") != null) {
			return ByteString.copyFrom(new byte[0]);
		}
		return ByteString.copyFrom(Base64.encodeBase64(bs.toByteArray()));
	}

	public List<BigDecimal> getFunctionFamily(Long jobId) {
		String sql = "select f.function_family"
				+ " from function_types f, fusion_jobs fj"
				+ " where f.function_id = fj.function_id and fj.job_id = ?";
		return repository.findBySql(sql, jobId);
	}
}
