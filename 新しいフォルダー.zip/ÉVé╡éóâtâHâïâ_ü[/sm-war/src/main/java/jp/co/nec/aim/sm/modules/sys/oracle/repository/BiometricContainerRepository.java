package jp.co.nec.aim.sm.modules.sys.oracle.repository;

import java.util.List;

import jp.co.nec.aim.sm.common.persistence.BaseRepository;
import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.ContainerEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.BiometricContainerPojo;

public interface BiometricContainerRepository extends
		BaseRepository<ContainerEntity, Long> {

	/** find Biometric Container Page **/
	public Page<BiometricContainerPojo> findBiometricContainerPage(
			Page<BiometricContainerPojo> page,
			BiometricContainerPojo biometricContainer);

	/** update Biometric Container **/
	public int updateBiometricContainer(Long binId, String formatName,
			Long minimumRedundancy, Long minMuNumForSlb, Long maxSegmentSize);

	/** get All Bins **/
	public List<Long> getAllContainers();
	
	public List<ContainerEntity> getDmEligibleBinList(Long dmId) ;
}
