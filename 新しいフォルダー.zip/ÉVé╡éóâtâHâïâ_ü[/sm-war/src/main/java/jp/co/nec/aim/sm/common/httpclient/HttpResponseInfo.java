package jp.co.nec.aim.sm.common.httpclient;

import java.io.UnsupportedEncodingException;

import org.apache.commons.httpclient.HttpStatus;

/**
 * HttpResponseInfo
 * 
 * @author liuyq
 * 
 */
public final class HttpResponseInfo {

	/**
	 * HttpResponseInfo
	 * 
	 * @param statusCode
	 * @param bytes
	 */
	public HttpResponseInfo(int statusCode, byte[] bytes) {
		this.statusCode = statusCode;
		this.bytes = bytes;
	}

	private byte[] bytes;
	private int statusCode;

	public int getStatusCode() {
		return statusCode;
	}

	public String getBodyMessage() {
		try {
			return new String(bytes, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			return null;
		}
	}

	public byte[] getBytes() {
		return bytes;
	}

	public boolean isOK() {
		return (statusCode == HttpStatus.SC_OK);
	}
}
