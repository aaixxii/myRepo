package jp.co.nec.aim.sm.unitcontrol.message;

import jp.co.nec.aim.sm.common.constant.ProcessType;
import jp.co.nec.aim.sm.common.utils.DateUtils;
import jp.co.nec.aim.sm.common.utils.SMUtil;
import jp.co.nec.aim.sm.unitcontrol.dispatcher.MessageManager;

import org.slf4j.Logger;

/**
 * the Message tracker of UnitControl
 * 
 * @author liuyq
 * 
 */
public final class UnitControlMessage {

	/**
	 * the default constructor
	 * 
	 * @param unitIpAddress
	 * @param serviceName
	 * @param user
	 * @param processType
	 * @param message
	 */
	public UnitControlMessage(final String unitIpAddress,
			final String serviceName, final String user,
			final ProcessType processType, final MessageManager manager,
			final Logger logger) {
		this.unitIpAddress = unitIpAddress;
		this.serviceName = serviceName;
		this.user = user;
		this.processType = processType;
		this.manager = manager;
		this.logger = logger;
	}

	/**
	 * the another constructor
	 * 
	 * @param message
	 * @param logger
	 */
	public UnitControlMessage(final MessageManager manager, final Logger logger) {
		this(null, null, null, null, manager, logger);
	}

	/**
	 * the unit remote ip addres
	 */
	private final String unitIpAddress;

	/**
	 * the specified script name that exist in /etc/init.d
	 */
	private final String serviceName;

	/**
	 * the current user name
	 */
	private final String user;

	/**
	 * BR line
	 */
	private static final String BR = "\r";

	/**
	 * the process type
	 */
	private final ProcessType processType;

	/**
	 * the message vector
	 */
	private final MessageManager manager;

	/**
	 * the log instance
	 */
	private final Logger logger;

	/**
	 * push the Message
	 * 
	 * @param detail
	 *            the detail message
	 * @return the last message
	 */
	public void push(final String detail) {
		logger.info(message(true, detail));
		manager.appendMessages(message(false, detail));
	}

	/**
	 * push the Error message
	 * 
	 * @param detail
	 */
	public void pushError(final String detail, final Throwable e) {
		logger.error(message(true, detail), e);
		manager.appendMessages(message(false, "Error: " + detail));
	}

	/**
	 * push the Error message
	 * 
	 * @param detail
	 */
	public void pushError(final String detail) {
		logger.error(message(true, detail));
		manager.appendMessages(message(false, detail));
	}

	/**
	 * generate the message
	 * 
	 * @param isOutPutLog
	 * @param detail
	 * @return the appended message
	 */
	private String message(final boolean isOutPutLog, final String detail) {
		final StringBuffer message = new StringBuffer();

		if (!isOutPutLog) {
			message.append(BR);
			message.append("[");
			message.append(DateUtils.getDateTime());
			message.append("] ");
		}

		if (!SMUtil.isObjectNull(user) && !SMUtil.isObjectNull(unitIpAddress)) {
			message.append("[");
			message.append(user);
			message.append("@");
			message.append(unitIpAddress);
			message.append("]");
		}

		if (!SMUtil.isObjectNull(serviceName)) {
			message.append(" service name:");
			message.append(serviceName);
		}

		if (!SMUtil.isObjectNull(processType)) {
			message.append(" service type:");
			message.append(processType.name());
		}

		message.append(" ==> ");
		message.append(detail);
		message.append("<br>");
		return message.toString();
	}
}
