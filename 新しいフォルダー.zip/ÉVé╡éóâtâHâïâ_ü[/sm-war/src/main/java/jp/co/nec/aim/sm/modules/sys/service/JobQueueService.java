package jp.co.nec.aim.sm.modules.sys.service;

import java.util.Iterator;
import java.util.List;

import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.exception.SMServiceException;
import jp.co.nec.aim.sm.modules.sys.BaseService;
import jp.co.nec.aim.sm.modules.sys.postgres.entity.JobQueueEntity;
import jp.co.nec.aim.sm.modules.sys.postgres.pojo.mapping.JobAMRPojo;
import jp.co.nec.aim.sm.modules.sys.postgres.pojo.mapping.JobElapsePojo;
import jp.co.nec.aim.sm.modules.sys.postgres.repository.FunctionRepository;
import jp.co.nec.aim.sm.modules.sys.postgres.repository.JobQueueRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional(value = "postgresTXManager")
public class JobQueueService extends BaseService {

	@Autowired
	private JobQueueRepository jobRepository;

	@Autowired
	private FunctionRepository functionTypeDao;

	/**
	 * get all Inquiry Function Type
	 * 
	 * @return
	 */
	public List<String> findInquiryFunctionList() {
		try {
			List<String> list = functionTypeDao.findFunctionNameList();			
			for (Iterator<String> iterator = list.iterator(); iterator.hasNext(); ) {
				String value = iterator.next();
				if (value.toUpperCase().endsWith("-S")) {
					iterator.remove();					
				}				
				if (value.toUpperCase().equals("EXTRACTION")) {						
					iterator.remove();					
				}
			}
			return list;
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			throw new SMServiceException(ex);
		}
	}

	/**
	 * get JobAMRPojo form JOB_QUEUE, FUNCTION_TYPES
	 * 
	 * @param page
	 * @param JobQueueEntity
	 * @return
	 */
	public Page<JobAMRPojo> getJobAMR(Page<JobAMRPojo> page,
			JobQueueEntity JobQueueEntity) {
		try {
			return jobRepository.getJobAMR(page, JobQueueEntity);
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			throw new SMServiceException(ex);
		}
	}

	/**
	 * get JobAMRPojo form JOB_QUEUE, FUNCTION_TYPES
	 * 
	 * @param JobQueueEntity
	 * @return
	 */
	public List<JobAMRPojo> getJobAMR(JobQueueEntity JobQueueEntity) {
		try {
			return jobRepository.getJobAMR(JobQueueEntity);
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			throw new SMServiceException(ex);
		}
	}

	/**
	 * get JobElapsePojo form JOB_QUEUE, FUNCTION_TYPES
	 * 
	 * @param JobQueueEntity
	 * @return
	 */
	public List<JobElapsePojo> getJobElapse(JobQueueEntity JobQueueEntity) {
		try {
			return jobRepository.getJobElapse(JobQueueEntity);
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			throw new SMServiceException(ex);
		}
	}

	/**
	 * get JobElapsePojo form JOB_QUEUE, FUNCTION_TYPES
	 * 
	 * @param page
	 * @param JobQueueEntity
	 * @return
	 */
	public Page<JobElapsePojo> getJobElapse(Page<JobElapsePojo> page,
			JobQueueEntity JobQueueEntity) {
		try {
			return jobRepository.getJobElapse(page, JobQueueEntity);
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			throw new SMServiceException(ex);
		}
	}

	/**
	 * save And Flush JobQueueEntity
	 * 
	 * @param job
	 */
	public void saveAndFlush(JobQueueEntity job) {
		jobRepository.saveAndFlush(job);
	}
}
