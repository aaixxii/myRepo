package jp.co.nec.aim.sm.modules.sys.postgres.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "\"PRIVILEDGES\"", schema = "public")
public class Priviledge {

	/**
	 * @return the priviledgeId
	 */
	public long getPriviledgeId() {
		return priviledgeId;
	}

	/**
	 * @param priviledgeId
	 *            the priviledgeId to set
	 */
	public void setPriviledgeId(long priviledgeId) {
		this.priviledgeId = priviledgeId;
	}

	/**
	 * @return the priviledge
	 */
	public String getPriviledge() {
		return priviledge;
	}

	/**
	 * @param priviledge
	 *            the priviledge to set
	 */
	public void setPriviledge(String priviledge) {
		this.priviledge = priviledge;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description
	 *            the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	@Id
	@Column(name = "\"PRIVILEDGE_ID\"")
	private long priviledgeId;

	@Column(name = "\"PRIVILEDGE\"")
	private String priviledge;

	@Column(name = "\"ACTION\"")
	private String action;

	@Column(name = "\"DESCRIPTION\"")
	private String description;

	/**
	 * @return the action
	 */
	public String getAction() {
		return action;
	}

	/**
	 * @param action
	 *            the action to set
	 */
	public void setAction(String action) {
		this.action = action;
	}

}
