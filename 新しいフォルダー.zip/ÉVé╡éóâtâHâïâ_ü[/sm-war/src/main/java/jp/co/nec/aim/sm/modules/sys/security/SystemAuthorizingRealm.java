package jp.co.nec.aim.sm.modules.sys.security;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import jp.co.nec.aim.sm.common.utils.Encodes;
import jp.co.nec.aim.sm.common.utils.SpringContextHolder;
import jp.co.nec.aim.sm.exception.SMServiceException;
import jp.co.nec.aim.sm.modules.sys.postgres.entity.MenuEntity;
import jp.co.nec.aim.sm.modules.sys.postgres.entity.UserEntity;
import jp.co.nec.aim.sm.modules.sys.service.UserService;
import jp.co.nec.aim.sm.modules.sys.util.UserUtils;
import jp.co.nec.aim.sm.modules.sys.web.LoginController;

import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.SimpleAuthenticationInfo;
import org.apache.shiro.authc.credential.HashedCredentialsMatcher;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.cache.Cache;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.subject.SimplePrincipalCollection;
import org.apache.shiro.util.ByteSource;
import org.springframework.context.annotation.DependsOn;
import org.springframework.stereotype.Service;

@Service
@DependsOn({ "userRepository", "roleRepository" })
public class SystemAuthorizingRealm extends AuthorizingRealm {
	/**
	 * doGetAuthenticationInfo
	 */
	@Override
	protected AuthenticationInfo doGetAuthenticationInfo(
			AuthenticationToken authcToken) throws AuthenticationException {
		UsernamePasswordToken token = (UsernamePasswordToken) authcToken;

		if (LoginController.isValidateCodeLogin(token.getUsername(), false,
				false)) {
			// Session session = SecurityUtils.getSubject().getSession();
			// String code = (String) session
			// .getAttribute(ValidateCodeServlet.VALIDATE_CODE);
			if (token.getCaptcha() == null) {
				throw new SMServiceException("validate code error..");
			}
		}

		UserEntity user = getUserService().getUserByLoginName(
				token.getUsername());
		if (user != null) {
			byte[] salt = Encodes
					.decodeHex(user.getPassword().substring(0, 16));
			getUserService().updateUserLoginInfo(user.getId());
			return new SimpleAuthenticationInfo(new Principal(user), user
					.getPassword().substring(16), ByteSource.Util.bytes(salt),
					getName());
		} else {
			return null;
		}
	}

	/**
	 * 
	 */
	@Override
	protected AuthorizationInfo doGetAuthorizationInfo(
			PrincipalCollection principals) {
		Principal principal = (Principal) getAvailablePrincipal(principals);
		UserEntity user = getUserService().getUserByLoginName(
				principal.getLoginName());
		if (user != null) {
			UserUtils.putCache("user", user);
			SimpleAuthorizationInfo info = new SimpleAuthorizationInfo();
			List<MenuEntity> list = UserUtils.getMenuList();
			for (MenuEntity menu : list) {
				if (StringUtils.isNotBlank(menu.getPermission())) {
					info.addStringPermission(menu.getPermission());
				}
			}
			getUserService().updateUserLoginInfo(user.getId());
			return info;
		} else {
			return null;
		}
	}

	/**
	 * initCredentialsMatcher
	 */
	@PostConstruct
	public void initCredentialsMatcher() {
		HashedCredentialsMatcher matcher = new HashedCredentialsMatcher(
				UserService.HASH_ALGORITHM);
		matcher.setHashIterations(UserService.HASH_INTERATIONS);
		setCredentialsMatcher(matcher);
	}

	/**
	 * clearCachedAuthorizationInfo
	 */
	public void clearCachedAuthorizationInfo(String principal) {
		SimplePrincipalCollection principals = new SimplePrincipalCollection(
				principal, getName());
		clearCachedAuthorizationInfo(principals);
	}

	/**
	 * clearAllCachedAuthorizationInfo
	 */
	public void clearAllCachedAuthorizationInfo() {
		Cache<Object, AuthorizationInfo> cache = getAuthorizationCache();
		if (cache != null) {
			for (Object key : cache.keys()) {
				cache.remove(key);
			}
		}
	}

	private UserService userService;

	/**
	 * get user service
	 */
	public UserService getUserService() {
		if (userService == null) {
			userService = SpringContextHolder.getBean(UserService.class);
		}
		return userService;
	}

	/**
	 * Principal information
	 */
	public static class Principal implements Serializable {

		private static final long serialVersionUID = 1L;

		private Long id;
		private String loginName;
		private String name;
		private Map<String, Object> cacheMap;

		public Principal(UserEntity user) {
			this.id = user.getId();
			this.loginName = user.getLoginName();
			this.name = user.getName();
		}

		public Long getId() {
			return id;
		}

		public String getLoginName() {
			return loginName;
		}

		public String getName() {
			return name;
		}

		public Map<String, Object> getCacheMap() {
			if (cacheMap == null) {
				cacheMap = new HashMap<String, Object>();
			}
			return cacheMap;
		}

	}
}
