package jp.co.nec.aim.sm.unitcontrol.dispatcher;

import java.util.List;

import jp.co.nec.aim.sm.common.async.agent.AsyncAgent;
import jp.co.nec.aim.sm.common.constant.ProcessType;
import jp.co.nec.aim.sm.common.constant.UnitType;
import jp.co.nec.aim.sm.common.threadpool.SMExecutor;
import jp.co.nec.aim.sm.common.threadpool.StandardThreadExecutor;
import jp.co.nec.aim.sm.common.utils.SMUtil;
import jp.co.nec.aim.sm.common.utils.ToolUtil;
import jp.co.nec.aim.sm.common.worker.OperateRemoteServiceWorker;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.UnitPojo;
import jp.co.nec.aim.sm.unitcontrol.message.UnitControlMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * @author liuyq
 * 
 */
public final class RemoteTasksDispatcher {

	/**
	 * the log instance
	 */
	private static final Logger logger = LoggerFactory
			.getLogger(RemoteTasksDispatcher.class);

	/**
	 * the input parameter <br>
	 * include all the unit(DM,MM,MU,SM) that in state working<br>
	 */
	private final List<UnitPojo> pidUnitList;

	/**
	 * the current user name
	 */
	private final static String USER_NAME = System.getProperty("user.name");

	/**
	 * the process type
	 */
	private final ProcessType processType;

	/**
	 * the thread pool executor <br>
	 * thread pool core size -> 25 <br>
	 * thread pool max size -> 200<br>
	 */
	private static final SMExecutor executor = StandardThreadExecutor
			.getInstance();

	/**
	 * the agents of the selected unit list <br>
	 * all the result that thread executed <br>
	 * will be saved in this object list <br>
	 */
	private final List<AsyncAgent> asyncAgents;

	/**
	 * 
	 */
	private final MessageManager manager;

	/**
	 * messageTracker without the detail information
	 */
	private final UnitControlMessage messageTracker;

	/**
	 * the default constructor
	 * 
	 * @param pidUnitList
	 *            the selected units list
	 * @param processType
	 *            the process type
	 */
	public RemoteTasksDispatcher(final List<UnitPojo> pidUnitList,
			final ProcessType processType, final MessageManager manager) {
		this.pidUnitList = pidUnitList;
		this.processType = processType;

		// this manager instance is singleton
		this.manager = manager;
		final List<AsyncAgent> agents = this.manager.getAgents();

		// clear the agents lists due to
		// this manager instance is singleton
		agents.clear();
		this.asyncAgents = agents;

		this.messageTracker = new UnitControlMessage(manager, logger);
	}

	/**
	 * group the each unit and execute the given command
	 */
	public void execute() {
		logger.info("-> begin to method execute()");

		messageTracker.push("ready to loop the each units"
				+ " and execute asynchronously. ");

		// nothing to execute the command
		if (SMUtil.isListNullOrEmpty(pidUnitList)) {
			messageTracker.push("there is nothing units to execute, "
					+ "confirm that specify the unit to execute.");
			return;
		}

		boolean isSleep = false;
		if (pidUnitList.size() > 1
				&& !UnitType.MM.name().equals(pidUnitList.get(0).getType())
				&& UnitType.MM.name().equals(
						pidUnitList.get(pidUnitList.size() - 1).getType())) {
			isSleep = true;
		}

		// loop each unit and add OperateRemoteServiceWorker
		// to thread pool asynchronously
		for (final UnitPojo unit : pidUnitList) {
			// the message tracker with detail information
			UnitControlMessage tracker = null;
			try {
				// get the unit ip address
				// if the ip address can not be found
				// skip this unit, go continue next..
				final String ip = ToolUtil.getIpAddress(unit.getUniqueId(),
						unit.getContactURL());
				if (SMUtil.isObjectNull(ip)) {
					messageTracker.pushError("the unit ip address is missing.");
					continue;
				}

				// get the unit type (MM,MU,DM,SM)
				// if the unit type is not specified
				// skip this unit and go continue next..
				final UnitType unitType = UnitType.valueOf(unit.getType());
				if (SMUtil.isObjectNull(unitType)) {
					messageTracker.pushError("the unit type is incorrect, "
							+ "type name:" + unit.getType());
					continue;
				}

				// message tracker instance
				tracker = new UnitControlMessage(ip, unitType.name(),
						USER_NAME, processType, manager, logger);

				// if the unit type is SM, skip do command
				if (unitType == UnitType.SM) {
					tracker.push("the unit type is SM, can not boot itself.");
					continue;
				}

				tracker.push("prepare the worker parameter AsyncAgent.");

				// prepare the instance of AsyncAgent.
				final AsyncAgent agent = AsyncAgent.newInstance(new Object[] {
						ip, unitType.getServiceName(), processType, manager });

				// submit the worker asynchronously
				// each worker will connect the remote server
				// with specified ip, and execute the given
				// command like /sbin/service mm start
				if (unitType == UnitType.MM) {
					executor.execute(new OperateRemoteServiceWorker(agent,
							isSleep));
				} else {
					executor.execute(new OperateRemoteServiceWorker(agent,
							false));
				}

				// add this object to the list
				// this object can tell the thread is done or not,
				// has exception nor not
				asyncAgents.add(agent);
			} catch (Exception ex) {
				final String error = "Exception occurred when add worker to "
						+ "thread pool.";
				if (SMUtil.isObjectNull(tracker)) {
					messageTracker.pushError(error, ex);
				} else {
					tracker.pushError(error, ex);
				}
			}
		}

		logger.info("-> finish to method execute()");
	}
}
