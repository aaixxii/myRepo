package jp.co.nec.aim.sm.modules.sys.postgres.repository;

import jp.co.nec.aim.sm.common.persistence.BaseRepository;
import jp.co.nec.aim.sm.modules.sys.postgres.entity.RoleEntity;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

/**
 * RoleRepository interface
 */
public interface RoleRepository extends BaseRepository<RoleEntity, Long> {
	@Query("from RoleEntity where name = ?1")
	public RoleEntity findByName(String name);

	@Modifying
	@Query("delete from RoleEntity where id = ?1")
	public int deleteById(Long id);
}
