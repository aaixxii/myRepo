package jp.co.nec.aim.sm.modules.sys.oracle.repository;

import java.util.List;

import jp.co.nec.aim.sm.common.persistence.BaseRepository;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.MatchUnitEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.ComponentStatus;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.DBMonitorData;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.MuLoadPojo;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.TransactionMonitorData;

public interface MonitorRepository extends
		BaseRepository<MatchUnitEntity, Long> {
	public List<ComponentStatus> getComponentStatusList();

	public List<DBMonitorData> getDBMonitorList(Integer scope);

	public List<TransactionMonitorData> getTransactionMonitorDataList();
	
	public String getSlbStatus();
	
	public List<MuLoadPojo> getMuInquiryLoadDataList();

	public List<MuLoadPojo> getMuExtractLoadDataList();
}
