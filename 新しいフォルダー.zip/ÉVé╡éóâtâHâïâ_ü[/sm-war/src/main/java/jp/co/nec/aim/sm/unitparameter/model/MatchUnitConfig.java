package jp.co.nec.aim.sm.unitparameter.model;

import jp.co.nec.aim.mm.exception.AimRuntimeException;


/**
 * json class
 * 
 * @author jinxl
 * 
 */
public class MatchUnitConfig implements Comparable<MatchUnitConfig>{
	/**
	 * mu index
	 */
	private Integer idx;
	/**
	 * mu ipaddress and port
	 */
	private String ipAddress;

	/**
	 * xml MUConfig
	 */
	private ConfigUpdateRequest muConfigurations;
	/**
	 * get MU Idx
	 * @return
	 */
	public Integer getIdx() {
		return idx;
	}
	
	/**
	 * set MU Idx
	 * @param idx
	 */
	public void setIdx(Integer idx) {
		this.idx = idx;
	}

	/**
	 * get mu ip and port
	 * 
	 * @return
	 */
	public String getIpAddress() {
		return ipAddress;
	}

	/**
	 * set mu ip and port
	 * 
	 * @param ipAddress
	 */
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public ConfigUpdateRequest getMuConfigurations() {
		return muConfigurations;
	}

	public void setMuConfigurations(ConfigUpdateRequest muConfigurations) {
		this.muConfigurations = muConfigurations;
	}

	@Override
	public int compareTo(MatchUnitConfig other) {
		if (other == null || !(other instanceof MatchUnitConfig)) {
			throw new AimRuntimeException("other is null or other is not a instance of MatchUnitConfig");
		}
		int first = this.getIdx().compareTo(other.getIdx());
		int second = this.getIpAddress().compareTo(other.getIpAddress());
		return first != 0 ? first: second;
	}
}
