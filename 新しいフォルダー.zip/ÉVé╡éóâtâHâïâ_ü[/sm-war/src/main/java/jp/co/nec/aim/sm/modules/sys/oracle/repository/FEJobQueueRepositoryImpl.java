package jp.co.nec.aim.sm.modules.sys.oracle.repository;

import java.io.IOException;
import java.util.List;

import jp.co.nec.aim.message.proto.AIMMessages.PBExtractJobResultInternal;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplate;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractLatentFingerOutput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractLatentOutput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractLatentPalmOutput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractOutputPayload;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractPalmOutput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractTenprintFingerOutput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractTenprintOutput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFingerPrelsectionDataOutput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFingerPsrData;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFingerQrData;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFingerQrDataOutput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFisData;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBImageData;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBMinutiaData;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBPaExtData;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBPrefilterData;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBPrefilterDataTenprintFinger;
import jp.co.nec.aim.message.proto.ExtractService.PBExtractJobResult;
import jp.co.nec.aim.sm.common.constant.FeJobStatus;
import jp.co.nec.aim.sm.common.constant.JobState;
import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.common.utils.DateUtils;
import jp.co.nec.aim.sm.common.utils.Deflater;
import jp.co.nec.aim.sm.common.utils.SMUtil;
import jp.co.nec.aim.sm.exception.SMDaoException;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.FeJobQueueEntity;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;

import com.google.protobuf.ByteString;

public class FEJobQueueRepositoryImpl {

	@Autowired
	FEJobQueueRepository repository;

	private final static String FAILED_REASON = "Completed Feature Extract "
			+ "Jobs by System Manage.";

	private final static String fejobsSql_complete = "UPDATE fe_job_queue"
			+ " SET job_state = 2, failed_flag = 1, results_ts = systimestamp,"
			+ " failure_count = failure_count + 1 WHERE job_state != 2"
			+ " and job_id = ?";
	private final static String fejobsReasonSql_complete = "INSERT INTO"
			+ " fe_job_failure_reasons (failure_id, mu_id, job_id, reason,"
			+ " failure_ts) select extract_failure_seq.nextval,"
			+ " case when MU_ID is null then -1 else MU_ID end, JOB_ID, '"
			+ FAILED_REASON + "', systimestamp from FE_JOB_QUEUE where"
			+ " JOB_ID = ?";

	private final static String fejobsSql_restart = "UPDATE fe_job_queue"
			+ " SET job_state = 0, failed_flag = 0, results_ts = null,"
			+ " results_xml = null, mu_id = null, process_start_ts = null,"
			+ " failure_count = 0 WHERE job_id = ?";

	public Page<FeJobQueueEntity> findFEJobQueuePage(
			Page<FeJobQueueEntity> page, FeJobQueueEntity fusionjob) {
		DetachedCriteria dc = getDetachedCriteria(fusionjob);
		// add order by condition
		if (!StringUtils.isNotEmpty(page.getOrderBy())) {
			dc.addOrder(Order.desc("jobId"));
		}
		return repository.findPage(page, dc);
	}

	public List<FeJobQueueEntity> findFEJobQueueList(FeJobQueueEntity fusionjob) {
		DetachedCriteria dc = getDetachedCriteria(fusionjob);
		dc.addOrder(Order.desc("jobId"));
		return repository.find(dc);
	}

	private DetachedCriteria getDetachedCriteria(FeJobQueueEntity fejob) {
		// create the DetachedCriteria instance without session
		final DetachedCriteria dc = DetachedCriteria
				.forClass(FeJobQueueEntity.class);

		Long jobid = fejob.getJobId();
		if (!SMUtil.isObjectNull(jobid)) {
			// dc.add(Restrictions.eq("jobId", jobid));
			dc.add(Restrictions.eq("jobId", jobid));
		}

		String submissionTS = fejob.getSubmissionTs();
		if (StringUtils.isNotBlank(submissionTS)) {
			long epoch = DateUtils.parseDate(submissionTS).getTime();
			dc.add(Restrictions.ge("submissionTs", String.valueOf(epoch)));
		}

		Integer functionid = fejob.getFunctionId();
		if (!SMUtil.isObjectNull(functionid)) {
			dc.add(Restrictions.eq("functionId", functionid));
		}

		JobState jobstatus = fejob.getJobStatus();
		if (!SMUtil.isObjectNull(jobstatus)) {
			dc.add(Restrictions.eq("jobStatus", jobstatus));
		}

		List<FeJobStatus> statusList = fejob.getStatusList();
		if (!SMUtil.isListNullOrEmpty(statusList)) {
			for (int i = statusList.size() - 1; i >= 0; i--) {
				if (statusList.get(i) == null) {
					statusList.remove(i);
				}
			}
			dc.add(Restrictions.in("jobStatus", statusList));
		}

		Integer failedflag = fejob.getFailedFlag();
		if (!SMUtil.isObjectNull(failedflag)) {
			dc.add(Restrictions.eq("failedFlag", failedflag));
		}

		Integer muid = fejob.getMatchUnitId();
		if (!SMUtil.isObjectNull(muid)) {
			dc.add(Restrictions.eq("matchUnitId", muid));
		}
		return dc;
	}

	public String findResultsByjobId(Long jobId, String field) {
		DetachedCriteria dc = DetachedCriteria.forClass(FeJobQueueEntity.class);
		if (!SMUtil.isObjectNull(jobId)) {
			dc.add(Restrictions.eq("jobId", jobId));
		}
		dc.setProjection(Projections.property("result"));
		List<byte[]> results = this.repository.findAndCast(dc);
		if (results.size() != 1) {
			return null;
		}
		byte[] bytes = results.get(0);
		if (bytes == null || bytes.length <= 0) {
			return "No results was found..";
		}

		PBExtractJobResult result;		
		
		try {
			result = convertByteData(unPressesPayloadExResult(bytes));
		} catch (IOException e) {
			throw new SMDaoException("InvalidProtocolBufferException occurred "
					+ "when parseFrom extract job result bytes.", e);
		} 
		return result.toString();
	}

	private PBExtractJobResult convertByteData(PBExtractJobResult res) {
		PBExtractJobResult.Builder builder = res.toBuilder();
		for (int i = 0; i < builder.getKeyedTemplateBuilderList().size(); i++) {
			builder.setKeyedTemplate(i,
					convertBinaryInKt(builder.getKeyedTemplateBuilder(i)));
		}
		if (builder.hasOutputPayload()) {
			PBExtractOutputPayload.Builder extOutPayloadBuilder = builder
					.getOutputPayloadBuilder();
			if (extOutPayloadBuilder.hasTenprintOutput()) {
				extOutPayloadBuilder
						.setTenprintOutput(convertBinaryInTenpOutput(extOutPayloadBuilder
								.getTenprintOutputBuilder()));
			}
			if (extOutPayloadBuilder.hasLatentOutput()) {
				extOutPayloadBuilder
						.setLatentOutput(convertBinaryInLatentOutput(extOutPayloadBuilder
								.getLatentOutputBuilder()));
			}
		}
		return builder.build();
	}	

	public PBKeyedTemplate convertBinaryInKt(PBKeyedTemplate.Builder builder) {
		ByteString bs = builder.getTemplateBinary();
		builder.setTemplateBinary(convertBinaryToBase64orEmpty(bs));
		return builder.build();
	}

	public PBExtractTenprintOutput convertBinaryInTenpOutput(
			PBExtractTenprintOutput.Builder builder) {
		if (builder.hasPsrData()) {
			builder.setPsrData(convertBinaryInPsrOutput(builder
					.getPsrDataBuilder()));
		}
		if (builder.hasQrData()) {
			builder.setQrData(convertBinaryInQrOutput(builder
					.getQrDataBuilder()));
		}
		for (int i = 0; i < builder.getFingerOutputCount(); i++) {
			builder.setFingerOutput(i, convertBinaryInTenpFinOutput(builder
					.getFingerOutputBuilder(i)));
		}
		for (int i = 0; i < builder.getPalmOutputCount(); i++) {
			builder.setPalmOutput(i,
					convertBinaryInPalmOutput(builder.getPalmOutputBuilder(i)));
		}
		return builder.build();
	}

	public PBExtractLatentOutput convertBinaryInLatentOutput(
			PBExtractLatentOutput.Builder builder) {
		if (builder.hasFingerOutput()) {
			builder.setFingerOutput(convertLatentFinOutput(builder
					.getFingerOutputBuilder()));
		}
		if (builder.hasPalmOutput()) {
			builder.setPalmOutput(convertBinaryInLatentPalmOutput(builder
					.getPalmOutputBuilder()));
		}
		return builder.build();
	}

	public PBExtractLatentPalmOutput convertBinaryInLatentPalmOutput(
			PBExtractLatentPalmOutput.Builder builder) {
		if (builder.hasMinutiaData()) {
			builder.setMinutiaData(convertBinaryInMinutiaData(builder
					.getMinutiaDataBuilder()));
		}
		for (int i = 0; i < builder.getPrefilterDataCount(); i++) {
			builder.setPrefilterData(i, convertBinaryInPrefilterData(builder
					.getPrefilterDataBuilder(i)));
		}
		if (builder.hasPaExtData()) {
			builder.setPaExtData(convertBinaryInPaExtData(builder
					.getPaExtDataBuilder()));
		}
		return builder.build();
	}

	public PBExtractLatentFingerOutput convertLatentFinOutput(
			PBExtractLatentFingerOutput.Builder builder) {
		for (int i = 0; i < builder.getMinutiaDataCount(); i++) {
			builder.setMinutiaData(
					i,
					convertBinaryInMinutiaData(builder.getMinutiaDataBuilder(i)));
		}
		for (int i = 0; i < builder.getPrefilterDataCount(); i++) {
			builder.setPrefilterData(i, convertBinaryInPrefilterData(builder
					.getPrefilterDataBuilder(i)));
		}
		for (int i = 0; i < builder.getFisDataCount(); i++) {
			builder.setFisData(i,
					convertBinaryInFisData(builder.getFisDataBuilder(i)));
		}
		return builder.build();
	}

	public PBExtractPalmOutput convertBinaryInPalmOutput(
			PBExtractPalmOutput.Builder builder) {
		builder.setMinutiaData(convertBinaryInMinutiaData(builder
				.getMinutiaDataBuilder()));
		for (int i = 0; i < builder.getPrefilterDataCount(); i++) {
			builder.setPrefilterData(i, convertBinaryInPrefilterData(builder
					.getPrefilterDataBuilder(i)));
		}
		builder.setPaExtData(convertBinaryInPaExtData(builder
				.getPaExtDataBuilder()));
		if (builder.hasImageData()) {
			builder.setImageData(convertBinaryInImageData(builder
					.getImageDataBuilder()));
		}
		return builder.build();
	}

	public PBPaExtData convertBinaryInPaExtData(PBPaExtData.Builder builder) {
		builder.setMinutia(convertBinaryToBase64orEmpty(builder.getMinutia()));
		builder.setSkeleton(convertBinaryToBase64orEmpty(builder.getSkeleton()));
		return builder.build();
	}

	public PBPrefilterData convertBinaryInPrefilterData(
			PBPrefilterData.Builder builder) {
		builder.setData(convertBinaryToBase64orEmpty(builder.getData()));
		return builder.build();
	}

	public PBExtractTenprintFingerOutput convertBinaryInTenpFinOutput(
			PBExtractTenprintFingerOutput.Builder builder) {
		for (int i = 0; i < builder.getMinutiaDataCount(); i++) {
			builder.setMinutiaData(
					i,
					convertBinaryInMinutiaData(builder.getMinutiaDataBuilder(i)));
		}
		for (int i = 0; i < builder.getPrefilterDataCount(); i++) {
			builder.setPrefilterData(i, convertBinaryInTenpFinPrefilter(builder
					.getPrefilterDataBuilder(i)));
		}
		for (int i = 0; i < builder.getFisDataCount(); i++) {
			builder.setFisData(i,
					convertBinaryInFisData(builder.getFisDataBuilder(i)));
		}
		if (builder.hasImageData()) {
			builder.setImageData(convertBinaryInImageData(builder
					.getImageDataBuilder()));
		}
		return builder.build();
	}

	public PBImageData convertBinaryInImageData(PBImageData.Builder builder) {
		if (builder.hasCroppedImage()) {
			builder.setCroppedImage(convertBinaryToBase64orEmpty(builder
					.getCroppedImage()));
		}
		if (builder.hasLowResolutionImage()) {
			builder.setLowResolutionImage(convertBinaryToBase64orEmpty(builder
					.getLowResolutionImage()));
		}
		return builder.build();
	}

	public PBFisData convertBinaryInFisData(PBFisData.Builder builder) {
		builder.setMinutia(convertBinaryToBase64orEmpty(builder.getMinutia()));
		builder.setSkeleton(convertBinaryToBase64orEmpty(builder.getSkeleton()));
		builder.setZone(convertBinaryToBase64orEmpty(builder.getZone()));
		return builder.build();
	}

	public PBPrefilterDataTenprintFinger convertBinaryInTenpFinPrefilter(
			PBPrefilterDataTenprintFinger.Builder builder) {
		if (builder.hasRolled()) {
			ByteString bs = builder.getRolled();
			builder.setRolled(convertBinaryToBase64orEmpty(bs));
		}
		if (builder.hasSlap()) {
			ByteString bs = builder.getSlap();
			builder.setSlap(convertBinaryToBase64orEmpty(bs));
		}
		return builder.build();
	}

	public PBMinutiaData convertBinaryInMinutiaData(
			PBMinutiaData.Builder builder) {
		ByteString bs = builder.getData();
		builder.setData(convertBinaryToBase64orEmpty(bs));
		return builder.build();
	}

	public PBFingerQrDataOutput convertBinaryInQrOutput(
			PBFingerQrDataOutput.Builder builder) {
		if (builder.hasQrS()) {
			builder.setQrS(convertBinaryInQrData(builder.getQrFBuilder()));
		}
		if (builder.hasQrF()) {
			builder.setQrF(convertBinaryInQrData(builder.getQrFBuilder()));
		}
		return builder.build();
	}

	public PBFingerQrData convertBinaryInQrData(PBFingerQrData.Builder builder) {
		if (builder.hasRolled()) {
			ByteString bs = builder.getRolled();
			builder.setRolled(convertBinaryToBase64orEmpty(bs));
		}
		if (builder.hasSlap()) {
			ByteString bs = builder.getSlap();
			builder.setSlap(convertBinaryToBase64orEmpty(bs));
		}
		return builder.build();
	}

	public PBFingerPrelsectionDataOutput convertBinaryInPsrOutput(
			PBFingerPrelsectionDataOutput.Builder builder) {
		for (int i = 0; i < builder.getRolled10Count(); i++) {
			builder.setRolled10(i,
					convertBinaryInPsrData(builder.getRolled10Builder(i)));
		}
		for (int i = 0; i < builder.getRolled8Count(); i++) {
			builder.setRolled8(i,
					convertBinaryInPsrData(builder.getRolled8Builder(i)));
		}
		for (int i = 0; i < builder.getSlapCount(); i++) {
			builder.setSlap(i,
					convertBinaryInPsrData(builder.getSlapBuilder(i)));
		}
		return builder.build();
	}

	public PBFingerPsrData convertBinaryInPsrData(
			PBFingerPsrData.Builder builder) {
		ByteString bs = builder.getData();
		builder.setData(convertBinaryToBase64orEmpty(bs));
		return builder.build();
	}

	public ByteString convertBinaryToBase64orEmpty(ByteString bs) {
		if (System.getenv("BINARY_EMPTY") != null) {
			return ByteString.copyFrom(new byte[0]);
		}
		return ByteString.copyFrom(Base64.encodeBase64(bs.toByteArray()));
	}

	public int restartJobs(List<Long> fejobIdlist) {
		int count = 0;
		for (Long fejobId : fejobIdlist) {
			count += repository.updateBySql(fejobsSql_restart, fejobId);
		}
		return count;
	}

	public int completeJobs(List<Long> fejobIdlist) {
		int count = 0;
		for (Long fejobId : fejobIdlist) {
			int ret = repository.updateBySql(fejobsSql_complete, fejobId);
			if (ret != 0) {
				repository.updateBySql(fejobsReasonSql_complete, fejobId);
				count += ret;
			}
		}
		return count;
	}

	public int updateFEPriority(FeJobQueueEntity fejob) {
		String sql = "update FE_JOB_QUEUE set PRIORITY = "
				+ fejob.getPriority() + " where JOB_ID = " + fejob.getJobId();

		return repository.updateBySql(sql);
	}
	
	public PBExtractJobResult unPressesPayloadExResult(
			byte[] compressedPayloadExResut) throws IOException {
		byte[] compressedOutputPayload = null;
		PBExtractJobResult.Builder newPBExtractJobResult = PBExtractJobResult
				.newBuilder();
		PBExtractJobResultInternal pbExInternal = PBExtractJobResultInternal
				.parseFrom(ByteString.copyFrom(compressedPayloadExResut));
		if (pbExInternal.hasCompressedOutputPayload()) {
			compressedOutputPayload = pbExInternal.getCompressedOutputPayload()
					.toByteArray();
			byte[] uncompressedOutputPayload = Deflater
					.uncompress(compressedOutputPayload);
			newPBExtractJobResult.setOutputPayload(PBExtractOutputPayload
					.parseFrom(uncompressedOutputPayload));
		}
		newPBExtractJobResult.setServiceState(pbExInternal.getServiceState());
		newPBExtractJobResult.setJobId(pbExInternal.getJobId());
		newPBExtractJobResult.addAllKeyedTemplate(pbExInternal
				.getKeyedTemplateList());
		return newPBExtractJobResult.build();
	}	
	
}
