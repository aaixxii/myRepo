package jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping;

import jp.co.nec.aim.sm.common.annocation.FieldMapped;
import jp.co.nec.aim.sm.common.annocation.InquiryMapping;

@InquiryMapping
public class SegmentsMUsSLBPojo {
	@FieldMapped
	private Long binId;

	@FieldMapped
	private Long segCount;

	@FieldMapped
	private Long muCount;

	@FieldMapped
	private Long muSegSum;

	@FieldMapped
	private Long avgSeg;

	private String formats;

	public SegmentsMUsSLBPojo() {

	}

	public void setSegCount(Long segCount) {
		this.segCount = segCount;
	}

	public Long getSegCount() {
		return segCount;
	}

	public void setMuCount(Long muCount) {
		this.muCount = muCount;
	}

	public Long getMuCount() {
		if (muCount == null) {
			return 0l;
		}
		return muCount;
	}

	public void setFormats(String formats) {
		this.formats = formats;
	}

	public String getFormats() {
		return formats;
	}

	public void setBinId(Long binId) {
		this.binId = binId;
	}

	public Long getBinId() {
		return binId;
	}

	public void setMuSegSum(Long muSegSum) {
		this.muSegSum = muSegSum;
	}

	public Long getMuSegSum() {
		return muSegSum;
	}

	public void setAvgSeg(Long avgSeg) {
		this.avgSeg = avgSeg;
	}

	public Long getAvgSeg() {
		return avgSeg;
	}
}
