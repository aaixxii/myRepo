package jp.co.nec.aim.sm.modules.sys.oracle.repository;

import java.util.List;

import jp.co.nec.aim.sm.common.persistence.BaseRepository;
import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.FusionJobEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.FusionJob;

public interface FusionJobRepository extends
		BaseRepository<FusionJobEntity, Long> {
	public Page<FusionJob> findFusionJobPage(Page<FusionJob> page,
			FusionJob fusionjob);

	public List<FusionJob> findFusionJobList(FusionJob fusionjob);

	public String findResultsByfusionJobId(Long fusionJobId, String field);
}
