package jp.co.nec.aim.sm.common.constant;

/**
 * @author rkumarak
 * 
 */
public enum ContainerJobState {

	NEW(0), ASSIGNED(1), COMPLETED(2);

	private int state;

	private ContainerJobState(int state) {
		this.state = state;
	}

	public static ContainerJobState getMuJobState(int value) {
		for (ContainerJobState j : ContainerJobState.values()) {
			if (j.state == value)
				return j;
		}
		throw new IllegalArgumentException("Unknown JobState: " + value);

	}

	/**
	 * @return Returns the state.
	 */
	public int getState() {
		return state;
	}

}
