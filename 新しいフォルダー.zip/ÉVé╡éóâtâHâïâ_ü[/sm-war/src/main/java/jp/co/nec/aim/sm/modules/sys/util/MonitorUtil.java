package jp.co.nec.aim.sm.modules.sys.util;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.ComponentStatus;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.ComponentStatusComparator;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.DBMonitorData;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.DBMonitorDataCompareator;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.MuLoadPojo;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.MuLoadPojoComparator;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.TransactionMonitorData;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.TransactionMonitorDataComparator;

public class MonitorUtil {
	
	public Map<String , Map<String,Integer>> convertStatusListToMap(List<ComponentStatus> toBeConvertedList) {		
		Map<String , Map<String,Integer>> statusMaps = new HashMap<String , Map<String,Integer>>();
		Collections.sort(toBeConvertedList, new ComponentStatusComparator());
		String componetName  = toBeConvertedList.get(0).getComponentName();
		Map<String,Integer> subMap = new HashMap<>();
		for (int i = 0; i < toBeConvertedList.size(); i++) {
			if (toBeConvertedList.get(i).getComponentName().equals(componetName)) {
				subMap.put(toBeConvertedList.get(i).getState(), toBeConvertedList.get(i).getCount());				
			} else {
				statusMaps.put(componetName, subMap);
				subMap = null;
				componetName = null;
				subMap = new HashMap<String,Integer>();	
				componetName  = toBeConvertedList.get(i).getComponentName();
				subMap.put(toBeConvertedList.get(i).getState(), toBeConvertedList.get(i).getCount());
			}		
		}
		if (subMap != null) {
			statusMaps.put(componetName, subMap);
		}		
		return statusMaps;			
	}
	
	public Map<String , Map<String,Integer>> convertDBMonitorListToMap(List<DBMonitorData> toBeConvertedList) {		
		Map<String , Map<String,Integer>> tempMaps = new HashMap<String , Map<String,Integer>>();
		Collections.sort(toBeConvertedList, new DBMonitorDataCompareator());
		String function  = toBeConvertedList.get(0).getFunction();
		Map<String,Integer> subMap = new HashMap<>();
		for (int i = 0; i < toBeConvertedList.size(); i++) {
			if (toBeConvertedList.get(i).getFunction().equals(function)) {
				subMap.put(toBeConvertedList.get(i).getTemplateFormat(), toBeConvertedList.get(i).getRecordCount());				
			} else {
				tempMaps.put(function, subMap);
				subMap = null;
				function = null;
				subMap = new HashMap<String,Integer>();	
				function  = toBeConvertedList.get(i).getFunction();
				subMap.put(toBeConvertedList.get(i).getTemplateFormat(), toBeConvertedList.get(i).getRecordCount());
			}		
		}
		if (subMap != null) {
			tempMaps.put(function, subMap);
		}		
		return tempMaps;			
	}

	public Map<String , Map<String,Long>> convertTransactionMonitorToMap(List<TransactionMonitorData> toBeConvertedList) {		
		Map<String , Map<String,Long>> transactionMaps = new HashMap<String , Map<String,Long>>();
		Collections.sort(toBeConvertedList,new TransactionMonitorDataComparator());
		String funtionType = toBeConvertedList.get(0).getFunctionType();
		Map<String,Long> subMap = new HashMap<>();
		for (int i = 0; i < toBeConvertedList.size(); i++) {
			if (toBeConvertedList.get(i).getFunctionType().equals(funtionType)) {
				subMap.put(toBeConvertedList.get(i).getFamily(), toBeConvertedList.get(i).getCount());				
			} else {
				transactionMaps.put(funtionType, subMap);
				subMap = null;
				funtionType = null;
				subMap = new HashMap<String,Long>();	
				funtionType  = toBeConvertedList.get(i).getFunctionType();
				subMap.put(toBeConvertedList.get(i).getFamily(), toBeConvertedList.get(i).getCount());
			}		
		}
		if (subMap != null) {
			transactionMaps.put(funtionType, subMap);
		}		
		return transactionMaps;			
	}	

	public Map<String,Long> convertMuLoadListToMap(List<MuLoadPojo> toBeConvertedList) {		
		Map<String,Long> muLoadMaps = new HashMap<String,Long>();
		Collections.sort(toBeConvertedList, new MuLoadPojoComparator());
		long currentMu = toBeConvertedList.get(0).getMuId().longValue();
		long currentSum = 0;
		for (int i = 0; i < toBeConvertedList.size(); i++) {
			if (toBeConvertedList.get(i).getMuId().longValue() == currentMu) {				
				currentSum += toBeConvertedList.get(i).getPressure().longValue();				
			} else {				
				muLoadMaps.put(String.valueOf(currentMu), currentSum);
				currentMu = toBeConvertedList.get(i).getMuId().longValue();
				currentSum = toBeConvertedList.get(i).getPressure().longValue();
			}		
	}
		muLoadMaps.put(String.valueOf(currentMu), currentSum);
		return muLoadMaps;
  }
}
