package jp.co.nec.aim.sm.modules.sys.oracle.repository;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.common.utils.SMUtil;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.ContainerEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.BiometricContainerPojo;

import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

public class BiometricContainerRepositoryImpl {
	/** the log instance **/
	private static Logger logger = LoggerFactory
			.getLogger(BiometricContainerRepositoryImpl.class);

	@Autowired
	BiometricContainerRepository repository;

	/**
	 * get Detached Criteria
	 * 
	 * @param biometricContainer
	 * @return
	 */
	private DetachedCriteria getDetachedCriteria(
			ContainerEntity biometricContainer) {
		// create the DetachedCriteria instance without session
		final DetachedCriteria dc = DetachedCriteria
				.forClass(ContainerEntity.class);

		// add condition ContainerEntityId
		final Long ContainerEntityId = (long) biometricContainer
				.getContainerId();
		if (!SMUtil.isObjectNull(ContainerEntityId)) {
			logger.debug("add condition ContainerEntityId = {}",
					ContainerEntityId);
			dc.add(Restrictions.eq("containerId", ContainerEntityId));
		}

		// add condition formatId
		final Long formatId = biometricContainer.getFormatId();
		if (!SMUtil.isObjectNull(formatId)) {
			logger.debug("add condition formatId = {}", formatId);
			dc.add(Restrictions.eq("formatId", formatId));
		}

		// add condition minimumRedundancy
		final Integer minimumRedundancy = biometricContainer.getMinRedundancy();
		if (!SMUtil.isObjectNull(minimumRedundancy)) {
			logger.debug("add condition minimumRedundancy = {}",
					minimumRedundancy);
			dc.add(Restrictions.eq("minimumRedundancy", minimumRedundancy));
		}
		return dc;
	}

	/**
	 * find Biometric Container Page
	 * 
	 * @param page
	 * @param biometricContainer
	 * @return
	 */
	public Page<BiometricContainerPojo> findBiometricContainerPage(
			Page<BiometricContainerPojo> page,
			BiometricContainerPojo biometricContainer) {
		String sql = "select CONTAINER_ID as binId, "
				+ "CONTAINER_NAME as containerName,SCOPE_ID as scopeId,"
				+ "FORMAT_NAME as format,"
				+ " MIN_REDUNDANCY as minimumRedundancy,"
				+ " MIN_MU_NUM_FOR_SLB as minMuNumForSlb,"
				+ " MAX_SEGMENT_SIZE as maxSegmentSize  "
				+ "from CONTAINERS b, FORMAT_TYPES ft "
				+ " where b.FORMAT_ID = ft.FORMAT_ID";

		Long binId = biometricContainer.getBinId();
		if (!SMUtil.isObjectNull(binId)) {
			sql += " and b.CONTAINER_ID=" + binId;
		}

		String format = biometricContainer.getFormat();
		if (StringUtils.isNotBlank(format)) {
			sql += " and ft.FORMAT_NAME = '" + format + "'";
		}
		sql += " order by CONTAINER_ID";		
		return repository.findBySql(page, sql, BiometricContainerPojo.class);
	}

	/**
	 * find Biometric Container List
	 * 
	 * @param page
	 * @param biometricContainer
	 * @return
	 */
	public List<ContainerEntity> findBiometricContainer(
			ContainerEntity biometricContainer) {
		final DetachedCriteria dc = getDetachedCriteria(biometricContainer);
		// add order by condition
		dc.addOrder(Order.asc("containerId"));

		logger.debug("find List for ContainerEntity");
		return repository.find(dc);
	}

	/**
	 * find Biometric Container List
	 * 
	 * @param page
	 * @param biometricContainer
	 * @return
	 */
	public List<BiometricContainerPojo> findBiometricContainer(
			BiometricContainerPojo biometricContainer) {
		String sql = "select CONTAINER_ID as binId, FORMAT_NAME as format,"
				+ " MIN_REDUNDANCY as minimumRedundancy"
				+ " from CONTAINERS b, FORMAT_TYPES ft "
				+ " where b.FORMAT_ID = ft.FORMAT_ID";

		Long binId = biometricContainer.getBinId();
		if (!SMUtil.isObjectNull(binId)) {
			sql += " and CONTAINER_ID=" + binId;
		}

		String format = biometricContainer.getFormat();
		if (StringUtils.isNotBlank(format)) {
			sql += " and FORMAT_NAME = '" + format + "'";
		}
		sql += " order by CONTAINER_ID";		
		return repository.findBySql(sql, BiometricContainerPojo.class);
	}

	/**
	 * update Biometric Container
	 * 
	 * @param binId
	 * @param formatName
	 * @param minimumRedundancy
	 * @return
	 */
	public int updateBiometricContainer(Long binId, String formatName,
			Long minimumRedundancy, Long minMuNumForSlb, Long maxSegmentSize) {
		String sql = "update CONTAINERS set MIN_REDUNDANCY = "
				+ minimumRedundancy + "" + ",MIN_MU_NUM_FOR_SLB = "
				+ minMuNumForSlb;
		if (maxSegmentSize != null) {
			sql += ",MAX_SEGMENT_SIZE = " + maxSegmentSize;
		}

		sql += " where CONTAINER_ID = " + binId;
		if (StringUtils.isNotBlank(formatName)) {
			sql += " and FORMAT_ID in ("
					+ "select FORMAT_ID from FORMAT_TYPES where FORMAT_NAME = '"
					+ formatName + "')";
		}

		logger.debug("update Biometric Container: MIN_REDUNDANCY = {}"
				+ " where CONTAINER_ID = {}, FORMAT_NAME = '{}'", new Object[] {
				minimumRedundancy, binId, formatName });
		return repository.updateBySql(sql);
	}

	/**
	 * get All Bins
	 * 
	 * @return
	 */
	public List<Long> getAllContainers() {
		String sql = "select CONTAINER_ID from CONTAINERS order by CONTAINER_ID";		
		List<BigDecimal> list = repository.findBySql(sql);

		logger.debug("change Bin ID List from BigDecimal to Long");
		List<Long> bins = new ArrayList<Long>();
		for (int i = 0; i < list.size(); i++) {
			bins.add(list.get(i).longValue());
		}
		return bins;
	}
	
	public List<ContainerEntity> getDmEligibleBinList(Long dmId) {
		String sqlString = ""
				+ "select * from containers c "
				+ "where c.container_id in "
				+ "(select container_id from DM_ELIGIBLE_CONTAINERS de "
				+ "where de.dm_id = ?)"; 		
			sqlString += " order by c.container_id";			
		
		return repository.findBySql(sqlString, ContainerEntity.class, dmId);
	}
}
