package jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping;

import java.io.Serializable;

public class ComponentStatus implements Serializable {
	private static final long serialVersionUID = 3901169944819727894L;
	private String componentName;
	private String state;
	private Integer count;

	public String getComponentName() {
		return componentName;
	}

	public ComponentStatus() {
	}

	public ComponentStatus(String componentName, String state, Integer count) {
		this.componentName = componentName;
		this.state = state;
		this.count = count;
	}

	public void setComponentName(String componentName) {
		this.componentName = componentName;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Integer getCount() {
		return count;
	}

	public void setCount(Integer count) {
		this.count = count;
	}

	@Override
	public int hashCode() {
		return this.componentName.hashCode() + this.state.hashCode()
				+ this.count.hashCode() + this.hashCode();
	}

	@Override
	public boolean equals(Object other) {
		if (other != null
				&& other instanceof ComponentStatus
				&& this.componentName
						.equals(((ComponentStatus) other).componentName)
				&& this.state.equals(((ComponentStatus) other).state)
				&& this.count.intValue() == ((ComponentStatus) other).count
						.intValue()) {
			return true;
		} else {
			return false;
		}
	}
}
