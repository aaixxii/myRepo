package jp.co.nec.aim.sm.exception;

/**
 * RSA File IncorrectException
 * 
 * @author liuyq
 */
public class RSAFileIncorrectException extends RuntimeException {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -335026656751093927L;

	/**
	 * @param message
	 */
	public RSAFileIncorrectException(String message) {
		super(message);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public RSAFileIncorrectException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * @param cause
	 */
	public RSAFileIncorrectException(Throwable cause) {
		super(cause);
	}
}
