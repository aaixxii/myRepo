package jp.co.nec.aim.sm.common.threadpool;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.TimeUnit;

import jp.co.nec.aim.sm.common.async.agent.AsyncAgent;
import jp.co.nec.aim.sm.common.utils.SMUtil;
import jp.co.nec.aim.sm.common.worker.AbstractWorker;

import org.hibernate.metamodel.domain.Superclass;

public final class StandardThreadExecutor implements SMExecutor {

	/**
	 * Default thread priority
	 */
	private int threadPriority = Thread.NORM_PRIORITY;

	/**
	 * Run threads in daemon or non-daemon state
	 */
	private boolean daemon = true;

	/**
	 * Default name prefix for the thread name
	 */
	private String namePrefix = "SystemMamager-Exec-";

	/**
	 * max number of threads
	 */
	private int maxThreads = 200;

	/**
	 * min number of threads
	 */
	private int minSpareThreads = 25;

	/**
	 * idle time in milliseconds
	 */
	private int maxIdleTime = 60000;

	/**
	 * The executor we use for this component
	 */
	private ThreadPoolExecutor executor = null;

	/**
	 * prestart threads?
	 */
	private boolean prestartminSpareThreads = false;

	/**
	 * The maximum number of elements that can queue up before we reject them
	 */
	protected int maxQueueSize = Integer.MAX_VALUE;

	/**
	 * After a context is stopped, threads in the pool are renewed. To avoid
	 * renewing all threads at the same time, this delay is observed between 2
	 * threads being renewed.
	 */
	protected long threadRenewalDelay = Constants.DEFAULT_THREAD_RENEWAL_DELAY;

	private TaskQueue taskqueue = null;
	private static StandardThreadExecutor instance = null;
	
	/**
	 * the default constructor
	 */
	private StandardThreadExecutor() {
		taskqueue = new TaskQueue(maxQueueSize);
		TaskThreadFactory tf = new TaskThreadFactory(namePrefix, daemon,
				threadPriority);
		executor = new ThreadPoolExecutor(minSpareThreads, getMaxThreads(),
				maxIdleTime, TimeUnit.MILLISECONDS, taskqueue, tf);
		if (prestartminSpareThreads) {
			executor.prestartAllCoreThreads();
		}
		taskqueue.setParent(executor);
	}

	/**
	 * get the single instance
	 * 
	 * @return the instance of StandardThreadExecutor
	 */
	public static synchronized StandardThreadExecutor getInstance() {
		if (instance == null) {
			instance = new StandardThreadExecutor();
		}
		return instance;
	}

	/**
	 * Stop the thread pool
	 */
	@Override
	public void stopInternal() {
		if (executor != null)
			executor.shutdownNow();
		executor = null;
		taskqueue = null;
	}

	/**
	 * see {@link Superclass}
	 */
	@Override
	public void execute(Runnable command, long timeout, TimeUnit unit) {
		if (executor != null) {
			executor.execute(command, timeout, unit);
		} else {
			throw new IllegalStateException(
					"StandardThreadExecutor not started.");
		}
	}

	/**
	 * see {@link Superclass}
	 */
	@Override
	public void execute(Runnable command) {
		if (executor != null) {
			try {
				executor.execute(command);
			} catch (RejectedExecutionException rx) {
				// there could have been contention around the queue
				if (!((TaskQueue) executor.getQueue()).force(command))
					throw new RejectedExecutionException("Work queue full.");
			}
		} else
			throw new IllegalStateException("StandardThreadPool not started.");
	}

	/**
	 * see {@link Superclass}
	 */
	public void contextStopping() {
		if (executor != null) {
			executor.contextStopping();
		}
	}

	/**
	 * see {@link Superclass}
	 */
	@Override
	public int getMaxThreads() {
		return maxThreads;
	}

	/**
	 * see {@link Superclass}
	 */
	@Override
	public int getActiveCount() {
		return (executor != null) ? executor.getActiveCount() : 0;
	}

	/**
	 * see {@link Superclass}
	 */
	@Override
	public long getCompletedTaskCount() {
		return (executor != null) ? executor.getCompletedTaskCount() : 0;
	}

	/**
	 * 
	 * @param args
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException {
		final int taskNumber = 100;

		final SMExecutor exec = StandardThreadExecutor.getInstance();
		final List<AsyncAgent> asyncAgents = new ArrayList<AsyncAgent>(
				taskNumber);

		for (int i = 0; i < taskNumber; i++) {
			final StringBuffer messages = new StringBuffer();
			final AsyncAgent agent = AsyncAgent
					.newInstance(new Object[] { messages });
			asyncAgents.add(agent);

			exec.execute(new AbstractWorker(agent) {
				@Override
				protected Object doTask(Object[] paras) throws Exception {

					final StringBuffer m = SMUtil.cast(paras[0]);
					final Thread t = Thread.currentThread();
					for (int i = 0; i < 100; i++) {
						if (t.isInterrupted()) {
							break;
						}

						m.append("Thread name:");
						m.append(t.getName());
						m.append(" i was loop ");
						m.append(i);
						m.append(" times.. ");
						m.append("\r\n");
						Thread.sleep(200);
					}
					return null;
				}

				@Override
				protected void checkParameter(Object[] paras)
						throws IllegalArgumentException {
					if (SMUtil.isNullOrEmpty(paras))
						throw new IllegalArgumentException(
								"the parameter is incorrect..");

					if (paras.length != 1)
						throw new IllegalArgumentException(
								"the parameter length is not 1..");

				}
			});
		}

		while (true) {
			for (final AsyncAgent a : asyncAgents) {
				final StringBuffer m = SMUtil.cast(a.getParameters()[0]);
				final String str = m.toString();
				if (!str.isEmpty()) {
					System.out.println(str);
					m.delete(0, m.length());
				}
			}
		}

	}
}
