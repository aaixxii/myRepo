package jp.co.nec.aim.sm.modules.sys.service;

import jp.co.nec.aim.sm.common.persistence.Page;
import jp.co.nec.aim.sm.exception.SMServiceException;
import jp.co.nec.aim.sm.modules.sys.BaseService;
import jp.co.nec.aim.sm.modules.sys.oracle.entities.MuSegmentEntity;
import jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping.SegmentSegmentReport;
import jp.co.nec.aim.sm.modules.sys.oracle.repository.MatchUnitSegmentRepository;
import jp.co.nec.aim.sm.modules.sys.oracle.repository.SegmentRepository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional(value = "oracleTXManager")
public class SegmentsService extends BaseService {
	/** the log instance **/
	private static Logger logger = LoggerFactory
			.getLogger(SegmentsService.class);
	
	@Autowired
	private SegmentRepository segmentDao;	

	@Autowired
	private MatchUnitSegmentRepository matchUnitSegmentDao;
	

	public Page<MuSegmentEntity> findSegmentAllocation(
			Page<MuSegmentEntity> page, MuSegmentEntity muSeg) {
		try {
			return matchUnitSegmentDao.findSegmentAllocation(page, muSeg);
		} catch (Exception ex) {
			logger.error("Find Segment Allocation Page Failed..", ex);
			throw new SMServiceException(ex);
		}
	}

	public Page<SegmentSegmentReport> getSegmentSegmentReports(
			Page<SegmentSegmentReport> page, Long muId) {
		try {
			return segmentDao.getSegmentSegmentReports(page, muId);
		} catch (Exception ex) {
			throw new SMServiceException(ex);
		}
	}
	
	public Page<SegmentSegmentReport> getDmSegmentSegmentReports(Page<SegmentSegmentReport> page, Long dmId) {
		try {
			return segmentDao.getDmSegmentSegmentReports(page, dmId);
		} catch (Exception ex) {
			throw new SMServiceException(ex);
		}		
	}
}
