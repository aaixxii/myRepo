package jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping;

import java.io.Serializable;

import jp.co.nec.aim.sm.common.annocation.FieldMapped;
import jp.co.nec.aim.sm.common.annocation.InquiryMapping;

/**
 * The container total information
 */
@InquiryMapping
public final class TotalInformation implements Serializable {
	/** serialVersionUID */
	private static final long serialVersionUID = 7193345967846409733L;

	/**
	 * Constructor
	 */
	public TotalInformation() {
	}

	/**
	 * Constructor
	 * 
	 * @param totalBinCount
	 * @param totalSegmentCount
	 * @param totalBinarySize
	 */
	public TotalInformation(int totalBinCount, int totalSegmentCount,
			long totalBinarySize) {
		this.totalBinCount = totalBinCount;
		this.totalSegmentCount = totalSegmentCount;
		this.totalBinarySize = totalBinarySize;
	}

	public Integer getTotalBinCount() {
		return totalBinCount;
	}

	public void setTotalBinCount(Integer totalBinCount) {
		this.totalBinCount = totalBinCount;
	}

	public Integer getTotalSegmentCount() {
		return totalSegmentCount;
	}

	public void setTotalSegmentCount(Integer totalSegmentCount) {
		this.totalSegmentCount = totalSegmentCount;
	}

	public Long getTotalBinarySize() {
		return totalBinarySize;
	}

	public void setTotalBinarySize(Long totalBinarySize) {
		this.totalBinarySize = totalBinarySize;
	}

	@FieldMapped
	private Integer totalBinCount;
	@FieldMapped
	private Integer totalSegmentCount;
	@FieldMapped
	private Long totalBinarySize;
}
