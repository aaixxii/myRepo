package jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping;

import java.util.List;

import jp.co.nec.aim.sm.common.constant.JobState;

public class JobPojo {
	private Long jobid;
	private String functiontype;
	private JobState jobStatus;
	private Integer failedFlag;
	private Integer priority;
	private List<JobState> statusList;
	private String submissionTS;

	public Long getJobid() {
		return jobid;
	}

	public void setJobid(Long jobid) {
		this.jobid = jobid;
	}

	public String getFunctiontype() {
		return functiontype;
	}

	public void setFunctiontype(String functiontype) {
		this.functiontype = functiontype;
	}

	public JobState getJobStatus() {
		return jobStatus;
	}

	public void setJobStatus(JobState jobStatus) {
		this.jobStatus = jobStatus;
	}

	public Integer getFailedFlag() {
		return failedFlag;
	}

	public void setFailedFlag(Integer failedFlag) {
		this.failedFlag = failedFlag;
	}

	public Integer getPriority() {
		return priority;
	}

	public void setPriority(Integer priority) {
		this.priority = priority;
	}

	public void setStatusList(List<JobState> statusList) {
		this.statusList = statusList;
	}

	public List<JobState> getStatusList() {
		return statusList;
	}

	public void setSubmissionTS(String submissionTS) {
		this.submissionTS = submissionTS;
	}

	public String getSubmissionTS() {
		return submissionTS;
	}

}
