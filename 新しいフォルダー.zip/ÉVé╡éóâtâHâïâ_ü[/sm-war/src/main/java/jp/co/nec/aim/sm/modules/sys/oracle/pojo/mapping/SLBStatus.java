package jp.co.nec.aim.sm.modules.sys.oracle.pojo.mapping;

public enum SLBStatus {
	ON, OFF;
}
