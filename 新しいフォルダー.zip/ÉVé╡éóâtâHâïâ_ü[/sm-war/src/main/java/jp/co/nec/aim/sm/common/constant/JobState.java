package jp.co.nec.aim.sm.common.constant;

public enum JobState {
	QUEUED(0), WORKING(1), COMPLETED(2);

	private int state;

	private JobState(int state) {
		this.state = state;
	}

	public static JobState getJobState(int value) {
		for (JobState j : JobState.values()) {
			if (j.state == value)
				return j;
		}
		throw new IllegalArgumentException("Unknown JobState: " + value);

	}

	/**
	 * @return Returns the state.
	 */
	public int getState() {
		return state;
	}
}
