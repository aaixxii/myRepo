package com.nec.aim.audio.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import lombok.extern.slf4j.Slf4j;

@Controller
public class AimAudioController {
	@RequestMapping("/")
	public String index() {
		return "index";		
	}
	
	@RequestMapping("/demo")
	public String getAudio() {
		return "audio";
	}

}
