package jp.co.alsok.g6.zwu.config;

import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.net.URL;

import javax.xml.parsers.ParserConfigurationException;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.PathMatchConfigurer;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.xml.sax.SAXException;

import jp.co.alsok.g6.common.log.ApplicationLog;
import jp.co.alsok.g6.zwu.web.common.SZWUInterceptor;
import jp.co.alsok.g6.zwu.web.common.SZWUMappingConst;
import jp.co.alsok.g6.zwu.web.constants.SZWUCommonConstants;

@Configuration
public class SZWUConfigurerAdapter implements WebMvcConfigurer {

    /**
     * 自己定义的拦截器类
     * 
     * @return
     */
    @Bean
    SZWUInterceptor szwuInterceptor() {
        return new SZWUInterceptor();
    }

    /* (非 Javadoc)
     * @see org.springframework.web.servlet.config.annotation.WebMvcConfigurer#configurePathMatch(org.springframework.web.servlet.config.annotation.PathMatchConfigurer)
     */
    @Override
    public void configurePathMatch(PathMatchConfigurer configurer) {
        WebMvcConfigurer.super.configurePathMatch(configurer);
      URL missurl = ClassLoader.getSystemResource("/home/alsok/apache-tomcat-9.0.20/webapps/alsok-g6-app/WEB-INF/classes/zwu_appLog.xml");
      System.out.print("missurl is null " + missurl == null);
      
        URL myUrl = Thread.currentThread().getContextClassLoader ().getResource(""); 
        System.out.print("myUrl is "+ myUrl.getFile());       
       URL applogUrl = ApplicationLog.class.getClassLoader().getResource("/");
       System.out.print("ApplicationLog.class url is "+ applogUrl.getFile()); 
        try {  
        	int size = applogUrl.getPath().length();
            ApplicationLog.readConfigurations(applogUrl.getPath().substring(size - 5,  size -1) + "/classes/zwu_appLog.xml");
        } catch (ParserConfigurationException | SAXException | IOException | URISyntaxException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {

        // add SZWU Interceptor
        registry.addInterceptor(szwuInterceptor()).addPathPatterns(SZWUMappingConst.BASE + "/**");
    }

}
