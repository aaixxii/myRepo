#!/bin/sh

# ----------------------------------------------------------------------
# Checking   paramters  all are correctly!
# 1. aim_release_version
# 2. currently_aim_branches_version
# 3. sm_developing_version
# exsample : ./doSMRelease.sh 5.0.3  5.0.2  5.0.1
# ----------------------------------------------------------------------


# Begin
# CHECK Args of doSMRelease()
if test  $# != 3 ; then
	echo Usage : ./doSMRelease.sh  aim_release_version  currently_aim_branches_version   sm_developing_version
	exit
fi

RELEASE_VER=$1
DEV_VER=$2
SM_VER=$3
DB_SCRIPT_COPY_TO_DIR=http://dev01a/shipment/branches/Release/AIM-$RELEASE_VER/AIM-$RELEASE_VER-ENV/sm-db/
RPM_COPY_TO_DIR=http://dev01a/shipment/branches/Release/AIM-$RELEASE_VER/AIM-$RELEASE_VER-PKG/AIM-$RELEASE_VER-BASIC/AIMInstaller/pkgs/

RPM_NAME=aim-sm-$SM_VER-0.x86_64.rpm
SM_TAG_DIR=http://dev01a/svn/tags/SystemManager/$RELEASE_VER/
SM_RELEASE_TAG_DIR=http://dev01a/svn/tags/Release/AIM-$RELEASE_VER/SystemManager/
count=0
SVN_USER=xia
SVN_PWD=xia

mkdir release
cd release

# added code 1
function checkZipContentDiff(){
    local zip_1=$1
    local zip_2=$2
    mkdir -p tmp/$zip_1 tmp/$zip_2
    unzip -o -d tmp/$zip_1 $zip_1 > /dev/null
    unzip -o -d tmp/$zip_2 $zip_2 > /dev/null
    local checkNum=`diff -r tmp/$zip_1 tmp/$zip_2|wc -l`
    rm -rf tmp
    return $checkNum
}

# --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# Release SM to shipment
# 1. Copy SM db script to http://dev01a/shipment/branches/Release/AIM-{releaseVer}/AIM-{releaseVer}-ENV/sm-db/
# 2. Copy SM rpm to http://dev01a/shipment/branches/Release/AIM-{releaseVer}/AIM-{releaseVer}-PKG/AIM-{releaseVer}-BASIC/AIMInstaller/pkgs/
# --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# CHECKOUT  SHIPMENT DIRECTORY OF DB_SCRIPT
svn ls --username $SVN_USER --password $SVN_PWD $DB_SCRIPT_COPY_TO_DIR > /dev/null
if test $? = 1 ; then
	svn mkdir --username $SVN_USER --password $SVN_PWD --parents --message "Directory Created By $SVN_USER" $DB_SCRIPT_COPY_TO_DIR
	svn co --username $SVN_USER --password $SVN_PWD $DB_SCRIPT_COPY_TO_DIR
else		
	svn co --username $SVN_USER --password $SVN_PWD --depth=empty $DB_SCRIPT_COPY_TO_DIR
	svn ls --username $SVN_USER --password $SVN_PWD $DB_SCRIPT_COPY_TO_DIR/sqlscript-sm.zip
	if test $? != 0 ; then
		svn up --username $SVN_USER --password $SVN_PWD --depth=files sm-db/sqlscript-sm.zip
	fi
fi

# added code 2
checkZipContentDiff sm-db/sqlscript-sm.zip ../sb-db/target/sqlscript-sm.zip
if test $? != 0 ; then
	cp -p -f ../sb-db/target/sqlscript-sm.zip sm-db/
	cd  sm-db
	svn add *
	svn commit --username $SVN_USER --password $SVN_PWD --message "Update By $SVN_USER"
	COMMIT_RESULT=$?
	if test $COMMIT_RESULT -eq 0 ; then	
		count=`expr $count + 1`	 
	fi
	cd ..
else
	echo "--------------------------------------------------------------------------------------------"
	echo "NO EXIST DIFF. SKIP $DB_SCRIPT_COPY_TO_DIR/sqlscript-sm.zip  UPDATE"
	echo "---------------------------------------------------------------------------------------------"
	count=`expr $count + 1`	 
fi


# CHECKOUT  SHIPMENT DIRECTORY OF SM RPM
svn ls --username $SVN_USER --password $SVN_PWD $RPM_COPY_TO_DIR > /dev/null
if test $? = 1 ; then
	svn mkdir --username $SVN_USER --password $SVN_PWD --parents --message "Directory Created By $SVN_USER" $RPM_COPY_TO_DIR
	svn co --username $SVN_USER --password $SVN_PWD $RPM_COPY_TO_DIR
else	
	svn co --username $SVN_USER --password $SVN_PWD --depth=empty $RPM_COPY_TO_DIR
	svn ls --username $SVN_USER --password $SVN_PWD $RPM_COPY_TO_DIR/$RPM_NAME
	if test $? = 0 ; then
		svn up --username $SVN_USER --password $SVN_PWD --depth=files pkgs/$RPM_NAME
	fi
fi
cp -p -f ../sm-war/target/rpm/aim-sm/RPMS/x86_64/$RPM_NAME pkgs/
cd  pkgs
svn add *
svn commit --username $SVN_USER --password  $SVN_PWD --message "Update By $SVN_USER"
COMMIT_RESULT=$?
if test $COMMIT_RESULT -eq 0 ; then	
	count=`expr $count + 1`
fi
cd ../../
rm -rf release

# ----------------------------------------------------------------------------------------------------------------------------------------
# Create Tag  for  SM
# 1. Copy SM sources form branche to http://dev01a/svn/tags/Release/AIM-${releaseVer}/SystemManager
# 2. Copy SM sources from branche to http://dev01a/svn/tags/SystemManager/${releaseVer}
# -----------------------------------------------------------------------------------------------------------------------------------------

echo "--------------------------------------------------------------------------------"
echo "CREATE SM TAG TO http://dev01a/svn/tags/Release/..."
echo "--------------------------------------------------------------------------------"
if test $count -eq 0 ; then 
	echo "There are commit failed. exit without make TAG."
	exit
fi

# CHECK IF TAG IS ALREADY CREATED OR NOT
svn ls --username $SVN_USER --password $SVN_PWD $SM_RELEASE_TAG_DIR > /dev/null
if test $? = 0 ; then
	svn delete --username $SVN_USER --password $SVN_PWD --message "Delete Tag by $SVN_USER" $SM_RELEASE_TAG_DIR
else 
	svn mkdir --username $SVN_USER --password $SVN_PWD --parents --message "Directory Created By $SVN_USER" $SM_RELEASE_TAG_DIR
fi

# CREATE SOURCE CODE TAG
svn copy --username $SVN_USER --password $SVN_PWD --message "Create Source Code Tag by $SVN_USER" --parents http://dev01a/svn/branches/AIM-$DEV_VER/SystemManager $SM_RELEASE_TAG_DIR

echo "--------------------------------------------------------------------------------------------"
echo "CREATE SM TAG TO http://dev01a/svn/tags/SystemManager/.. "
echo "---------------------------------------------------------------------------------------------"

# CHECK IF TAG IS ALREADY CREATED OR NOT
svn ls --username $SVN_USER --password $SVN_PWD $SM_TAG_DIR > /dev/null
if test $? = 0 ; then
	svn delete --username $SVN_USER --password $SVN_PWD --message "Delete Tag by $SVN_USER" $SM_TAG_DIR
else
	svn mkdir --username $SVN_USER --password $SVN_PWD --parents --message "Directory Created By $SVN_USER" $SM_TAG_DIR
fi

# CREATE SOURCE CODE TAG
svn copy --username $SVN_USER --password $SVN_PWD --message "Create Source Code Tag by $SVN_USER" --parents http://dev01a/svn/branches/AIM-$DEV_VER/SystemManager $SM_TAG_DIR

echo "Completed ......Done!"

