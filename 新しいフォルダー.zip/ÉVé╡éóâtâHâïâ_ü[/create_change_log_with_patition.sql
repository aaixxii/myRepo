-- segment change log init with partition

CREATE TABLE IF NOT EXISTS segment_change_log (
  segment_change_id BIGINT(38) ,
  biometrics_id BIGINT(38)  NOT NULL,
  external_id VARCHAR(36),
  template_data BLOB  NULL,   
  segment_id BIGINT(38)  NOT NULL ,
  segment_version BIGINT(38)  NOT NULL ,
  change_type INT(4)  NOT NULL,   #new:0,insert:1,delete:2,update:3 
  update_ts DATE  NOT NULL,
  p_no BIGINT NOT NULL,
  PRIMARY KEY (segment_change_id,p_no)
) 
PARTITION BY LIST (p_no)
(PARTITION p0 VALUES IN (0) ENGINE = InnoDB,
 PARTITION p1 VALUES IN (1) ENGINE = InnoDB,
 PARTITION p2 VALUES IN (2) ENGINE = InnoDB,
 PARTITION p3 VALUES IN (3) ENGINE = InnoDB,
 PARTITION p4 VALUES IN (4) ENGINE = InnoDB,
 PARTITION p5 VALUES IN (5) ENGINE = InnoDB,
 PARTITION p6 VALUES IN (6) ENGINE = InnoDB);

