package jp.co.nec.aim.mm.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.google.common.collect.Lists;

import jp.co.nec.aim.message.proto.BusinessMessage.E_REQUESET_TYPE;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBusinessMessage;
import jp.co.nec.aim.message.proto.BusinessMessage.PBCandidate;
import jp.co.nec.aim.message.proto.BusinessMessage.PBCandidateList;
import jp.co.nec.aim.message.proto.BusinessMessage.PBCandidateList.Builder;
import jp.co.nec.aim.message.proto.BusinessMessage.PBDataBlock;
import jp.co.nec.aim.message.proto.BusinessMessage.PBDataElement;
import jp.co.nec.aim.message.proto.BusinessMessage.PBDataGroup;
import jp.co.nec.aim.message.proto.BusinessMessage.PBProcessInfo;
import jp.co.nec.aim.message.proto.BusinessMessage.PBProcessMetrics;
import jp.co.nec.aim.message.proto.BusinessMessage.PBRequest;
import jp.co.nec.aim.message.proto.BusinessMessage.PBResponse;
import jp.co.nec.aim.message.proto.InquiryService.IdentifyResponse;

public class ProtbufAndAggregationTest {	
	@Before
	public void setUp() throws Exception {		
	}

	@After
	public void tearDown() throws Exception {
	}
	
	
	@Test
	public void PBDataElementComparatorTest() {
		List<PBDataElement> pbDeList = Lists.newArrayList();
		for (int i = 0 ; i < 5; i++) {
			PBDataElement.Builder pb = PBDataElement.newBuilder();
			pb.setElementName("read");
			pb.setElementValue(String.valueOf(i));
			pbDeList.add(pb.build());
		}
		for (int i = 3 ; i < 6; i++) {
			PBDataElement.Builder pb = PBDataElement.newBuilder();
			pb.setElementName("rmf");
			pb.setElementValue(String.valueOf(i));
			pbDeList.add(pb.build());
		}
		for (int i = 1 ; i < 5; i++) {
			PBDataElement.Builder pb = PBDataElement.newBuilder();
			pb.setElementName("iris");
			pb.setElementValue(String.valueOf(i));
			pbDeList.add(pb.build());
		}
		
		for (int i = 5; i < 10; i++) {
			PBDataElement.Builder pb = PBDataElement.newBuilder();
			pb.setElementName("face");
			pb.setElementValue(String.valueOf(i));
			pbDeList.add(pb.build());
		}
		Collections.shuffle(pbDeList); 
		System.out.print(pbDeList.toString());
		System.out.print("*************************");
		Collections.sort(pbDeList, new PBDataElementComparator());
		//pbDeList.stream().sorted(new PBDataElementComparator()).collect(Collectors.toList());		
		System.out.print(pbDeList.toString());		
		 
	}
	
	@Test
	public void SameCandidateMergeComparatorTest() {
		List<PBCandidate> pcList = Lists.newArrayList();
		for (int i = 0 ; i < 5; i++) {
			PBCandidate.Builder pb = PBCandidate.newBuilder();
			pb.setEnrollmentId("enroll");
			pb.setScaledScore(100 + i);			
			pcList.add(pb.build());
		}
		for (int i = 0 ; i < 4; i++) {
			PBCandidate.Builder pb = PBCandidate.newBuilder();
			pb.setEnrollmentId("external");
			pb.setScaledScore(10 + i);			
			pcList.add(pb.build());
		}
		
		for (int i = 0 ; i < 7; i++) {
			PBCandidate.Builder pb = PBCandidate.newBuilder();
			pb.setEnrollmentId("test" );
			pb.setScaledScore(27 + i);			
			pcList.add(pb.build());
		}
		Collections.shuffle(pcList); 
		System.out.print(pcList.toString());
		System.out.print("*************************");
		Collections.sort(pcList, new SameCandidateMergeComparator());		
		System.out.print(pcList.toString());
		
	}
	
	@Test
	public void CandidateLastComparatorTest() {
		List<PBCandidate> pcList = Lists.newArrayList();
		for (int i = 0 ; i < 5; i++) {
			PBCandidate.Builder pb = PBCandidate.newBuilder();
			pb.setEnrollmentId("enroll");
			pb.setScaledScore(100 + i);			
			pcList.add(pb.build());
		}
		for (int i = 0 ; i < 5; i++) {
			PBCandidate.Builder pb = PBCandidate.newBuilder();
			pb.setEnrollmentId("external");
			pb.setScaledScore(100 + i);			
			pcList.add(pb.build());
		}
		
		for (int i = 0 ; i < 7; i++) {
			PBCandidate.Builder pb = PBCandidate.newBuilder();
			pb.setEnrollmentId("test" );
			pb.setScaledScore(100 + i);			
			pcList.add(pb.build());
		}
		Collections.shuffle(pcList); 
		System.out.print(pcList.toString());
		System.out.print("*************************");
		Collections.sort(pcList, new CandidateLastComparator());		
		System.out.print(pcList.toString()); 
		
	}
	@Test
	public void calculatePBDataGroupAmrTest() {
		List<PBDataElement> pbDeList= new ArrayList<>();
		for (int i = 0 ; i < 5; i++) {
			PBDataElement.Builder pb = PBDataElement.newBuilder();
			pb.setElementName("read");
			pb.setElementValue(String.valueOf(i));
			pbDeList.add(pb.build());
		}
		for (int i = 3 ; i < 6; i++) {
			PBDataElement.Builder pb = PBDataElement.newBuilder();
			pb.setElementName("rmf");
			pb.setElementValue(String.valueOf(i));
			pbDeList.add(pb.build());
		}
		for (int i = 1 ; i < 5; i++) {
			PBDataElement.Builder pb = PBDataElement.newBuilder();
			pb.setElementName("iris");
			pb.setElementValue(String.valueOf(i));
			pbDeList.add(pb.build());
		}
		
		for (int i = 5; i < 10; i++) {
			PBDataElement.Builder pb = PBDataElement.newBuilder();
			pb.setElementName("face");
			pb.setElementValue(String.valueOf(i));
			pbDeList.add(pb.build());
		}
		System.out.print(pbDeList.toString());
		Collections.shuffle(pbDeList); 		
		PBDataGroup.Builder pg = PBDataGroup.newBuilder();
		pg.setGroupName("amr");
		for (int i = 0; i < pbDeList.size(); i++) {
			pg.addDataElement(i, pbDeList.get(i));
		}
		System.out.print("*************************");
		PBDataGroup newPb = calculatePBDataGroupAmr(pg.build());
		System.out.print(newPb.getDataElementList().toString());		
	}
	
	@Test	
	public void buildDataBlockTest() {
		List<PBBusinessMessage> pbbMsgList = Lists.newArrayList();
		PBBusinessMessage.Builder pbMsg = PBBusinessMessage.newBuilder();		
		PBRequest.Builder pq = PBRequest.newBuilder();
		pq.setRequestId("12");
		pq.setRequestType(E_REQUESET_TYPE.IDENTIFY_DEFAULT);
		pbMsg.setRequest(pq);
		PBResponse.Builder ps = PBResponse.newBuilder();
		ps.setStatus("0:success");
		pbMsg.setResponse(ps);
		PBDataBlock.Builder pd = PBDataBlock.newBuilder();
		List<PBCandidate> pbList = Lists.newArrayList();
		for (int i = 0 ; i < 5; i++) {
			PBCandidate.Builder pb = PBCandidate.newBuilder();
			pb.setEnrollmentId("enroll");
			pb.setScaledScore(100 + i);			
			pbList.add(pb.build());
		}
		for (int i = 0 ; i < 4; i++) {
			PBCandidate.Builder pb = PBCandidate.newBuilder();
			pb.setEnrollmentId("external");
			pb.setScaledScore(10 + i);			
			pbList.add(pb.build());			
		}
		
		for (int i = 0 ; i < 7; i++) {
			PBCandidate.Builder pb = PBCandidate.newBuilder();
			pb.setEnrollmentId("test" );
			pb.setScaledScore(27 + i);			
			pbList.add(pb.build());
		}
		for (int i = 0 ; i < 10; i++) {
			PBCandidate.Builder pb = PBCandidate.newBuilder();
			pb.setEnrollmentId("xia" + i);
			pb.setScaledScore(100 + i);			
			pbList.add(pb.build());
		}	
		
		Collections.shuffle(pbList);
		pd.getCandidateListBuilder().addAllCandidates(pbList);
		pd.getCandidateListBuilder().setMore(true);
		PBCandidateList moreCadList = pd.getCandidateList();
		moreCadList.toBuilder().setMore(false);
		pd.getCandidateListBuilder().addAllCandidates(moreCadList.getCandidatesList());
		
		PBProcessMetrics.Builder pbProcess = PBProcessMetrics.newBuilder();
		PBProcessInfo.Builder pinfo  = PBProcessInfo.newBuilder();
		pinfo.setProcessName("matcher");
		pinfo.setEndTime(String.valueOf(System.currentTimeMillis()));
		pinfo.setStartTime(String.valueOf(System.currentTimeMillis() -1000));
		pbProcess.addProcessMetric(pinfo.build());
		PBProcessInfo.Builder pinfo1  = PBProcessInfo.newBuilder();
		pinfo1.setProcessName("matcher1");
		pinfo1.setEndTime(String.valueOf(System.currentTimeMillis()));
		pinfo1.setStartTime(String.valueOf(System.currentTimeMillis() -1000));
		pbProcess.addProcessMetric(pinfo1.build());	
		pd.getProcessMetricBuilder().addProcessMetric(pinfo.build());
		pd.getProcessMetricBuilder().addProcessMetric(pinfo1.build());			
		
		List<PBDataElement> pbDeList= new ArrayList<>();
		for (int i = 0 ; i < 5; i++) {
			PBDataElement.Builder pb = PBDataElement.newBuilder();
			pb.setElementName("read");
			pb.setElementValue(String.valueOf(i));
			pbDeList.add(pb.build());
		}
		for (int i = 3 ; i < 6; i++) {
			PBDataElement.Builder pb = PBDataElement.newBuilder();
			pb.setElementName("rmf");
			pb.setElementValue(String.valueOf(i));
			pbDeList.add(pb.build());
		}
		for (int i = 1 ; i < 5; i++) {
			PBDataElement.Builder pb = PBDataElement.newBuilder();
			pb.setElementName("iris");
			pb.setElementValue(String.valueOf(i));
			pbDeList.add(pb.build());
		}
		
		for (int i = 5; i < 10; i++) {
			PBDataElement.Builder pb = PBDataElement.newBuilder();
			pb.setElementName("face");
			pb.setElementValue(String.valueOf(i));
			pbDeList.add(pb.build());
		}		
		Collections.shuffle(pbDeList); 		
		PBDataGroup.Builder pg = PBDataGroup.newBuilder();
		pg.setGroupName("amr");
		for (int i = 0; i < pbDeList.size(); i++) {
			pg.addDataElement(i, pbDeList.get(i));
		}
		
		pd.addDataGroup(pg.build());		
		pbMsg.setDataBlock(pd.build());
		pbbMsgList.add(pbMsg.build());		
		PBDataBlock testBlock = buildDataBlock(pbbMsgList, 10);	
		System.out.println(testBlock.toString());		
	}
	
	@Test	
	public void mergeCandidatesTest() {
		List<PBCandidate> pcList = Lists.newArrayList();
		for (int i = 0 ; i < 5; i++) {
			PBCandidate.Builder pb = PBCandidate.newBuilder();
			pb.setEnrollmentId("enroll");
			pb.setScaledScore(100 + i);			
			pcList.add(pb.build());
		}
		for (int i = 0 ; i < 4; i++) {
			PBCandidate.Builder pb = PBCandidate.newBuilder();
			pb.setEnrollmentId("external");
			pb.setScaledScore(10 + i);			
			pcList.add(pb.build());
		}
		
		for (int i = 0 ; i < 7; i++) {
			PBCandidate.Builder pb = PBCandidate.newBuilder();
			pb.setEnrollmentId("test" );
			pb.setScaledScore(27 + i);			
			pcList.add(pb.build());
		}
		for (int i = 0 ; i < 10; i++) {
			PBCandidate.Builder pb = PBCandidate.newBuilder();
			pb.setEnrollmentId("xia" + i);
			pb.setScaledScore(100 + i);			
			pcList.add(pb.build());
		}		
		Collections.shuffle(pcList); 
		System.out.print(pcList.toString());
		List<PBCandidate> mergedList = mergeCandidates(pcList);
		System.out.println("*************************");
		System.out.println(mergedList.toString());
		
	}
	
	private PBDataBlock buildDataBlock(List<PBBusinessMessage> inquiryPbBnsMesgList, int maxCandidate) {		
		List<PBCandidate> toBeAggregtedList = Lists.newArrayList();
		for (PBBusinessMessage pbMsg : inquiryPbBnsMesgList) {
			if (pbMsg.hasDataBlock() && pbMsg.getDataBlock().hasCandidateList()) {
				PBCandidateList pbMsgCandites = pbMsg.getDataBlock().getCandidateList();
				toBeAggregtedList.addAll(pbMsgCandites.getCandidatesList());
			}
		}		
		
		final PBDataBlock.Builder pBDataBlock = PBDataBlock.newBuilder();
		final List<PBDataGroup> lastPbDataGroupList = Lists.newArrayList();
		inquiryPbBnsMesgList.forEach(pm -> {
			if (pm.hasDataBlock() && pm.getDataBlock().getDataGroupCount() > 0 ) {				
				pm.getDataBlock().getDataGroupList().forEach(gp -> {
					final PBDataGroup newPbGrData = calculatePBDataGroupAmr(gp);
					if (!Objects.isNull(newPbGrData)) {
						lastPbDataGroupList.add(newPbGrData);
					}					
				});				
			}		
		});
		for (int i = 0; i < lastPbDataGroupList.size(); i++) {
			 pBDataBlock.addDataGroup(i, lastPbDataGroupList.get(i));
		}
		
		inquiryPbBnsMesgList.forEach(one -> {
			if (one.hasDataBlock() && one.getDataBlock().hasProcessMetric()) {								
				final List<PBProcessInfo> prcessList = one.getDataBlock().getProcessMetric().getProcessMetricList();				
				pBDataBlock.getProcessMetricBuilder().addAllProcessMetric(prcessList);	
			}
		});
		
		 if (toBeAggregtedList != null && toBeAggregtedList.size() > 0)  {
			 List<PBCandidate> sortedAndSameKeyMerged = mergeCandidates(toBeAggregtedList);	
			 if (sortedAndSameKeyMerged.size() > maxCandidate) {
				 sortedAndSameKeyMerged = sortedAndSameKeyMerged.subList(0, maxCandidate);
			 }			 
			 pBDataBlock.getCandidateListBuilder().addAllCandidates(sortedAndSameKeyMerged);			 
			    //pBDataBlock.getCandidateListBuilder().setMore(false);
		 }
		 
		 Predicate<PBBusinessMessage>  predicateMore = one -> one.hasDataBlock() && one.getDataBlock().hasCandidateList() &&
				 one.getDataBlock().getCandidateList().getMore() == true;
		 
		 if (inquiryPbBnsMesgList.stream().anyMatch(predicateMore)) {
			 pBDataBlock.getCandidateListBuilder().setMore(true);
		 } else {
			 pBDataBlock.getCandidateListBuilder().setMore(false);
		 }	
		
		return pBDataBlock.build();
	}
	
	private List<PBCandidate> mergeCandidates(List<PBCandidate> toBeMergeList) {		
		Collections.sort(toBeMergeList, new SameCandidateMergeComparator());				
		final List<PBCandidate> samekeyMergedAndSortedList = Lists.newArrayList();				
		Map<String, List<PBCandidate>> grpByType = toBeMergeList.stream().collect( Collectors.groupingBy(PBCandidate::getEnrollmentId));               
		grpByType.entrySet().stream().forEach(entry -> {
			//Predicate<PBCandidate> predicate = one -> one.getScaledScore() > 0;
			Optional<PBCandidate> test = entry.getValue().stream().sorted(new CandidateLastComparator()).findFirst();
			if (test.isPresent()) {
			   PBCandidate maxCandidate = entry.getValue().stream().sorted(new CandidateLastComparator()).findFirst().get();
		       samekeyMergedAndSortedList.add(maxCandidate);
			}
          
		});	
		Collections.sort(samekeyMergedAndSortedList, new CandidateLastComparator());
		return samekeyMergedAndSortedList;		
	}
	
	private PBDataGroup calculatePBDataGroupAmr(PBDataGroup pBDataGroup) {
		 PBDataGroup.Builder newPBDataGroup = PBDataGroup.newBuilder();
		 newPBDataGroup.setGroupName(pBDataGroup.getGroupName());
		final List<PBDataElement> edList = pBDataGroup.getDataElementList();
		if (edList.isEmpty()) return null;
		final List<PBDataElement> newList = Lists.newArrayList();
		//Collections.sort(edList,new PBDataElementComparator());
		Map<String, List<PBDataElement>> deMap = edList.stream().collect(Collectors.groupingBy(PBDataElement::getElementName));
		final PBDataElement.Builder newPBDataElement = PBDataElement.newBuilder();
		 deMap.entrySet().forEach(de -> {
			 String name = de.getKey();
			final List<PBDataElement> elList = de.getValue();
			int sum = elList.stream().mapToInt(e -> Integer.valueOf(e.getElementValue())).sum();
			newPBDataElement.setElementName(name);
			newPBDataElement.setElementValue(String.valueOf(sum));	
			newList.add(newPBDataElement.build());
		 });
	
		 for (int i = 0; i < newList.size(); i++) {
			 newPBDataGroup.addDataElement(i, newList.get(i));	 
		 }			
		return newPBDataGroup.build();		
	}	

	class PBDataElementComparator implements Comparator<PBDataElement> {
		@Override
		public int compare(PBDataElement o1, PBDataElement o2) {
			if (o1 == null && o2 == null) return 0;
			if (o1 == null && o2 != null) return -1;
			if (o1 != null && o2 == null) return 1;
			int first = o1.getElementName().compareTo(o2.getElementName());
			return first == 0 ? Integer.valueOf(o1.getElementValue()).compareTo(Integer.valueOf(o2.getElementValue())) : first;
		}	
	}

	class SameCandidateMergeComparator implements Comparator<PBCandidate> {
		@Override
		public int compare(PBCandidate o1,PBCandidate o2) {	
			if (o1 == null && o2 == null) return 0;
			if (o1 == null && o2 != null) return -1;
			if (o1 != null && o2 == null) return 1;
			int first = o1.getEnrollmentId().compareTo(o2.getEnrollmentId());
			int second = first == 0 ? Integer.valueOf(o2.getScaledScore())
					.compareTo(Integer.valueOf(o1.getScaledScore())) : first;
			return second;
		}
	}
	class CandidateLastComparator implements Comparator<PBCandidate> {
		@Override
		public int compare(PBCandidate o1, PBCandidate o2) {
			if (o1 == null && o2 == null) return 0;
			if (o1 == null && o2 != null) return -1;
			if (o1 != null && o2 == null) return 1;
			int first = Integer.valueOf(o2.getScaledScore()).compareTo(
					Integer.valueOf(o1.getScaledScore()));
			int second = first == 0 ? o1.getEnrollmentId().compareTo(
					o2.getEnrollmentId()) : first;
			return second;
		}
	}
	
	@Test
	public void testMap() {
	ConcurrentHashMap<String, String> testMap = new ConcurrentHashMap<>();
	 testMap.put(String.valueOf(199), "xia");
		String value = testMap.get(String.valueOf(199));
		String value2 = testMap.get(new String("199"));
		System.out.print(value);
		System.out.print(value2);	
	}
}
