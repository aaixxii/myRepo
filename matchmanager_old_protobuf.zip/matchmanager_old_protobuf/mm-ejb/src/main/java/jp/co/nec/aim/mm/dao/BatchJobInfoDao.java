package jp.co.nec.aim.mm.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import jp.co.nec.aim.mm.entities.BatchJobInfoEntity;

public class BatchJobInfoDao {
	
	private EntityManager em;

	public BatchJobInfoDao(EntityManager em) {
		this.em = em;
	}
	
	@SuppressWarnings("unchecked")
	public List<BatchJobInfoEntity> getBatchJobInfo(long jobId) {
		Query q = em.createNamedQuery("NQ::getBatchjobInfo");
		q.setParameter("internalId", jobId);
		return (List<BatchJobInfoEntity>) q.getResultList();
	}
	
	@SuppressWarnings("unchecked")
	public List<BatchJobInfoEntity> getBatchJobInfo(String extId, String batchType) {
		Query q = em.createNamedQuery("NQ::getJobidByRefId");
		q.setParameter("refId", extId);
		q.setParameter("batchType", batchType);
		return (List<BatchJobInfoEntity>) q.getResultList();
	}
	
}
