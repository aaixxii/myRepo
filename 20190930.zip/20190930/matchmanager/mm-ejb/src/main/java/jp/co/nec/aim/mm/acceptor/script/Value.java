package jp.co.nec.aim.mm.acceptor.script;

import java.util.Set;

/**
 * Value interface is used for save the default aim script result
 * 
 * @author liuyq
 * 
 */
public interface Value {

	/**
	 * get Container Id set
	 * 
	 * @return Container id set
	 */
	Set<Integer> getContainerIds();

	/**
	 * getScope
	 * 
	 * @return the scope
	 */
	Integer getScope();
}
