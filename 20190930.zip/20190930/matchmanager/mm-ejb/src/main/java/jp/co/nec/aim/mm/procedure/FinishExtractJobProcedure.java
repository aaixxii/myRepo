package jp.co.nec.aim.mm.procedure;

import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.SqlLobValue;
import org.springframework.jdbc.object.StoredProcedure;

import jp.co.nec.aim.mm.logger.PerformanceLogger;
import jp.co.nec.aim.mm.util.StopWatch;

/**
 * Spring StoredProcedure class to call finish_extract_job()
 * 
 * @author kurosu
 * 
 */
public class FinishExtractJobProcedure extends StoredProcedure {

	private static final String SQL = "MATCH_MANAGER_API.finish_extract_job";

	//private String[] keyArray;
	//private byte[][] templateArray;
	//private int[] indexArray;

	public FinishExtractJobProcedure(DataSource dataSource) {
		setDataSource(dataSource);
		setFunction(true);
		setSql(SQL);
		declareParameter(new SqlOutParameter("l_count", Types.INTEGER));
		declareParameter(new SqlParameter("p_mu_id", Types.BIGINT));
		declareParameter(new SqlParameter("p_job_id", Types.BIGINT));
		declareParameter(new SqlParameter("p_result", Types.BLOB));
		declareParameter(new SqlParameter("p_keys", Types.ARRAY,
				"CLOB_TABLE_TYPE"));
		declareParameter(new SqlParameter("p_indexs", Types.ARRAY,
				"NUM_TABLE_TYPE"));
		declareParameter(new SqlParameter("p_values", Types.ARRAY,
				"BLOB_TABLE_TYPE"));
		compile();
	}

	/**
	 * Update FE_JOB_QUEUE SET JOB_STATE=DONE, and insert records into
	 * FE_RESULTS If keyedBinaries contains same keys, save 1st one.
	 * 
	 * @param muId
	 * @param jobId
	 * @param result
	 * @param keyedBinaries
	 * @return number of updated records of fe_job_queue
	 * @throws SQLException
	 */
	public int execute(long muId, long jobId, byte[] result, byte[] template) throws SQLException {
			
		if (muId < 1L) {
			throw new IllegalArgumentException("muId is less than 1");
		}
		if (jobId < 1L) {
			throw new IllegalArgumentException("jobId is less than 1");
		}
		if (result == null) {
			throw new IllegalArgumentException("results is null");
		}

		StopWatch stopWatch = new StopWatch();
		stopWatch.start();

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("p_mu_id", new Long(muId));
		map.put("p_job_id", new Long(jobId));
		map.put("p_result", new SqlLobValue(result));		
		Map<String, Object> resultMap = execute(map);		
		int count = ((Integer) resultMap.get("l_count")).intValue();

		stopWatch.stop();
		PerformanceLogger.log(getClass().getSimpleName(), "execute",
				stopWatch.elapsedTime());

		return count;
	}

	
}
