package jp.co.nec.aim.mm.validator;

import java.util.concurrent.atomic.AtomicInteger;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceStateReason;
import jp.co.nec.aim.message.proto.SyncService.PBSyncJobRequest;
import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.constants.ConfigProperties;
import jp.co.nec.aim.mm.constants.ConfigPropertyNames;
import jp.co.nec.aim.mm.constants.MMConfigProperty;
import jp.co.nec.aim.mm.dao.SystemConfigDao;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.exception.HttpPostException;
import jp.co.nec.aim.mm.exception.TemplateValidatorException;
import jp.co.nec.aim.mm.util.HttpPoster;
import jp.co.nec.aim.mm.util.HttpResponseInfo;

import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.protobuf.InvalidProtocolBufferException;

/**
 * TemplateValidator
 * 
 * @author liuyq
 * 
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class TemplateValidator {
	private static final Logger log = LoggerFactory
			.getLogger(TemplateValidator.class);

	@PersistenceContext(unitName = "aim-db")
	private EntityManager manager;

	@Resource(mappedName = "java:jboss/OracleDS")
	private DataSource dataSource;

	private static final String URL = ConfigProperties.getInstance()
			.getPropertyValue(ConfigPropertyNames.TEMPLATE_VALIDATION_URL);

	private SystemConfigDao configDao;
	private static final AimError V_ERROR = AimError.TEMPLATE_VALIDATOR_ERROR;
	private static final int MAX_ROLLBACK_COUNT = 10;
	private static final int SLEEP_INTERVALS = 1000;

	/**
	 * private constructor
	 */
	public TemplateValidator() {
	}

	@PostConstruct
	public void init() {
		configDao = new SystemConfigDao(manager);
	}

	/**
	 * validate the template
	 * 
	 * @param syncJobRequest
	 */
	public void validate(PBSyncJobRequest syncJobRequest) {
		if (syncJobRequest == null) {
			throw new TemplateValidatorException(
					V_ERROR.getErrorCode(),
					String.format(V_ERROR.getMessage(),
							"Parameter syncJobRequest is null when validate the template.."));
		}
		boolean enabled = configDao
				.getMMPropertyBool(MMConfigProperty.TEMPLATE_VALIDATION_ENABLED);
		if (!enabled) {
			log.info("Template validation was disabled..");
			return;
		}
		AtomicInteger count = new AtomicInteger(0);
		validate(syncJobRequest, count);
	}

	/**
	 * validate the template
	 * 
	 * @param syncJobRequest
	 *            the instance of PBSyncJobRequest
	 */
	private void validate(PBSyncJobRequest syncJobRequest,
			AtomicInteger rollbackCount) {
		try {
			sleep(rollbackCount);
			HttpResponseInfo info = HttpPoster.validatorPost(URL,
					syncJobRequest.toByteArray());
			int statusCode = info.getStatusCode();
			switch (statusCode) {
			case HttpStatus.SC_OK:
				PBServiceState state = PBServiceState
						.parseFrom(info.getBytes());
				ServiceStateType stateType = state.getState();
				switch (stateType) {
				case SERVICE_STATE_SUCCESS:
					log.info("Template validator response success state,"
							+ " Template validation was passed..");
					break;
				case SERVICE_STATE_ROLLBACK:
					log.warn("Template validator response rollback state..");
					retryValidate(syncJobRequest, rollbackCount);
					break;
				case SERVICE_STATE_ERROR:
					if (!state.hasReason()) {
						throw new TemplateValidatorException(
								V_ERROR.getErrorCode(),
								String.format(
										V_ERROR.getMessage(),
										"Reason must be specified "
												+ "when service state is SERVICE_STATE_ERROR "));
					}
					final PBServiceStateReason reason = state.getReason();
					throw new TemplateValidatorException(reason.getCode(),
							reason.getDescription(), reason.getTime());
				default:
					throw new AimRuntimeException("ServiceState Type:"
							+ state.getState() + " is not support!");
				}
				break;
			case HttpStatus.SC_BAD_REQUEST:
				throw new TemplateValidatorException(
						V_ERROR.getErrorCode(),
						String.format(V_ERROR.getMessage(),
								"Bad request(400) received from Template validator.."));
			case HttpStatus.SC_NOT_FOUND:
				throw new TemplateValidatorException(V_ERROR.getErrorCode(),
						String.format(V_ERROR.getMessage(),
								"Template validator request URL:" + URL
										+ " may be incorrect."));
			case HttpStatus.SC_SERVICE_UNAVAILABLE:
				log.warn("Template validator is busy, retry to request.");
				retryValidate(syncJobRequest, rollbackCount);
				break;
			default:
				throw new TemplateValidatorException(V_ERROR.getErrorCode(),
						String.format(V_ERROR.getMessage(),
								"The response code from template validator:"
										+ statusCode + " is not support!"));
			}
		} catch (HttpPostException e) {
			log.error("HttpPost Exception occurred "
					+ "when post to Template validator", e);
			throw new TemplateValidatorException(V_ERROR.getErrorCode(),
					String.format(V_ERROR.getMessage(), e.getMessage()));
		} catch (InvalidProtocolBufferException e) {
			log.error("InvalidProtocolBuffer Exception occurred "
					+ "when post to Template validator", e);
			throw new TemplateValidatorException(V_ERROR.getErrorCode(),
					String.format(V_ERROR.getMessage(), e.getMessage()));
		}
	}

	/**
	 * sleep
	 * 
	 * @param rollbackCount
	 */
	private void sleep(AtomicInteger rollbackCount) {
		int count = rollbackCount.get();
		if (count > 0) {
			try {
				Thread.sleep(SLEEP_INTERVALS * count);
			} catch (InterruptedException e) {
				log.warn("InterruptedException occurred when Thread sleep..");
			}
		}
	}

	/**
	 * retry request to template validator
	 * 
	 * @param syncJobRequest
	 *            the instance of PBSyncJobRequest
	 * @param rollbackCount
	 *            rollBack count
	 */
	private void retryValidate(PBSyncJobRequest syncJobRequest,
			AtomicInteger rollbackCount) {
		if (rollbackCount.incrementAndGet() >= MAX_ROLLBACK_COUNT) {
			log.error("Template validator rollback too many times("
					+ MAX_ROLLBACK_COUNT + ")");
			throw new TemplateValidatorException(V_ERROR.getErrorCode(),
					String.format(V_ERROR.getMessage(),
							"Template validator rollback too many times("
									+ MAX_ROLLBACK_COUNT + ")."));
		}
		log.warn("Template validator already rollback times:"
				+ rollbackCount.get());
		validate(syncJobRequest, rollbackCount);
	}
}
