package jp.co.nec.aim.mm.util;

import org.apache.http.HttpStatus;

/**
 * 
 * @author liuyq
 * 
 */
public final class HttpResponseInfo {

	/**
	 * HttpResponseInfo
	 * 
	 * @param statusCode
	 */
	public HttpResponseInfo(int statusCode) {
		this.statusCode = statusCode;
	}

	/**
	 * HttpResponseInfo
	 * 
	 * @param statusCode
	 * @param bytes
	 */
	public HttpResponseInfo(int statusCode, byte[] bytes) {
		this.statusCode = statusCode;
		this.bytes = bytes;
	}

	private int statusCode;
	private byte[] bytes;

	public int getStatusCode() {
		return statusCode;
	}

	public boolean isOK() {
		return (statusCode == HttpStatus.SC_OK);
	}

	public byte[] getBytes() {
		return bytes;
	}

	public void setBytes(byte[] bytes) {
		this.bytes = bytes;
	}
}
