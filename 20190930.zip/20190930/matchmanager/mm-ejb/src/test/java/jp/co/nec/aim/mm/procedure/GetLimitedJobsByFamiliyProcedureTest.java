package jp.co.nec.aim.mm.procedure;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class GetLimitedJobsByFamiliyProcedureTest extends
		AbstractTransactionalJUnit4SpringContextTests {
	@PersistenceContext(unitName = "aim-db")
	protected EntityManager entityManager;
	@Resource
	protected DataSource dataSource;
	@Resource
	protected JdbcTemplate jdbcTemplate;
	private GetLimitedJobsByFamiliyProcedure identifyPlannerDao;

	@Before
	public void setUp() throws Exception {
		identifyPlannerDao = new GetLimitedJobsByFamiliyProcedure(dataSource);
		jdbcTemplate.execute("delete from job_queue");
		jdbcTemplate.execute("commit");
	}

	@After
	public void tearDown() throws Exception {
		jdbcTemplate.execute("delete from job_queue");
		identifyPlannerDao = null;
		jdbcTemplate.execute("commit");
	}

	@Test
	public void testGetLimitedJobsByFamiliy() {
		String jobQueueSql = "insert into job_queue(job_id,priority,job_state,submission_ts,callback_style,failure_count,remain_jobs,family_id)"
				+ " values(?,?,0,3000,0,?,0,?)";
		Integer[] jobIds = { 1000, 1001, 1002, 1003, 1004 };
		BigDecimal[] priority = { new BigDecimal(1), new BigDecimal(1),
				new BigDecimal(1), new BigDecimal(2), new BigDecimal(1) };
		BigDecimal[] failureCount = { new BigDecimal(3), new BigDecimal(2),
				new BigDecimal(0), new BigDecimal(0), new BigDecimal(0) };
		BigDecimal[] familyIds = { new BigDecimal(1), new BigDecimal(2),
				new BigDecimal(2), new BigDecimal(1), new BigDecimal(2) };
		for (int i = 0; i < jobIds.length; i++) {
			jdbcTemplate.update(jobQueueSql, new Object[] { jobIds[i],
					priority[i], failureCount[i], familyIds[i] });
		}
		jdbcTemplate.update("commit");
		try {
			List<Long> results = identifyPlannerDao.getLimitedJobsByFamiliy();
			Assert.assertNotNull(results.size() > 0);
		} catch (DataAccessException e) {

			e.printStackTrace();
		} catch (SQLException e) {

			e.printStackTrace();
		}
	}

	@Test
	public void testGetLimitedJobsByFamiliy_null() {
		try {
			List<Long> results = identifyPlannerDao.getLimitedJobsByFamiliy();
			Assert.assertNull(results);
		} catch (DataAccessException e) {

			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
