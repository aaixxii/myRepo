//package jp.co.nec.aim.mm.identify.planner;
//
//import java.io.IOException;
//import java.io.InputStream;
//import java.lang.reflect.InvocationTargetException;
//import java.lang.reflect.Method;
//import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.HashMap;
//import java.util.HashSet;
//import java.util.Iterator;
//import java.util.List;
//import java.util.Map;
//import java.util.Properties;
//import java.util.Set;
//
//import javax.annotation.Resource;
//import javax.sql.DataSource;
//
//import jp.co.nec.aim.mm.dao.DateDao;
//import mockit.Deencapsulation;
//import mockit.Mock;
//import mockit.MockUp;
//import mockit.Mocked;
//
//import org.junit.After;
//import org.junit.Assert;
//import org.junit.Before;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.test.annotation.Repeat;
//import org.springframework.test.context.ContextConfiguration;
//import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
//import org.springframework.transaction.annotation.Transactional;
//
//import com.google.common.collect.Maps;
//
//@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration(locations = { "/applicationContext.xml" })
//@Transactional
//public class MuExcutionPlanCreatorTest {
//	@Resource
//	private DataSource dataSource;
//
//	// private MuExcutionPlanCreator planCreator;
//	private static String space = " ";
//	private static String slash = "/";
//	private static String comma = ",";
//	private static String semicolon = ":";
//	private static final String PROPERTY_FILE_NAME = "mu.ablity.properties";
//	private static final Logger logger = LoggerFactory
//			.getLogger(MuExcutionPlanCreatorTest.class);
//
//	@Before
//	public void setUp() throws Exception {
//		
//	}
//	
//	private void setUpMock() {
//		
//	}
//	
//
//
//	@After
//	public void tearDown() throws Exception {
//	}
//
//	@Test
//	public void testGetFactor() {
//		Map<String, Double> factor = getAllValues();
//		Assert.assertTrue((Double) factor.get("MINUS4").doubleValue() == 1.5d);
//		Assert.assertTrue((Double) factor.get("MINUS3").doubleValue() == 1.5d);
//		Assert.assertTrue((Double) factor.get("MINUS2").doubleValue() == 1.5d);
//		Assert.assertTrue((Double) factor.get("MINUS1").doubleValue() == 1.2d);
//		Assert.assertTrue((Double) factor.get("ZERO").doubleValue() == 1.0d);
//		Assert.assertTrue((Double) factor.get("PLUS1").doubleValue() == 0.8d);
//		Assert.assertTrue((Double) factor.get("PLUS2").doubleValue() == 0.5d);
//		Assert.assertTrue((Double) factor.get("PLUS3").doubleValue() == 0.2d);
//		Assert.assertTrue((Double) factor.get("PLUS4").doubleValue() == 0.0d);
//	}
//
//	@Test
//	public void testBiulderPlanSting() throws NoSuchMethodException,
//			SecurityException, IllegalAccessException,
//			IllegalArgumentException, InvocationTargetException {
//		// It must be string like
//		// this:"muId,segmentId:version,segmentId:version/muId,segmentId:vesion"
//		MuExcutionPlanCreator planCreator = new MuExcutionPlanCreator(
//				new DateDao(dataSource));
//		Map<Integer, List<MuSegmentMap>> testMapList = new HashMap<Integer, List<MuSegmentMap>>();
//		final Integer containerId = 1;
//		final Integer functionId = 1;
//		Long[] segIds = { 1000L, 1001L, 1002L, 1003L, 1004L, 1005L };
//		Integer[] muIds = { 1, 2, 3, 4, 5, 6 };
//		Long[] segVers = { 10L, 11L, 12L, 13L, 14L, 15L };
//		for (int i = 0; i < muIds.length; i++) {
//			testMapList.put(
//					muIds[i],
//					createTestMuSegMaps(functionId, containerId, muIds, segIds,
//							segVers));
//		}
//		Method method = MuExcutionPlanCreator.class.getDeclaredMethod(
//				"builderPlanString", java.util.Map.class);
//		method.setAccessible(true);
//		String results = (String) method.invoke(planCreator, testMapList);
//		Assert.assertTrue(!results.substring(0, 0).equals(slash));
//		Assert.assertTrue(!results.substring(results.length() - 1,
//				results.length() - 1).equals(comma));
//		String[] resultArrays = results.split(slash);
//		Assert.assertEquals(muIds.length, resultArrays.length);
//		for (int i = 0; i < resultArrays.length; i++) {
//			Assert.assertTrue(resultArrays[i].startsWith(String
//					.valueOf(muIds[i])));
//			String[] tmp = resultArrays[i].split(comma);
//			for (int j = 1; j < tmp.length; j++) {
//				String[] temp = tmp[j].split(semicolon);
//				Assert.assertEquals(segIds[j - 1], Long.valueOf(temp[0]));
//				Assert.assertEquals(segVers[j - 1], Long.valueOf(temp[1]));
//			}
//		}
//		planCreator = null;
//		method = null;
//	}
//
//	@Test
//	public void testMap2Matrix_1() throws NoSuchMethodException,
//			SecurityException, IllegalAccessException,
//			IllegalArgumentException, InvocationTargetException {
//		MuExcutionPlanCreator planCreator = new MuExcutionPlanCreator(
//				new DateDao(dataSource));
//		Integer[] muIds = { 1, 2, 3, 4, 5 };
//		Long[] segIds = { 1001L, 1002L, 1003L, 1004L, 1005L };
//		List<MuSegmentMap> muSegmaps = new ArrayList<MuSegmentMap>();
//		for (int i = 0; i < 5; i++) {
//			MuSegmentMap map = new MuSegmentMap();
//			map.setMuId(muIds[i]);
//			map.setSegmentId(segIds[i]);
//			muSegmaps.add(map);
//		}
//		Map<Integer, Integer> muIdIndexMap = Maps.newHashMap();
//		Map<Long, Integer> segIdIndexMap = Maps.newHashMap();
//		for (int i = 0; i < muIds.length; i++) {
//			muIdIndexMap.put(muIds[i], i);
//		}
//		for (int i = 0; i < segIds.length; i++) {
//			segIdIndexMap.put(segIds[i], i);
//		}
//		Method method = MuExcutionPlanCreator.class.getDeclaredMethod(
//				"map2Matrix", List.class, List.class, List.class, Map.class,
//				Map.class);
//		method.setAccessible(true);
//		boolean[][] matrix = (boolean[][]) method.invoke(planCreator,
//				muSegmaps, Arrays.asList(muIds), Arrays.asList(segIds),
//				muIdIndexMap, segIdIndexMap);
//		Assert.assertEquals(muIds.length, matrix.length);
//		Assert.assertEquals(segIds.length, matrix[0].length);
//		for (int i = 0; i < matrix.length; i++) {
//			for (int j = 0; j < matrix[0].length; j++) {
//				if (j == i) {
//					Assert.assertTrue(matrix[i][j]);
//				}
//			}
//		}
//		planCreator = null;
//		method = null;
//	}
//
//	@Test
//	public void testMap2Matrix_2() throws NoSuchMethodException,
//			SecurityException, IllegalAccessException,
//			IllegalArgumentException, InvocationTargetException {
//		MuExcutionPlanCreator planCreator = new MuExcutionPlanCreator(
//				new DateDao(dataSource));
//		Integer[] muIds = { 1, 2, 3, 4, 5 };
//		Long[] segIds = { 1001L, 1002L, 1003L, 1004L, 1005L };
//		List<MuSegmentMap> muSegmaps = new ArrayList<MuSegmentMap>();
//		for (int i = 0; i < 5; i++) {
//			MuSegmentMap map = new MuSegmentMap();
//			map.setMuId(muIds[i]);
//			map.setSegmentId(segIds[i]);
//			muSegmaps.add(map);
//		}
//		int segIndex = 0;
//		int selSeg = 0;
//		for (int i = 0; i < 5; i++) {
//			MuSegmentMap map = new MuSegmentMap();
//			map.setMuId(muIds[i]);
//			selSeg = (segIndex - 1) < 0 ? segIds.length - 1 : segIndex - 1;
//			map.setSegmentId(segIds[selSeg]);
//			muSegmaps.add(map);
//		}
//		Map<Integer, Integer> muIdIndexMap = Maps.newHashMap();
//		Map<Long, Integer> segIdIndexMap = Maps.newHashMap();
//		for (int i = 0; i < muIds.length; i++) {
//			muIdIndexMap.put(muIds[i], i);
//		}
//		for (int i = 0; i < segIds.length; i++) {
//			segIdIndexMap.put(segIds[i], i);
//		}
//
//		Method method = MuExcutionPlanCreator.class.getDeclaredMethod(
//				"map2Matrix", List.class, List.class, List.class, Map.class,
//				Map.class);
//		method.setAccessible(true);
//		boolean[][] matrix = (boolean[][]) method.invoke(planCreator,
//				muSegmaps, Arrays.asList(muIds), Arrays.asList(segIds),
//				muIdIndexMap, segIdIndexMap);
//		Assert.assertEquals(muIds.length, matrix.length);
//		Assert.assertEquals(segIds.length, matrix[0].length);
//		int segIdx = 0;
//		int selSegIdx = 0;
//		for (int i = 0; i < matrix.length; i++) {
//			selSegIdx = (segIdx - 1) < 0 ? segIds.length - 1 : segIdx - 1;
//			for (int j = 0; j < matrix[0].length; j++) {
//				if (j == i || j == selSegIdx) {
//					Assert.assertTrue(matrix[i][j]);
//				}
//			}
//		}
//		planCreator = null;
//		method = null;
//	}
//
//	@Test
//	public void testReOrderSegment() throws NoSuchMethodException,
//			SecurityException, IllegalAccessException,
//			IllegalArgumentException, InvocationTargetException {
//		MuExcutionPlanCreator planCreator = new MuExcutionPlanCreator(
//				new DateDao(dataSource));
//		int[] bestOrderSegments = new int[50];
//		int size = bestOrderSegments.length;
//		int[] copy = new int[50];
//		for (int i = 0; i < copy.length; i++) {
//			copy[i] = i;
//		}
//		Method method = MuExcutionPlanCreator.class.getDeclaredMethod(
//				"reOrderSegment", int[].class);
//		method.setAccessible(true);
//		method.invoke(planCreator, bestOrderSegments);
//		Assert.assertEquals(50, bestOrderSegments.length);
//		for (int i = 0; i < size; i++) {
//			Assert.assertTrue(bestOrderSegments[i] >= 0);
//		}
//		planCreator = null;
//		method = null;
//	}
//
//	@Test
//	public void testCalculateCorrectFactor_nomal(
//			@Mocked final AdjustMuAblistyFactorPropertyUtil util)
//			throws NoSuchMethodException, SecurityException,
//			IllegalAccessException, IllegalArgumentException,
//			InvocationTargetException {
//
//		MuExcutionPlanCreator planCreator = new MuExcutionPlanCreator(
//				new DateDao(dataSource));
//		final Integer containerId = 1;
//		final Integer functionId = 1;
//		Long[] segIds = { 1000L, 1001L, 1002L, 1003L, 1004L, 1005L };
//		Integer[] muIds = { 1, 2, 3, 4, 5, 6 };
//		Long[] segVers = { 10L, 11L, 12L, 13L, 14L, 15L };
//		final List<MuSegmentMap> mapList = createTestMuSegMaps(functionId,
//				containerId, muIds, segIds, segVers);
//		long time = System.currentTimeMillis();
//		int[] cpus = { 2, 4, 6, 8, 10, 12 };
//		long[] pressures = { 1, 2, 3, 4, 5, 6 };
//		long[] reportTs = { time + 500l, time + 1000l, time + 2000l,
//				time + 3000l, time + 4000l, time + 5000l };
//		List<MuCpuAndPressure> muAbilitys = createCpuAndPressureList(muIds,
//				cpus, pressures, reportTs);
//		final Map<String, Double> factor = getAllValues();
//		new MockUp<AdjustMuAblistyFactorPropertyUtil>() {
//			@Mock
//			Map<String, Double> getAllValues() {
//				return factor;
//			}
//		};
//
//		double[] correctFactor = new double[6];
//		Arrays.fill(correctFactor, -9.9d);
//		Deencapsulation.setField(planCreator, "util", util);
//		Deencapsulation.setField(planCreator, "muCpuAndPressures", muAbilitys);
//		Deencapsulation.setField(planCreator, "muSegMaps", mapList);
//		Method method = MuExcutionPlanCreator.class.getDeclaredMethod(
//				"calculateCorrectFactor", double[].class);
//		method.setAccessible(true);
//		method.invoke(planCreator, correctFactor);
//		for (int i = 0; i < correctFactor.length; i++) {
//			Assert.assertTrue(correctFactor[i] >= 0.0d);
//			Assert.assertTrue(correctFactor[i] <= 1.5d);
//		}		
//		planCreator = null;
//		method = null;
//	}
//
//	@Test
//	public void testCalculateCorrectFactor_all_pressure_minus(
//			@Mocked final AdjustMuAblistyFactorPropertyUtil util)
//			throws NoSuchMethodException, SecurityException,
//			IllegalAccessException, IllegalArgumentException,
//			InvocationTargetException {
//		MuExcutionPlanCreator planCreator = new MuExcutionPlanCreator(
//				new DateDao(dataSource));
//		final Integer containerId = 1;
//		final Integer functionId = 1;
//		Long[] segIds = { 1000L, 1001L, 1002L, 1003L, 1004L, 1005L };
//		Integer[] muIds = { 1, 2, 3, 4, 5, 6 };
//		Long[] segVers = { 10L, 11L, 12L, 13L, 14L, 15L };
//		final List<MuSegmentMap> mapList = createTestMuSegMaps(functionId,
//				containerId, muIds, segIds, segVers);
//		long time = System.currentTimeMillis();
//		int[] cpus = { 2, 4, 4, 8, 8, 12 };
//		long[] pressures = { -2l, -1l, -1l, -1l, -1l, -1l };
//		long[] reportTs = { -999l, time + 1000l, time + 2000l, time + 3000l,
//				time + 4000l, time + 5000l };
//		List<MuCpuAndPressure> muAbilitys = createCpuAndPressureList(muIds,
//				cpus, pressures, reportTs);
//		planCreator = new MuExcutionPlanCreator(mapList, muAbilitys,
//				new DateDao(dataSource));
//		final Map<String, Double> factor = getAllValues();
//		new MockUp<AdjustMuAblistyFactorPropertyUtil>() {
//			@Mock
//			Map<String, Double> getAllValues() {
//				return factor;
//			}
//		};
//		double[] correctFactor = new double[6];
//		Arrays.fill(correctFactor, -9.9d);
//		Deencapsulation.setField(planCreator, "util", util);
//		Deencapsulation.setField(planCreator, "muCpuAndPressures", muAbilitys);
//		Deencapsulation.setField(planCreator, "muSegMaps", mapList);
//		Method method = MuExcutionPlanCreator.class.getDeclaredMethod(
//				"calculateCorrectFactor", double[].class);
//		method.setAccessible(true);
//		method.invoke(planCreator, correctFactor);
//		for (int i = 0; i < correctFactor.length; i++) {
//			Assert.assertTrue(correctFactor[i] >= 0.0d);
//			Assert.assertTrue(correctFactor[i] <= 1.5d);
//			if (i == 0) {
//				Assert.assertTrue(correctFactor[i] == 1.0d);
//			}
//		}		
//		planCreator = null;
//		method = null;
//	}
//
//	@Test
//	public void testCalculateCorrectFactor_reportTS_minus(
//			@Mocked final AdjustMuAblistyFactorPropertyUtil util)
//			throws NoSuchMethodException, SecurityException,
//			IllegalAccessException, IllegalArgumentException,
//			InvocationTargetException {
//		MuExcutionPlanCreator planCreator = new MuExcutionPlanCreator(
//				new DateDao(dataSource));
//		final Integer containerId = 1;
//		final Integer functionId = 1;
//		Long[] segIds = { 1000L, 1001L, 1002L, 1003L, 1004L, 1005L };
//		Integer[] muIds = { 1, 2, 3, 4, 5, 6 };
//		Long[] segVers = { 10L, 11L, 12L, 13L, 14L, 15L };
//		final List<MuSegmentMap> mapList = createTestMuSegMaps(functionId,
//				containerId, muIds, segIds, segVers);
//		long time = System.currentTimeMillis();
//		int[] cpus = { 2, 4, 4, 8, 8, 12 };
//		long[] pressures = { -88l, 2l, 3l, 4l, 5l, 6l };
//		long[] reportTs = { -999l, time + 1000l, time + 2000l, time + 3000l,
//				time + 4000l, time + 5000l };
//		List<MuCpuAndPressure> muAbilitys = createCpuAndPressureList(muIds,
//				cpus, pressures, reportTs);
//		final Map<String, Double> factor = getAllValues();
//		new MockUp<AdjustMuAblistyFactorPropertyUtil>() {
//			@Mock
//			Map<String, Double> getAllValues() {
//				return factor;
//			}
//		};
//		Deencapsulation.setField(planCreator, "util", util);
//		double[] correctFactor = new double[6];
//		Arrays.fill(correctFactor, -9.9d);
//		Deencapsulation.setField(planCreator, "util", util);
//		Deencapsulation.setField(planCreator, "muCpuAndPressures", muAbilitys);
//		Deencapsulation.setField(planCreator, "muSegMaps", mapList);
//		Method method = MuExcutionPlanCreator.class.getDeclaredMethod(
//				"calculateCorrectFactor", double[].class);
//		method.setAccessible(true);
//		method.invoke(planCreator, correctFactor);
//		for (int i = 0; i < correctFactor.length; i++) {
//			Assert.assertTrue(correctFactor[i] >= 0.0d);
//			Assert.assertTrue(correctFactor[i] <= 1.5d);
//		}		
//		planCreator = null;
//		method = null;
//	}
//
//	@Test
//	public void testReOrderMUByAbility()
//			throws NoSuchMethodException, SecurityException,
//			IllegalAccessException, IllegalArgumentException,
//			InvocationTargetException {
//		MuExcutionPlanCreator planCreator = new MuExcutionPlanCreator(
//				new DateDao(dataSource));
//		final Integer containerId = 1;
//		final Integer functionId = 1;
//		Long[] segIds = { 1000L, 1001L, 1002L, 1003L, 1004L, 1005L, 1006L,
//				1007L, 1008L, 1009L, 1010L, 1011L };
//		Integer[] muIds = { 1, 2, 3, 4, 5, 6 };
//		Long[] segVers = { 10L, 10L, 10L, 10L, 10L, 10L, 11L, 12L, 13L, 14L,
//				15L, 16L };
//		final List<MuSegmentMap> mapList = createTestMuSegMaps(functionId,
//				containerId, muIds, segIds, segVers);
//		long time = System.currentTimeMillis();
//		int[] cpus = { 1, 2, 3, 4, 5, 6 };
//		long[] pressures = { 1l, 2l, 3l, 4l, 5l, 6l };
//		long[] reportTs = { time + 500l, time + 1000l, time + 2000l,
//				time + 3000l, time + 4000l, time + 5000l };
//		List<MuCpuAndPressure> muAbilitys = createCpuAndPressureList(muIds,
//				cpus, pressures, reportTs);
//		final Map<String, Double> factor = getAllValues();
//		new MockUp<AdjustMuAblistyFactorPropertyUtil>() {
//			@Mock
//			Map<String, Double> getAllValues() {
//				return factor;
//			}
//		};
//		AdjustMuAblistyFactorPropertyUtil util;
//		double[] correctFactor = new double[6];
//		Arrays.fill(correctFactor, -9.9d);
//		Deencapsulation.setField(planCreator, "util", util);
//		Deencapsulation.setField(planCreator, "muCpuAndPressures", muAbilitys);
//		Deencapsulation.setField(planCreator, "muSegMaps", mapList);
//		Deencapsulation.setField(planCreator, "util", util);
//		int muCount = muIds.length;
//		int segCount = segIds.length;
//		// int[] ruoundTable = new int[muCount + segCount];
//		Method method = MuExcutionPlanCreator.class.getDeclaredMethod(
//				"reOrderMUByAbility", int.class, int.class);
//		method.setAccessible(true);
//		int[] table = (int[]) method.invoke(planCreator, muCount, segCount);
//		Assert.assertTrue(table.length > 0);
//		int max = Math.max(segCount, muCount);
//		Assert.assertTrue(table.length >= max);		
//		planCreator = null;
//		method = null;
//	}
//
//	@Test
//	@Repeat(value = 10)
//	public void testDestributeWithAbility(
//			@Mocked final AdjustMuAblistyFactorPropertyUtil util)
//			throws NoSuchMethodException, SecurityException,
//			IllegalAccessException, IllegalArgumentException,
//			InvocationTargetException {
//		MuExcutionPlanCreator planCreator = new MuExcutionPlanCreator(
//				new DateDao(dataSource));
//		final Integer containerId = 1;
//		final Integer functionId = 1;
//		Long[] segIds = { 1000L, 1001L, 1002L, 1003L, 1004L, 1005L, 1006L,
//				1007L, 1008L, 1009L, 1010L, 1011L };
//		Integer[] muIds = { 1, 2, 3, 4, 5, 6 };
//		Long[] segVers = { 10L, 10L, 10L, 10L, 10L, 10L, 11L, 12L, 13L, 14L,
//				15L, 16L };
//		final List<MuSegmentMap> mapList = createTestMuSegMaps(functionId,
//				containerId, muIds, segIds, segVers);
//		long time = System.currentTimeMillis();
//		int[] cpus = { 2, 2, 3, 4, 5, 6 };
//		long[] pressures = { 1l, 2l, 3l, 4l, 5l, 6l };
//		long[] reportTs = { time + 500l, time + 1000l, time + 2000l,
//				time + 3000l, time + 4000l, time + 5000l };
//		List<MuCpuAndPressure> muAbilitys = createCpuAndPressureList(muIds,
//				cpus, pressures, reportTs);
//		final Map<String, Double> factor = getAllValues();
//		new MockUp<AdjustMuAblistyFactorPropertyUtil>() {
//			@Mock
//			Map<String, Double> getAllValues() {
//				return factor;
//			}
//		};
//		double[] correctFactor = new double[6];
//		Arrays.fill(correctFactor, -9.9d);
//		Deencapsulation.setField(planCreator, "util", util);
//		Deencapsulation.setField(planCreator, "muCpuAndPressures", muAbilitys);
//		Deencapsulation.setField(planCreator, "muSegMaps", mapList);
//		Method method = MuExcutionPlanCreator.class.getDeclaredMethod(
//				"destributeWithAbility", boolean[][].class, int.class,
//				int.class, int[].class);
//		method.setAccessible(true);
//		int muCount = muIds.length;
//		int segCount = segIds.length;
//		int[] assignedMu = new int[muCount + segCount];
//		boolean[][] matrix = buildMuSegmentMatrix(2, muCount, segCount);
//		boolean results = (boolean) method.invoke(planCreator, matrix, muCount,
//				segCount, assignedMu);
//		Assert.assertTrue(results == true);		
//		planCreator = null;
//		method = null;
//	}
//
//	@Test
//	@Repeat(value = 10)
//	public void testDestributeWithAbility1(
//			@Mocked final AdjustMuAblistyFactorPropertyUtil util)
//			throws NoSuchMethodException, SecurityException,
//			IllegalAccessException, IllegalArgumentException,
//			InvocationTargetException {
//		MuExcutionPlanCreator planCreator = new MuExcutionPlanCreator(
//				new DateDao(dataSource));
//		final Integer containerId = 1;
//		final Integer functionId = 1;
//		Long[] segIds = { 1000L, 1001L, 1002L, 1003L, 1004L, 1005L, 1006L,
//				1007L, 1008L, 1009L };
//		Integer[] muIds = { 1, 2, 3, 4, 5 };
//		Long[] segVers = { 10L, 10L, 10L, 10L, 10L, 10L, 11L, 12L, 13L, 14L };
//		final List<MuSegmentMap> mapList = createTestMuSegMaps(functionId,
//				containerId, muIds, segIds, segVers);
//		long time = System.currentTimeMillis();
//		int[] cpus = { 4, 4, 4, 4, 4 };
//		long[] pressures = { 5l, 5l, 5l, 5l, 5l };
//		long[] reportTs = { time + 1000l, time + 1000l, time + 1000l,
//				time + 1000l, time + 1000l };
//		List<MuCpuAndPressure> muAbilitys = createCpuAndPressureList(muIds,
//				cpus, pressures, reportTs);
//		final Map<String, Double> factor = getAllValues();
//		new MockUp<AdjustMuAblistyFactorPropertyUtil>() {
//			@Mock
//			Map<String, Double> getAllValues() {
//				return factor;
//			}
//		};
//		double[] correctFactor = new double[6];
//		Arrays.fill(correctFactor, -9.9d);
//		Deencapsulation.setField(planCreator, "util", util);
//		Deencapsulation.setField(planCreator, "muCpuAndPressures", muAbilitys);
//		Deencapsulation.setField(planCreator, "muSegMaps", mapList);
//		Method method = MuExcutionPlanCreator.class.getDeclaredMethod(
//				"destributeWithAbility", boolean[][].class, int.class,
//				int.class, int[].class);
//		method.setAccessible(true);
//		int muCount = muIds.length;
//		int segCount = segIds.length;
//		int[] assignedMu = new int[muCount + segCount];
//		boolean[][] matrix = buildMuSegmentMatrix(2, muCount, segCount);
//		boolean results = (boolean) method.invoke(planCreator, matrix, muCount,
//				segCount, assignedMu);
//		Assert.assertTrue(results == true);		
//		planCreator = null;
//		method = null;
//	}
//
//	@Test
//	public void testCreateMuPlans(
//			@Mocked final AdjustMuAblistyFactorPropertyUtil util) {
//		MuExcutionPlanCreator planCreator = new MuExcutionPlanCreator(
//				new DateDao(dataSource));
//		final Integer containerId = 1;
//		final Integer functionId = 1;
//		Long[] segIds = { 1000L, 1001L, 1002L, 1003L, 1004L, 1005L, 1006L,
//				1007L, 1008L, 1009L };
//		Integer[] muIds = { 1, 2, 3, 4, 5 };
//		Long[] segVers = { 10L, 10L, 10L, 10L, 10L, 10L, 11L, 12L, 13L, 14L };
//		final List<MuSegmentMap> mapList = createTestMuSegMaps(functionId,
//				containerId, muIds, segIds, segVers);
//		long time = System.currentTimeMillis();
//		int[] cpus = { 1, 2, 3, 4, 5 };
//		long[] pressures = { 1l, 2l, 3l, 4l, 5l };
//		long[] reportTs = { time + 500l, time + 1000l, time + 2000l,
//				time + 3000l, time + 4000l };
//		List<MuCpuAndPressure> muAbilitys = createCpuAndPressureList(muIds,
//				cpus, pressures, reportTs);
//		final Map<String, Double> factor = getAllValues();
//		new MockUp<AdjustMuAblistyFactorPropertyUtil>() {
//			@Mock
//			Map<String, Double> getAllValues() {
//				return factor;
//			}
//		};
//		double[] correctFactor = new double[6];
//		Arrays.fill(correctFactor, -9.9d);
//		Deencapsulation.setField(planCreator, "util", util);
//		Deencapsulation.setField(planCreator, "muCpuAndPressures", muAbilitys);
//		Deencapsulation.setField(planCreator, "muSegMaps", mapList);
//		String results = planCreator.createMuPlans();
//		Assert.assertTrue(!results.isEmpty());
//		System.out.println(results);
//		planCreator = null;
//	}
//
//	@Test
//	public void testCreateMuPlans_oneMU(
//			@Mocked final AdjustMuAblistyFactorPropertyUtil util) {
//		MuExcutionPlanCreator planCreator = new MuExcutionPlanCreator(
//				new DateDao(dataSource));
//		final Integer containerId = 1;
//		final Integer functionId = 1;
//		Long[] segIds = { 1000L, 1001L, 1002L, 1003L };
//
//		Integer[] muIds = { 1 };
//		Long[] segVers = { 10L, 10L, 10L, 10L };
//		final List<MuSegmentMap> mapList = createTestMuSegMaps(functionId,
//				containerId, muIds, segIds, segVers);
//		long time = System.currentTimeMillis();
//		int[] cpus = { 4 };
//		long[] pressures = { 5l };
//		long[] reportTs = { time + 500l };
//		List<MuCpuAndPressure> muAbilitys = createCpuAndPressureList(muIds,
//				cpus, pressures, reportTs);
//		final Map<String, Double> factor = getAllValues();
//		new MockUp<AdjustMuAblistyFactorPropertyUtil>() {
//			@Mock
//			Map<String, Double> getAllValues() {
//				return factor;
//			}
//		};
//		double[] correctFactor = new double[6];
//		Arrays.fill(correctFactor, -9.9d);
//		Deencapsulation.setField(planCreator, "util", util);
//		Deencapsulation.setField(planCreator, "muCpuAndPressures", muAbilitys);
//		Deencapsulation.setField(planCreator, "muSegMaps", mapList);
//		String results = planCreator.createMuPlans();
//		Assert.assertTrue(!results.isEmpty());
//		System.out.println(results);
//		planCreator = null;
//	}
//
//	@Test
//	public void testCreateMuPlans1(
//			@Mocked final AdjustMuAblistyFactorPropertyUtil util) {
//		MuExcutionPlanCreator planCreator = new MuExcutionPlanCreator(
//				new DateDao(dataSource));
//		final Integer containerId = 1;
//		final Integer functionId = 1;
//		Long[] segIds = { 1000L, 1001L, 1002L, 1003L, 1004L, 1005L, 1006L,
//				1007L, 1008L, 1009L };
//		Integer[] muIds = { 1, 2, 3, 4, 5 };
//		Long[] segVers = { 10L, 10L, 10L, 10L, 10L, 10L, 11L, 12L, 13L, 14L };
//		final List<MuSegmentMap> mapList = createTestMuSegMaps(functionId,
//				containerId, muIds, segIds, segVers);
//		long time = System.currentTimeMillis();
//		int[] cpus = { 4, 4, 4, 4, 4 };
//		long[] pressures = { 5l, 5l, 5l, 5l, 5l };
//		long[] reportTs = { time + 1000l, time + 1000l, time + 1000l,
//				time + 1000l, time + 1000l };
//		List<MuCpuAndPressure> muAbilitys = createCpuAndPressureList(muIds,
//				cpus, pressures, reportTs);
//		final Map<String, Double> factor = getAllValues();
//		new MockUp<AdjustMuAblistyFactorPropertyUtil>() {
//			@Mock
//			Map<String, Double> getAllValues() {
//				return factor;
//			}
//		};
//		double[] correctFactor = new double[6];
//		Arrays.fill(correctFactor, -9.9d);
//		Deencapsulation.setField(planCreator, "util", util);
//		Deencapsulation.setField(planCreator, "muCpuAndPressures", muAbilitys);
//		Deencapsulation.setField(planCreator, "muSegMaps", mapList);
//		String results = planCreator.createMuPlans();
//		Assert.assertTrue(!results.isEmpty());
//		System.out.println(results);
//		planCreator = null;
//	}
//
//	@Test
//	public void testTestData_redundancy2() {
//		int redundacy = 2;
//		int mus = 5;
//		int segs = 10;
//		int segsPerMu = segs / mus * redundacy;
//		boolean[][] testMatrix = buildMuSegmentMatrix(redundacy, mus, segs);
//		Assert.assertEquals(mus, testMatrix.length);
//		Assert.assertEquals(segs, testMatrix[0].length);
//		for (int i = 0; i < mus; i++) {
//			Assert.assertEquals(segsPerMu, sumRow(i, testMatrix));
//		}
//
//		for (int i = 0; i < segs; i++) {
//			Assert.assertEquals(redundacy, sumCol(i, testMatrix));
//		}
//		logger.info(printMartix(testMatrix).toString());
//	}
//
//	public int getLocationByArrayValue(int[] array, int value) {
//		int location = -1;
//		for (int i = 0; i < array.length; i++) {
//			if (array[i] == value) {
//				location = i;
//				break;
//			}
//		}
//		return location;
//	}
//
//	public Map<String, Double> getAllValues() {
//		InputStream input = this.getClass().getClassLoader()
//				.getResourceAsStream(PROPERTY_FILE_NAME);
//		Properties prop = new Properties();
//		Map<String, Double> results = new HashMap<>();
//		Set<String> keys = new HashSet<String>();
//		try {
//			prop.load(input);
//			Set<Object> sets = prop.keySet();
//			Iterator<Object> it = sets.iterator();
//			while (it.hasNext()) {
//				String tmp = (String) it.next();
//				keys.add(tmp);
//			}
//			for (String key : keys) {
//				results.put(key, Double.valueOf(prop.getProperty(key)));
//			}
//		} catch (IOException e) {
//			e.printStackTrace();
//			return null;
//		}
//		return results;
//	}
//
//	public List<MuCpuAndPressure> createCpuAndPressureList(Integer[] muIds,
//			int[] cpus, long[] pressures, long[] reportTs) {
//		// long time = System.currentTimeMillis();
//		List<MuCpuAndPressure> muAbilitys = new ArrayList<>();
//		for (int i = 0; i < muIds.length; i++) {
//			MuCpuAndPressure mp = new MuCpuAndPressure();
//			mp.setMuId(muIds[i]);
//			mp.setAbility(cpus[i]);
//			mp.setPressure(pressures[i]);
//			mp.setReportTs(reportTs[i]);
//			muAbilitys.add(mp);
//		}
//		return muAbilitys;
//	}
//
//	public List<MuSegmentMap> createTestMuSegMaps(Integer functionId,
//			Integer containerId, Integer[] muIds, Long[] segmentIds,
//			Long[] segVers) {
//		List<MuSegmentMap> maps = new ArrayList<>();
//		int muIndex = 0;
//		for (int i = 0; i < segmentIds.length; i++) {
//			if (muIndex == muIds.length) {
//				muIndex = 0;
//			}
//			MuSegmentMap map = new MuSegmentMap();
//			map.setContainerId(containerId);
//			map.setFunctionId(functionId);
//			map.setSegmentId(segmentIds[i]);
//			map.setMuId(muIds[muIndex]);
//			map.setSegmentVersion(segVers[i]);
//			map.setStatus(0);
//			maps.add(map);
//			muIndex++;
//		}
//		return maps;
//	}
//
//	public int sumRow(int row, boolean[][] matrix) {
//		int[] rowData = new int[matrix[row].length];
//		int sum = 0;
//		for (int i = 0; i < rowData.length; i++) {
//			if (matrix[row][i] == true) {
//				sum++;
//			}
//		}
//		return sum;
//	}
//
//	public int sumCol(int col, boolean[][] matrix) {
//		int[] colData = new int[matrix.length];
//		int sum = 0;
//		for (int i = 0; i < colData.length; i++) {
//			if (matrix[i][col] == true) {
//				sum++;
//			}
//		}
//		return sum;
//	}
//
//	static String printSpace(int count) {
//		StringBuilder bu = new StringBuilder();
//		for (int i = 0; i < count; i++) {
//			bu.append(space.toString());
//		}
//		return bu.toString();
//	}
//
//	public String printMartix(boolean[][] matrix) {
//		int rows = matrix.length;
//		int cols = matrix[0].length;
//		StringBuilder sb = new StringBuilder();
//		sb.append("\n");
//		sb.append("Print Matrix:");
//		sb.append("\n");
//		sb.append(String.format("%2s", space));
//
//		for (int i = 0; i < cols; i++) {
//			sb.append(String.format("%6d", i));
//		}
//		sb.append("\n");
//		for (int i = 0; i < rows; i++) {
//			sb.append(String.format("%2d", i));
//			for (int j = 0; j < cols; j++) {
//				if (matrix[i][j] == true) {
//					sb.append(String.format("%6s", "X"));
//				} else {
//					sb.append(String.format("%6s", space));
//				}
//			}
//			sb.append("\n");
//		}
//		return sb.toString();
//	}
//
//	public boolean[][] buildMuSegmentMatrix(int redundancy, int muCount,
//			int segCount) {
//		boolean[][] muSegmentMatrix = new boolean[muCount][segCount];
//		int segsPerMu = segCount / muCount * redundancy;
//		int sumRow = 0;
//		int sumCol = 0;
//		int seg = 0;
//		int mu = 0;
//		int firsrtR = 0;
//		int startR = 0;
//		firsrtR = startR;
//		while (seg < segCount) {
//			mu = firsrtR;
//			while (mu < muCount) {
//				sumCol = sumCol(seg, muSegmentMatrix);
//				sumRow = sumRow(mu, muSegmentMatrix);
//				if (muSegmentMatrix[mu][seg] != true && sumCol < redundancy
//						&& sumRow < segsPerMu) {
//					muSegmentMatrix[mu][seg] = true;
//					mu++;
//				} else {
//					muSegmentMatrix[mu][seg] = false;
//					mu++;
//				}
//			}
//			seg++;
//			firsrtR++;
//			if (firsrtR >= muCount) {
//				firsrtR = 0;
//			}
//		}
//		for (int i = 0; i < muSegmentMatrix[0].length; i++) {
//			if (i == 4 || i == 9) {
//				muSegmentMatrix[0][i] = true;
//			}
//		}
//		return muSegmentMatrix;
//	}
//
//	public void preparePrameter(List<MuSegmentMap> testMapList,
//			List<MuCpuAndPressure> muAbilitys) {
//		final Integer containerId = 1;
//		final Integer functionId = 1;
//		Long[] segIds = { 1000L, 1001L, 1002L, 1003L, 1004L, 1005L };
//		Integer[] muIds = { 1, 2, 3, 4, 5, 6 };
//		Long[] segVers = { 10L, 11L, 12L, 13L, 14L, 15L };
//		testMapList = createTestMuSegMaps(functionId, containerId, muIds,
//				segIds, segVers);
//
//		long time = System.currentTimeMillis();
//		int[] cpus = { 2, 4, 4, 8, 8, 12 };
//		long[] pressures = { 1l, 2l, 3l, 4l, 5l, 6l };
//		long[] reportTs = { time + 500l, time + 1000l, time + 2000l,
//				time + 3000l, time + 4000l, time + 5000l };
//
//		for (int i = 0; i < muIds.length; i++) {
//			MuCpuAndPressure mp = new MuCpuAndPressure();
//			mp.setMuId(muIds[i]);
//			mp.setAbility(cpus[i]);
//			mp.setPressure(pressures[i]);
//			mp.setReportTs(reportTs[i]);
//			muAbilitys.add(mp);
//		}
//	}
//}
