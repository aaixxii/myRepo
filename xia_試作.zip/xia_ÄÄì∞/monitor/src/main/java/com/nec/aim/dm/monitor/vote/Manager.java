package com.nec.aim.dm.monitor.vote;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class Manager {	
	private static final ScheduledExecutorService tolenScheduler = Executors.newScheduledThreadPool(1);
	private static final ConcurrentHashMap<String, String> dmInfoMap = new ConcurrentHashMap<>();
	
	public static void sheduleTask(Runnable task, long rate) {
		tolenScheduler.scheduleAtFixedRate(task, 0, rate, TimeUnit.MILLISECONDS);
	}
	
	public static void shutdown() {
		tolenScheduler.shutdown();
		dmInfoMap.clear();
	}
	
	public static void put(String key , String value) {
		dmInfoMap.putIfAbsent(key, value);
	}
	
	public String getValue(String key) {
		return dmInfoMap.get(key);
	}
}
