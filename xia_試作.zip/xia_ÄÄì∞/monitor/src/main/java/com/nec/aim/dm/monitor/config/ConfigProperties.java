package com.nec.aim.dm.monitor.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Data;

@Data
@Component
@ConfigurationProperties(prefix = "dm.monitor")
public class ConfigProperties {
	private int myId;
	private String dmId; 
	private int interval; 	
}
