package com.nec.aim.dm.nodostorage.service;

import java.sql.SQLException;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nec.aim.dm.nodostorage.config.ConfigProperties;
import com.nec.aim.dm.nodostorage.repository.NodeStorageRepository;
import com.nec.aim.dm.nodostorage.repository.SegmentLoadRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class HeatbeatService {
	
	private static final ScheduledExecutorService statusUpdateScheduler = Executors.newScheduledThreadPool(1);
	private static final ScheduledExecutorService catchUpScheduler = Executors.newScheduledThreadPool(1);
	
	@Autowired
	NodeStorageRepository nodeStorageRepository;
	
	@Autowired
	SegmentLoadRepository segmentLoadRepository;
	
	@Autowired
	ConfigProperties config;
	
	@PostConstruct
	public void updateMyInfo() throws SQLException {
		Runnable statusUpdateTask = () -> {
			try {
				nodeStorageRepository.heatbeat();
			} catch (SQLException e) {
				log.warn(e.getMessage());
			}
		};	
		statusUpdateScheduler.scheduleAtFixedRate(statusUpdateTask, 0, config.getHeatbeatInterval(), TimeUnit.MILLISECONDS);
		
		Runnable catchUpTask = () -> {			
			int mailFlag = -1;
			try {
				mailFlag = nodeStorageRepository.getMyMailFlag();
			} catch (SQLException e) {
				log.error(e.getMessage());
			}
			if (mailFlag > 0) {
				doCatchUp();
			}	
		};		
		catchUpScheduler.scheduleAtFixedRate(catchUpTask, 0, config.getCatchUpInterval(), TimeUnit.MILLISECONDS);
	}
	
	@PreDestroy
	public void colse() {
		statusUpdateScheduler.shutdown();
		catchUpScheduler.shutdown();
	}
	
	private void doCatchUp() {	
		try {
			List<Long> catchUpSegmenIds = segmentLoadRepository.getMustCatchUpSegments();
			
		} catch (SQLException e) {
			
		}
		
	}
	
}
