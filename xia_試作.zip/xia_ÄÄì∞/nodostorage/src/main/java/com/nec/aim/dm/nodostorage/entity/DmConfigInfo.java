package com.nec.aim.dm.nodostorage.entity;

import lombok.Data;

@Data
public class DmConfigInfo {	
	int configId;
	int key_name;
	int key_value;
}
