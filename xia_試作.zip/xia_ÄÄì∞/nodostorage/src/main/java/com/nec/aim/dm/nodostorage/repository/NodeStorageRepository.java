package com.nec.aim.dm.nodostorage.repository;

import java.sql.SQLException;



public interface NodeStorageRepository {	
	public void heatbeat() throws SQLException;
	public int getMyMailFlag()throws SQLException;	
}
