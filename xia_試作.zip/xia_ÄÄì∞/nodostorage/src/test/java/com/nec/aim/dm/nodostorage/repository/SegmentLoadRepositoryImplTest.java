package com.nec.aim.dm.nodostorage.repository;

import static org.junit.Assert.*;

import java.sql.SQLException;
import java.util.List;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.junit4.SpringRunner;

import com.nec.aim.dm.nodostorage.NodostorageApplication;



@RunWith(SpringRunner.class)
@SpringBootTest(classes = { NodostorageApplication.class })
public class SegmentLoadRepositoryImplTest {
	
	@Autowired
    private JdbcTemplate jdbcTemplate;
	
	@Autowired
	SegmentLoadRepository segmentLoadRepository;
	

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testGetMustCatchUpSegments() throws SQLException {
		List<Long> result = segmentLoadRepository.getMustCatchUpSegments();
		Assert.assertEquals(1, result.size());
	}

}
