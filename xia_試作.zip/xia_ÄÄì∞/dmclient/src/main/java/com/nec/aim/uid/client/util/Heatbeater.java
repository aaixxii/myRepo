package com.nec.aim.uid.client.util;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Heatbeater {
	private static Logger logger = LoggerFactory.getLogger(Heatbeater.class);
	public static boolean isActive(String ip) {
		String cmd = "ping " + ip;
		boolean isActive = false;
		try {
			Process p = Runtime.getRuntime().exec(cmd);
			BufferedReader inputStream = new BufferedReader(
					new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8));
			String allString = "";
			String s = "";			
			while ((s = inputStream.readLine()) != null) {
				allString = allString + s;				
			}			
			logger.info(allString);
			if (allString.length() > 400) {
				isActive = true;
			} else {
				isActive =  false;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return isActive;	
	}	

}
