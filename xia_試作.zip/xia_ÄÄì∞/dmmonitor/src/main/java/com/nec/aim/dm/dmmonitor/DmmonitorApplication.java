package com.nec.aim.dm.dmmonitor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DmmonitorApplication {

	public static void main(String[] args) {
		SpringApplication.run(DmmonitorApplication.class, args);
	}

}
