package com.nec.aim.dm.dmmonitor;


import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DmmonitorApplicationTests {

	@Test
	void contextLoads() {
	}

}
