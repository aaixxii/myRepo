package jp.co.nec.aim.mm.acceptor;

import java.io.Serializable;

/**
 * The Sync Request Class <br>
 * include two fields <br>
 * 1. containerId -> Sync target container id <br>
 * 2. Record -> template binary information <br>
 * 
 * @author liuyq
 * 
 */
public final class AimSyncRequest implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -1485113056588337155L;

	/** container id **/
	private Integer containerId;
	/** record instance **/
	private Record record;

	/**
	 * SyncRequest
	 * 
	 * @param containerId
	 * @param binary
	 * @param eventId
	 * @param externalId
	 */
	
	public AimSyncRequest(int containerId) {
		this.containerId = containerId;		
	}	
	
	public AimSyncRequest(int containerId, Record record) {
		this.containerId = containerId;
		this.record = record;
	}

	public Integer getContainerId() {
		return containerId;
	}

	public void setContainerId(Integer containerId) {
		this.containerId = containerId;
	}

	public Record getRecord() {
		return record;
	}

	public void setRecord(Record record) {
		this.record = record;
	}
}
