CREATE DEFINER=`aimuser`@`%` FUNCTION `get_source_url`(
p_segment_id int) RETURNS varchar(1024) CHARSET utf8mb4
    DETERMINISTIC
BEGIN
  DECLARE l_url varchar(1024);
  DECLARE t_error integer DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
  SELECT DISTINCT
    dm.CONTACT_URL INTO l_url
  FROM DATA_MANAGERS dm,
       DM_SEG_REPORTS dsr,
       DM_SEGMENTS ds
  WHERE dm.DM_ID = dsr.DM_ID
  AND dm.DM_ID = ds.DM_ID
  AND dsr.SEGMENT_ID = p_segment_id
  AND ds.SEGMENT_ID = p_segment_id
  AND dm.STATE = 1
  AND dsr.STATUS IN (0, 1);
  IF t_error = 1 THEN
    RETURN l_url;
  ELSE
    RETURN "error";
  END IF;
END