CREATE DEFINER=`aimuser`@`%` PROCEDURE `decrease_extract_load`(
  in p_mu_id  int,
  in p_lot_count int,
  out o_pressure int
)
BEGIN
  declare l_count int;
  declare  l_pressure int;
  declare  t_err int DEFAULT 0;
  DECLARE EXIT HANDLER FOR  SQLEXCEPTION set t_err =1;   
  DECLARE CONTINUE HANDLER FOR SQLWARNING begin end;
  SELECT COUNT(*) INTO l_count FROM MU_EXTRACT_LOAD  WHERE MU_ID  = p_mu_id;
         IF l_count > 0 THEN
            SELECT PRESSURE INTO l_pressure  FROM MU_EXTRACT_LOAD  WHERE MU_ID = p_mu_id FOR UPDATE;
            UPDATE MU_EXTRACT_LOAD SET pressure = pressure - p_lot_count, update_ts = get_epoch_time_num() 
            WHERE MU_ID = p_mu_id; 
            set o_pressure=l_pressure;             
         ELSE
            INSERT INTO MU_EXTRACT_LOAD(MU_ID, PRESSURE, UPDATE_TS) VALUES(p_mu_id, 0, get_epoch_time_num());
            set o_pressure=0;
             COMMIT;           
         END IF;         
         IF (l_pressure < 0) THEN
           UPDATE MU_EXTRACT_LOAD SET PRESSURE = 0, UPDATE_TS = get_epoch_time_num() 
           WHERE MU_ID = p_mu_id;
         END IF;
         COMMIT;  
END