CREATE DEFINER=`aimuser`@`%` PROCEDURE `finish_extract_job`(
	IN p_mu_id INT,
    IN p_job_id BIGINT(38),
	IN p_result BLOB,
    IN p_tab_name VARCHAR(50),
    OUT l_count INT
)
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN
	DECLARE t_time BIGINT;
    DECLARE t_count INT;
     DECLARE t_in_tab_count INT;
    DECLARE t_error INT DEFAULT 0;
	DECLARE not_found INT DEFAULT 0; 
	DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET not_found = 1;
    SELECT UNIX_TIMESTAMP(NOW()) into t_time;
    UPDATE FE_JOB_QUEUE
    SET  LOT_JOB_ID = NULL,
       JOB_STATE = 2,
       FAILED_FLAG = 0,
       RESULT = p_result,
       RESULT_TS = t_time,
       MU_ID = p_mu_id
    WHERE  JOB_ID = p_job_id
	AND JOB_STATE = 1
	AND MU_ID = p_mu_id; 
	SELECT ROW_COUNT() into t_count;	
	IF t_count > 0 THEN
	SET @insSql = CONCAT('INSERT INTO FE_RESULTS (JOB_ID, RESULT_DATA, TEMPLATE_KEY, TEMPLATE_INDEX) SELECT jobid,result_data,tkey,tindex FROM ', p_tab_name);
    PREPARE stmt1 FROM @insSql;
    EXECUTE stmt1;
	END IF;
	UPDATE  EXTRACT_COMPLETE_COUNT
	SET COMPLETE_COUNT = COMPLETE_COUNT + t_count,
	COMPLETE_TS = t_time;              
    IF t_error = 1 THEN
       ROLLBACK; 
       set l_count = 0;
     ELSE
       COMMIT;  
       set l_count = t_count;
    END IF; 
END