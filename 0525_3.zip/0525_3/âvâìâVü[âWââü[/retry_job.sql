CREATE DEFINER=`aimuser`@`%` PROCEDURE `retry_job`(
 IN p_job_id BIGINT(38),
 OUT l_job_exec_count BIGINT)
BEGIN 
  DECLARE tab_count int;
 DECLARE o_job_exec_count BIGINT;
  DECLARE l_remain_jobs long;
  DECLARE l_family_id int;
  DECLARE t_error integer DEFAULT 0;
  DECLARE cur CURSOR FOR
  SELECT
    id
  FROM l_container_ids;
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
  DROP TEMPORARY TABLE IF EXISTS try_container_ids;
  CREATE TEMPORARY TABLE try_container_ids (
    id BIGINT(38)
  ) ENGINE = MEMORY;
  SET  @@autocommit=0;
  START TRANSACTION;
  INSERT INTO try_container_ids(id)
    SELECT cj.CONTAINER_JOB_ID FROM JOB_QUEUE jq, FUSION_JOBS fj, CONTAINER_JOBS cj WHERE jq.JOB_STATE < 2 AND 0 < jq.REMAIN_JOBS AND jq.JOB_ID = fj.JOB_ID AND fj.FUSION_JOB_ID = cj.FUSION_JOB_ID AND jq.JOB_ID = p_job_id for update;
   select count(id) into tab_count from try_container_ids;
   
  SET l_remain_jobs = tab_count;
  IF (0 < l_remain_jobs) THEN
UPDATE CONTAINER_JOBS
  SET  MR_ID = NULL,
       ASSIGNED_TS = NULL,
       JOB_STATE = 0,
       PLAN_ID = NULL,
       RESULT_TS = NULL,
       CONTAINER_JOB_RESULT = NULL 
    WHERE container_job_id IN (SELECT
        id
      FROM try_container_ids);
 UPDATE JOB_QUEUE
SET    JOB_STATE = 0,
       FAILURE_COUNT = FAILURE_COUNT + 1,
       ASSIGNED_TS = NULL,
       REMAIN_JOBS = l_remain_jobs
WHERE  JOB_ID = p_job_id; 

SELECT jq.FAMILY_ID
INTO   l_family_id
FROM   JOB_QUEUE jq
WHERE  jq.JOB_ID = p_job_id; 

UPDATE INQUIRY_TRAFFIC
SET    JOB_EXEC_COUNT = JOB_EXEC_COUNT - 1
WHERE  FAMILY_ID = l_family_id;

SELECT JOB_EXEC_COUNT
INTO   l_job_exec_count
FROM   INQUIRY_TRAFFIC; 
    IF l_job_exec_count < 0 THEN
     UPDATE INQUIRY_TRAFFIC it 
      SET JOB_EXEC_COUNT = (
       SELECT  COUNT(JOB_ID)  FROM JOB_QUEUE jq                
        WHERE it.FAMILY_ID = jq.FAMILY_ID  AND jq.JOB_STATE = 1);  
        SELECT JOB_EXEC_COUNT
          INTO  l_job_exec_count
           FROM  INQUIRY_TRAFFIC
        WHERE  FAMILY_ID = l_family_id;   
	END IF;
    IF t_error = 1 THEN
      ROLLBACK;     
    ELSE
      COMMIT;       
    END IF;
  END IF;
END