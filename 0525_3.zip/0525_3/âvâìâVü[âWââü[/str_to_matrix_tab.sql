CREATE DEFINER=`aimuser`@`%` PROCEDURE `str_to_matrix_tab`(
  IN p_slb_matrix VARCHAR(2048),
  out err int
)
BEGIN
  DECLARE t_len int; 
  DECLARE t_idx int DEFAULT 1;
  DECLARE t_idx_2 int;
  DECLARE t_tmp varchar(20);
  DECLARE t_mu_id int;
  DECLARE t_seg BIGINT;
  DECLARE not_found int DEFAULT 0;
  DECLARE t_error integer DEFAULT 0;
  DROP TEMPORARY TABLE IF EXISTS list_tmp;
   CREATE TEMPORARY TABLE list_tmp (
    mu_id int,
    seg_id BIGINT(38)
  ) ENGINE = MEMORY;

-- slb_matrix data="muId1:1000,muId2:1001,muId2:1003"; 
 SELECT
    LENGTH(p_slb_matrix) INTO t_len;
while_lab:
  WHILE t_len > 0
    && t_idx > 0 DO
    SET t_idx = INSTR(p_slb_matrix, ',');
    IF t_idx <= 0 THEN
      SET t_tmp = p_slb_matrix;
      SET t_idx_2 = INSTR(t_tmp, ':');
      SET t_mu_id = CAST(SUBSTR(t_tmp, 1, t_idx_2 - 1) AS UNSIGNED);
      SET t_seg = CAST(SUBSTR(t_tmp, t_idx_2 + 1, LENGTH(t_tmp)) AS UNSIGNED);
      INSERT INTO list_tmp
        VALUES (t_mu_id, t_seg);
      LEAVE while_lab;
    END IF;
    SET t_tmp = SUBSTR(p_slb_matrix, 1, t_idx - 1);
    SET t_idx_2 = INSTR(t_tmp, ':');
    SET t_mu_id = CAST(SUBSTR(t_tmp, 1, t_idx_2 - 1) AS UNSIGNED);
    SET t_seg = CAST(SUBSTR(t_tmp, t_idx_2 + 1, LENGTH(t_tmp)) AS UNSIGNED);
    INSERT INTO list_tmp
      VALUES (t_mu_id, t_seg);
    SET p_slb_matrix = SUBSTR(p_slb_matrix, t_idx + 1, LENGTH(p_slb_matrix));
    SET t_len = LENGTH(p_slb_matrix);
  END WHILE;
    if t_error =1 then
	   set err=1;
	ELSE  
      set err=0;
    END IF;  
END