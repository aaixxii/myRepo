CREATE DEFINER=`aimuser`@`%` PROCEDURE `update_inquiry_traffic`(
IN p_top_job_id int
)
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN
  DECLARE l_job_exec_count int;
  DECLARE l_job_limit_count int;
  DECLARE l_family_id int;
  DECLARE t_err int DEFAULT 0;  
  DECLARE  not_found integer DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_err = 1;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET not_found = 1;
  
  -- DECLARE CONTINUE HANDLER FOR SQLWARNING BEGIN END;  
  SET  @@autocommit=0;
  SELECT
    FAMILY_ID INTO l_family_id
  FROM JOB_QUEUE
  WHERE JOB_ID = p_top_job_id;
  UPDATE INQUIRY_TRAFFIC it
  SET it.JOB_EXEC_COUNT = it.JOB_EXEC_COUNT + 1
  WHERE it.FAMILY_ID = l_family_id;
  SELECT
    JOB_EXEC_COUNT,
    JOB_LIMIT_COUNT INTO l_job_exec_count, l_job_limit_count
  FROM INQUIRY_TRAFFIC it
  WHERE it.FAMILY_ID = l_family_id;
  IF (l_job_exec_count < 0
    OR l_job_exec_count > l_job_limit_count) THEN
    UPDATE INQUIRY_TRAFFIC it
    SET it.JOB_EXEC_COUNT = (SELECT
        COUNT(JOB_ID)
      FROM JOB_QUEUE jq
      WHERE jq.FAMILY_ID = it.FAMILY_ID
      AND jq.JOB_STATE = 1)
    WHERE it.FAMILY_ID = l_family_id;
  END IF;
  IF t_error = 1 THEN
    ROLLBACK;  
  ELSE
    COMMIT;  
  END IF;
END