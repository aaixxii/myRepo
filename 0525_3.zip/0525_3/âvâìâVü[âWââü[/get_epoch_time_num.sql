CREATE DEFINER=`aimuser`@`%` FUNCTION `get_epoch_time_num`() RETURNS bigint(20)
    READS SQL DATA
    SQL SECURITY INVOKER
BEGIN
  DECLARE l_time int(38);
  SELECT UNIX_TIMESTAMP(NOW()) into l_time;
RETURN l_time;
END