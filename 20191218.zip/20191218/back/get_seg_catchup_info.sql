CREATE DEFINER=`aimuser`@`%` PROCEDURE `get_seg_catchup_info`(
	IN p_component_type INT,
	IN p_seg_diffs VARCHAR(1024),
    OUT tab_name VARCHAR(50)
	)
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
mylable:BEGIN 
	DECLARE v_idx INT DEFAULT 999;
	DECLARE v_tmp_str VARCHAR(1024);
        DECLARE v_view_str VARCHAR(1024);
	DECLARE v_ch_log_id BIGINT(38);
        DECLARE his_count int;
	DECLARE seg_diff varchar(64);
	DECLARE v_segId BIGINT(38);
	DECLARE v_reportVer BIGINT(38);
	DECLARE v_lastVer BIGINT(38);
	DECLARE t_error integer DEFAULT 0;
	DECLARE not_found integer DEFAULT 0; 
	DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET not_found = 1;
	DROP TEMPORARY TABLE IF EXISTS history_ids;
	CREATE TEMPORARY TABLE history_ids(id BIGINT(38) PRIMARY KEY) ENGINE = MEMORY;   
	DROP TABLE IF EXISTS segment_diffs;
	CREATE TABLE segment_diffs (
          seg_id BIGINT(38),
          rep_ver BIGINT(38),
          last_ver BIGINT(38)
	) ENGINE = innodb;
    
	DROP TEMPORARY TABLE IF EXISTS catchup_info_tab;
	CREATE TEMPORARY TABLE catchup_info_tab (
      segmentId BIGINT(38),
      biometrocsId BIGINT(38),
      segVer BIGINT(38),
      changType INT4,
      bioData BLOB,
      extId  VARCHAR(36),
      eventId INT
	) ENGINE = InnoDB;    
     
	SET  @@autocommit=0;
    IF LENGTH(p_seg_diffs) < 1 THEN
	    LEAVE mylable;
	END IF;
    -- p_seg_diffs= '{1000:1:5},{1001:2:5},{1002:1:7}';
	while_labe: WHILE v_idx > 0 DO
     SET v_idx = INSTR(p_seg_diffs,',');
	 IF v_idx <=0 then
         SET v_tmp_str = substr(p_seg_diffs,2,LENGTH(p_seg_diffs)-2); 
		 SET v_segId = SUBSTRING_INDEX(v_tmp_str,':',1);           
		 SET v_reportVer = SUBSTRING_INDEX(v_tmp_str,':',2);
         SET v_reportVer = SUBSTRING_INDEX(v_reportVersion, ':', -1);
		 SET v_lastVer = SUBSTRING_INDEX(v_tmp_str,':',-1);
		 INSERT INTO  segment_diffs(seg_id,rep_ver,last_ver) VALUES(CAST(v_segId AS UNSIGNED), CAST(v_report AS UNSIGNED),CAST(v_lastVer AS UNSIGNED));       
         LEAVE while_labe;
      END IF;
      SET v_tmp_str = substr(p_seg_diffs,3,v_idx-3); 
	  	 SET v_segId = SUBSTRING_INDEX(v_tmp_str,':',1);           
		 SET v_reportVer = SUBSTRING_INDEX(v_tmp_str,':',2);
         SET v_reportVer = SUBSTRING_INDEX(v_reportVersion, ':', -1);
		 SET v_lastVer = SUBSTRING_INDEX(v_tmp_str,':',-1);
		 INSERT INTO  segment_diffs(seg_id,rep_ver,last_ver) VALUES(CAST(v_segId AS UNSIGNED), CAST(v_reportVer AS UNSIGNED),CAST(v_lastVer AS UNSIGNED));
         SET p_seg_diffs=substr(p_seg_diffs,v_idx +1 ,LENGTH(p_seg_diffs));
	END WHILE;
    IF t_error = 1 THEN	 
       SET tab_name = '';
       LEAVE mylable;
	END IF;  
	INSERT INTO history_ids(id)
    SELECT seglg.SEGMENT_CHANGE_ID
            FROM SEGMENT_CHANGE_LOG seglg, segment_diffs segdf             
            WHERE seglg.SEGMENT_ID = segdf.segmentId
              AND seglg.SEGMENT_VERSION <= segdf.latestVersion 
              AND seglg.SEGMENT_VERSION > segdf.reportVersion
            ORDER BY SEGMENT_CHANGE_ID, SEGMENT_VERSION;
   select COUNT(id) INTO his_count FROM history_ids;
   IF his_count < 1 THEN
	  SET tab_name = '';
      LEAVE mylable;
   END IF;   
	IF (p_component_type = 3) THEN
      INSERT INTO catchup_info_tab(segmentId,biometrocsId,segVer,changType,bioData,extId, eventId)
	  SELECT
        scl.SEGMENT_ID,
        scl.BIOMETRICS_ID,
        scl.SEGMENT_VERSION,
        scl.CHANGE_TYPE,
        CASE WHEN scl.CHANGE_TYPE = 1 THEN NULL ELSE pb.BIOMETRIC_DATA END AS BIOMETRIC_DATA,
        pb.EXTERNAL_ID,
        pb.EVENT_ID
	  FROM SEGMENT_CHANGE_LOG scl,PERSON_BIOMETRICS pb
	  WHERE scl.BIOMETRICS_ID = pb.BIOMETRICS_ID 
	  AND scl.SEGMENT_CHANGE_ID IN (SELECT id FROM  history_ids) 
	  ORDER BY scl.SEGMENT_ID, scl.SEGMENT_CHANGE_ID; 
   ELSEIF (p_component_type = 1) THEN
     INSERT INTO catchup_info_tab(segmentId,biometrocsId,segVer,changType,bioData,extId, eventId)
     SELECT
        SEGMENT_ID,
        BIOMETRICS_ID,
        SEGMENT_VERSION,
       CHANGE_TYPE,
	    NULL AS BIOMETRIC_DATA,
        NULL AS EXTERNAL_ID,
        NULL AS EVENT_ID
       FROM SEGMENT_CHANGE_LOG
       WHERE segment_change_id IN (SELECT id from history_ids)       
      ORDER BY segment_id, segment_change_id;
      SET tab_name = 'catchup_info_tab';
  END IF;
  IF t_error = 1 THEN
    ROLLBACK;   
     SET tab_name = '';
  ELSE
    COMMIT;       
  END IF;
  DROP TEMPORARY TABLE IF EXISTS history_ids;
  DROP TEMPORARY TABLE IF EXISTS segment_diffs; 
END