package jp.co.nec.aim.mm.procedure;

import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.sql.DataSource;

import jp.co.nec.aim.mm.entities.FeLotJobEntity;
import jp.co.nec.aim.mm.entities.MuExtractLoadEntity;
import jp.co.nec.aim.mm.extract.planner.FeProcedureResults;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class ProcessOneFeMatchUnitProcedureTest extends
		AbstractTransactionalJUnit4SpringContextTests {

	@PersistenceContext(unitName = "aim-db")
	protected EntityManager entityManager;
	@Resource
	protected DataSource dataSource;
	@Resource
	protected JdbcTemplate jdbcTemplate;
	private ProcessOneFeMatchUnitProcedure oneProcedure;

	@Before
	public void setUp() throws Exception {
		oneProcedure = new ProcessOneFeMatchUnitProcedure(dataSource);
		jdbcTemplate.update("delete from mu_extract_load");
		jdbcTemplate.update("delete from mu_eligible_functions");
		jdbcTemplate.update("delete from fe_job_queue");
		jdbcTemplate.update("delete from fe_lot_jobs");
		jdbcTemplate.update("delete from match_units");
		jdbcTemplate.execute("commit");
	}

	@After
	public void tearDown() throws Exception {
		oneProcedure = null;
		jdbcTemplate.update("delete from mu_extract_load");
		jdbcTemplate.update("delete from mu_eligible_functions");
		jdbcTemplate.update("delete from fe_job_queue");
		jdbcTemplate.update("delete from fe_lot_jobs");
		jdbcTemplate.update("delete from match_units");
		jdbcTemplate.execute("commit");
	}

	@Test
	public void testProcessOneFeMatchUnit_normal() {
		int maxMulots = 12;
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		String extratLoadSql = "INSERT INTO MU_EXTRACT_LOAD (MU_ID, PRESSURE, UPDATE_TS)  VALUES(?,?,?)";
		String eligibleFunctionsSql = "INSERT INTO MU_ELIGIBLE_FUNCTIONS (MU_ID,FUNCTION_ID) VALUES(?,?)";

		int[] muIds = { 1000, 1001, 1002, 1003, 1004 };
		Integer muCpu = 4;
		String[] muStautus = { "WORKING", "EXIT", "WORKING", "WORKING",
				"WORKING" };
		int[] muCpus = { 4, 8, 4, 4, 4 };
		int[] muPressure = { 4, 5, 6, 7, 8 };
		int[] muFunctionId = { 17, 17, 17, 17, 17 };
		long epochTime = System.currentTimeMillis();
		for (int i = 0; i < 5; i++) {
			jdbcTemplate.update(muSql, new Object[] { new Integer(muIds[i]),
					String.valueOf((muIds[i])), muStautus[i],
					new Integer(muCpus[i]) });
			jdbcTemplate.update(extratLoadSql, new Object[] {
					new Integer(muIds[i]), new Integer(muPressure[i]),
					new Long(epochTime) });
			jdbcTemplate.update(eligibleFunctionsSql, new Object[] {
					new Integer(muIds[i]), new Integer(muFunctionId[i]) });
		}

		long assignedTS = System.currentTimeMillis();
		Long[] feJobIds = { 3000L, 3001L, 3002L, 3003L, 3004L };
		Integer[] priotity = { 2, 2, 2, 3, 2 };
		Integer[] states = { 0, 0, 0, 0, 0 };
		Integer[] failureCount = { 0, 1, 2, 2, 1 };

		String feJobSql = "insert into fe_job_queue(job_id,function_id,PRIORITY,job_state,failure_count,submission_ts,CALLBACK_STYLE)"
				+ " values(?,17,?,?,?,?,0)";
		for (int i = 0; i < feJobIds.length; i++) {
			jdbcTemplate.update(feJobSql, new Object[] { feJobIds[i],
					priotity[i], states[i], failureCount[i],
					new Long(assignedTS) });
		}

		String topJobtimeOutValueSql = " SELECT top_level_job_timeouts"
				+ " FROM function_types " + " WHERE function_id = 17"
				+ "AND queue_type = 1";
		Long topJobtimeOutValue = jdbcTemplate.queryForObject(
				topJobtimeOutValueSql, Long.class);
		topJobtimeOutValue = topJobtimeOutValue * muCpu;
		jdbcTemplate.execute("commit");
		Long selectedMuId = 1000L;
		FeProcedureResults feResults = new FeProcedureResults();
		// Long lotJobId;
		try {
			feResults = oneProcedure.processOneFeMatchUnit(maxMulots);
			Long lotJobId = feResults.getFeLotJobId();
			Assert.assertTrue(lotJobId.longValue() > 0);
			FeLotJobEntity feLotJob = entityManager.find(FeLotJobEntity.class,
					lotJobId);
			Assert.assertNotNull(topJobtimeOutValue);
			Assert.assertEquals(topJobtimeOutValue.longValue(),
					feLotJob.getTimeouts());
			Assert.assertEquals(selectedMuId.intValue(), feLotJob.getMuId());
			String muExLoadSql = "from MuExtractLoadEntity ml where ml.muId =:muid";
			Query q = entityManager.createQuery(muExLoadSql);
			q.setParameter("muid", selectedMuId);
			MuExtractLoadEntity muLoad = (MuExtractLoadEntity) q
					.getSingleResult();
			Assert.assertNotNull(muLoad);
			Assert.assertTrue((muLoad.getPressure() >= 1L));
			String feJobQueueMuIdSql = "select mu_id from fe_job_queue where lot_job_id= ?";
			List<Map<String, Object>> muIdLsit = jdbcTemplate.queryForList(
					feJobQueueMuIdSql, lotJobId);
			Iterator<Map<String, Object>> it = muIdLsit.iterator();
			while (it.hasNext()) {
				Assert.assertEquals(selectedMuId.toString(),
						it.next().get("mu_id").toString());
			}

		} catch (DataAccessException | SQLException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testProcessOneFeMatchUnit_feJob1_proority_selected() {
		int maxMulots = 12;
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		String extratLoadSql = "INSERT INTO MU_EXTRACT_LOAD (MU_ID, PRESSURE, UPDATE_TS)  VALUES(?,?,?)";
		String eligibleFunctionsSql = "INSERT INTO MU_ELIGIBLE_FUNCTIONS (MU_ID,FUNCTION_ID) VALUES(?,?)";

		int[] muIds = { 1000, 1001, 1002, 1003, 1004 };
		String[] muStautus = { "WORKING", "WORKING", "WORKING", "WORKING",
				"WORKING" };
		int[] muCpus = { 4, 8, 4, 4, 4 };
		int[] muPressure = { 4, 5, 6, 7, 8 };
		int[] muFunctionId = { 17, 17, 17, 17, 17 };
		Long[] feJobIds = { 3000L, 3001L, 3002L, 3003L, 3004L };
		Integer[] priotity = { 1, 1, 1, 1, 1 };
		Integer[] states = { 0, 0, 0, 0, 0 };
		Integer[] failureCount = { 1, 1, 2, 2, 1 };
		long epochTime = System.currentTimeMillis();
		long assignedTS = System.currentTimeMillis();

		for (int i = 0; i < 5; i++) {
			jdbcTemplate.update(muSql, new Object[] { new Integer(muIds[i]),
					String.valueOf((muIds[i])), muStautus[i],
					new Integer(muCpus[i]) });
			jdbcTemplate.update(extratLoadSql, new Object[] {
					new Integer(muIds[i]), new Integer(muPressure[i]),
					new Long(epochTime) });
			jdbcTemplate.update(eligibleFunctionsSql, new Object[] {
					new Integer(muIds[i]), new Integer(muFunctionId[i]) });
		}

		String feJobSql = "insert into fe_job_queue(job_id,function_id,PRIORITY,job_state,failure_count,submission_ts,CALLBACK_STYLE)"
				+ " values(?,17,?,?,?,?,0)";
		for (int i = 0; i < feJobIds.length; i++) {
			jdbcTemplate.update(feJobSql, new Object[] { feJobIds[i],
					priotity[i], states[i], failureCount[i],
					new Long(assignedTS) });
		}

		String topJobtimeOutValueSql = " SELECT top_level_job_timeouts"
				+ " FROM function_types " + " WHERE function_id = 17"
				+ "AND queue_type = 1";
		Long topJobtimeOutValue = jdbcTemplate.queryForObject(
				topJobtimeOutValueSql, Long.class);
		topJobtimeOutValue = topJobtimeOutValue * 1;
		jdbcTemplate.execute("commit");
		Long selectedMuId = 1000L;
		FeProcedureResults feResults = new FeProcedureResults();
		try {
			feResults = oneProcedure.processOneFeMatchUnit(maxMulots);
			Long lotJobId = feResults.getFeLotJobId();
			Assert.assertTrue(lotJobId.longValue() > 0);
			FeLotJobEntity feLotJob = entityManager.find(FeLotJobEntity.class,
					lotJobId);
			Assert.assertNotNull(topJobtimeOutValue);
			Assert.assertEquals(topJobtimeOutValue.longValue(),
					feLotJob.getTimeouts());
			Assert.assertEquals(selectedMuId.intValue(), feLotJob.getMuId());
			String muExLoadSql = "from MuExtractLoadEntity ml where ml.muId =:muid";
			Query q = entityManager.createQuery(muExLoadSql);
			q.setParameter("muid", selectedMuId);
			MuExtractLoadEntity muLoad = (MuExtractLoadEntity) q
					.getSingleResult();
			Assert.assertNotNull(muLoad);
			Assert.assertTrue((muLoad.getPressure() >= 1L));
			String feJobQueueMuIdSql = "select mu_id from fe_job_queue where lot_job_id= ?";
			List<Map<String, Object>> muIdLsit = jdbcTemplate.queryForList(
					feJobQueueMuIdSql, lotJobId);
			Iterator<Map<String, Object>> it = muIdLsit.iterator();
			while (it.hasNext()) {
				Assert.assertEquals(selectedMuId.toString(),
						it.next().get("mu_id").toString());
			}
		} catch (DataAccessException | SQLException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testProcessOneFeMatchUnit_second_maxFailureCount_selected() {
		int maxMulots = 12;
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		String extratLoadSql = "INSERT INTO MU_EXTRACT_LOAD (MU_ID, PRESSURE, UPDATE_TS)  VALUES(?,?,?)";
		String eligibleFunctionsSql = "INSERT INTO MU_ELIGIBLE_FUNCTIONS (MU_ID,FUNCTION_ID) VALUES(?,?)";

		int[] muIds = { 1000, 1001, 1002, 1003, 1004 };
		Integer muCpu = 4;
		String[] muStautus = { "WORKING", "WORKING", "WORKING", "WORKING",
				"WORKING" };
		int[] muCpus = { 4, 8, 4, 4, 4 };
		int[] muPressure = { 5, 5, 5, 5, 5 };
		int[] muFunctionId = { 17, 17, 17, 17, 17 };
		Long[] feJobIds = { 3000L, 3001L, 3002L, 3003L, 3004L };
		Integer[] priotity = { 2, 2, 2, 2, 2 };
		Integer[] states = { 0, 0, 0, 0, 0 };
		Integer[] failureCount = { 3, 1, 2, 2, 1 };
		long epochTime = System.currentTimeMillis();
		long assignedTS = System.currentTimeMillis();

		for (int i = 0; i < 5; i++) {
			jdbcTemplate.update(muSql, new Object[] { new Integer(muIds[i]),
					String.valueOf((muIds[i])), muStautus[i],
					new Integer(muCpus[i]) });
			jdbcTemplate.update(extratLoadSql, new Object[] {
					new Integer(muIds[i]), new Integer(muPressure[i]),
					new Long(epochTime) });
			jdbcTemplate.update(eligibleFunctionsSql, new Object[] {
					new Integer(muIds[i]), new Integer(muFunctionId[i]) });
		}

		String feJobSql = "insert into fe_job_queue(job_id,function_id,PRIORITY,job_state,failure_count,submission_ts,CALLBACK_STYLE)"
				+ " values(?,17,?,?,?,?,0)";
		for (int i = 0; i < feJobIds.length; i++) {
			jdbcTemplate.update(feJobSql, new Object[] { feJobIds[i],
					priotity[i], states[i], failureCount[i],
					new Long(assignedTS) });
		}

		String topJobtimeOutValueSql = " SELECT top_level_job_timeouts"
				+ " FROM function_types " + " WHERE function_id = 17"
				+ "AND queue_type = 1";
		Long topJobtimeOutValue = jdbcTemplate.queryForObject(
				topJobtimeOutValueSql, Long.class);
		topJobtimeOutValue = topJobtimeOutValue * muCpu;
		jdbcTemplate.execute("commit");
		Long selectedMuId = 1000L;
		FeProcedureResults feResults = new FeProcedureResults();

		try {
			feResults = oneProcedure.processOneFeMatchUnit(maxMulots);
			Long lotJobId = feResults.getFeLotJobId();
			Assert.assertTrue(lotJobId.longValue() > 0);
			FeLotJobEntity feLotJob = entityManager.find(FeLotJobEntity.class,
					lotJobId);
			Assert.assertNotNull(topJobtimeOutValue);
			Assert.assertEquals(topJobtimeOutValue.longValue(),
					feLotJob.getTimeouts());
			Assert.assertEquals(selectedMuId.intValue(), feLotJob.getMuId());
			String muExLoadSql = "from MuExtractLoadEntity ml where ml.muId =:muid";
			Query q = entityManager.createQuery(muExLoadSql);
			q.setParameter("muid", selectedMuId);
			MuExtractLoadEntity muLoad = (MuExtractLoadEntity) q
					.getSingleResult();
			Assert.assertNotNull(muLoad);
			Assert.assertTrue((muLoad.getPressure() >= 1L));
			String feJobQueueMuIdSql = "select mu_id from fe_job_queue where lot_job_id= ?";
			List<Map<String, Object>> muIdLsit = jdbcTemplate.queryForList(
					feJobQueueMuIdSql, lotJobId);
			Iterator<Map<String, Object>> it = muIdLsit.iterator();
			while (it.hasNext()) {
				Assert.assertEquals(selectedMuId.toString(),
						it.next().get("mu_id").toString());
			}
		} catch (DataAccessException | SQLException e) {
			e.printStackTrace();
		}

	}

	@Test
	public void testProcessOneFeMatchUnit_num_feJob_selected() {
		int maxMulots = 12;
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		String extratLoadSql = "INSERT INTO MU_EXTRACT_LOAD (MU_ID, PRESSURE, UPDATE_TS)  VALUES(?,?,?)";
		String eligibleFunctionsSql = "INSERT INTO MU_ELIGIBLE_FUNCTIONS (MU_ID,FUNCTION_ID) VALUES(?,?)";

		int[] muIds = { 1000, 1001, 1002, 1003, 1004 };
		Integer muCpu = 4;
		String[] muStautus = { "WORKING", "WORKING", "WORKING", "WORKING",
				"WORKING" };
		int[] muCpus = { 4, 8, 4, 4, 4 };
		int[] muPressure = { 4, 5, 6, 7, 8 };
		int[] muFunctionId = { 17, 17, 17, 17, 17 };
		Long[] feJobIds = { 3000L, 3001L, 3002L, 3003L, 3004L };
		Integer[] priotity = { 2, 2, 2, 2, 2 };
		Integer[] states = { 0, 0, 0, 0, 0 };
		Integer[] failureCount = { 1, 1, 1, 1, 1 };
		long epochTime = System.currentTimeMillis();
		long assignedTS = System.currentTimeMillis();

		for (int i = 0; i < 5; i++) {
			jdbcTemplate.update(muSql, new Object[] { new Integer(muIds[i]),
					String.valueOf((muIds[i])), muStautus[i],
					new Integer(muCpus[i]) });
			jdbcTemplate.update(extratLoadSql, new Object[] {
					new Integer(muIds[i]), new Integer(muPressure[i]),
					new Long(epochTime) });
			jdbcTemplate.update(eligibleFunctionsSql, new Object[] {
					new Integer(muIds[i]), new Integer(muFunctionId[i]) });
		}

		String feJobSql = "insert into fe_job_queue(job_id,function_id,PRIORITY,job_state,failure_count,submission_ts,CALLBACK_STYLE)"
				+ " values(?,17,?,?,?,?,0)";
		for (int i = 0; i < feJobIds.length; i++) {
			jdbcTemplate.update(feJobSql, new Object[] { feJobIds[i],
					priotity[i], states[i], failureCount[i],
					new Long(assignedTS) });
		}

		String topJobtimeOutValueSql = " SELECT top_level_job_timeouts"
				+ " FROM function_types " + " WHERE function_id = 17"
				+ "AND queue_type = 1";
		Long topJobtimeOutValue = jdbcTemplate.queryForObject(
				topJobtimeOutValueSql, Long.class);
		topJobtimeOutValue = topJobtimeOutValue * muCpu;
		jdbcTemplate.execute("commit");
		Long selectedMuId = 1000L;
		FeProcedureResults feResults = new FeProcedureResults();
		try {
			feResults = oneProcedure.processOneFeMatchUnit(maxMulots);
			Long lotJobId = feResults.getFeLotJobId();
			Assert.assertTrue(lotJobId.longValue() > 0);
			FeLotJobEntity feLotJob = entityManager.find(FeLotJobEntity.class,
					lotJobId);
			Assert.assertNotNull(topJobtimeOutValue);
			Assert.assertEquals(topJobtimeOutValue.longValue(),
					feLotJob.getTimeouts());
			Assert.assertEquals(selectedMuId.intValue(), feLotJob.getMuId());
			String muExLoadSql = "from MuExtractLoadEntity ml where ml.muId =:muid";
			Query q = entityManager.createQuery(muExLoadSql);
			q.setParameter("muid", selectedMuId);
			MuExtractLoadEntity muLoad = (MuExtractLoadEntity) q
					.getSingleResult();
			Assert.assertNotNull(muLoad);
			Assert.assertTrue((muLoad.getPressure() >= 1L));
			String feJobQueueMuIdSql = "select mu_id from fe_job_queue where lot_job_id= ?";
			List<Map<String, Object>> muIdLsit = jdbcTemplate.queryForList(
					feJobQueueMuIdSql, lotJobId);
			Iterator<Map<String, Object>> it = muIdLsit.iterator();
			while (it.hasNext()) {
				Assert.assertEquals(selectedMuId.toString(),
						it.next().get("mu_id").toString());
			}
		} catch (DataAccessException | SQLException e) {
			e.printStackTrace();
		}

	}

	@Test
	public void testProcessOneFeMatchUnit_all_feJob_no_state1() {
		int maxMulots = 12;
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		String extratLoadSql = "INSERT INTO MU_EXTRACT_LOAD (MU_ID, PRESSURE, UPDATE_TS)  VALUES(?,?,?)";
		String eligibleFunctionsSql = "INSERT INTO MU_ELIGIBLE_FUNCTIONS (MU_ID,FUNCTION_ID) VALUES(?,?)";

		int[] muIds = { 1000, 1001, 1002, 1003, 1004 };
		Integer muCpu = 4;
		String[] muStautus = { "WORKING", "WORKING", "WORKING", "WORKING",
				"WORKING" };
		int[] muCpus = { 4, 8, 4, 4, 4 };
		int[] muPressure = { 5, 5, 5, 5, 5 };
		int[] muFunctionId = { 17, 17, 17, 17, 17 };
		Long[] feJobIds = { 3000L, 3001L, 3002L, 3003L, 3004L };
		Integer[] priotity = { 2, 2, 2, 2, 2 };
		Integer[] states = { 1, 1, 1, 1, 1 };
		Integer[] failureCount = { 3, 1, 2, 2, 1 };
		long epochTime = System.currentTimeMillis();
		long assignedTS = System.currentTimeMillis();

		for (int i = 0; i < 5; i++) {
			jdbcTemplate.update(muSql, new Object[] { new Integer(muIds[i]),
					String.valueOf((muIds[i])), muStautus[i],
					new Integer(muCpus[i]) });
			jdbcTemplate.update(extratLoadSql, new Object[] {
					new Integer(muIds[i]), new Integer(muPressure[i]),
					new Long(epochTime) });
			jdbcTemplate.update(eligibleFunctionsSql, new Object[] {
					new Integer(muIds[i]), new Integer(muFunctionId[i]) });
		}

		String feJobSql = "insert into fe_job_queue(job_id,function_id,PRIORITY,job_state,failure_count,submission_ts,CALLBACK_STYLE)"
				+ " values(?,17,?,?,?,?,0)";
		for (int i = 0; i < feJobIds.length; i++) {
			jdbcTemplate.update(feJobSql, new Object[] { feJobIds[i],
					priotity[i], states[i], failureCount[i],
					new Long(assignedTS) });
		}

		String topJobtimeOutValueSql = " SELECT top_level_job_timeouts"
				+ " FROM function_types " + " WHERE function_id = 17"
				+ "AND queue_type = 1";
		Long topJobtimeOutValue = jdbcTemplate.queryForObject(
				topJobtimeOutValueSql, Long.class);
		topJobtimeOutValue = topJobtimeOutValue * muCpu;
		jdbcTemplate.execute("commit");
		FeProcedureResults feResults = new FeProcedureResults();
		try {
			feResults = oneProcedure.processOneFeMatchUnit(maxMulots);
			Assert.assertNull(feResults);
		} catch (DataAccessException | SQLException e) {
			e.printStackTrace();
		}

	}

	@Test
	public void testProcessOneFeMatchUnit_feJob1_proority_selected_one_only() {
		int maxMulots = 12;
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		String extratLoadSql = "INSERT INTO MU_EXTRACT_LOAD (MU_ID, PRESSURE, UPDATE_TS)  VALUES(?,?,?)";
		String eligibleFunctionsSql = "INSERT INTO MU_ELIGIBLE_FUNCTIONS (MU_ID,FUNCTION_ID) VALUES(?,?)";

		int[] muIds = { 1000, 1001, 1002, 1003, 1004 };
		String[] muStautus = { "WORKING", "WORKING", "WORKING", "WORKING",
				"WORKING" };
		int[] muCpus = { 4, 8, 4, 4, 4 };
		int[] muPressure = { 4, 5, 6, 7, 8 };
		int[] muFunctionId = { 17, 17, 17, 17, 17 };
		Long[] feJobIds = { 3000L, 3001L, 3002L, 3003L, 3004L };
		Integer[] priotity = { 1, 2, 2, 2, 2 };
		Integer[] states = { 0, 0, 0, 0, 0 };
		Integer[] failureCount = { 3, 1, 2, 2, 1 };
		long epochTime = System.currentTimeMillis();
		long assignedTS = System.currentTimeMillis();

		for (int i = 0; i < 5; i++) {
			jdbcTemplate.update(muSql, new Object[] { new Integer(muIds[i]),
					String.valueOf((muIds[i])), muStautus[i],
					new Integer(muCpus[i]) });
			jdbcTemplate.update(extratLoadSql, new Object[] {
					new Integer(muIds[i]), new Integer(muPressure[i]),
					new Long(epochTime) });
			jdbcTemplate.update(eligibleFunctionsSql, new Object[] {
					new Integer(muIds[i]), new Integer(muFunctionId[i]) });
		}

		String feJobSql = "insert into fe_job_queue(job_id,function_id,PRIORITY,job_state,failure_count,submission_ts,CALLBACK_STYLE)"
				+ " values(?,17,?,?,?,?,0)";
		for (int i = 0; i < feJobIds.length; i++) {
			jdbcTemplate.update(feJobSql, new Object[] { feJobIds[i],
					priotity[i], states[i], failureCount[i],
					new Long(assignedTS) });
		}

		String topJobtimeOutValueSql = " SELECT top_level_job_timeouts"
				+ " FROM function_types " + " WHERE function_id = 17"
				+ "AND queue_type = 1";
		Long topJobtimeOutValue = jdbcTemplate.queryForObject(
				topJobtimeOutValueSql, Long.class);
		topJobtimeOutValue = topJobtimeOutValue * 1;
		jdbcTemplate.execute("commit");
		Long selectedMuId = 1000L;
		FeProcedureResults feResults = new FeProcedureResults();
		try {
			feResults = oneProcedure.processOneFeMatchUnit(maxMulots);
			Long lotJobId = feResults.getFeLotJobId();
			Assert.assertTrue(lotJobId.longValue() > 0);
			FeLotJobEntity feLotJob = entityManager.find(FeLotJobEntity.class,
					lotJobId);
			Assert.assertNotNull(topJobtimeOutValue);
			Assert.assertEquals(topJobtimeOutValue.longValue(),
					feLotJob.getTimeouts());
			Assert.assertEquals(selectedMuId.intValue(), feLotJob.getMuId());
			String muExLoadSql = "from MuExtractLoadEntity ml where ml.muId =:muid";
			Query q = entityManager.createQuery(muExLoadSql);
			q.setParameter("muid", selectedMuId);
			MuExtractLoadEntity muLoad = (MuExtractLoadEntity) q
					.getSingleResult();
			Assert.assertNotNull(muLoad);
			Assert.assertTrue((muLoad.getPressure() >= 1L));
			String feJobQueueMuIdSql = "select mu_id from fe_job_queue where lot_job_id= ?";
			List<Map<String, Object>> muIdLsit = jdbcTemplate.queryForList(
					feJobQueueMuIdSql, lotJobId);
			Iterator<Map<String, Object>> it = muIdLsit.iterator();
			while (it.hasNext()) {
				Assert.assertEquals(selectedMuId.toString(),
						it.next().get("mu_id").toString());
			}
		} catch (DataAccessException | SQLException e) {
			e.printStackTrace();
		}
	}
}
