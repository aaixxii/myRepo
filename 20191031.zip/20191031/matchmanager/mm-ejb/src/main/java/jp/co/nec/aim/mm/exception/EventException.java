package jp.co.nec.aim.mm.exception;

public class EventException extends AimRuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2874681181709291204L;

	public EventException() {
	}

	public EventException(Throwable ex) {
		super(ex);
	}

	public EventException(String detail, Throwable ex) {
		super(detail, ex);
	}

}
