package jp.co.nec.aim.mm.dao;

import java.util.List;

import jp.co.nec.aim.mm.entities.FeJobPayloadEntity;
import jp.co.nec.aim.mm.entities.FeJobQueueEntity;
import jp.co.nec.aim.mm.entities.FeLotJobEntity;
import jp.co.nec.aim.mm.entities.MuExtractLoadEntity;

public interface FEPlanDispatchDao {
	public FeLotJobEntity getFeLotJob(long feLotJobId);

	public List<FeJobQueueEntity> getFeJobs(long feLotJobId);

	public List<FeJobPayloadEntity> getFeJobPayLoads(List<Long> feJobIds);

	public String getMuUrl(long muId);

	public long getFeJobTimeOut();

	public Integer getMaxExtractJobRetryCount();

	public MuExtractLoadEntity findMuExtractLoadEntity(long muId);

	public String getCallBackURL(long feJobId);

	public String getSystemConfigValue(String propertyName);

	public void updateMuExtractLoad(Integer muId);
}
