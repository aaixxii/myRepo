package jp.co.nec.aim.mm.exception;

public class UtilException extends AimRuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2874681181709291204L;

	public UtilException() {
	}

	public UtilException(Throwable ex) {
		super(ex);
	}

	public UtilException(String detail) {
		super(detail);
	}

	public UtilException(String detail, Throwable ex) {
		super(detail, ex);
	}

}
