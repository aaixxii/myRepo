package com.nec.aim.dm.dmservice.persistence;

import static org.junit.Assert.*;

import java.sql.SQLException;
import java.util.Map;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.junit4.SpringRunner;

import com.nec.aim.dm.dmservice.DmserviceApplication;
import com.nec.aim.dm.dmservice.entity.SegmentInfo;
import com.nec.aim.dm.dmservice.entity.SegmentLoading;

@RunWith(SpringRunner.class)  
@SpringBootTest(classes={DmserviceApplication.class})
public class SegmentLoadRepositoryImplTest {
	
	@Autowired
	SegmentRepository segmentRepository;
	
	@Autowired
	SegmentLoadRepository segmentLoadRepository;
	
	@Autowired
    private JdbcTemplate jdbcTemplate;
	

	@Before
	public void setUp() throws Exception {
		jdbcTemplate.execute("delete from segment_loading");
		jdbcTemplate.execute("delete from segments_info");
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testInsertSegmentLoad() throws SQLException {
		SegmentInfo segInfo = new SegmentInfo();
		segInfo.setSegmentId(1000);		
		segmentRepository.insertSegment(segInfo);
		SegmentLoading segLoading = new SegmentLoading();
		segLoading.setSegmentId(1000);
		segLoading.setStorage_id(1);
		segLoading.setStatus(1);
		segLoading.setLastVersion(0);
		segmentLoadRepository.insertSegmentLoad(segLoading);
		String selectSql = "select * from segment_loading where segment_id = 1000 and storage_id =1";
		Map<String, Object> result = jdbcTemplate.queryForMap(selectSql);
		long segmentId = (long) result.get("segment_id");
		long lastVer = (long) result.get("last_version");
		int status = (int) result.get("status");
	
		Assert.assertEquals(1000, segmentId);
		Assert.assertEquals(0, lastVer);
		Assert.assertEquals(1, status);	
		System.out.print("OKOK");	
		
	}

	@Test
	public void testUpdateSegmentLoadWithMailFlag() {
		fail("まだ実装されていません");
	}

	@Test
	public void testUpdateSegmentLoadNoMailFlag() {
		fail("まだ実装されていません");
	}

	@Test
	public void testDelBioFromSegmentLoadNoMailFlag() {
		fail("まだ実装されていません");
	}

	@Test
	public void testUpdateAfterNew() throws SQLException {
		SegmentInfo segInfo = new SegmentInfo();
		segInfo.setSegmentId(1000);		
		segmentRepository.insertSegment(segInfo);
		SegmentLoading segLoading = new SegmentLoading();
		segLoading.setSegmentId(1000);
		segLoading.setStorage_id(1);
		segLoading.setStatus(1);
		segLoading.setLastVersion(0);
		segmentLoadRepository.insertSegmentLoad(segLoading);
		segmentLoadRepository.updateAfterNew(-1, 1, 1000);
		String selectSql = "select * from segment_loading where segment_id = 1000 and storage_id =1";
		Map<String, Object> result = jdbcTemplate.queryForMap(selectSql);
		long segmentId = (long) result.get("segment_id");
		long lastVer = (long) result.get("last_version");
		int status = (int) result.get("status");
	
		Assert.assertEquals(1000, segmentId);
		Assert.assertEquals(-1, lastVer);
		Assert.assertEquals(1, status);	
		System.out.print("OKOK");
		
	}

	@Test
	public void testGetLastVersion() {
		fail("まだ実装されていません");
	}

}
