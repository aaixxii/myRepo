package com.nec.aim.dm.dmservice.entity;

import java.sql.Timestamp;

import lombok.Data;

@Data
public class NodeStorage {
	int storageId;
	String dmStorageid;
	String url;
	int diskSize;
	int space;
	int status;// pending:0 working:1 stopped:2 suspending:4 detached:5
	Timestamp updateTs;
	String mailFlag;
}
