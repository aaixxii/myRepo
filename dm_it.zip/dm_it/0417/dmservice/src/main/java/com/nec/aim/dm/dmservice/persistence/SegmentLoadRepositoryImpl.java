package com.nec.aim.dm.dmservice.persistence;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.nec.aim.dm.dmservice.entity.SegmentLoading;

@Repository
public class SegmentLoadRepositoryImpl implements SegmentLoadRepository {
	private static final String insertSql = "insert into segment_loading(storage_id, segment_id, status,last_version, last_ts) values (?,?,?,?,CURRENT_TIMESTAMP())";
	private static final String updateSqlWithMailFlag = "update segment_loading set status=?,last_version=?, last_ts=CURRENT_TIMESTAMP() where storage_id=? and segment_id =?";
	private static final String updateSqlWithNoMailFlag = "update segment_loading set last_version=?, last_ts=CURRENT_TIMESTAMP() where storage_id=? and segment_id =?";
	private static final String updateAfterdeleteBioSql = "update segment_loading set last_version=last_version+1, last_ts=CURRENT_TIMESTAMP() where storage_id=? and segment_id =?";
	private static final String updateAfterNew = "update segment_loading set last_version =? where storage_id =? and segment_id=?";
	private static final String getLastVerSql = "select last_version from segment_loading where storage_id = ? and segment_id =?";
	private static final String getActiveStoragesUrlSql = "select ng.url from segment_loading sl, node_storage ng where sl.storage_id=ng.storage_id and ng.status = 1 and segment_id=?";
	
	
	@Autowired
    private JdbcTemplate jdbcTemplate;	

	@Override
	public void insertSegmentLoad(SegmentLoading segLoad) throws SQLException {		
		jdbcTemplate.execute("SET @@autocommit=0");
		jdbcTemplate.update(insertSql, new Object[] {segLoad.getStorage_id(), segLoad.getSegmentId(), segLoad.getStatus(), segLoad.getLastVersion()});
	}	
	
	@Override
	public void updateSegmentLoadWithMailFlag(SegmentLoading segLoad) throws SQLException {
		jdbcTemplate.execute("SET @@autocommit=0");
		jdbcTemplate.update(updateSqlWithMailFlag, new Object[] {segLoad.getStatus(), segLoad.getLastVersion(),  segLoad.getStorage_id(), segLoad.getSegmentId()});		
	}

	@Override
	public void updateSegmentLoadNoMailFlag(SegmentLoading segLoad) throws SQLException {
		jdbcTemplate.execute("SET @@autocommit=0");
		jdbcTemplate.update(updateSqlWithNoMailFlag, new Object[] {segLoad.getLastVersion(),  segLoad.getStorage_id(), segLoad.getSegmentId()});
	}

	@Override
	public void updateAfterDelWithNoMailFlag(SegmentLoading segLoad) throws SQLException {
		jdbcTemplate.execute("SET @@autocommit=0");
		jdbcTemplate.update(updateAfterdeleteBioSql,  new Object[] {segLoad.getStorage_id(), segLoad.getSegmentId()});
	}

	@Override
	public void updateAfterNew(long version, int storage_id, long segmentId) throws SQLException {
		jdbcTemplate.execute("SET @@autocommit=0");
		jdbcTemplate.update(updateAfterNew, new Object[] {version, storage_id, segmentId});		
	}

	@Override
	public long getLastVersion(int storageId, long segmentId) throws SQLException {
		jdbcTemplate.execute("SET @@autocommit=0");
		Long lastVer = jdbcTemplate.queryForObject(getLastVerSql, new Object[] {storageId, segmentId},  Long.class);
		return lastVer.longValue();
	}

	@Override
	public List<String> getActiveStorageUrl(long segmentId) throws SQLException {
		return jdbcTemplate.queryForList(getActiveStoragesUrlSql, new Object[] {segmentId}, String.class);
	}
}
