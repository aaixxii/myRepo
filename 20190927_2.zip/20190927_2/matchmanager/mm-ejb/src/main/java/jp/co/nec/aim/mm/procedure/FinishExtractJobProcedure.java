package jp.co.nec.aim.mm.procedure;

import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.sql.DataSource;

import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplate;
import jp.co.nec.aim.mm.logger.PerformanceLogger;
import jp.co.nec.aim.mm.util.KeyedIndexer;
import jp.co.nec.aim.mm.util.StopWatch;

import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.SqlLobValue;
import org.springframework.jdbc.object.StoredProcedure;

/**
 * Spring StoredProcedure class to call finish_extract_job()
 * 
 * @author kurosu
 * 
 */
public class FinishExtractJobProcedure extends StoredProcedure {

	private static final String SQL = "MATCH_MANAGER_API.finish_extract_job";

	private String[] keyArray;
	private byte[][] templateArray;
	private int[] indexArray;

	public FinishExtractJobProcedure(DataSource dataSource) {
		setDataSource(dataSource);
		setFunction(true);
		setSql(SQL);
		declareParameter(new SqlOutParameter("l_count", Types.INTEGER));
		declareParameter(new SqlParameter("p_mu_id", Types.BIGINT));
		declareParameter(new SqlParameter("p_job_id", Types.BIGINT));
		declareParameter(new SqlParameter("p_result", Types.BLOB));
		declareParameter(new SqlParameter("p_keys", Types.ARRAY,
				"CLOB_TABLE_TYPE"));
		declareParameter(new SqlParameter("p_indexs", Types.ARRAY,
				"NUM_TABLE_TYPE"));
		declareParameter(new SqlParameter("p_values", Types.ARRAY,
				"BLOB_TABLE_TYPE"));
		compile();
	}

	/**
	 * Update FE_JOB_QUEUE SET JOB_STATE=DONE, and insert records into
	 * FE_RESULTS If keyedBinaries contains same keys, save 1st one.
	 * 
	 * @param muId
	 * @param jobId
	 * @param result
	 * @param keyedBinaries
	 * @return number of updated records of fe_job_queue
	 * @throws SQLException
	 */
	public int execute(long muId, long jobId, byte[] result,
			List<PBKeyedTemplate> keyedBinaries) throws SQLException {
		if (muId < 1L) {
			throw new IllegalArgumentException("muId is less than 1");
		}
		if (jobId < 1L) {
			throw new IllegalArgumentException("jobId is less than 1");
		}
		if (result == null) {
			throw new IllegalArgumentException("results is null");
		}
		if (keyedBinaries == null) {
			throw new IllegalArgumentException("keyedBinaries is null");
		}

		StopWatch stopWatch = new StopWatch();
		stopWatch.start();

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("p_mu_id", new Long(muId));
		map.put("p_job_id", new Long(jobId));
		map.put("p_result", new SqlLobValue(result));
		createKeyTemplateArray(keyedBinaries);
		ClobTableTypeValue ctValue = new ClobTableTypeValue(keyArray);
		map.put("p_keys", ctValue);
		NumTableTypeValue indexValue = new NumTableTypeValue(indexArray);
		map.put("p_indexs", indexValue);
		BlobTableTypeValue btValue = new BlobTableTypeValue(templateArray);
		map.put("p_values", btValue);
		Map<String, Object> resultMap = execute(map);
		ctValue.freeTemporary(getJdbcTemplate());
		btValue.freeTemporary(getJdbcTemplate());
		int count = ((Integer) resultMap.get("l_count")).intValue();

		stopWatch.stop();
		PerformanceLogger.log(getClass().getSimpleName(), "execute",
				stopWatch.elapsedTime());

		return count;
	}

	/**
	 * Create String array of unique Key.
	 * 
	 * @param keyedBinaries
	 * @return
	 */
	private void createKeyTemplateArray(List<PBKeyedTemplate> keyedBinaries) {
		Set<KeyedIndexer> keys = new HashSet<KeyedIndexer>();
		for (PBKeyedTemplate kt : keyedBinaries) {
			KeyedIndexer newKI = new KeyedIndexer(kt.getKey(), kt.getIndexer(),
					kt.getTemplateBinary());
			if (!keys.contains(newKI)) {
				keys.add(newKI);
			}
		}

		KeyedIndexer[] kiArray = keys.toArray(new KeyedIndexer[0]);
		keyArray = new String[kiArray.length];
		templateArray = new byte[kiArray.length][];
		indexArray = new int[kiArray.length];

		for (int i = 0; i < kiArray.length; i++) {
			keyArray[i] = kiArray[i].getKey();
			indexArray[i] = kiArray[i].getIndex();
			templateArray[i] = kiArray[i].getTemplate();
		}
	}

}
