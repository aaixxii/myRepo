package jp.co.nec.aim.mm.license;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import jp.co.nec.aim.mm.exception.LicenseException;

import org.junit.Assert;
import org.junit.Test;

/**
 * LicenseManagerTest
 * 
 * @author liuyq
 * 
 */
public class LicenseManagerTest {

	private LicenseManager manager = LicenseManager.getInstance();

	@Test
	public void testLicensePassed() {
		Date date = new Date(1432610352449L);
		try {
			manager.check("TI", date);
		} catch (LicenseException e) {
			Assert.fail();
		} catch (Exception e) {
			Assert.fail();
		}
	}

	@Test
	public void testLicense_function_error() {
		Date date = new Date(1432610352449L);
		try {
			manager.check("ERROR", date);
		} catch (LicenseException e) {
			Assert.assertEquals(
					"(License validation error with specified function name: ERROR,"
							+ " Error message: No enum constant jp.co.nec.aim.clientapi.afis.AfisLowLevelFunctionEnum.ERROR)",
					e.getMessage());
			return;
		}
		Assert.fail();
	}

	@Test
	public void testLicense_expired_error() {
		try {
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			Date date = format.parse("2050-1-1");
			manager.check("TI", date);
		} catch (LicenseException e) {
			Assert.assertEquals(
					"(License validation error with specified function name: TI, Error message: License for 'AIM' expired on 6/30/20; it is now 1/1/50.)",
					e.getMessage());
			return;
		} catch (ParseException e) {
			Assert.fail();
		}
		Assert.fail();
	}

	@Test
	public void testLicenseMultipThread() {
		final Date date = new Date(1432610352449L);
		final LicenseManager manager = LicenseManager.getInstance();

		ExecutorService service = null;
		try {
			service = Executors.newFixedThreadPool(100);
			List<Callable<Void>> tasks = new ArrayList<Callable<Void>>();
			for (int i = 0; i < 1000; i++) {
				tasks.add(new Callable<Void>() {
					@Override
					public Void call() throws Exception {
						manager.check("TI", date);
						return null;
					}
				});
			}
			service.invokeAll(tasks);
		} catch (InterruptedException e) {
			e.printStackTrace();
		} finally {
			if (service != null) {
				service.shutdown();
			}
		}

	}

}
