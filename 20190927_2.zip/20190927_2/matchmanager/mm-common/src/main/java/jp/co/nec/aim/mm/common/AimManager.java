package jp.co.nec.aim.mm.common;

import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import javax.servlet.AsyncContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.aim.message.proto.BusinessMessage.PBResponse;
import jp.co.nec.aim.message.proto.ExtractService.ExtractResponse;
import jp.co.nec.aim.message.proto.InquiryService.IdentifyResponse;
import jp.co.nec.aim.message.proto.SyncService.SyncResponse;


public class AimManager {
	private static Logger logger = LoggerFactory.getLogger(AimManager.class);
	private static final ConcurrentHashMap<Long, AsyncContext> inquiryJobCtxQueue = new ConcurrentHashMap<>();
	private static final ConcurrentHashMap<Long, AsyncContext> extractJobCtxQueue = new ConcurrentHashMap<>();
	private static final ConcurrentHashMap<Long, AsyncContext> syncJobJobCtxQueue = new ConcurrentHashMap<>();
	
	private static final ConcurrentHashMap<Long, IdentifyResponse> inquiryJobResQueue = new ConcurrentHashMap<>();
	private static final ConcurrentHashMap<Long, ExtractResponse> extractJobResQueue = new ConcurrentHashMap<>();
	private static final ConcurrentHashMap<Long, SyncResponse> syncJobJobResQueue = new ConcurrentHashMap<>();
	
	private static void doExtractRespose(Long key, Object value) {
		
	}
	
	public static void saveToExtractJobResQueue(Long key, ExtractResponse extResulst) {
		extractJobResQueue.putIfAbsent(key, extResulst);
	}
	
	public static void resExtractErr(Long key, PBResponse errRes ) {
		
	}	
	
	public static void addToInquiryJobCtxQueue(Long jobId,  AsyncContext ctx ) {		
		inquiryJobCtxQueue.putIfAbsent(jobId, ctx);
	}
	
	
	public static AsyncContext getInquiryAsncCtxToRespose(Long jobId) {
		return inquiryJobCtxQueue.get(jobId);		
	}
	
	public static void addToExtractJobCtxQueue(Long jobId,  AsyncContext ctx ) {		
		extractJobCtxQueue.putIfAbsent(jobId, ctx);
	}
	
	public static AsyncContext getExtractAsncCtxToRespose(Long jobId) {
		return extractJobCtxQueue.get(jobId);		
	}
	
	public static void addToSyncJobResQueue(Long jobId,  AsyncContext ctx ) {		
		syncJobJobCtxQueue.putIfAbsent(jobId, ctx);
	}
	
	public static AsyncContext getSyncAsncCtxToRespose(Long jobId) {
		return syncJobJobCtxQueue.get(jobId);		
	}	

}
