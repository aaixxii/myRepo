package com.nec.aim.uid.mumock.extract;

import com.google.protobuf.InvalidProtocolBufferException;
import com.nec.aim.uid.mumock.constants.Configer;
import com.nec.aim.uid.mumock.post.HttpPoster;
import com.nec.aim.uid.mumock.util.ProtobufCreater;

import jp.co.nec.aim.message.proto.AIMEnumTypes.ComponentType;
import jp.co.nec.aim.message.proto.AIMMessages.PBComponentInfo;
import jp.co.nec.aim.message.proto.AIMMessages.PBEnterResponse;

public class EnterPoster {
	
	public void entertoMM() {
		
		PBComponentInfo enterReq = ProtobufCreater.buildEnterReqeust(ComponentType.MATCH_UNIT, "http://192.168.22.118:8084", "http://192.168.22.118:8084");
		
		String url = "http://192.168.22.107:8080/matchmanager/Enter";
		byte[] enterRespose = HttpPoster.post(url, enterReq.toByteArray());
		PBEnterResponse enterRes = null;
		try {
			enterRes = PBEnterResponse.parseFrom(enterRespose);
		} catch (InvalidProtocolBufferException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		Configer.setMuId(enterRes.getId());
		System.out.print(enterRes.getId());
	}
}
