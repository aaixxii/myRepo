package com.nec.aim.uid.mumock;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.nec.aim.uid.mumock.extract.EnterPoster;

@SpringBootApplication
public class MockApplication {

	public static void main(String[] args) {
		SpringApplication.run(MockApplication.class, args);
		EnterPoster enter = new EnterPoster();
		enter.entertoMM();
		
		//HttpPoster.doMuHeatbeat();
	}
}
