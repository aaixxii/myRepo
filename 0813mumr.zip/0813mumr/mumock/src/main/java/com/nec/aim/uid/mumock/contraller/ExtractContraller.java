package com.nec.aim.uid.mumock.contraller;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.nec.aim.uid.mumock.extract.ExtractResultSender;

import jp.co.nec.aim.message.proto.AIMMessages.PBMuExtractJobRequest;
import lombok.extern.slf4j.Slf4j;



@Controller
@Slf4j
public class ExtractContraller extends HttpServlet {

	private static final long serialVersionUID = 8218404538720520522L;

	@RequestMapping(value = "/ExtractJob", method = RequestMethod.POST)
	public void extract(HttpServletRequest req, HttpServletResponse res) {
		log.info("Received extract request from {}", req.getRemoteHost());			
		try {
			PBMuExtractJobRequest pbExtReq = PBMuExtractJobRequest.parseFrom(req.getInputStream());	
			ExtractResultSender sender = new ExtractResultSender(pbExtReq);
			Thread task = new Thread(sender);
			task.start();
			//MockManager.sumitExtractCompleteTask(sender);
			res.setStatus(200);		
			
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			res.setStatus(500);
		}
	}

}
