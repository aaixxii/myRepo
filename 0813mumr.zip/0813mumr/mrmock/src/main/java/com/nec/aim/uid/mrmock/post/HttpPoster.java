package com.nec.aim.uid.mrmock.post;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.aim.uid.mrmock.constants.Configer;
import com.nec.aim.uid.mrmock.mant.MockManager;
import com.nec.aim.uid.mrmock.protobuf.ProtobufCreater;
import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;
import com.squareup.okhttp.Response;

import jp.co.nec.aim.message.proto.AIMEnumTypes.ComponentType;
import jp.co.nec.aim.message.proto.AIMMessages.PBComponentInfo;
import jp.co.nec.aim.message.proto.AIMMessages.PBHeartBeatResponse;

public class HttpPoster {
	private static Logger logger = LoggerFactory.getLogger(HttpPoster.class);	
	private static final MediaType MEDIA_TYPE_PLAINTEXT = MediaType.parse("text/plain; charset=utf-8");
	
	/**
	 * @param url
	 * @param dmSegReq
	 * @return
	 */
	public static byte[] post(String url, byte[] data) {
		Callable<byte[]> newPostTask = () -> {
			OkHttpClient client = new OkHttpClient();
			client.setConnectTimeout(30, TimeUnit.SECONDS);
			client.setReadTimeout(30, TimeUnit.SECONDS);
			client.setWriteTimeout(30, TimeUnit.SECONDS);			
			Request request = new Request.Builder().url(url)
					.post(RequestBody.create(MEDIA_TYPE_PLAINTEXT, data)).build();
			byte[] responseData = null;
			try {
				Response response = client.newCall(request).execute();	
				responseData = response.body().bytes();
				logger.info("reposene is success:" + response.isSuccessful());			
			
			} catch (Exception  e) {
				logger.error(e.getMessage(), e);
				responseData = null;
			}			
			return responseData;
		};
		try {
			return MockManager.submitBinary(newPostTask);
		} catch (InterruptedException | ExecutionException e) {
			logger.error(e.getMessage(), e);
			return null;
		}
	}
	
	public static void doIdentifyComplete(String url, byte[] mrJobResuts) {		
			OkHttpClient client = new OkHttpClient();
			client.setConnectTimeout(30, TimeUnit.SECONDS);
			client.setReadTimeout(30, TimeUnit.SECONDS);
			client.setWriteTimeout(30, TimeUnit.SECONDS);			
			Request request = new Request.Builder().url(url)
					.post(RequestBody.create(MEDIA_TYPE_PLAINTEXT, mrJobResuts)).build();
			try {
				Response response = client.newCall(request).execute();
				logger.info("IdentifyComplete is success:" + response.isSuccessful());			
			
			} catch (Exception  e) {
				logger.error(e.getMessage(), e);
			}		
	}
	
	public static void doMrHeatbeat() {
		PBComponentInfo info = ProtobufCreater.buildEnterReqeust(ComponentType.MAP_REDUCER, "http://127.0.0.1:8085", "http://127.0.0.1:8085");
	    String mmUrl = "http://127.0.0.1:8080/matchmanager//HeartBeat";
		Runnable task = () -> {
			OkHttpClient client = new OkHttpClient();
			client.setConnectTimeout(30, TimeUnit.SECONDS);
			client.setReadTimeout(30, TimeUnit.SECONDS);
			client.setWriteTimeout(30, TimeUnit.SECONDS);			
			Request request = new Request.Builder().url(mmUrl)
					.post(RequestBody.create(MEDIA_TYPE_PLAINTEXT, info.toByteArray())).build();
		
			try {
				Response response = client.newCall(request).execute();
				logger.info("reposen is success:" + response.isSuccessful());
				PBHeartBeatResponse hbRes = PBHeartBeatResponse.parseFrom(response.body().bytes());
				logger.info(hbRes.toString());
			
			} catch (Exception  e) {
				logger.error(e.getMessage(), e);
			}
		};		
		MockManager.scheduleMuheartbeat(task);	
	}
}
