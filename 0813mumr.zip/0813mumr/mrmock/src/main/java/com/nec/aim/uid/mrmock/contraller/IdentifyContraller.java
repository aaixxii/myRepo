package com.nec.aim.uid.mrmock.contraller;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.nec.aim.uid.mrmock.indentify.MrJobResultSender;

import jp.co.nec.aim.message.proto.AIMMessages.PBMapInquiryJobRequest;
import lombok.extern.slf4j.Slf4j;



@Controller
@Slf4j
public class IdentifyContraller extends HttpServlet {	
	
	private static final long serialVersionUID = -7548985888118460502L;

	@RequestMapping(value = "/MapInquiryJob", method = RequestMethod.POST)
	public void identity(HttpServletRequest req, HttpServletResponse res) {
		log.info("Received inquiry request from {}", req.getRemoteHost());			
		try {
			PBMapInquiryJobRequest pbMrReq = PBMapInquiryJobRequest.parseFrom(req.getInputStream());		
			
			MrJobResultSender mrJobSender = new MrJobResultSender(pbMrReq);
			Thread task = new Thread(mrJobSender);
			task.start();
			//MockManager.scheduleIdentifyResultSend(mrJobSender);
			res.setStatus(200);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			res.setStatus(500);
		}
		
	}

}
