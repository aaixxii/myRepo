package com.nec.aim.uid.mrmock.protobuf;

import java.io.IOException;

import com.nec.aim.uid.mrmock.constants.Configer;
import com.nec.aim.uid.mrmock.xml.UidaiResposeCreater;
import com.nec.aim.uid.mrmock.xml.XmlUtil;

import jp.co.nec.aim.message.proto.AIMEnumTypes.ComponentType;
import jp.co.nec.aim.message.proto.AIMEnumTypes.SegmentStateType;
import jp.co.nec.aim.message.proto.AIMEnumTypes.ServiceStateType;
import jp.co.nec.aim.message.proto.AIMMessages.PBAbilityInfo;
import jp.co.nec.aim.message.proto.AIMMessages.PBComponentInfo;
import jp.co.nec.aim.message.proto.AIMMessages.PBExitRequest;
import jp.co.nec.aim.message.proto.AIMMessages.PBInquiryJobInfoInternal;
import jp.co.nec.aim.message.proto.AIMMessages.PBInquiryJobInfoOutput;
import jp.co.nec.aim.message.proto.AIMMessages.PBLoadState;
import jp.co.nec.aim.message.proto.AIMMessages.PBMapInquiryJobRequest;
import jp.co.nec.aim.message.proto.AIMMessages.PBMapInquiryJobResult;
import jp.co.nec.aim.message.proto.AIMMessages.PBResourceInfo;
import jp.co.nec.aim.message.proto.AIMMessages.PBSegmentInfo;
import jp.co.nec.aim.message.proto.AIMMessages.PBServiceState;
import jp.co.nec.aim.message.proto.AIMMessages.PBServiceStateReason;

public class ProtobufCreater {
	
	public static PBComponentInfo buildEnterReqeust(ComponentType type, String uniqueId, String contactUrl) {	
		//uniqueId = IP;
		PBComponentInfo.Builder pBComponentInfo = PBComponentInfo.newBuilder();
		pBComponentInfo.setComponent(type);
		pBComponentInfo.setUniqueId(uniqueId);
		pBComponentInfo.setContactUrl(contactUrl);
		pBComponentInfo.setVersion("1");
		
		PBResourceInfo.Builder pBResourceInfo = PBResourceInfo.newBuilder();
		PBAbilityInfo.Builder pBAbilityInfo = PBAbilityInfo.newBuilder();
		pBAbilityInfo.setPrimarySize(100000);
		pBAbilityInfo.setSecondarySize(100000);
		pBAbilityInfo.setNumOfExtractors(8);
		pBAbilityInfo.setNumOfMatchers(8);
		pBAbilityInfo.setPerformanceFactor(1);
		pBResourceInfo.setAbilityInfo(pBAbilityInfo.build());
		
		PBSegmentInfo.Builder pBSegmentInfo = PBSegmentInfo.newBuilder();
		pBSegmentInfo.setId(3);
		pBSegmentInfo.setVersion(-1);
		pBSegmentInfo.setQueuedVersion(-1);
		pBSegmentInfo.setState(SegmentStateType.SEGMENT_STATE_NONE);
		pBResourceInfo.addSegmentInfo(pBSegmentInfo.build());
		pBResourceInfo.setSegmentMapChanged(false);
		pBComponentInfo.setResourceInfo(pBResourceInfo.build());
		return pBComponentInfo.build();		
	}
	
	public static PBLoadState buildPBLoadState(ComponentType type, long muId, int matchLoad) {
		PBLoadState.Builder pBLoadState = PBLoadState.newBuilder();
		pBLoadState.setComponent(type);
		pBLoadState.setId(muId);
		pBLoadState.setMatchingLoad(matchLoad);		
		return pBLoadState.build();	
	}
	
	public static PBExitRequest buildPBExitRequest(ComponentType type) {
		PBExitRequest.Builder pbExit = PBExitRequest.newBuilder();
		pbExit.setComponent(type);
		pbExit.setId(3);
		return  pbExit.build();		
	}
	
	public static PBMapInquiryJobResult buildPBMapInquiryJobResult(long mrId, long planId, long topId, String reqId, String refId, String url) throws IOException {
		PBMapInquiryJobResult.Builder pBMapInquiryJobResult = PBMapInquiryJobResult.newBuilder();
		pBMapInquiryJobResult.setMrId(mrId);
		pBMapInquiryJobResult.setPlanId(planId);
		for (int i = 0; i < 10; i++) {
			PBInquiryJobInfoInternal.Builder pBInquiryJobInfoInternal = PBInquiryJobInfoInternal.newBuilder();
			pBInquiryJobInfoInternal.setTopLevelJobId(topId);
			pBInquiryJobInfoInternal.setRequestIndex(1);
			pBInquiryJobInfoInternal.setContainerId(1);
			pBInquiryJobInfoInternal.setMessageSequence(0);
			pBInquiryJobInfoInternal.setJobTimeout(5000);
			PBInquiryJobInfoOutput.Builder pBInquiryJobInfoOutput = PBInquiryJobInfoOutput.newBuilder();
			PBServiceState.Builder pBServiceState = PBServiceState.newBuilder();
			pBServiceState.setState(ServiceStateType.SERVICE_STATE_SUCCESS);
			PBServiceStateReason.Builder pBServiceStateReason = PBServiceStateReason.newBuilder();
			pBServiceStateReason.setCode("1");
			pBServiceStateReason.setDescription("ok");
			pBServiceStateReason.setTime("new");
			pBServiceState.setReason(pBServiceStateReason);
			pBInquiryJobInfoOutput.setJobState(pBServiceState.build());
			String xmlRes = UidaiResposeCreater.buildSuccessInquiryRespose(reqId, refId, url);
			pBInquiryJobInfoOutput.setResponse(xmlRes);	
			pBInquiryJobInfoInternal.setOut(pBInquiryJobInfoOutput);
			pBMapInquiryJobResult.addJobInfo(pBInquiryJobInfoInternal.build());
		}	
		return pBMapInquiryJobResult.build();		
	}
	
	public static PBMapInquiryJobResult buildPBMapInquiryJobResult(PBMapInquiryJobRequest mrReq)  {		
		PBMapInquiryJobResult.Builder pBMapInquiryJobResult = PBMapInquiryJobResult.newBuilder();
		pBMapInquiryJobResult.setMrId(Configer.getMrId());
		pBMapInquiryJobResult.setPlanId(mrReq.getPlanId());
	//	mrReq.getJobInfoList().forEach(one -> {
			for (int i = 0; i < mrReq.getJobInfoCount(); i++) {
				PBInquiryJobInfoInternal one = mrReq.getJobInfoList().get(i);
			String xmlReq = one.getIn().getRequest();
			String cmd = XmlUtil.getXmlCmd(xmlReq);
			String reqId = XmlUtil.getRequestId(xmlReq);
			String refId = XmlUtil.getRefId(xmlReq, cmd);
			String url = XmlUtil.getUrl(xmlReq, cmd);
			PBInquiryJobInfoInternal.Builder pBInquiryJobInfoInternal = PBInquiryJobInfoInternal.newBuilder();
			pBInquiryJobInfoInternal.setTopLevelJobId(one.getTopLevelJobId());
			pBInquiryJobInfoInternal.setRequestIndex(one.getRequestIndex());
			pBInquiryJobInfoInternal.setContainerId(one.getContainerId());
			pBInquiryJobInfoInternal.setMessageSequence(one.getMessageSequence());
			pBInquiryJobInfoInternal.setJobTimeout(5000);
			PBInquiryJobInfoOutput.Builder pBInquiryJobInfoOutput = PBInquiryJobInfoOutput.newBuilder();
			PBServiceState.Builder pBServiceState = PBServiceState.newBuilder();
			pBServiceState.setState(ServiceStateType.SERVICE_STATE_SUCCESS);
			PBServiceStateReason.Builder pBServiceStateReason = PBServiceStateReason.newBuilder();
			pBServiceStateReason.setCode("1");
			pBServiceStateReason.setDescription("ok");
			pBServiceStateReason.setTime(String.valueOf(System.currentTimeMillis()));
			pBServiceState.setReason(pBServiceStateReason);
			pBInquiryJobInfoOutput.setJobState(pBServiceState.build());
			String xmlRes = null;
			try {
				xmlRes = UidaiResposeCreater.buildSuccessInquiryRespose(reqId, refId, url);
			} catch (IOException e) {				
				e.printStackTrace();
			}
			pBInquiryJobInfoOutput.setResponse(xmlRes);	
			pBInquiryJobInfoInternal.setOut(pBInquiryJobInfoOutput);
			pBMapInquiryJobResult.addJobInfo(pBInquiryJobInfoInternal.build());			
		};
			
		return pBMapInquiryJobResult.build();		
	}
	
	public static PBMapInquiryJobResult buildPBMapInquiryJobFaildResult(PBMapInquiryJobRequest mrReq)  {		
		PBMapInquiryJobResult.Builder pBMapInquiryJobResult = PBMapInquiryJobResult.newBuilder();
		pBMapInquiryJobResult.setMrId(Configer.getMrId());
		pBMapInquiryJobResult.setPlanId(mrReq.getPlanId());
	//	mrReq.getJobInfoList().forEach(one -> {
			for (int i = 0; i < mrReq.getJobInfoCount(); i++) {
				PBInquiryJobInfoInternal one = mrReq.getJobInfoList().get(i);
			String xmlReq = one.getIn().getRequest();
			String cmd = XmlUtil.getXmlCmd(xmlReq);
			String reqId = XmlUtil.getRequestId(xmlReq);
			String refId = XmlUtil.getRefId(xmlReq, cmd);
			String url = XmlUtil.getUrl(xmlReq, cmd);
			PBInquiryJobInfoInternal.Builder pBInquiryJobInfoInternal = PBInquiryJobInfoInternal.newBuilder();
			pBInquiryJobInfoInternal.setTopLevelJobId(one.getTopLevelJobId());
			pBInquiryJobInfoInternal.setRequestIndex(one.getRequestIndex());
			pBInquiryJobInfoInternal.setContainerId(one.getContainerId());
			pBInquiryJobInfoInternal.setMessageSequence(one.getMessageSequence());
			pBInquiryJobInfoInternal.setJobTimeout(5000);
			PBInquiryJobInfoOutput.Builder pBInquiryJobInfoOutput = PBInquiryJobInfoOutput.newBuilder();
			PBServiceState.Builder pBServiceState = PBServiceState.newBuilder();
			pBServiceState.setState(ServiceStateType.SERVICE_STATE_ERROR);
			PBServiceStateReason.Builder pBServiceStateReason = PBServiceStateReason.newBuilder();
			pBServiceStateReason.setCode("2");
			pBServiceStateReason.setDescription("mu faild");
			pBServiceStateReason.setTime(String.valueOf(System.currentTimeMillis()));
			pBServiceState.setReason(pBServiceStateReason);
			pBInquiryJobInfoOutput.setJobState(pBServiceState.build());
			String xmlRes = null;
			try {
				xmlRes = UidaiResposeCreater.buildSuccessInquiryRespose(reqId, refId, url);
			} catch (IOException e) {				
				e.printStackTrace();
			}
			pBInquiryJobInfoOutput.setResponse(xmlRes);	
			pBInquiryJobInfoInternal.setOut(pBInquiryJobInfoOutput);
			pBMapInquiryJobResult.addJobInfo(pBInquiryJobInfoInternal.build());			
		};
			
		return pBMapInquiryJobResult.build();		
	}
	
	public static PBMapInquiryJobResult buildPBMapInquiryJobRollbackResult(PBMapInquiryJobRequest mrReq)  {		
		PBMapInquiryJobResult.Builder pBMapInquiryJobResult = PBMapInquiryJobResult.newBuilder();
		pBMapInquiryJobResult.setMrId(Configer.getMrId());
		pBMapInquiryJobResult.setPlanId(mrReq.getPlanId());
	//	mrReq.getJobInfoList().forEach(one -> {
			for (int i = 0; i < mrReq.getJobInfoCount(); i++) {
				PBInquiryJobInfoInternal one = mrReq.getJobInfoList().get(i);
			String xmlReq = one.getIn().getRequest();
			String cmd = XmlUtil.getXmlCmd(xmlReq);
			String reqId = XmlUtil.getRequestId(xmlReq);
			String refId = XmlUtil.getRefId(xmlReq, cmd);
			String url = XmlUtil.getUrl(xmlReq, cmd);
			PBInquiryJobInfoInternal.Builder pBInquiryJobInfoInternal = PBInquiryJobInfoInternal.newBuilder();
			pBInquiryJobInfoInternal.setTopLevelJobId(one.getTopLevelJobId());
			pBInquiryJobInfoInternal.setRequestIndex(one.getRequestIndex());
			pBInquiryJobInfoInternal.setContainerId(one.getContainerId());
			pBInquiryJobInfoInternal.setMessageSequence(one.getMessageSequence());
			pBInquiryJobInfoInternal.setJobTimeout(5000);
			PBInquiryJobInfoOutput.Builder pBInquiryJobInfoOutput = PBInquiryJobInfoOutput.newBuilder();
			PBServiceState.Builder pBServiceState = PBServiceState.newBuilder();
			pBServiceState.setState(ServiceStateType.SERVICE_STATE_ROLLBACK);
			PBServiceStateReason.Builder pBServiceStateReason = PBServiceStateReason.newBuilder();
			pBServiceStateReason.setCode("2");
			pBServiceStateReason.setDescription("rollback");
			pBServiceStateReason.setTime(String.valueOf(System.currentTimeMillis()));
			pBServiceState.setReason(pBServiceStateReason);
			pBInquiryJobInfoOutput.setJobState(pBServiceState.build());
			String xmlRes = null;
			try {
				xmlRes = UidaiResposeCreater.buildSuccessInquiryRespose(reqId, refId, url);
			} catch (IOException e) {				
				e.printStackTrace();
			}
			pBInquiryJobInfoOutput.setResponse(xmlRes);	
			pBInquiryJobInfoInternal.setOut(pBInquiryJobInfoOutput);
			pBMapInquiryJobResult.addJobInfo(pBInquiryJobInfoInternal.build());			
		};
			
		return pBMapInquiryJobResult.build();		
	}

	


}
