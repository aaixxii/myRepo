package com.nec.aim.uid.mrmock;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.google.protobuf.InvalidProtocolBufferException;
import com.nec.aim.uid.mrmock.indentify.EnterPoster;
import com.nec.aim.uid.mrmock.post.HttpPoster;

@SpringBootApplication
public class MockApplication {	
	

	public static void main(String[] args) throws InvalidProtocolBufferException {
		SpringApplication.run(MockApplication.class, args);
		 EnterPoster enter = new  EnterPoster();
		 enter.entertoMM();		 
		//HttpPoster.doMrHeatbeat();
			
		//ExitPoster exPost = new ExitPoster();
		//exPost.exitToMM();		
	}	

}
