package com.nec.aim.uid.mrmock.constants;

public class Configer {
	
	public static long mRId = 10002l;
	public static String mRIpPort = "127.0.0.1:8085";
	public static long getMrId() {
		return mRId;
	}
	public static void setMrId(long mrId) {
		Configer.mRId = mrId;
	}
	public static String getmRIpPort() {
		return mRIpPort;
	}
	public static void setmRIpPort(String mRIpPort) {
		Configer.mRIpPort = mRIpPort;
	}	
	
}
