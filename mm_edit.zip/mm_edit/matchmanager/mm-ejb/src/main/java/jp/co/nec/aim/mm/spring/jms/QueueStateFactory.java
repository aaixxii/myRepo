package jp.co.nec.aim.mm.spring.jms;

import java.lang.management.ManagementFactory;

import javax.management.Attribute;
import javax.management.AttributeList;
import javax.management.MBeanServer;
import javax.management.ObjectName;

/**
 * QueueStateFactory get stae of Queue mageged by MBean.<br/>
 * refer to below url.<br/>
 * http://xebee.xebia.in/2009/11/26/accessing-jboss-managed-resources-using-
 * mbeans/
 * 
 * @author kurosu
 * 
 */
public class QueueStateFactory {

	public QueueStateFactory() {
	}

	/**
	 * Returns QueueState object of errorQueue
	 * 
	 * @return
	 */
//	public QueueState getErrorQueueState() {
//		return createQueueState("org.hornetq:module=JMS,name=\"errorQueue\",type=Queue");
//	}

	/**
	 * Returns QueueState object of infoQueue
	 * 
	 * @return
	 */
//	public QueueState getInfoQueueState() {
//		return createQueueState("org.hornetq:module=JMS,name=\"infoQueue\",type=Queue");
//	}

	private QueueState createQueueState(String name) {
		QueueState state = new QueueState();
		try {
			ObjectName target = new ObjectName(name);
			MBeanServer mBeanServer = ManagementFactory
					.getPlatformMBeanServer();
			AttributeList attributes = mBeanServer.getAttributes(target,
					new String[] { "MessageCount", "MaxSize" });
			for (Object obj : attributes) {
				Attribute attribute = (Attribute) obj;
				if ("MessageCount".equals(attribute.getName())) {
					state.setMessageCount(((Integer) attribute.getValue())
							.intValue());
				} else if ("MaxSize".equals(attribute.getName())) {
					state.setMaxSize(((Integer) attribute.getValue())
							.intValue());
				}
			}
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		return state;
	}

}
