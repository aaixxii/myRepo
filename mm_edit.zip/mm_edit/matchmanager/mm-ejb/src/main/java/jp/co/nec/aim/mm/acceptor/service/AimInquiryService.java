package jp.co.nec.aim.mm.acceptor.service;

import static jp.co.nec.aim.mm.constants.MMConfigProperty.INTERVAL_CLIENT_SYNC_RESPONSE_TIMEOUT;

import java.io.IOException;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Lists;

import jp.co.nec.aim.message.proto.AIMMessages.PBMuExtractJobResultItem;
import jp.co.nec.aim.mm.acceptor.AimInquiryRequest;
import jp.co.nec.aim.mm.acceptor.CommonOptions;
import jp.co.nec.aim.mm.acceptor.Inquiry;
import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.constants.UidRequestType;
import jp.co.nec.aim.mm.dao.DateDao;
import jp.co.nec.aim.mm.dao.FEJobDao;
import jp.co.nec.aim.mm.dao.FunctionDao;
import jp.co.nec.aim.mm.dao.InquiryJobDao;
import jp.co.nec.aim.mm.dao.MatchManagerDao;
import jp.co.nec.aim.mm.dao.PersonBiometricDao;
import jp.co.nec.aim.mm.dao.SystemConfigDao;
import jp.co.nec.aim.mm.entities.FeJobQueueEntity;
import jp.co.nec.aim.mm.entities.FunctionTypeEntity;
import jp.co.nec.aim.mm.entities.PersonBiometricEntity;
import jp.co.nec.aim.mm.exception.AimIdnetifyException;
import jp.co.nec.aim.mm.exception.DataBaseException;
import jp.co.nec.aim.mm.exception.ExceptionHelper;
import jp.co.nec.aim.mm.exception.UidTimeoutException;
import jp.co.nec.aim.mm.hazelcast.HazelcastService;
import jp.co.nec.aim.mm.jms.JmsSender;
import jp.co.nec.aim.mm.jms.NotifierEnum;
import jp.co.nec.aim.mm.procedure.FeJobProcedures;
import jp.co.nec.aim.mm.sessionbeans.DmServiceBean;
import jp.co.nec.aim.mm.sessionbeans.pojo.AimManager;
import jp.co.nec.aim.mm.util.XmlUtil;
import jp.co.nec.aim.mm.validator.AcceptorValidator;

/**
 * The main work flow of inquiry <br>
 * 
 * Include following public method:
 * <p>
 * inquiry, getJobStatus, listJobIds, deleteJob clearJobs, getJobResult,
 * getJobResult
 * <p>
 * 
 * @author xiazp
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class AimInquiryService {
	/** log instance **/
	private static Logger log = LoggerFactory.getLogger(AimInquiryService.class);

	@PersistenceContext(unitName = "aim-db")
	private EntityManager manager;

	@Resource(mappedName = "java:jboss/MySqlDS")
	private DataSource dataSource;
	@EJB
	DmServiceBean dmServiceBean;
	
	@EJB
	private Inquiry inquiry;
	private InquiryJobDao inquiryJobDao;
	private DateDao dateDao;
	private FEJobDao feJobDao;
	private FunctionDao functionDao;
	private SystemConfigDao sysConfigDao;
	private MatchManagerDao mmDao;
	private FeJobProcedures feJobProcedures;
	private PersonBiometricDao personBiometricDao;	
	private ExceptionHelper exception;

	/**
	 * AimInquiryService default constructor
	 */
	public AimInquiryService() {
	}

	@PostConstruct
	private void init() {
		this.inquiryJobDao = new InquiryJobDao(manager, dataSource);
		this.dateDao = new DateDao(dataSource);
		this.feJobDao = new FEJobDao(manager, dataSource);
		this.functionDao = new FunctionDao(manager);
		this.sysConfigDao = new SystemConfigDao(manager);
		this.mmDao = new MatchManagerDao(manager);
		this.feJobProcedures = new FeJobProcedures(dataSource);
		this.personBiometricDao = new PersonBiometricDao(manager);
		this.exception = new ExceptionHelper(dateDao);
	}

	/**
	 * The main work flow of inquiry
	 * 
	 * @param request
	 *            PBInquiryJobRequest instance
	 * @param isFromServlet
	 *            IS called by SERVLET
	 * @return PBInquiryJobResponse instance
	 * @throws IOException
	 */
	public Long inquiry(final String inqRequest, boolean isFromServlet) {
		if (log.isDebugEnabled()) {
			log.debug(inqRequest);
		}
		String requestId = XmlUtil.getRequestId(inqRequest);
		String cmd = XmlUtil.getXmlCmd(inqRequest);
		String refId = XmlUtil.getRefId(inqRequest, UidRequestType.Identify.name());
		String refUrl = XmlUtil.getUrl(inqRequest, UidRequestType.Identify.name());
		String maxResults = XmlUtil.getIdentifyAtribute(inqRequest, "maxResults");
		AcceptorValidator.checkInquiryRequest(inqRequest, requestId, cmd, refId, refUrl, maxResults);
		Long jobId = null;
		final CommonOptions options = new CommonOptions();
		options.setFromServlet(isFromServlet);
		options.setFunctioName("MI");
		options.setMaxCandidates(Integer.valueOf(maxResults));
		AimInquiryRequest aimInquiryRequest = null;
		byte[] templateData = null;
		if (!StringUtils.isBlank(refId)) {
			templateData = tryGetTemplateFromFeQueue(refId);
			if (templateData == null) {
				PersonBiometricEntity psEntity = personBiometricDao.isHaveBioMetricDataInMyTable(refId);
				if (psEntity != null) {
					try {
						templateData = dmServiceBean.getTemplate(refId);
					} catch (Exception e) {
						AimError aimErr = AimError.INQ_JOB_DM_SERVICE_ERR;
						throw new AimIdnetifyException(aimErr.getMessage(), aimErr.getErrorCode(),
								String.valueOf(System.currentTimeMillis()), aimErr.getUidCode());
					}
				}
			}
			if (templateData != null && templateData.length > 1) {
				aimInquiryRequest = new AimInquiryRequest("MI", Integer.valueOf(1), requestId, inqRequest,
						templateData);
				jobId = doGetIdentifyResponse(aimInquiryRequest, options);
				return jobId;
			}
		}
		if (templateData == null && !StringUtils.isBlank(refId) && !StringUtils.isBlank(refUrl)) {
			FunctionTypeEntity fte = functionDao.getExtractFunction();
			if (fte == null) {
				AimError dbErr = AimError.SYNC_FUNCTIONTYPE;			
				throw new DataBaseException(dbErr.getErrorCode(), dbErr.getMessage(), String.valueOf(System.currentTimeMillis()), dbErr.getUidCode());
			}
			Long newFeJobId = null;
			try {
				newFeJobId = feJobProcedures.createNewFeJob(refId, requestId, UidRequestType.Identify.name(), inqRequest);
			} catch (Exception e1) {
				feJobDao.deleteExtractJob(newFeJobId);			
				AimError dbErr = AimError.SYNC_DB;
				throw new DataBaseException(dbErr.getErrorCode(), dbErr.getMessage(), String.valueOf(System.currentTimeMillis()), dbErr.getUidCode());
			}

			JmsSender.getInstance().sendToFEJobPlanner(NotifierEnum.ExtractService,
					String.format("create extract job id: %s", newFeJobId));
			String myUrl = mmDao.getMyIpAndPort();
			RemoteJobItem inqJobItem = new RemoteJobItem();
			//inqJobItem.setInqJobId(jobQueueEntity.getJobId());
			inqJobItem.setFeJobId(newFeJobId);
			inqJobItem.setRequestId(requestId);
			inqJobItem.setRefId(refId);
			inqJobItem.setMmUrl(myUrl);
			inqJobItem.setUidRequestType(UidRequestType.Identify);
			inqJobItem.setRequst(inqRequest);
			inqJobItem.setIsFromServlet(isFromServlet);
			inqJobItem.setMaxResults(maxResults);
			HazelcastService.getInstance().saveRemoteJobInfo(newFeJobId, inqJobItem);			
			
			Integer syncJobWaitTime = sysConfigDao.getMMPropertyInt(INTERVAL_CLIENT_SYNC_RESPONSE_TIMEOUT);
			if (Objects.isNull(syncJobWaitTime) || syncJobWaitTime < 0) {
				syncJobWaitTime = 100000;
			}
			String key = String.valueOf(newFeJobId.longValue());
			Object extractJoblocker = new Object();
			AimManager.saveToExtractLockQueue(key, extractJoblocker);
			Optional<PBMuExtractJobResultItem> onejobResult = null;
			synchronized (extractJoblocker) {
				long startGetExtResultTime = System.currentTimeMillis();
				try {
					extractJoblocker.wait(syncJobWaitTime);
				} catch (InterruptedException e) {
					log.error(e.getMessage(), e);
					Thread.currentThread().interrupt();
				}
				try {
					onejobResult = Optional.ofNullable(AimManager.getExtractJobResult(key));
				} catch (NullPointerException e) {
					log.warn("can't get extractResponse, it may be timeout.");
					AimError aimErr = AimError.INQ_INTERNAL;
					String errMsg = String.format(e.getMessage() + "inquiry exract internal error.");
					aimErr.setMessage(errMsg);
					throw new UidTimeoutException(aimErr.getErrorCode(), aimErr.getMessage(),
							String.valueOf(System.currentTimeMillis()), aimErr.getUidCode());
				}
				if (onejobResult.isPresent()) {
					log.info("Get insert by url jobId({}) result success", newFeJobId);
					long endGetResultTime = System.currentTimeMillis();
					log.info("*****MM get insert by url job results used time = {}****",
							endGetResultTime - startGetExtResultTime);
				} else {
					log.warn("Got empty PBMuExtractJobResultItem, key={}", key);
					long currentTime = System.currentTimeMillis();
					if (currentTime - startGetExtResultTime >= syncJobWaitTime) {
						log.warn("Timeout is happend! the waiting time = ({}), jobId({})",
								currentTime - startGetExtResultTime, newFeJobId.longValue());
						AimError timeoutErr = AimError.JOB_TIMEOUT;
						String errMsg = String.format(timeoutErr.getMessage() +  " .sync insert by url job timeout.");
						timeoutErr.setMessage(errMsg);
						throw new UidTimeoutException(timeoutErr.getErrorCode(), timeoutErr.getMessage(),
								String.valueOf(System.currentTimeMillis()), timeoutErr.getUidCode());
					}
				}
			}
			AimManager.finishExtractJob(key);
			templateData = onejobResult.get().getBisonTemplate().toByteArray();
			aimInquiryRequest = new AimInquiryRequest("MI", Integer.valueOf(1), requestId, inqRequest,
					templateData);
			jobId = doGetIdentifyResponse(aimInquiryRequest, options);
		}
		return jobId;
	}

	private byte[] tryGetTemplateFromFeQueue(String refId) {
		byte[] data = null;
		List<FeJobQueueEntity> resultList = feJobDao.getExResult(refId);
		if (resultList != null && resultList.size() > 0) {
			data = resultList.get(0).getTempalteData();
		}
		return data;
	}

	private Long doGetIdentifyResponse(final AimInquiryRequest aimInquiryRequest, final CommonOptions options) {
		String requestId = aimInquiryRequest.getRequestId();
		final List<AimInquiryRequest> aimRequestList = Lists.newArrayList();
		aimRequestList.add(aimInquiryRequest);
		long jobId = inquiry.inquiry(aimRequestList, requestId, options);
		return Long.valueOf(jobId);
	}

	
	@SuppressWarnings("unused")
	private byte[] doExtract(String inqRequest, String refId, String requestId, String url) {

		FunctionTypeEntity fte = functionDao.getExtractFunction();
		if (fte == null) {
			return null;
		}
		Long newFeJobId = null;
		try {
			newFeJobId = feJobProcedures.createNewFeJob(refId, requestId, UidRequestType.Identify.name(), inqRequest);
			log.info("succss create feJob({})", newFeJobId);
		} catch (Exception e1) {
			feJobDao.deleteExtractJob(newFeJobId);
			return null;
		}

		Integer syncJobWaitTime = sysConfigDao.getMMPropertyInt(INTERVAL_CLIENT_SYNC_RESPONSE_TIMEOUT);
		if (Objects.isNull(syncJobWaitTime) || syncJobWaitTime < 0) {
			syncJobWaitTime = 100000;
		}
		String key = String.valueOf(newFeJobId.longValue());
		Long extractJoblocker = Long.valueOf(key);
		HazelcastService.getInstance().saveToExtractLockQueue(key, extractJoblocker);
		Thread.currentThread().setPriority(Thread.MAX_PRIORITY);
		Optional<PBMuExtractJobResultItem> onejobResult = null;
		synchronized (extractJoblocker) {
			long startGetExtResultTime = System.currentTimeMillis();
			try {
				extractJoblocker.wait(syncJobWaitTime);
			} catch (InterruptedException e) {
				log.error(e.getMessage(), e);
				Thread.currentThread().interrupt();
			}
			try {
				onejobResult = Optional.ofNullable(HazelcastService.getInstance().getExtractJobResult(key));
			} catch (NullPointerException e) {
				log.warn("can't get extractResponse, it may be timeout.");
				return null;
			}
			if (onejobResult.isPresent()) {
				log.info("Get inquiry by url jobId({}) result success", newFeJobId);
				long endGetResultTime = System.currentTimeMillis();
				log.info("*****MM get identify by url job results used time = {}****",
						endGetResultTime - startGetExtResultTime);
			} else {
				log.warn("Got empty PBMuExtractJobResultItem, key={}", key);
				long currentTime = System.currentTimeMillis();
				if (currentTime - startGetExtResultTime >= syncJobWaitTime) {
					log.warn("Timeout is happend! the waiting time = ({}), jobId({})",
							currentTime - startGetExtResultTime, newFeJobId);
					return null;
				}
			}
		}
		byte[] extResult = onejobResult.get().getBisonTemplate().toByteArray();
		HazelcastService.getInstance().finishExtractJob(key);
		return extResult;
	}

	/**
	 * delete the inquiry Job with specified job id
	 * 
	 * @param request
	 *            PBDeleteJobRequest instance
	 */
	public void deleteJob(String deleRequest) {
		String requestId = XmlUtil.getRequestId(deleRequest);
		try {
			inquiryJobDao.deleteJobByRequstId(requestId);
		} catch (Exception ex) {
			exception.throwDBException(AimError.INQ_DB, ex,
					String.format("Exception occurred when when delete " + "inquiry job by requestId %s", requestId));
		}
	}

	/**
	 * clear all inquiry Jobs
	 */
	public void clearJobs() {
		try {
			inquiryJobDao.clearJobs();
		} catch (Exception ex) {
			exception.throwDBException(AimError.INQ_DB, ex, "Exception occurred when clear inquiry job.");
		}
	}
}
