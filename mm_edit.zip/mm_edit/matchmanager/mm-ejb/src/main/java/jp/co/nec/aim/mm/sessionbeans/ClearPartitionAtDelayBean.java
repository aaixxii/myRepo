package jp.co.nec.aim.mm.sessionbeans;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.aim.mm.dao.PartitionDao;
import jp.co.nec.aim.mm.partition.PartitionUtil;

@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class ClearPartitionAtDelayBean {
    
    private static final Logger logger = LoggerFactory.getLogger(ClearPartitionAtDelayBean.class);
    
    @Resource(mappedName = "java:jboss/MySqlDS")
	private DataSource dataSource;

	@PersistenceContext(unitName = "aim-db")
	private EntityManager manager;
	
	private PartitionDao partitionDao;	
	
	public ClearPartitionAtDelayBean() {
	}
	
	@PostConstruct
	public void init() {
		partitionDao = new PartitionDao(dataSource);		
	}
	
	public void execute(List<LocalDate> targetDays)  {
		PartitionUtil partitionUtil = PartitionUtil.getInstance();
		List<Long> pNoList = targetDays.stream().map(one -> partitionUtil.caculateHashAtThisToday(one)).collect(Collectors.toList());
		partitionDao.deletePartitions(pNoList);	
		logger.info("Delete partition size= ", pNoList.size());
	}
}
