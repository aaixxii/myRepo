package jp.co.nec.aim.mm.extract.dispatch;

public enum MessageType {
	ERROR, INFO, WARN
}
