package jp.co.nec.aim.mm.procedure;

import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import jp.co.nec.aim.mm.logger.PerformanceLogger;
import jp.co.nec.aim.mm.sessionbeans.pojo.AimServiceState;
import jp.co.nec.aim.mm.util.StopWatch;

public class FailExtractJobProcedure extends StoredProcedure {

	private static final String SQL = "fail_extract_job";

	public FailExtractJobProcedure(DataSource dataSource) {
		setDataSource(dataSource);
		setSql(SQL);
		//setFunction(true);		
		declareParameter(new SqlParameter("p_extract_job_id", Types.BIGINT));
		declareParameter(new SqlParameter("p_mu_id", Types.BIGINT));
		declareParameter(new SqlParameter("p_result", Types.VARCHAR));
		declareParameter(new SqlParameter("p_reason", Types.VARCHAR));
		declareParameter(new SqlParameter("p_code", Types.VARCHAR));
		declareParameter(new SqlParameter("p_time", Types.VARCHAR));
		declareParameter(new SqlOutParameter("l_count", Types.INTEGER));
		compile();
	}

	public int execute(long extractJobId, long muId,
			AimServiceState reason, String result) {
		if (muId < 1L) {
			throw new IllegalArgumentException("muId is less than 1");
		}
		if (extractJobId < 1L) {
			throw new IllegalArgumentException("extractJobId is less than 1");
		}
		if (result == null) {
			throw new IllegalArgumentException("results is null");
		}
		if (reason == null) {
			throw new IllegalArgumentException("reason is null");
		}

		if (StringUtils.isBlank(reason.getErrorcode())) {
			throw new IllegalArgumentException("reason code is Blank or null");
		}

		if (StringUtils.isBlank(reason.getFailureTime())) {
			throw new IllegalArgumentException("reason time is Blank or null");
		}

		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		reason.getErrorcode();

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("p_extract_job_id", new Long(extractJobId));
		map.put("p_mu_id", new Long(muId));
		map.put("p_result", result);
		map.put("p_reason", "aim uid error");		
		map.put("p_code", reason.getErrorcode());
		map.put("p_time", reason.getFailureTime());
		Map<String, Object> resultMap = execute(map);
		int count = ((Integer) resultMap.get("l_count")).intValue();

		stopWatch.stop();
		PerformanceLogger.log(getClass().getSimpleName(), "execute",
				stopWatch.elapsedTime());

		return count;
	}
}
