package jp.co.nec.aim.mm.constants;
import java.io.File;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.configuration.reloading.FileChangedReloadingStrategy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AmqReloadAbleProperties {
	private static Logger logger = LoggerFactory.getLogger(AmqReloadAbleProperties.class);
	private static final String PROPERTIES_FILE = "aim.mq.properties";
	private static final AmqReloadAbleProperties instance = new AmqReloadAbleProperties();	
	private static PropertiesConfiguration propsConfig;
	private static boolean mustLoad = true;
	
	public AmqReloadAbleProperties() {	
		loadAmqConfig();
		mustLoad = false;
	}

	public static AmqReloadAbleProperties getInstance() {
		if (instance == null || !mustLoad) {
			loadAmqConfig();
			mustLoad = false;
		}
		return instance;
	}

	public static void loadAmqConfig()  {
//		URL url = Thread.currentThread().getContextClassLoader().getResource(PROPERTIES_FILE);
//		String path = url.getPath();
  	    String path = System.getProperty("jboss.server.config.dir") + PROPERTIES_FILE;	
		
		File file = new File(path);	
		String configFilePath = file.getPath();
		propsConfig = new PropertiesConfiguration();
		propsConfig.setEncoding("UTF-8");
		try {
			propsConfig.load(configFilePath);
		} catch (ConfigurationException e) {
			logger.warn("Can't load aim.mq.properties file!");
		}		
		propsConfig.setAutoSave(true);		
		propsConfig.setReloadingStrategy(new FileChangedReloadingStrategy());
	}	

	public String getPropertyValue(String name) {
		return  propsConfig.getString(name);
	}

	/**
	 * return boolean value.
	 * 
	 * If key is not found in the property, this method return false.
	 * 
	 * @param name
	 * @return
	 */
	public boolean isPropertyValue(String name) {
		String value = getPropertyValue(name);
		return Boolean.valueOf(value);
	}
}
