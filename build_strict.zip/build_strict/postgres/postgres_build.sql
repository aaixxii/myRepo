\i env.cfg
\i create.dbs
\i create_tablespaces.sql

