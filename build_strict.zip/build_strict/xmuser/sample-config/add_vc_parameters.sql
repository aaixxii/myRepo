-- Ignore if scope record already exists 

Insert into "BIO_PARAMETERS"
   ("NAME", "SCOPE", "VALUE", "DESCRIPTION", "CREATE_DATETIME", "CREATEBY")   
 Values
   ('VERIFY_NODE_PROTOCOL_TYPE', 'DEFAULT', 'ZEROMQ', 'Protocol used between VC and VN. ZEROMQ or TCP', CURRENT_TIMESTAMP, 'ADMIN');
Insert into "BIO_PARAMETERS"
   ("NAME", "SCOPE", "VALUE", "DESCRIPTION", "CREATE_DATETIME", "CREATEBY")  
 Values
   ('MAX_VERIFY_JOB_TIMEOUT_MILLI', 'DEFAULT', '2000', 'Max verify job timeout in milliseconds', CURRENT_TIMESTAMP, 'ADMIN');
Insert into "BIO_PARAMETERS"
   ("NAME", "SCOPE", "VALUE", "DESCRIPTION", "CREATE_DATETIME", "CREATEBY")  
 Values
   ('VERIFY_NODE_STATUS_CHECK_DELAY_SECONDS', 'DEFAULT', '30', 'VN Status check delay in milliseconds', CURRENT_TIMESTAMP, 'ADMIN');
Insert into "BIO_PARAMETERS"
   ("NAME", "SCOPE", "VALUE", "DESCRIPTION", "CREATE_DATETIME", "CREATEBY")  
 Values
   ('VERIFY_NODE_OFFLINE_TIMEOUT_FACTOR', 'DEFAULT', '70.0', 'VN Offline timeout factor of MAX_VERIFY_JOB_TIMEOUT_MILLI', CURRENT_TIMESTAMP, 'ADMIN');


Insert into "BIO_PARAMETERS"
   ("NAME", "SCOPE", "VALUE", "DESCRIPTION", "CREATE_DATETIME", "CREATEBY")  
 Values
   ('VERIFICATION_CONTROLLER_CLUSTER_MODE_FLAG', 'DEFAULT', 'true', 'VC mode flag. true for cluster mode, false for standalone.', CURRENT_TIMESTAMP, 'ADMIN');

Insert into "BIO_PARAMETERS"
   ("NAME", "SCOPE", "VALUE", "DESCRIPTION", "CREATE_DATETIME", "CREATEBY")  
 Values
   ('MAX_VERIFY_JOB_RETRY_COUNT', 'DEFAULT', '3', 'Verify job retry count', CURRENT_TIMESTAMP, 'ADMIN');

   

