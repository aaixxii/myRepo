
/* Server Settings- Modify SERVER_ID, SERVER_HOSTNAME, MAX_JOB_COUNT accordingly  */


Insert into "BIO_SERVER_INFO"
   ("SERVER_ID", "SERVER_HOSTNAME", "SERVER_TYPE", "SERVER_STATE", "COMPONENT_TYPE", 
    "SERVER_GROUP_ID", "SUB_SYSTEM_GROUP_ID", "MAX_JOB_COUNT", "CREATE_DATETIME")
 Values
   ('EC001', '192.168.21.12', 'MANAGER', 'ACTIVE', 'EC', 
    'ECG01', 'ENG01', 4, CURRENT_TIMESTAMP);	

/* Connection Settings- Modify SERVER_ID, ipaddress in CONNECTION_URL accordingly  */

Insert into "BIO_SERVER_CONNECTION_INFO"
   ("SERVER_ID", "COMPONENT_TYPE", "CONNECTION_TYPE", "PROTOCOL_TYPE", "CONNECTION_URL")
 Values
   ('EC001', 'EC', 'CLUSTER', 'HAZELCAST', 'tcp://192.168.21.12:5901');

Insert into "BIO_SERVER_CONNECTION_INFO"
   ("SERVER_ID", "COMPONENT_TYPE", "CONNECTION_TYPE", "PROTOCOL_TYPE", "CONNECTION_URL")
 Values
   ('EC001', 'EC', 'SERVICE', 'HESSIAN', 'http://192.168.21.12:8080/bio-matcher-webservices/remoting/http/bioMatcherWebservice/httpBioMatcherWebservice');

