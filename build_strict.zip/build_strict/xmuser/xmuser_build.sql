
\i create_tables.sql

\i alter_tables.sql

\i sample-config/add_bin_segments.sql
\i sample-config/add_ec.sql
\i sample-config/add_ec_parameters.sql
\i sample-config/add_en.sql

\i sample-config/add_sb.sql
\i sample-config/add_sc.sql
\i sample-config/add_sc_parameters.sql
\i sample-config/add_sn.sql

\i sample-config/add_tvc.sql
\i sample-config/add_tvn.sql
\i sample-config/add_vc.sql
\i sample-config/add_vc_parameters.sql
\i sample-config/add_vn.sql


\i sample-config/add_groups.sql
\i sample-config/add_template_definitions.sql
\i sample-config/add_template_storage.sql
