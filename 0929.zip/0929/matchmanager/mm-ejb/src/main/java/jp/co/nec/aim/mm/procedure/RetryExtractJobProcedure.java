package jp.co.nec.aim.mm.procedure;

import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import jp.co.nec.aim.message.proto.BusinessMessage.PBResponse;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceStateReason;
import jp.co.nec.aim.mm.logger.PerformanceLogger;
import jp.co.nec.aim.mm.util.StopWatch;

import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

public class RetryExtractJobProcedure extends StoredProcedure {

	private static final String SQL = "MATCH_MANAGER_API.retry_extract_job";

	public RetryExtractJobProcedure(DataSource dataSource) {
		setDataSource(dataSource);
		setSql(SQL);
		setFunction(true);
		declareParameter(new SqlOutParameter("l_count", Types.INTEGER));
		declareParameter(new SqlParameter("p_extract_job_id", Types.BIGINT));
		declareParameter(new SqlParameter("p_mu_id", Types.BIGINT));
		declareParameter(new SqlParameter("p_reason", Types.VARCHAR));
		declareParameter(new SqlParameter("p_code", Types.VARCHAR));
		declareParameter(new SqlParameter("p_time", Types.VARCHAR));
		compile();
	}

	public int execute(long extractJobId, long muId, PBResponse reason) {
		if (muId < 1L) {
			throw new IllegalArgumentException("muId is less than 1");
		}
		if (extractJobId < 1L) {
			throw new IllegalArgumentException("extractJobId is less than 1");
		}
		if (reason == null) {
			throw new IllegalArgumentException("reason is null");
		}

		StopWatch stopWatch = new StopWatch();
		stopWatch.start();

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("p_extract_job_id", new Long(extractJobId));
		map.put("p_mu_id", new Long(muId));
		map.put("p_reason", reason.getErrorMessage());
		map.put("p_code", reason.getStatus());
		map.put("p_time", reason.getTime());
		Map<String, Object> resultMap = execute(map);
		int count = ((Integer) resultMap.get("l_count")).intValue();

		stopWatch.stop();
		PerformanceLogger.log(getClass().getSimpleName(), "execute",
				stopWatch.elapsedTime());

		return count;
	}
}
