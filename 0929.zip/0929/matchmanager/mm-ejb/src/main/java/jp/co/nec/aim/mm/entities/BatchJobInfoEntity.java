package jp.co.nec.aim.mm.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import jp.co.nec.aim.mm.constants.JobState;

/**
 * The persistent class for the CONTAINER_JOBS database table.
 * 
 */
@Entity
@Table(name = "BATCH_JOB_INFO")
public class BatchJobInfoEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id	
	@Column(name = "BATCH_JOB_ID")
	private long batchJobId;
	
	@Column(name = "REQUEST_ID ")
	private String reqeustId;
	
	@Column(name = "INTERNAL_JOB_ID ")
	private long internalJobId; 	

	@Column(name = "CONTAINER_ID")
	private int containerId;	

	@Column(name = "BATCH_TYPE")	
	private String batchType;
	
	@Column(name = "PBBusinessMessage")
	private byte[] businessMessage;
	
	@Column(name = "PBResponse_ERR")
	private byte[] pbResErr;


	public long getBatchJobId() {
		return batchJobId;
	}

	public void setBatchJobId(long batchJobId) {
		this.batchJobId = batchJobId;
	}	

	public String getReqeustId() {
		return reqeustId;
	}

	public void setReqeustId(String reqeustId) {
		this.reqeustId = reqeustId;
	}

	public long getInternalJobId() {
		return internalJobId;
	}

	public void setInternalJobId(long internalJobId) {
		this.internalJobId = internalJobId;
	}	

	public int getContainerId() {
		return containerId;
	}

	public void setContainerId(int containerId) {
		this.containerId = containerId;
	}	

	public String getBatchType() {
		return batchType;
	}

	public void setBatchType(String batchType) {
		this.batchType = batchType;
	}

	public byte[] getBusinessMessage() {
		return businessMessage;
	}

	public void setBusinessMessage(byte[] businessMessage) {
		this.businessMessage = businessMessage;
	}

	public byte[] getPbResErr() {
		return pbResErr;
	}

	public void setPbResErr(byte[] pbResErr) {
		this.pbResErr = pbResErr;
	}
	
}