package jp.co.nec.aim.mm.acceptor.service;

import static jp.co.nec.aim.mm.constants.MMConfigProperty.DEFAULT_HIT_THRESHOLD;
import static jp.co.nec.aim.mm.constants.MMConfigProperty.DEFAULT_MAX_CANDIDATES;
import static jp.co.nec.aim.mm.constants.MMConfigProperty.DEFAULT_PERCENTAGE_POINT;
import static jp.co.nec.aim.mm.constants.MMConfigProperty.DEFAULT_PRIORITY;

import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerSetType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.JobStateType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.TemplateFormatType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBInquiryScopeOptions;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplate;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplateData;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.InquiryFunctionType;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBFusionJobInput;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryFusionWeight;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryJobInfo;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryOptions;
import jp.co.nec.aim.message.proto.InquiryService.IdentifyRequest;
import jp.co.nec.aim.message.proto.InquiryService.IdentifyResponse;
import jp.co.nec.aim.message.proto.JobCommonService.PBDeleteJobRequest;
import jp.co.nec.aim.message.proto.JobCommonService.PBJobResultRequest;

import jp.co.nec.aim.mm.acceptor.CommonOptions;
import jp.co.nec.aim.mm.acceptor.Inquiry;
import jp.co.nec.aim.mm.acceptor.InquiryRequest;
import jp.co.nec.aim.mm.acceptor.script.ScriptManager;
import jp.co.nec.aim.mm.acceptor.script.ScriptValue;
import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.constants.JobState;
import jp.co.nec.aim.mm.dao.DateDao;
import jp.co.nec.aim.mm.dao.InquiryJobDao;
import jp.co.nec.aim.mm.dao.SystemConfigDao;
import jp.co.nec.aim.mm.entities.JobQueueEntity;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.exception.ExceptionHelper;
import jp.co.nec.aim.mm.util.CollectionsUtil;
import jp.co.nec.aim.mm.util.PBStateUtil;
import jp.co.nec.aim.mm.validator.AcceptorValidator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Lists;
import com.google.protobuf.InvalidProtocolBufferException;

/**
 * The main work flow of inquiry <br>
 * 
 * Include following public method:
 * <p>
 * inquiry, getJobStatus, listJobIds, deleteJob clearJobs, getJobResult,
 * getJobResult
 * <p>
 * 
 * @author liuyq
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class AimInquiryService {
	/** log instance **/
	private static Logger log = LoggerFactory
			.getLogger(AimInquiryService.class);

	@PersistenceContext(unitName = "aim-db")
	private EntityManager manager;

	@Resource(mappedName = "java:jboss/OracleDS")
	private DataSource dataSource;
	@EJB
	private Inquiry inquiry;
	private ScriptManager scriptManager;
	private AcceptorValidator validator;
	private InquiryJobDao inquiryJobDao;
	private SystemConfigDao sysConfigDao;
	private DateDao dateDao;
	private ExceptionHelper exception;

	/**
	 * AimInquiryService default constructor
	 */
	public AimInquiryService() {
	}

	@PostConstruct
	private void init() {
		this.inquiryJobDao = new InquiryJobDao(manager, dataSource);
		this.sysConfigDao = new SystemConfigDao(manager);
		this.validator = new AcceptorValidator(manager, dataSource);
		this.scriptManager = ScriptManager.getInstance();
		this.dateDao = new DateDao(dataSource);
		this.exception = new ExceptionHelper(dateDao);
	}

	/**
	 * The main work flow of inquiry
	 * 
	 * @param request
	 *            PBInquiryJobRequest instance
	 * @param isFromServlet
	 *            IS called by SERVLET
	 * @return PBInquiryJobResponse instance
	 */
	public IdentifyResponse inquiry(final IdentifyRequest request,
			boolean isFromServlet) {
		// first check the parameter PBInquiryJobRequest
		// if any error occurred, throw IllegalArgumentException
		// servLet will response 400 (bad request)
		// at the meanwhile convert to new Request
		IdentifyRequest.Builder newRequest = validator
				.checkInquiryJobRequest(request);

		if (log.isDebugEnabled()) {
			log.debug("Ready to create inquiry CommonOptions");
		}

		if (log.isDebugEnabled()) {
			log.debug("ready to call method inquiry with "
					+ "InquiryRequest list and CommonOptions");
		}
		long jobId = inquiry.inquiry(request);

		IdentifyResponse.Builder b = IdentifyResponse.newBuilder();
		b.setJobId(jobId);
		b.setServiceState(PBStateUtil.creatSuccessState());
		return b.build();
	}

	/**
	 * get inquiry Job Status
	 * 
	 * @param request
	 *            PBJobStatusRequest instance
	 * @return PBJobStatusResponse instance
	 */
	public PBJobStatusResponse getJobStatus(PBJobStatusRequest request) {
		PBJobStatusResponse.Builder b = PBJobStatusResponse.newBuilder();
		long jobId = request.getJobId();

		JobQueueEntity jobQueue = null;
		try {
			jobQueue = inquiryJobDao.getTopLevelJob(jobId);
		} catch (Exception ex) {
			exception.throwDBException(AimError.INQ_DB, ex, String.format(
					"Exception occurred when find top level job by job id %s",
					jobId));
		}

		if (jobQueue == null) {
			final String error = String.format(
					"Can not find top level job by job id %s", jobId);
			log.error(error);			
			exception.throwArgException(AimError.MISS_JOBID_ERROR, error, jobId);		
		}

		b.setJobId(jobId);
		JobState jobState = jobQueue.getJobState();
		switch (jobState) {
		case QUEUED:
			b.setJobState(JobStateType.JOB_STATE_QUEUED);
			break;
		case WORKING:
			b.setJobState(JobStateType.JOB_STATE_WORKING);
			break;
		case DONE:
			b.setJobState(JobStateType.JOB_STATE_DONE);
			break;
		default:
			throw new AimRuntimeException("jobState:" + jobState.name()
					+ " is not support..");
		}
		b.setJobFailed(jobQueue.getFailedFlag() == null ? false : jobQueue
				.getFailedFlag());
		b.setServiceState(PBStateUtil.creatSuccessState());
		return b.build();
	}

	/**
	 * list inquiry JobIds
	 * 
	 * @return PBListJobIdsResponse instance
	 */
	public PBListJobIdsResponse listJobIds() {
		PBListJobIdsResponse.Builder b = PBListJobIdsResponse.newBuilder();
		List<Long> jobIds = null;
		try {
			jobIds = inquiryJobDao.listAllJobIds();
		} catch (Exception ex) {
			exception.throwDBException(AimError.INQ_DB, ex,
					"Exception occurred when list inquiry job ids");
		}
		if (CollectionsUtil.isNotEmpty(jobIds)) {
			b.addAllJobId(jobIds);
		}

		b.setServiceState(PBStateUtil.creatSuccessState());
		return b.build();
	}

	/**
	 * delete the inquiry Job with specified job id
	 * 
	 * @param request
	 *            PBDeleteJobRequest instance
	 */
	public void deleteJob(PBDeleteJobRequest request) {
		long jobId = request.getJobId();
		try {
			inquiryJobDao.deleteJob(jobId);
		} catch (Exception ex) {
			exception.throwDBException(AimError.INQ_DB, ex, String.format(
					"Exception occurred when when delete "
							+ "inquiry job by job id %s", jobId));
		}
	}

	/**
	 * clear all inquiry Jobs
	 */
	public void clearJobs() {
		try {
			inquiryJobDao.clearJobs();
		} catch (Exception ex) {
			exception.throwDBException(AimError.INQ_DB, ex,
					"Exception occurred when clear inquiry job.");
		}
	}

	/**
	 * getJobResult
	 * 
	 * @param request
	 *            the instance of PBJobResultRequest
	 * @return PBInquiryJobResult instance
	 */
	public PBInquiryJobResult getJobResult(PBJobResultRequest request) {
		long jobId = request.getJobId();
		PBInquiryJobResult.Builder b = PBInquiryJobResult.newBuilder();
		JobQueueEntity job = null;
		try {
			job = inquiryJobDao.getTopLevelJob(jobId);
		} catch (Exception ex) {
			exception.throwDBException(AimError.INQ_DB, ex, String.format(
					"Exception occurred when find top level job by job id %s",
					jobId));
		}

		if (job == null) {
			final String error = String.format("Can not find top job by job id %s", jobId);					
			log.error(error);						
			exception.throwArgException(AimError.MISS_JOBID_ERROR, error);	
		}

		if (job.getJobState() != JobState.DONE) {
			final String error = "Job "
					+ jobId
					+ " is in "
					+ job.getJobState()
					+ " state. Job must be in DONE state before calling getJobResult()";
			log.error(error);
			throw new AimRuntimeException(error);
		}

		if (job.getResults() == null) {
			final String error = "Inquiry Job " + jobId + " result is null..)";
			log.error(error);
			throw new AimRuntimeException(error);
		}

		PBInquiryJobResult result = null;
		try {
			result = PBInquiryJobResult.parseFrom(job.getResults());
		} catch (InvalidProtocolBufferException e) {
			final String error = "InvalidProtocolBufferException occurred "
					+ "when parse from inquiry result..";
			throw new AimRuntimeException(error, e);
		}

		// b.setServiceState(PBStateUtil.creatSuccessState());
		b.setJobId(result.getJobId());
		if (result.hasStatistics()) {
			b.setStatistics(result.getStatistics());
		}

		if (result.hasCandidateList()) {
			b.setCandidateList(result.getCandidateList());
		}

		if (result.hasServiceState()) {
			b.setServiceState(result.getServiceState());
		}
		return b.build();
	}

	/**
	 * Create InquiryRequest list with new generated request<br>
	 * newRequest already checked passed and KeyedTemplate is required <br>
	 * due to keyedReference already convert to keyedTemplate <br>
	 * 
	 * @param newRequest
	 *            PBInquiryJobRequest.Builder instance
	 * @return InquiryRequest list
	 */
	private List<InquiryRequest> createInquiryRequest(
			PBInquiryJobRequest.Builder newRequest) {
		final PBInquiryJobInfo jobInfo = newRequest.getJobInfo(); // required
		final InquiryFunctionType function = jobInfo.getFunction(); // required
		final List<PBFusionJobInput.Builder> fJobInputs = newRequest
				.getFusionJobInputBuilderList();

		final List<InquiryRequest> requests = Lists.newArrayList();
		for (final PBFusionJobInput.Builder fJobInput : fJobInputs) {
			final PBKeyedTemplateData template = fJobInput
					.getKeyedTemplateData();
			final PBInquiryScopeOptions scopes = fJobInput.hasScopes() ? fJobInput
					.getScopes() : null; // optional

			// newRequest KeyedTemplate must exist!!
			// after converted, keyedReference will
			// convert into keyedTemplate if extract
			// result is exist with jobId key and indexer
			if (!template.hasKeyedTemplate()) {
				throw new AimRuntimeException(
						"KeyedTemplate must be specified after convert..");
			}

			final PBKeyedTemplate kTemplate = template.getKeyedTemplate(); // required
			final ScriptValue value = scriptManager.findInqContainerIds(
					function, kTemplate, scopes);
			// fusionWeights.putAll(value.getFusionWeightsMap());

			// FusionWeights is optional, merger the fusion weight
			// with the default from aim-script and client
			mergerFusionWeights(fJobInput, value.getFusionWeightsMap());

			// add to constructed InquiryRequest instance into requests list
			// Attention!! FunctioName is parse from the TemplateFormatType
			// TEMPLATE_TLIS -> TLIS, TEMPLATE_TLIM -> TLIM
			requests.add(new InquiryRequest(getFunctioName(kTemplate.getKey()),
					Lists.newArrayList(value.getContainerIds()), newRequest));
		}

		return requests;
	}

	/**
	 * Merger FusionWeights <br>
	 * 1. If fusionWeights from client is empty, set default fusion weight <br>
	 * 2. client fusion weight is not empty, replace with the specified weights <br>
	 * 
	 * For Example <br>
	 * [Input from client] <br>
	 * LIX fusionWeight inquirySet="PC2_Slap" 150 [aim-script] <br>
	 * LIX fusionWeight <br>
	 * inquirySet="PC2_Rolled" 200 <-default <br>
	 * inquirySet="PC2_Slap" 150 <- set value from client <br>
	 * inquirySet="Fmp5_Rolled" 100 <-default <br>
	 * inquirySet="Fmp5_Slap" 100 <-default <br>
	 * 
	 * @param newRequest
	 *            regenerated request
	 * @param value
	 *            ScriptValue instance
	 */
	private void mergerFusionWeights(PBFusionJobInput.Builder fJobInput,
			Map<FingerSetType, PBInquiryFusionWeight> defaultWeights) {
		if (fJobInput.hasInquiryOptions()) {
			PBInquiryOptions.Builder options = fJobInput
					.getInquiryOptionsBuilder();
			List<PBInquiryFusionWeight> fusionWeights = options
					.getFusionWeightList();
			// if fusionWeights from client is empty, set default fusion weight
			if (CollectionsUtil.isEmpty(fusionWeights)) {
				options.addAllFusionWeight(defaultWeights.values());
			} else {
				// default fusion weight is null or empty..
				// return directly..
				if (CollectionsUtil.isEmpty(defaultWeights)) {
					return;
				}
				// client fusion weight is not empty
				for (PBInquiryFusionWeight weight : fusionWeights) {
					FingerSetType key = weight.getInquirySet();
					if (defaultWeights.containsKey(key)) {
						defaultWeights.put(key, weight); // replace
					}
				}
				options.clearFusionWeight();
				options.addAllFusionWeight(defaultWeights.values());
			}
		} else {
			fJobInput.setInquiryOptions(PBInquiryOptions.newBuilder()
					.addAllFusionWeight(defaultWeights.values()));
		}
	}

	/**
	 * create CommonOptions instance
	 * 
	 * @param request
	 *            PBInquiryJobRequest instance
	 * @param isFromServlet
	 *            Is the interface From servLet
	 * @return the instance of CommonOptions
	 */
	private CommonOptions createOptions(PBInquiryJobRequest.Builder newRequest,
			boolean isFromServlet) {
		final CommonOptions options = new CommonOptions();
		options.setFromServlet(isFromServlet);

		PBInquiryJobInfo.Builder jobInfo = newRequest.getJobInfoBuilder(); // required
		// set Priority
		if (jobInfo.hasPriority()) {
			options.setPriority(jobInfo.getPriority());
		} else {
			options.setPriority(sysConfigDao.getMMPropertyInt(DEFAULT_PRIORITY));
			jobInfo.setPriority(options.getPriority());
		}

		// set CallBackUrl
		if (jobInfo.hasCallBackUrl()) {
			options.setCallbackURL(jobInfo.getCallBackUrl());
		}

		// set Function
		if (jobInfo.hasFunction()) {
			options.setFunctioName(jobInfo.getFunction().name());
		}

		// set max Candidate
		if (jobInfo.hasMaxCandidate()) {
			options.setMaxCandidates(jobInfo.getMaxCandidate());
		} else {
			int sysMaxCandidate = sysConfigDao
					.getMMPropertyInt(DEFAULT_MAX_CANDIDATES);
			// set default MaxCandidates
			options.setMaxCandidates(sysMaxCandidate);
			jobInfo.setMaxCandidate(options.getMaxCandidates());
		}

		// set DynThreshHitThreshold
		if (jobInfo.hasDynThreshHitThreshold()) {
			options.setDynThreshHitThreshold(jobInfo.getDynThreshHitThreshold());
		} else {
			// set default DynThreshHitThreshold
			options.setDynThreshHitThreshold(sysConfigDao
					.getMMPropertyInt(DEFAULT_HIT_THRESHOLD));
			jobInfo.setDynThreshHitThreshold(options.getDynThreshHitThreshold());
		}

		// set DynThreshPercentagePoint
		if (jobInfo.hasDynThreshPercentagePoint()) {
			options.setDynThreshPercentagePoint(jobInfo
					.getDynThreshPercentagePoint());
		} else {
			// set default DynThreshPercentagePoint
			options.setDynThreshPercentagePoint(sysConfigDao
					.getMMPropertyFloat(DEFAULT_PERCENTAGE_POINT));
			jobInfo.setDynThreshPercentagePoint(options
					.getDynThreshPercentagePoint());
		}
		return options;
	}

	/**
	 * Get FunctioName by TemplateFormatType, for example <br>
	 * TEMPLATE_TLIS -> TLIS <br>
	 * TEMPLATE_TLIM -> TLIM <br>
	 * 
	 * @return Real FunctioName
	 */
	private String getFunctioName(final TemplateFormatType key) {
		String keyName = key.name();
		String[] array = keyName.split("_");
		return array[1];
	}
}
