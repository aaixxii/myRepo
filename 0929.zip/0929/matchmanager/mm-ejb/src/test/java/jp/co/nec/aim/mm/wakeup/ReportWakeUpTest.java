package jp.co.nec.aim.mm.wakeup;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.util.Set;
import java.util.TreeSet;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.aim.mm.common.SocketReceiveUtil;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.exception.UDPNotifyException;
import jp.co.nec.aim.mm.util.UDPNotifyHelper;
import mockit.Mock;
import mockit.MockUp;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class ReportWakeUpTest {
	@Resource
	private DataSource dataSource;
	@Resource
	private JdbcTemplate jdbcTemplate;
	@PersistenceContext(unitName = "aim-db")
	private EntityManager entityManager;

	@Before
	public void setUp() {
		jdbcTemplate.update("delete from SYSTEM_INIT");
	}

	@After
	public void tearDown() {
		jdbcTemplate.update("delete from SYSTEM_INIT");
	}

	@Test
	public void test_notifyIpAddressIsIncorrect() throws Exception {
		SocketReceiveUtil listen = null;
		try {
			prepareIncorrectBroadCastData(8356);

			listen = new SocketReceiveUtil(8356);

			Set<Long> unitList = new TreeSet<Long>();
			unitList.add(1L);
			unitList.add(2L);
			unitList.add(3L);

			ReportWakeUp wakeUp = new ReportWakeUp(entityManager);
			wakeUp.notifyMessage(unitList);

			listen.join();

			assertEquals(17, listen.getDatagramPacketLen());
			assertEquals("Receive timed out", listen.getDatagramPacketMsg());
		} finally {
			if (listen != null) {
				listen.closeSocket();
			}
		}
	}

	@Test
	public void test_notifyIpAddressIsCorrectAndPortIsInCorrect()
			throws Exception {
		SocketReceiveUtil listen = null;
		try {
			prepareIncorrectBroadCastData(9356);

			listen = new SocketReceiveUtil(9358);

			Set<Long> unitList = new TreeSet<Long>();
			unitList.add(1L);
			unitList.add(2L);
			unitList.add(3L);

			ReportWakeUp wakeUp = new ReportWakeUp(entityManager);
			wakeUp.notifyMessage(unitList);

			listen.join();
			assertEquals(17, listen.getDatagramPacketLen());
			assertEquals("Receive timed out", listen.getDatagramPacketMsg());
		} finally {
			if (listen != null) {
				listen.closeSocket();
			}
		}
	}

	@Test
	public void test_notifyPortIsInCorrect() throws Exception {
		SocketReceiveUtil listen = null;
		try {
			prepareBroadCastData(10356);

			listen = new SocketReceiveUtil(10358);

			Set<Long> unitList = new TreeSet<Long>();
			unitList.add(1L);
			unitList.add(2L);
			unitList.add(3L);

			ReportWakeUp wakeUp = new ReportWakeUp(entityManager);
			wakeUp.notifyMessage(unitList);

			listen.join();

			assertEquals(17, listen.getDatagramPacketLen());
			assertEquals("Receive timed out", listen.getDatagramPacketMsg());
		} finally {
			if (listen != null) {
				listen.closeSocket();
			}
		}
	}

	@Test
	public void test_NorifySuccessfully() throws InterruptedException {
		SocketReceiveUtil listen = null;
		try {
			prepareBroadCastData(11356);

			listen = new SocketReceiveUtil(11356);

			Set<Long> unitList = new TreeSet<Long>();
			unitList.add(1L);
			unitList.add(2L);
			unitList.add(3L);

			ReportWakeUp wakeUp = new ReportWakeUp(entityManager);
			wakeUp.notifyMessage(unitList);

			listen.join();

			assertEquals("1,2,3,", listen.getDatagramPacketMsg());
		} finally {
			if (listen != null) {
				listen.closeSocket();
			}
		}
	}

	@Test
	public void test_NorifyNoMessage() throws InterruptedException {
		SocketReceiveUtil listen = null;
		try {
			prepareBroadCastData(14356);

			listen = new SocketReceiveUtil(14356);

			Set<Long> unitList = new TreeSet<Long>();

			ReportWakeUp wakeUp = new ReportWakeUp(entityManager);
			wakeUp.notifyMessage(unitList);

			listen.join();

			assertEquals("Receive timed out", listen.getDatagramPacketMsg());
		} finally {
			if (listen != null) {
				listen.closeSocket();
			}
		}
	}

	private void prepareBroadCastData(int port) {
		jdbcTemplate
				.execute("Insert into SYSTEM_INIT(INIT_ID, KEY_NAME,"
						+ " KEY_VALUE) values(1, 'UNIT_NETWORK_SEGMENT', '127.0.0.255')");
		jdbcTemplate.execute("Insert into SYSTEM_INIT (INIT_ID, KEY_NAME,"
				+ " KEY_VALUE) values(2, 'UNIT_WAKEUP_PORT', '" + port + "')");

	}

	private void prepareIncorrectBroadCastData(int port) {
		jdbcTemplate.execute("Insert into SYSTEM_INIT(INIT_ID, KEY_NAME,"
				+ " KEY_VALUE) values(1, 'UNIT_NETWORK_SEGMENT', 'abcde')");
		jdbcTemplate.execute("Insert into SYSTEM_INIT(INIT_ID, KEY_NAME,"
				+ " KEY_VALUE) values(2, 'UNIT_WAKEUP_PORT', '" + port + "')");

	}

	@Test
	public void testUDPNotifyException() {
		new MockUp<UDPNotifyHelper>() {
			@Mock
			public void notifyCompoent(String message) {
				throw new UDPNotifyException();
			}
		};
		try {
			jdbcTemplate.execute("Insert into SYSTEM_INIT(INIT_ID, KEY_NAME,"
					+ " KEY_VALUE) values(1, 'UNIT_NETWORK_SEGMENT', 'abcde')");

			Set<Long> unitList = new TreeSet<Long>();
			unitList.add(1L);
			unitList.add(2L);
			unitList.add(3L);

			ReportWakeUp wakeUp = new ReportWakeUp(entityManager);
			try {
				wakeUp.notifyMessage(unitList);
			} catch (AimRuntimeException e) {
				assertEquals("UDPNotifyException occurred while notify.",
						e.getMessage());
				return;
			}
			fail();
		} finally {			
		}
	}

	@Test
	public void testException() {
		new MockUp<UDPNotifyHelper>() {
			@Mock
			public void notifyCompoent(String message) throws Exception {
				throw new Exception("");
			}
		};
		try {
			jdbcTemplate.execute("Insert into SYSTEM_INIT(INIT_ID, KEY_NAME,"
					+ " KEY_VALUE) values(2, 'UNIT_WAKEUP_PORT', '4523')");

			Set<Long> unitList = new TreeSet<Long>();
			unitList.add(1L);
			unitList.add(2L);
			unitList.add(3L);

			ReportWakeUp wakeUp = new ReportWakeUp(entityManager);
			try {
				wakeUp.notifyMessage(unitList);
			} catch (AimRuntimeException e) {
				assertEquals("Exception occurred while notify.", e.getMessage());
				return;
			}
			fail();
		} finally {
			
		}
	}
}
