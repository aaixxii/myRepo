package com.nec.aim.uid.zkpdm;


import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZkpdmApplicationTests {

	@Test
	void contextLoads() {
	}

}
