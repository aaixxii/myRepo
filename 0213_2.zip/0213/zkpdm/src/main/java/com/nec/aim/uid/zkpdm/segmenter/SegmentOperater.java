package com.nec.aim.uid.zkpdm.segmenter;

import static com.nec.aim.uid.zkpdm.segmenter.DmConstants.SEGMENT_HEADER_SIZE;
import static com.nec.aim.uid.zkpdm.segmenter.DmConstants.SIZE_TEMPLATE_HEADER;
import static com.nec.aim.uid.zkpdm.segmenter.DmConstants.SIZE_CHECKSUM; //templateCheckSum
import static com.nec.aim.uid.zkpdm.segmenter.DmConstants.SIZE_TSZ; //templateTotalSize;
import static com.nec.aim.uid.zkpdm.segmenter.DmConstants.SIZE_TEMPLATE_ID;


import java.nio.ByteBuffer;
import java.sql.Blob;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.locks.Lock;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.google.protobuf.InvalidProtocolBufferException;

import jp.co.nec.aim.message.proto.AIMEnumTypes.SegmentSyncCommandType;
import jp.co.nec.aim.message.proto.AIMMessages.PBDmSyncRequest;
import jp.co.nec.aim.message.proto.BusinessMessage.PBTemplateInfo;
import lombok.extern.slf4j.Slf4j;

@Service
@Scope("prototype")
@Slf4j
public class SegmentOperater {
	public static final int AIM_VERSION = 2;
	public static final short FORMAT_ID = 1;
	public static long MAX_SEGMENT_SIZE = 1000000000;
	
	
	
	public Boolean handerRequest(PBDmSyncRequest dmSegRequest)
			throws InvalidProtocolBufferException, InterruptedException, ExecutionException {
		PBDmSyncRequest dmSegReq = PBDmSyncRequest.parseFrom(dmSegRequest.toByteString());
		String changeType = dmSegReq.getCmd().name().toUpperCase();
		long bioId = dmSegReq.getBioId();
		PBTemplateInfo templateInfo = dmSegReq.getTemplateData();
		String externalId = templateInfo.getReferenceId();
		byte[] templateData = templateInfo.getData().toByteArray();
		long segId = dmSegReq.getTargetSegments().getId();
		long segVer = dmSegReq.getTargetSegments().getVersion();		
		if (Objects.isNull(templateData) || templateData.length < 0) {
			log.warn("Received empty template data!!" );
			return false;
		}	
		boolean resulst = false;
		SegmentInfo segInfo = SegmentManager.getSegmentInfo(segId);		
		if (changeType.equals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT.name())) {
			if (Objects.isNull(segInfo)) {				
				resulst = newSegment(templateData, bioId, externalId, segId, segVer);
			} else {
				resulst = updateSegment(segInfo, templateData, bioId, externalId, segId, segVer);
			}
		} else if (changeType.equals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_DELETE.name())){
			if (Objects.isNull(segInfo)) {
              log.warn("can't found segment data for sementId={}", segId);
			} else {
				resulst = deleteTemplate(segInfo, bioId, externalId);
			}
		}
		return Boolean.valueOf(resulst);
	}

	private Boolean newSegment(byte[] data, long bioId, String extId, long segId, long segVer) {			
		Callable<Boolean> newSegmentTask = () -> {
			int tSize = SEGMENT_HEADER_SIZE + SIZE_TEMPLATE_HEADER + data.length;			
			ByteBuffer segBuffer = ByteBuffer.allocate(tSize);		
			SegmentInfo newSegInfo = new SegmentInfo(segId);
			newSegInfo.setSegId(segId);
			newSegInfo.getLocker().writeLock().lock();
			try {
				segBuffer.position(0);
				segBuffer.putInt(AIM_VERSION);
				segBuffer.putShort(FORMAT_ID);
				segBuffer.putLong(MAX_SEGMENT_SIZE);
				segBuffer.putInt(1);
				segBuffer.putLong(segVer);
				byte[] templateWithHeader = TemplateHeadBuilder.prependHeader(bioId, data, extId, 1);
				segBuffer.put(templateWithHeader);
				segBuffer.put(data);				
				Blob blob = new javax.sql.rowset.serial.SerialBlob(segBuffer.array());
				//Segments newSeg = new Segments(segId);
				//newSeg.setData(blob);
				//segmentsRepository.insert(newSeg);
				blob.free();
				newSegInfo.setRecordcount(1);				
				newSegInfo.setLastPosition(segBuffer.position() -1);
				SegmentManager.saveToQueue(Long.valueOf(segId), newSegInfo);
				segBuffer.clear();
				segBuffer = null;
			} finally {
				newSegInfo.getLocker().writeLock().unlock();
			}			
			return true;
		};
		try {
			return SegmentManager.submit(newSegmentTask);			
		} catch (InterruptedException | ExecutionException e) {
			log.error(e.getMessage(), e);
			return false;
		}
	}

	private Boolean updateSegment(SegmentInfo segInfo, byte[] data, long bioId, String extId, long segId, long segVer)
			throws InterruptedException, ExecutionException {
		Callable<Boolean> updateSegmentTask = () -> {
			segInfo.getLocker().writeLock().lock();
			try {
//				Optional<Segments> segmentFromDB = segmentsRepository.findById(segId);
//				if (!segmentFromDB.isPresent()) {
//					log.warn("The segment is not exit, segmentId={}", segId);
//					return false;
//				}
//				Blob blobData = segmentFromDB.get().getData();		
				Blob blobData = null;
				int blobByteSize = (int) blobData.length();
				if (blobByteSize != segInfo.getLastPosition()) {
					log.warn("The segment size may have a miss,  id={}",segId);
				}
				byte[] binaryData = blobData.getBytes(0, (int) blobData.length());
				int newSize = binaryData.length + SIZE_TEMPLATE_HEADER + data.length;
				ByteBuffer newByteBuf = ByteBuffer.allocate(newSize);
				newByteBuf.put(binaryData);
				byte[] templateWithHeader = TemplateHeadBuilder.prependHeader(bioId, data, extId, 1);
				newByteBuf.put(templateWithHeader);
				newByteBuf.put(data);
				byte[] newData = newByteBuf.array();				
				Blob newBlob = new javax.sql.rowset.serial.SerialBlob(newByteBuf.array());
				//segmentFromDB.get().setData(newBlob);
				//segmentsRepository.save(segmentFromDB.get());
				segInfo.setLastPosition(newData.length);
				segInfo.setRecordcount(segInfo.getRecordcount() + 1);
				log.info("Success upate segment to cassandra db, segmentId={}", segId);
				blobData.free();
				newByteBuf.clear();
				newByteBuf = null;
				newBlob.free();
			} finally {
				segInfo.getLocker().writeLock().unlock();
			}
			return true;
		};
		return SegmentManager.submit(updateSegmentTask);
	}

	private Boolean deleteTemplate(SegmentInfo segInfo, long bioId, String extId) throws InterruptedException, ExecutionException {
		Callable<Boolean> delTemplateTask = () -> {
			long segId = segInfo.getSegId();			
			Lock locker = segInfo.getLocker().writeLock();
			locker.lock();
			ByteBuffer delByteBuf = null;
			try {
//				Optional<Segments> segmentFromDB = segmentsRepository.findById(segId);
//				if (!segmentFromDB.isPresent()) {
//					log.warn("The segment is not exit, segmentId={}", segId);
//					return false;
//				}
//				Blob blobData = segmentFromDB.get().getData();
				Blob blobData = null;
				int blobByteSize = (int) blobData.length();
				if (blobByteSize != segInfo.getLastPosition()) {
					log.warn("May be have a rong in the segment size,  id={}",segId);
				}
				byte[] binaryData = blobData.getBytes(0, (int) blobData.length());
				delByteBuf = ByteBuffer.wrap(binaryData);
				int firstSeekPositon = SEGMENT_HEADER_SIZE + SIZE_CHECKSUM;
				delByteBuf.position(firstSeekPositon);				
				int templateSize = delByteBuf.getInt();
				long seachedBioId = delByteBuf.getLong();
				if (seachedBioId == bioId) {
					byte b = 1;
					delByteBuf.put(b);					
					//segmentsRepository.save(segmentFromDB.get());					
					log.info("found bioId:{},setDelFlag", seachedBioId);
					segInfo.setRecordcount(segInfo.getRecordcount() -1);
					return true;
				} else {						
					boolean finish = false;
					int currentTemplateSize = templateSize;
					long currentBioId = seachedBioId;
					while (!finish) {
						int nextSeekSize = delByteBuf.position() + currentTemplateSize - (SIZE_CHECKSUM + SIZE_TSZ + SIZE_TEMPLATE_ID) + SIZE_CHECKSUM + SIZE_TSZ;
						delByteBuf.position(nextSeekSize);
						currentTemplateSize = delByteBuf.getInt();
						currentBioId = delByteBuf.getLong();
						if (currentBioId == bioId) {
							byte b = 1;
							delByteBuf.put(b);
							//segmentsRepository.save(segmentFromDB.get());	
							log.info("found bioId:{},setDelFlag", currentBioId);
							segInfo.setRecordcount(segInfo.getRecordcount() -1);
							finish = true;
							return true;						
					}
				}
				if (!finish) {
					log.info("Can't found templateId({}) in this segment({})", bioId, segId);
					return false;
				}
			}				
			} finally {
				locker.unlock();
				delByteBuf.clear();
				delByteBuf = null;
			}			
			return true;
		};
		return SegmentManager.submit(delTemplateTask);
	}
}
