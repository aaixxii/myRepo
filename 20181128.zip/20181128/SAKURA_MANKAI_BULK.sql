--------------------------------------------------------
--  �t�@�C�����쐬���܂��� - ���j��-11��-28-2018   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Procedure SAKURA_MANKAI_BULK
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "XMPERF"."SAKURA_MANKAI_BULK" 
( 
TAR_SEGMINT_ID IN NUMBER 
, EXPAND_SIZE IN NUMBER 
) AUTHID CURRENT_USER IS 
 
 TYPE seg_count_rec IS RECORD (
		seg_id	BIO_EVENT_INFO. ASSIGNED_SEGMENT_ID%TYPE,
		count 	NUMBER
	);
 TYPE seg_count_tab is table of seg_count_rec;
  seg_counts seg_count_tab;
 v_base_size NUMBER;
 
BEGIN
 select count(*) into v_base_size from (select ASSIGNED_SEGMENT_ID, count(ASSIGNED_SEGMENT_ID) as count from bio_event_info group by ASSIGNED_SEGMENT_ID);
 if (v_base_size < 1) then
  dbms_output.put_line('No data to process, return');
  return;
 end if;

 seg_counts.EXTEND(v_base_size);
 select ASSIGNED_SEGMENT_ID, count(ASSIGNED_SEGMENT_ID) as count BULK COLLECT  INTO seg_counts from bio_event_info group by ASSIGNED_SEGMENT_ID ;
 
 
 
  NULL;
END SAKURA_MANKAI_BULK;

/
