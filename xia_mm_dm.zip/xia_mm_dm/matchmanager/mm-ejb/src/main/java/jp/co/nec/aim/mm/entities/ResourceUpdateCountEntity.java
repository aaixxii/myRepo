package jp.co.nec.aim.mm.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the RESOURCE_UPDATE_COUNT database table.
 * 
 */
@Entity
@Table(name = "RESOURCE_UPDATE_COUNT")
@NamedQuery(name = "ResourceUpdateCountEntity.findAll", query = "SELECT r FROM ResourceUpdateCountEntity r")
public class ResourceUpdateCountEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "ID")
    private long id;
	
	@Column(name = "UPDATE_COUNT")
	private long updateCount;

	@Column(name = "UPDATE_TS")
	private long updateTs;

	public ResourceUpdateCountEntity() {
	}	

	public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getUpdateCount() {
		return this.updateCount;
	}

	public void setUpdateCount(long updateCount) {
		this.updateCount = updateCount;
	}

	public long getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(long updateTs) {
		this.updateTs = updateTs;
	}

}