package jp.co.nec.aim.mm.result;

import jp.co.nec.aim.mm.constants.FunctionFamily;

public class DynamicThresholdParams {

	private final FunctionFamily paramEnum;
	private final double percentagePoint;
	private final int hitThreshold;

	public DynamicThresholdParams(FunctionFamily paramEnum,
			double percentagePoint, int hitThreshold) {
		this.paramEnum = paramEnum;
		this.percentagePoint = percentagePoint;
		this.hitThreshold = hitThreshold;
	}

	public FunctionFamily getParamEnum() {
		return paramEnum;
	}

	public double getPercentagePoint() {
		return percentagePoint;
	}

	public int getHitThreshold() {
		return hitThreshold;
	}

}
