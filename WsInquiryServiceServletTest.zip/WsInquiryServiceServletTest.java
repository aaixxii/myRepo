package jp.co.nec.aim.mm.servlet;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.ServletException;

import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerPrintType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.JobStateType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.TemplateFormatType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBInquiryScopeOptions;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplate;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplateData;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplateIndexer;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.InquiryFunctionType;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBFusionJobInput;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryJobInfo;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryResultStatistics;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryResultStatisticsAMR;
import jp.co.nec.aim.message.proto.InquiryService.PBInquiryJobRequest;
import jp.co.nec.aim.message.proto.InquiryService.PBInquiryJobResponse;
import jp.co.nec.aim.message.proto.InquiryService.PBInquiryJobResult;
import jp.co.nec.aim.message.proto.JobCommonService.PBDeleteJobRequest;
import jp.co.nec.aim.message.proto.JobCommonService.PBJobResultRequest;
import jp.co.nec.aim.message.proto.JobCommonService.PBJobStatusRequest;
import jp.co.nec.aim.message.proto.JobCommonService.PBJobStatusResponse;
import jp.co.nec.aim.message.proto.JobCommonService.PBListJobIdsResponse;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.jms.JmsSender;
import jp.co.nec.aim.mm.license.LicenseManager;
import mockit.Mock;
import mockit.MockUp;

import org.apache.http.HttpStatus;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.google.protobuf.ByteString;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class InquiryServiceServletTest {
	@Resource
	private InquiryServiceServlet servlet;
	@Resource
	private JdbcTemplate jdbcTemplate;

	@Before
	public void setUp() throws ServletException {
		jdbcTemplate.execute("delete from Segments");
		jdbcTemplate.execute("delete from CONTAINER_JOBS");
		jdbcTemplate.execute("delete from FUSION_JOBS");
		jdbcTemplate.execute("delete from JOB_QUEUE");
		servlet.init();
		setMockMethod();
	}

	@After
	public void tearDown() {
		jdbcTemplate.execute("delete from Segments");
		jdbcTemplate.execute("delete from CONTAINER_JOBS");
		jdbcTemplate.execute("delete from FUSION_JOBS");
		jdbcTemplate.execute("delete from JOB_QUEUE");
		//Mockit.tearDownMocks();
	}

	private void setMockMethod() {
		new MockUp<JmsSender>() {
			@Mock
			private void convertAndSend(String queueName, Object message) {
				// build ConnectionFactory And Queue is necessary
				return;
			}
		};

	}

	@Test
	public void testDoPostUrlEndWithInquiryUrlEmpty() {
		new MockUp<LicenseManager>() {
			@Mock
			public void check(String function, Date now) {
				throw new AimRuntimeException("CommonOptions functioName can not be null or empty..");
			}
		};	
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();
		try {
			servlet.doPost(req, res);
			final int status = res.getStatus();
			assertEquals(status, HttpStatus.SC_METHOD_NOT_ALLOWED);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testDoPostUrlEndWithInquiryReqEmpty() {
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();
		req.setRequestURI("/AIMInquiryService/inquiry");
		try {

			servlet.doPost(req, res);
			final int status = res.getStatus();
			assertEquals(status, HttpStatus.SC_BAD_REQUEST);
			final String content = res.getContentAsString();
			assertEquals(
					content,
					"Received an empty POST request information:"
							+ " RemoteHost:localhost RemoteAddress:127.0.0.1 RemotePort:80 RemoteUser:null");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Test
	public void testDoPostUrlEndWithInquiry_parsefrom_error() {
		final MockHttpServletRequest req = new MockHttpServletRequest();
		req.setContent(new byte[] { 0 });
		final MockHttpServletResponse res = new MockHttpServletResponse();
		req.setRequestURI("/AIMInquiryService/inquiry");
		try {
			servlet.doPost(req, res);
			final int status = res.getStatus();
			assertEquals(status, HttpStatus.SC_BAD_REQUEST);
			final String content = res.getContentAsString();
			assertEquals(
					content,
					"Protocol message contained an invalid tag (zero). "
							+ "information: RemoteHost:localhost RemoteAddress:127.0.0.1 RemotePort:80 RemoteUser:null");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Test
	public void testDoPostUrlEndWithInquiryError() throws IOException {
		final MockHttpServletRequest req = new MockHttpServletRequest();
		byte[] bytes = PBInquiryJobRequest
				.newBuilder()
				.setJobInfo(
						PBInquiryJobInfo.newBuilder().setPriority(5)
								.setCallBackUrl("http://182.123.1.1")
								.setFunction(InquiryFunctionType.TI)).build()
				.toByteArray();

		req.setContent(bytes);
		final MockHttpServletResponse res = new MockHttpServletResponse();
		req.setRequestURI("/AIMInquiryService/inquiry");

		servlet.doPost(req, res);
		final int status = res.getStatus();
		assertEquals(HttpStatus.SC_BAD_REQUEST, status);
		final byte[] content = res.getContentAsByteArray();
		PBInquiryJobResponse inquiryJobResponse = PBInquiryJobResponse
				.parseFrom(content);
		assertEquals(ServiceStateType.SERVICE_STATE_ERROR, inquiryJobResponse
				.getServiceState().getState());

	}

	@Test
	public void testDoPostUrlEndWithInquiry() {
		new MockUp<LicenseManager>() {
			@Mock
			public void check(String function, Date now) {
				return;
			}
		};		
		
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(1,1,1,1,83,1,1,1,83)");
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(2,2,1,1,83,1,1,1,83)");
		byte[] bytes = { 1, 2, 3 };
		final MockHttpServletRequest req = new MockHttpServletRequest();

		PBKeyedTemplateData.Builder builder = PBKeyedTemplateData
				.newBuilder()
				.setKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setTemplateBinary(ByteString.copyFrom(bytes))
								.setKey(TemplateFormatType.TEMPLATE_TI)
								.setIndexer(
										PBKeyedTemplateIndexer
												.newBuilder()
												.setFingerPrintType(
														FingerPrintType.FINGER_PRINT_SLAP)));
		byte[] bytesInquiry = PBInquiryJobRequest
				.newBuilder()
				.setJobInfo(
						PBInquiryJobInfo.newBuilder()
								.setFunction(InquiryFunctionType.TI)
								.setPriority(5)
								.setCallBackUrl("http://182.123.1.1"))
				.addFusionJobInput(
						PBFusionJobInput
								.newBuilder()
								.mergeKeyedTemplateData(builder.build())
								.setScopes(
										PBInquiryScopeOptions
												.newBuilder()
												.addScope(1)
												.addTargetFingerPrint(
														FingerPrintType.FINGER_PRINT_SLAP)))
				.build().toByteArray();

		req.setContent(bytesInquiry);
		final MockHttpServletResponse res = new MockHttpServletResponse();
		req.setRequestURI("/AIMInquiryService/inquiry");
		try {
			servlet.doPost(req, res);
			jdbcTemplate.update("commit");
			final int status = res.getStatus();
			assertEquals(HttpStatus.SC_OK, status);
			final byte[] content = res.getContentAsByteArray();
			PBInquiryJobResponse jobResponse = PBInquiryJobResponse
					.parseFrom(content);
			assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, jobResponse
					.getServiceState().getState());
			Assert.assertNotNull(jobResponse.getJobId());
			List<Map<String, Object>> listJq = jdbcTemplate
					.queryForList("select * from job_queue");
			Assert.assertEquals(1, listJq.size());
			Map<String, Object> mapJq = listJq.get(0);
			Assert.assertEquals(0,
					Integer.parseInt(mapJq.get("JOB_STATE").toString()));
			Assert.assertEquals(1,
					Integer.parseInt(mapJq.get("CALLBACK_STYLE").toString()));
			Assert.assertEquals("http://182.123.1.1", mapJq.get("CALLBACK_URL"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Test
	public void testDoPostUrlEndWithGetJobResultUrlEmpty() {
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();
		try {
			servlet.doPost(req, res);
			final int status = res.getStatus();
			assertEquals(status, HttpStatus.SC_METHOD_NOT_ALLOWED);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Test
	public void testDoPostUrlEndWithGetJobResultReqEmpty() {
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();
		req.setRequestURI("/AIMInquiryService/getJobResult");
		try {
			servlet.doPost(req, res);
			final int status = res.getStatus();
			assertEquals(status, HttpStatus.SC_BAD_REQUEST);
			final String content = res.getContentAsString();
			assertEquals(
					content,
					"Received an empty POST request information:"
							+ " RemoteHost:localhost RemoteAddress:127.0.0.1 RemotePort:80 RemoteUser:null");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Test
	public void testDoPostUrlEndWithGetJobResult_parsefrom_error() {
		final MockHttpServletRequest req = new MockHttpServletRequest();
		req.setContent(new byte[] { 0 });
		final MockHttpServletResponse res = new MockHttpServletResponse();
		req.setRequestURI("/AIMInquiryService/getJobResult");
		try {
			servlet.doPost(req, res);
			final int status = res.getStatus();
			assertEquals(status, HttpStatus.SC_BAD_REQUEST);
			final String content = res.getContentAsString();
			assertEquals(
					content,
					"Protocol message contained an invalid tag (zero). "
							+ "information: RemoteHost:localhost RemoteAddress:127.0.0.1 RemotePort:80 RemoteUser:null");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Test
	public void testDoPostUrlEndWitGetJobResultError() throws IOException {
		final MockHttpServletRequest req = new MockHttpServletRequest();
		byte[] bytes = PBJobResultRequest.newBuilder().setJobId(1).build()
				.toByteArray();
		req.setContent(bytes);
		final MockHttpServletResponse res = new MockHttpServletResponse();
		req.setRequestURI("/AIMInquiryService/getJobResult");
		servlet.doPost(req, res);
		final int status = res.getStatus();
		assertEquals(HttpStatus.SC_BAD_REQUEST, status);
		final byte[] content = res.getContentAsByteArray();
		PBInquiryJobResponse inquiryJobResponse = PBInquiryJobResponse
				.parseFrom(content);
		assertEquals(ServiceStateType.SERVICE_STATE_ERROR, inquiryJobResponse
				.getServiceState().getState());

	}

	@Test
	public void testDoPostUrlEndWitGetJobResult() throws IOException {

		byte[] results = PBInquiryJobResult
				.newBuilder()
				.setServiceState(
						PBServiceState.newBuilder().setState(
								ServiceStateType.SERVICE_STATE_SUCCESS))
				.setJobId(20)
				.setStatistics(
						PBInquiryResultStatistics.newBuilder().setAmr(
								PBInquiryResultStatisticsAMR.newBuilder()
										.setMatchCount(2).setReadCount(20)))
				.build().toByteArray();
		jdbcTemplate
				.update("insert into JOB_QUEUE (JOB_ID,PRIORITY,JOB_STATE,RESULT,SUBMISSION_TS,CALLBACK_STYLE,TIMEOUTS,FAILURE_COUNT,REMAIN_JOBS,FAMILY_ID) values(20,5,2,?,22222,0,1234,1,1,1)",
						results);
		jdbcTemplate.execute("commit");
		final MockHttpServletRequest req = new MockHttpServletRequest();
		byte[] bytes = PBJobResultRequest.newBuilder().setJobId(20).build()
				.toByteArray();
		req.setContent(bytes);
		final MockHttpServletResponse res = new MockHttpServletResponse();
		req.setRequestURI("/AIMInquiryService/getJobResult");
		servlet.doPost(req, res);
		final int status = res.getStatus();
		assertEquals(HttpStatus.SC_OK, status);
		final byte[] content = res.getContentAsByteArray();
		PBInquiryJobResult inquiryJobResponse = PBInquiryJobResult
				.parseFrom(content);
		assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, inquiryJobResponse
				.getServiceState().getState());

	}

	@Test
	public void testDoPostUrlEndWithListJobIdsUrlEmpty() {
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();
		try {
			servlet.doPost(req, res);
			final int status = res.getStatus();
			assertEquals(status, HttpStatus.SC_METHOD_NOT_ALLOWED);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Test
	public void testDoPostUrlEndWithListJobIds() throws ServletException {
		jdbcTemplate
				.update("insert into JOB_QUEUE (JOB_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE,TIMEOUTS,FAILURE_COUNT,REMAIN_JOBS,FAMILY_ID) values(20,5,2,22222,0,1234,1,1,1)");
		jdbcTemplate.execute("commit");
		final MockHttpServletRequest req = new MockHttpServletRequest();
		PBJobStatusRequest jobStatusRequest = PBJobStatusRequest.newBuilder()
				.setJobId(1).build();
		req.setContent(jobStatusRequest.toByteArray());
		final MockHttpServletResponse res = new MockHttpServletResponse();
		req.setRequestURI("/AIMInquiryService/listJobIds");
		try {
			servlet.doGet(req, res);
			final int status = res.getStatus();
			assertEquals(HttpStatus.SC_OK, status);
			final byte[] content = res.getContentAsByteArray();
			PBListJobIdsResponse jobResponse = PBListJobIdsResponse
					.parseFrom(content);
			assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, jobResponse
					.getServiceState().getState());
			assertEquals(1, jobResponse.getJobIdList().size());

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Test
	public void testDoPostUrlEndWithGetJobStatus_parsefrom_error() {
		final MockHttpServletRequest req = new MockHttpServletRequest();
		req.setContent(new byte[] { 0 });
		final MockHttpServletResponse res = new MockHttpServletResponse();
		req.setRequestURI("/AIMInquiryService/getJobStatus");
		try {
			servlet.doPost(req, res);
			final int status = res.getStatus();
			assertEquals(status, HttpStatus.SC_BAD_REQUEST);
			final String content = res.getContentAsString();
			assertEquals(
					content,
					"Protocol message contained an invalid tag (zero). "
							+ "information: RemoteHost:localhost RemoteAddress:127.0.0.1 RemotePort:80 RemoteUser:null");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Test
	public void testDoPostUrlEndWithGetJobStatusError() throws IOException {
		final MockHttpServletRequest req = new MockHttpServletRequest();
		byte[] bytes = PBInquiryJobRequest.newBuilder().getJobInfoBuilder()
				.setPriority(5).setCallBackUrl("http://182.123.1.1")
				.setFunction(InquiryFunctionType.TI).build().toByteArray();

		req.setContent(bytes);
		final MockHttpServletResponse res = new MockHttpServletResponse();
		req.setRequestURI("/AIMInquiryService/getJobStatus");

		servlet.doPost(req, res);
		final int status = res.getStatus();
		assertEquals(HttpStatus.SC_BAD_REQUEST, status);
		final byte[] content = res.getContentAsByteArray();
		PBInquiryJobResponse inquiryJobResponse = PBInquiryJobResponse
				.parseFrom(content);
		assertEquals(ServiceStateType.SERVICE_STATE_ERROR, inquiryJobResponse
				.getServiceState().getState());

	}

	@Test
	public void testDoPostUrlEndWithGetJobStatus() {
		jdbcTemplate
				.update("insert into JOB_QUEUE (JOB_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE,TIMEOUTS,FAILURE_COUNT,REMAIN_JOBS,FAMILY_ID) values(20,5,2,22222,0,1234,1,1,1)");
		jdbcTemplate.execute("commit");

		final MockHttpServletRequest req = new MockHttpServletRequest();

		PBJobStatusRequest jobStatusRequest = PBJobStatusRequest.newBuilder()
				.setJobId(20).build();
		req.setContent(jobStatusRequest.toByteArray());
		final MockHttpServletResponse res = new MockHttpServletResponse();
		req.setRequestURI("/AIMInquiryService/getJobStatus");
		try {
			servlet.doPost(req, res);
			final int status = res.getStatus();
			assertEquals(HttpStatus.SC_OK, status);
			final byte[] content = res.getContentAsByteArray();
			PBJobStatusResponse jobResponse = PBJobStatusResponse
					.parseFrom(content);
			assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, jobResponse
					.getServiceState().getState());
			assertEquals(false, jobResponse.getJobFailed());
			Assert.assertNotNull(jobResponse.getJobId());
			assertEquals(20, jobResponse.getJobId());
			assertEquals(JobStateType.JOB_STATE_DONE, jobResponse.getJobState());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Test
	public void testDoPostUrlEndWithGetJobStatusUrlEmpty() {
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();
		try {
			servlet.doPost(req, res);
			final int status = res.getStatus();
			assertEquals(status, HttpStatus.SC_METHOD_NOT_ALLOWED);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Test
	public void testDoPostUrlEndWithGetJobStatusReqEmpty() {
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();
		req.setRequestURI("/AIMInquiryService/getJobStatus");
		try {

			servlet.doPost(req, res);
			final int status = res.getStatus();
			assertEquals(status, HttpStatus.SC_BAD_REQUEST);
			final String content = res.getContentAsString();
			assertEquals(
					content,
					"Received an empty POST request information:"
							+ " RemoteHost:localhost RemoteAddress:127.0.0.1 RemotePort:80 RemoteUser:null");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Test
	public void testDoPostUrlEndWithDeleteJobUrlEmpty() {
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();
		try {
			servlet.doPost(req, res);
			final int status = res.getStatus();
			assertEquals(status, HttpStatus.SC_METHOD_NOT_ALLOWED);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Test
	public void testDoPostUrlEndWithDeleteJobReqEmpty() {
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();
		req.setRequestURI("/AIMInquiryService/DeleteJob");
		try {

			servlet.doPost(req, res);
			final int status = res.getStatus();
			assertEquals(status, HttpStatus.SC_BAD_REQUEST);
			final String content = res.getContentAsString();
			assertEquals(
					content,
					"Received an empty POST request information:"
							+ " RemoteHost:localhost RemoteAddress:127.0.0.1 RemotePort:80 RemoteUser:null");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Test
	public void testDoPostUrlEndWithDeleteJob_parsefrom_error() {
		final MockHttpServletRequest req = new MockHttpServletRequest();
		req.setContent(new byte[] { 0 });
		final MockHttpServletResponse res = new MockHttpServletResponse();
		req.setRequestURI("/AIMInquiryService/DeleteJob");
		try {
			servlet.doPost(req, res);
			final int status = res.getStatus();
			assertEquals(status, HttpStatus.SC_BAD_REQUEST);
			String content = res.getContentAsString();
			assertEquals(
					"Protocol message contained an invalid tag (zero). information: RemoteHost:localhost RemoteAddress:127.0.0.1 RemotePort:80 RemoteUser:null",
					content);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Ignore
	@Test
	public void testDoPostUrlEndWithDeleteJobError() throws IOException {
		final MockHttpServletRequest req = new MockHttpServletRequest();

		byte[] bytes = PBDeleteJobRequest.newBuilder().setJobId(1).build()
				.toByteArray();

		req.setContent(bytes);
		final MockHttpServletResponse res = new MockHttpServletResponse();
		req.setRequestURI("/AIMInquiryService/DeleteJob");

		InquiryServiceServlet inquiryServlet = new InquiryServiceServlet();
		inquiryServlet.doPost(req, res);
		final int status = res.getStatus();
		assertEquals(HttpStatus.SC_INTERNAL_SERVER_ERROR, status);
		String content = res.getContentAsString();
		assertEquals(
				"NullPointerException occurred.. information: RemoteHost:localhost RemoteAddress:127.0.0.1 RemotePort:80 RemoteUser:null",
				content);

	}

	@Test
	public void testDoPostUrlEndWithDeleteJob() {
		final MockHttpServletRequest req = new MockHttpServletRequest();
		PBJobStatusRequest jobStatusRequest = PBJobStatusRequest.newBuilder()
				.setJobId(1).build();
		req.setContent(jobStatusRequest.toByteArray());
		final MockHttpServletResponse res = new MockHttpServletResponse();
		req.setRequestURI("/AIMInquiryService/DeleteJob");
		try {
			servlet.doPost(req, res);
			final int status = res.getStatus();
			assertEquals(HttpStatus.SC_OK, status);
			String content = res.getContentAsString();
			assertEquals("", content);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Test
	public void testDoPostUrlEndWithClearjobsUrlEmpty() {
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();
		try {
			servlet.doPost(req, res);
			final int status = res.getStatus();
			assertEquals(status, HttpStatus.SC_METHOD_NOT_ALLOWED);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Test
	public void testDoPostUrlEndWithClearjobsError() throws IOException, ServletException {
		final MockHttpServletRequest req = new MockHttpServletRequest();

		byte[] bytes = PBDeleteJobRequest.newBuilder().setJobId(1).build()
				.toByteArray();

		req.setContent(bytes);
		final MockHttpServletResponse res = new MockHttpServletResponse();
		req.setRequestURI("/AIMInquiryService/clearjobs");

		InquiryServiceServlet inquiryServlet = new InquiryServiceServlet();
		inquiryServlet.doGet(req, res);
		final int status = res.getStatus();
		assertEquals(HttpStatus.SC_INTERNAL_SERVER_ERROR, status);
		String content = res.getContentAsString();
		assertEquals(
				" information: RemoteHost:localhost RemoteAddress:127.0.0.1 RemotePort:80 RemoteUser:null",
				content);

	}

	@Test
	public void testDoPostUrlEndWithClearjobs() throws ServletException {
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();
		req.setRequestURI("/AIMInquiryService/clearjobs");
		try {
			servlet.doGet(req, res);
			final int status = res.getStatus();
			assertEquals(HttpStatus.SC_OK, status);
			String content = res.getContentAsString();
			assertEquals("", content);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void testDoTrace() throws ServletException, IOException {
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();			
			servlet.doTrace(req, res);
			final int status = res.getStatus();
			assertEquals(status, HttpStatus.SC_METHOD_NOT_ALLOWED);			
			
	}
	
	@Test
	public void testDoHead() throws ServletException, IOException {
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();			
			servlet.doHead(req, res);
			final int status = res.getStatus();
			assertEquals(status, HttpStatus.SC_METHOD_NOT_ALLOWED);		
	}	
	
	@Test
	public void testDoPut() throws ServletException, IOException {
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();			
			servlet.doPut(req, res);
			final int status = res.getStatus();
			assertEquals(status, HttpStatus.SC_METHOD_NOT_ALLOWED);		
	}	
	
	@Test
	public void testDoDelete() throws ServletException, IOException {
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();			
			servlet.doDelete(req, res);
			final int status = res.getStatus();
			assertEquals(status, HttpStatus.SC_METHOD_NOT_ALLOWED);		
	}		

}
