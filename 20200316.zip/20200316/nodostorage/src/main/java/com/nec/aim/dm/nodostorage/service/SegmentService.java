package com.nec.aim.dm.nodostorage.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nec.aim.dm.nodostorage.config.ConfigProperties;
import com.nec.aim.dm.nodostorage.exception.NodeStroageException;
import com.nec.aim.dm.nodostorage.manager.NodeStorageManager;
import com.nec.aim.dm.nodostorage.repository.NodeStorageRepository;
import com.nec.aim.dm.nodostorage.segments.SegmentWriter;

import jp.co.nec.aim.message.proto.AIMEnumTypes.SegmentSyncCommandType;
import jp.co.nec.aim.message.proto.AIMMessages.PBDmSyncRequest;


import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class SegmentService {
	
	@Autowired
	NodeStorageRepository nodeStorageRepository;
	
	@Autowired
	ConfigProperties config;
	
	@Transactional
	public Boolean handlePostRequest(PBDmSyncRequest dmSegReq) {
		String changeType = null;
		Long bioId = null;		
		Long segId = null;	
		Boolean result = null;
		try {
			changeType = dmSegReq.getCmd().name().toUpperCase();			
			bioId = Long.valueOf((int)dmSegReq.getBioId());		
			segId = Long.valueOf(dmSegReq.getTargetSegments().getId());			
			SegmentWriter segWriter = null;
			if (changeType.equals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_NEW.name())) { // add segment			
				segWriter = new SegmentWriter(segId, bioId);
				result = Boolean.valueOf(segWriter.writeSegmentHead());
			}  else if (changeType.equals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT.name())) { // update template
				segWriter = NodeStorageManager.getSegmentWriter(segId);
				result = Boolean.valueOf(segWriter.writeTemplate(dmSegReq));				
		    } else if (changeType.equals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_DELETE.name())) { // delete template
		    	segWriter = NodeStorageManager.getSegmentWriter(segId);
		    	String exteralId  = dmSegReq.getTemplateData().getReferenceId();
		    	if (exteralId == null) {
		    		log.error("External ID can't be null for delete template.");
		    		result=  Boolean.FALSE;
		    	}
		    	result = Boolean.valueOf(segWriter.deleteTemplate(segId, bioId, exteralId));
			}			
		} catch (Exception e) {
			throw new NodeStroageException(e);
		}
		return result;		
	}
}
