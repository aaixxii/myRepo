package com.nec.aim.dm.nodostorage.repository;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.nec.aim.dm.nodostorage.entity.SegmentLoading;



@Repository
public class SegmentLoadRepositoryImpl implements SegmentLoadRepository {	
	private static final String getSegmentLoadInfo = "";
	
	
	
	@Autowired
    private JdbcTemplate jdbcTemplate;	

	
	@Override
	public SegmentLoading getSegmentLoading(int storageId, long segId) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}


}
