package com.nec.aim.dm.nodostorage.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.concurrent.ExecutionException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.nec.aim.dm.nodostorage.exception.NodeStroageException;
import com.nec.aim.dm.nodostorage.service.DownloadService;

import lombok.extern.slf4j.Slf4j;



@Controller
@Slf4j
public class DownloadController extends HttpServlet {	
	
	private static final long serialVersionUID = -5673372086651421607L;
	
	@Autowired
	DownloadService downloadService;

	@GetMapping("/seg/{Id}")
	public void downloadSegment(HttpServletRequest req, HttpServletResponse res, @PathVariable("Id") Long segId) throws IOException, InterruptedException, ExecutionException, SQLException {
		//Long segmentId = new Long(req.getPathInfo().substring(1));
		Long segmentId = new Long(segId);
		String rangeStr = req.getHeader("Range");
		if (rangeStr == null || rangeStr.isEmpty()) {		
			throw new NodeStroageException("Http range is not setting in request!");					
		}		
		rangeStr = rangeStr.substring(6, rangeStr.length());
		long posStart = -1, posEnd = -1;		
		 String[] rangeArr = rangeStr.split("-");
		 if (rangeArr.length == 2) {
			 posStart = Long.parseLong(rangeArr[0].trim());
			 posEnd = Long.parseLong(rangeArr[1].trim());
         } else {
        	 posStart = Long.parseLong(rangeArr[0].trim());
         }	
			
		byte[] segmentData = downloadService.download(res,segmentId, posStart, posEnd);
		//byte[] segmentData = "uid dm prototype test".getBytes();
		if (segmentData != null && segmentData.length > 0) {			
			res.setStatus(200);
			//res.setStatus(HttpServletResponse.SC_PARTIAL_CONTENT);
			log.info("Success send segment data to mu, segmentId={}", segmentId);
		} else {
			throw new NodeStroageException("Faild to get segment data");
		}
	}	
}
