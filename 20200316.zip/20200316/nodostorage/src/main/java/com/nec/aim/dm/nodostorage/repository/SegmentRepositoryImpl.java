package com.nec.aim.dm.nodostorage.repository;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.nec.aim.dm.nodostorage.entity.SegmentInfo;


@Repository
public class SegmentRepositoryImpl implements SegmentRepository {
	
	@Autowired
    private JdbcTemplate jdbcTemplate;
	
	//private static final String insertSql = "insert into segments_info(external_id,bio_id_start, bio_id_end, binary_length, record_count, version , update_ts) values (?,?,?,?,?,?,CURRENT_TIMESTAMP()";
	private static final String insertSql = "insert into segments_info(segment_id,bio_id_start,bio_id_end,binary_length, record_count, version , update_ts) values (?,0,0,26,0,0,CURRENT_TIMESTAMP())";			
	private static final String updateSql = "update segments_info set bio_id_start= (CASE bio_id_start WHEN 0 THEN ? ELSE  bio_id_start END), bio_id_end=? ,binary_length=binary_length + 54 + ?, record_count=record_count+1, version =version +1, update_ts =CURRENT_TIMESTAMP() where segment_id =?";
	private static final String updateForSegmentCreatedSql = "update segments_info set bio_id_start=0,bio_id_end=0 ,binary_length=0, record_count=0, version =-1, update_ts =CURRENT_TIMESTAMP() where segment_id =?";	
	private static final String updateAfterDelSql = "update segments_info set binary_length=binary_length-54-36864 , record_count=record_count-1, version =version +1, update_ts =CURRENT_TIMESTAMP() where segment_id =?";
			
	private static final String setFaildSegmentVer = "update segments_info  set version = -9, update_ts =CURRENT_TIMESTAMP() where segment_id =?";
	private static final String setSuccessSegmentVer = "update segments_info  set version = -1, update_ts =CURRENT_TIMESTAMP() where segment_id =?";
	private static final String updateAfterNew = "update segments_info set version = ? where segment_id = ?";
	
	@Override
	public void insertSegment(SegmentInfo segInfo) throws SQLException {
		jdbcTemplate.execute("SET @@autocommit=0");
		jdbcTemplate.update(insertSql, new Object[] {segInfo.getSegmentId()});
		//jdbcTemplate.update(insertSql, new Object[] {segInfo.getExternalId(),segInfo.getBioIdStart(), segInfo.getBioIdEnd(), segInfo.getBinaryLegth(),segInfo.getRecordCount(),segInfo.getVersion()});
	}
	
	@Override
	public void updateSegment(SegmentInfo segInfo) {
		jdbcTemplate.execute("SET @@autocommit=0");
		jdbcTemplate.update(updateSql, new Object[] {segInfo.getBioIdStart(), segInfo.getBioIdEnd(), segInfo.getBinaryLegth(), segInfo.getSegmentId()});		
	}

	
	public void updateForSegmentCreated(SegmentInfo segInfo) {
		jdbcTemplate.execute("SET @@autocommit=0");
		jdbcTemplate.update(updateForSegmentCreatedSql, new Object[] {segInfo.getSegmentId()});		
	}

	@Override
	public void updateSegmentAfterDelete(SegmentInfo segInfo) throws SQLException {
		jdbcTemplate.execute("SET @@autocommit=0");
		jdbcTemplate.update(updateAfterDelSql, new Object[] {segInfo.getSegmentId()});
	}
	
	@Override
	public void setFaildSegmentVer(SegmentInfo segInfo) throws SQLException {
		jdbcTemplate.execute("SET @@autocommit=0");
		jdbcTemplate.update(setFaildSegmentVer, new Object[] {segInfo.getSegmentId()});
	}

	@Override
	public void setSuccessSegmentVer(SegmentInfo segInfo) throws SQLException {
		jdbcTemplate.execute("SET @@autocommit=0");
		jdbcTemplate.update(setSuccessSegmentVer, new Object[] {segInfo.getSegmentId()});
	}

	@Override
	public void updateAfterNew(long version, long segmentId) throws SQLException {
		jdbcTemplate.execute("SET @@autocommit=0");
		jdbcTemplate.update(updateAfterNew, new Object[] {version, segmentId});
	}
}
