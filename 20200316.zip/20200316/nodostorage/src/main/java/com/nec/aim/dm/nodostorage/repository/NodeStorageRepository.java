package com.nec.aim.dm.nodostorage.repository;

import java.sql.SQLException;



public interface NodeStorageRepository {
	public void updateMyInfo()  throws SQLException;
	public void heatbeat() throws SQLException;
}
