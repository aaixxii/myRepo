package com.nec.aim.dm.nodostorage.repository;

import java.sql.SQLException;

import com.nec.aim.dm.nodostorage.entity.SegmentLoading;



public interface SegmentLoadRepository {
	public SegmentLoading getSegmentLoading(int storageId, long segId) throws SQLException;	
}
