package com.nec.aim.dm.nodostorage.segments;

import static com.nec.aim.dm.nodostorage.segments.DmConstants.SEGMENT_HEADER_SIZE;
import static com.nec.aim.dm.nodostorage.segments.DmConstants.SIZE_CHECKSUM;
import static com.nec.aim.dm.nodostorage.segments.DmConstants.SIZE_DELETE_FLAG;
import static com.nec.aim.dm.nodostorage.segments.DmConstants.SIZE_EVENT_ID;
import static com.nec.aim.dm.nodostorage.segments.DmConstants.SIZE_EXTERNAL_ID;
import static com.nec.aim.dm.nodostorage.segments.DmConstants.SIZE_TSZ;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.sql.SQLException;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import org.springframework.beans.factory.annotation.Autowired;

import com.nec.aim.dm.nodostorage.config.ConfigProperties;
import com.nec.aim.dm.nodostorage.manager.NodeStorageManager;
import com.nec.aim.dm.nodostorage.repository.DmConfigRepository;

import jp.co.nec.aim.message.proto.AIMMessages.PBDmSyncRequest;
import jp.co.nec.aim.message.proto.BusinessMessage.PBTemplateInfo;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Data
@Slf4j
public class SegmentWriter {
	private Long segmentId;
	private Long segmentVersion;
	private Long bioIdStart;		
	private ReadWriteLock locker;	
	private boolean corrupted;
	private final Lock readLock; 
    private final Lock writeLock;
    private  File myFile;  
    private int oneTemplateSize;
    
    @Autowired
    ConfigProperties config;
    
    @Autowired
    DmConfigRepository dmConfigRepository;

	
	public SegmentWriter(Long segmentId, Long bioIdStart) throws IOException, SQLException {
		this.segmentId = segmentId;
		this.bioIdStart = bioIdStart;
		this.segmentVersion = 0l;
		this.myFile = new File(config.getPath() + "/" + String.valueOf(this.segmentId));
		this.locker = new ReentrantReadWriteLock();			
		this.readLock = locker.readLock();
		this.writeLock = locker.writeLock();
		this.corrupted = false;			
		this.oneTemplateSize = dmConfigRepository.getOneTempalteSize();		
	}	
	
	public boolean writeSegmentHead()  {
		ByteBuffer segBuffer = ByteBuffer.allocate(DmConstants.SEGMENT_HEADER_SIZE);
		FileOutputStream outputStream = null;
		boolean sucess = false;		
			try {
				outputStream = new FileOutputStream(myFile);				
				segBuffer.position(0);
				segBuffer.putInt(DmConstants.AIM_VERSION);
				segBuffer.putShort(DmConstants.FORMAT_ID);
				segBuffer.putLong(DmConstants.MAX_SEGMENT_SIZE);
				segBuffer.putInt(0); //recordCount
				segBuffer.putLong(segmentVersion);
				NodeStorageManager.saveToQueue(this.segmentId, this);			
				sucess = true;
			} catch (Exception e) {
				log.error(e.getMessage(), e);
				sucess = false;
				myFile.delete();				
			} finally {						
				if (outputStream != null) {
					try {
						outputStream.close();
					} catch (IOException e) {
						log.error(e.getMessage());
						sucess = false;
					}				}									
				segBuffer.clear();
				segBuffer = null;
			}
		return sucess;		
	}
	
	public boolean writeTemplate(PBDmSyncRequest dmSegReq) throws InterruptedException, ExecutionException {
		Callable<Boolean> oneTemplateWrite = () -> {
			long bioId = dmSegReq.getBioId();
			PBTemplateInfo templateInfo = dmSegReq.getTemplateData();
			String externalId = null;
			byte[] templateData = null;
			if (templateInfo.hasReferenceId()) {
				externalId = templateInfo.getReferenceId();
			}
			if (templateInfo.hasData()) {
				templateData = templateInfo.getData().toByteArray();
			}
			if (externalId == null || templateData == null || templateData.length < 0) {
				log.error(externalId == null ? "externalId can't null!" : "template data can't null!");
				return false;
			}
			long segId = dmSegReq.getTargetSegments().getId();
			long segVer = dmSegReq.getTargetSegments().getVersion();
			
			boolean success = false;
			SegmentWriter segWrite = NodeStorageManager.getSegmentWriter(segmentId);
			if (segWrite == null) {
				log.error("SegmentFile is not found! segmentId={}", segmentId);
				return false;
			}
			writeLock.tryLock();			
			try {
				byte[] templateWithHeader = TemplateHeaderHelper.prependHeader(bioId, templateData, externalId, 1);			
				RandomAccessFile randomFile = new RandomAccessFile(myFile, "rw");
				randomFile.seek(14);
				int recordCount = (int)bioId - this.bioIdStart.intValue() + 1;
				randomFile.writeInt( recordCount);
				randomFile.writeLong(segVer);
				int beginPosition = DmConstants.SEGMENT_HEADER_SIZE + (int) ((bioId - this.bioIdStart + 1) * oneTemplateSize) + 1;				
				randomFile.seek(beginPosition);
				randomFile.write(templateWithHeader);
				randomFile.close();				
				log.info("Success saved tempate data to segment file, segmentId={}", segId);

			} finally {
				writeLock.unlock();
			}
			return success;
		};
		return NodeStorageManager.submit(oneTemplateWrite);
	}
	
	public Boolean deleteTemplate(Long segId, Long bioId, String extId)
			throws InterruptedException, ExecutionException, IOException {
		Callable<Boolean> delTemplateTask = () -> {	
			SegmentWriter segWrite = NodeStorageManager.getSegmentWriter(segId);
			if (segWrite == null) {
				log.warn("There are some wrong, the file:{} is not exist!", segId);
				return false;
			}
			
			RandomAccessFile randomFile = null;
			boolean deleted = false;
			writeLock.tryLock();
			try {
				randomFile = new RandomAccessFile(segWrite.getMyFile(), "rw");
				byte b = 1;
				byte[] delFlag = new byte[] { b };				
				int firstSeekPositon = SEGMENT_HEADER_SIZE + SIZE_CHECKSUM;
				randomFile.seek(firstSeekPositon);
				long prePostion = randomFile.getFilePointer();
				long nextPosition = -1;
				boolean finish = false;				
				while (!finish) {
					nextPosition = prePostion + SIZE_TSZ;
					randomFile.seek(nextPosition);
					long templateId = randomFile.readLong();
					if (templateId == bioId) {
						randomFile.write(delFlag);
						deleted = true;
						finish = true;
						break;
					}
					nextPosition = nextPosition + SIZE_DELETE_FLAG + SIZE_EXTERNAL_ID + SIZE_EVENT_ID;
					prePostion = nextPosition;
				}
				if (!finish) {
					log.info("Can't found templateId({}) in this segment({})", bioId, segId);
					deleted = false;
				}				
			} catch (Exception e) {
				deleted = false;
				log.error(e.getMessage(), e);
			} finally {
				writeLock.unlock();
				randomFile.close();
			}
			return  Boolean.valueOf(deleted);
		};
		return NodeStorageManager.submit(delTemplateTask);
	}
	
	public boolean isFileExists(long segmentId) {
		if (this.segmentId == segmentId &&  this.myFile != null && myFile.exists()) {
			return true;
		} else {
			return false;
		}			
	}	
}
