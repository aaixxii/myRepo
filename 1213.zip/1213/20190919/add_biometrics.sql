CREATE DEFINER=`aimuser`@`localhost` PROCEDURE `add_biometrics`(
	IN p_external_id  varchar(64),
	IN p_event_id  bigint(38),
    IN p_container_id  int,
	IN p_biometric_data   MEDIUMBLOB,
	OUT p_biometric_id bigint(38),
    OUT p_seg_id bigint(38),
    OUT p_seg_version bigint(38)
    
)
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN
	DECLARE l_seg_created bigint(38);
    DECLARE r_seg_id bigint(38);
    DECLARE r_seg_version bigint(38);
    DECLARE r_biometric_id bigint(38);
	DECLARE l_count INT;
	DECLARE l_biometrics_id bigint(38);
	DECLARE l_data_len bigint(38);
	DECLARE tmp_container_id bigint(38);
	DECLARE tmp_max_segment_size bigint(38);
	DECLARE seg_semgnet_id bigint(38);
	DECLARE seg_binary_length_compacted bigint(38);
	DECLARE seg_binary_length_uncompacted bigint(38);
	DECLARE seg_record_count bigint(38);
	DECLARE seg_version bigint(38);
	DECLARE seg_revision bigint(38);
	DECLARE seg_bio_id_end bigint(38);
	DECLARE t_error INTEGER DEFAULT 0;
	DECLARE not_found INTEGER DEFAULT 0;
	DECLARE CONTINUE handler FOR SQLEXCEPTION SET t_error=1;
	DECLARE CONTINUE handler FOR NOT found SET not_found=1;  
    SET  @@autocommit=0;
	SELECT Count(c.CONTAINER_ID)
	INTO   l_count
	FROM   CONTAINERS c
	WHERE  c.CONTAINER_ID = P_CONTAINER_ID; 
	IF l_count < 1 THEN  SET t_error=1;
	  SET p_seg_id = 0;
	  SET p_seg_version = 0;
      SET p_biometric_id = 0;
	END IF;    
	SELECT OCTET_LENGTH(p_biometric_data) into l_data_len from dual;  
    
	INSERT INTO PERSON_BIOMETRICS
            (CONTAINER_ID,
             EXTERNAL_ID,
             BIOMETRIC_DATA,
             BIOMETRIC_DATA_LEN,
             REGISTED_TS,
             EVENT_ID)
	VALUES   (p_container_id,
             p_external_id,
             p_biometric_data,
             l_data_len,             
             UNIX_TIMESTAMP(NOW()),
             p_event_id); 
	SELECT max(BIOMETRICS_ID) INTO  l_biometrics_id FROM  PERSON_BIOMETRICS; 
	SET r_biometric_id = l_biometrics_id;
	SELECT CONTAINER_ID,
       MAX_SEGMENT_SIZE
	INTO  tmp_container_id, tmp_max_segment_size
	FROM  CONTAINERS
	WHERE CONTAINER_ID =p_container_id;    
    
	SELECT seg.SEGMENT_ID,
       seg.BINARY_LENGTH_COMPACTED,
       seg.BINARY_LENGTH_UNCOMPACTED,
       seg.RECORD_COUNT,
       seg.VERSION,
       seg.REVISION,
       seg.BIO_ID_END
	INTO seg_semgnet_id, seg_binary_length_compacted,
       seg_binary_length_uncompacted,
       seg_record_count,
	   seg_version, seg_revision, seg_bio_id_end
	FROM SEGMENTS seg
	WHERE CONTAINER_ID = p_container_id
	AND SEGMENT_ID = (SELECT Max(SEGMENT_ID)
					  FROM   SEGMENTS s
					  WHERE  s.CONTAINER_ID = p_container_id);  
    
	IF seg_bio_id_end < l_biometrics_id THEN
	  SET seg_bio_id_end = l_biometrics_id;
	END IF;
   
  IF seg_binary_length_compacted + l_data_len + 54 < tmp_max_segment_size THEN
	UPDATE SEGMENTS
	SET  BINARY_LENGTH_COMPACTED = seg_binary_length_compacted + l_data_len + 54,
	     BINARY_LENGTH_UNCOMPACTED = seg_binary_length_uncompacted + l_data_len + 54,                                  
         RECORD_COUNT = seg_record_count + 1,
         VERSION = seg_version  + 1,
         REVISION = seg_revision + 1,
         BIO_ID_END = seg_bio_id_end
	WHERE SEGMENT_ID = seg_semgnet_id
	AND REVISION = seg_revision;  
	INSERT INTO SEGMENT_CHANGE_LOG
            (SEGMENT_ID,
             SEGMENT_VERSION,
             CHANGE_TYPE,
             BIOMETRICS_ID)
	 VALUES  (seg_semgnet_id,
             seg_version + 1,
              0,
              l_biometrics_id);     
     SET r_seg_id = seg_semgnet_id;
     SET r_seg_version  = seg_version  + 1;
  ELSE
	INSERT INTO SEGMENTS
           (BIO_ID_START,
             BIO_ID_END,
             BINARY_LENGTH_COMPACTED,
             BINARY_LENGTH_UNCOMPACTED,
             RECORD_COUNT,
             VERSION,
             CONTAINER_ID,
             REVISION)
	  VALUES  (l_biometrics_id,
              l_biometrics_id,
              l_data_len + 54 + 26,
              l_data_len + 54 + 26,
              1,
              0,
              p_container_id,
              0 ); 
     SELECT last_insert_id() into r_seg_id;  
	 SET r_seg_version  = 0;
	END IF;        
	SET p_seg_id =r_seg_id;
    SET p_seg_version = r_seg_version;
    SET p_biometric_id = r_biometric_id;
	IF t_error=1 THEN
	   rollback;
	  SET p_seg_id = -1;
	  SET p_seg_version = -1;
      SET p_biometric_id = -1;
   ELSE
     commit;
   END IF; 
END