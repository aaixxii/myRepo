CREATE DEFINER=`aimuser`@`%` PROCEDURE `testTab`(
 IN  p_candidate_containers VARCHAR(1024),
 OUT v_count int,
 OUT v_err int
)
mylab:BEGIN
	DECLARE v_idx INT DEFAULT 999;
	DECLARE v_tmp_str VARCHAR(20);
	DECLARE t_error INTEGER DEFAULT 0;
	DECLARE CONTINUE handler FOR SQLEXCEPTION SET t_error=1;
	DROP TEMPORARY TABLE IF EXISTS arr_container_ids;
	CREATE TEMPORARY table arr_container_ids(id int) engine=innodb; 
	WHILE v_idx > 0 do
          SET v_idx = INSTR(p_candidate_containers,',');
          IF v_idx <=0 then
            INSERT INTO arr_container_ids (id)  VALUES( CAST(p_candidate_containers AS UNSIGNED));  
            SELECT count(id) into v_count from arr_container_ids;
            SET v_err = t_error;
            LEAVE mylab;
		 END IF;
		 SET v_tmp_str = substr(p_candidate_containers,1,v_idx-1);    
		 INSERT INTO arr_container_ids (id)  values( CAST(v_tmp_str AS UNSIGNED));
		 SET p_candidate_containers=substr(p_candidate_containers,v_idx +1 ,LENGTH(p_candidate_containers));             
	END WHILE; 
	SELECT count(id) INTO v_count from arr_container_ids;
END