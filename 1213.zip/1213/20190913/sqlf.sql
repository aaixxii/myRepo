use aimdb;
call check_container_formats(1, '1,2,3', @xia);

call testTab('1123,4,345', @xia);
select @xia;
select * from arr_container_ids;
select '1,2,3';

drop table if exists  pre_person;
create table `person` (
  `id` int(11)primary key NOT NULL DEFAULT '0',
  `age` int(11) DEFAULT NULL,
  `name` varchar(25) not null
) engine=innodb default charset=utf8;
insert into person values(1,1,'张三'),(2,2,'李四'),(3,3,'王五'),(4,4,'赵六'),(5,5,'许仙');

call sp_test();

set @@autocommit=0;

show variables like "autocommit"; 