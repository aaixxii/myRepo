CREATE DEFINER=`aimuser`@`%` PROCEDURE `add_biometrics`(
	IN p_external_id  varchar(64),
	IN p_event_id  int,
    IN  p_container_id  int,
	IN p_biometric_data   MEDIUMBLOB,
   -- OUT p_seg_id  int,
   -- OUT p_seg_version int,
	-- OUT p_biometric_id int,
    out p_seg_created int
)
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN
	DECLARE l_seg_created INT;
	DECLARE l_count INT;
	DECLARE l_biometrics_id INT;
	DECLARE l_data_len INT;
	DECLARE tmp_container_id INT;
	DECLARE tmp_max_segment_size LONG;
	DECLARE seg_semgnet_id LONG;
	DECLARE seg_binary_length_compacted LONG;
	DECLARE seg_binary_length_uncompacted LONG;
	DECLARE seg_record_count LONG;
	DECLARE seg_version LONG;
	DECLARE seg_revision LONG;
	DECLARE seg_bio_id_end LONG;
	DECLARE t_error INTEGER DEFAULT 0;
	DECLARE not_found INTEGER DEFAULT 0;
	DECLARE CONTINUE handler FOR SQLEXCEPTION SET t_error=1;
	DECLARE CONTINUE handler FOR NOT found SET not_found=1;  
    
	SELECT Count(c.CONTAINER_ID)
	INTO   L_COUNT
	FROM   CONTAINERS c
	WHERE  c.CONTAINER_ID = P_CONTAINER_ID; 
	IF l_count < 1 THEN  SET t_error=1;SET p_seg_created =0;END IF;    
	SELECT OCTET_LENGTH(p_biometric_data) into l_data_len from dual;  
    
	INSERT INTO PERSON_BIOMETRICS
            (CONTAINER_ID,
             EXTERNAL_ID,
             BIOMETRIC_DATA,
             BIOMETRIC_DATA_LEN,
             REGISTED_TS,
             EVENT_ID)
	VALUES   (P_CONTAINER_ID,
             P_EXTERNAL_ID,
             P_BIOMETRIC_DATA,
             L_DATA_LEN,
             Get_epoch_time_num(),
             P_EVENT_ID ); 
	SELECT Last_insert_id() INTO  L_BIOMETRICS_ID FROM   PERSON_BIOMETRICS; 
	
	SELECT CONTAINER_ID,
       MAX_SEGMENT_SIZE
	INTO  TMP_CONTAINER_ID, TMP_MAX_SEGMENT_SIZE
	FROM  CONTAINERS
	WHERE CONTAINER_ID = P_CONTAINER_ID;  
    
	SELECT seg.SEGMENT_ID,
       seg.BINARY_LENGTH_COMPACTED,
       seg.BINARY_LENGTH_UNCOMPACTED,
       seg.RECORD_COUNT,
       seg.VERSION,
       seg.REVISION,
       seg.BIO_ID_END
	INTO SEG_SEMGNET_ID, SEG_BINARY_LENGTH_COMPACTED,
       SEG_BINARY_LENGTH_UNCOMPACTED,
       SEG_RECORD_COUNT,
	   SEG_VERSION, SEG_REVISION, SEG_BIO_ID_END
	FROM SEGMENTS seg
	WHERE CONTAINER_ID = P_CONTAINER_ID
	AND SEGMENT_ID = (SELECT Max(SEGMENT_ID)
					  FROM   SEGMENTS s
					  WHERE  s.CONTAINER_ID = P_CONTAINER_ID);  
    
	IF seg_bio_id_end < l_biometrics_id THEN
	  SET seg_bio_id_end = l_biometrics_id;
	END IF;
   
  IF seg_binary_length_compacted + l_data_len + 54 < tmp_max_segment_size THEN
	UPDATE SEGMENTS
	SET  BINARY_LENGTH_COMPACTED = SEG_BINARY_LENGTH_COMPACTED + L_DATA_LEN + 54,
	     BINARY_LENGTH_UNCOMPACTED = SEG_BINARY_LENGTH_UNCOMPACTED + L_DATA_LEN + 54,                                  
         RECORD_COUNT = SEG_RECORD_COUNT + 1,
         VERSION = SEG_VERSION + 1,
         REVISION = SEG_VERSION + 1,
         BIO_ID_END = SEG_BIO_ID_END
	WHERE SEGMENT_ID = SEG_SEMGNET_ID
	AND REVISION = SEG_REVISION;  
	INSERT INTO SEGMENT_CHANGE_LOG
            (SEGMENT_ID,
             SEGMENT_VERSION,
             CHANGE_TYPE,
             BIOMETRICS_ID)
	 VALUES  ( SEG_SEMGNET_ID,
              SEG_VERSION + 1,
              0,
              P_BIOMETRIC_ID ); 
     SET l_seg_created = 0;      
  ELSE
	INSERT INTO SEGMENTS
           (BIO_ID_START,
             BIO_ID_END,
             BINARY_LENGTH_COMPACTED,
             BINARY_LENGTH_UNCOMPACTED,
             RECORD_COUNT,
             VERSION,
             CONTAINER_ID,
             REVISION)
	  VALUES  ( L_BIOMETRICS_ID,
              L_BIOMETRICS_ID,
              L_DATA_LEN + 54 + 26,
              L_DATA_LEN + 54 + 26,
              1,
              0,
              P_CONTAINER_ID,
              0 ); 
     SELECT last_insert_id() into l_seg_created;    
	END IF;        
	SET p_seg_created =l_seg_created;
	IF t_error=1 THEN
	   rollback;
	  SET p_seg_created = -1;
   ELSE
     commit;
   END IF; 
END