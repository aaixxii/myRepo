#create aimdb user

CREATE USER 'aimuser'@'%' IDENTIFIED BY 'aimuser@SV06';
GRANT ALL PRIVILEGES ON *.* TO 'aimuser'@'%' WITH GRANT OPTION;
FLUSH PRIVILEGES;

