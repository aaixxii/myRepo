
SOURCE ddl/create_tab.sql
SOURCE ddl/create_con.sql
SOURCE ddl/create_idx.sql
SOURCE ddl/create_seq.sql
SOURCE ddl/create_typ.sql
SOURCE ddl/log.pks
SOURCE ddl/log.pkb
SOURCE ddl/match_manager.pks
SOURCE ddl/match_manager.pkb
SOURCE ddl/data_manager.pks
SOURCE ddl/data_manager.pkb
SOURCE ddl/create_trigger.sql
SOURCE seed/seed.sql






