

SOURCE./insert_format_types.sql

SOURCE./insert_inquiry_traffic.sql

SOURCE./insert_function_types.sql

SOURCE./insert_scopes.sql

SOURCE./insert_containers.sql

SOURCE./insert_high_level_service_layouts.sql

SOURCE./insert_system_init.sql

SOURCE./insert_extract_complete_count.sql




