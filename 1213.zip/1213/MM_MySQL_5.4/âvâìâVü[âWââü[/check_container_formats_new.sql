﻿CREATE DEFINER = `aimuser`@`%` PROCEDURE `check_container_formats_new` (IN p_function_id int,
IN p_candidate_containers varchar(1024))
READS SQL DATA
my_label:
  BEGIN
    -- p_candidate_containers="1,2,3,321,322,323"；     
    DECLARE l_actual_format_name varchar(255);
    DECLARE l_target_format_name varchar(255);
    DECLARE l_target_format_id int;
    DECLARE l_function_name varchar(20);
    DECLARE v_idx int DEFAULT 999;
    DECLARE v_tmp_str varchar(20);
    DECLARE v_contaier_id int;
    DECLARE v_format_id int;
    DECLARE f_contaier_id int;
    DECLARE f_format_id int;
    DECLARE t_error integer DEFAULT 0;
    DECLARE t_err_msg varchar(2048);
    --  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1;
    -- DROP TEMPORARY TABLE IF EXISTS arr_container_ids;
    -- create temporary table arr_container_ids(id int  NOT NULL PRIMARY KEY UNIQUE) engine=memory; 
    WHILE v_idx > 0 DO
      SET v_idx = INSTR(p_candidate_containers, ',');
      SET v_tmp_str = SUBSTR(p_slb_matrix, 0, t_idx - 1);
      SET v_contaier_id = CAST(v_tmp_str AS UNSIGNED);
      SET p_candidate_containers = SUBSTR(p_candidate_containers, v_idx + 1, LENGTH(p_candidate_containers));
      SELECT
        c.container_id INTO f_contaier_id
      FROM containers c
      WHERE c.container_id = v_contaier_id;
      IF f_contaier_id IS NULL THEN
        SET t_error = 1;
        SELECT
          $t_err_msg;
      END IF;
      LEAVE my_label;
      SELECT
        f.target_format_id,
        f.function_name INTO l_target_format_id, l_function_name
      FROM function_types f
      WHERE f.function_id = p_function_id;
      SELECT
        c.format_id INTO f_format_id
      FROM containers c
      WHERE c.container_id = v_contaier_id;
      IF STRCMP(f_format_id, l_target_format_id) <> 0 THEN
        SET t_err_msg = "";
        SELECT
          $t_err_msg;
      END IF;
    END WHILE;
  END