CREATE DEFINER = `aimuser`@`%` PROCEDURE `decrease_extract_load_new` (IN p_mu_id int,
IN p_lot_count int,
OUT o_pressure int)
BEGIN
  DECLARE l_count int;
  DECLARE l_pressure int;
  DECLARE t_err int DEFAULT 0;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION SET t_err = 1;
  DECLARE CONTINUE HANDLER FOR SQLWARNING BEGIN
  END;
  SELECT
    COUNT(*) INTO l_count
  FROM mu_extract_load
  WHERE mu_id = p_mu_id;
  IF l_count > 0 THEN
    SELECT
      pressure INTO l_pressure
    FROM mu_extract_load
    WHERE mu_id = p_mu_id FOR UPDATE;
    UPDATE mu_extract_load
    SET pressure = pressure - p_lot_count,
        update_ts = get_epoch_time_num()
    WHERE mu_id = p_mu_id;
    SET o_pressure = l_pressure;
  ELSE
    INSERT INTO mu_extract_load (mu_id, pressure, update_ts)
      VALUES (p_mu_id, 0, get_epoch_time_num());
    SET o_pressure = 0;
    COMMIT;
  END IF;
  IF (l_pressure < 0) THEN
    UPDATE mu_extract_load
    SET pressure = 0,
        update_ts = get_epoch_time_num()
    WHERE mu_id = p_mu_id;
  END IF;
  COMMIT;
  SELECT
    o_pressure;

END