CREATE DEFINER = `aimuser`@`%` PROCEDURE `update_after_planned` (IN p_job_id int,
IN p_container_id int,
IN p_container_job_id int,
IN p_function_id int,
IN p_plans_string longtext,
OUT r_plan_id int)
MODIFIES SQL DATA
SQL SECURITY INVOKER
BEGIN
  DECLARE l_current_time int;
  DECLARE l_failure_count int;
  DECLARE t_error integer DEFAULT 0;
  DECLARE cur CURSOR FOR
  SELECT
    id
  FROM l_container_ids;
  SELECT
    failure_count INTO l_failure_count
  FROM job_queue
  WHERE job_id = p_job_id;
  SET l_failure_count := l_failure_count + 1;
  SET l_current_time := get_epoch_time_num();
  INSERT INTO mu_job_execute_plans (planed_ts,
  container_id,
  function_id,
  PLAN,
  planed_count,
  job_id)
    VALUES (l_current_time, p_container_id, p_function_id, p_plans_string, l_failure_count, p_job_id);
  SELECT
    MAX(plan_id) INTO r_plan_id;
  UPDATE job_queue
  SET job_state = 1,
      assigned_ts = l_current_time
  WHERE job_id = p_job_id
  AND job_state = 0;

  UPDATE container_jobs
  SET job_state = 1,
      plan_id = r_plan_id
  WHERE container_id = p_container_id
  AND container_job_id = p_container_job_id;
  IF t_error = 1 THEN
    ROLLBACK;
  ELSE
    COMMIT;
  END IF;
END