CREATE DEFINER = `aimuser`@`%` PROCEDURE `process_one_mu` (IN p_max_lot int,
OUT l_lot_job_id int,
OUT l_mu_id int,
OUT l_currentlots int)
MODIFIES SQL DATA
SQL SECURITY INVOKER
mylable:
  BEGIN
    DECLARE l_num_extractor int;
    DECLARE l_remain_lots int;
    DECLARE l_one_lot_count int;
    DECLARE l_fe_job_timeout long;
    DECLARE l_current_epoch_time long;
    DECLARE t_error integer DEFAULT 0;
    DECLARE v_idx int DEFAULT 999;
    DECLARE v_tmp_str varchar(20);
    DECLARE v_id int;
    DECLARE notfound int;
    DECLARE tmp_count int;
    DECLARE cur CURSOR FOR
    SELECT
      id
    FROM l_locked_fe_job_ids;
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET notfound = 1;
    DROP TEMPORARY TABLE IF EXISTS l_locked_fe_job_ids;
    CREATE TEMPORARY TABLE l_locked_fe_job_ids (
      id int
    ) ENGINE = MEMORY;

    DROP TEMPORARY TABLE IF EXISTS fe_job_ids_tab;
    CREATE TEMPORARY TABLE fe_job_ids_tab (
      id int
    ) ENGINE = MEMORY;

    SELECT
      mus.mu_id,
      mls.pressure AS currentlots,
      mus.number_of_extractors AS num_extractor,
      p_max_lot - mls.pressure AS remain_lots INTO l_mu_id, l_currentlots, l_one_lot_count, l_remain_lots
    FROM match_units mus,
         mu_extract_load mls
    WHERE mus.mu_id = mls.mu_id
    AND mus.state = 'WORKING'
    AND mus.mu_id = (SELECT
        mu.mu_id,
        ml.pressure AS
        currentlots,
        mu.number_of_extractors AS
        num_extractor,
        p_max_lot - ml.pressure AS
        remain_lots
      FROM match_units mu,
           mu_extract_load ml,
           mu_eligible_functions mf
      WHERE mu.mu_id = ml.mu_id
      AND mu.mu_id = mf.mu_id
      AND mu.state = c_working_state_string
      AND p_max_lot - ml.pressure > 0
      AND mf.function_id = 17)
    ORDER BY ml.pressure, ml.update_ts
    LIMIT 1
    FOR UPDATE OF mus NOWAIT;
    IF notfound = 1 THEN
      ROLLBACK;
      LEAVE mylable;
    END IF;
    INSERT INTO fe_job_ids_tab (id)
      VALUES ((SELECT fj.job_id FROM fe_job_queue fj WHERE fj.job_state = 0 AND fj.priority = 1 ORDER BY fj.priority, fj.failure_count DESC, fj.job_id LIMIT 1));
    SELECT
      COUNT(id) INTO tmp_count
    FROM fe_job_ids_tab;
    IF tmp_count = 1 THEN
      SET l_one_lot_count = 1;
    ELSEIF tmp_count < 1 THEN
      INSERT INTO fe_job_ids_tab (id)
        VALUES ((SELECT fj.job_id FROM fe_job_queue fj WHERE fj.job_state = 0 ORDER BY fj.priority, fj.failure_count DESC, fj.job_id LIMIT 1 FOR UPDATE OF fj NOWAIT));
    END IF;

    SELECT
      COUNT(id) INTO tmp_count
    FROM fe_job_ids_tab;
    IF (tmp_count IS NULL
      OR tmp_count = 0) THEN
      -- dbms_output.Put_line ('no fe_job to assign! return'); 
      ROLLBACK;
      LEAVE mylable;
    END IF;
    SELECT
      top_level_job_timeouts INTO l_fe_job_timeout
    FROM function_types
    WHERE function_id = 17
    AND queue_type = 1;
    SET l_fe_job_timeout = l_fe_job_timeout * l_locked_fe_job_ids.count;
    SET l_current_epoch_time = get_epoch_time_num();
    INSERT INTO fe_lot_jobs (mu_id,
    assigned_ts,
    timeouts)
      VALUES (l_mu_id, l_current_epoch_time, l_fe_job_timeout);

    SELECT
      MAX(lot_job_id) INTO l_lot_job_id
    FROM fe_lot_jobs;
    UPDATE mu_extract_load
    SET pressure = pressure + 1,
        update_ts = l_current_epoch_time
    WHERE mu_id = l_mu_id;
    OPEN cur;
  lable_loop:
    LOOP
      FETCH cur INTO v_id;
      UPDATE fe_job_queue
      SET lot_job_id = l_lot_job_id,
          mu_id = l_mu_id,
          job_state = 1,
          assigned_ts = l_current_epoch_time
      WHERE job_id = v_id;
    END LOOP;
    CLOSE cur;
    IF t_error = 1 THEN
      ROLLBACK;
    ELSE
      COMMIT;
    END IF;
  END