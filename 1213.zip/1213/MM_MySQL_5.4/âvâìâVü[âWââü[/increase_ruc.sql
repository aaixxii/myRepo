CREATE DEFINER = `aimuser`@`%` PROCEDURE `increase_ruc` ()
MODIFIES SQL DATA
SQL SECURITY INVOKER
BEGIN
  DECLARE l_count int;
  DECLARE l_update_count int;
  DECLARE t_error integer DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
  START TRANSACTION;
    SELECT
      COUNT(update_count) INTO l_count
    FROM resource_update_count;
    IF (l_count = 0) THEN
      INSERT INTO resource_update_count (update_count, update_ts)
        VALUES (1, get_epoch_time_num());
    ELSE
      SELECT
        update_count + 1 INTO l_update_count
      FROM resource_update_count
      ORDER BY update_ts DESC LIMIT 1;
      IF l_update_count < 0 THEN
        SET l_update_count := 0;
      END IF;
      UPDATE resource_update_count
      SET update_count = l_update_count,
          update_ts = get_epoch_time_num();
    END IF;
  COMMIT;
END