create or replace PACKAGE body match_manager_api
AS
    c_segment_header_length CONSTANT NUMBER := 26;
    c_template_header_length CONSTANT NUMBER := 54;
    c_search_queue_type CONSTANT NUMBER := 0;
    c_extract_queue_type CONSTANT NUMBER := 1;
    c_dynamic_alloc_type CONSTANT NUMBER := 2;
    c_data_manager_unit_type CONSTANT NUMBER := 2;
    c_working_state_string CONSTANT VARCHAR(10) := 'WORKING';
    c_ring_size CONSTANT NUMBER := 360;
    c_component_type_mu CONSTANT NUMBER := 3;
    c_component_type_mr CONSTANT NUMBER := 2;
    c_component_type_dm CONSTANT NUMBER := 1;

    c_job_state_queued CONSTANT NUMBER := 0;
    c_job_state_working CONSTANT NUMBER := 1;
    c_job_state_done CONSTANT NUMBER := 2;
    
    -- Application exceptions
    extract_reference_not_found EXCEPTION;
    PRAGMA EXCEPTION_INIT(extract_reference_not_found, -20001);

    unsegmented_bins EXCEPTION;
    PRAGMA EXCEPTION_INIT(unsegmented_bins, -20002);

    -- Application exception error numbers.
    c_error_no_such_container CONSTANT NUMBER := -20003;
    c_error_wrong_format CONSTANT NUMBER := -20004;
    c_error_optimistic_lock CONSTANT NUMBER := -20005;
    c_error_null_external_id CONSTANT NUMBER := -20010;
    c_bad_parameters CONSTANT NUMBER := -20011;

    /****************************************************************************************************/
    /************************************** LOCAL PROCEDURES ********************************************/
    /****************************************************************************************************/
     /**
     * Local procedure.
     *
     * This is called prior to the creation of a 1:N search job
     * to ensure that the given list of container IDs is consistent
     * with the defined target container ID of the search function.
     * An application error is raised if there is any inconsistency.
     */
    PROCEDURE check_container_formats
    (
      p_function_id NUMBER,
      p_candidate_containers NUM_TABLE_TYPE
    )
    IS
      l_actual_format_name VARCHAR2(255);
      l_target_format_name VARCHAR2(255);
      l_target_format_id NUMBER;
      l_function_name VARCHAR2(20);
    BEGIN
      SELECT  f.target_format_id, f.function_name
              INTO l_target_format_id, l_function_name
      FROM function_types f
      WHERE f.function_id = p_function_id;

      FOR c1 IN (SELECT candidate_containers.container_id, c.format_id
                FROM format_types f, containers c, (
                    SELECT COLUMN_VALUE container_id FROM TABLE(CAST(p_candidate_containers AS num_table_type))
                    ) candidate_containers
                WHERE candidate_containers.container_id = c.container_id (+)
                AND (c.format_id IS NULL OR c.format_id  != l_target_format_id))
      LOOP
          IF c1.format_id IS NULL
          THEN
              RAISE_APPLICATION_ERROR(c_error_no_such_container, 'The given container ID, ' || c1.container_id
                  || ', does not exist in the system.', TRUE);
          ELSE
            BEGIN
              SELECT format_name INTO l_actual_format_name
              FROM format_types f WHERE f.format_id = c1.format_id;
SELECT
  format_name INTO l_target_format_name
FROM format_types f
WHERE f.format_id = l_target_format_id;

              RAISE_APPLICATION_ERROR(c_error_wrong_format, 'The given container ID, ' || c1.container_id 
                  || ', has a format of ' || l_actual_format_name || '. The function ' || l_function_name 
                  || ' is only compatible with containers of format type ' || l_target_format_name 
                  || '.', TRUE);
            END;
          END IF;
      END LOOP;
    END check_container_formats;
    
    /**
     * get different between the report and latest version
     * by giving p_seg_diffs parameter.
     * return the history template of segment
     * 1. component type is MU and change type is insert 
     * BIOMETRIC_DATA is necessary
     * 2. component type is DM
     * BIOMETRIC_DATA is not necessary 
     * due to DM will get BIOMETRIC_DATA itself
     */


    PROCEDURE get_seg_catchup_info
    (
       p_refcursor OUT sys_refcursor,
       p_component_type IN NUMBER,
       p_seg_diffs IN SEGMENTDIFF_TABLE_TYPE
    )
    IS
      l_segment_diff        SEGMENTDIFF;
      l_history_ids         NUM_TABLE_TYPE;
      l_tmp_change_ids      NUM_TABLE_TYPE;
    BEGIN
      l_history_ids := NUM_TABLE_TYPE();
      
      -- fetch all segment change id that need to catch up
      FOR i IN p_seg_diffs.first .. p_seg_diffs.last
      LOOP
        l_segment_diff := p_seg_diffs(i);
        SELECT segment_change_id BULK COLLECT INTO l_tmp_change_ids
            FROM
              segment_change_log
            WHERE segment_id = l_segment_diff.segmentId
              AND segment_version <= l_segment_diff.latestVersion 
              AND segment_version > l_segment_diff.reportVersion
            ORDER BY segment_change_id, segment_version;
        l_history_ids := l_history_ids MULTISET UNION DISTINCT l_tmp_change_ids;
      END LOOP;
      
      -- if no history id  was found, return directly
      IF (l_history_ids.COUNT() = 0) THEN
          RETURN;
      END IF;
      
      -- component type is MU
      -- if change type is insert, BIOMETRIC_DATA is necessary
      IF (p_component_type = c_component_type_mu) THEN
         OPEN p_refcursor FOR
            SELECT 
              scl.SEGMENT_ID,
              scl.BIOMETRICS_ID,
              scl.SEGMENT_VERSION,
              scl.CHANGE_TYPE,
              CASE WHEN scl.CHANGE_TYPE = 1 THEN NULL ELSE pb.BIOMETRIC_DATA END as BIOMETRIC_DATA,
              pb.EXTERNAL_ID,
              pb.EVENT_ID
            FROM 
              segment_change_log scl,
              person_biometrics pb 
            WHERE scl.segment_change_id IN (SELECT * FROM TABLE(CAST(l_history_ids AS NUM_TABLE_TYPE)))
              AND scl.biometrics_id = pb.biometrics_id (+)
            ORDER BY scl.segment_id, scl.segment_change_id;
        ELSIF (p_component_type = c_component_type_dm) THEN   
          OPEN p_refcursor FOR
            SELECT 
              SEGMENT_ID,
              BIOMETRICS_ID,
              SEGMENT_VERSION,
              CHANGE_TYPE,
              null as BIOMETRIC_DATA,
              null as EXTERNAL_ID,
              null as EVENT_ID
            FROM 
              segment_change_log
            WHERE segment_change_id IN (SELECT * FROM TABLE(CAST(l_history_ids AS NUM_TABLE_TYPE)))
            ORDER BY segment_id, segment_change_id;
        ELSE
            RAISE_APPLICATION_ERROR(c_bad_parameters,'Unsupported component type of input parameter values.',
                 TRUE);
        END IF;
    END get_seg_catchup_info;



    
    /***
     *** Registers new data into the system.
     *** If the container being registered to is covered by a segment set,
     *** Either an existing segment is updated, or a new segment is created.
     */
    FUNCTION add_biometrics
    (
        p_external_id          VARCHAR2,
        p_event_id             NUMBER,
        p_container_id         NUMBER,
        p_biometric_data       BLOB,
        p_seg_id               OUT NUMBER,
        p_seg_version          OUT NUMBER,
        p_biometric_id         OUT NUMBER
    ) RETURN NUMBER
    IS
        l_seg_created     NUMBER;
        l_biometrics_id   NUMBER;
        l_data_len        NUMBER;

        CURSOR affected_container_cur(p_container_id NUMBER) IS
SELECT
  c.*
FROM CONTAINERS c
WHERE c.CONTAINER_ID = p_container_id FOR UPDATE;
        container_rec affected_container_cur%ROWTYPE;

        CURSOR last_seg_cur(c_id_in NUMBER) IS
SELECT
  s.*
FROM segments s
WHERE s.CONTAINER_ID = c_id_in
AND s.segment_id IN (SELECT
    MAX(s2.segment_id)
  FROM segments s2
  WHERE s2.CONTAINER_ID = c_id_in);
        last_seg_rec last_seg_cur%ROWTYPE;

        /*
         * Helper procedure for add_biometrics, handles the case where a new segment has to be created
         * for the template being registered.
         */
        FUNCTION create_new_segment
        (
          p_container_id NUMBER,
          p_biometrics_id NUMBER,
          p_biometric_data_len NUMBER
        ) RETURN NUMBER
        IS
            l_conatiner_id NUMBER;
            l_new_segment_id NUMBER;
        BEGIN
             INSERT INTO segments
             (
                segment_id,
                bio_id_start,
                bio_id_end,
                binary_length_compacted,
                binary_length_uncompacted,
                record_count,
                version,
                container_id,
                revision
              )
              VALUES
               (
                  segment_seq.NEXTVAL,
                  p_biometrics_id,
                  p_biometrics_id,
                  p_biometric_data_len + c_template_header_length + c_segment_header_length,
                  p_biometric_data_len + c_template_header_length + c_segment_header_length,
                  1,
                  0,
                  p_container_id,
                  0
                )
                RETURNING segment_id INTO l_new_segment_id;
          RETURN 1;
        END create_new_segment;

        /*
         * Helper procedure for add_biometrics(), handles the case where the template fits in
         * an existing segment.
         */
        FUNCTION update_existing_segment
        (
          seg_rec last_seg_cur%ROWTYPE,
          p_data_len NUMBER
        ) RETURN NUMBER
        IS
          l_new_binary_len_comp NUMBER;
          l_new_binary_len_uncomp NUMBER;
          l_new_rec_count  NUMBER;
          l_new_version    NUMBER;
          l_new_revision   NUMBER;
          l_new_end        NUMBER;
        BEGIN
          --- When adding data, both compacted and uncompacted binary lengths go up.
          l_new_binary_len_comp := seg_rec.binary_length_compacted + l_data_len
                  + c_template_header_length;
          l_new_binary_len_uncomp := seg_rec.binary_length_uncompacted + l_data_len
                  + c_template_header_length;
          l_new_rec_count  := seg_rec.record_count + 1;
          l_new_version    := seg_rec.version + 1;
          l_new_revision   := seg_rec.revision + 1;

          IF l_biometrics_id > seg_rec.bio_id_end THEN
            l_new_end := l_biometrics_id;
          ELSE
            l_new_end := seg_rec.bio_id_end;
          END IF;

UPDATE segments
SET binary_length_compacted = l_new_binary_len_comp,
    binary_length_uncompacted = l_new_binary_len_uncomp,
    record_count = l_new_rec_count,
    version = l_new_version,
    revision = l_new_revision,
    bio_id_end = l_new_end
WHERE segment_id = seg_rec.segment_id
AND revision = seg_rec.revision;

          --- At this point we expect that we are the only ones updating
          --- the segment, so if the update didn't update any rows
          --- then somebody else got there first.
          --- Current protocol - raise an exception.
          IF (SQL%ROWCOUNT = 0) THEN
            RAISE_APPLICATION_ERROR(c_error_optimistic_lock, 'Segment ' || seg_rec.segment_id 
                || ' changed during update_existing_segment(), orginial revision:' 
                || seg_rec.revision, TRUE);
          END IF;

          --- Reflect changes in the log
INSERT INTO segment_change_log (segment_change_id,
segment_id,
segment_version,
change_type,
biometrics_id)
  VALUES (segment_change_log_seq.NEXTVAL, seg_rec.segment_id, l_new_version, 0, l_biometrics_id);
            
            p_seg_version := l_new_version;
            p_seg_id := seg_rec.segment_id;
            RETURN 0;
        END update_existing_segment;



        
        /*
         * check the container is exist in this system
         */
        PROCEDURE check_container
        (
           p_container_id        NUMBER
        )
        IS
        l_count     NUMBER := 0;
        BEGIN
           SELECT COUNT(c.container_id) into l_count FROM containers c where c.container_id = p_container_id;
           IF l_count <= 0 THEN 
              RAISE_APPLICATION_ERROR(c_error_no_such_container, 'The given container ID, ' || p_container_id
                  || ', does not exist in the system.', TRUE);
           END IF;
        END check_container;
        
    BEGIN
        -- check the container is exist in this system
        check_container(p_container_id);

        l_data_len := Dbms_Lob.getlength(p_biometric_data);

        -- It is crucial for transactional thread safety that this OPEN statement
        -- occur before the INSERT statement below. The OPEN on this cursor
        -- executes a SELECT...FOR UPDATE which attains an exclusive lock
        -- on the row in the SEGMENT_SETS table for the segment set
        -- being updated here.
        OPEN affected_container_cur(p_container_id);

        INSERT INTO person_biometrics
        (
            biometrics_id,
            container_id,
            external_id,
            biometric_data,
            biometric_data_len,
            registed_ts,
            event_id
        )
        VALUES
        (
            person_biometric_seq.NEXTVAL,
            p_container_id,
            p_external_id,
            p_biometric_data,
            l_data_len,
            get_epoch_time_num(),--systimestamp,
            p_event_id
        )
        returning biometrics_id INTO l_biometrics_id;
        
        p_biometric_id := l_biometrics_id;

       LOOP
        -- For every segment set affected by the addition of this new template,
          FETCH affected_container_cur INTO container_rec;
          EXIT WHEN affected_container_cur%NOTFOUND;
          -- Find the 'last' segment in the set
          OPEN last_seg_cur(c_id_in => container_rec.container_id);
          FETCH last_seg_cur INTO last_seg_rec;
          IF last_seg_cur%FOUND
          THEN
              -- there is a last segment (this segment set is not completely empty).
              IF last_seg_rec.binary_length_uncompacted + l_data_len + c_template_header_length
                   < container_rec.max_segment_size
              THEN
                --- If newly added data + overhead will fit in existing segment,
                l_seg_created := update_existing_segment(last_seg_rec, l_data_len);
              ELSE
                --- new template won't fit, need to create a new segment.
                l_seg_created := create_new_segment(container_rec.container_id, l_biometrics_id, l_data_len);
              END IF;
          ELSE
            -- there is no 'last' segment (this segment set is completely empty).
            -- create the first segment in the set.
            l_seg_created := create_new_segment(container_rec.container_id, l_biometrics_id, l_data_len);
          END IF;
          CLOSE last_seg_cur;
       END LOOP;
       CLOSE affected_container_cur;
       
       RETURN  l_seg_created;
    EXCEPTION
        WHEN OTHERS THEN
            RAISE;
    END add_biometrics;

    /***
     *** Deletes registered data from the system. Removes the data from person_biometrics, and
     *** updates all the affected segments.
     */
    FUNCTION delete_biometrics
    (
        p_external_id         VARCHAR2,
        p_event_id            NUMBER,
        p_container_ids       num_table_type,
        p_seg_ids             OUT num_table_type,
        p_seg_versions        OUT num_table_type,
        p_template_ids        OUT num_table_type
    ) RETURN NUMBER
    IS
        l_person_id      NUMBER;
        l_new_binary_len_comp NUMBER;
        l_new_rec_count  NUMBER;
        l_new_version    NUMBER;
        l_new_revision   NUMBER;
        l_deleted_record_count NUMBER := 0;
        l_count          NUMBER :=0;

        TYPE biotype IS REF CURSOR  RETURN person_biometrics%ROWTYPE;
        c0 biotype;
        l_bio_rec person_biometrics%ROWTYPE;
    BEGIN
        p_seg_ids :=      NUM_TABLE_TYPE(); 
        p_seg_versions := NUM_TABLE_TYPE();
        p_template_ids := NUM_TABLE_TYPE();
    
        IF (p_external_id IS NULL) THEN
            RAISE_APPLICATION_ERROR(c_error_null_external_id, 
              'External ID parameter cannot be null', TRUE);
        END IF;

        IF (p_event_id IS NOT NULL) AND (p_container_ids IS NOT NULL) THEN
            --- specific event, specific binlist.
            OPEN c0 FOR
                SELECT *
                FROM  person_biometrics
                WHERE external_id      = p_external_id
                AND   event_id         = p_event_id
                AND   container_id IN (SELECT * FROM TABLE(CAST(p_container_ids as num_table_type)))
            ORDER BY container_id, biometrics_id;
        ELSIF (p_event_id IS NOT NULL) AND (p_container_ids IS NULL) THEN
            --- specific event, all bins.
            OPEN c0 FOR
SELECT
  *
FROM person_biometrics
WHERE external_id = p_external_id
AND event_id = p_event_id
ORDER BY container_id, biometrics_id;
        ELSIF (p_event_id IS NULL) AND (p_container_ids IS NOT NULL) THEN
            --- specific binlist, all events
            OPEN c0 FOR
                SELECT *
                FROM person_biometrics
                WHERE external_id = p_external_id
                AND   container_id IN (SELECT * FROM TABLE(CAST(p_container_ids as num_table_type))) 
            ORDER BY container_id, biometrics_id;
        ELSIF (p_event_id IS NULL) AND (p_container_ids IS NULL) THEN
            --- all events, all bins.
            OPEN c0 FOR
SELECT
  *
FROM person_biometrics
WHERE external_id = p_external_id
ORDER BY container_id, biometrics_id;
        ELSE
            RAISE_APPLICATION_ERROR(c_bad_parameters,'Unsupported combination of input parameter values.',
                 TRUE);
        END IF;
        
        FETCH c0 INTO l_bio_rec;
        WHILE c0%FOUND
        LOOP
DELETE
  FROM person_biometrics
WHERE biometrics_id = l_bio_rec.biometrics_id;
            IF (SQL%ROWCOUNT = 1) THEN
                l_deleted_record_count := l_deleted_record_count + 1;
                FOR c1 IN
                (
                    SELECT segment_id,
                           record_count,
                           binary_length_compacted,
                           version,
                           revision
                    FROM   segments s,
                           containers c
                    WHERE  s.container_id = c.container_id
                    AND   (l_bio_rec.biometrics_id BETWEEN s.bio_id_start AND s.bio_id_end)
                    AND   (c.container_id = l_bio_rec.container_id)
                    FOR    UPDATE
                )
                LOOP
                    /* note that we ONLY update the COMPACTED binary length,
                       because we cannot assume that the space has been reclaimed */
                    l_new_rec_count := c1.record_count - 1;
                    l_new_binary_len_comp := c1.binary_length_compacted - l_bio_rec.biometric_data_len
                        - c_template_header_length;
                    l_new_version   := c1.version + 1;
                    l_new_revision  := c1.revision + 1;

UPDATE segments
SET record_count = l_new_rec_count,
    binary_length_compacted = l_new_binary_len_comp,
    version = l_new_version,
    revision = l_new_revision
WHERE segment_id = c1.segment_id
AND revision = c1.revision;
    
                    IF (SQL%ROWCOUNT = 0) THEN
                         RAISE_APPLICATION_ERROR(c_error_optimistic_lock, 'Segment ' || c1.segment_id 
                             || ' changed during delete_biometrics(), orginial revision:' 
                             || c1.revision, TRUE);
                    END IF;

INSERT INTO segment_change_log (segment_change_id,
segment_id,
segment_version,
change_type,
biometrics_id)
  VALUES (segment_change_log_seq.NEXTVAL, c1.segment_id, l_new_version, 1, l_bio_rec.biometrics_id);
                    
                    -- add into array
                    l_count := l_count + 1;
                    -- deleted template related segment id
                    p_seg_ids.extend;
                    p_seg_ids(l_count) := c1.segment_id;

                    -- deleted template related segment version
                    p_seg_versions.extend;
                    p_seg_versions(l_count) := l_new_version;

                    -- deleted template id
                    p_template_ids.extend;
                    p_template_ids(l_count) := l_bio_rec.biometrics_id;
                END LOOP;
                --- go to the next record
            END IF;
            FETCH c0 INTO l_bio_rec;
        END LOOP;
        CLOSE c0;
        
       -- OPEN p_refcursor FOR
           -- SELECT l_seg_ids as a, l_seg_versions as b, l_template_ids as c FROM DUAL;
      RETURN l_deleted_record_count;
    EXCEPTION
        WHEN OTHERS THEN
            RAISE;
    END delete_biometrics;
    
    /**
      * Helper function to create_fusion_job() that inserts into the fusion_jobs table.
      */
    FUNCTION insert_fusion_job_row
      (
        p_job_id IN NUMBER,
        p_search_request_index IN NUMBER,
        p_function_id IN NUMBER,
        p_inquiry_job_data IN BLOB
      ) RETURN NUMBER
      IS
        l_fusion_job_id NUMBER;
      BEGIN
        INSERT INTO fusion_jobs
        (   fusion_job_id,
            function_id,
            job_id,
            inquiry_job_data,
            search_request_index
          )
          VALUES
          (
            fusion_jobs_seq.NEXTVAL,
            p_function_id,
            p_job_id,
            p_inquiry_job_data,
            p_search_request_index
          )
          RETURNING fusion_job_id INTO l_fusion_job_id;

      RETURN l_fusion_job_id;
    END insert_fusion_job_row;
    
    /**
     * Function to create record in FUSION_JOB and CONTAINER_JOB
     */
    FUNCTION create_container_job
    (
      p_job_id IN NUMBER,
      p_search_request_index IN NUMBER,
      p_function_id IN NUMBER,
      p_inquiry_job_data IN BLOB,
      p_container_list IN NUM_TABLE_TYPE,
      p_empty_job OUT NUMBER,
      p_remain_job OUT NUMBER
    ) RETURN NUMBER
    IS
      l_fusion_job_id NUMBER;
      l_count NUMBER;
      l_container_ids NUM_TABLE_TYPE;

    BEGIN

      -- before anything, check that container formats match
      -- with the function's target format.
      check_container_formats(p_function_id, p_container_list);

      -- first insert: create single row in fusion_jobs table.
      l_fusion_job_id := insert_fusion_job_row(   p_job_id,
                                                  p_search_request_index,
                                                  p_function_id,
                                                  p_inquiry_job_data);
                                                  
      SELECT c.container_id BULK COLLECT INTO l_container_ids FROM containers c 
        WHERE
        c.container_id IN (SELECT * FROM TABLE (CAST(p_container_list AS NUM_TABLE_TYPE)))
        AND EXISTS (SELECT seg.segment_id FROM segments seg WHERE seg.container_id = c.container_id);
        
      -- second insert: create rows for every segment set associated with the list of containers.
      p_empty_job := 1; -- 1 means FUSION_JOBS of l_fusion_job_id has no CONTAINER_JOBS records.
      IF 0 < l_container_ids.Count THEN
        FOR i IN l_container_ids.first..l_container_ids.last LOOP
INSERT INTO container_jobs (container_job_id, fusion_job_id, container_id)
  VALUES (CONTAINER_JOB_SEQ.NEXTVAL, l_fusion_job_id, l_container_ids(i));
        END LOOP;
        p_empty_job := 0; -- 0 means FUSION_JOBS of l_fusion_job_id has some CONTAINER_JOBS records.
      END IF;
      
      -- set remain job = l_container_ids.Count
      p_remain_job := l_container_ids.Count;
      
      RETURN l_fusion_job_id;
      EXCEPTION
        WHEN OTHERS THEN
            RAISE;
    END create_container_job;
    
    /**
     * delete the inquiry job with specified job id
     */
    PROCEDURE delete_job
    (
      p_job_id NUMBER
    )
    IS
      l_function_type_id NUMBER;
      BEGIN
          DELETE FROM job_queue WHERE job_id = p_job_id;
      END;

    /**
     * delete the extract job with specified job id
     */
     PROCEDURE delete_extract_job
     (
        p_extract_job_id NUMBER
     )
     IS
        BEGIN
          DELETE FROM fe_job_queue WHERE job_id = p_extract_job_id;
     END;
     
     /*
      * get the next MR position
      * 1. if map_reducer record is not exist, return null to mr_id
      *    then will retry or fail the container job(Java)
      * 2. if last_assign_mr record is not exist, insert the record 
      *    into the last_assign_mr with MR that own the min ring location
      * 3. get the next MR position with the last assign MR and save the
      *    current checkpoint
      *    lock table LAST_ASSIGNED_MR is necessary due to same MR may be
      *    fetched when mutip-thread reached..
      */
      PROCEDURE get_next_mr_position 
      (
         p_refcursor         OUT sys_refcursor
      )
      IS
        l_last_location   NUMBER;
        l_last_ts         NUMBER;
        l_next_position   NUMBER;
        l_next_mr_id      NUMBER;
        l_seed            NUMBER;
        l_count_last_mr   NUMBER;
        l_count_reducer   NUMBER;
      BEGIN
        -- check MAP_REDUCERS record is exist or not
        -- 1 MR is in working state
        -- 2 RING_LOCATION is not null
        -- if not exist, push null to refcursor and return
        SELECT COUNT(mr_id) into l_count_reducer FROM MAP_REDUCERS
        WHERE 
          STATE = c_working_state_string
          AND RING_LOCATION IS NOT NULL;
        IF (l_count_reducer = 0) THEN
           OPEN p_refcursor FOR
SELECT
  NULL AS mr_id,
  NULL AS CONTACT_URL
FROM DUAL; 
           RETURN;
        END IF;

-- check LAST_ASSIGNED_MR record is exist
-- if not exist, fetch min RING_LOCATION record from MAP_REDUCERS
LOCK TABLE LAST_ASSIGNED_MR IN EXCLUSIVE MODE;
SELECT
  COUNT(ASSIGNED_LOCATION) INTO l_count_last_mr
FROM LAST_ASSIGNED_MR;
        IF(l_count_last_mr = 0) THEN
            SELECT mr_id, ring_location INTO l_next_mr_id, l_next_position
                   FROM MAP_REDUCERS 
                   WHERE STATE = c_working_state_string
                   AND RING_LOCATION IS NOT NULL ORDER BY ring_location
                   FETCH NEXT 1 ROWS ONLY;
INSERT INTO LAST_ASSIGNED_MR (assigned_location, assigned_ts)
  VALUES (l_next_position, get_epoch_time_num());
COMMIT;
            -- at last, return the MR id and it's contact url
            OPEN p_refcursor FOR
SELECT
  mr.mr_id,
  mr.CONTACT_URL
FROM MAP_REDUCERS mr
WHERE mr.mr_id = l_next_mr_id;
            RETURN;
        END IF;

        -- if last checkPoint is exist, then fetch the latest latest MR location
         SELECT assigned_location, assigned_ts INTO l_last_location, l_last_ts
         FROM LAST_ASSIGNED_MR
         ORDER BY assigned_ts DESC FETCH NEXT 1 ROWS ONLY;

        -- fetch next MR location with specified latest MR location
        -- MR state must in working and RING_LOCATION is not null
        SELECT mr_id                                                                                                      AS mr_id,
          ring_location                                                                                                   AS location,
          (-floor((ring_location - (l_last_location + 1)) / c_ring_size) * 360) + (ring_location - (l_last_location + 1)) AS seed
        INTO l_next_mr_id,
          l_next_position,
          l_seed
        FROM MAP_REDUCERS
        WHERE STATE = c_working_state_string
        AND RING_LOCATION IS NOT NULL
        ORDER BY SEED
        FETCH NEXT 1 ROWS ONLY;

-- save the last MR checkpoint
UPDATE LAST_ASSIGNED_MR
SET assigned_location = l_next_position,
    assigned_ts = get_epoch_time_num()
WHERE assigned_location = l_last_location
AND assigned_ts = l_last_ts;
-- let the other transaction find the last MR position
COMMIT;
        
        -- at last, return the MR id and it's contact URL
        OPEN p_refcursor FOR
SELECT
  mr.mr_id,
  mr.CONTACT_URL
FROM MAP_REDUCERS mr
WHERE mr.mr_id = l_next_mr_id;
      END get_next_mr_position;

     /*
      * get_inquiry_distrutor_info
      * get the inquiry distributor job information
      * with the specified job id, function id and
      * container id
      */
      PROCEDURE get_inquiry_distributor_info (
       p_refcursor         OUT sys_refcursor,
       p_job_id            NUMBER,
       p_function_id       NUMBER,
       p_plan_id           NUMBER
      )
      IS
      BEGIN
       OPEN p_refcursor FOR
SELECT
  jq.failure_count,
  fj.search_request_index,
  fj.inquiry_job_data,
  ft.container_job_timeouts,
  GREATEST(jq.max_candidates, nvl(ft.internal_candidate_size, 0)) AS internal_candidate_size,
  cj.container_job_id
FROM job_queue jq,
     fusion_jobs fj,
     function_types ft,
     container_jobs cj
WHERE jq.job_id = fj.job_id
AND fj.function_id = ft.function_id
AND fj.fusion_job_id = cj.fusion_job_id
AND jq.job_id = p_job_id
AND fj.function_id = p_function_id
AND cj.plan_id = p_plan_id;
      END get_inquiry_distributor_info;



     /*
      * update_inquiry_load
      * update_inquiry_load, if the record count is not exist
      * insert new record with specified load, otherwise update
      * the record with specified load
      */
      PROCEDURE update_inquiry_load 
      (
          p_mu_id        in NUMBER,
          p_inquiry_load in NUMBER
      )
      IS
       l_count        NUMBER;
       BEGIN
         --
LOCK TABLE mu_inquiry_load IN EXCLUSIVE MODE;
SELECT
  COUNT(pressure) INTO l_count
FROM mu_inquiry_load
WHERE mu_id = p_mu_id;
         IF(l_count = 0)
         THEN
INSERT INTO mu_inquiry_load (mu_id, pressure, report_ts)
  VALUES (p_mu_id, p_inquiry_load, get_epoch_time_num());
         ELSE
UPDATE mu_inquiry_load
SET pressure = p_inquiry_load,
    report_ts = get_epoch_time_num()
WHERE mu_id = p_mu_id;
         END IF;
COMMIT;
      END update_inquiry_load;

     /*
      * increase_ruc
      * increase the ruc count, if the record count is not exist
      * insert new record with count(1), otherwise increase the 
      * count(count++), if the count is Negative number, set to 0
      * lock table resource_update_count is necessary due to multip
      * thread may be reached..
      */
      PROCEDURE increase_ruc
      IS
       l_count        NUMBER;
       l_update_count NUMBER;
       BEGIN
         LOCK TABLE resource_update_count IN EXCLUSIVE MODE;
SELECT
  COUNT(update_count) INTO l_count
FROM resource_update_count;
         IF(l_count = 0)
         THEN
INSERT INTO resource_update_count (update_count, update_ts)
  VALUES (1, get_epoch_time_num());
         ELSE
           SELECT update_count + 1 into l_update_count FROM resource_update_count ORDER BY update_ts DESC FETCH NEXT 1 ROWS ONLY;
           IF l_update_count < 0 THEN
              l_update_count := 0;
           END IF;
UPDATE resource_update_count
SET update_count = l_update_count,
    update_ts = get_epoch_time_num();
         END IF;
COMMIT;
       END increase_ruc;
       
     /*
      * Helper function that determines what DM URL an MU should download
      * any given segment ID from.
      */
      FUNCTION get_source_url
      (
          p_segment_id in NUMBER
      ) RETURN VARCHAR2
      IS
      BEGIN
        FOR c1 IN
        (
          SELECT dm.contact_url
          FROM data_managers dm, dm_seg_reports dsr, dm_segments ds
          WHERE dm.dm_id = dsr.dm_id
          AND  dm.dm_id = ds.dm_id
          AND dsr.segment_id = p_segment_id
          AND ds.segment_id = p_segment_id
          AND dm.state = c_working_state_string
          AND dsr.status IN (0,1)
          ORDER BY DBMS_RANDOM.RANDOM
        )
        LOOP
          -- this is in the structure of a loop just for convenience.
          -- it will always return the first row if any exist.
          RETURN c1.contact_url;
        END LOOP;
        RETURN NULL;
      END get_source_url;
    
      /*
       * Updates the appropriate timestamps in the mu_contacts, 
       * dm_contacts, mr_contacts table for a given unit.
       */
      PROCEDURE update_contact_times
      (
          p_unit_id IN NUMBER,
          p_unit_type IN NUMBER
      )
      IS
          PRAGMA AUTONOMOUS_TRANSACTION;
          BEGIN
              IF p_unit_type = c_component_type_mu THEN
UPDATE mu_contacts
SET contact_ts = get_epoch_time_num()
WHERE mu_id = p_unit_id;
              ELSIF p_unit_type = c_component_type_dm THEN
UPDATE dm_contacts
SET contact_ts = get_epoch_time_num()
WHERE dm_id = p_unit_id;
              ELSIF p_unit_type = c_component_type_mr THEN
UPDATE mr_contacts
SET contact_ts = get_epoch_time_num()
WHERE mr_id = p_unit_id;
              END IF;
COMMIT;
      END update_contact_times;

      /*
       * init_executing_job_count
       */
      PROCEDURE init_executing_job_count
      AS
      BEGIN
          UPDATE INQUIRY_TRAFFIC it SET
              (JOB_EXEC_COUNT) = (SELECT count(JOB_ID) FROM JOB_QUEUE jq
                  WHERE it.FAMILY_ID = jq.FAMILY_ID AND jq.JOB_STATE = c_job_state_working);
COMMIT;
      END init_executing_job_count;
  
      /*
       * complete_inquiryjob
       */
      FUNCTION complete_inquiryjob
      (
          p_job_id           NUMBER,
          p_container_job_id NUMBER,
          p_sequence         INTEGER,
          p_result BLOB
      )
      RETURN NUMBER
      IS
          l_failure_count NUMBER;
          --l_systimestamp  NUMBER;
          l_remain_jobs   NUMBER;
          v_errcode       NUMBER;
          BEGIN
              SELECT failure_count
              INTO l_failure_count
              FROM job_queue
              WHERE job_id     = p_job_id
              AND job_state    = c_job_state_working
              AND 0            < remain_jobs FOR UPDATE OF remain_jobs WAIT 60;
              
              IF p_sequence    = l_failure_count THEN
                  --l_systimestamp:=get_epoch_time();
UPDATE CONTAINER_JOBS
SET JOB_STATE = c_job_state_done,
    RESULT_TS = get_epoch_time_num(),
    CONTAINER_JOB_RESULT = p_result
WHERE CONTAINER_JOB_ID = p_container_job_id
AND job_state = c_job_state_working;
                  IF 0                   < SQL%ROWCOUNT THEN
                      UPDATE job_queue
                      SET remain_jobs = remain_jobs - 1
                      WHERE job_id    = p_job_id RETURNING remain_jobs
                      INTO l_remain_jobs;
                  ELSE
ROLLBACK;
                      RETURN -3;
                  END IF;
              ELSE
ROLLBACK;
                  RETURN -2;
              END IF;
COMMIT;
              return l_remain_jobs;
              EXCEPTION
                  WHEN NO_DATA_FOUND THEN -- JOB_QUEUE not found
                      RETURN -1;
                  WHEN OTHERS THEN
                      v_errcode   := sqlcode;
                      IF v_errcode = -30006 THEN -- Resource busy, WAIT Timeout
                          RETURN       -4;
                      END IF;
                      RAISE;
          END complete_inquiryjob;
  
    /*
     * force_quit_job
     * inquiry job state is Error or failcount > MaxFailcount
     * insert container_job_failure_reasons, update container_jobs and job_queue
     */
    FUNCTION force_quit_job
    (
        p_code             IN VARCHAR2,
        p_reason           IN VARCHAR2,
        p_failure_time     IN VARCHAR2,
        p_container_job_id IN NUMBER,
        p_segment_id       IN NUMBER,
        p_result IN BLOB)
    RETURN NUMBER
    IS
        l_job_id       NUMBER;
        l_mr_id        NUMBER;
        v_errcode      NUMBER;
        l_container_job_ids      NUM_TABLE_TYPE;
        l_container_job_id       NUMBER;
        
        /*
         * insert_failure_reason
         * insert the container failure reason with some parameter
        */
        PROCEDURE insert_failure_reason 
        (
          p_mr_id            IN  NUMBER,
          p_code             IN  VARCHAR2,
          p_reason           IN  VARCHAR2,
          p_failure_time     IN  VARCHAR2,
          p_container_job_id IN  NUMBER,
          p_segment_id       IN  NUMBER
        )
        IS
        l_segment_id  NUMBER;
        BEGIN
         IF p_segment_id IS NOT NULL OR p_segment_id        > 0 THEN
           l_segment_id := p_segment_id;
         ELSE
           l_segment_id := NULL;
         END IF;

INSERT INTO container_job_failure_reasons (failure_id,
code,
reason,
failure_time,
mr_id,
container_job_id,
SEGMENT_ID)
  VALUES (FAILURE_ID_SEQ.NEXTVAL, p_code, p_reason, p_failure_time, p_mr_id, p_container_job_id, l_segment_id);
        END insert_failure_Reason;
    BEGIN
        SELECT jq.job_id , cj.mr_id
            INTO l_job_id, l_mr_id
        FROM job_queue jq,
          fusion_jobs fj,
          container_jobs cj
          WHERE jq.job_id        = fj.job_id
          AND fj.fusion_job_id   = cj.fusion_job_id
          AND cj.container_job_id= p_container_job_id
          AND 0                  < jq.remain_jobs
          AND jq.job_state       < c_job_state_done FOR UPDATE OF remain_jobs NOWAIT;

UPDATE container_jobs
SET job_state = c_job_state_done,
    CONTAINER_JOB_RESULT = p_result,
    result_ts = get_epoch_time_num()
WHERE container_job_id = p_container_job_id
AND job_state < c_job_state_done;

        -- insert the current container job failure reason
        insert_failure_Reason(l_mr_id,  p_code,  p_reason, p_failure_time, p_container_job_id, p_segment_id);

        -- collect the other container job id to l_container_job_ids
        SELECT cj.container_job_id BULK COLLECT INTO l_container_job_ids
        FROM 
          job_queue jq,
          fusion_jobs fj, 
          container_jobs cj
        WHERE
          jq.job_id = l_job_id
          AND jq.job_id = fj.job_id 
          AND fj.fusion_job_id = cj.fusion_job_id
          AND cj.container_job_id <> p_container_job_id;

        IF l_container_job_ids.COUNT() > 0 THEN
          FOR i IN l_container_job_ids.first .. l_container_job_ids.last
          LOOP
            l_container_job_id := l_container_job_ids(i);
UPDATE container_jobs
SET result_ts = get_epoch_time_num(),
    job_state = c_job_state_done
WHERE container_job_id = l_container_job_id;
            -- insert into container failure reason with other container job ids that belong to the same top level job
            insert_failure_Reason(NULL, p_code , 'Container job failed due to the related Container job:' || p_container_job_id || ' has some error.', p_failure_time, l_container_job_id, NULL);
          END LOOP;
        END IF;

-- increase the job_queue failure count
UPDATE job_queue
SET remain_jobs = 0,
    failure_count = failure_count + 1
WHERE job_id = l_job_id;
COMMIT;
        return l_job_id;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN -- JOB_QUEUE not found
            RETURN -1;
        WHEN OTHERS THEN
            v_errcode   := sqlcode;
            IF v_errcode = -00054 THEN     -- ORA-00054: resource busy and acquire with NOWAIT specified or timeout expired
                                           --  ORA-30006: resource busy; acquire with WAIT timeout expired
            RETURN       -2;
    END IF;
        RAISE;
    END force_quit_job;

  
     /**
      * retry_job
      */
      FUNCTION retry_job 
      ( 
          p_job_id NUMBER 
      ) 
      RETURN NUMBER 
      IS 
        l_container_jobs NUM_TABLE_TYPE; 
        l_job_exec_count NUMBER; 
        l_remain_jobs NUMBER;
        l_family_id NUMBER;
      BEGIN        
      SELECT cj.container_job_id bulk collect 
        INTO   l_container_jobs 
        FROM   job_queue jq, 
               fusion_jobs fj, 
               container_jobs cj
        WHERE  jq.job_state < c_job_state_done 
        AND    0 < jq.remain_jobs 
        AND    jq.job_id = fj.job_id 
        AND    fj.fusion_job_id = cj.fusion_job_id 
        AND    jq.job_id = p_job_id FOR UPDATE OF jq.job_state, 
               jq.failure_count, 
               jq.submission_ts skip LOCKED; 
         
      l_remain_jobs:= l_container_jobs.count;
      IF(0 < l_container_jobs.count) THEN
        UPDATE container_jobs
        SET mr_id =NULL,
            assigned_ts =NULL,
            job_state =c_job_state_queued,
            plan_id =NULL,
            result_ts =NULL,
            container_job_result =NULL
        WHERE container_job_id IN
            (SELECT *
             FROM TABLE(Cast(l_container_jobs AS NUM_TABLE_TYPE)));

UPDATE job_queue
SET job_state = c_job_state_queued,
    failure_count = failure_count + 1,
    assigned_ts = NULL,
    remain_jobs = l_remain_jobs
WHERE job_id = p_job_id;


SELECT
  jq.family_id INTO l_family_id
FROM job_queue jq
WHERE jq.job_id = p_job_id; 

        UPDATE inquiry_traffic
        SET job_exec_count=job_exec_count-1
        WHERE family_id = l_family_id returning job_exec_count INTO l_job_exec_count;
        
        IF l_job_exec_count <0 THEN 
          Init_executing_job_count();
SELECT
  job_exec_count INTO l_job_exec_count
FROM inquiry_traffic
WHERE family_id = l_family_id;
        END IF;      
      END IF;
COMMIT; 
        RETURN l_job_exec_count; 
      EXCEPTION 
      WHEN no_data_found THEN -- JOB_QUEUE which has container_jobs not found 
        RETURN -1;            -- return -1 
      WHEN OTHERS THEN 
        RAISE; 
      END retry_job; 
      
    PROCEDURE get_container_results
    (
        p_success_refcursor OUT SYS_REFCURSOR,
        p_job_id IN NUMBER
    )
    IS
    BEGIN
        OPEN p_success_refcursor FOR
SELECT
  cj.container_job_result
FROM container_jobs cj,
     fusion_jobs fj,
     job_queue jq
WHERE cj.fusion_job_id = fj.fusion_job_id
AND fj.job_id = jq.job_id
AND jq.job_id = p_job_id
AND cj.job_state = c_job_state_done
AND jq.job_state = c_job_state_working
ORDER BY cj.container_job_id;

    EXCEPTION
      WHEN OTHERS THEN
        RAISE;
    END get_container_results;
  
      /*
       * Moves a top-level job into the completed state
       */
      FUNCTION complete_top_level_job 
      ( 
          p_job_id NUMBER, 
          p_failed  INTEGER , 
          p_result BLOB) 
      RETURN NUMBER 
      IS 
        --l_epochtime      NUMBER; 
        l_family_id      NUMBER; 
        l_job_exec_count NUMBER; 
      BEGIN 
        --l_epochtime:=Get_epoch_time(); 
        SELECT jq.family_id 
        INTO   l_family_id 
        FROM   job_queue jq 
        WHERE  jq.job_id=p_job_id FOR UPDATE OF jq.family_id wait 60; 
         
        UPDATE job_queue j 
        SET    "RESULT" = p_result, 
               result_ts = get_epoch_time_num(), 
               failed_flag = p_failed, 
               job_state = c_job_state_done 
        WHERE  j.job_id = p_job_id; 
         
        UPDATE inquiry_traffic 
        SET       job_exec_count=job_exec_count-1,
        		  JOB_COMPLETE_COUNT = JOB_COMPLETE_COUNT + 1 
        WHERE     family_id = l_family_id 
        returning job_exec_count 
        INTO      l_job_exec_count; 
         
        IF l_job_exec_count < 0 THEN 
          Init_executing_job_count();
SELECT
  job_exec_count INTO l_job_exec_count
FROM inquiry_traffic
WHERE family_id = l_family_id;
        END IF;
COMMIT; 
        RETURN l_job_exec_count; 
      END complete_top_level_job; 
    
     /***
      ***
      *** Get top job info for create plan
      ***
      */       
   PROCEDURE get_job_info_for_create_plans
    (  limited_job_ids IN NUM_TABLE_TYPE, 
       p_refcursor     OUT SYS_REFCURSOR) 
   AS 
   BEGIN 
    OPEN p_refcursor FOR 
      SELECT jq.job_id, 
             jq.family_id,
             fq.function_id, 
             ssj.container_id,
             ssj.container_job_id
      FROM   job_queue jq, 
             fusion_jobs fq, 
             container_jobs ssj           
      WHERE  jq.job_id = fq.job_id 
             AND fq.fusion_job_id = ssj.fusion_job_id 
             AND jq.job_state = c_job_state_queued              
             AND ssj.container_id != (select container_id from segment_defragmentation) 
             AND jq.job_id IN (SELECT * 
                               FROM   TABLE(Cast(limited_job_ids AS 
                                                 NUM_TABLE_TYPE)) 
                              ) 
      ORDER  BY priority, 
                failure_count DESC, 
                job_id ;    
   EXCEPTION 
   WHEN OTHERS THEN    
  dbms_output.Put_line ('Error Code:' 
                        || To_char(SQLCODE) 
                        || '  Error Message:' 
                        || SQLERRM);
  RAISE; 
  END get_job_info_for_create_plans;       
    
      /***
       ***
       *** Get payload and ability of mu
       ***
      */
      
  PROCEDURE get_mu_pressure_ability
    (  p_mu_ids IN num_table_type, 
       p_refcursor OUT SYS_REFCURSOR
    )
    AS     
    BEGIN 
        OPEN p_refcursor FOR 
          SELECT ml.mu_id, 
                 ml.pressure, 
                 mu.number_of_matchers * mu.reported_performance_factor as ability,
                 ml.report_ts 
         FROM   mu_inquiry_load ml, 
                match_units mu 
          WHERE  ml.mu_id = mu.mu_id 
               AND mu.state = c_working_state_string
                 AND mu.mu_id IN (SELECT * 
                              FROM   TABLE(Cast(p_mu_ids AS NUM_TABLE_TYPE)))
           ORDER BY ml.mu_id; 
    EXCEPTION 
      WHEN OTHERS THEN                dbms_output.Put_line ('Error Code:' 
                                   || To_char(SQLCODE) 
                                   || '  Error Message:' 
                                   || SQLERRM); 
    RAISE;
  END get_mu_pressure_ability;   
      
    
    /***
    ***
    *** Get new mu_segment_maps by container
    ***
    */     
     PROCEDURE get_new_mu_seg_maps
    (  p_container_id IN NUMBER, 
       p_function_id  IN NUMBER, 
       p_refcursor    OUT SYS_REFCURSOR
    ) 
    AS 
    BEGIN 
      OPEN p_refcursor FOR
SELECT
  map.mu_id,
  map.segment_id,
  seg.version AS segment_version,
  seg.container_id,
  mf.function_id
FROM match_units mu,
     segments seg,
     mu_eligible_functions mf,
     mu_seg_reports map
WHERE mu.mu_id = map.mu_id
AND seg.segment_id = map.segment_id
AND mu.mu_id = mf.mu_id
AND mu.state = c_working_state_string
AND map.status <= 1
AND mf.function_id = p_function_id
AND seg.container_id = p_container_id
AND seg.container_id != (SELECT
    container_id
  FROM segment_defragmentation);      
      EXCEPTION 
      WHEN OTHERS THEN 
                dbms_output.Put_line ('Error Code:' 
                                     || To_char(SQLCODE) 
                                     || '  Error Message:' 
                                     || SQLERRM); 
               RAISE; 
    END get_new_mu_seg_maps; 
   
  
    /***
    ***
    *** assign one lot job to mu
    ***
    */
     PROCEDURE process_one_mu_lot
     ( 
          p_mu_id IN NUMBER,
           p_number_of_extractors IN NUMBER,
          l_lot_job_id OUT NUMBER
     )
        AS        
        l_locked_fe_job_ids num_table_type;
        l_one_lot_count         NUMBER;
        l_mu_extract_load_count NUMBER;
        l_fe_job_timeout        NUMBER;   
        l_current_epoch_time    NUMBER;
        BEGIN 
        IF( p_mu_id <= 0 OR  p_number_of_extractors <= 0 )
       THEN 
        dbms_output.Put_line ('input pramarameter is incorrect! return'); 
       RETURN; 
       END IF; 
      l_one_lot_count := p_number_of_extractors; 
    
    SELECT job_id bulk collect INTO l_locked_fe_job_ids FROM  (
             SELECT job_id, Row_number() over(ORDER BY priority, failure_count DESC, job_id) AS rn
              FROM  fe_job_queue
              WHERE job_state = c_job_state_queued
              AND   priority  = 1
           ) WHERE  rn <= 1;
   IF l_locked_fe_job_ids.count = 1 then 
    l_one_lot_count := 1;     
    ELSIF l_locked_fe_job_ids.count < 1 then 
          SELECT job_id bulk collect INTO l_locked_fe_job_ids FROM  (
             SELECT job_id, Row_number() over(ORDER BY priority, failure_count DESC, job_id) AS rn
              FROM  fe_job_queue
              WHERE job_state = c_job_state_queued             
           ) WHERE  rn <= l_one_lot_count;             
    END IF;
       
       IF ( l_locked_fe_job_ids IS NULL  OR    
        l_locked_fe_job_ids.count = 0 )
        THEN 
        dbms_output.Put_line ('no fe_job to assign! return');        
        return; 
       END IF;
SELECT
  top_level_job_timeouts INTO l_fe_job_timeout
FROM function_types
WHERE function_id = 17
AND queue_type = 1;    
      l_fe_job_timeout := l_fe_job_timeout * l_locked_fe_job_ids.count; 
      l_current_epoch_time := get_epoch_time_num(); 
      INSERT INTO fe_lot_jobs 
                  ( 
                              lot_job_id, 
                              mu_id, 
                              assigned_ts, 
                              timeouts 
                  ) 
                  VALUES 
                  ( 
                              fe_lot_job_seq.NEXTVAL, 
                              p_mu_id, 
                              l_current_epoch_time, 
                              l_fe_job_timeout 
                  ) 
      returning   lot_job_id 
      INTO        l_lot_job_id;

UPDATE mu_extract_load
SET pressure = pressure + 1,
    update_ts = l_current_epoch_time
WHERE mu_id = p_mu_id;    
     
      FOR i IN l_locked_fe_job_ids.first..l_locked_fe_job_ids.last 
      LOOP
UPDATE fe_job_queue
SET lot_job_id = l_lot_job_id,
    mu_id = p_mu_id,
    job_state = c_job_state_working,
    assigned_ts = l_current_epoch_time
WHERE job_id = l_locked_fe_job_ids(i);    
      END LOOP;    
      EXCEPTION 
      WHEN OTHERS THEN       
       dbms_output.Put_line ('Error Code:' 
       || To_char(SQLCODE) 
       || '  Error Message:' 
       || SQLERRM); 
       RAISE;       
    END process_one_mu_lot;  
    
   /***
    *** pickup one mu from match_unit 
    *** and assign one lot job to it
    ***
    */   
    PROCEDURE process_one_mu 
      (
        p_max_lot IN NUMBER,         
        l_lot_job_id OUT NUMBER,
        l_mu_id  OUT NUMBER,
        l_currentlots  OUT NUMBER
      )
      AS 
        l_num_extractor NUMBER;
        l_remain_lots NUMBER;     
        l_one_lot_count NUMBER;      
        l_fe_job_timeout NUMBER;   
        l_current_epoch_time  NUMBER; 
        l_locked_fe_job_ids num_table_type;
     BEGIN     
       SELECT mus.mu_id, 
                 mls.pressure  AS currentlots, 
                 mus.number_of_extractors  AS num_extractor, 
                 p_max_lot - mls.pressure  AS remain_lots 
        INTO     l_mu_id ,l_currentlots,l_one_lot_count,l_remain_lots       
          FROM   match_units mus, 
                 mu_extract_load mls 
          WHERE  mus.mu_id = mls.mu_id 
                 AND mus.state = c_working_state_string
                 AND mus.mu_id = (SELECT mu_id 
                              FROM   (SELECT mu.mu_id, 
                                             ml.pressure 
                                             AS 
                                             currentlots, 
                                             mu.number_of_extractors 
                                             AS 
                                             num_extractor, 
                                             p_max_lot - ml.pressure 
                                             AS 
                                             remain_lots, 
                                             row_number() 
                                               over ( 
                                                 ORDER BY ml.pressure , 
                                               ml.update_ts) AS  rn                                             
                                      FROM   match_units mu, 
                                             mu_extract_load ml, 
                                             mu_eligible_functions mf 
                                      WHERE  mu.mu_id = ml.mu_id 
                                             AND mu.mu_id = mf.mu_id 
                                             AND mu.state = c_working_state_string 
                                             AND  p_max_lot - ml.pressure > 0
                                             AND mf.function_id = 17) 
                              WHERE  rn <= 1) 
                              for update of mus.mu_id,mls.mu_id NOWAIT;     
       IF SQL%NOTFOUND THEN
       dbms_output.put_line ('Not data found for get first mu lots ! return');
ROLLBACK; 
       return;
       end IF; 
       
      SELECT fjq.job_id bulk collect 
      INTO   l_locked_fe_job_ids 
      FROM   fe_job_queue fjq 
      WHERE  fjq.job_id = 
             ( 
                    SELECT job_id 
                    FROM   ( 
                                    SELECT   fj.job_id, 
                                             Row_number() over( ORDER BY fj.priority, fj.failure_count DESC, fj.job_id) AS rn 
                                    FROM     fe_job_queue fj 
                                    WHERE    fj.job_state = c_job_state_queued
                                  AND      fj.priority  = 1)                                    
                    WHERE  rn <= 1) FOR UPDATE OF fjq.job_id NOWAIT; 
    IF l_locked_fe_job_ids.count = 1 then 
    l_one_lot_count := 1;    
    ELSIF l_locked_fe_job_ids.count < 1 then 
      SELECT fjq.job_id bulk collect 
      INTO   l_locked_fe_job_ids 
      FROM   fe_job_queue fjq 
      WHERE  fjq.job_id IN 
             ( 
                    SELECT job_id 
                    FROM   ( 
                                    SELECT   fj.job_id, 
                                             Row_number() over( ORDER BY fj.priority, fj.failure_count DESC, fj.job_id) AS rn 
                                    FROM     fe_job_queue fj 
                                    WHERE    fj.job_state = c_job_state_queued)                                    
                    WHERE  rn <= l_one_lot_count) FOR UPDATE OF fjq.job_id NOWAIT; 
    END IF;       
       IF ( l_locked_fe_job_ids IS NULL  OR    
        l_locked_fe_job_ids.count = 0 )
        THEN 
        dbms_output.Put_line ('no fe_job to assign! return');
ROLLBACK; 
        return;      
       END IF;
SELECT
  top_level_job_timeouts INTO l_fe_job_timeout
FROM function_types
WHERE function_id = 17
AND queue_type = 1;    
      l_fe_job_timeout := l_fe_job_timeout * l_locked_fe_job_ids.count; 
      l_current_epoch_time := get_epoch_time_num(); 
      INSERT INTO fe_lot_jobs 
                  ( 
                              lot_job_id, 
                              mu_id, 
                              assigned_ts, 
                              timeouts 
                  ) 
                  VALUES 
                  ( 
                              fe_lot_job_seq.NEXTVAL, 
                              l_mu_id, 
                              l_current_epoch_time, 
                              l_fe_job_timeout 
                  ) 
      returning   lot_job_id 
      INTO        l_lot_job_id;

UPDATE mu_extract_load
SET pressure = pressure + 1,
    update_ts = l_current_epoch_time
WHERE mu_id = l_mu_id;    
     
      FOR i IN l_locked_fe_job_ids.first..l_locked_fe_job_ids.last 
      LOOP
UPDATE fe_job_queue
SET lot_job_id = l_lot_job_id,
    mu_id = l_mu_id,
    job_state = 1,
    assigned_ts = l_current_epoch_time
WHERE job_id = l_locked_fe_job_ids(i);    
      END LOOP;
COMMIT; 
      EXCEPTION 
      WHEN OTHERS THEN
ROLLBACK; 
       dbms_output.Put_line ('Error Code:' 
       || To_char(SQLCODE) 
       || '  Error Message:' 
       || SQLERRM);      
    END process_one_mu ;
      
    /***
    ***
    *** Update job_queue,container_job,mu_excution_job table
    ***
    */
    PROCEDURE update_after_planned
     (
        p_job_id       IN NUMBER, 
        p_container_id IN NUMBER, 
        p_container_job_id IN NUMBER,
        p_function_id   IN NUMBER, 
        p_plans_string  IN CLOB, 
        r_plan_id       OUT NUMBER
    ) 
      IS         
        l_current_time  NUMBER; 
        l_failure_count NUMBER; 
      BEGIN 
        SELECT failure_count 
        INTO   l_failure_count 
        FROM   job_queue 
        WHERE  job_id = p_job_id; 
    
        l_failure_count := l_failure_count + 1;     
        l_current_time := get_epoch_time_num();     
    
          INSERT INTO mu_job_execute_plans 
                      (planed_ts, 
                       container_id, 
                       function_id, 
                       PLAN, 
                       plan_id, 
                       planed_count, 
                       job_id) 
          VALUES      ( l_current_time, 
                       p_container_id, 
                       p_function_id, 
                       p_plans_string, 
                       mu_job_plan_seq.NEXTVAL, 
                       l_failure_count, 
                       p_job_id ) 
          returning plan_id INTO r_plan_id;

UPDATE job_queue
SET job_state = c_job_state_working,
    assigned_ts = l_current_time
WHERE job_id = p_job_id
AND job_state = c_job_state_queued;

UPDATE container_jobs
SET job_state = c_job_state_working,
    plan_id = r_plan_id
WHERE container_id = p_container_id
AND container_job_id = p_container_job_id;
      EXCEPTION 
      WHEN OTHERS THEN 
                 dbms_output.Put_line ( 
                 'An error occurred while do update_after_planned()'); 
    
                 dbms_output.Put_line ('Error Code:' 
                                       || To_char(SQLCODE) 
                                       || '  Error Message:' 
                                       || SQLERRM); 
                 RAISE; 
   END update_after_planned; 
    
        /***
    ***
    *** change current time to epoch time
    ***
    */ 
      FUNCTION get_epoch_time_num RETURN NUMBER   
      AS 
       epoch_long NUMBER; 
      BEGIN 
        SELECT (extract(day   from (sys_extract_utc(systimestamp) - timestamp '1970-01-01 00:00:00')) * 86400000
             + extract(hour   from (sys_extract_utc(systimestamp) - timestamp '1970-01-01 00:00:00')) * 3600000
             + extract(minute from (sys_extract_utc(systimestamp) - timestamp '1970-01-01 00:00:00')) * 60000
             + extract(second from (sys_extract_utc(systimestamp) - timestamp '1970-01-01 00:00:00')) * 1000)
             into epoch_long
        FROM   dual;
        dbms_output.Put_line(epoch_long); 
        RETURN epoch_long; 
      EXCEPTION 
       WHEN OTHERS THEN 
                 dbms_output.Put_line ( 
                 'An error occurred while do fuction: GET_EPOCH_TIME()'); 
    
                 dbms_output.Put_line ('Error Code:' 
                                       || To_char(SQLCODE) 
                                       || '  Error Message:' 
                                       || SQLERRM); 
                 RAISE; 
      END get_epoch_time_num; 
      
   /***
    ***
    *** get one mu's lot at first of list
    ***
    */ 
    
  PROCEDURE get_first_mu_remain_lots
     (  p_max_lot   IN NUMBER, 
        p_refcursor OUT SYS_REFCURSOR) 
     AS 
     BEGIN 
      OPEN p_refcursor FOR 
      SELECT
         mu_id,
        currentlots,
        num_extractor,
        remain_lots
          FROM (
          SELECT
            mu.mu_id,
            ml.pressure AS currentlots,
            mu.number_of_extractors AS num_extractor,
            p_max_lot - ml.pressure AS remain_lots,
           row_number() over (ORDER BY p_max_lot - ml.pressure DESC, ml.update_ts) AS rn
     FROM
        match_units mu,
        mu_extract_load ml,
        mu_eligible_functions mf
    WHERE
        mu.mu_id = ml.mu_id
        AND mu.mu_id = mf.mu_id
        AND mu.state = c_working_state_string
        AND p_max_lot - ml.pressure > 0
	    AND mu.number_of_extractors > 0
        AND mf.function_id = 17)
   WHERE rn = 1;   
     EXCEPTION 
   WHEN OTHERS THEN             
             dbms_output.Put_line ('Error Code:' 
                                   || To_char(SQLCODE) 
                                   || '  Error Message:' 
                                   || SQLERRM); 
             RAISE;                      
    END get_first_mu_remain_lots;

    /***
    ***
    *** Get limite count of job
    ***
    */ 
    FUNCTION get_limited_jobs_by_familiy 
      RETURN NUM_TABLE_TYPE 
      AS 
       l_job_ids NUM_TABLE_TYPE; 
       r_job_ids num_table_type := num_table_type();
       l_index number := 0;

      BEGIN 
        FOR rec IN (SELECT family_id, 
                           job_limit_count - job_exec_count AS limit_count 
                    FROM   inquiry_traffic
                    WHERE (job_limit_count - job_exec_count) > 0) LOOP 
            SELECT job_id 
            bulk   collect INTO l_job_ids 
            FROM   (SELECT job_id, 
                           row_number() 
                             over ( 
                               ORDER BY priority, failure_count DESC, job_id) AS rn 
                    FROM   job_queue 
                    WHERE  family_id = rec.family_id
                    and    job_state = c_job_state_queued) 
            WHERE  rn <= rec.limit_count; 
            if(l_job_ids.count > 0 ) then
            for i in l_job_ids.first..l_job_ids.last loop
            l_index :=  l_index + 1;
            r_job_ids.extend;
            r_job_ids(l_index) := l_job_ids(i);
            end loop;
            end if;
        END LOOP;
      RETURN r_job_ids;
      EXCEPTION 
       WHEN OTHERS THEN  
      dbms_output.Put_line ('Error Code:' 
                            || To_char(SQLCODE) 
                            || '  Error Message:' 
                            || SQLERRM);        
      RETURN null; 
      END get_limited_jobs_by_familiy;
   
      
    FUNCTION garbage_seg_change_log
      RETURN NUMBER
    IS
     l_segment_ids num_table_type;
     l_count NUMBER;
     l_bottom NUMBER;
     l_max_diff NUMBER;
     l_version NUMBER;
     l_deleted NUMBER;
    BEGIN
      l_count := 0;

      SELECT segment_id bulk collect into l_segment_ids FROM segments ORDER BY segment_id;
      IF l_segment_ids.Count = 0 THEN
        return l_count;
      END IF;

SELECT
  TO_NUMBER(property_value) INTO l_max_diff
FROM system_config
WHERE property_name = 'BEHAVIOR.MAX_SEGMENT_DIFFS';

      FOR i IN l_segment_ids.first..l_segment_ids.last LOOP
SELECT
  version INTO l_version
FROM segments
WHERE segment_id = l_segment_ids(i);
        l_bottom := l_version - l_max_diff;

        l_deleted := 1;
        WHILE (0 < l_deleted) LOOP
          DELETE FROM segment_change_log WHERE segment_change_id IN (
            SELECT segment_change_id FROM (
              SELECT 
                segment_change_id, row_number() OVER (ORDER BY segment_change_id) as rn
                FROM segment_change_log WHERE segment_id = l_segment_ids(i)
                  AND segment_version < l_bottom
            ) WHERE rn <= 10000
          );
             l_deleted := SQL%ROWCOUNT;
             l_count := l_count + l_deleted;
COMMIT;
        END LOOP;
      END LOOP;
        return l_count;
      EXCEPTION
        WHEN OTHERS THEN
            RAISE;
    END garbage_seg_change_log;

    PROCEDURE find_unaggregated_jobs
    (
        p_refcursor OUT sys_refcursor
    )
    IS
      l_detect_time NUMBER;
      l_epoch_time NUMBER;
    BEGIN
      l_epoch_time := get_epoch_time_num();
SELECT
  to_number(property_value) INTO l_detect_time
FROM system_config
WHERE property_name = 'JOB_AGGREGATION.AUTO_DETECT_TIME';  

      OPEN p_refcursor FOR
SELECT /*+ */ jq.job_id
FROM job_queue jq
WHERE jq.job_state = c_job_state_working
AND jq.remain_jobs = 0
-- check if TopLevelJob has a record in container_jobs
AND EXISTS (SELECT
    cj.container_job_id
  FROM fusion_jobs fj,
       container_jobs cj
  WHERE fj.job_id = jq.job_id
  AND fj.fusion_job_id = cj.fusion_job_id)
-- check if all container_jobs record is DONE.
AND NOT EXISTS (SELECT
    cj.container_job_id
  FROM fusion_jobs fj,
       container_jobs cj
  WHERE fj.job_id = jq.job_id
  AND fj.fusion_job_id = cj.fusion_job_id
  AND cj.job_state != c_job_state_done)
-- select TopLevelJob whose CONTAINER_JOBS are DONE but not aggregated for l_detect_time/1000 second 
AND EXISTS (SELECT
    MAX(cj.result_ts)
  FROM fusion_jobs fj,
       container_jobs cj
  WHERE jq.job_id = fj.job_id
  AND fj.fusion_job_id = cj.fusion_job_id
  GROUP BY jq.job_id
  HAVING MAX(cj.result_ts) < (SELECT
      l_epoch_time - l_detect_time
    FROM dual))
ORDER BY jq.job_id;

    EXCEPTION
      WHEN OTHERS THEN
          RAISE;
      
    END find_unaggregated_jobs;

    PROCEDURE fetch_timeout_job (
        p_job_ids         OUT num_table_type
    )
    IS
        l_epoch_time NUMBER;
        l_job_ids num_table_type;
        l_c_job_ids num_table_type;
    BEGIN
        l_epoch_time := get_epoch_time_num();

        SELECT job_id BULK COLLECT INTO l_job_ids FROM job_queue 
          WHERE job_state = c_job_state_working 
          AND 0 <= timeouts 
          AND assigned_ts < (select l_epoch_time - timeouts FROM dual)
        order by job_id;

        p_job_ids := l_job_ids;    
    EXCEPTION
        WHEN OTHERS THEN
            RAISE;
    END fetch_timeout_job;

    FUNCTION retry_extract_job
    (
        p_extract_job_id     NUMBER,
        p_mu_id              NUMBER,
        p_reason             VARCHAR2,
        p_code               VARCHAR2,
        p_time               VARCHAR2
    )
    RETURN NUMBER
    IS
      l_count NUMBER;
    BEGIN

      UPDATE fe_job_queue SET
        lot_job_id = null,
        mu_id = null,
        assigned_ts = NULL,
        failure_count = failure_count + 1,
        job_state = c_job_state_queued
      WHERE job_id = p_extract_job_id
        AND job_state = c_job_state_working
        AND mu_id = p_mu_id;

      l_count := SQL%ROWCOUNT;

      IF(0 < l_count) THEN
INSERT INTO FE_JOB_FAILURE_REASONS (FAILURE_ID,
JOB_ID,
MU_ID,
CODE,
REASON,
FAILURE_TIME)
  VALUES (FE_JOB_FAILURE_SEQ.NEXTVAL, p_extract_job_id, p_mu_id, p_code, p_reason, p_time);
      END IF;

COMMIT;
      RETURN l_count;
    END retry_extract_job;

    FUNCTION fail_extract_job
    (
        p_extract_job_id     NUMBER,
        p_mu_id              NUMBER,
        p_result             BLOB,
        p_reason             VARCHAR2,
        p_code               VARCHAR2,
        p_time               VARCHAR2
    )
    RETURN NUMBER
    IS
      l_count NUMBER;
      l_epoch_time NUMBER;
    BEGIN
      l_epoch_time := get_epoch_time_num();

UPDATE fe_job_queue
SET lot_job_id = NULL,
    job_state = c_job_state_done,
    failed_flag = 1,
    result_ts = l_epoch_time,
    result = p_result,
    failure_count = failure_count + 1,
    mu_id = p_mu_id
WHERE job_id = p_extract_job_id
AND job_state = c_job_state_working
AND mu_id = p_mu_id;

      l_count := SQL%ROWCOUNT;

      IF(0 < l_count) THEN
INSERT INTO FE_JOB_FAILURE_REASONS (FAILURE_ID,
JOB_ID,
MU_ID,
CODE,
REASON,
FAILURE_TIME)
  VALUES (FE_JOB_FAILURE_SEQ.NEXTVAL, p_extract_job_id, p_mu_id, p_code, p_reason, p_time);
      END IF;

COMMIT;
      RETURN l_count;
    END fail_extract_job;

    FUNCTION finish_extract_job
    (
        p_mu_id              NUMBER,
        p_job_id             NUMBER,
        p_result             BLOB,
        p_keys               clob_table_type,
        p_indexs             num_table_type,
        p_values             blob_table_type
    )
    RETURN NUMBER
    IS
      l_count NUMBER;
      l_epoch_time NUMBER;
    BEGIN
      l_epoch_time := get_epoch_time_num();

UPDATE fe_job_queue
SET lot_job_id = NULL,
    job_state = c_job_state_done,
    failed_flag = 0,
    result = p_result,
    result_ts = l_epoch_time,
    mu_id = p_mu_id
WHERE job_id = p_job_id
AND job_state = c_job_state_working
AND mu_id = p_mu_id;
        
        l_count := SQL%ROWCOUNT;

        IF(0 < l_count) THEN
          IF(0 < p_keys.Count) THEN
            FOR i IN p_keys.first..p_keys.last LOOP
INSERT INTO FE_RESULTS (RESULT_ID, JOB_ID, RESULT_DATA, TEMPLATE_KEY, TEMPLATE_INDEX)
  VALUES (FE_RESULT_SEQ.NEXTVAL, p_job_id, p_values(i), p_keys(i), p_indexs(i));
            END LOOP;
          END IF;
UPDATE extract_complete_count
SET complete_count = complete_count + l_count,
    complete_ts = get_epoch_time_num();
COMMIT;
        END IF;
       RETURN l_count;
    EXCEPTION
        WHEN OTHERS THEN
            RAISE;
   END finish_extract_job;

    /*
     * Procedure to reset max_segment_size.
     * update CONTAINERS table set max_segment_size.
     * delete segments by container_id
     * insert segments
     */
    PROCEDURE create_segments
    (
        p_container_id IN NUMBER,
        p_max_segment_size IN NUMBER
    ) 
    IS
        l_curr_size        NUMBER := 0;
        l_starting_id      NUMBER;
        l_ending_id        NUMBER;
        l_rec_count        NUMBER;
        l_segment_id       NUMBER;
        CURSOR c1 IS
SELECT
  biometrics_id,
  biometric_data_len
FROM person_biometrics
WHERE container_id = p_container_id
ORDER BY biometrics_id;
        l_bio c1%ROWTYPE; 
    BEGIN
        ---
        --- The current behaviour is to lock person_biometrics table in exclusive mode
        --- and prevent other users from adding new records to the biometrics table.
        ---
        --- This process is relatively fast, the table will only be locked for a few seconds.
        ---
        --- There are a couple of implications of this design:
        ---    1. Transaction control - the client MUST issue a commit or rollback to unlock
        ---       the table. At this time the transaction control is happening on the client.
        ---    2. If the client program fails to issue a commit/rolback statement, without
        ---       closing the connection, the table will remain locked indefinitely.
        ---    3. To prevent this behaiour we may use PRAGMA AUTONOMOUS_TRANSACTION;
        ---       for this routine, to mark it as a unit of work.
        ---
        --- At this point it's not clear which approach is better, so for now we'll go
        --- with client-side transaction control.
        ---
        --- Specifying NOWAIT option will raise ORA-00054: resource busy and acquire with NOWAIT specified
        --- exception if another program already locked the table. This error must be intercepted
        --- by the client and properly handled.

LOCK TABLE person_biometrics IN EXCLUSIVE MODE NOWAIT;
UPDATE CONTAINERS
SET MAX_SEGMENT_SIZE = p_max_segment_size
WHERE container_id = p_container_id;
DELETE
  FROM segments
WHERE container_id = p_container_id;

        OPEN c1;
        FETCH c1 INTO l_bio;
        IF c1%NOTFOUND THEN
           --- log_api.debug(g_ctx, 'No records found during segmentation for bin_id=' || p_bin_id);
            RETURN;
        END IF;

        l_starting_id := l_bio.biometrics_id;
        l_ending_id   := l_bio.biometrics_id;
        l_curr_size   := c_segment_header_length + l_bio.biometric_data_len + c_template_header_length;
        l_rec_count   := 1;

        LOOP
            FETCH c1 INTO l_bio;
            EXIT WHEN c1%NOTFOUND;

            IF (l_curr_size < p_max_segment_size) AND
               (l_curr_size + l_bio.biometric_data_len + c_template_header_length <= p_max_segment_size)
            THEN
                l_curr_size := l_curr_size + l_bio.biometric_data_len + c_template_header_length;
                l_ending_id := l_bio.biometrics_id;
                l_rec_count := l_rec_count + 1;
            ELSE
                --- Create new segment
                INSERT INTO segments
                (
                    segment_id,
                    CONTAINER_ID,
                    bio_id_start,
                    bio_id_end,
                    binary_length_compacted,
                    binary_length_uncompacted,
                    record_count,
                    version,
                    revision
                )
                VALUES
                (
                    segment_seq.NEXTVAL,
                    p_container_id,
                    l_starting_id,
                    l_ending_id,
                    l_curr_size,
                    l_curr_size,
                    l_rec_count,
                    0,
                    0
                )
                returning segment_id INTO l_segment_id;

                --- At least one record will be added to the next segment
                l_starting_id := l_bio.biometrics_id;
                l_ending_id   := l_bio.biometrics_id;
                l_rec_count := 1;
                l_curr_size := c_segment_header_length + l_bio.biometric_data_len
                        + c_template_header_length;
            END IF;
        END LOOP;
        CLOSE c1;

        --- Last segment
        IF l_ending_id IS NOT NULL THEN
            INSERT INTO segments
            (
                segment_id,
                CONTAINER_ID,
                bio_id_start,
                bio_id_end,
                binary_length_compacted,
                binary_length_uncompacted,
                record_count,
                version,
                revision
            )
            VALUES
            (
                segment_seq.NEXTVAL,
                p_container_id,
                l_starting_id,
                l_ending_id,
                l_curr_size,
                l_curr_size,
                l_rec_count,
                0,
                0
            )
            returning segment_id INTO l_segment_id;
        END IF;
COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            RAISE;
    END create_segments;
    
    /*
     * persist the matrix that slb was executed
     * first delete the mu_segment which segment
     * in the range of specified container id
     * then insert the record into mu_segment with
     * specified parameter p_slb_matrix
     */
    PROCEDURE persist_slb_matrix
    (
       p_slb_matrix       IN SLBMATRIX_TABLE_TYPE,
       p_container_id     IN NUMBER,
       p_component_type   IN NUMBER
    )
    IS
      l_slb_matrix        SLBMATRIX;
    BEGIN
      IF (p_component_type = c_component_type_mu) THEN
-- component type is MU
DELETE
  FROM mu_segments
WHERE segment_id IN (SELECT
      segment_id
    FROM SEGMENTS
    WHERE container_id = p_container_id);
        FOR i IN p_slb_matrix.first .. p_slb_matrix.last
        LOOP
          l_slb_matrix := p_slb_matrix(i);
INSERT INTO mu_segments (mu_id, segment_id, rank)
  VALUES (l_slb_matrix.unitId, l_slb_matrix.segId, 0);
        END LOOP;
      ELSIF (p_component_type = c_component_type_dm) THEN
-- component type is DM
DELETE
  FROM dm_segments
WHERE segment_id IN (SELECT
      segment_id
    FROM SEGMENTS
    WHERE container_id = p_container_id);
        FOR i IN p_slb_matrix.first .. p_slb_matrix.last
        LOOP
          l_slb_matrix := p_slb_matrix(i);
INSERT INTO dm_segments (dm_id, segment_id, rank)
  VALUES (l_slb_matrix.unitId, l_slb_matrix.segId, 0);
        END LOOP;
      ELSE
         RAISE_APPLICATION_ERROR(c_bad_parameters,'Unsupported component type of input parameter values.',
                 TRUE);
      END IF;
    END persist_slb_matrix;



    

   PROCEDURE update_inquiry_traffic
   (
       p_top_job_id IN NUMBER
   )
   AS
     l_job_exec_count  NUMBER;
     l_job_limit_count NUMBER;
     l_family_id  NUMBER;
   BEGIN
    select family_id into l_family_id from job_queue where job_id = p_top_job_id;
UPDATE inquiry_traffic it
SET it.job_exec_count = it.job_exec_count + 1
WHERE it.family_id = l_family_id;
SELECT
  job_exec_count,
  job_limit_count INTO l_job_exec_count, l_job_limit_count
FROM inquiry_traffic it
WHERE it.family_id = l_family_id;
     IF(l_job_exec_count < 0 OR l_job_exec_count > l_job_limit_count) THEN
UPDATE INQUIRY_TRAFFIC it
SET it.JOB_EXEC_COUNT = (SELECT
    COUNT(JOB_ID)
  FROM JOB_QUEUE jq
  WHERE jq.FAMILY_ID = it.FAMILY_ID
  AND jq.JOB_STATE = c_job_state_working)
WHERE it.FAMILY_ID = l_family_id;
     END IF;
     EXCEPTION 
     WHEN OTHERS THEN             
             dbms_output.Put_line ('Error Code:' 
                                   || To_char(SQLCODE) 
                                   || '  Error Message:' 
                                   || SQLERRM); 
             RAISE;        
   END UPDATE_INQUIRY_TRAFFIC;   
    /*
      * decrease_extract_load
      * decrease_extract_load, if the record count is not exist
      * insert new record with specified load, otherwise update
      * the record with specified load
      */
      
    FUNCTION decrease_extract_load 
      (
           p_mu_id      IN NUMBER,
         p_lot_count    IN NUMBER
      ) RETURN NUMBER
      IS
       l_count        NUMBER;
       l_pressure     NUMBER;
       BEGIN
         SELECT COUNT(*) INTO l_count FROM mu_extract_load WHERE mu_id = p_mu_id;
         IF l_count > 0 THEN
SELECT
  pressure INTO l_pressure
FROM mu_extract_load
WHERE mu_id = p_mu_id FOR UPDATE;
            UPDATE mu_extract_load SET pressure = pressure - p_lot_count, update_ts = get_epoch_time_num() 
            WHERE mu_id = p_mu_id
            RETURNING pressure INTO l_pressure;
         ELSE
INSERT INTO mu_extract_load (mu_id, pressure, update_ts)
  VALUES (p_mu_id, 0, get_epoch_time_num());
COMMIT;
            RETURN 0;
         END IF;
         
         IF (l_pressure < 0) THEN
UPDATE mu_extract_load
SET pressure = 0,
    update_ts = get_epoch_time_num()
WHERE mu_id = p_mu_id;
         END IF;

COMMIT;
         RETURN l_pressure;
      END decrease_extract_load;
    
END match_manager_api;
/
show errors package body match_manager_api;
