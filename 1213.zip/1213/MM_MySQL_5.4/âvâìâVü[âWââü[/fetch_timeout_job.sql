CREATE DEFINER = `aimuser`@`%` PROCEDURE `fetch_timeout_job` (
)
BEGIN
  DECLARE l_epoch_time long;
  DECLARE t_error integer DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
  SET l_epoch_time := get_epoch_time_num();
  SELECT
    job_id
  FROM job_queue
  WHERE job_state = 'WORKING'
  AND 0 <= timeouts
  AND assigned_ts < (SELECT
      l_epoch_time - timeouts
    FROM dual)
  ORDER BY job_id;
  IF t_error = 1 THEN
    SELECT
      1
    FROM dual
    WHERE FALSE;
  END IF;
END