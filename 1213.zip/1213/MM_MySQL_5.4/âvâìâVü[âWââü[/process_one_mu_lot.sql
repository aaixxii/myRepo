CREATE DEFINER=`aimuser`@`%` PROCEDURE `process_one_mu_lot`(
    IN  p_mu_id int,
    IN  p_number_of_extractors int,
    OUT l_lot_job_id int
)
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
mylable:BEGIN
      declare l_one_lot_count          int;
	  declare  l_mu_extract_load_count int;
	  declare  l_fe_job_timeout        int;   
	  declare l_current_epoch_time    int;
        DECLARE t_error INTEGER DEFAULT 0;  
      declare v_idx int default 999 ;
      declare v_tmp_str varchar(20);
      declare v_id int;     
	 declare cur cursor for select jobId from l_locked_fe_job_ids;  
     DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1;  
	 DROP TEMPORARY TABLE IF EXISTS l_locked_fe_job_ids;
     create temporary table l_locked_fe_job_ids(jobId int  NOT NULL PRIMARY KEY UNIQUE) engine=memory;      
      IF( p_mu_id <= 0 OR  p_number_of_extractors <= 0 ) then
       set l_lot_job_id = -9999;       
       leave mylable;
      end if; 
       set l_one_lot_count = p_number_of_extractors;
     insert into l_locked_fe_job_ids(jobId) values (
      (select job_id from FE_JOB_QUEUE
       WHERE job_state = 0
		AND   priority  = 1
        ORDER BY priority, failure_count DESC, job_id
       limit 1)
      );  
	IF l_locked_fe_job_ids.count = 1 then 
    set l_one_lot_count = 1;     
    ELSEIF l_locked_fe_job_ids.count < 1 then 
       select job_id from FE_JOB_QUEUE
       WHERE job_state = 0
		AND   priority  = 1
        order by priority, failure_count DESC, job_id
       limit l_one_lot_count;               
    END IF;
	IF ( l_locked_fe_job_ids IS NULL  OR  l_locked_fe_job_ids.count = 0 )  THEN   
       --  dbms_output.Put_line ('no fe_job to assign! return');        
        leave mylable;
	END IF; 
	SELECT top_level_job_timeouts 
      INTO   l_fe_job_timeout 
      FROM   function_types 
      WHERE  function_id = 17 
      AND    queue_type = 1;    
     set l_fe_job_timeout := l_fe_job_timeout * l_locked_fe_job_ids.count; 
      set l_current_epoch_time := get_epoch_time_num(); 
      INSERT INTO fe_lot_jobs 
                  (                             
                              mu_id, 
                              assigned_ts, 
                              timeouts 
                  ) 
                  VALUES 
                  (                              
                              p_mu_id, 
                              l_current_epoch_time, 
                              l_fe_job_timeout 
                  ) ;
      select max(lot_job_id) into l_lot_job_id from fe_lot_jobs;
		UPDATE mu_extract_load 
        SET    pressure = pressure + 1, 
               update_ts = l_current_epoch_time 
        WHERE  mu_id = p_mu_id;
      open cur;
        lable_loop: loop
           FETCH cur INTO v_id;
		UPDATE fe_job_queue 
        SET    lot_job_id = l_lot_job_id, 
               mu_id = p_mu_id, 
               job_state = 'WORKING', 
               assigned_ts = l_current_epoch_time 
        WHERE  job_id = v_id;   
		end loop;
        close cur;
        if t_error=1 then
        rollback;
	 else 
	   commit;
	 end if;
END