CREATE DEFINER = `aimuser`@`%` PROCEDURE `complete_top_level_job` (IN p_job_id long,
IN p_failed integer,
IN p_result mediumblob,
OUT o_job_exec_count int)
MODIFIES SQL DATA
SQL SECURITY INVOKER
BEGIN
  DECLARE l_family_id long;
  DECLARE l_job_exec_count int;
  DECLARE t_error integer DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
  SELECT
    jq.family_id INTO l_family_id
  FROM job_queue jq
  WHERE jq.job_id = p_job_id FOR UPDATE;

  UPDATE inquiry_traffic
  SET job_exec_count = job_exec_count - 1,
      JOB_COMPLETE_COUNT = JOB_COMPLETE_COUNT + 1
  WHERE family_id = l_family_id;
  SELECT
    job_exec_count INTO l_job_exec_count
  FROM inquiry_traffic;
  IF l_job_exec_count < 0 THEN
    CALL init_executing_job_count();
    SELECT
      job_exec_count INTO l_job_exec_count
    FROM inquiry_traffic
    WHERE family_id = l_family_id;
  END IF;
  IF t_error = 1 THEN
    ROLLBACK;
  ELSE
    COMMIT;
  END IF;
  SET o_job_exec_count = l_job_exec_count;
  SELECT
    o_job_exec_count;
END