CREATE DEFINER = `aimuser`@`%` PROCEDURE `testTab` (IN p_candidate_containers varchar(1024),
OUT v_count int)
BEGIN
  DECLARE v_id int;
  DECLARE v_idx int DEFAULT 999;
  DECLARE v_tmp_str varchar(20);
  DECLARE t_error integer DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
  DROP TEMPORARY TABLE IF EXISTS arr_container_ids;
  CREATE TEMPORARY TABLE arr_container_ids (
    id int
  ) ENGINE = INNODB;
  WHILE v_idx > 0 DO
    SET v_idx = INSTR(p_candidate_containers, ',');
    SET v_tmp_str = SUBSTR(p_candidate_containers, 1, v_idx - 1);
    INSERT INTO arr_container_ids (id)
      VALUES (CAST(v_tmp_str AS UNSIGNED));
    SET p_candidate_containers = SUBSTR(p_candidate_containers, v_idx + 1, LENGTH(p_candidate_containers));
  END WHILE;
  SELECT
    COUNT(id) INTO v_count
  FROM arr_container_ids;

END