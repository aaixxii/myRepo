﻿CREATE DEFINER = `aimuser`@`%` PROCEDURE `check_container_formats` (IN p_function_id int,
IN p_candidate_containers varchar(1024),
OUT r_err_str varchar(1024))
READS SQL DATA
BEGIN
  -- p_candidate_containers="1,2,3,321,322,323"；     
  DECLARE l_actual_format_name varchar(255);
  DECLARE l_target_format_name varchar(255);
  DECLARE l_target_format_id int;
  DECLARE l_function_name varchar(20);
  DECLARE v_idx int DEFAULT 999;
  DECLARE v_tmp_str varchar(20);
  DECLARE v_id int;
  DECLARE v_format_id int;
  DECLARE t_error integer DEFAULT 0;
  DECLARE t_err_msg varchar(2048);
  DECLARE id_cur CURSOR FOR
  SELECT
    c.container_id
  FROM containers c
    RIGHT JOIN arr_container_ids a
      ON c.container_id = a.id;
  DECLARE cur CURSOR FOR
  SELECT
    a.id,
    c.format_id
  FROM containers c,
       format_types f
         LEFT JOIN arr_container_ids a
           ON a.id = c.container_id
           AND (c.format_id IS NULL
           OR c.format_id != l_target_format_id);
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
  DROP TEMPORARY TABLE IF EXISTS arr_container_ids;
  CREATE TEMPORARY TABLE arr_container_ids (
    id int
  ) ENGINE = MEMORY;
  WHILE v_idx > 0 DO
    SET v_idx = INSTR(p_candidate_containers, ',');
    SET v_tmp_str = SUBSTR(p_candidate_containers, 1, t_idx - 1);
    INSERT INTO arr_container_ids (id)
      VALUES (CAST(v_tmp_str AS UNSIGNED));
    SET p_candidate_containers = SUBSTR(p_candidate_containers, v_idx + 1, LENGTH(p_candidate_containers));
  END WHILE;
  SELECT
    f.target_format_id,
    f.function_name INTO l_target_format_id, l_function_name
  FROM function_types f
  WHERE f.function_id = p_function_id;
  SET r_err_str = "";
  OPEN id_cur;
  LOOP
    FETCH id_cur INTO v_id;
    IF (v_id IS NULL) THEN
      SET r_err_str = CONCAT(r_err_str, 'container_id:', CAST(v_id AS char));
    END IF;
  END LOOP;





  OPEN cur;
lable_loop:
  LOOP
    FETCH cur INTO v_id, v_format_id;
    IF v_format_id IS NULL THEN
      SET t_error = 1;
    ELSE
      SELECT
        format_name INTO l_actual_format_name
      FROM format_types f
      WHERE f.format_id = c1.format_id;
      SELECT
        format_name INTO l_target_format_name
      FROM format_types f
      WHERE f.format_id = l_target_format_id;
      SET t_err_msg = CONCAT(t_err_msg, '');
    END IF;
  END LOOP;
  CLOSE cur;
END