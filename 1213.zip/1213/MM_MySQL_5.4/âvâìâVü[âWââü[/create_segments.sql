CREATE DEFINER=`aimuser`@`%` PROCEDURE `create_segments`(
   IN  p_container_id int,
   IN p_max_segment_size long
)
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN
	declare  l_curr_size  int default 0;
	declare   l_starting_id  int;
    declare  l_ending_id  int;
	declare   l_rec_count int;
	declare   l_segment_id int;
       DECLARE t_error INTEGER DEFAULT 0;  
      declare v_idx int default 999 ;
      declare v_tmp_str varchar(20);
      declare v_id int;     
	  declare cur cursor for 
		SELECT biometrics_id, biometric_data_len
            FROM   person_biometrics
            WHERE  container_id = p_container_id
            ORDER BY biometrics_id;
     DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1;  
	DROP TEMPORARY TABLE IF EXISTS container_ids;
	create temporary table container_ids(id int  NOT NULL PRIMARY KEY UNIQUE) engine=memory; 
  
      
    
    
    

END