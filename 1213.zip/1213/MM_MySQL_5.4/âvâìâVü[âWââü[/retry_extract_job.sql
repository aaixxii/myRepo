CREATE DEFINER = `aimuser`@`%` PROCEDURE `retry_extract_job` (IN p_extract_job_id int,
IN p_mu_id int,
IN p_reason varchar(20),
IN p_code varchar(20),
IN p_time varchar(20),
OUT r_count int)
MODIFIES SQL DATA
BEGIN
  DECLARE l_count int;
  DECLARE t_error integer DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;

  UPDATE fe_job_queue
  SET lot_job_id = NULL,
      mu_id = NULL,
      assigned_ts = NULL,
      failure_count = failure_count + 1,
      job_state = c_job_state_queued
  WHERE job_id = p_extract_job_id
  AND job_state = c_job_state_working
  AND mu_id = p_mu_id;

  SELECT
    ROW_COUNT() INTO l_count;
  IF (0 < l_count) THEN
    INSERT INTO FE_JOB_FAILURE_REASONS (FAILURE_ID,
    JOB_ID,
    MU_ID,
    CODE,
    REASON,
    FAILURE_TIME)
      VALUES (FE_JOB_FAILURE_SEQ.NEXTVAL, p_extract_job_id, p_mu_id, p_code, p_reason, p_time);
  END IF;
  IF t_error = 1 THEN
    ROLLBACK;
    SET r_count = -999;
  ELSE
    COMMIT;
    SET r_count = l_count;
  END IF;
  SELECT
    r_count;
END