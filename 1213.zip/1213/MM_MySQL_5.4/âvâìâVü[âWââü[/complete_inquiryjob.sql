CREATE DEFINER = `aimuser`@`%` PROCEDURE `complete_inquiryjob` (IN p_job_id int,
IN p_container_job_id int,
IN p_sequence integer,
IN p_result blob,
OUT l_remain_jobs integer)
MODIFIES SQL DATA
SQL SECURITY INVOKER
BEGIN
  DECLARE l_count int DEFAULT 0;
  DECLARE l_failure_count int;
  DECLARE l_remain_jobs int;
  DECLARE v_errcode int;
  DECLARE t_error integer DEFAULT 0;
  DECLARE cur CURSOR FOR
  SELECT
    id
  FROM l_container_ids;
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
  SELECT
    failure_count INTO l_failure_count
  FROM job_queue
  WHERE job_id = p_job_id
  AND job_state = 1
  AND 0 < remain_jobs FOR UPDATE;
  IF p_sequence = l_failure_count THEN
    UPDATE CONTAINER_JOBS
    SET JOB_STATE = 2,
        RESULT_TS = get_epoch_time_num(),
        CONTAINER_JOB_RESULT = p_result
    WHERE CONTAINER_JOB_ID = p_container_job_id
    AND job_state = 'WORKING';
    SELECT
      ROW_COUNT() INTO l_count;
    IF 0 < l_count THEN
      UPDATE job_queue
      SET remain_jobs = remain_jobs - 1
      WHERE job_id = p_job_id;
      SELECT
        remain_jobs INTO l_remain_jobs
      FROM job_queue;
    ELSE
      ROLLBACK;
      SET l_remain_jobs = -3;
    END IF;
  ELSE
    ROLLBACK;
    SET l_remain_jobs = -2;
  END IF;
  IF t_error = 1 THEN
    ROLLBACK;
    SET l_remain_jobs = -1;
  ELSE
    COMMIT;
  END IF;
END