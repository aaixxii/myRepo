CREATE DEFINER = `aimuser`@`%` PROCEDURE `finish_extract_job` (IN p_mu_id int,
IN p_job_id int,
IN p_result blob,
IN p_keys varchar(1024),
IN p_indexs varchar(1024),
IN p_values varchar(1024))
BEGIN

END