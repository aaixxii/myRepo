CREATE DEFINER = `aimuser`@`%` PROCEDURE `get_job_info_for_create_plans` (IN limited_job_ids varchar(2048))
MODIFIES SQL DATA
SQL SECURITY INVOKER
BEGIN
  DECLARE t_error integer DEFAULT 0;
  DECLARE v_idx int DEFAULT 999;
  DECLARE v_tmp_str varchar(20);
  DECLARE v_id int;
  DECLARE cur CURSOR FOR
  SELECT
    id
  FROM l_container_ids;
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
  DROP TEMPORARY TABLE IF EXISTS limited_ids_tab;
  CREATE TEMPORARY TABLE limited_ids_tab (
    id int
  ) ENGINE = MEMORY;
  WHILE v_idx > 0 DO
    SET v_idx = INSTR(limited_job_ids, ',');
    SET v_tmp_str = SUBSTR(limited_job_ids, 0, t_idx - 1);
    INSERT INTO limited_ids_tab (id)
      VALUES (CAST(v_tmp_str AS UNSIGNED));
    SET limited_job_ids = SUBSTR(limited_job_ids, v_idx + 1, LENGTH(limited_job_ids));
  END WHILE;

  SELECT
    jq.job_id,
    jq.family_id,
    fq.function_id,
    ssj.container_id,
    ssj.container_job_id
  FROM job_queue jq,
       fusion_jobs fq,
       container_jobs ssj
  WHERE jq.job_id = fq.job_id
  AND fq.fusion_job_id = ssj.fusion_job_id
  AND jq.job_state = 0
  AND ssj.container_id != (SELECT
      container_id
    FROM segment_defragmentation)
  AND jq.job_id IN (SELECT
      id
    FROM limited_job_ids)
  ORDER BY priority, failure_count DESC, job_id;
  IF t_error = 1 THEN
    -- select empty to return;
    SELECT
      NULL
    FROM dual;
  END IF;
END