CREATE DEFINER = `aimuser`@`%` PROCEDURE `insert_fusion_job_row` (IN p_job_id int,
IN p_search_request_index int,
IN p_function_id int,
IN p_inquiry_job_data blob)
BEGIN
  DECLARE l_fusion_job_id int;
  INSERT INTO fusion_jobs (function_id,
  job_id,
  inquiry_job_data,
  search_request_index)
    VALUES (p_function_id, p_job_id, p_inquiry_job_data, p_search_request_index);
  SELECT
    LAST_INSERT_ID() INTO l_fusion_job_id;

END