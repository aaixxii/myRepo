package com.nec.aim.uid.zkpdm.curator;

import java.nio.charset.Charset;
import java.util.List;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;

import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.recipes.cache.TreeCache;
import org.apache.curator.framework.recipes.cache.TreeCacheListener;
import org.apache.curator.framework.recipes.locks.InterProcessLock;
import org.apache.curator.framework.recipes.locks.InterProcessMultiLock;
import org.apache.curator.framework.recipes.locks.InterProcessMutex;
import org.apache.curator.framework.recipes.locks.InterProcessReadWriteLock;
import org.apache.curator.framework.recipes.locks.InterProcessSemaphoreMutex;
import org.apache.curator.x.async.AsyncEventException;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.data.Stat;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.nec.aim.uid.zkpdm.exception.CuratorClientException;

import lombok.extern.slf4j.Slf4j;

@Service
@Scope("singleton")
@Slf4j
public class CuratorClient {	
	
	@Autowired
	private CuratorFramework curatorFramework;
	private static final String CHARSET = "utf-8";

	public void createNode(CreateMode mode, String path, String nodeData) {
		try {
			curatorFramework.create().creatingParentsIfNeeded().withMode(mode).forPath(path,
					nodeData.getBytes(Charset.forName(CHARSET)));
			log.info("success to create node");
		} catch (Exception e) {
			throw new CuratorClientException("Faild to create node", e);
		}
	}

	public void deleteNode(final String path) {
		try {
			deleteNode(path, true);
		} catch (Exception e) {
			throw new CuratorClientException("Faild to delete node", e);
		}
	}

	public void deleteNode(final String path, Boolean deleteChildre) {
		try {
			if (deleteChildre) {
				curatorFramework.delete().guaranteed().deletingChildrenIfNeeded().forPath(path);
			} else {
				curatorFramework.delete().guaranteed().forPath(path);
			}
		} catch (Exception e) {
			throw new CuratorClientException("Faild to delete node", e);
		}
	}

	public void setNodeData(String path, byte[] data) {
		try {
			curatorFramework.setData().forPath(path, data);
		} catch (Exception ex) {
			throw new CuratorClientException("Faild to delete node", ex);
		}
	}

	public byte[] getNodeData(String path) {
		try {
			return curatorFramework.getData().forPath(path);
		} catch (Exception e) {
			throw new CuratorClientException("Faild to get nodeData", e);
		}
	}

	public byte[] synNodeData(String path) {
		curatorFramework.sync();
		return getNodeData(path);
	}

	public boolean isExistNode(final String path) {
		curatorFramework.sync();
		try {
			Stat state = curatorFramework.checkExists().forPath(path);
			return state != null;
		} catch (Exception e) {
			return false;
		}
	}

	public List<String> getChildren(String path) {
		List<String> childrenList;
		try {
			childrenList = curatorFramework.getChildren().forPath(path);
		} catch (Exception e) {
			throw new CuratorClientException("Faild to get nodeData", e);
		}
		return childrenList;
	}

	public InterProcessSemaphoreMutex getSemaphoreMutexLock(String path) {
		return new InterProcessSemaphoreMutex(curatorFramework, path);
	}

	public InterProcessMutex getMutexLock(String path) {
		return new InterProcessMutex(curatorFramework, path);
	}

	public InterProcessMultiLock getMultiMutexLock(List<String> paths) {
		return new InterProcessMultiLock(curatorFramework, paths);
	}

	public InterProcessMultiLock getMultiLock(List<InterProcessLock> locks) {
		return new InterProcessMultiLock(locks);
	}

	public void acquire(InterProcessLock lock) {
		try {
			lock.acquire();
		} catch (Exception e) {
			throw new CuratorClientException(e.getMessage(), e);
		}
	}

	public void acquire(InterProcessLock lock, long time, TimeUnit unit) {
		try {
			lock.acquire(time, unit);
		} catch (Exception e) {
			throw new CuratorClientException(e.getMessage(), e);
		}
	}

	public void release(InterProcessLock lock) {
		try {
			lock.release();
		} catch (Exception e) {
			throw new CuratorClientException(e.getMessage(), e);
		}
	}

	public boolean isAcquiredInThisProcess(InterProcessLock lock) {
		return lock.isAcquiredInThisProcess();
	}

	public InterProcessReadWriteLock getReadWriteLock(String path) {
		return new InterProcessReadWriteLock(curatorFramework, path);
	}

	public TreeCache watch(String path, TreeCacheListener listener, Executor pool) {
		TreeCache cache = new TreeCache(curatorFramework, path);
		cache.getListenable().addListener(listener, pool);
		try {
			cache.start();
		} catch (Exception e) {
			throw new CuratorClientException(e.getMessage(), e);
		}
		return cache;
	}

	public TreeCache watch(String path, TreeCacheListener listener) {
		TreeCache cache = new TreeCache(curatorFramework, path);
		cache.getListenable().addListener(listener);
		try {
			cache.start();
		} catch (Exception e) {
			throw new CuratorClientException(e.getMessage(), e);
		}
		return cache;
	}

	public void unwatch(TreeCache cache, TreeCacheListener listener) {
		if (cache == null) {
			throw new CuratorClientException("TreeCache can't be null");
		}
		cache.getListenable().removeListener(listener);
	}	

	
	@SuppressWarnings("unused")
	private void handleWatchedStage(CompletionStage<WatchedEvent> watchedStage) {
		watchedStage.thenAccept(event -> {
			System.out.println(event.getType());
			System.out.println(event);
			// todo
		});

		watchedStage.exceptionally(exception -> {
			AsyncEventException asyncEx = (AsyncEventException) exception;
			asyncEx.printStackTrace(); // handle the error as needed
			handleWatchedStage(asyncEx.reset());
			return null;
		});
	}

}
