package com.nec.aim.uid.zkpdm.curator;

import org.apache.curator.framework.CuratorFramework;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.nec.aim.uid.zkpdm.config.ZkpConfigProperties;

import lombok.extern.slf4j.Slf4j;



@Service
@Scope("singleton")
public class HeadBeatCather {
	
	@Autowired
	private CuratorFramework curatorFramework;

	@Autowired
	ZkpConfigProperties zkpConfig;
	
	

}
