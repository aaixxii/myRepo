package com.nec.aim.uid.zkpdm.controller;

import static com.nec.aim.uid.zkpdm.segments.DmConstants.SEG_FILE_EXTENSION;

import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import com.nec.aim.uid.zkpdm.segments.SegmentDownloadHandler;

import lombok.extern.slf4j.Slf4j;


@Controller
@Slf4j
public class DownloadController extends HttpServlet {
	
	@Autowired
	SegmentDownloadHandler segDownloader;
	private static final long serialVersionUID = -5673372086651421607L;

	@SuppressWarnings("unused")
	@Autowired
	private ServletContext servletContext;

	@GetMapping("/segs/")	
	public void downloadSegment(HttpServletRequest req, HttpServletResponse res) throws IOException {
		Integer segmentId = new Integer(req.getPathInfo().substring(1));
		byte[] segmentData = segDownloader.getSegmentData(segmentId);
		long length = segmentData.length;
		res.setContentType("application/binary");
		res.addHeader("Content-Length", Long.toString(length));				
		res.setHeader("Content-Disposition", "attachment; filename=" + segmentId + SEG_FILE_EXTENSION);
		res.getOutputStream().write(segmentData);
		res.setStatus(200);	
		log.info("Success send segment data to mu, segmentId={}", segmentId);
	}
}
