package com.nec.aim.uid.zkpdm.segments;

import java.io.File;

public class FileUtil {
	
	public static boolean isFileExist(String path) {
		File file = new File(path);
		return file.exists();		
	}	

}
