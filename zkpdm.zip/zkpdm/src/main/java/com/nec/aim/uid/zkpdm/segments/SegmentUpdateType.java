package com.nec.aim.uid.zkpdm.segments;

public enum SegmentUpdateType {
	NEW, UPDATE, DELETE, COMPACTION, RE_CREATE;
}
