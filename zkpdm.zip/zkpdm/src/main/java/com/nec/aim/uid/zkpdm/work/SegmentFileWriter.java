package com.nec.aim.uid.zkpdm.work;

import java.util.concurrent.Callable;

public class SegmentFileWriter implements Callable<Boolean> {
	long segId;
	long segVer;
	long bioId;
	String extId;
	byte[] data;
	
	public SegmentFileWriter(long segId, long bioId, String extId, long segVer, byte[] data ) {
		
	}

	@Override
	public Boolean call() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
