package com.nec.aim.uid.zkpdm.curator;

import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Enumeration;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.listen.Listenable;
import org.apache.curator.framework.recipes.cache.TreeCache;
import org.apache.curator.framework.recipes.cache.TreeCacheEvent;
import org.apache.curator.framework.recipes.cache.TreeCacheEvent.Type;
import org.apache.curator.framework.recipes.cache.TreeCacheListener;
import org.apache.curator.utils.CloseableUtils;
import org.apache.zookeeper.CreateMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.nec.aim.uid.zkpdm.config.ZkpConfigProperties;

import lombok.extern.slf4j.Slf4j;

@Service
@Scope("singleton")
@Slf4j
public class TreeCacher {
	private TreeCache treeCache;
	@Autowired
	private CuratorFramework curatorFramework;

	@Autowired
	ZkpConfigProperties zkpConfig;
	

	@PostConstruct
    public void init() throws Exception {	
		if (!isExistNode(zkpConfig.getHeatbeatNode())) {
			curatorFramework.create().withMode(CreateMode.PERSISTENT).forPath(zkpConfig.getHeatbeatNode(), "dm server list for heatbeat".getBytes());	
		}
		treeCache =  TreeCache.newBuilder(curatorFramework, zkpConfig.getHeatbeatNode()).build();
		TreeCacheListener treeListener = (client, event) -> {
			
			  switch (event.getType())  { 
			  case CONNECTION_LOST:
			  case NODE_ADDED:
			  case NODE_REMOVED:
			  case NODE_UPDATED:
			   //ToDo
				  
			
			  
			  }
		};		
	    treeCache.getListenable().addListener(treeListener);
	    registerMyIP();
	}
	
	@PreDestroy
	public void stop() {
		CloseableUtils.closeQuietly(treeCache);
		CloseableUtils.closeQuietly(curatorFramework);
	}
	
	private void registerMyIP() throws Exception {
		Enumeration<NetworkInterface> e = NetworkInterface.getNetworkInterfaces();
		while (e.hasMoreElements()) {
			  NetworkInterface n = (NetworkInterface) e.nextElement();
			    Enumeration<?> ee = n.getInetAddresses();
			    while (ee.hasMoreElements()) {
			        InetAddress i = (InetAddress) ee.nextElement();
			        if (isMyId(i)) {
			        	curatorFramework.create().withMode(CreateMode.EPHEMERAL_SEQUENTIAL).forPath(zkpConfig.getHeatbeatNode() + i.getHostName(), i.getAddress());
			        }			        
			    }			
		}	
				
	}
	
	private boolean  isMyId(InetAddress addr) {
		String allIp = zkpConfig.getConnectString();
		String[] ipArr = allIp.split(",");
		for (String arr : ipArr) {
			int index = arr.indexOf(":");			
			String ip = arr.substring(0, index -1);
			addr.getHostAddress().equals(ip);
			return true;			
		}		
		return false;
		
	}
	
	public  InetAddress findLeaderIP() {
		byte[] leader = null;
		//Watcher watcher;
		
		try {
			
		} catch (Exception e) {
			
		}
		return null;
		
		
	}
	
	public boolean isExistNode(final String segId) {		
		try {
			return null != curatorFramework.checkExists().forPath("/"  + segId);
		} catch (Exception e) {
			return false;
		}
	}
	
	public String  checkWhoDown() {
		return null;		
	}
}
