package com.nec.aim.client;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;


import lombok.extern.slf4j.Slf4j;


@SpringBootApplication
@EnableDiscoveryClient
@Slf4j
public class AimServiceConsumer {
  @Bean
  public RestTemplate restTemplate() {
    return new RestTemplate();
  }

  public static void main(String[] args) {
    SpringApplication.run(AimServiceConsumer.class, args);
    log.info("Aim clinet  is running!");
  }
}
