package com.nec.aim.audio.service;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "speaker")
@XmlAccessorType(XmlAccessType.FIELD)
public class Speaker implements Serializable{	
	private static final long serialVersionUID = -7429276346853208724L;
	@XmlAttribute(required = true)
	private String name;
	
	@XmlAttribute(required = true)
	private String start;
	
	@XmlAttribute(required = true)
	private String end;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getStart() {
		return start;
	}

	public void setStart(String start) {
		this.start = start;
	}

	public String getEnd() {
		return end;
	}

	public void setEnd(String end) {
		this.end = end;
	}
}
