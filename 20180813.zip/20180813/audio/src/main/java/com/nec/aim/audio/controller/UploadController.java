package com.nec.aim.audio.controller;
import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import lombok.extern.slf4j.Slf4j;


@Controller
@Slf4j
public class UploadController {
	
	
	 @Value("${audio.upload.path}")
	    private String uploadPath;  
	 
	 Charset charset = StandardCharsets.UTF_8;

	   @PostMapping("/upload")
	    @ResponseBody
	    public String singleFileUpload(@RequestParam("file") MultipartFile file, RedirectAttributes redirectAttributes) {
	        if (file.isEmpty()) 
	            return "file is empty, please select a file.";	
	        String fileName = file.getOriginalFilename();
	        uploadPath = uploadPath.endsWith("/") ? uploadPath: uploadPath + "/";	      
	        File dest = new File(uploadPath + fileName);
	        try {
	            file.transferTo(dest);
	           log.info("sucess upload file:" + fileName);
	        } catch (IOException e) {
	            log.error(e.toString(), e);
	        }	 
	        String path = dest.toURI().toString();
	        path = path.substring(6, path.length());
	        byte[] path64 = Base64.getEncoder().encode(path.getBytes(charset));
	        String returnValue =  new String( path64, charset);
	        System.out.println(returnValue);	                
	       // return dest.toURI().toString();
	        return returnValue;
	    }
	   

	        
	   @PostMapping("/multiUpload")
	    @ResponseBody
	    public String multiUpload(HttpServletRequest request) {
		   uploadPath = uploadPath.endsWith("/") ? uploadPath: uploadPath + "/";
	        List<MultipartFile> files = ((MultipartHttpServletRequest) request).getFiles("file");	       
	        for (int i = 0; i < files.size(); i++) {
	            MultipartFile file = files.get(i);
	            if (file.isEmpty()) {
	                return "file" + (i++) + "is empty";	            }
	            String fileName = file.getOriginalFilename();
	            File dest = new File(uploadPath + fileName);
	            try {
	                file.transferTo(dest);	               
	            } catch (IOException e) {
	                log.error(e.toString(), e);
	                return "file" + (i++) + "upload failed.";
	            }
	        }
	        return files.size() + "files" + "sucess upload!";
	    } 
}
