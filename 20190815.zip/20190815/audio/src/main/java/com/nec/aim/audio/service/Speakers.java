package com.nec.aim.audio.service;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "speakers")
@XmlAccessorType(XmlAccessType.FIELD)
public class Speakers {
	
	 @XmlElement(name = "speaker")
	    private List<Speaker> speakerList = null;

	public List<Speaker> getSpeakerList() {
		return speakerList;
	}

	public void setSpeakerList(List<Speaker> speakerList) {
		this.speakerList = speakerList;
	} 
}
