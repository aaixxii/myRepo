#create dmdb user

DROP DATABASE IF EXISTS DMDB;

CREATE DATABASE DMDB character set utf8mb4;

DROP USER IF EXISTS dmuser;

CREATE USER 'dmuser'@'%' IDENTIFIED BY 'dmuser@SV99';
GRANT ALL PRIVILEGES ON *.* TO 'dmuser'@'%' WITH GRANT OPTION;
flush privileges;

