package com.nec.aim.uid.zkpdm.curator;

import java.util.List;
import java.util.Objects;
import java.util.concurrent.ExecutionException;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.recipes.cache.ChildData;
import org.apache.curator.framework.recipes.cache.NodeCache;
import org.apache.curator.framework.recipes.cache.NodeCacheListener;
import org.apache.curator.framework.recipes.cache.PathChildrenCache;
import org.apache.curator.utils.CloseableUtils;
import org.apache.curator.utils.ZKPaths;
import org.apache.zookeeper.CreateMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.google.protobuf.InvalidProtocolBufferException;
import com.nec.aim.uid.zkpdm.config.ZkpConfigProperties;
import com.nec.aim.uid.zkpdm.exception.CuratorClientException;
import com.nec.aim.uid.zkpdm.segments.SegmentInfo;
import com.nec.aim.uid.zkpdm.segments.SegmentManager;
import com.nec.aim.uid.zkpdm.segments.SegmentOperator;
import com.nec.aim.uid.zkpdm.segments.SegmentUpdateType;

import jp.co.nec.aim.message.proto.AIMEnumTypes.SegmentSyncCommandType;
import jp.co.nec.aim.message.proto.AIMMessages.PBDmSyncRequest;
import lombok.extern.slf4j.Slf4j;

@Service
@Scope("singleton")
@Slf4j
public class NodeCacher {

	private NodeCache nodeCache;

	@Autowired
	private CuratorFramework curatorFramework;

	@Autowired
	ZkpConfigProperties zkpConfig;
	
	@PostConstruct
    public void init() throws Exception {			
	}
	
	
	@PreDestroy
	public void stop() {
		CloseableUtils.closeQuietly(nodeCache);
		CloseableUtils.closeQuietly(curatorFramework);
	}

	public boolean createNewNode(CreateMode mode, String segId, byte[] nodeData) throws Exception {
		nodeCache = new NodeCache(curatorFramework,  "/" + segId);
		nodeCache.start(true);		
		nodeCache.getListenable().addListener(new NodeCacheListener() {
			@Override
			public void nodeChanged() throws Exception {
				doUpdateSegment(segId, nodeData);
			}
		});
		return doUpdateSegment(segId, nodeData);
	}
	
	public boolean updateNode(String segId, byte[] nodeData) throws Exception {	
		try {
			curatorFramework.setData().forPath("/" + segId, nodeData);
			return true;
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			return false;
		}
	}

	public boolean deleteNode(final String path) {
		try {
			deleteNode(path, false);
			return true;
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			return false;
		}
	}

	public void deleteNode(final String path, Boolean deleteChildre) {
		try {
			if (deleteChildre) {
				curatorFramework.delete().guaranteed().deletingChildrenIfNeeded().forPath(path);
			} else {
				curatorFramework.delete().guaranteed().forPath(path);
			}
		} catch (Exception e) {
			throw new CuratorClientException("Faild to delete node", e);
		}
	}

	public void setNodeData(String path, byte[] data) {
		try {
			curatorFramework.setData().forPath(path, data);			
		} catch (Exception ex) {
			throw new CuratorClientException("Faild to update node data", ex);			
		}
	}

	public byte[] getNodeData(String path) {
		try {
			return curatorFramework.getData().forPath(path);
		} catch (Exception e) {
			throw new CuratorClientException("Faild to get nodeData", e);
		}
	}

	public byte[] synNodeData(String path) {
		curatorFramework.sync();
		return getNodeData(path);
	}

	public boolean isExistNode(final String segId) {		
		try {
			return null != curatorFramework.checkExists().forPath("/"  + segId);
		} catch (Exception e) {
			return false;
		}
	}

	public List<String> getChildren(String path) {
		List<String> childrenList;
		try {
			childrenList = curatorFramework.getChildren().forPath(path);
		} catch (Exception e) {
			throw new CuratorClientException("Faild to get nodeData", e);
		}
		return childrenList;
	}

	@SuppressWarnings("unused")
	private boolean deleteNodeAfterSuccess(final String path) {
		try {
			deleteNode("/" + path, false);
			return true;
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			return false;
		}
	}
	
	@SuppressWarnings("unused")
	private void doNewSegment(String segmentId, byte[] nodeData)  {
		System.out.println("Node changed: " + ZKPaths.getNodeFromPath("/" + segmentId));
		try {
			PBDmSyncRequest dmSegReq = PBDmSyncRequest.parseFrom(nodeData);
			SegmentInfo segInfo = new SegmentInfo(Long.valueOf(segmentId));	
			SegmentOperator segOprater = SegmentOperator.getInstance();
			segOprater.init(Long.valueOf(segmentId), zkpConfig.getSavePath());
			segInfo.setSegOperator(segOprater);	
			SegmentManager.saveToQueue(Long.parseLong(segmentId), segInfo);			
			boolean successed = segOprater.processRequest(dmSegReq, segInfo, SegmentUpdateType.NEW);
			if (successed) {
				log.info("Success create new segment file, segmentId ={}", segmentId);
			}
			
		} catch (InvalidProtocolBufferException | InterruptedException | ExecutionException e) {
			log.error(e.getMessage(), e);
			throw new CuratorClientException(e);
		}
	}
	
	private boolean doUpdateSegment(String segmentId, byte[] nodeData)  {
		System.out.println("Node changed: " + ZKPaths.getNodeFromPath("/" + segmentId));
		boolean successed = false;
		try {
			PBDmSyncRequest dmSegReq = PBDmSyncRequest.parseFrom(nodeData);
			String changeType = dmSegReq.getCmd().name().toUpperCase();
			SegmentInfo segInfo = SegmentManager.getSegmentInfo(Long.valueOf(segmentId));			
			SegmentOperator segOprater = null;
			if (Objects.isNull(segInfo)) {			
				segInfo = new SegmentInfo(Long.valueOf(segmentId));	
				segOprater = SegmentOperator.getInstance();
				segOprater.init(Long.valueOf(segmentId), zkpConfig.getSavePath());
				segInfo.setSegOperator(segOprater);	
				SegmentManager.saveToQueue(segInfo.getSegId(), segInfo);
				if (changeType.equals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT.name())) {
					 successed = segOprater.processRequest(dmSegReq, segInfo, SegmentUpdateType.NEW);
						if (successed) {
							log.info("Success create new segment file, segmentId ={}", segmentId);
						}
				} 
			} else {				
				segOprater = segInfo.getSegOperator();
				if (Objects.isNull(segOprater)) {
					segOprater = SegmentOperator.getInstance();
					segOprater.init(Long.valueOf(segmentId), zkpConfig.getSavePath());
					segInfo.setSegOperator(segOprater);
					SegmentManager.updateToQueue(segInfo.getSegId(), segInfo);
				}
				if (changeType.equals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT.name())) {
					 successed = segOprater.processRequest(dmSegReq, segInfo, SegmentUpdateType.UPDATE);
				} else if (changeType.equals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_DELETE.name())) {
					successed = segOprater.processRequest(dmSegReq, segInfo, SegmentUpdateType.DELETE);
				}			
				if (successed) {
					log.info("Success update  segment data, segmentId ={}", segmentId);
				}	
			}			
			
		} catch (InvalidProtocolBufferException | InterruptedException | ExecutionException e) {
			log.error(e.getMessage(), e);
			throw new CuratorClientException(e);
		}
		return successed;
	}		


	@SuppressWarnings("unused")
	private static void list(PathChildrenCache cache) {
		if (cache.getCurrentData().size() == 0) {
			System.out.println("* empty *");
		} else {
			for (ChildData data : cache.getCurrentData()) {
				System.out.println(data.getPath() + " = " + new String(data.getData()));
			}
		}
	}

}
