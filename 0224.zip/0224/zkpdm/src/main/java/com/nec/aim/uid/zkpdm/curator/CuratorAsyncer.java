package com.nec.aim.uid.zkpdm.curator;

import java.util.concurrent.CompletionStage;

import javax.annotation.PostConstruct;

import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.x.async.AsyncCuratorFramework;
import org.apache.curator.x.async.AsyncEventException;
import org.apache.curator.x.async.WatchMode;
import org.apache.zookeeper.WatchedEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

@Service
@Scope("singleton")
@Slf4j
public class CuratorAsyncer {
	private AsyncCuratorFramework asyncClient;

	@Autowired
	private CuratorFramework curatorFramework;

	@PostConstruct
	public void init() {
		asyncClient = AsyncCuratorFramework.wrap(curatorFramework);
	}

	public void create(String path, byte[] payload) {
		asyncClient = AsyncCuratorFramework.wrap(curatorFramework);
		asyncClient.create().forPath(path, payload).whenComplete((name, exception) -> {
			if (exception != null) {
				log.error(exception.getMessage(), exception);
			} else {
				log.info("Created node name is: " + name);
				// Todo
			}
		});
	}

	public void createThenWatch(String path) {
		asyncClient.create().forPath(path).whenComplete((name, exception) -> {
			if (exception != null) {
				log.error(exception.getMessage(), exception);
			} else {
				handleWatchedStage(asyncClient.watched().checkExists().forPath(path).event());
			}
		});
	}

	public void createThenWatchSimple(CuratorFramework client, String path) {
		asyncClient.create().forPath(path).whenComplete((name, exception) -> {
			if (exception != null) {
				log.error(exception.getMessage(), exception);
			} else {
				asyncClient.with(WatchMode.successOnly).watched().checkExists().forPath(path).event()
						.thenAccept(event -> {
							System.out.println(event.getType());
							System.out.println(event);
						});
			}
		});
	}

	private void handleWatchedStage(CompletionStage<WatchedEvent> watchedStage) {
		watchedStage.thenAccept(event -> {
			System.out.println(event.getType());
			System.out.println(event);
			// todo
		});

		watchedStage.exceptionally(exception -> {
			AsyncEventException asyncEx = (AsyncEventException) exception;
			asyncEx.printStackTrace(); // handle the error as needed
			handleWatchedStage(asyncEx.reset());
			return null;
		});
	}
}
