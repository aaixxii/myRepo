package com.nec.aim.uid.zkpdm.segments;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

@Service
@Scope("prototype")
@Slf4j
public class SegmentDownloadHandler {
	
	private static String HDFS_PATH = "/SEGMENTS";
	
	public byte[] getSegmentData(long segmentId) throws IOException {	
		String strPath = HDFS_PATH + "/" + String.valueOf(segmentId);
		File file = new File(strPath);
		if (!file.exists()) {
			log.warn("There are some wrong, the file:{} is not exist!", segmentId);
			return null;
		}
		byte[] byteData = null;	
		byte[] buffer = new byte[1024 * 10];
		FileInputStream input = null;
			try {
				input = new FileInputStream(file);
				input.read(buffer);
				//ToDo
				 log.info("Success get segment({}) data", segmentId);
			} catch (Exception e) {
				log.error(e.getMessage(), e);
				byteData =  null;
			}
		
		
		return byteData;		
	}	

}
