package com.nec.aim.uid.zkpdm.segments;

import javax.annotation.PostConstruct;

import org.apache.zookeeper.CreateMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nec.aim.uid.zkpdm.config.ZkpConfigProperties;
import com.nec.aim.uid.zkpdm.curator.NodeCacher;

import jp.co.nec.aim.message.proto.AIMMessages.PBDmSyncRequest;
import lombok.extern.slf4j.Slf4j;

@Service
public class SegmentOperationHandler {
	
	@Autowired	
	NodeCacher nodeCacher;
	
	@Autowired
	ZkpConfigProperties zkpConfig;
	
	
	

	@PostConstruct
	public void init() {
	}	

	public boolean handerRequest(PBDmSyncRequest dmSegRequest) throws Exception {
		PBDmSyncRequest dmSegReq = PBDmSyncRequest.parseFrom(dmSegRequest.toByteString());		
		long segId = dmSegReq.getTargetSegments().getId();	
		boolean result = false;
		String path = zkpConfig.getNamespace().endsWith("/") ? zkpConfig.getNamespace() + String.valueOf(segId) : zkpConfig.getNamespace() +"/" + String.valueOf(segId);
		if (!FileUtil.isFileExist(path)) {
		//if (!nodeCacher.isExistNode(String.valueOf(segId))) {			
			result =  nodeCacher.createNewNode(CreateMode.PERSISTENT_SEQUENTIAL, String.valueOf(segId), dmSegReq.toByteArray());
					
		} else {
			result =  nodeCacher.updateNode(String.valueOf(segId), dmSegReq.toByteArray());
		}
		return result;
		
	}
}




