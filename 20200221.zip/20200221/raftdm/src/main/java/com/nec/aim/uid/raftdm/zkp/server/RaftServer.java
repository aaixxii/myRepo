package com.nec.aim.uid.raftdm.zkp.server;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alipay.remoting.rpc.RpcServer;
import com.alipay.sofa.jraft.Node;
import com.alipay.sofa.jraft.RaftGroupService;
import com.alipay.sofa.jraft.conf.Configuration;
import com.alipay.sofa.jraft.core.TimerManager;
import com.alipay.sofa.jraft.entity.PeerId;
import com.alipay.sofa.jraft.option.NodeOptions;
import com.alipay.sofa.jraft.rpc.RaftRpcServerFactory;

public class RaftServer { 
	
	private static final Logger logger = LoggerFactory.getLogger(RaftServer.class);
    private RaftGroupService raftGroupService;
    
    private Node node;    
    private DmSyncRequestTatusMachine fsm;

    public RaftServer(String dataPath, String groupId, PeerId serverId, NodeOptions nodeOptions) throws IOException {        
        FileUtils.forceMkdir(new File(dataPath)); 
//		try {
//			 Class<TimerManager> tmClass = TimerManager.class;
//			 TimerManager tm = (TimerManager) tmClass.newInstance();
//			Method method = tmClass.getDeclaredMethod("init");
//			method.setAccessible(true);
//	        try {
//				method.invoke(tm, 50);
//			} catch (IllegalArgumentException | InvocationTargetException e) {
//				logger.error(e.getMessage(), e);
//			}
//		} catch (NoSuchMethodException | SecurityException | InstantiationException | IllegalAccessException e) {
//			logger.error(e.getMessage(), e);
//		}
        
       
        RpcServer rpcServer = new RpcServer(serverId.getPort());
        RaftRpcServerFactory.addRaftRequestProcessors(rpcServer);        
        rpcServer.registerUserProcessor(new DmSyncRequestProcessor(this));
        //rpcServer.registerUserProcessor(new IncrementAndGetRequestProcessor(this));       
        this.fsm = new DmSyncRequestTatusMachine();        
        nodeOptions.setFsm(this.fsm);        
        nodeOptions.setLogUri(dataPath + File.separator + "log");       
        nodeOptions.setRaftMetaUri(dataPath + File.separator + "raft_meta");        
        nodeOptions.setSnapshotUri(dataPath + File.separator + "snapshot");       
        this.raftGroupService = new RaftGroupService(groupId, serverId, nodeOptions, rpcServer);        
        this.node = this.raftGroupService.start();
    }

    public DmSyncRequestTatusMachine getFsm() {
        return this.fsm;
    }

    public Node getNode() {
        return this.node;
    }

    public RaftGroupService RaftGroupService() {
        return this.raftGroupService;
    }
    
    public ValueResponse redirect() {
        ValueResponse response = new ValueResponse();
        response.setSuccess(false);
        if (node != null) {
            PeerId leader = node.getLeaderId();
            if (leader != null) {
                response.setRedirect(leader.toString());
            }
        }

        return response;
    }

    public void init (String dataPath, String groupId, String myIpPort, String serverIdsPorts) throws IOException {   

        NodeOptions nodeOptions = new NodeOptions();        
        nodeOptions.setElectionTimeoutMs(5000);
        nodeOptions.setDisableCli(false);
        nodeOptions.setSnapshotIntervalSecs(30);       
        PeerId serverId = new PeerId();
        if (!serverId.parse(myIpPort)) {
            throw new IllegalArgumentException("Fail to parse serverId:" + myIpPort);
        }
        Configuration initConf = new Configuration();
        if (!initConf.parse(serverIdsPorts)) {
            throw new IllegalArgumentException("Fail to parse initConf:" + serverIdsPorts);
        }      
        nodeOptions.setInitialConf(initConf);
       
        RaftServer raftServer = new RaftServer(dataPath, groupId, serverId, nodeOptions);
        System.out.println("Started counter server at port:"
                           + raftServer.getNode().getNodeId().getPeerId().getPort());
    }
}