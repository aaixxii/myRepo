package com.nec.aim.uid.raftdm.zkp.server;

import com.alipay.sofa.jraft.Closure;
import com.alipay.sofa.jraft.Status;

import jp.co.nec.aim.message.proto.AIMMessages.PBDmSyncRequest;

public class DmSyncRequestClosure implements Closure {
	 private RaftServer raftServer;
	    private PBDmSyncRequest request;
	    private ValueResponse response;
	    private Closure done;
	    
	public DmSyncRequestClosure(RaftServer dmServer, PBDmSyncRequest request, ValueResponse response, Closure done) {
		super();
		this.raftServer = dmServer;
		this.request = request;
		this.response = response;
		this.done = done;
	}

	  @Override
	    public void run(Status status) {	        
	        if (this.done != null) {
	            done.run(status);
	        }
	    }

	    public PBDmSyncRequest getRequest() {
	        return this.request;
	    }

	    public void setRequest(PBDmSyncRequest request) {
	        this.request = request;
	    }

		public ValueResponse getResponse() {
			return response;
		}
		    
}
