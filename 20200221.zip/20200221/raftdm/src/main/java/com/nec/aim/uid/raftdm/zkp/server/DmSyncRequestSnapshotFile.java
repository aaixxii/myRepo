package com.nec.aim.uid.raftdm.zkp.server;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DmSyncRequestSnapshotFile {

    private static final Logger LOG = LoggerFactory.getLogger(DmSyncRequestSnapshotFile.class);

    private String              path;

    public DmSyncRequestSnapshotFile(String path) {
        super();
        this.path = path;
    }

    public String getPath() {
        return this.path;
    }

    /**
     * Save value to snapshot file.
     */
    public boolean save(final boolean value) {
        try {
            FileUtils.writeStringToFile(new File(path), String.valueOf(value));
            return true;
        } catch (IOException e) {
            LOG.error("Fail to save snapshot", e);
            return false;
        }
    }

    public boolean load() throws IOException {
        final String s = FileUtils.readFileToString(new File(path));
        if (s != null && ! s.isEmpty()) {
            return Boolean.parseBoolean(s);
        }
        throw new IOException("Fail to load snapshot from " + path + ",content: " + s);
    }
}
