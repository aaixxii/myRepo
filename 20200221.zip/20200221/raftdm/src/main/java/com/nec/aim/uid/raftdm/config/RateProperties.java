package com.nec.aim.uid.raftdm.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Data;

@Data
@Component
@ConfigurationProperties(prefix = "raft")
public class RateProperties {
	
	@Value("${raft.datapath}")
    private String datapath; //path for raft(log etc.)
	
	@Value("${raft.groupid}")
    private String dmGroup;
	
	@Value("${raft.myid}")
    private String myId; //like 127.0.0.1:8081 
	
	@Value("${raft.connection.str}")
    private String conectionStr; //like 127.0.0.1:8081 127.0.0.1:8081,127.0.0.1:8082,127.0.0.1:8083

}
