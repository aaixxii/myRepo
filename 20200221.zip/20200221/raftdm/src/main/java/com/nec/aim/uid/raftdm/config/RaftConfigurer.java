package com.nec.aim.uid.raftdm.config;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.alipay.sofa.jraft.entity.PeerId;
import com.alipay.sofa.jraft.option.NodeOptions;
import com.nec.aim.uid.raftdm.zkp.server.RaftServer;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Configuration
@Slf4j
@Data
public class RaftConfigurer {
	
	@Autowired
	RateProperties raftProperties;

	
	 @Bean
	 public RaftServer buildRafteServer() throws IOException {	
	        NodeOptions nodeOptions = new NodeOptions();        
	        nodeOptions.setElectionTimeoutMs(5000);
	        nodeOptions.setDisableCli(false);
	        nodeOptions.setSnapshotIntervalSecs(30);       
	        PeerId serverId = new PeerId();
	        if (!serverId.parse(raftProperties.getMyId())) {
	            throw new IllegalArgumentException("Fail to parse serverId:" + raftProperties.getMyId());
	        }
	        com.alipay.sofa.jraft.conf.Configuration initConf = new com.alipay.sofa.jraft.conf.Configuration();
	        if (!initConf.parse(raftProperties.getConectionStr())) {
	            throw new IllegalArgumentException("Fail to parse initConf:" + raftProperties.getConectionStr());
	        }      
	        nodeOptions.setInitialConf(initConf);	       
	        RaftServer raftServer = new RaftServer(raftProperties.getDatapath(), raftProperties.getDmGroup(), serverId, nodeOptions);	        
	        log.info("Started counter server at port:"
	                           + raftServer.getNode().getNodeId().getPeerId().getPort());
	        return raftServer;
	}
}
