package com.nec.aim.uid.dmclient.rpc;

import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;

import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.alipay.remoting.InvokeCallback;
import com.alipay.remoting.exception.RemotingException;
import com.alipay.sofa.jraft.RouteTable;
import com.alipay.sofa.jraft.conf.Configuration;
import com.alipay.sofa.jraft.entity.PeerId;
import com.alipay.sofa.jraft.option.CliOptions;
import com.alipay.sofa.jraft.rpc.impl.cli.BoltCliClientService;
import com.nec.aim.uid.dmclient.config.RateProperties;

import jp.co.nec.aim.message.proto.AIMMessages.PBDmSyncRequest;
import lombok.extern.slf4j.Slf4j;

@Service
@Scope("prototype")
@Slf4j
public class RafeDmSyncRequestSender {

	@Autowired
	RateProperties raftProperties;

	public boolean dmSyncRequestProcess(PBDmSyncRequest dmSegReq) throws Exception {
		final String groupId = raftProperties.getDmGroup();
		final String confStr = raftProperties.getConectionStr();

		final Configuration conf = new Configuration();
		if (!conf.parse(confStr)) {
			throw new IllegalArgumentException("Fail to parse conf:" + confStr);
		}

		RouteTable.getInstance().updateConfiguration(groupId, conf);

		final BoltCliClientService cliClientService = new BoltCliClientService();
		cliClientService.init(new CliOptions());

		if (!RouteTable.getInstance().refreshLeader(cliClientService, groupId, 1000).isOk()) {
			throw new IllegalStateException("Refresh leader failed");
		}

		final PeerId leader = RouteTable.getInstance().selectLeader(groupId);
		log.info("Leader is " + leader);
		final long start = System.currentTimeMillis();
		final AtomicBoolean res = new AtomicBoolean(false);
		sendDmSyncInsertRequest(res, dmSegReq, cliClientService, leader);
		log.info(" ops, cost : " + (System.currentTimeMillis() - start) + " ms.");
		return res.get();
	}

	@PreDestroy
	public void stop() {

	}

	private static void sendDmSyncInsertRequest(final AtomicBoolean resValue, final PBDmSyncRequest dmSegReq,
			final BoltCliClientService cliClientService, final PeerId leader)
			throws RemotingException, InterruptedException {
		cliClientService.getRpcClient().invokeWithCallback(leader.getEndpoint().toString(), dmSegReq,
				new InvokeCallback() {
					@Override
					public void onResponse(Object result) {
						if (result != null) {
							System.out.println("DmSync result:" + result);
							resValue.set((boolean) result);
						}
					}

					@Override
					public void onException(Throwable e) {
						e.printStackTrace();
					}

					@Override
					public Executor getExecutor() {
						return null;
					}
				}, 5000);
	}

}
