package com.nec.aim.uid.dmclient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DmclientApplication {

	public static void main(String[] args) {
		SpringApplication.run(DmclientApplication.class, args);
	}

}
