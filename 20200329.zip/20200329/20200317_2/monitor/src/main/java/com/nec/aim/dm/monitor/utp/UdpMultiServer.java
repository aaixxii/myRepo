package com.nec.aim.dm.monitor.utp;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;

public class UdpMultiServer {

	private static MulticastSocket ds;
	static String multicastHost = "239.0.1.255";
	static InetAddress receiveAddress;

	public static void main(String[] args) throws IOException {
	        ds = new MulticastSocket(8899);	        
	        receiveAddress = InetAddress.getByName(multicastHost);	       
	        ds.joinGroup(receiveAddress);	       
	        new Thread() {
			public void run() {
				byte buf[] = new byte[1024];
				DatagramPacket dp = new DatagramPacket(buf, 1024);
				while (true) {
					try {
						System.out.println("美女（没有帅哥）准备好了：");
						ds.receive(dp);
						String receiveMsg = new String(buf, 0, dp.getLength());
						System.out.println("美女听到街上有人喊：" + receiveMsg);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
	     }.start();
	}

}
