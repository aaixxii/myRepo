package com.nec.aim.dm.monitor.dao;

import java.sql.SQLException;

public interface MasterDao {
	public int setToken() throws SQLException;
	public void setTokenToZero() throws SQLException;
	public DmInfo getMyDmInfo() throws SQLException;
	public int setLock() throws SQLException;
	public int releaseLock() throws SQLException;
}
