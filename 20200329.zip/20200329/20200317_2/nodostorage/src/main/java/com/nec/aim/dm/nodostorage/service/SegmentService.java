package com.nec.aim.dm.nodostorage.service;

import static com.nec.aim.dm.nodostorage.segments.DmConstants.SEGMENT_HEADER_SIZE;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nec.aim.dm.nodostorage.config.ConfigProperties;
import com.nec.aim.dm.nodostorage.exception.NodeStroageException;
import com.nec.aim.dm.nodostorage.manager.NodeStorageManager;
import com.nec.aim.dm.nodostorage.repository.DmConfigRepository;
import com.nec.aim.dm.nodostorage.repository.NodeStorageRepository;
import com.nec.aim.dm.nodostorage.segments.SegmentWriter;

import jp.co.nec.aim.message.proto.AIMEnumTypes.SegmentSyncCommandType;
import jp.co.nec.aim.message.proto.AIMMessages.PBDmSyncRequest;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class SegmentService {
	
	@Autowired
	NodeStorageRepository nodeStorageRepository;
	
	@Autowired
	DmConfigRepository dmConfigRepository;
	
	@Autowired
	ConfigProperties config;
	
	@Transactional
	public boolean handlePostRequest(PBDmSyncRequest dmSegReq) {
		String changeType = null;
		Long bioIdStart = null;	
		Long bioIdEnd = null;		
		Long segId = null;	
		Long segVer = null;
		Boolean result = null;
		try {
			changeType = dmSegReq.getCmd().name().toUpperCase();	
			if (dmSegReq.hasBioIdStart()) {
				bioIdStart = Long.valueOf((int)dmSegReq.getBioIdStart());
			}
			
			if (dmSegReq.hasBioIdEnd()) {
				bioIdEnd = Long.valueOf((int)dmSegReq.getBioIdEnd());
			}
					
			segId = Long.valueOf(dmSegReq.getTargetSegment().getId());	
			segVer = dmSegReq.getTargetSegment().getVersion();
			SegmentWriter segWriter = null;
			if (changeType.equals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_NEW.name())) { // add segment		
				if (null == bioIdStart) {
					throw new NodeStroageException("bioId_start can't be null in " + SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_NEW.name().toLowerCase()); 
				}
				segWriter = new SegmentWriter(segId, bioIdStart);				
				result = segWriter.writeSegmentHead();	
				nodeStorageRepository.updateStorageSpace(SEGMENT_HEADER_SIZE, NodeStorageManager.getIntDmConfigValue("myId"), NodeStorageManager.getStringDmConfigValue("myDmId"));
			}  else if (changeType.equals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT.name())) { // update template
				if (null == bioIdEnd) {
					throw new NodeStroageException("bioId_end can't be  null in " + SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT.name().toLowerCase()); 
				}
				segWriter = NodeStorageManager.getSegmentWriter(segId);
				if (null == segWriter) {
					//throw new NodeStroageException("There are some wrong in segment file, segmentId=" + segId ) ;
					segWriter = new SegmentWriter(segId, bioIdStart);
					segWriter.writeSegmentHead();
				}
				result = segWriter.writeTemplate(dmSegReq);
				nodeStorageRepository.updateStorageSpace(NodeStorageManager.getIntDmConfigValue("templateSize"), NodeStorageManager.getIntDmConfigValue("myId"), NodeStorageManager.getStringDmConfigValue("myDmId"));
		    } else if (changeType.equals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_DELETE.name())) { // delete template
		    	if (null == bioIdEnd) {
					throw new NodeStroageException("bioId_end can't be  null in " + SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_DELETE.name().toLowerCase()); 
				}
		    	segWriter = NodeStorageManager.getSegmentWriter(segId);
		    	if (null == segWriter) {
					//throw new NodeStroageException("There are some wrong in segment file, segmentId=" + segId ) ;
		    		segWriter = new SegmentWriter(segId, bioIdStart);
		    		segWriter.writeSegmentHead();
				}
		    	String exteralId  = dmSegReq.getTemplateData().getReferenceId();
		    	
		    	if (exteralId == null) {
		    		log.error("External ID can't be null for delete template.");
		    		result=  Boolean.FALSE;
		    	}
		    	result =segWriter.deleteTemplate(segId, segVer, bioIdEnd, exteralId);	
		    	nodeStorageRepository.updateStorageSpace(-1 * NodeStorageManager.getIntDmConfigValue("templateSize"),NodeStorageManager.getIntDmConfigValue("myId"), NodeStorageManager.getStringDmConfigValue("myDmId"));
			}			
		} catch (Exception e) {
			throw new NodeStroageException(e);
		}
		return result.booleanValue();		
	}
}
