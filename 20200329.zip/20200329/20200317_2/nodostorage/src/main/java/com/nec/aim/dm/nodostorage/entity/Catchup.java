package com.nec.aim.dm.nodostorage.entity;

import java.sql.Blob;

import lombok.Data;

@Data
public class Catchup {
	Long segmentChangId;
	Integer storageId;
	Long  bioIdstart;
	Long bioIdEnd;
	String externalId;
	Blob templateData;
	Long segmentId;
	Long segmentVersion;
	Integer changeType; //new:0,insert:1,delete:2,update:3 
}
