package com.nec.aim.dm.nodostorage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import lombok.extern.slf4j.Slf4j;

@SpringBootApplication
@Slf4j
public class NodostorageApplication {

	public static void main(String[] args) {
		SpringApplication.run(NodostorageApplication.class, args);	
		log.info("Node storage manage success started!");
	}
}
