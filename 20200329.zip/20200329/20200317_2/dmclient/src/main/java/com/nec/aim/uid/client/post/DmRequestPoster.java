package com.nec.aim.uid.client.post;

import static com.nec.aim.uid.client.common.UidClientConstants.DM_CONCURRENT_COUNT;
import static com.nec.aim.uid.client.common.UidClientConstants.JOB_TEMPLATES_PATH;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.protobuf.ByteString;
import com.nec.aim.uid.client.exception.UidClientException;
import com.nec.aim.uid.client.manager.UidCommonManager;
import com.nec.aim.uid.client.manager.UidDmJobRunManager;
import com.nec.aim.uid.client.proerties.PropertyNames;
import com.nec.aim.uid.client.util.FileUtil;
import com.nec.aim.uid.client.util.StopWatch;
import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;
import com.squareup.okhttp.Response;

import jp.co.nec.aim.message.proto.AIMEnumTypes.SegmentSyncCommandType;
import jp.co.nec.aim.message.proto.AIMMessages.PBDmSyncRequest;
import jp.co.nec.aim.message.proto.AIMMessages.PBDmSyncResponce;
import jp.co.nec.aim.message.proto.AIMMessages.PBTargetSegmentVersion;
import jp.co.nec.aim.message.proto.BusinessMessage.PBTemplateInfo;

public class DmRequestPoster implements Runnable {
	private static Logger logger = LoggerFactory.getLogger(DmRequestPoster.class);
	private static long postTimeOut = 6000;
	private static final MediaType MEDIA_TYPE_PLAINTEXT = MediaType.parse("text/plain; charset=utf-8");
	private List<String> fileList;

	public DmRequestPoster(List<String> files) {
		this.fileList = files;
	}

	@Override
	public void run() {
		String concurentJobCount = UidCommonManager.getValue(DM_CONCURRENT_COUNT);
		if (fileList.size() == 1 && concurentJobCount != null && Integer.valueOf(concurentJobCount) > 0) {
			for (int i = 0; i < Integer.valueOf(concurentJobCount); i++) {
				buildDmJobRequest(fileList.get(0));
			}
		} else {
			for (String one : fileList) {
				buildDmJobRequest(one);
			}
		}
	}

	private static void buildDmJobRequest(String dmRequestFile) {
		Properties prop = new Properties();
		PBDmSyncRequest.Builder dmRequest = PBDmSyncRequest.newBuilder();
		try (InputStream input = new FileInputStream(dmRequestFile)) {
			prop.load(input);
			String activeDmServices = UidDmJobRunManager.getOneActiveDm();
			if (activeDmServices == null || activeDmServices.isEmpty()) {
				logger.warn("No Active Dm Service!, Skip process.");
				return;
			}
			String dmUrl =  activeDmServices + "/dmSyncSegment";
			String dmDownLoadUrl = activeDmServices + "/seg/";
			
			String dmDownloadSegId = prop.getProperty(PropertyNames.DM_DOWNLOAD_SEG_ID.name());
			if (dmDownloadSegId != null && !dmDownloadSegId.isEmpty() && !dmDownloadSegId.startsWith("-1")) {
				String httpGetUrl = dmDownLoadUrl + dmDownloadSegId;
				byte[] downloaded = getSegment(httpGetUrl, Long.valueOf(dmDownloadSegId));
				if (downloaded != null) {
					logger.info("Download segmentData from dm , data size  ={}", downloaded.length);
				} else {
					logger.warn("there are som worg, get empty data from dm service. segmentId={}, dm service url ={}", dmDownloadSegId, httpGetUrl );
				}
				return;
			}

			String dmReqCmd = prop.getProperty(PropertyNames.DM_REQ_CMD.name());
			if (dmReqCmd != null && !dmReqCmd.isEmpty() && !dmReqCmd.startsWith("-1")) {
				if (String.format(dmReqCmd).startsWith("INSERT")) {
					dmRequest.setCmd(SegmentSyncCommandType.valueOf(2));
				} else if (String.format(dmReqCmd).startsWith("DELETE")) {
					dmRequest.setCmd(SegmentSyncCommandType.valueOf(3));
				}  else if (String.format(dmReqCmd).startsWith("NEW")) {	
			    	 dmRequest.setCmd(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_NEW);
			    }
			}
			
			String dmReqBioIdStart = prop.getProperty(PropertyNames.DM_REQ_BIO_ID_START.name());
			if (dmReqBioIdStart != null && !dmReqBioIdStart.isEmpty() && !dmReqBioIdStart.startsWith("-1")) {
				dmRequest.setBioIdStart(Long.valueOf(dmReqBioIdStart));
			}
			
			String dmReqBioIdEnd = prop.getProperty(PropertyNames.DM_REQ_BIO_ID_END.name());
			if (dmReqBioIdEnd != null && !dmReqBioIdEnd.isEmpty() && !dmReqBioIdEnd.startsWith("-1")) {
				dmRequest.setBioIdEnd(Long.valueOf(dmReqBioIdEnd));
			}			
			
			PBTemplateInfo.Builder templateInfo = PBTemplateInfo.newBuilder();
			String dmReqExternalId = prop.getProperty(PropertyNames.DM_REQ_REF_ID.name());
			if (dmReqExternalId != null && !dmReqExternalId.isEmpty() && !dmReqExternalId.startsWith("-1")) {
				templateInfo.setReferenceId(dmReqExternalId);
			}
			String dmReqTemplatePath = prop.getProperty(PropertyNames.DM_REQ_TEMPLATE_DATA_PATH.name());
			if (dmRequest.getCmd().ordinal() == 1) {
				if ( dmReqTemplatePath == null || dmReqTemplatePath.isEmpty() || dmReqTemplatePath.startsWith("-1")) {
					String templatePath = UidCommonManager.getValue(JOB_TEMPLATES_PATH);
					File templateDir = new File(templatePath);
					String[] files = templateDir.list();
					byte[] data = FileUtil.getDataFromFile(templatePath + "/" + files[0]);
					templateInfo.setData(ByteString.copyFrom(data));
					logger.info("Get template data from default path:{}", templatePath);
				} else if (dmReqTemplatePath != null && !dmReqTemplatePath.isEmpty() && !dmReqTemplatePath.startsWith("-1")) {
					byte[] data = FileUtil.getDataFromFile(dmReqTemplatePath);
					templateInfo.setData(ByteString.copyFrom(data));
					logger.info("Get template data from  path:{}", dmReqTemplatePath);
				}
				dmRequest.setTemplateData(templateInfo.build());
			} 			

			PBTargetSegmentVersion.Builder segVerBuilder = PBTargetSegmentVersion.newBuilder();
			String dmReqSegVer = prop.getProperty(PropertyNames.DM_REQ_SEG_VER.name());
			if (dmReqSegVer != null && !dmReqSegVer.isEmpty()) {
				segVerBuilder.setVersion(Long.valueOf(dmReqSegVer));
			}
			String dmReqSegId = prop.getProperty(PropertyNames.DM_REQ_SEG_ID.name());
			if (dmReqSegId != null && !dmReqSegId.isEmpty() && !dmReqSegId.startsWith("-1")) {
				segVerBuilder.setId(Long.valueOf(dmReqSegId));
			}			
			dmRequest.setTargetSegment(segVerBuilder.build());
			logger.info("Send dm request to DM cluster...");
			System.out.print(dmRequest.toString());
			Boolean result = post(dmUrl, dmRequest.build());
			logger.info("Get response from dm,result ={}", result);

		} catch (Exception e) {
			throw new UidClientException(e.getMessage(), e);
		} finally {
			prop.clear();
			prop = null;
		}
	}

	public static Boolean post(String url, PBDmSyncRequest dmSegReq) {
		String cmmd = dmSegReq.getCmd().name().toLowerCase();
		OkHttpClient client = new OkHttpClient();
		client.setConnectTimeout(10, TimeUnit.SECONDS);
		client.setReadTimeout(10, TimeUnit.SECONDS);
		client.setWriteTimeout(10, TimeUnit.SECONDS);
		final StopWatch t = new StopWatch();
		t.start();
		Request request = new Request.Builder().url(url)
				.post(RequestBody.create(MEDIA_TYPE_PLAINTEXT, dmSegReq.toByteArray())).build();
		try {
			Response response = client.newCall(request).execute();
			t.stop();
			PBDmSyncResponce dmRes = PBDmSyncResponce.parseFrom(response.body().bytes());
			Boolean jobResult = Boolean.valueOf(dmRes.getSuccess());
			logger.info("Post PBDmSyncRequest(cmd= {} segmentId={}) to {} used time={}, and status={} job success is {}", 
					cmmd, dmSegReq.getTargetSegment().getId(), url, t.elapsedTime(), response.code(), jobResult);
			return jobResult;
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			return Boolean.valueOf(false);
		}
	}

	public static byte[] getSegment(String getUrl, Long segId) throws InterruptedException, ExecutionException {
		final StopWatch t = new StopWatch();
		t.start();
		OkHttpClient client = new OkHttpClient();
		client.setConnectTimeout(10, TimeUnit.SECONDS);
		client.setReadTimeout(10, TimeUnit.SECONDS);
		client.setWriteTimeout(10, TimeUnit.SECONDS);
		Request request = new Request.Builder().url(getUrl).build();
		try {
			Response response = client.newCall(request).execute();
			t.stop();
			if (response.code() == 200) {
				logger.info("Send getSegment request(segmentId={}) to {} used time={}, and status={}", segId, getUrl,
						t.elapsedTime(), response.code());
				return response.body().bytes();
			} else {
				logger.warn("Faild to get segment data from dm cluster, sendUrl={} segmentId={}, and status={}", getUrl,
						segId, response.code());
				return null;
			}

		} catch (IOException e) {
			logger.info(e.getMessage());
			return null;
		}
	}
}
