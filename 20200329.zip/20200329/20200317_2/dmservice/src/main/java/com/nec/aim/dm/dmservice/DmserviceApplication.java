package com.nec.aim.dm.dmservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import com.nec.aim.dm.dmservice.socket.HeatBeatSocketServer;

import lombok.extern.slf4j.Slf4j;

@SpringBootApplication
@Slf4j
public class DmserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DmserviceApplication.class, args);
		log.info("Dm service suceess started!");
		String socketPort = null;
		if (args.length == 3 && args[1] != null) {
			socketPort = args[1];
			HeatBeatSocketServer server = new HeatBeatSocketServer();
			server.start(Integer.valueOf(socketPort));
		} else if (args.length == 2 && args[0] != null) {
			socketPort = args[0];
			HeatBeatSocketServer server = new HeatBeatSocketServer();
			server.start(Integer.valueOf(socketPort));
		} else if (args.length == 1 && args[0] != null) {
			socketPort = args[0];
			try {
				int port = Integer.valueOf(socketPort);
				HeatBeatSocketServer server = new HeatBeatSocketServer();
				server.start(port);
			} catch (NumberFormatException e) {
			}
		}
	}
}
