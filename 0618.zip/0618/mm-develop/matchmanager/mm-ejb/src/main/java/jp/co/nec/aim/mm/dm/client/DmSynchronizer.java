/**this is file DmSynchronizer.java
 * @author xia
   @date 2020/06/15
 */
package jp.co.nec.aim.mm.dm.client;

/**
 * @author xia
 *
 */
public class DmSynchronizer {

}
