package jp.co.nec.aim.mm.exception;

/**
 * DataBaseException
 * 
 * @author liuyq
 * 
 */
public class DataBaseException extends AimErrorInfoException {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -932313536378093096L;

	/**
	 * DataBaseException
	 * 
	 * @param errorCode
	 *            error code
	 * @param description
	 *            error description
	 * @param epochTime
	 *            error epoch time
	 */
	public DataBaseException(String errorCode, String description, String time, String uidCode) {
		super(errorCode, description, time, uidCode);
	}
	//
	// public DataBaseException(Throwable ex) {
	// super(ex);
	// }
	//
	// public DataBaseException(String detail, Throwable ex) {
	// super(detail, ex);
	// }

}
