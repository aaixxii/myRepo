package jp.co.nec.aim.mm.procedure;

import java.sql.SQLException;
import java.sql.Types;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.jdbc.support.nativejdbc.CommonsDbcpNativeJdbcExtractor;

import jp.co.nec.aim.dm.message.proto.AimDmMessages.SegmentSyncCommandType;
import jp.co.nec.aim.mm.segment.sync.SegSyncInfos;

/**
 * DeleteBiometricsProcedure
 * 
 * @author liuyq
 * 
 */
public class DeleteBiometricsProcedure extends StoredProcedure {

	private static final String SQL = "delete_biometrics";	
	private String externalId;
	private Integer pNo;
	private Integer containerId;

	/**
	 * DeleteBiometricsProcedure
	 * 
	 * @param dataSource
	 *            DataSource instance
	 */
	public DeleteBiometricsProcedure(DataSource dataSource) {
		setDataSource(dataSource);
		setSql(SQL);
		// AbstractSqlTypeValue uses native Connection
//		getJdbcTemplate().setNativeJdbcExtractor(
//				new CommonsDbcpNativeJdbcExtractor());
				// We must set SqlOutParameter FIRST!
		declareParameter(new SqlParameter("p_external_id", Types.VARCHAR));		
		declareParameter(new SqlParameter("p_container_id", Types.INTEGER));
		declareParameter(new SqlParameter("p_no", Types.INTEGER));
		declareParameter(new SqlOutParameter("o_seg_ids", Types.VARCHAR));				
		declareParameter(new SqlOutParameter("o_seg_vers", Types.VARCHAR));				
		declareParameter(new SqlOutParameter("o_bio_ids", Types.VARCHAR));
		declareParameter(new SqlOutParameter("r_deleted_record_count",Types.INTEGER));				
		compile();
	}

	/**
	 * call MATCH_MANAGER_API.delete_biometrics and returns
	 * l_deleted_record_count.
	 * 
	 * @throws SQLException
	 */
	public Integer executeDeletion(List<SegSyncInfos> syncList)
			throws SQLException {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("p_external_id", getExternalId());
		map.put("p_container_id", getContainerId());
		map.put("p_no", getpNo());		
		Map<String, Object> resultMap = execute(map);
		int count = (Integer) resultMap.get("r_deleted_record_count");
		if (count < 1) {
			return Integer.valueOf(count);
		}

		String segIdarr = (String) resultMap.get("o_seg_ids");
		segIdarr = segIdarr.substring(0, segIdarr.length() -1);
		String[] strSegIds = segIdarr.split(",");
	//int[] array = Arrays.asList(strSegIds).stream().mapToInt(Integer::parseInt).toArray();
		long[] segIds = Arrays.asList(strSegIds).stream().mapToLong(Long::parseLong).toArray();
		String segVerarr = (String) resultMap.get("o_seg_vers");
		segVerarr = segVerarr.substring(0, segVerarr.length() -1);
		String[] strSegVers = segVerarr.split(",");
		long[] segVersions = Arrays.asList(strSegVers).stream().mapToLong(Long::parseLong).toArray();
		String bioIdarr = (String) resultMap.get("o_bio_ids");
		bioIdarr = bioIdarr.substring(0, bioIdarr.length() -1);
		String[] strBioIds = bioIdarr.split(",");
		long[] templateIds = Arrays.asList(strBioIds).stream().mapToLong(Long::parseLong).toArray();	

		for (int index = 0; index < segIds.length; index++) {
			long segId = segIds[index];
			long segVersion = segVersions[index];
			long templateId = templateIds[index];
			syncList.add(new SegSyncInfos(segId, segVersion, templateId,
					SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_DELETE));					
		}
		return Integer.valueOf(count);
	}

	public String getExternalId() {
		return externalId;
	}

	public void setExternalId(String externalId) {
		this.externalId = externalId;
	}

	

	public Integer getpNo() {
		return pNo;
	}

	public void setpNo(Integer pNo) {
		this.pNo = pNo;
	}

	public Integer getContainerId() {
		return containerId;
	}

	public void setContainerId(Integer containerId) {
		this.containerId = containerId;
	}	
}
