package jp.co.nec.aim.mm.result;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.protobuf.InvalidProtocolBufferException;

import jp.co.nec.aim.message.proto.BusinessMessage.PBBusinessMessage;
import jp.co.nec.aim.message.proto.InquiryService.IdentifyResponse;

public class HitMarking {
	private static Logger log = LoggerFactory.getLogger(HitMarking.class);

	public static void markHits(IdentifyResponse.Builder finalResults,
			DynamicThresholdParams params) {
		PBBusinessMessage pbMsg = null;
		try {
			pbMsg = PBBusinessMessage.parseFrom(finalResults.getBusinessMessageList().get(0));
		} catch (InvalidProtocolBufferException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int iCandidateCount = pbMsg.getDataBlock().getCandidateList().getCandidatesCount();
				
		if (0 < iCandidateCount) {
			DynamicThresholdNew dynth = new DynamicThresholdNew(
					iCandidateCount, params);
			for (int i = 0; i < iCandidateCount; ++i) {
				// set each score
				dynth.dynthScoreList.dynthRecords[i].fusionScore = pbMsg.getDataBlock().getCandidateList().getCandidates(i).getScaledScore();
						
			}

			// perform decision method
			dynth.perform();

			// mark the hits.
			for (int i = 0; i < iCandidateCount; ++i) {
				if (dynth.dynthScoreList.dynthRecords[i].hitFlag == 1) {
					pbMsg.getDataBlock().getCandidateListOrBuilder().getCandidatesOrBuilder(i); //can't set hitf
							
				}
			}
		} else {
			log.debug("No candidates found for request id " + pbMsg.getRequest().getRequestId()
					+ ", skipping dynamic thresholding logic.");
		}
	}
}
