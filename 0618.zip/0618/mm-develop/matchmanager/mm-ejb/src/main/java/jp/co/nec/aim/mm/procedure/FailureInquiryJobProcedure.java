package jp.co.nec.aim.mm.procedure;

import java.math.BigDecimal;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.SqlLobValue;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.util.StopWatch;

import jp.co.nec.aim.mm.sessionbeans.pojo.AimServiceState;

/**
 * Spring StoredProcedure class to call complete_mu_jobs()
 * 
 * @author jinxl
 * 
 */
public class FailureInquiryJobProcedure extends StoredProcedure {
	private static final String SQL = "MATCH_MANAGER_API.force_quit_job";

	public FailureInquiryJobProcedure(DataSource dataSource) {
		setDataSource(dataSource);
		setFunction(true);
		setSql(SQL);
		declareParameter(new SqlOutParameter("l_job_id", Types.NUMERIC));
		declareParameter(new SqlParameter("p_code", Types.VARCHAR));
		declareParameter(new SqlParameter("p_reason", Types.VARCHAR));
		declareParameter(new SqlParameter("p_failure_time", Types.VARCHAR));
		declareParameter(new SqlParameter("p_container_job_id", Types.NUMERIC));
		declareParameter(new SqlParameter("p_segment_id", Types.NUMERIC));
		declareParameter(new SqlParameter("p_result", Types.BLOB));
		compile();
	}

	/**
	 * Returns JOB_QUEUE.REMAIN_JOBS if succeeded update MU_JOBS to DONE
	 * 
	 * @param serviceState
	 * @param bJobResult
	 * @param containerJobId
	 * @param segmentId
	 * @return JOB_QUEUE.REMAIN_JOBS if succeeded. -1 If it failed
	 */
	public long action(AimServiceState serviceState, String bJobResult,
			long containerJobId, Long segmentId) {
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("p_code", serviceState.getErrorcode());
		String decription = serviceState.getErrMsg();
		map.put("p_reason", decription);
		map.put("p_failure_time", serviceState.getFailureTime());
		map.put("p_container_job_id", containerJobId);
		map.put("p_segment_id", segmentId);
		map.put("p_result", new SqlLobValue(bJobResult));
		Map<String, Object> resultMap = execute(map);
		long jobId = ((BigDecimal) resultMap.get("l_job_id")).longValue();

		stopWatch.stop();

		return jobId;
	}

}
