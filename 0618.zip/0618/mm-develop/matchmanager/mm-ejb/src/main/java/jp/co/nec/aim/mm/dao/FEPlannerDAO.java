package jp.co.nec.aim.mm.dao;

import java.sql.SQLException;

import jp.co.nec.aim.mm.extract.planner.FeProcedureResults;
import jp.co.nec.aim.mm.extract.planner.MuRemainLots;

import org.springframework.dao.DataAccessException;

public interface FEPlannerDAO {
	public Integer getMaxMuLots();

	public MuRemainLots getfirstMuRemainLots(int maxMuLot);

	public Long processOneMuLot(MuRemainLots muRemainLot);

	public void setPressureToMaxLot(Long muId, Long newPressure)
			throws DataAccessException, SQLException;

	//public FeProcedureResults processOneFeMatchUnit(int maxMuLot);

	public Long getCurretMuLots(Long muId);

	public void lockForFePlanner() throws DataAccessException;

	//public MuRemainLots lockAndGetfirstMuRemainLots(int maxMuLot);

	public Integer getFeLotJobCount(Long feLotJobId);

	public void rollbackFeLotJobRelated(Long feLotJobId, Long muId);

	public void rollbackFeJobQueue(Long feLotJobId);

	public void deleteFeLotJob(Long feLotJobId);

	public void rollbackMuExtractLoad(Long muId);

}
