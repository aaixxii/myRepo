package jp.co.nec.aim.mm.sessionbeans;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;
import javax.transaction.Transactional;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.google.common.collect.Lists;

import jp.co.nec.aim.message.proto.AIMMessages.PBInquiryJobInfoInternal;
import jp.co.nec.aim.message.proto.AIMMessages.PBMapInquiryJobResult;
import jp.co.nec.aim.message.proto.BusinessMessage.E_REQUESET_TYPE;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBusinessMessage;
import jp.co.nec.aim.message.proto.BusinessMessage.PBCandidate;
import jp.co.nec.aim.message.proto.BusinessMessage.PBDataBlock;
import jp.co.nec.aim.message.proto.BusinessMessage.PBDataElement;
import jp.co.nec.aim.message.proto.BusinessMessage.PBDataGroup;
import jp.co.nec.aim.message.proto.BusinessMessage.PBRequest;
import jp.co.nec.aim.message.proto.BusinessMessage.PBResponse;
import jp.co.nec.aim.message.proto.BusinessMessage.PBResponseAttribute;
import jp.co.nec.aim.mm.aggregator.Aggregator;
import jp.co.nec.aim.mm.dao.DateDao;
import jp.co.nec.aim.mm.dao.InquiryJobDao;
import jp.co.nec.aim.mm.dao.SystemConfigDao;
import jp.co.nec.aim.mm.entities.ContainerJobEntity;
import jp.co.nec.aim.mm.jms.JmsSender;
import mockit.Mock;
import mockit.MockUp;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class InquiryJobCompleteBeanTest {
	@Resource
	private DataSource ds;

	@PersistenceContext(unitName = "AIMDB")
	private EntityManager entityManager;

	@Resource
	private JdbcTemplate jdbcTemplate;
	@Resource
	private InquiryJobCompleteBean inquiryBean;
	

	private InquiryJobDao inquiryJobDao;
	private DateDao dateDao;

	private SystemConfigDao systemConfigDao;	

	@Before
	public void setUp() throws Exception {		
		inquiryJobDao = new InquiryJobDao(entityManager);		
		systemConfigDao = new SystemConfigDao(entityManager);		
		systemConfigDao.writeAllMissingProperties(ds);
		dateDao = new DateDao(ds);
		clearDB();
		setMockMethod();
	}
	
	public void clearDB() {		
		jdbcTemplate.execute("delete from JOB_QUEUE");
		jdbcTemplate.execute("delete from FUSION_JOBS");
		jdbcTemplate.execute("delete from CONTAINER_JOBS");		
		jdbcTemplate.execute("delete from MAP_REDUCERS");
		
		jdbcTemplate.execute("commit");
	}
	
	private void setMockMethod() {
		new MockUp<Aggregator>() {
			@Mock
			public void doAggregation(long jobId) {
				return;
			}
		};
		new MockUp<JmsSender>() {
			@Mock
			private void convertAndSend(String queueName, Object object) {
				return;
			}
		};		
	}

	@After
	public void tearDown() throws Exception {
		clearDB();
	}

	@Test
	public void testCompleteJob_remain_job_0() {
		long topJobId = 1000;
		long fusionJobId = 10001;
		long  containerJobId =10001; 
		long planId = 3000;
		long mrId = 5000;
		long[] muIds = {111,222,333};
		long curTime = dateDao.getCurrentTimeMS();
		PBMapInquiryJobResult mrResult = buildMrResult(mrId, muIds, topJobId, planId, false);		
		String jobQueueSql = "insert into job_queue(job_id,priority,job_state,submission_ts,callback_style,failure_count,remain_jobs,family_id)"
				+ " values(?,1,1,3000,0,0,1,1)";
		String fusionJobSql = "insert into fusion_jobs(fusion_job_id,function_id,job_id,search_request_index) values(?,1,?,0)";
		String contaiJobSql = "insert into container_jobs(container_job_id,container_id,plan_id,fusion_job_id,mr_id,RESULT_TS,job_state) "
				+ " values(?,1,?,?,?,?,1)";
		jdbcTemplate.update(jobQueueSql, new Object[] {topJobId});		
		jdbcTemplate.update(fusionJobSql, new Object[] {fusionJobId, topJobId});	
		
		jdbcTemplate.execute("insert into MAP_REDUCERS(MR_ID, UNIQUE_ID,"
				+ " RING_LOCATION, STATE) values(" + mrId + ", '" + mrId
				+ "', " + mrId + ", 'WORKING')");
		jdbcTemplate.execute("insert into MR_CONTACTS(MR_ID, CONTACT_TS)"
				+ " values(" + mrId+ ", " + curTime + ")");
	
	jdbcTemplate.execute("insert into LAST_ASSIGNED_MR(ASSIGNED_LOCATION,"
			+ " ASSIGNED_TS) values(1, " + (curTime - 100000) + ")");
		jdbcTemplate.update(contaiJobSql, new Object[] {containerJobId, planId, fusionJobId, mrId, dateDao.getCurrentTimeMS()});	
		jdbcTemplate.update(contaiJobSql, new Object[] {containerJobId+1, planId, fusionJobId, mrId,  dateDao.getCurrentTimeMS()});
		inquiryBean.completeJob(mrResult);
		ContainerJobEntity cj = inquiryJobDao.getContainerJob(containerJobId);
		assertNotNull(cj);		
		assertNotNull(cj.getContainerJobResult());
	}
	
	@Test
	public void testCompleteJob_remain_job_1() {
		long topJobId = 1000;
		long fusionJobId = 10001;
		long  containerJobId =10001; 
		long planId = 3000;
		long mrId = 5000;
		long[] muIds = {111,222,333};
		long curTime = dateDao.getCurrentTimeMS();
		PBMapInquiryJobResult mrResult = buildMrResult(mrId, muIds, topJobId, planId, false);		
		String jobQueueSql = "insert into job_queue(job_id,priority,job_state,submission_ts,callback_style,failure_count,remain_jobs,family_id)"
				+ " values(?,1,1,3000,0,0,2,1)";
		String fusionJobSql = "insert into fusion_jobs(fusion_job_id,function_id,job_id,search_request_index) values(?,1,?,0)";
		String contaiJobSql = "insert into container_jobs(container_job_id,container_id,plan_id,fusion_job_id,mr_id,RESULT_TS,job_state) "
				+ " values(?,1,?,?,?,?,1)";
		jdbcTemplate.update(jobQueueSql, new Object[] {topJobId});		
		jdbcTemplate.update(fusionJobSql, new Object[] {fusionJobId, topJobId});	
		
		jdbcTemplate.execute("insert into MAP_REDUCERS(MR_ID, UNIQUE_ID,"
				+ " RING_LOCATION, STATE) values(" + mrId + ", '" + mrId
				+ "', " + mrId + ", 'WORKING')");
		jdbcTemplate.execute("insert into MR_CONTACTS(MR_ID, CONTACT_TS)"
				+ " values(" + mrId+ ", " + curTime + ")");
	
	jdbcTemplate.execute("insert into LAST_ASSIGNED_MR(ASSIGNED_LOCATION,"
			+ " ASSIGNED_TS) values(1, " + (curTime - 100000) + ")");
		jdbcTemplate.update(contaiJobSql, new Object[] {containerJobId, planId, fusionJobId, mrId, dateDao.getCurrentTimeMS()});	
		jdbcTemplate.update(contaiJobSql, new Object[] {containerJobId+1, planId, fusionJobId, mrId,  dateDao.getCurrentTimeMS()});
		inquiryBean.completeJob(mrResult);
		ContainerJobEntity cj = inquiryJobDao.getContainerJob(containerJobId);
		assertNotNull(cj);		
		assertNotNull(cj.getContainerJobResult());
	}
	
	@Test
	public void testCompleteJob_result_faild_update() {
		long topJobId = 1000;
		long fusionJobId = 10001;
		long  containerJobId =10001; 
		long planId = 3000;
		long mrId = 5000;
		long[] muIds = {111,222,333};
		long curTime = dateDao.getCurrentTimeMS();
		PBMapInquiryJobResult mrResult = buildMrResult(mrId, muIds, topJobId, planId, true);		
		String jobQueueSql = "insert into job_queue(job_id,priority,job_state,submission_ts,callback_style,failure_count,remain_jobs,family_id)"
				+ " values(?,1,1,3000,0,0,1,1)";
		String fusionJobSql = "insert into fusion_jobs(fusion_job_id,function_id,job_id,search_request_index) values(?,1,?,0)";
		String contaiJobSql = "insert into container_jobs(container_job_id,container_id,plan_id,fusion_job_id,mr_id,RESULT_TS,job_state) "
				+ " values(?,1,?,?,?,?,1)";
		jdbcTemplate.update(jobQueueSql, new Object[] {topJobId});		
		jdbcTemplate.update(fusionJobSql, new Object[] {fusionJobId, topJobId});	
		
		jdbcTemplate.execute("insert into MAP_REDUCERS(MR_ID, UNIQUE_ID,"
				+ " RING_LOCATION, STATE) values(" + mrId + ", '" + mrId
				+ "', " + mrId + ", 'WORKING')");
		jdbcTemplate.execute("insert into MR_CONTACTS(MR_ID, CONTACT_TS)"
				+ " values(" + mrId+ ", " + curTime + ")");
	
	jdbcTemplate.execute("insert into LAST_ASSIGNED_MR(ASSIGNED_LOCATION,"
			+ " ASSIGNED_TS) values(1, " + (curTime - 100000) + ")");
		jdbcTemplate.update(contaiJobSql, new Object[] {containerJobId, planId, fusionJobId, mrId, dateDao.getCurrentTimeMS()});	
		jdbcTemplate.update(contaiJobSql, new Object[] {containerJobId+1, planId, fusionJobId, mrId,  dateDao.getCurrentTimeMS()});
		inquiryBean.completeJob(mrResult);
		ContainerJobEntity cj = inquiryJobDao.getContainerJob(containerJobId);
		assertNotNull(cj);		
		assertNull(cj.getContainerJobResult());
		List<Map<String, Object>> mapValue = jdbcTemplate.queryForList("select * from container_job_failure_reasons where container_job_id=10001");
		assertNotNull(mapValue);	
		assertEquals(1, mapValue.size());
	}
	
	private  PBMapInquiryJobResult buildMrResult(long mrId, long[] muIds, long topLevelJobId,long planId, boolean setingFailed) {	
		PBMapInquiryJobResult.Builder builder = PBMapInquiryJobResult.newBuilder();				
		builder.setMrId(mrId);
		builder.setPlanId(planId);	
		for (int i = 0; i < muIds.length; i++) {
			PBInquiryJobInfoInternal.Builder jobInfo = builder.getJobInfoBuilder();
			jobInfo.setTopLevelJobId(topLevelJobId);
			jobInfo.setRequestIndex(1);
			jobInfo.setContainerId(1);
			jobInfo.setMessageSequence(0);
			jobInfo.setJobTimeout(5000);
			jobInfo.setInternalMaxCandidates(10);
			jobInfo.setMuJobPopTime(7);		
			PBBusinessMessage result =  createPBBusinessMessage(setingFailed);
			builder.setResult(result);	
		}			
		return builder.build();
	}	
	
	private PBBusinessMessage createPBBusinessMessage(boolean setingFailed) {
		PBBusinessMessage.Builder pbMsg = PBBusinessMessage.newBuilder();		
		PBRequest.Builder pq = PBRequest.newBuilder();
		pq.setRequestId("12");
		pq.setRequestType(E_REQUESET_TYPE.IDENTIFY_DEFAULT);
		pbMsg.setRequest(pq);
		PBResponse.Builder ps = PBResponse.newBuilder();		
		if (!setingFailed) {			
			ps.setStatus("0");			
		} else {
			ps.setStatus("109faild");
			ps.setErrorMessage("testFaild");
			PBResponseAttribute.Builder attr = PBResponseAttribute.newBuilder();
			attr.setAttributeName("createdTimestamp");
			attr.setAttributeValue(String.valueOf(dateDao.getCurrentTimeMS()));
			ps.addResponseAttributes(attr.build());			
		}
		pbMsg.setResponse(ps);		
	
		PBDataBlock.Builder pd = PBDataBlock.newBuilder();
		List<PBCandidate> pbList = Lists.newArrayList();
		for (int i = 0 ; i < 5; i++) {
			PBCandidate.Builder pb = PBCandidate.newBuilder();
			pb.setEnrollmentId("enroll");
			pb.setScaledScore(100 + i);			
			pbList.add(pb.build());
		}
		for (int i = 0 ; i < 4; i++) {
			PBCandidate.Builder pb = PBCandidate.newBuilder();
			pb.setEnrollmentId("external");
			pb.setScaledScore(10 + i);			
			pbList.add(pb.build());
		}
		
		Collections.shuffle(pbList); 		
		
		pd.getCandidateListBuilder().addAllCandidates(pbList);
		pd.getCandidateListBuilder().setMore(false);
		
		List<PBDataElement> pbDeList= new ArrayList<>();
		for (int i = 0 ; i < 5; i++) {
			PBDataElement.Builder pb = PBDataElement.newBuilder();
			pb.setElementName("read");
			pb.setElementValue(String.valueOf(i));
			pbDeList.add(pb.build());
		}
		for (int i = 3 ; i < 6; i++) {
			PBDataElement.Builder pb = PBDataElement.newBuilder();
			pb.setElementName("rmf");
			pb.setElementValue(String.valueOf(i));
			pbDeList.add(pb.build());
		}
		for (int i = 1 ; i < 5; i++) {
			PBDataElement.Builder pb = PBDataElement.newBuilder();
			pb.setElementName("iris");
			pb.setElementValue(String.valueOf(i));
			pbDeList.add(pb.build());
		}
		
		for (int i = 5; i < 10; i++) {
			PBDataElement.Builder pb = PBDataElement.newBuilder();
			pb.setElementName("face");
			pb.setElementValue(String.valueOf(i));
			pbDeList.add(pb.build());
		}		
		Collections.shuffle(pbDeList); 		
		PBDataGroup.Builder pg = PBDataGroup.newBuilder();
		pg.setGroupName("amr");
		for (int i = 0; i < pbDeList.size(); i++) {
			pg.addDataElement(i, pbDeList.get(i));
		}
		
		pd.addDataGroup(pg.build());		
		pbMsg.setDataBlock(pd.build());
		return pbMsg.build();
	}

	
	

}
