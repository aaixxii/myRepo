//package jp.co.nec.aim.mm.dao;
//
//import static org.junit.Assert.assertEquals;
//import static org.junit.Assert.assertNotNull;
//import static org.junit.Assert.assertNull;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import javax.annotation.Resource;
//import javax.persistence.EntityManager;
//import javax.persistence.PersistenceContext;
//import javax.sql.DataSource;
//import javax.transaction.Transactional;
//
//import jp.co.nec.aim.mm.common.JdbcTemplateHelper;
//import jp.co.nec.aim.mm.constants.CallbackStyle;
//import jp.co.nec.aim.mm.constants.FunctionFamily;
//import jp.co.nec.aim.mm.constants.JobState;
//import jp.co.nec.aim.mm.entities.ContainerJobEntity;
//import jp.co.nec.aim.mm.entities.ContainerJobFailureReasonEntity;
//import jp.co.nec.aim.mm.entities.InquiryTrafficEntity;
//import jp.co.nec.aim.mm.entities.JobQueueEntity;
//import jp.co.nec.aim.mm.entities.MapReducerEntity;
//
//import org.junit.After;
//import org.junit.Assert;
//import org.junit.Before;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.springframework.jdbc.core.JdbcTemplate;
//import org.springframework.test.context.ContextConfiguration;
//import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
//
//@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration(locations = { "/applicationContext.xml" })
//@Transactional
//public class InquiryJobDaoTest {
//	@PersistenceContext(unitName = "AIMDB")
//	private EntityManager entityManager;
//
//	@Resource
//	private JdbcTemplate jdbcTemplate;
//	@Resource
//	private DataSource dataSource;
//
//	private InquiryJobDao inquiryjobdao;
//
//	@Before
//	public void setUp() throws Exception {
//		inquiryjobdao = new InquiryJobDao(entityManager, dataSource);
//		JdbcTemplateHelper helper = new JdbcTemplateHelper();
//		helper.deleteInquiryJob(jdbcTemplate);
//		helper.scene01(jdbcTemplate);
//	}
//
//	@After
//	public void tearDown() throws Exception {
//	}
//
//	@Test
//	public void test_getJobQueueByJobId() {
//		JobQueueEntity jobqueueentity = inquiryjobdao.getTopLevelJob(1);
//		assertNull(jobqueueentity);
//		jobqueueentity = inquiryjobdao.getTopLevelJob(1000);
//		assertNotNull(jobqueueentity);
//		assertEquals(JobState.QUEUED, jobqueueentity.getJobState());
//		assertEquals(1, jobqueueentity.getPriority());
//		assertEquals(CallbackStyle.XML, jobqueueentity.getCallbackStyle());
//		assertEquals(0, jobqueueentity.getFailureCount());
//		assertEquals(20, jobqueueentity.getRemainJobs());
//		assertEquals(FunctionFamily.TI,
//				FunctionFamily.fromVal(jobqueueentity.getFamilyId()));
//	}
//
//	@Test
//	public void test_getAllContainerJob() {
//		List<ContainerJobEntity> list = inquiryjobdao.getAllContainerJob(1);
//		assertEquals(0, list.size());
//		list = inquiryjobdao.getAllContainerJob(1000);
//		assertEquals(80, list.size());
//		for (ContainerJobEntity containerJob : list) {
//			assertEquals(JobState.WORKING, containerJob.getJobState());
//		}
//	}
//
//	@Test
//	public void test_clearAllContainerJob() {
//		List<ContainerJobEntity> list = inquiryjobdao.getAllContainerJob(1000);
//		assertEquals(80, list.size());
//
//		inquiryjobdao.clearAllContainerJob(1000);
//
//		list = inquiryjobdao.getAllContainerJob(1000);
//		assertEquals(0, list.size());
//	}
//
//	@Test
//	public void test_getContainerJob() {
//		ContainerJobEntity containerJob = inquiryjobdao.getContainerJob(1);
//		assertNull(containerJob);
//		containerJob = inquiryjobdao.getContainerJob(10423);
//		assertEquals(4, containerJob.getContainerId());
//		assertEquals(JobState.WORKING, containerJob.getJobState());
//	}
//
//	// @Test
//	// public void test_getContainerJob_2() {
//	// ContainerJobEntity containerJob = inquiryjobdao.getContainerJob(1042l,
//	// 4);
//	// assertEquals(4, containerJob.getContainerId());
//	// assertEquals(10423, containerJob.getContainerJobId());
//	// assertEquals(JobState.WORKING, containerJob.getJobState());
//	// }
//
//	@Test
//	public void test_GetWorkingContainerJobs() {
//		jdbcTemplate.execute("update container_jobs set MR_ID = 1"
//				+ " where JOB_STATE != 0");
//		jdbcTemplate.execute("commit");
//		List<ContainerJobEntity> containerJobList = inquiryjobdao
//				.getWorkingContainerJobs();
//		assertEquals(481, containerJobList.size());
//	}
//
//	@Test
//	public void test_getContainerJobFailureReason() {
//		ContainerJobFailureReasonEntity reason = inquiryjobdao
//				.getContainerJobFailureReason(1);
//		assertEquals("1001", reason.getCode());
//		assertEquals("error Msg", reason.getReason());
//		assertEquals("1421206612748", reason.getFailureTime());
//		assertEquals(null, reason.getSegmentId());
//		assertEquals(new Long(1), reason.getMrId());
//		assertEquals(10063, reason.getContainerJobId());
//	}
//
//	// @Test
//	// public void test_getFusionJob() {
//	// FusionJobEntity fusionJob = inquiryjobdao.getFusionJob(new Long(1001),
//	// 3);
//	// assertEquals(1021, fusionJob.getFusionJobId());
//	// assertEquals(1001, fusionJob.getJobId());
//	// assertEquals(3, fusionJob.getFunctionId());
//	// assertEquals(2, fusionJob.getSearchRequestIndex());
//	// }
//
//	@Test
//	public void test_getInquiryTraffic() {
//		InquiryTrafficEntity inquiryTraffic = inquiryjobdao
//				.getInquiryTraffic(1001);
//		assertEquals(new Long(2), inquiryTraffic.getJobExecCount());
//	}
//
//	@Test
//	public void test_getJobQueuebyContainerJobId() {
//		JobQueueEntity jobQueue = inquiryjobdao.getJobQueue(10023);
//		assertEquals(1002, jobQueue.getJobId());
//	}
//
//	@Test
//	public void testGetTopLevelJob() {
//		jdbcTemplate.update("insert into job_queue (JOB_ID,PRIORITY,JOB_STATE,"
//				+ "SUBMISSION_TS,CALLBACK_STYLE,TIMEOUTS,FAILURE_COUNT,"
//				+ "REMAIN_JOBS,FAMILY_ID)values(20,4,0,123,0,123,0,0,1)");
//		JobQueueEntity jobQueueEntity = inquiryjobdao.getTopLevelJob(20);
//		assertEquals(1, jobQueueEntity.getFamilyId());
//	}
//
//	@Test
//	public void testGetTopLevelJobJobIdNotExist() {
//		JobQueueEntity jobQueueEntity = inquiryjobdao.getTopLevelJob(20);
//		assertEquals(null, jobQueueEntity);
//	}
//
//	@Test
//	public void testListAllJobIds() {
//		List<Long> jobIds = inquiryjobdao.listAllJobIds();
//		Assert.assertEquals(8, jobIds.size());
//	}
//
//	@Test
//	public void testClearJobs() {
//		inquiryjobdao.clearJobs();
//		int count = jdbcTemplate.queryForObject(
//				"select count(*) from JOB_QUEUE", Integer.class);
//		Assert.assertEquals(0, count);
//	}
//
//	@Test
//	public void testDeleteJob() {
//		int count = jdbcTemplate.queryForObject(
//				"select count(*) from JOB_QUEUE where JOB_ID = " + 1000,
//				Integer.class);
//		Assert.assertEquals(1, count);
//
//		inquiryjobdao.deleteJob(1000);
//		jdbcTemplate.update("commit");
//
//		count = jdbcTemplate.queryForObject(
//				"select count(*) from JOB_QUEUE where JOB_ID = " + 1000,
//				Integer.class);
//		Assert.assertEquals(0, count);
//	}
//
//	@Test
//	public void testUpdateContainerJob() {
//		jdbcTemplate.update("insert into JOB_QUEUE (JOB_ID,PRIORITY,JOB_STATE,"
//				+ "SUBMISSION_TS,CALLBACK_STYLE,TIMEOUTS,FAILURE_COUNT,"
//				+ "REMAIN_JOBS,FAMILY_ID)values(1,1,1,123,1,123,1,0,1)");
//		jdbcTemplate.update("insert into fusion_jobs values(1,1,1,null,1)");
//		jdbcTemplate.update("insert into container_jobs(CONTAINER_JOB_ID,"
//				+ "CONTAINER_ID,FUSION_JOB_ID)values(1,1,1)");
//		jdbcTemplate.update("commit");
//		inquiryjobdao.updateContainerJob(1, 1);
//		jdbcTemplate.update("commit");
//		int mrId = jdbcTemplate.queryForObject(
//				"select MR_ID from container_jobs where CONTAINER_JOB_ID = 1",
//				Integer.class);
//		Assert.assertEquals(1, mrId);
//	}
//
//	@Test
//	public void test_listTimedOutJobs() {
//		jdbcTemplate.execute("update container_jobs set ASSIGNED_TS = 110000"
//				+ " where JOB_STATE != 0");
//		jdbcTemplate.execute("commit");
//		List<ContainerJobEntity> list = inquiryjobdao.listTimedOutJobs("LIX");
//		assertEquals(0, list.size());
//		list = inquiryjobdao.listTimedOutJobs("TI");
//		assertEquals(60, list.size());
//	}
//
//	@Test
//	public void test_listDeadContainerJobs() {
//		jdbcTemplate.execute("update container_jobs set MR_ID = 1"
//				+ " where JOB_STATE != 0");
//		jdbcTemplate.execute("update MR_CONTACTS set CONTACT_TS = 110000");
//		jdbcTemplate.execute("commit");
//		List<MapReducerEntity> mrList = new ArrayList<MapReducerEntity>();
//		List<ContainerJobEntity> list = inquiryjobdao
//				.listDeadContainerJobs(mrList);
//		assertEquals(0, list.size());
//
//		MapReducerEntity mr = new MapReducerEntity();
//		mr.setMrId(new Long(1));
//		mrList.add(mr);
//
//		list = inquiryjobdao.listDeadContainerJobs(mrList);
//		assertEquals(481, list.size());
//	}
//
//	@Test
//	public void test_listDeadJobs() {
//		jdbcTemplate.execute("update container_jobs set MR_ID = 1"
//				+ " where JOB_STATE != 0");
//		jdbcTemplate.execute("update MR_CONTACTS set CONTACT_TS = 110000");
//		jdbcTemplate.execute("commit");
//
//		List<ContainerJobEntity> list = inquiryjobdao.listDeadJobs(2l);
//		assertEquals(0, list.size());
//
//		list = inquiryjobdao.listDeadJobs(1l);
//		assertEquals(481, list.size());
//	}
//}
