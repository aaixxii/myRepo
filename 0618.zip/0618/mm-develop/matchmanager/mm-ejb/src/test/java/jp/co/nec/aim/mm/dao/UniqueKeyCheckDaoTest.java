package jp.co.nec.aim.mm.dao;

import java.util.List;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.aim.message.proto.BatchTypeProto.BatchType;
import jp.co.nec.aim.mm.entities.BatchJobInfoEntity;
import jp.co.nec.aim.mm.entities.PersonBiometricEntity;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
    "/applicationContext.xml"
})
@Transactional
public class UniqueKeyCheckDaoTest {
    @PersistenceContext(unitName = "AIMDB")
    private EntityManager entityManager;
    
    @Resource
    private DataSource dataSource;
    
    @Resource
    private JdbcTemplate jdbcTemplate;
    
    private UniqueKeyCheckDao checkDao;
    
    private DateDao dateDao;
    
    @Before
    public void setUp() throws Exception {
        checkDao = new UniqueKeyCheckDao(entityManager);
        dateDao = new DateDao(dataSource);
        jdbcTemplate.update("delete from PERSON_BIOMETRICS");
    }
    
    @After
    public void tearDown() throws Exception {
    } 
    
    @Test
    public void testCheckBatchJobId_have_one() {
        BatchJobInfoEntity entity = new BatchJobInfoEntity();
        entity.setBatchJobId(1000);
        entity.setBatchType(BatchType.ENROLL.name());
        entity.setReqeustId("1000");
        entityManager.persist(entity);
        List<BatchJobInfoEntity> result = checkDao.checkBatchJobId(1000, BatchType.ENROLL.name());
        Assert.assertEquals(1, result.size());
    }
    
    @Test
    public void testCheckBatchJobId_have_no_data() {
        BatchJobInfoEntity entity = new BatchJobInfoEntity();
        entity.setBatchJobId(1000);
        entity.setBatchType(BatchType.ENROLL.name());
        entity.setReqeustId("1000");
        entityManager.persist(entity);
        List<BatchJobInfoEntity> result = checkDao.checkBatchJobId(1001, BatchType.ENROLL.name());
        Assert.assertEquals(0, result.size());
    }
    
    @Test
    public void testCheckBatchJobId_exception_result_null() {
        BatchJobInfoEntity entity = new BatchJobInfoEntity();
        entity.setBatchJobId(1000);
        entity.setBatchType(BatchType.ENROLL.name());
        entity.setReqeustId("1000");
        entityManager.persist(entity);
        BatchJobInfoEntity entity2 = new BatchJobInfoEntity();
        entity.setBatchJobId(1000);
        entity.setBatchType(BatchType.ENROLL.name());
        entity.setReqeustId("1001");
        entityManager.persist(entity2);
        List<BatchJobInfoEntity> result = checkDao.checkBatchJobId(1000, BatchType.ENROLL.name());
        Assert.assertNull(result);
    }
    
    @Test
    public void testCheckRequestId_have_one() {
        BatchJobInfoEntity entity = new BatchJobInfoEntity();
        entity.setBatchJobId(1000);
        entity.setBatchType(BatchType.ENROLL.name());
        entity.setReqeustId("1000");
        entityManager.persist(entity);
        List<BatchJobInfoEntity> result = checkDao.checkRequestId(String.valueOf(1000), BatchType.ENROLL.name());
        Assert.assertEquals(1, result.size());
    }
    
    @Test
    public void testCheckRequestId__exception_result_null() {
        BatchJobInfoEntity entity = new BatchJobInfoEntity();
        entity.setBatchJobId(1000);
        entity.setBatchType(BatchType.ENROLL.name());
        entity.setReqeustId("1000");
        entityManager.persist(entity);
        BatchJobInfoEntity entity1 = new BatchJobInfoEntity();
        entityManager.persist(entity1);
        List<BatchJobInfoEntity> result = checkDao.checkRequestId(String.valueOf(1000), BatchType.ENROLL.name());
        Assert.assertNull(result);
    }
    
    @Test
    public void testCheckRequestId_have_no_data() {
        BatchJobInfoEntity entity = new BatchJobInfoEntity();
        entity.setBatchJobId(1000);
        entity.setBatchType(BatchType.ENROLL.name());
        entity.setReqeustId("1000");
        entityManager.persist(entity);
        List<BatchJobInfoEntity> result = checkDao.checkRequestId(String.valueOf(1001), BatchType.ENROLL.name());
        Assert.assertEquals(0, result.size());
    }
    
    @Test
    public void testCheckEnrollmentID1() {
        PersonBiometricEntity pb = new PersonBiometricEntity();
        pb.setBiometricsId(1);
        pb.setBiometricData("test".getBytes());
        pb.setBiometricDataLen("test".getBytes().length);
        pb.setContainerId(1);
        pb.setExternalId("ext1");
        pb.setRegistedTs(System.currentTimeMillis());
        pb.setCorruptedFlag(3);
        entityManager.persist(pb);
        entityManager.flush();
        List<PersonBiometricEntity> pbList = checkDao.checkEnrollmentID("ext1");
        Assert.assertEquals(1, pbList.size());
    }
    
    @Test
    public void testCheckEnrollmentID_ok() {
        jdbcTemplate
            .update(
                "insert into PERSON_BIOMETRICS (BIOMETRICS_ID,EXTERNAL_ID,BIOMETRIC_DATA,BIOMETRIC_DATA_LEN,REGISTED_TS,CORRUPTED_FLAG,EVENT_ID,CONTAINER_ID)values(1,'1',TO_BLOB('111'),3,111,0,1,1)");
        int count = jdbcTemplate.update("select count(*) from PERSON_BIOMETRICS");
        Assert.assertEquals(1, count);
    }
    
    @Test(expected = DuplicateKeyException.class)
    public void testCheckEnrollmentID_duplicate() {
        jdbcTemplate
            .update(
                "insert into PERSON_BIOMETRICS (BIOMETRICS_ID,EXTERNAL_ID,BIOMETRIC_DATA,BIOMETRIC_DATA_LEN,REGISTED_TS,CORRUPTED_FLAG,EVENT_ID,CONTAINER_ID)values(1,'1',TO_BLOB('111'),3,111,0,1,1)");
        jdbcTemplate.execute("commit");
        jdbcTemplate
            .update(
                "insert into PERSON_BIOMETRICS (BIOMETRICS_ID,EXTERNAL_ID,BIOMETRIC_DATA,BIOMETRIC_DATA_LEN,REGISTED_TS,CORRUPTED_FLAG,EVENT_ID,CONTAINER_ID)values(2,'1',TO_BLOB('111'),4,444,0,2,1)");
        jdbcTemplate.execute("commit");
    }     
    
    @Test
    public void testCheckEnrollmentID_no_data() {
        PersonBiometricEntity pb = new PersonBiometricEntity();
        pb.setBiometricsId(1);
        pb.setBiometricData("test".getBytes());
        pb.setBiometricDataLen("test".getBytes().length);
        pb.setContainerId(1);
        pb.setExternalId("ext1");
        pb.setRegistedTs(System.currentTimeMillis());
        pb.setCorruptedFlag(3);
        entityManager.persist(pb);
        List<PersonBiometricEntity> pbList = checkDao.checkEnrollmentID("ext2");
        Assert.assertEquals(0, pbList.size());
    }
    
    @Test
    public void testCheckEnrollmentID_exception_result_null() {
        PersonBiometricEntity pb = new PersonBiometricEntity();
        pb.setBiometricsId(1);
        pb.setBiometricData("test".getBytes());
        pb.setBiometricDataLen("test".getBytes().length);
        pb.setContainerId(1);
        pb.setExternalId("ext1");
        pb.setRegistedTs(System.currentTimeMillis());
        pb.setCorruptedFlag(3);
        entityManager.persist(pb);
        PersonBiometricEntity pb2 = new PersonBiometricEntity();
        entityManager.persist(pb2);
        List<PersonBiometricEntity> pbList = checkDao.checkEnrollmentID("ext2");
        Assert.assertNull(pbList);
    }
    
    @Test
    public void testDateDao() {
        Long testDate = dateDao.getCurrentTimeMS();
        System.out.print(testDate);
    }
    
}
