package jp.co.nec.aim.mm.procedure;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.sql.DataSource;
import javax.transaction.Transactional;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import jp.co.nec.aim.mm.segment.sync.SegSyncInfos;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class AddBiometricsProcedureTest {
	@Resource
	private DataSource dataSource;

	@Resource
	private JdbcTemplate jdbcTemplate;

	private AddBiometricsProcedure addBiometricsProcedure;

	@Before
	public void setUp() throws Exception {
		addBiometricsProcedure = new AddBiometricsProcedure(dataSource);
		jdbcTemplate.update("delete from PERSON_BIOMETRICS");
		jdbcTemplate.update("delete from SEGMENTS");
		jdbcTemplate.update("delete from SEGMENT_CHANGE_LOG");
		jdbcTemplate.update("delete from FE_JOB_QUEUE");		
		jdbcTemplate.update("commit");
	}

	@After
	public void tearDown() throws Exception {
		jdbcTemplate.update("delete from PERSON_BIOMETRICS");
		jdbcTemplate.update("delete from SEGMENTS");
		jdbcTemplate.update("delete from SEGMENT_CHANGE_LOG ");
		jdbcTemplate.update("delete from FE_JOB_QUEUE");		
		jdbcTemplate.update("commit");
	}

	@Test
	public void testExecuteBiometricsData() {
		byte[] bytes = { 1, 2, 3 };
		addBiometricsProcedure.setExternalId("1");
		addBiometricsProcedure.setpNo(1);
		addBiometricsProcedure.setContainerId(1);
		addBiometricsProcedure.setBiometricsData(bytes);
		SegSyncInfos result = addBiometricsProcedure.execute();
		jdbcTemplate.update("commit");
		List<Map<String, Object>> listSeg = jdbcTemplate
				.queryForList("select * from SEGMENTS");
		Assert.assertEquals(1, listSeg.size());
		Map<String, Object> mapSeg = listSeg.get(0);
		Assert.assertEquals(1,
				Integer.parseInt(mapSeg.get("CONTAINER_ID").toString()));
		Assert.assertEquals(1,
				Integer.parseInt(mapSeg.get("RECORD_COUNT").toString()));
		Assert.assertEquals(-1,
				Integer.parseInt(mapSeg.get("VERSION").toString()));
		List<Map<String, Object>> listPer = jdbcTemplate
				.queryForList("select * from PERSON_BIOMETRICS");
		Assert.assertEquals(1, listPer.size());
		Map<String, Object> mapPer = listPer.get(0);
		Assert.assertEquals("1", mapPer.get("EXTERNAL_ID"));		
		Assert.assertEquals(1,
				Integer.parseInt(mapPer.get("CONTAINER_ID").toString()));
	}

	@Test
	public void testExecuteBiometricsDataUpdateSegments() {
		byte[] bytes = { 1, 2, 3 };
		jdbcTemplate
				.update("insert into SEGMENTS(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH,RECORD_COUNT,VERSION,REVISION)values(1,1,1,1,26,1,1,1)");
		//jdbcTemplate.update("commit");
		addBiometricsProcedure.setExternalId("1");
		addBiometricsProcedure.setpNo(1);
		addBiometricsProcedure.setContainerId(1);
		addBiometricsProcedure.setBiometricsData(bytes);
		SegSyncInfos result = addBiometricsProcedure.execute();

		List<Map<String, Object>> listSeg = jdbcTemplate
				.queryForList("select * from SEGMENTS");
		Assert.assertEquals(1, listSeg.size());
		Map<String, Object> mapSeg = listSeg.get(0);
		Assert.assertEquals(1,
				Integer.parseInt(mapSeg.get("CONTAINER_ID").toString()));
		Assert.assertEquals(2,
				Integer.parseInt(mapSeg.get("RECORD_COUNT").toString()));
		Assert.assertEquals(2,
				Integer.parseInt(mapSeg.get("VERSION").toString()));
		List<Map<String, Object>> listPer = jdbcTemplate
				.queryForList("select * from PERSON_BIOMETRICS");
		Assert.assertEquals(1, listPer.size());
		Map<String, Object> mapPer = listPer.get(0);
		Assert.assertEquals("1", mapPer.get("EXTERNAL_ID"));		
		Assert.assertEquals(1,
				Integer.parseInt(mapPer.get("CONTAINER_ID").toString()));
		List<Map<String, Object>> listSegChangeLog = jdbcTemplate
				.queryForList("select * from SEGMENT_CHANGE_LOG");
		Assert.assertEquals(1, listSegChangeLog.size());
		Map<String, Object> mapSegChangeLog = listSegChangeLog.get(0);
		Assert.assertEquals(1,
				Integer.parseInt(mapSegChangeLog.get("CHANGE_TYPE").toString()));
		Assert.assertEquals(2, Integer.parseInt(mapSegChangeLog.get(
				"SEGMENT_VERSION").toString()));
		Assert.assertEquals(1,
				Integer.parseInt(mapSegChangeLog.get("SEGMENT_ID").toString()));
	}

	@Test
	public void testExecuteBiometricsDataNewSegments() {
		byte[] bytes = { 1, 2, 3 };
		jdbcTemplate
				.update("insert into SEGMENTS(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH,RECORD_COUNT,VERSION,REVISION)values(1,1,1,1,19999999,1,1,1)");
		// jdbcTemplate.update("commit");
		addBiometricsProcedure.setExternalId("1");
		addBiometricsProcedure.setpNo(1);
		addBiometricsProcedure.setContainerId(1);
		addBiometricsProcedure.setBiometricsData(bytes);
		SegSyncInfos result = addBiometricsProcedure.execute();
		// jdbcTemplate.update("commit");
		List<Map<String, Object>> listSeg = jdbcTemplate
				.queryForList("select * from SEGMENTS order by SEGMENT_ID");
		Assert.assertEquals(2, listSeg.size());
		Map<String, Object> mapSeg = listSeg.get(1);
		Assert.assertEquals(1,
				Integer.parseInt(mapSeg.get("CONTAINER_ID").toString()));
		Assert.assertEquals(1,
				Integer.parseInt(mapSeg.get("RECORD_COUNT").toString()));
		Assert.assertEquals(-1,
				Integer.parseInt(mapSeg.get("VERSION").toString()));
		List<Map<String, Object>> listPer = jdbcTemplate
				.queryForList("select * from PERSON_BIOMETRICS");
		Assert.assertEquals(1, listPer.size());
		Map<String, Object> mapPer = listPer.get(0);
		Assert.assertEquals("1", mapPer.get("EXTERNAL_ID"));		
		Assert.assertEquals(1,
				Integer.parseInt(mapPer.get("CONTAINER_ID").toString()));
		List<Map<String, Object>> listSegChangeLog = jdbcTemplate
				.queryForList("select * from SEGMENT_CHANGE_LOG");
		Assert.assertEquals(0, listSegChangeLog.size());
	}

}
