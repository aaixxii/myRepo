//package jp.co.nec.aim.mm.common;
//
//import java.util.List;
//import java.util.Map;
//
//import javax.persistence.EntityManager;
//import javax.persistence.Query;
//
//import jp.co.nec.aim.message.proto.AIMMessages.PBInquiryJobResultInternal;
//import jp.co.nec.aim.mm.constants.SchedulerEnum;
//import jp.co.nec.aim.mm.entities.ContainerEntity;
//import jp.co.nec.aim.mm.entities.SegmentEntity;
//import jp.co.nec.aim.mm.entities.SystemConfigEntity;
//import jp.co.nec.aim.mm.entities.UnitState;
//import jp.co.nec.aim.mm.util.CollectionsUtil;
//
//import org.springframework.jdbc.core.JdbcTemplate;
//
//import com.google.common.collect.Lists;
//
//public class JdbcTemplateHelper {
//
//	private final static String dateSql = "SELECT match_manager_api.get_epoch_time_num() AS MILLIONS FROM DUAL";;
//
//	/* */
//	public void scene01(JdbcTemplate jdbcTemplate) {
//		insertMapReducer(jdbcTemplate);
//		insertJobQueue(jdbcTemplate);
//	}
//
//	// Job Queue Id=1000~1004
//	// 1000 0
//	// 1001 1
//	// 1002 1
//	// 1003 1
//	// 1004 1
//	public void insertJobQueue(JdbcTemplate jdbcTemplate) {
//		long lastTs = jdbcTemplate.queryForObject(dateSql, Long.class);
//		String sql = "insert into job_queue(job_id,priority,"
//				+ "job_state,submission_ts,callback_style,max_candidates,failure_count,remain_jobs,family_id)"
//				+ "values(?,?,?,?,?,?,?,?,?)";
//		for (int index = 0; index < 8; index++) {
//			switch (index) {
//			case 0:
//				jdbcTemplate.update(sql, new Object[] { index + 1000, 1, 0,
//						lastTs, 0, 50, 0, 20, 1 });
//				insertFusionJobs(jdbcTemplate, index + 1000);
//				UpdateInquiryTraffic(jdbcTemplate, 2, 1);
//				break;
//			case 1:
//				jdbcTemplate.update(sql, new Object[] { index + 1000, 1, 1,
//						lastTs, 0, 50, 0, 10, 1 });
//				insertFusionJobs(jdbcTemplate, index + 1000);
//				break;
//			case 2:
//				jdbcTemplate.update(sql, new Object[] { index + 1000, 1, 1,
//						lastTs - 50000, 0, 50, 0, 10, 1 });
//				insertFusionJobs(jdbcTemplate, index + 1000);
//				break;
//			case 3:
//				jdbcTemplate.update(sql, new Object[] { index + 1000, 1, 1,
//						lastTs, 0, 50, 0, 10, 1 });
//				insertFusionJobs(jdbcTemplate, index + 1000);
//				break;
//			case 4:
//				jdbcTemplate.update(sql, new Object[] { index + 1000, 1, 1,
//						lastTs, 0, 50, 0, 10, 1 });
//				insertFusionJobs(jdbcTemplate, index + 1000);
//				break;
//			case 5:
//				jdbcTemplate.update(sql, new Object[] { index + 1000, 1, 1,
//						lastTs, 0, 50, 0, 10, 1 });
//				insertFusionJobs(jdbcTemplate, index + 1000);
//				updateDB_01(jdbcTemplate, index + 1000,
//						prepareResultXml_oneRecode(80), 1, 100);
//				UpdateInquiryTraffic(jdbcTemplate, 2, 1);
//				break;
//			case 6:
//				jdbcTemplate.update(sql, new Object[] { index + 1000, 1, 1,
//						lastTs, 0, 50, 0, 10, 1 });
//				insertFusionJobs(jdbcTemplate, index + 1000);
//				insertContainerJobFailure(jdbcTemplate);
//				break;
//			case 7:
//				jdbcTemplate.update(sql, new Object[] { index + 1000, 1, 1,
//						lastTs, 0, 50, 0, 1, 1 });
//				insertFusionJobs(jdbcTemplate, index + 1000);
//				updateDB_01(jdbcTemplate, index + 1000,
//						prepareResultXml_oneRecode(80), 1, 100);
//				jdbcTemplate
//						.update("update CONTAINER_JOBS set JOB_STATE=1 where CONTAINER_JOB_ID=?",
//								new Object[] { 10770 });
//				UpdateInquiryTraffic(jdbcTemplate, 2, 1);
//				break;
//
//			}
//
//		}
//		jdbcTemplate.execute("commit");
//	}
//
//	// Fusion Job 1000~1004,1010~1014,1020~1024,1030~1034,1040~1044,1050~1054
//	// Fusion Job 1060~1064,1070~1074,1080~1084,1090~1094
//	public void insertFusionJobs(JdbcTemplate jdbcTemplate, long jobId) {
//		for (int index = 0; index < 8; index++) {
//			String sql = "insert into fusion_jobs(fusion_job_id,function_id,"
//					+ "job_id,search_request_index)values(?,?,?,?)";
//			jdbcTemplate.update(sql, new Object[] { index * 10 + jobId,
//					index + 1, jobId, index });
//			insertContainerJobs(jdbcTemplate, index * 10 + jobId);
//		}
//	}
//
//	public void insertContainer(JdbcTemplate jdbcTemplate) {
//		String sql = "insert into \"CONTAINERS\"(CONTAINER_ID,CONTAINER_NAME,"
//				+ "SCOPE_ID,FORMAT_ID,MAX_SEGMENT_SIZE)values(?,?,?,?,?)";
//		jdbcTemplate.update(sql, new Object[] { 1, "RDBT", 1, 1, 20000000 });
//		jdbcTemplate.update(sql, new Object[] { 2, "SDBT", 1, 1, 20000000 });
//		jdbcTemplate.update(sql, new Object[] { 3, "RDBL", 1, 2, 20000000 });
//		jdbcTemplate.update(sql, new Object[] { 4, "SDBL", 1, 2, 20000000 });
//		jdbcTemplate.update(sql, new Object[] { 5, "PDB", 1, 14, 20000000 });
//		jdbcTemplate.update(sql, new Object[] { 321, "LDB", 1, 3, 20000000 });
//		jdbcTemplate.update(sql, new Object[] { 322, "PLDB", 1, 15, 20000000 });
//		jdbcTemplate.update(sql, new Object[] { 323, "RDBLS", 1, 7, 20000000 });
//		jdbcTemplate.update(sql, new Object[] { 324, "SDBLS", 1, 7, 20000000 });
//		jdbcTemplate.update(sql, new Object[] { 326, "LDBS", 1, 9, 20000000 });
//		jdbcTemplate
//				.update(sql, new Object[] { 331, "RDBTM", 1, 16, 20000000 });
//		jdbcTemplate
//				.update(sql, new Object[] { 332, "SDBTM", 1, 16, 20000000 });
//		jdbcTemplate
//				.update(sql, new Object[] { 333, "RDBLM", 1, 17, 20000000 });
//		jdbcTemplate
//				.update(sql, new Object[] { 334, "SDBLM", 1, 17, 20000000 });
//		jdbcTemplate.update(sql, new Object[] { 335, "FDB", 1, 18, 20000000 });
//		jdbcTemplate.update(sql, new Object[] { 336, "LDBM", 1, 19, 20000000 });
//		jdbcTemplate.update(sql, new Object[] { 341, "XDBL", 1, 20, 20000000 });
//		jdbcTemplate.update(sql, new Object[] { 342, "LDBX", 1, 21, 20000000 });
//	}
//
//	public void updateContainer(JdbcTemplate jdbcTemplate) {
//		String sql = "update \"CONTAINERS\" set CONTAINER_NAME=?,"
//				+ "SCOPE_ID=?,FORMAT_ID=?,MAX_SEGMENT_SIZE=? where CONTAINER_ID=?";
//		jdbcTemplate.update(sql, new Object[] { "RDBT", 1, 1, 20000000, 1 });
//		jdbcTemplate.update(sql, new Object[] { "SDBT", 1, 1, 20000000, 2 });
//		jdbcTemplate.update(sql, new Object[] { "RDBL", 1, 2, 20000000, 3 });
//		jdbcTemplate.update(sql, new Object[] { "SDBL", 1, 2, 20000000, 4 });
//		jdbcTemplate.update(sql, new Object[] { "PDB", 1, 14, 20000000, 5 });
//		jdbcTemplate.update(sql, new Object[] { "LDB", 1, 3, 20000000, 321 });
//		jdbcTemplate.update(sql, new Object[] { "PLDB", 1, 15, 20000000, 322 });
//		jdbcTemplate.update(sql, new Object[] { "RDBLS", 1, 7, 20000000, 323 });
//		jdbcTemplate.update(sql, new Object[] { "SDBLS", 1, 7, 20000000, 324 });
//		jdbcTemplate.update(sql, new Object[] { "LDBS", 1, 9, 20000000, 326 });
//		jdbcTemplate
//				.update(sql, new Object[] { "RDBTM", 1, 16, 20000000, 331 });
//		jdbcTemplate
//				.update(sql, new Object[] { "SDBTM", 1, 16, 20000000, 332 });
//		jdbcTemplate
//				.update(sql, new Object[] { "RDBLM", 1, 17, 20000000, 333 });
//		jdbcTemplate
//				.update(sql, new Object[] { "SDBLM", 1, 17, 20000000, 334 });
//		jdbcTemplate.update(sql, new Object[] { "FDB", 1, 18, 20000000, 335 });
//		jdbcTemplate.update(sql, new Object[] { "LDBM", 1, 19, 20000000, 336 });
//		jdbcTemplate.update(sql, new Object[] { "XDBL", 1, 20, 20000000, 341 });
//		jdbcTemplate.update(sql, new Object[] { "LDBX", 1, 21, 20000000, 342 });
//	}
//
//	// Container Job Id 10000~10048,10100~10148,10200~10248,10300~10348
//	// Container Job Id 10400~10448,10500~10548,10600~10648,10700~10748
//	// Container Job Id 10800~10848,10900~10948
//	public void insertContainerJobs(JdbcTemplate jdbcTemplate, long fusionJobId) {
//		long containerIds[] = { 1, 2, 3, 4, 5, 321, 322, 323, 324, 326, 331,
//				332, 333, 334, 335, 336, 341, 342 };
//		@SuppressWarnings("deprecation")
//		long result = jdbcTemplate
//				.queryForLong("select count(*) from containers");
//		if (result == 0) {
//			insertContainer(jdbcTemplate);
//		}
//
//		for (int index = 0; index < 10; index++) {
//			String sql = "insert into container_jobs(container_job_id,"
//					+ "container_id,fusion_job_id,job_state,plan_id)values(?,?,?,?,?)";
//			jdbcTemplate.update(sql, new Object[] { fusionJobId * 10 + index,
//					containerIds[index], fusionJobId, 1,
//					fusionJobId * 10 + index + 10 });
//		}
//	}
//
//	public void insertFEJobQueue(JdbcTemplate jdbcTemplate) {
//		long epochTime = jdbcTemplate.queryForObject(dateSql, Long.class);
//
//		String sql = "insert into fe_job_queue (job_id,lot_job_id,function_id,priority,"
//				+ "job_state,mu_id,submission_ts,FAILURE_COUNT,CALLBACK_URL,callback_style)values(?,?,?,?,?,?,?,?,?,?)";
//		for (int index = 0; index < 2; index++) {
//			switch (index) {
//			case 0:
//				insertFELotJob(jdbcTemplate, index + 1000);
//				jdbcTemplate.update(sql,
//						new Object[] { index + 1000, index + 1000, 1, 5, 0, 13,
//								epochTime, 0, "127.0.0.1", 0 });
//				break;
//			case 1:
//				insertFELotJob(jdbcTemplate, index + 1000);
//				jdbcTemplate.update(sql,
//						new Object[] { index + 1000, index + 1000, 1, 5, 1, 13,
//								epochTime, 0, "127.0.0.1", 0 });
//				break;
//			}
//		}
//		jdbcTemplate.execute("commit");
//	}
//
//	public void insertFELotJob(JdbcTemplate jdbcTemplate, long feJobId) {
//		long epochTime = jdbcTemplate.queryForObject(dateSql, Long.class);
//
//		String sql = "insert into FE_LOT_JOBS values(?,?,?,?)";
//
//		switch ((int) feJobId) {
//		case 1000:
//			jdbcTemplate.update(sql, new Object[] { feJobId, 13, epochTime,
//					5000 });
//			break;
//		case 1001:
//			jdbcTemplate.update(sql, new Object[] { feJobId, 13,
//					epochTime - 50000, 5000 });
//			break;
//		}
//	}
//
//	public void deleteInquiryJob(JdbcTemplate jdbcTemplate) {
//		String sql = "delete from job_queue";
//		jdbcTemplate.update(sql);
//		sql = "delete from fusion_jobs";
//		jdbcTemplate.update(sql);
//		sql = "delete from container_jobs";
//		jdbcTemplate.update(sql);
//		sql = "delete from container_job_failure_reasons";
//		jdbcTemplate.update(sql);
//		sql = "delete from map_reducers";
//		jdbcTemplate.update(sql);
//		jdbcTemplate.execute("commit");
//	}
//
//	public void deleteSystemConfig(JdbcTemplate jdbcTemplate) {
//		String sql = "delete from SYSTEM_CONFIG";
//		jdbcTemplate.update(sql);
//		sql = "delete from MM_EVENTS";
//		jdbcTemplate.update(sql);
//		jdbcTemplate.execute("commit");
//	}
//
//	public void deleteMatchManagers(JdbcTemplate jdbcTemplate) {
//		String sql = "delete from MATCH_MANAGERS";
//		jdbcTemplate.update(sql);
//		sql = "delete from MATCH_UNITS";
//		jdbcTemplate.update(sql);
//		sql = "delete from MU_CONTACTS";
//		jdbcTemplate.update(sql);
//		sql = "delete from DATA_MANAGERS";
//		jdbcTemplate.update(sql);
//		sql = "delete from DM_CONTACTS";
//		jdbcTemplate.update(sql);
//		sql = "delete from MAP_REDUCERS";
//		jdbcTemplate.update(sql);
//		sql = "delete from MR_CONTACTS";
//		jdbcTemplate.update(sql);
//		jdbcTemplate.execute("commit");
//	}
//
//	public void deleteFEJobs(JdbcTemplate jdbcTemplate) {
//		String sql = "delete from FE_JOB_QUEUE";
//		jdbcTemplate.update(sql);
//		sql = "delete from FE_LOT_JOBS";
//		jdbcTemplate.update(sql);
//		jdbcTemplate.execute("commit");
//	}
//
//	public void insertMatchManagers(JdbcTemplate jdbcTemplate) {
//		long epochTime = jdbcTemplate.queryForObject(dateSql, Long.class);
//		String sql = "INSERT INTO MATCH_MANAGERS (MM_ID, UNIQUE_ID, STATE, CONTACT_URL, HEARTBEAT_TS, VERSION)"
//				+ "  VALUES (?, ?, ?, ?, ?, ?)";
//		for (int index = 0; index <= 10; index++) {
//			long mmId = index + 10;
//			String uniqueId = "10.84.75." + String.valueOf(index + 213);
//			String ConnectUrl = "http://11.20.13." + String.valueOf(index + 10)
//					+ ":8080/matchmanager";
//			String version = "5.0.0";
//			if (index < 3) {
//				jdbcTemplate.update(sql, new Object[] { mmId, uniqueId,
//						UnitState.WORKING.name(), ConnectUrl, epochTime,
//						version });
//			} else if (index < 4) {
//				jdbcTemplate.update(sql, new Object[] { mmId, uniqueId,
//						UnitState.WORKING.name(), ConnectUrl,
//						epochTime - 5000000, version });
//			} else if (index < 8) {
//				jdbcTemplate.update(sql,
//						new Object[] { mmId, uniqueId, UnitState.EXITED.name(),
//								ConnectUrl, epochTime, version });
//			} else if (index <= 10) {
//				jdbcTemplate.update(sql, new Object[] { mmId, uniqueId,
//						UnitState.TIMED_OUT.name(), ConnectUrl, epochTime,
//						version });
//			}
//		}
//		jdbcTemplate.execute("commit");
//	}
//
//	public void insertMapReducer(JdbcTemplate jdbcTemplate) {
//		String sql = "insert into MAP_REDUCERS (MR_ID,UNIQUE_ID,STATE)Values(?,?,?)";
//		jdbcTemplate.update(sql, new Object[] { 1, "127.0.0.1", "WORKING" });
//		sql = "insert into MR_CONTACTS(MR_ID,CONTACT_TS)Values(1,"
//				+ "match_manager_api.get_epoch_time_num())";
//		jdbcTemplate.update(sql);
//		jdbcTemplate.execute("commit");
//	}
//
//	public void insertContainerJobFailure(JdbcTemplate jdbcTemplate) {
//		String sql = "insert  into container_job_failure_reasons (failure_id, code, "
//				+ "reason, failure_time, mr_id, container_job_id, segment_id)"
//				+ "values (1,'1001','error Msg','1421206612748',1, 10063,null)";
//		jdbcTemplate.update(sql);
//	}
//
//	public void UpdateInquiryTraffic(JdbcTemplate jdbcTemplate, long execCount,
//			long familyId) {
//		String sql = "update inquiry_traffic set job_exec_count=? where family_id=?";
//
//		jdbcTemplate.update(sql, new Object[] { execCount, familyId });
//	}
//
//	public void UpdateSystemConfig(JdbcTemplate jdbcTemplate,
//			String propertyName, String propertyValue) {
//		String sql = "update SYSTEM_CONFIG set PROPERTY_VALUE=? where PROPERTY_NAME=?";
//		jdbcTemplate.update(sql, new Object[] { propertyValue, propertyName });
//		jdbcTemplate.execute("commit");
//	}
//
//	public void UpdateSystemConfig(EntityManager entityManager,
//			String propertyName, String propertyValue) {
//		Query q = entityManager.createNamedQuery("NQ::getConfigEntity");
//		q.setParameter("name", propertyName);
//		SystemConfigEntity e = (SystemConfigEntity) q.getResultList().get(0);
//		e.setValue(propertyValue);
//		entityManager.merge(e);
//	}
//
//	public void insertMMEvents(JdbcTemplate jdbcTemplate, String name,
//			long mmId, long lastTs) {
//		String sql = "insert into MM_EVENTS (NAME,LAST_TS,MM_ID)values(?,?,?)";
//		jdbcTemplate.update(sql, new Object[] { name, lastTs, mmId });
//		jdbcTemplate.execute("commit");
//	}
//
//	// public void updateMMEvents(JdbcTemplate jdbcTemplate, String name,
//	// long mmId, long lastTs) {
//	// String sql = "update mm_events set last_ts= ?, mm_id=? WHERE name=?";
//	// jdbcTemplate.update(sql, new Object[] { lastTs, mmId, name });
//	// jdbcTemplate.execute("commit");
//	// }
//
//	public void insertMM_SameMMId_pass(JdbcTemplate jdbcTemplate) {
//		long lastTs = jdbcTemplate.queryForObject(dateSql, Long.class);
//		insertMatchManagers(jdbcTemplate);
//		for (SchedulerEnum schedulerEnum : SchedulerEnum.values()) {
//			switch (schedulerEnum) {
//			case PurgeJobQueueSchedulable:
//				long mmId = 10;
//				insertMMEvents(jdbcTemplate, schedulerEnum.getMMEventType()
//						.name(), mmId, lastTs);
//				break;
//			case GarbageSegmentChangeLogSchedulable:
//				mmId = 11;
//				insertMMEvents(jdbcTemplate, schedulerEnum.getMMEventType()
//						.name(), mmId, lastTs);
//				break;
//			case DefragSchedulable:
//				mmId = 12;
//				insertMMEvents(jdbcTemplate, schedulerEnum.getMMEventType()
//						.name(), mmId, lastTs + 60000);
//				break;
//			case PollSchedulable:
//				mmId = 15;
//				insertMMEvents(jdbcTemplate, schedulerEnum.getMMEventType()
//						.name(), mmId, lastTs);
//				break;
//			case LoadBalanceSchedulable:
//				mmId = 16;
//				insertMMEvents(jdbcTemplate, schedulerEnum.getMMEventType()
//						.name(), mmId, lastTs);
//				break;
//			case AggregationSchedulable:
//				mmId = 17;
//				insertMMEvents(jdbcTemplate, schedulerEnum.getMMEventType()
//						.name(), mmId, lastTs);
//				break;
//			case IdentifyPlannerSchedulable:
//				mmId = 18;
//				insertMMEvents(jdbcTemplate, schedulerEnum.getMMEventType()
//						.name(), mmId, lastTs);
//				break;
//			case FePlannerSchedulable:
//				mmId = 19;
//				insertMMEvents(jdbcTemplate, schedulerEnum.getMMEventType()
//						.name(), mmId, lastTs - 500000);
//				break;
//			default:
//				break;
//			}
//		}
//	}
//
//	public void insertMM_SameMMId(JdbcTemplate jdbcTemplate) {
//		long lastTs = jdbcTemplate.queryForObject(dateSql, Long.class);
//		insertMatchManagers(jdbcTemplate);
//		for (SchedulerEnum schedulerEnum : SchedulerEnum.values()) {
//			switch (schedulerEnum) {
//			case PurgeJobQueueSchedulable:
//				long mmId = 10;
//				insertMMEvents(jdbcTemplate, schedulerEnum.getMMEventType()
//						.name(), mmId, lastTs);
//				break;
//			case GarbageSegmentChangeLogSchedulable:
//				mmId = 11;
//				insertMMEvents(jdbcTemplate, schedulerEnum.getMMEventType()
//						.name(), mmId, lastTs);
//				break;
//			case DefragSchedulable:
//				mmId = 12;
//				insertMMEvents(jdbcTemplate, schedulerEnum.getMMEventType()
//						.name(), mmId, lastTs);
//				break;
//			case PollSchedulable:
//				mmId = 15;
//				insertMMEvents(jdbcTemplate, schedulerEnum.getMMEventType()
//						.name(), mmId, lastTs);
//				break;
//			case LoadBalanceSchedulable:
//				mmId = 16;
//				insertMMEvents(jdbcTemplate, schedulerEnum.getMMEventType()
//						.name(), mmId, lastTs);
//				break;
//			case AggregationSchedulable:
//				mmId = 17;
//				insertMMEvents(jdbcTemplate, schedulerEnum.getMMEventType()
//						.name(), mmId, lastTs);
//				break;
//			case IdentifyPlannerSchedulable:
//				mmId = 18;
//				insertMMEvents(jdbcTemplate, schedulerEnum.getMMEventType()
//						.name(), mmId, lastTs);
//				break;
//			case FePlannerSchedulable:
//				mmId = 19;
//				insertMMEvents(jdbcTemplate, schedulerEnum.getMMEventType()
//						.name(), mmId, lastTs);
//				break;
//			default:
//				break;
//			}
//		}
//	}
//
//	public void insertMM_SameMMId_mmId10(JdbcTemplate jdbcTemplate) {
//		long lastTs = jdbcTemplate.queryForObject(dateSql, Long.class);
//		insertMatchManagers(jdbcTemplate);
//		for (SchedulerEnum schedulerEnum : SchedulerEnum.values()) {
//			if (schedulerEnum.equals(SchedulerEnum.MMHeartBeatSchedulable)) {
//				continue;
//			}
//			long mmId = 10;
//			insertMMEvents(jdbcTemplate, schedulerEnum.getMMEventType().name(),
//					mmId, lastTs);
//		}
//	}
//
//	public void insertMR(JdbcTemplate jdbcTemplate, long lastTs) {
//		String sql = "insert into MAP_REDUCERS(MR_ID,UNIQUE_ID,STATE)values(?,?,?)";
//		for (int index = 0; index < 10; index++) {
//			if (index < 4) {
//				jdbcTemplate
//						.update(sql,
//								new Object[] { index + 10,
//										"192.168.100." + index + 10,
//										UnitState.WORKING.name() });
//
//			} else if (index < 6) {
//				jdbcTemplate.update(sql,
//						new Object[] { index + 10, "192.168.100." + index + 10,
//								UnitState.TIMED_OUT.name() });
//			} else if (index < 10) {
//				jdbcTemplate.update(sql, new Object[] { index + 10,
//						"192.168.100." + index + 10, UnitState.EXITED.name() });
//			}
//		}
//
//		jdbcTemplate.execute("commit");
//
//		for (int idx = 0; idx < 10; idx++) {
//			sql = "insert into MR_CONTACTS (MR_ID,CONTACT_TS)values(?,?)";
//			if (idx == 3) {
//				jdbcTemplate.update(sql, new Object[] { idx + 10,
//						lastTs - 500000 });
//			} else {
//				jdbcTemplate.update(sql, new Object[] { idx + 10, lastTs });
//			}
//		}
//		jdbcTemplate.execute("commit");
//	}
//
//	public void insertMU(JdbcTemplate jdbcTemplate, long lastTs) {
//		String sql = "insert into MATCH_UNITS(MU_ID,UNIQUE_ID,STATE)values(?,?,?)";
//		for (int index = 0; index < 10; index++) {
//			if (index < 4) {
//				jdbcTemplate
//						.update(sql,
//								new Object[] { index + 10,
//										"192.168.100." + index + 10,
//										UnitState.WORKING.name() });
//
//			} else if (index < 6) {
//				jdbcTemplate.update(sql,
//						new Object[] { index + 10, "192.168.100." + index + 10,
//								UnitState.TIMED_OUT.name() });
//			} else if (index < 10) {
//				jdbcTemplate.update(sql, new Object[] { index + 10,
//						"192.168.100." + index + 10, UnitState.EXITED.name() });
//			}
//		}
//
//		jdbcTemplate.execute("commit");
//
//		for (int idx = 0; idx < 10; idx++) {
//			sql = "insert into MU_CONTACTS (MU_ID,CONTACT_TS)values(?,?)";
//			if (idx == 3) {
//				jdbcTemplate.update(sql, new Object[] { idx + 10,
//						lastTs - 500000 });
//			} else {
//				jdbcTemplate.update(sql, new Object[] { idx + 10, lastTs });
//			}
//		}
//		jdbcTemplate.execute("commit");
//	}
//
//	public void insertDM(JdbcTemplate jdbcTemplate, long lastTs) {
//		String sql = "insert into DATA_MANAGERS(DM_ID,UNIQUE_ID,STATE)values(?,?,?)";
//		for (int index = 0; index < 10; index++) {
//			if (index < 4) {
//				jdbcTemplate
//						.update(sql,
//								new Object[] { index + 10,
//										"192.168.100." + index + 10,
//										UnitState.WORKING.name() });
//			} else if (index < 6) {
//				jdbcTemplate.update(sql,
//						new Object[] { index + 10, "192.168.100." + index + 10,
//								UnitState.TIMED_OUT.name() });
//			} else if (index < 10) {
//				jdbcTemplate.update(sql, new Object[] { index + 10,
//						"192.168.100." + index + 10, UnitState.EXITED.name() });
//			}
//		}
//
//		jdbcTemplate.execute("commit");
//
//		for (int idx = 0; idx < 10; idx++) {
//			sql = "insert into DM_CONTACTS (DM_ID,CONTACT_TS)values(?,?)";
//			if (idx == 3) {
//				jdbcTemplate.update(sql, new Object[] { idx + 10,
//						lastTs - 500000 });
//			} else {
//				jdbcTemplate.update(sql, new Object[] { idx + 10, lastTs });
//			}
//
//		}
//		jdbcTemplate.execute("commit");
//	}
//
//	public Map<String, Object> getContainerJobFailureReasons(
//			JdbcTemplate jdbcTemplate, long jobId) {
//		String sql = "select cjfr.* from JOB_QUEUE jq,FUSION_JOBS fj,"
//				+ "CONTAINER_JOBS cj,CONTAINER_JOB_FAILURE_REASONS cjfr "
//				+ "where jq.JOB_ID=fj.JOB_ID "
//				+ "and fj.FUSION_JOB_ID=cj.FUSION_JOB_ID "
//				+ "and cj.CONTAINER_JOB_ID=cjfr.CONTAINER_JOB_ID "
//				+ "and jq.JOB_ID=? order by cj.CONTAINER_JOB_ID";
//
//		List<Map<String, Object>> list = jdbcTemplate.queryForList(sql,
//				new Object[] { jobId });
//		if (CollectionsUtil.isEmpty(list)) {
//			return null;
//		}
//		return CollectionsUtil.getFirst(list);
//	}
//
//	public void updateInquiryJob(JdbcTemplate jdbcTemplate) {
//		long lastTs = jdbcTemplate.queryForObject(dateSql, Long.class);
//		for (int index = 0; index < 8; index++) {
//			String sql = "update JOB_QUEUE jq set jq.ASSIGNED_TS=?,TIMEOUTS=5000 where jq.JOB_ID=?";
//
//			switch (index) {
//			case 0:
//				jdbcTemplate.update(sql, new Object[] { lastTs, index + 1000 });
//				break;
//			case 1:
//				jdbcTemplate.update(sql, new Object[] { lastTs, index + 1000 });
//				break;
//			case 2:
//				jdbcTemplate.update(sql, new Object[] { lastTs - 50000,
//						index + 1000 });
//				break;
//			case 3:
//				jdbcTemplate.update(sql, new Object[] { lastTs, index + 1000 });
//				break;
//			case 4:
//				jdbcTemplate.update(sql, new Object[] { lastTs, index + 1000 });
//				break;
//			case 5:
//				jdbcTemplate.update(sql, new Object[] { lastTs, index + 1000 });
//				break;
//			case 6:
//				jdbcTemplate.update(sql, new Object[] { lastTs, index + 1000 });
//				break;
//			case 7:
//				jdbcTemplate.update(sql, new Object[] { lastTs, index + 1000 });
//				break;
//			}
//		}
//
//	}
//
//	public void updateAllContainerJobs(JdbcTemplate jdbcTemplate, long jobId) {
//		String sql = "update CONTAINER_JOBS cj set cj.PLAN_ID=1 "
//				+ "where cj.CONTAINER_JOB_ID in ("
//				+ "select cj_.CONTAINER_JOB_ID from JOB_QUEUE jq, "
//				+ "FUSION_JOBS fj,CONTAINER_JOBS cj_ "
//				+ "where jq.JOB_ID=fj.JOB_ID "
//				+ "and fj.FUSION_JOB_ID=cj_.FUSION_JOB_ID "
//				+ "and jq.JOB_ID=?)";
//
//		jdbcTemplate.update(sql, new Object[] { jobId });
//	}
//
//	public void updateContianerJob(JdbcTemplate jdbcTemplate,
//			long containerJobId) {
//		long lastTs = jdbcTemplate.queryForObject(dateSql, Long.class);
//		String sql = "update CONTAINER_JOBS cj set cj.ASSIGNED_TS=? where cj.CONTAINER_JOB_ID=?";
//		jdbcTemplate.update(sql,
//				new Object[] { lastTs - 500000, containerJobId });
//	}
//
//	// set result_ts=null, container_job_result=null, job_state=1
//	public void updateContianerJob_01(JdbcTemplate jdbcTemplate,
//			long containerJobId) {
//		String sql = "update container_jobs set result_ts=null, container_job_result=null, job_state=1 where container_job_id=?";
//		jdbcTemplate.update(sql, new Object[] { containerJobId });
//		jdbcTemplate.execute("commit");
//	}
//
//	public void updateJobQueue(JdbcTemplate jdbcTemplate, long jobId) {
//		String sql = "update JOB_QUEUE jq set jq.DYNTHRESH_PERCENTAGE_POINT=? ,"
//				+ "jq.DYNTHRESH_HIT_THRESHOLD=? " + "where jq.JOB_ID=?";
//		jdbcTemplate.update(sql, new Object[] { 0.75, 2, jobId });
//		jdbcTemplate.execute("commit");
//	}
//
//	public void updateJobQueueURLandStyle(JdbcTemplate jdbcTemplate,
//			long jobId, String url, int style) {
//		String sql = "update JOB_QUEUE  set callback_url=?, callback_style=? where job_id=?";
//		jdbcTemplate.update(sql, new Object[] { url, style, jobId });
//		jdbcTemplate.execute("commit");
//	}
//
//	public void updateDB_01(JdbcTemplate jdbcTemplate, long jobId,
//			List<String> containerJobResullt, long matchCount, long readCount) {
//		String sql = "select cj.CONTAINER_JOB_ID from JOB_QUEUE jq,"
//				+ "FUSION_JOBS fj,CONTAINER_JOBS cj "
//				+ "where jq.JOB_ID=? and jq.JOB_ID=fj.JOB_ID "
//				+ "and fj.FUSION_JOB_ID=cj.FUSION_JOB_ID ";
//
//		List<Long> containerJobs = jdbcTemplate.queryForList(sql, Long.class,
//				new Object[] { jobId });
//
//		int index = 0;
//		long lastTs = jdbcTemplate.queryForObject(dateSql, Long.class);
//		for (Long containerJobId : containerJobs) {
//			sql = "update CONTAINER_JOBS cj set cj.CONTAINER_JOB_RESULT=?,RESULT_TS=?,JOB_STATE=2 where cj.CONTAINER_JOB_ID=?";
//			PBInquiryJobResultInternal internal = ProtobufHelper
//					.InquiryJobResultInternal(null,
//							containerJobResullt.get(index), matchCount,
//							readCount);
//
//			System.out.print(internal.toString());
//			jdbcTemplate.update(sql, new Object[] { internal.toByteArray(),
//					lastTs, containerJobId });
//			index++;
//		}
//		updateJobQueue(jdbcTemplate, jobId);
//		jdbcTemplate.execute("commit");
//	}
//
//	public void updateJobQueueJobState(JdbcTemplate jdbcTemplate, long jobId) {
//		String sql = "update JOB_QUEUE jq set jq.JOB_STATE=2 where jq.JOB_ID=? ";
//		jdbcTemplate.update(sql, new Object[] { jobId });
//		jdbcTemplate.execute("commit");
//	}
//
//	public void updateDB_common(JdbcTemplate jdbcTemplate, long jobId,
//			List<String> containerJobResullt, long matchCount, long readCount,
//			Integer founctionId) {
//		List<PBInquiryJobResultInternal> internals = Lists.newArrayList();
//		jdbcTemplate.update("delete from container_jobs");
//		jdbcTemplate.update("delete from fusion_jobs");
//		jdbcTemplate.update("delete from job_queue");
//		jdbcTemplate
//				.update("insert into JOB_QUEUE(JOB_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE,TIMEOUTS,FAILURE_COUNT,REMAIN_JOBS,FAMILY_ID,DYNTHRESH_PERCENTAGE_POINT,DYNTHRESH_HIT_THRESHOLD)values(1,1,1,111,1,10,0,0,1,5.2,2000)");
//		jdbcTemplate
//				.update("insert into fusion_jobs(FUSION_JOB_ID,FUNCTION_ID,JOB_ID,SEARCH_REQUEST_INDEX)values(1,?,1,1)",
//						founctionId);
//		jdbcTemplate
//				.update("insert into fusion_jobs(FUSION_JOB_ID,FUNCTION_ID,JOB_ID,SEARCH_REQUEST_INDEX)values(2,1,1,2)");
//		long lastTs = jdbcTemplate.queryForObject(dateSql, Long.class);
//		for (int i = 0; i < containerJobResullt.size(); i++) {
//
//			String sql1 = "insert into CONTAINER_JOBS(CONTAINER_JOB_ID,CONTAINER_ID,FUSION_JOB_ID,JOB_STATE)values(?,?,1,2)";
//
//			PBInquiryJobResultInternal internal = ProtobufHelper
//					.InquiryJobResultInternal(null, containerJobResullt.get(i),
//							matchCount, readCount);
//			Integer containerId = internal.getCandidateList().getCandidate(0)
//					.getCandidateTemplate(0).getContainerId();
//			jdbcTemplate.update(sql1, new Object[] { i, containerId });
//			String sql = "update CONTAINER_JOBS cj set cj.CONTAINER_JOB_RESULT=?,RESULT_TS=?,JOB_STATE=2 where cj.CONTAINER_JOB_ID=?";
//			jdbcTemplate.update(sql, new Object[] { internal.toByteArray(),
//					lastTs, i });
//			internals.add(internal);
//		}
//	}
//
//	public List<String> prepareResultXml_null(int size) {
//		List<String> list = Lists.newArrayList();
//		for (int index = 0; index < size; index++) {
//			list.add(null);
//		}
//		return list;
//	}
//
//	// String format
//	// candidate: externalId,fusionScore,consolidateKey
//	// candidateTemplate: eventId,containerId,inquiryRequestIndex,compositScore
//	// individualScore: score,fingerNumber,axis
//	// candidate and candidate ";"
//	// candidate and candidateTemplate "||"
//	// candidateTemplate and candidateTemplate "*"
//	// candidateTemplate and individualScore "@"
//	// individualScore and individualScore "@"
//	public List<String> prepareResultXml_oneRecode(int size) {
//		List<String> list = Lists.newArrayList();
//		for (int index = 0; index < 8; index++) {
//			list.add("ExternalId01," + String.valueOf(10 + index * 10)
//					+ ",ExternalId01-10-1||1,4," + String.valueOf(index % 4)
//					+ "," + String.valueOf(10 + index * 10)
//					+ "@25,10,1@75,10,1@-95,10,1");
//			list.add("ExternalId02," + String.valueOf(10 + index * 10)
//					+ ",ExternalId02-10-2||1,4," + String.valueOf(index % 4)
//					+ "," + String.valueOf(10 + index * 10)
//					+ "@25,10,2@75,10,2@-95,10,2");
//			list.add("ExternalId03," + String.valueOf(10 + index * 10)
//					+ ",ExternalId03-10-3||1,4," + String.valueOf(index % 4)
//					+ "," + String.valueOf(10 + index * 10)
//					+ "@25,10,3@75,10,3@-95,10,3");
//			list.add("ExternalId04," + String.valueOf(10 + index * 10)
//					+ ",ExternalId04-10-4||1,4," + String.valueOf(index % 4)
//					+ "," + String.valueOf(10 + index * 10)
//					+ "@25,10,4@75,10,4@-95,10,4");
//			list.add("ExternalId05," + String.valueOf(10 + index * 10)
//					+ ",ExternalId05-10-1||1,4," + String.valueOf(index % 4)
//					+ "," + String.valueOf(10 + index * 10)
//					+ "@25,10,1@75,10,1@-95,10,1");
//			list.add("ExternalId06," + String.valueOf(10 + index * 10)
//					+ ",ExternalId06-10-2||1,4," + String.valueOf(index % 4)
//					+ "," + String.valueOf(10 + index * 10)
//					+ "@25,10,2@75,10,2@95,10,2");
//			list.add("ExternalId07," + String.valueOf(10 + index * 10)
//					+ ",ExternalId07-10-3||1,4," + String.valueOf(index % 4)
//					+ "," + String.valueOf(10 + index * 10)
//					+ "@25,10,3@75,10,3@95,10,3");
//			list.add("ExternalId08," + String.valueOf(10 + index * 10)
//					+ ",ExternalId08-10-4||1,4," + String.valueOf(index % 4)
//					+ "," + String.valueOf(10 + index * 10)
//					+ "@25,10,4@75,10,4@95,10,4");
//			list.add("ExternalId09," + String.valueOf(10 + index * 10)
//					+ ",ExternalId09-10-1||1,4," + String.valueOf(index % 4)
//					+ "," + String.valueOf(10 + index * 10)
//					+ "@25,10,1@75,10,1@95,10,1");
//			list.add("ExternalId10," + String.valueOf(10 + index * 10)
//					+ ",ExternalId10-10-2||1,4," + String.valueOf(index % 4)
//					+ "," + String.valueOf(index % 4)
//					+ "@25,10,2@75,10,2@95,10,2");
//		}
//		return list;
//	}
//
//	public List<String> prepareResultXml_oneRecode1(int size) {
//		List<String> list = Lists.newArrayList();
//		for (int index = 0; index < 8; index++) {
//			list.add("ExternalId01," + String.valueOf(10 + index * 10)
//					+ ",ExternalId01-10-1||1,4," + String.valueOf(index % 3)
//					+ "," + String.valueOf(10 + index * 10)
//					+ "@25,10,1@75,10,1@95,10,1");
//			list.add("ExternalId02," + String.valueOf(10 + index * 10)
//					+ ",ExternalId02-10-2||1,4," + String.valueOf(index % 3)
//					+ "," + String.valueOf(10 + index * 10)
//					+ "@25,10,2@75,10,2@95,10,2");
//			list.add("ExternalId03," + String.valueOf(10 + index * 10)
//					+ ",ExternalId03-10-3||1,4," + String.valueOf(index % 3)
//					+ "," + String.valueOf(10 + index * 10)
//					+ "@25,10,3@75,10,3@95,10,3");
//			list.add("ExternalId04," + String.valueOf(10 + index * 10)
//					+ ",ExternalId04-10-4||1,4," + String.valueOf(index % 3)
//					+ "," + String.valueOf(10 + index * 10)
//					+ "@25,10,4@75,10,4@95,10,4");
//			list.add("ExternalId05," + String.valueOf(10 + index * 10)
//					+ ",ExternalId05-10-1||1,4," + String.valueOf(index % 3)
//					+ "," + String.valueOf(10 + index * 10)
//					+ "@25,10,1@75,10,1@95,10,1");
//			list.add("ExternalId06," + String.valueOf(10 + index * 10)
//					+ ",ExternalId06-10-2||1,4," + String.valueOf(index % 3)
//					+ "," + String.valueOf(10 + index * 10)
//					+ "@25,10,2@75,10,2@95,10,2");
//			list.add("ExternalId07," + String.valueOf(10 + index * 10)
//					+ ",ExternalId07-10-3||1,4," + String.valueOf(index % 3)
//					+ "," + String.valueOf(10 + index * 10)
//					+ "@25,10,3@75,10,3@95,10,3");
//			list.add("ExternalId08," + String.valueOf(10 + index * 10)
//					+ ",ExternalId08-10-4||1,4," + String.valueOf(index % 3)
//					+ "," + String.valueOf(10 + index * 10)
//					+ "@25,10,4@75,10,4@95,10,4");
//			list.add("ExternalId09," + String.valueOf(10 + index * 10)
//					+ ",ExternalId09-10-1||1,4," + String.valueOf(index % 3)
//					+ "," + String.valueOf(10 + index * 10)
//					+ "@25,10,1@75,10,1@95,10,1");
//			list.add("ExternalId10," + String.valueOf(10 + index * 10)
//					+ ",ExternalId10-10-2||1,4," + String.valueOf(index % 3)
//					+ "," + String.valueOf(index % 4)
//					+ "@25,10,2@75,10,2@95,10,2");
//		}
//		return list;
//	}
//
//	public List<String> prepareResultXml_twoRecodeDiff(int size) {
//		List<String> list = Lists.newArrayList();
//		list.add("ExternalId01," + String.valueOf(58)
//				+ ",ExternalId01-10-1||1,4," + String.valueOf(0) + ","
//				+ String.valueOf(58) + "@25,10,1@75,10,1@95,10,1;ExternalId01,"
//				+ String.valueOf(59) + ",ExternalId01-10-1||2,5,"
//				+ String.valueOf(1) + "," + String.valueOf(59)
//				+ "@25,10,1@75,10,1@95,10,1");
//
//		list.add("ExternalId01," + String.valueOf(70)
//				+ ",ExternalId01-10-1||1,4," + String.valueOf(0) + ","
//				+ String.valueOf(70) + "@25,10,1@75,10,1@95,10,1;ExternalId01,"
//				+ String.valueOf(89) + ",ExternalId01-10-1||2,5,"
//				+ String.valueOf(7) + "," + String.valueOf(89)
//				+ "@25,10,1@75,10,1@95,10,1");
//		return list;
//	}
//
//	public List<String> prepareResultXml_twoRecord(int size) {
//		List<String> list = Lists.newArrayList();
//		for (int index = 0; index < 8; index++) {
//			list.add("ExternalId01," + String.valueOf(10 + index * 8)
//					+ ",ExternalId01-10-1||1,4," + String.valueOf(index % 4)
//					+ "," + String.valueOf(10 + index * 8)
//					+ "@25,10,1@75,10,1@95,10,1;ExternalId01,"
//					+ String.valueOf(10 + index * 9)
//					+ ",ExternalId01-10-1||2,5," + String.valueOf(index % 6)
//					+ "," + String.valueOf(10 + index * 9)
//					+ "@25,10,1@75,10,1@95,10,1");
//			list.add("ExternalId02," + String.valueOf(10 + index * 8)
//					+ ",ExternalId02-10-2||1,4," + String.valueOf(index % 4)
//					+ ",50@25,10,2@75,10,2@95,10,2;ExternalId02,"
//					+ String.valueOf(10 + index * 9)
//					+ ",ExternalId02-10-2||2,5," + String.valueOf(index % 6)
//					+ ",50@25,10,2@75,10,2@95,10,2");
//			list.add("ExternalId03," + String.valueOf(10 + index * 8)
//					+ ",ExternalId03-10-3||1,4," + String.valueOf(index % 4)
//					+ ",50@25,10,3@75,10,3@95,10,3;ExternalId03,"
//					+ String.valueOf(10 + index * 9)
//					+ ",ExternalId03-10-3||2,5," + String.valueOf(index % 6)
//					+ ",50@25,10,3@75,10,3@95,10,3");
//			list.add("ExternalId04," + String.valueOf(10 + index * 8)
//					+ ",ExternalId04-10-4||1,4," + String.valueOf(index % 4)
//					+ ",50@25,10,4@75,10,4@95,10,4;ExternalId04,"
//					+ String.valueOf(10 + index * 9)
//					+ ",ExternalId04-10-4||2,5," + String.valueOf(index % 6)
//					+ ",50@25,10,4@75,10,4@95,10,4");
//			list.add("ExternalId05," + String.valueOf(10 + index * 8)
//					+ ",ExternalId05-10-1||1,4," + String.valueOf(index % 4)
//					+ ",50@25,10,1@75,10,1@95,10,1;ExternalId05,"
//					+ String.valueOf(10 + index * 9)
//					+ ",ExternalId05-10-1||2,5," + String.valueOf(index % 6)
//					+ ",50@25,10,1@75,10,1@95,10,1");
//			list.add("ExternalId06," + String.valueOf(10 + index * 8)
//					+ ",ExternalId06-10-2||1,4," + String.valueOf(index % 4)
//					+ ",50@25,10,2@75,10,2@95,10,2;ExternalId06,"
//					+ String.valueOf(10 + index * 9)
//					+ ",ExternalId06-10-2||2,5," + String.valueOf(index % 6)
//					+ ",50@25,10,2@75,10,2@95,10,2");
//			list.add("ExternalId07," + String.valueOf(10 + index * 8)
//					+ ",ExternalId07-10-3||1,4," + String.valueOf(index % 4)
//					+ ",50@25,10,3@75,10,3@95,10,3;ExternalId07,"
//					+ String.valueOf(10 + index * 9)
//					+ ",ExternalId07-10-3||2,5," + String.valueOf(index % 6)
//					+ ",50@25,10,3@75,10,3@95,10,3");
//			list.add("ExternalId08," + String.valueOf(10 + index * 8)
//					+ ",ExternalId08-10-4||1,4," + String.valueOf(index % 4)
//					+ ",50@25,10,4@75,10,4@95,10,4;ExternalId08,"
//					+ String.valueOf(10 + index * 9)
//					+ ",ExternalId08-10-4||2,5," + String.valueOf(index % 6)
//					+ ",50@25,10,4@75,10,4@95,10,4");
//			list.add("ExternalId09," + String.valueOf(10 + index * 8)
//					+ ",ExternalId09-10-1||1,4," + String.valueOf(index % 4)
//					+ ",50@25,10,1@75,10,1@95,10,1;ExternalId09,"
//					+ String.valueOf(10 + index * 9)
//					+ ",ExternalId09-10-1||2,5," + String.valueOf(index % 6)
//					+ ",50@25,10,1@75,10,1@95,10,1");
//			list.add("ExternalId10," + String.valueOf(10 + index * 8)
//					+ ",ExternalId10-10-2||1,4," + String.valueOf(index % 4)
//					+ ",50@25,10,2@75,10,2@95,10,2;ExternalId10,"
//					+ String.valueOf(10 + index * 9)
//					+ ",ExternalId10-10-2||2,5," + String.valueOf(index % 6)
//					+ ",50@25,10,2@75,10,2@95,10,2");
//		}
//		return list;
//	}
//
//	public List<String> prepareResultXml_twoRecord_sortMerge(int size) {
//		List<String> list = Lists.newArrayList();
//		for (int index = 0; index < 8; index++) {
//			list.add("ExternalId01," + String.valueOf(10 + index * 8)
//					+ ",ExternalId01-10-1||1,4," + String.valueOf(index % 4)
//					+ "," + String.valueOf(10 + index * 8)
//					+ "@25,10,1@75,10,1@95,10,1;ExternalId01,"
//					+ String.valueOf(10 + index * 9)
//					+ ",ExternalId01-10-1||2,5," + String.valueOf(index % 6)
//					+ "," + String.valueOf(10 + index * 9)
//					+ "@25,10,1@75,10,1@95,10,1");
//			list.add("ExternalId02," + String.valueOf(10 + index * 8)
//					+ ",ExternalId02-10-2||1,4," + String.valueOf(index % 3)
//					+ ",50@25,10,2@75,10,2@95,10,2;ExternalId02,"
//					+ String.valueOf(10 + index * 9)
//					+ ",ExternalId02-10-2||2,5," + String.valueOf(index % 8)
//					+ ",50@25,10,2@75,10,2@95,10,2");
//			list.add("ExternalId03," + String.valueOf(10 + index * 8)
//					+ ",ExternalId03-10-3||1,4," + String.valueOf(index % 2)
//					+ ",50@25,10,3@75,10,3@95,10,3;ExternalId03,"
//					+ String.valueOf(10 + index * 9)
//					+ ",ExternalId03-10-3||2,5," + String.valueOf(index % 5)
//					+ ",50@25,10,3@75,10,3@95,10,3");
//			list.add("ExternalId04," + String.valueOf(10 + index * 8)
//					+ ",ExternalId04-10-4||1,4," + String.valueOf(index % 3)
//					+ ",50@25,10,4@75,10,4@95,10,4;ExternalId04,"
//					+ String.valueOf(10 + index * 9)
//					+ ",ExternalId04-10-4||2,5," + String.valueOf(index % 7)
//					+ ",50@25,10,4@75,10,4@95,10,4");
//			list.add("ExternalId05," + String.valueOf(10 + index * 8)
//					+ ",ExternalId05-10-1||1,4," + String.valueOf(index % 6)
//					+ ",50@25,10,1@75,10,1@95,10,1;ExternalId05,"
//					+ String.valueOf(10 + index * 9)
//					+ ",ExternalId05-10-1||2,5," + String.valueOf(index % 4)
//					+ ",50@25,10,1@75,10,1@95,10,1");
//			list.add("ExternalId06," + String.valueOf(10 + index * 8)
//					+ ",ExternalId06-10-2||1,4," + String.valueOf(index % 3)
//					+ ",50@25,10,2@75,10,2@95,10,2;ExternalId06,"
//					+ String.valueOf(10 + index * 9)
//					+ ",ExternalId06-10-2||2,5," + String.valueOf(index % 5)
//					+ ",50@25,10,2@75,10,2@95,10,2");
//			list.add("ExternalId07," + String.valueOf(10 + index * 8)
//					+ ",ExternalId07-10-3||1,4," + String.valueOf(index % 2)
//					+ ",50@25,10,3@75,10,3@95,10,3;ExternalId07,"
//					+ String.valueOf(10 + index * 9)
//					+ ",ExternalId07-10-3||2,5," + String.valueOf(index % 4)
//					+ ",50@25,10,3@75,10,3@95,10,3");
//			list.add("ExternalId08," + String.valueOf(10 + index * 8)
//					+ ",ExternalId08-10-4||1,4," + String.valueOf(index % 3)
//					+ ",50@25,10,4@75,10,4@95,10,4;ExternalId08,"
//					+ String.valueOf(10 + index * 9)
//					+ ",ExternalId08-10-4||2,5," + String.valueOf(index % 5)
//					+ ",50@25,10,4@75,10,4@95,10,4");
//			list.add("ExternalId09," + String.valueOf(10 + index * 8)
//					+ ",ExternalId09-10-1||1,4," + String.valueOf(index % 4)
//					+ ",50@25,10,1@75,10,1@95,10,1;ExternalId09,"
//					+ String.valueOf(10 + index * 9)
//					+ ",ExternalId09-10-1||2,5," + String.valueOf(index % 6)
//					+ ",50@25,10,1@75,10,1@95,10,1");
//			list.add("ExternalId10," + String.valueOf(10 + index * 8)
//					+ ",ExternalId10-10-2||1,4," + String.valueOf(index % 5)
//					+ ",50@25,10,2@75,10,2@95,10,2;ExternalId10,"
//					+ String.valueOf(10 + index * 9)
//					+ ",ExternalId10-10-2||2,5," + String.valueOf(index % 2)
//					+ ",50@25,10,2@75,10,2@95,10,2");
//		}
//		return list;
//	}
//
//	public List<String> prepareResultXml_TI(int size) {
//		List<String> list = Lists.newArrayList();
//
//		list.add("A001,7619,A001-10-A||1,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A001,5523,A001-10-A||2,332,0,5523@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A001,4380,A001-10-A||3,331,1,4380@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A001,2505,A001-10-A||4,332,1,2505@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A002,4800,A002-10-A||1,331,0,4800@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A002,3600,A002-10-A||2,332,0,3600@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A002,3000,A002-10-A||3,331,1,3000@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A002,2000,A002-10-A||4,332,1,2000@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		return list;
//	}
//
//	public List<String> prepareResultXml_TI_COM(int size) {
//		List<String> list = Lists.newArrayList();
//
//		list.add("A001,7619,A001-10-A||1,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A001,5523,A001-10-A||2,332,0,5523@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A001,4380,A001-10-A||3,331,0,4380@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A001,2505,A001-10-A||4,332,0,2505@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A002,4800,A002-10-A||1,331,1,4800@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A002,3600,A002-10-A||2,332,1,3600@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A002,3000,A002-10-A||3,331,1,3000@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A002,2000,A002-10-A||4,332,1,2000@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		return list;
//	}
//
//	public List<String> prepareResultXml_LI(int size) {
//		List<String> list = Lists.newArrayList();
//		list.add("LI-001,400,LI-001-1-A||1,3,0,400@400,1,1");
//		list.add("LI-001,350,LI-001-1-A||1,4,0,350@400,1,1");
//		list.add("LI-001,408,LI-001-1-A||1,323,1,408@400,1,1");
//		list.add("LI-001,312,LI-001-1-A||1,324,1,312@400,1,1");
//		list.add("LI-001,700,LI-001-1-A||2,3,0,700@400,1,1");
//		list.add("LI-001,350,LI-001-1-A||2,4,0,350@400,1,1");
//		list.add("LI-001,720,LI-001-1-A||2,323,1,720@400,1,1");
//		list.add("LI-001,312,LI-001-1-A||2,324,1,312@400,1,1");
//		return list;
//	}
//
//	public List<String> prepareResultXml_LI_MultiAxis(int size) {
//		List<String> list = Lists.newArrayList();
//		String[] externalIds = { "LI-001", "LI-001", "LI-001", "LI-001",
//				"LI-001", "LI-001", "LI-001", "LI-001", "LI-001", "LI-001" };
//		Integer[] fusionScores = { 400, 350, 24, 492, 10, 360, 380, 360, 20, 30 };
//		String[] consolidateKeys = { "LI-001-1-A", "LI-001-1-A", "LI-001-1-A",
//				"LI-001-1-A", "LI-001-1-C", "LI-001-1-C", "LI-001-1-B",
//				"LI-001-1-B", "LI-001-1-D", "LI-001-1-D" };
//		Integer[] eventIds = { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 };
//		Integer[] containerIds = { 3, 4, 323, 324, 3, 4, 3, 4, 3, 4 };
//		Integer[] inquiryRequestIndexs = { 0, 0, 1, 1, 0, 0, 0, 0, 0, 0 };
//		Integer[] compositScores = { 400, 350, 24, 492, 10, 360, 380, 360, 20,
//				30 };
//		Integer[] scores = { 400, 350, 20, 410, 10, 360, 380, 360, 20, 30 };
//		Integer[] positions = { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 };
//		Integer[] fingerAxiss = { 1, 1, 1, 1, 3, 3, 2, 2, 4, 4 };
//		for (int i = 0; i < 10; i++) {
//			list.add(externalIds[i] + "," + fusionScores[i] + ","
//					+ consolidateKeys[i] + "||" + eventIds[i] + ","
//					+ containerIds[i] + "," + inquiryRequestIndexs[i] + ","
//					+ compositScores[i] + "@" + scores[i] + "," + positions[i]
//					+ "," + fingerAxiss[i]);
//		}
//		return list;
//	}
//
//	public List<String> prepareResultXml_LI_MultiAxis_other(int size) {
//		List<String> list = Lists.newArrayList();
//		String[] externalIds = { "LI-001", "LI-001", "LI-001", "LI-001" };
//		Integer[] fusionScores = { 360, 408, 516, 400 };
//		String[] consolidateKeys = { "LI-001-1-A", "LI-001-1-A", "LI-001-1-A",
//				"LI-001-1-B" };
//		Integer[] eventIds = { 1, 1, 1, 1 };
//		Integer[] containerIds = { 4, 323, 324, 3 };
//		Integer[] inquiryRequestIndexs = { 0, 1, 1, 0 };
//		Integer[] compositScores = { 360, 408, 516, 400 };
//		Integer[] scores = { 360, 408, 516, 400 };
//		Integer[] positions = { 1, 1, 1, 1 };
//		Integer[] fingerAxiss = { 1, 1, 1, 2 };
//		for (int i = 0; i < 4; i++) {
//			list.add(externalIds[i] + "," + fusionScores[i] + ","
//					+ consolidateKeys[i] + "||" + eventIds[i] + ","
//					+ containerIds[i] + "," + inquiryRequestIndexs[i] + ","
//					+ compositScores[i] + "@" + scores[i] + "," + positions[i]
//					+ "," + fingerAxiss[i]);
//		}
//		return list;
//	}
//
//	public List<String> prepareResultXml_LIX(int size) {
//		List<String> list = Lists.newArrayList();
//		String[] externalIds = { "LIX-001", "LIX-001", "LIX-002" };
//		Integer[] fusionScores = { 808, 1420, 810 };
//		String[] consolidateKeys = { "LIX-001-1-A", "LIX-001-1-A",
//				"LIX-002-1-A" };
//		Integer[] eventIds = { 1, 2, 1 };
//		Integer[] containerIds = { 341, 341, 341 };
//		Integer[] inquiryRequestIndexs = { 0, 0, 0 };
//		Integer[] compositScores = { 808, 1420, 810 };
//		Integer[] scores = { 808, 1420, 810 };
//		Integer[] positions = { 1, 1, 1 };
//		Integer[] fingerAxiss = { 1, 1, 1 };
//		for (int i = 0; i < 3; i++) {
//			list.add(externalIds[i] + "," + fusionScores[i] + ","
//					+ consolidateKeys[i] + "||" + eventIds[i] + ","
//					+ containerIds[i] + "," + inquiryRequestIndexs[i] + ","
//					+ compositScores[i] + "@" + scores[i] + "," + positions[i]
//					+ "," + fingerAxiss[i]);
//		}
//		return list;
//	}
//
//	public List<String> prepareResultXml_TLI(int size) {
//		List<String> list = Lists.newArrayList();
//		String[] externalIds = { "TLI-001", "TLI-001", "TLI-001", "TLI-001",
//				"TLI-001", "TLI-001", "TLI-001", "TLI-001" };
//		Integer[] fusionScores = { 400, 350, 408, 312, 700, 350, 720, 312 };
//		String[] consolidateKeys = { "TLI-001-1-A", "TLI-001-1-A",
//				"TLI-001-1-A", "TLI-001-1-A", "TLI-001-1-A", "TLI-001-1-A",
//				"TLI-001-1-A", "TLI-001-1-A" };
//		Integer[] eventIds = { 1, 1, 1, 1, 1, 1, 1, 1 };
//		Integer[] containerIds = { 321, 321, 326, 326, 321, 321, 326, 326 };
//		Integer[] inquiryRequestIndexs = { 0, 1, 2, 3, 0, 1, 2, 3 };
//		Integer[] compositScores = { 400, 350, 408, 312, 700, 350, 720, 312 };
//		Integer[] scores = { 400, 350, 408, 312, 700, 350, 720, 312 };
//		Integer[] positions = { 1, 1, 1, 1, 1, 1, 1, 1 };
//		Integer[] fingerAxiss = { 1, 1, 1, 1, 1, 1, 1, 1 };
//		for (int i = 0; i < 8; i++) {
//			list.add(externalIds[i] + "," + fusionScores[i] + ","
//					+ consolidateKeys[i] + "||" + eventIds[i] + ","
//					+ containerIds[i] + "," + inquiryRequestIndexs[i] + ","
//					+ compositScores[i] + "@" + scores[i] + "," + positions[i]
//					+ "," + fingerAxiss[i]);
//		}
//		return list;
//	}
//
//	public List<String> prepareResultXml_LLI(int size) {
//		// TODO Auto-generated method stub
//		List<String> list = Lists.newArrayList();
//		String[] externalIds = { "LLI-001", "LLI-001", "LLI-001", "LLI-001" };
//		Integer[] fusionScores = { 400, 408, 700, 720 };
//		String[] consolidateKeys = { "LLI-001-1-A", "LLI-001-1-A",
//				"LLI-001-1-A", "LLI-001-1-A" };
//		Integer[] eventIds = { 1, 1, 1, 1 };
//		Integer[] containerIds = { 321, 326, 321, 326 };
//		Integer[] inquiryRequestIndexs = { 0, 1, 0, 1 };
//		Integer[] compositScores = { 400, 408, 700, 720 };
//		Integer[] scores = { 400, 408, 700, 720 };
//		Integer[] positions = { 1, 1, 1, 1 };
//		Integer[] fingerAxiss = { 1, 1, 1, 1 };
//		for (int i = 0; i < 4; i++) {
//			list.add(externalIds[i] + "," + fusionScores[i] + ","
//					+ consolidateKeys[i] + "||" + eventIds[i] + ","
//					+ containerIds[i] + "," + inquiryRequestIndexs[i] + ","
//					+ compositScores[i] + "@" + scores[i] + "," + positions[i]
//					+ "," + fingerAxiss[i]);
//		}
//		return list;
//	}
//
//	public List<String> prepareResultXml_LIP() {
//		// TODO Auto-generated method stub
//		List<String> list = Lists.newArrayList();
//		String[] externalIds = { "LIP-001", "LIP-002", "LIP-002", "LIP-003",
//				"LIP-003", "LIP-004", "LIP-004" };
//		Integer[] fusionScores = { 9999, 700, 600, 400, 340, 240, 20 };
//		String[] consolidateKeys = { "LIP-001-1-A", "LIP-002-1-A",
//				"LIP-002-1-A", "LIP-003-1-A", "LIP-003-1-A", "LIP-004-1-A",
//				"LIP-004-3-A" };
//		Integer[] eventIds = { 1, 1, 2, 1, 1, 1, 1 };
//		Integer[] containerIds = { 5, 5, 5, 5, 5, 5, 5 };
//		Integer[] inquiryRequestIndexs = { 0, 0, 0, 0, 0, 0, 0 };
//		Integer[] compositScores = { 9999, 700, 600, 400, 340, 240, 20 };
//		Integer[] scores = { 9999, 700, 600, 400, 340, 240, 20 };
//		Integer[] positions = { 1, 1, 1, 1, 1, 1, 3 };
//		Integer[] fingerAxiss = { 1, 1, 1, 1, 1, 1, 1 };
//		for (int i = 0; i < 7; i++) {
//			list.add(externalIds[i] + "," + fusionScores[i] + ","
//					+ consolidateKeys[i] + "||" + eventIds[i] + ","
//					+ containerIds[i] + "," + inquiryRequestIndexs[i] + ","
//					+ compositScores[i] + "@" + scores[i] + "," + positions[i]
//					+ "," + fingerAxiss[i]);
//		}
//		return list;
//	}
//
//	public List<String> prepareResultXml_TLIP() {
//		// TODO Auto-generated method stub
//		List<String> list = Lists.newArrayList();
//		String[] externalIds = { "TLIP-001", "TLIP-003", "TLIP-003",
//				"TLIP-004", "TLIP-004" };
//		Integer[] fusionScores = { 9999, 400, 400, 240, 20 };
//		String[] consolidateKeys = { "TLIP-001-1-A", "TLIP-003-1-A",
//				"TLIP-003-1-A", "TLIP-004-1-A", "TLIP-004-3-A" };
//		Integer[] eventIds = { 1, 1, 1, 1, 1 };
//		Integer[] containerIds = { 322, 322, 322, 322, 322 };
//		Integer[] inquiryRequestIndexs = { 0, 0, 0, 0, 0 };
//		Integer[] compositScores = { 9999, 400, 400, 240, 20 };
//		Integer[] scores = { 9999, 400, 400, 240, 20 };
//		Integer[] positions = { 1, 1, 1, 1, 3 };
//		Integer[] fingerAxiss = { 1, 1, 1, 1, 1 };
//		for (int i = 0; i < 5; i++) {
//			list.add(externalIds[i] + "," + fusionScores[i] + ","
//					+ consolidateKeys[i] + "||" + eventIds[i] + ","
//					+ containerIds[i] + "," + inquiryRequestIndexs[i] + ","
//					+ compositScores[i] + "@" + scores[i] + "," + positions[i]
//					+ "," + fingerAxiss[i]);
//		}
//		return list;
//	}
//
//	public List<String> prepareResultXml_LLIP() {
//		// TODO Auto-generated method stub
//		List<String> list = Lists.newArrayList();
//		String[] externalIds = { "LLIP-001", "LLIP-003", "LLIP-003" };
//		Integer[] fusionScores = { 9999, 400, 340 };
//		String[] consolidateKeys = { "LLIP-001-1-A", "LLIP-003-1-A",
//				"LLIP-003-1-A" };
//		Integer[] eventIds = { 1, 1, 1 };
//		Integer[] containerIds = { 322, 322, 322 };
//		Integer[] inquiryRequestIndexs = { 0, 0, 0 };
//		Integer[] compositScores = { 9999, 400, 340 };
//		Integer[] scores = { 9999, 400, 340 };
//		Integer[] positions = { 1, 1, 1 };
//		Integer[] fingerAxiss = { 1, 1, 1 };
//		for (int i = 0; i < 3; i++) {
//			list.add(externalIds[i] + "," + fusionScores[i] + ","
//					+ consolidateKeys[i] + "||" + eventIds[i] + ","
//					+ containerIds[i] + "," + inquiryRequestIndexs[i] + ","
//					+ compositScores[i] + "@" + scores[i] + "," + positions[i]
//					+ "," + fingerAxiss[i]);
//		}
//		return list;
//	}
//
//	public List<String> prepareResultXml_FI() {
//		// TODO Auto-generated method stub
//		List<String> list = Lists.newArrayList();
//		String[] externalIds = { "FI-001", "FI-002", "FI-002", "FI-003",
//				"FI-003" };
//		Integer[] fusionScores = { 9999, 700, 600, 400, 340 };
//		String[] consolidateKeys = { "FI-001-1-A", "FI-002-1-A", "FI-002-1-A",
//				"FI-003-1-A", "FI-003-1-A" };
//		Integer[] eventIds = { 1, 1, 1, 1, 1 };
//		Integer[] containerIds = { 335, 335, 335, 335, 335 };
//		Integer[] inquiryRequestIndexs = { 0, 0, 0, 0, 0 };
//		Integer[] compositScores = { 9999, 700, 600, 400, 340 };
//		Integer[] scores = { 9999, 700, 600, 400, 340 };
//		Integer[] positions = { 1, 1, 1, 1, 1 };
//		Integer[] fingerAxiss = { 1, 1, 1, 1, 1 };
//		for (int i = 0; i < 5; i++) {
//			list.add(externalIds[i] + "," + fusionScores[i] + ","
//					+ consolidateKeys[i] + "||" + eventIds[i] + ","
//					+ containerIds[i] + "," + inquiryRequestIndexs[i] + ","
//					+ compositScores[i] + "@" + scores[i] + "," + positions[i]
//					+ "," + fingerAxiss[i]);
//		}
//		return list;
//	}
//
//	public void cleanRegistration(JdbcTemplate jdbcTemplate) {
//		jdbcTemplate.update("delete from segments");
//		jdbcTemplate.update("delete from person_biometrics");
//		jdbcTemplate.update("delete from RESOURCE_UPDATE_COUNT");
//		jdbcTemplate.execute("commit");
//	}
//
//	public List<ContainerEntity> getContainerInfo(JdbcTemplate jdbcTemplate,
//			Integer containerId) {
//		List<ContainerEntity> containerList = Lists.newArrayList();
//		String sql = "SELECT * FROM CONTAINERS c ";
//		if (containerId != null) {
//			sql += "where c.CONTAINER_ID=? ";
//		}
//		sql += "order by c.CONTAINER_ID";
//		List<Map<String, Object>> list = jdbcTemplate.queryForList(sql,
//				new Object[] { containerId });
//		for (Map<String, Object> map : list) {
//			ContainerEntity container = new ContainerEntity();
//			container.setContainerId(Integer.valueOf(map.get("CONTAINER_ID")
//					.toString()));
//			container.setContainerName(map.get("CONTAINER_NAME").toString());
//			container.setFormatId(Integer.valueOf(map.get("FORMAT_ID")
//					.toString()));
//			container.setMaxSegmentSize(Long.valueOf(map.get(
//					"MAX_SEGMENT_SIZE").toString()));
//			// container.setMinMuNumForSlb(Integer.valueOf(map.get(
//			// "MIN_MU_NUM_FOR_SLB").toString()));
//			container.setMinRedundancy(Integer.valueOf(map
//					.get("MIN_REDUNDANCY").toString()));
//			container.setScopeId(Long.valueOf(map.get("SCOPE_ID").toString()));
//			containerList.add(container);
//		}
//		return containerList;
//	}
//
//	public List<SegmentEntity> getSegmentInfo(JdbcTemplate jdbcTemplate,
//			Integer containerId) {
//		List<SegmentEntity> containerList = Lists.newArrayList();
//		String sql = "select * from SEGMENTS ";
//		if (containerId != null) {
//			sql += "where CONTAINER_ID=? ";
//		}
//		sql += "order by SEGMENT_ID";
//		List<Map<String, Object>> list = jdbcTemplate.queryForList(sql,
//				new Object[] { containerId });
//		for (Map<String, Object> map : list) {
//			SegmentEntity segment = new SegmentEntity();
//			segment.setSegmentId(Integer.valueOf(map.get("SEGMENT_ID")
//					.toString()));
//			segment.setBinaryLengthCompacted(Long.valueOf(map.get(
//					"BINARY_LENGTH_COMPACTED").toString()));
//			segment.setBinaryLengthUncompacted(Long.valueOf(map.get(
//					"BINARY_LENGTH_UNCOMPACTED").toString()));
//			segment.setBioIdEnd(Long.valueOf(map.get("BIO_ID_END").toString()));
//			segment.setBioIdStart(Integer.valueOf(map.get("BIO_ID_START")
//					.toString()));
//			segment.setContainerId(Integer.valueOf(map.get("CONTAINER_ID")
//					.toString()));
//			segment.setRecordCount(Long.valueOf(map.get("RECORD_COUNT")
//					.toString()));
//			containerList.add(segment);
//		}
//		return containerList;
//	}
//
//	public List<String> prepareResultXml_oneRecordCompare() {
//		List<String> list = Lists.newArrayList();
//
//		// 7619 5523 4380 2505 7000 8000 5000 4000 2000
//		list.add("A001,7619,A001-10-A||1,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||2,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||3,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||4,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||5,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||6,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||7,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||8,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||9,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A001,5523,A001-10-A||10,332,0,5523@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||11,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||12,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||13,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||14,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||15,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||16,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||17,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||18,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||19,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A001,4380,A001-10-A||20,331,1,4380@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||21,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||22,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||23,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||24,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||25,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||26,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||27,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||28,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||29,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A001,2505,A001-10-A||30,332,1,2505@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||31,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||32,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||33,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||34,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||35,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||36,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||37,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||38,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||39,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A001,7000,A001-10-A||40,331,0,7000@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||41,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||42,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||43,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||44,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||45,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||46,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||47,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||48,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||49,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A001,5000,A001-10-A||50,332,0,5000@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||51,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||52,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||53,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||54,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||55,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||56,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||57,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||58,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||59,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A001,4000,A001-10-A||60,331,1,4000@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||61,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||62,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||63,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||64,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||65,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||66,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||67,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||68,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||69,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A001,2000,A001-10-A||70,332,1,2000@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||71,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||72,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||73,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||74,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||75,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||76,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||77,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||78,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||79,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A001,8000,A001-10-A||80,331,0,8000@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||81,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||82,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||83,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||84,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||85,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||86,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||87,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||88,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||89,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A001,8000,A001-10-A||90,332,0,8000@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||91,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||92,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||93,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||94,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||95,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||96,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||97,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||98,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||99,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//
//		// 4800 3600 3000 2000
//		list.add("A002,4800,A002-10-A||1,331,0,4800@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||2,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||3,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||4,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||5,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||6,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||7,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||8,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||9,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A002,3600,A002-10-A||10,332,0,3600@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||11,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||12,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||13,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||14,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||15,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||16,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||17,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||18,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||19,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A002,3000,A002-10-A||20,331,1,3000@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||21,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||22,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||23,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||24,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||25,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||26,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||27,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||28,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||29,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A002,2000,A002-10-A||30,332,1,2000@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||31,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||32,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||33,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||34,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||35,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||36,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||37,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||38,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||39,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A002,4800,A002-10-A||40,331,0,4800@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||41,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||42,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||43,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||44,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||45,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||46,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||47,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||48,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||49,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A002,3600,A002-10-A||50,332,0,3600@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||51,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||52,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||53,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||54,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||55,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||56,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||57,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||58,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||59,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A002,3000,A002-10-A||60,331,1,3000@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||61,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||62,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||63,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||64,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||65,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||66,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||67,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||68,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||69,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A002,2000,A002-10-A||70,332,1,2000@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||71,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||72,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||73,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||74,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||75,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||76,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||77,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||78,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||79,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//
//		list.add("A002,8000,A002-10-A||80,331,0,8000@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||81,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||82,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||83,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||84,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||85,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||86,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||87,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||88,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||89,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A002,8000,A002-10-A||90,332,0,8000@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||91,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||92,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||93,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||94,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||95,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||96,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||97,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||98,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||99,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//
//		// 4800 3600 3000 2000
//		list.add("A003,4800,A003-10-A||1,331,0,4800@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||2,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||3,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||4,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||5,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||6,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||7,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||9,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A003,3600,A003-10-A||10,332,0,3600@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||11,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||12,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||18,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||19,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A003,3000,A003-10-A||20,331,1,3000@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||21,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||22,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||23,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||27,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||28,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||29,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A003,2000,A003-10-A||30,332,1,2000@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||31,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||39,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A003,4800,A003-10-A||40,331,0,4800@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||41,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||42,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||43,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||44,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A003,3600,A003-10-A||50,332,0,3600@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||51,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||52,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||53,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A003,3000,A003-10-A||60,331,1,3000@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||61,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A003,2000,A003-10-A||70,332,1,2000@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A003,8000,A003-10-A||80,331,0,8000@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A003,8000,A003-10-A||90,332,0,8000@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//
//		// 4800 3600 3000 2000
//		list.add("A004,4800,A004-10-A||1,331,0,4800@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||2,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||3,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||4,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||5,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||6,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||7,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||8,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||9,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A004,3600,A004-10-A||10,332,0,3600@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||11,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||12,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||13,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||14,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||15,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||16,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||17,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||18,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||19,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A004,3000,A004-10-A||20,331,1,3000@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||21,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||22,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||23,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||24,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||25,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||26,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||27,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||28,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||29,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A004,2000,A004-10-A||30,332,1,2000@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||31,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||32,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||33,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||34,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||35,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||36,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||37,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||38,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||39,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A004,4800,A004-10-A||40,331,0,4800@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||41,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||42,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||43,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||44,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||45,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||46,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||47,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||48,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||49,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A004,3600,A004-10-A||50,332,0,3600@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||51,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||52,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||53,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||54,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||55,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||56,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||57,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||58,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||59,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A004,3000,A004-10-A||60,331,1,3000@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||61,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||62,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||63,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||64,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||65,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||66,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||67,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||68,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||69,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A004,2000,A004-10-A||70,332,1,2000@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||71,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||72,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||73,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||74,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||75,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||76,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||77,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||78,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||79,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//
//		list.add("A004,8000,A004-10-A||80,331,0,8000@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||81,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||82,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||83,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||84,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||85,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||86,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||87,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||88,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||89,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A004,8000,A004-10-A||90,332,0,8000@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||91,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||92,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||93,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||94,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||95,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||96,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||97,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||98,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||99,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//
//		// 4800 3600 3000 2000
//		list.add("A005,4800,A005-10-A||1,331,0,4800@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||2,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||3,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||4,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||5,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||6,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||7,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||8,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||9,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A005,3600,A005-10-A||10,332,0,3600@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||11,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||12,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||13,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||14,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||15,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||16,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||17,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||18,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||19,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A005,3000,A005-10-A||20,331,1,3000@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||21,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||22,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||23,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||24,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||25,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||26,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||27,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||28,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||29,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A005,2000,A005-10-A||30,332,1,2000@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||31,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||32,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||33,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||34,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||35,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||36,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||37,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||38,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||39,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A005,4800,A005-10-A||40,331,0,4800@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||41,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||42,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||43,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||44,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||45,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||46,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||47,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||48,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||49,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A005,3600,A005-10-A||50,332,0,3600@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||51,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||52,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||53,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||54,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||55,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||56,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||57,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||58,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||59,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A005,3000,A005-10-A||60,331,1,3000@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||61,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||62,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||63,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||64,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||65,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||66,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||67,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||68,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||69,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A005,2000,A005-10-A||70,332,1,2000@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||71,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||72,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||73,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||74,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||75,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||76,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||77,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||78,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||79,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//
//		list.add("A005,8000,A005-10-A||80,331,0,8000@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||81,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||82,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||83,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||84,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||85,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||86,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||87,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||88,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||89,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A005,8000,A005-10-A||90,332,0,8000@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||91,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||92,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||93,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||94,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||95,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||96,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||97,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||98,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||99,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//
//		// 4800 3600 3000 2000
//		list.add("A006,4800,A006-10-A||1,331,0,4800@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||2,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||3,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||4,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||5,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||6,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||7,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||8,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||9,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A006,3600,A006-10-A||10,332,0,3600@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||11,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||12,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||13,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||14,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||15,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||16,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||17,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||18,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||19,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A006,3000,A006-10-A||20,331,1,3000@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||21,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||22,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||23,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||24,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||25,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||26,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||27,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||28,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||29,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A006,2000,A006-10-A||30,332,1,2000@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||31,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||32,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||33,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||34,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||35,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||36,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||37,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||38,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||39,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A006,4800,A006-10-A||40,331,0,4800@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||41,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||42,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||43,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||44,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||45,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||46,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||47,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||48,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||49,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A006,3600,A006-10-A||50,332,0,3600@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||51,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||52,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||53,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||54,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||55,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||56,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||57,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||58,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||59,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A006,3000,A006-10-A||60,331,1,3000@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||61,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||62,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||63,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||64,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||65,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||66,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||67,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||68,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||69,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A006,2000,A006-10-A||70,332,1,2000@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||71,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||72,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||73,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||74,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||75,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||76,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||77,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||78,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||79,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//
//		list.add("A006,8000,A006-10-A||80,331,0,8000@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||81,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||82,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||83,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||84,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||85,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||86,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||87,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||88,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||89,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A006,8000,A006-10-A||90,332,0,8000@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||91,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||92,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||93,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||94,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||95,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||96,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||97,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||98,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||99,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//
//		// 4800 3600 3000 2000
//		list.add("A007,4800,A007-10-A||1,331,0,4800@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||2,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||3,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//
//				+ "||8,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||9,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A007,3600,A007-10-A||10,332,0,3600@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||11,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||12,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//
//				+ "||19,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A007,3000,A007-10-A||20,331,1,3000@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||21,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||22,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//
//				+ "||27,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||28,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||29,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A007,2000,A007-10-A||30,332,1,2000@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||31,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||32,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||33,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//
//				+ "||38,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||39,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A007,4800,A007-10-A||40,331,0,4800@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||41,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||42,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||43,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||44,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//
//				+ "||47,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||48,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||49,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A007,3600,A007-10-A||50,332,0,3600@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||51,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||52,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||53,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//
//				+ "||59,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A007,3000,A007-10-A||60,331,1,3000@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||61,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||62,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||63,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||64,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||68,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||69,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A007,2000,A007-10-A||70,332,1,2000@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||71,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||72,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||77,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||78,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||79,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//
//		list.add("A007,8000,A007-10-A||80,331,0,8000@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||81,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||82,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||83,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||84,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||85,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||86,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||87,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||88,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||89,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A007,8000,A007-10-A||90,332,0,8000@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||91,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||92,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//
//				+ "||97,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||98,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||99,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		// 4800 3600 3000 2000
//		list.add("A008,4800,A008-10-A||1,331,0,4800@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||2,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||3,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//
//				+ "||6,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||7,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||8,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||9,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A008,3600,A008-10-A||10,332,0,3600@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A008,3000,A008-10-A||20,331,1,3000@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A008,2000,A008-10-A||30,332,1,2000@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||31,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A008,4800,A008-10-A||40,331,0,4800@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||41,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||42,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||43,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//
//				+ "||46,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||47,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||48,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||49,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A008,3600,A008-10-A||50,332,0,3600@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||51,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||52,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//
//				+ "||58,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||59,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A008,3000,A008-10-A||60,331,1,3000@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||61,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||62,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||63,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//
//				+ "||67,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||68,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||69,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A008,2000,A008-10-A||70,332,1,2000@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||71,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||72,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||73,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//
//				+ "||77,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||78,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||79,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//
//		list.add("A008,8000,A008-10-A||80,331,0,8000@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||81,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||82,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//
//				+ "||87,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||88,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||89,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//		list.add("A008,8000,A008-10-A||90,332,0,8000@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||91,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//
//				+ "||97,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||98,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1"
//				+ "||99,331,0,7619@145,10,1@437,2,1@680,3,1@680,3,1@1747,4,1@508,5,1@271,6,1@0,7,1@249,8,1@2143,9,1@172,10,1");
//
//		return list;
//	}
//}
