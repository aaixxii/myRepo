package jp.co.nec.aim.mm.dao;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class PersonBiometricDaoTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testFindSegment() {
		fail("Not yet implemented");
	}

	@Test
	public void testDelBioByExternalId() {
		fail("Not yet implemented");
	}

}
