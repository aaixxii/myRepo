//package jp.co.nec.aim.mm.common;
//
//import java.util.List;
//
//import jp.co.nec.aim.message.proto.AIMEnumTypes.ComponentType;
//import jp.co.nec.aim.message.proto.AIMEnumTypes.SegmentStateType;
//import jp.co.nec.aim.message.proto.AIMMessages.PBComponentInfo;
//import jp.co.nec.aim.message.proto.AIMMessages.PBCorruptTempalte;
//import jp.co.nec.aim.message.proto.AIMMessages.PBInquiryCandidateInternal;
//import jp.co.nec.aim.message.proto.AIMMessages.PBInquiryJobInfoInternal;
//import jp.co.nec.aim.message.proto.AIMMessages.PBInquiryJobResultInternal;
//import jp.co.nec.aim.message.proto.AIMMessages.PBMapInquiryJobResult;
//import jp.co.nec.aim.message.proto.AIMMessages.PBResourceInfo;
//import jp.co.nec.aim.message.proto.AIMMessages.PBSegmentInfo;
//import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerAxisType;
//import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerSetType;
//import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
//import jp.co.nec.aim.message.proto.InquiryPayloads.PBFlexibleScore;
//import jp.co.nec.aim.message.proto.InquiryPayloads.PBFlexibleScore.PBFlexibleScoreIris;
//import jp.co.nec.aim.message.proto.InquiryPayloads.PBFlexibleScore.PBFlexibleScoreLFML;
//import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryCandidateIndividualScore;
//import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryCandidateTemplate;
//import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryFusionWeight;
//import jp.co.nec.aim.mm.util.PBStateUtil;
//
//import org.apache.commons.lang3.StringUtils;
//import org.mortbay.log.Log;
//
//import com.google.common.collect.Lists;
//
//public class ProtobufHelper {
//
//	public static PBMapInquiryJobResult MapInquiryJobResult(long topLevelJobId,
//			long planId, int msgSequence, String value, long matchCount,
//			long readCount) {
//		int requestIndex = 7;
//		int containerId = 1;
//		int messageSequence = msgSequence;
//		long jobTimeout = 10;
//		int internalMaxCandidates = 10;
//		int mrId = 10;
//
//		PBMapInquiryJobResult.Builder builder = PBMapInquiryJobResult
//				.newBuilder();
//		builder.setMrId(mrId);
//		builder.setPlanId(planId);
//		PBInquiryJobInfoInternal.Builder jobInfo = builder.getJobInfoBuilder();
//		jobInfo.setTopLevelJobId(topLevelJobId);
//		jobInfo.setRequestIndex(requestIndex);
//		jobInfo.setContainerId(containerId);
//		jobInfo.setMessageSequence(messageSequence);
//		jobInfo.setJobTimeout(jobTimeout);
//		jobInfo.setInternalMaxCandidates(internalMaxCandidates);
//		jobInfo.setMuJobPopTime(7);
//
//		PBInquiryJobResultInternal result = InquiryJobResultInternal(
//				topLevelJobId, value, matchCount, readCount);
//		builder.setResult(result);
//		return builder.build();
//	}
//
//	// int inquiryrequestIndex, int fusionScore, Integer fingNo, String Axis
//	// value:externalId,fusionScore,consolidateKey;
//	// {eventId,containerId,inquiryRequestIndex,compositScore,[score,fingerNumber,axis]};
//	public static PBInquiryJobResultInternal InquiryJobResultInternal(
//			Long topLevelJobId, String value, long matchCount, long readCount) {
//
//		PBInquiryJobResultInternal.Builder result = PBInquiryJobResultInternal
//				.newBuilder();
//
//		if (null != topLevelJobId) {
//			result.setJobId(topLevelJobId);
//		}
//
//		result.setServiceState(PBStateUtil.creatSuccessState());
//
//		result.getStatisticsBuilder().getAmrBuilder().setMatchCount(matchCount)
//				.setReadCount(readCount);
//
//		if (StringUtils.isBlank(value)) {
//			return result.build();
//		}
//
//		String[] db = StringUtils.split(value, ";");
//		for (String itemValue : db) {
//			PBInquiryCandidateInternal.Builder candidate = PBInquiryCandidateInternal
//					.newBuilder();
//
//			String[] candidates = StringUtils.split(itemValue, "||");
//			if (StringUtils.isBlank(candidates[0])) {
//				result.getCandidateListBuilder().addCandidate(candidate);
//				return result.build();
//			}
//
//			String[] candidatesItems = StringUtils.split(candidates[0], ",");
//			if (candidatesItems.length != 3) {
//				Log.warn("candidates: externalId,fusionScore,consolidateKey set Error!!");
//				result.getCandidateListBuilder().addCandidate(candidate);
//				return result.build();
//			}
//			candidate.setExternalId(candidatesItems[0])
//					.setFusionScore(Integer.valueOf(candidatesItems[1]))
//					.setConsolidateKey(candidatesItems[2]);
//
//			if (candidates.length == 1) {
//				result.getCandidateListBuilder().addCandidate(candidate);
//				return result.build();
//			}
//
//			for (int idx = 1; idx < candidates.length; idx++) {
//				String[] templetes = StringUtils.split(candidates[idx], "*");
//				if (templetes.length == 0) {
//					result.getCandidateListBuilder().addCandidate(candidate);
//					return result.build();
//				}
//
//				for (String templete : templetes) {
//					String[] templeteItems = StringUtils.split(templete, "@");
//					String[] itemTempletes = StringUtils.split(
//							templeteItems[0], ",");
//					if (itemTempletes.length != 4) {
//						Log.warn("candidateTemplate: eventId,containerId,inquiryRequestIndex,compositScore set Error!!");
//						result.getCandidateListBuilder()
//								.addCandidate(candidate);
//						return result.build();
//					}
//
//					PBInquiryCandidateTemplate.Builder candidateTemplate = PBInquiryCandidateTemplate
//							.newBuilder();
//					candidateTemplate.setEventId(Integer
//							.valueOf(itemTempletes[0]));
//					candidateTemplate.setContainerId(Integer
//							.valueOf(itemTempletes[1]));
//					candidateTemplate.setInquiryRequestIndex(Integer
//							.valueOf(itemTempletes[2]));
//					candidateTemplate.setCompositScore(Integer
//							.valueOf(itemTempletes[3]));
//
//					for (int index = 1; index < templeteItems.length; index++) {
//						String[] individualScores = StringUtils.split(
//								templeteItems[index], ",");
//						if (individualScores.length == 0) {
//							candidate.addCandidateTemplate(candidateTemplate);
//							result.getCandidateListBuilder().addCandidate(
//									candidate);
//							return result.build();
//						}
//
//						PBInquiryCandidateIndividualScore.Builder individualScore = PBInquiryCandidateIndividualScore
//								.newBuilder();
//						individualScore.setScore(Integer
//								.valueOf(individualScores[0]));
//						individualScore.setPosition(Integer
//								.valueOf(individualScores[1]));
//						individualScore.setFingerAxis(FingerAxisType
//								.valueOf(Integer.valueOf(individualScores[2])));
//
//						if (individualScores.length > 3) {
//							String[] templeteFusionWights = StringUtils
//									.substringsBetween(individualScores[3],
//											"{", "}");
//							if (templeteFusionWights.length == 1) {
//								PBInquiryFusionWeight.Builder fusionWeight = individualScore
//										.getFusionWeightBuilder();
//								String[] fusionWeight1 = StringUtils.split(
//										templeteFusionWights[0], ":");
//								if (fusionWeight1.length != 0) {
//									fusionWeight
//											.setInquirySet(FingerSetType.valueOf(Integer
//													.parseInt(fusionWeight1[0])));
//									fusionWeight.setWeight(Integer
//											.parseInt(fusionWeight1[1]));
//								}
//
//							}
//
//							String[] templeteFlexibleScores = StringUtils
//									.substringsBetween(individualScores[3],
//											"[", "]");
//
//							if (null == templeteFlexibleScores) {
//								;
//							} else {
//								PBFlexibleScore.Builder flexbleScore = individualScore
//										.getFlexibleScoreBuilder();
//								for (int idx_ = 0; idx_ < templeteFlexibleScores.length; idx_++) {
//									String[] flexScore = StringUtils.split(
//											templeteFlexibleScores[idx_], ":");
//									PBFlexibleScoreLFML.Builder lfml = PBFlexibleScoreLFML
//											.newBuilder();
//									lfml.setSearchIndex(Integer
//											.parseInt(flexScore[0]));
//									lfml.setFileIndex(Integer
//											.parseInt(flexScore[1]));
//									lfml.setRawScore(Integer
//											.parseInt(flexScore[2]));
//									flexbleScore.addLfml(lfml);
//								}
//							}
//
//							String[] irIsStr = StringUtils.substringsBetween(
//									individualScores[3], "(", ")");
//
//							if (null == irIsStr) {
//								;
//							} else {
//								PBFlexibleScore.Builder flexbleScore = individualScore
//										.getFlexibleScoreBuilder();
//								for (int idx_ = 0; idx_ < templeteFlexibleScores.length; idx_++) {
//									String[] irisItems = StringUtils.split(
//											irIsStr[idx_], ":");
//									PBFlexibleScoreIris.Builder iris = PBFlexibleScoreIris
//											.newBuilder();
//									iris.setFilePosition(Integer
//											.parseInt(irisItems[0]));
//									iris.setScore(Integer
//											.parseInt(irisItems[1]));
//									flexbleScore.addIris(iris);
//								}
//							}
//						}
//						candidateTemplate.addIndividualScore(individualScore);
//
//					}
//					candidate.addCandidateTemplate(candidateTemplate);
//
//				}
//			}
//			result.getCandidateListBuilder().addCandidate(candidate);
//		}
//		return result.build();
//	}
//
//	public static PBMapInquiryJobResult MapInquiryJobResultFailure(
//			long topLevelJobId, long planId, ServiceStateType stateType,
//			String description) {
//		int requestIndex = 7;
//		int containerId = 1;
//		long jobTimeout = 10;
//		int internalMaxCandidates = 10;
//		int mrId = 10;
//
//		PBMapInquiryJobResult.Builder builder = PBMapInquiryJobResult
//				.newBuilder();
//		builder.setMrId(mrId);
//		builder.setPlanId(planId);
//		PBInquiryJobInfoInternal.Builder jobInfo = builder.getJobInfoBuilder();
//		jobInfo.setTopLevelJobId(topLevelJobId);
//		jobInfo.setRequestIndex(requestIndex);
//		jobInfo.setContainerId(containerId);
//		jobInfo.setMessageSequence(0);
//		jobInfo.setJobTimeout(jobTimeout);
//		jobInfo.setInternalMaxCandidates(internalMaxCandidates);
//		jobInfo.setMuJobPopTime(7);
//
//		PBInquiryJobResultInternal result = InquiryJobResultInternalFailure(
//				topLevelJobId, stateType, description);
//		builder.setResult(result);
//		return builder.build();
//	}
//
//	public static PBInquiryJobResultInternal InquiryJobResultInternalFailure(
//			Long topLevelJobId, ServiceStateType stateType, String description) {
//
//		PBInquiryJobResultInternal.Builder result = PBInquiryJobResultInternal
//				.newBuilder();
//
//		if (null != topLevelJobId) {
//			result.setJobId(topLevelJobId);
//		}
//
//		result.setServiceState(PBStateUtil.creatErrorState(stateType, "ABC",
//				description, "TIME"));
//		return result.build();
//	}
//
//	public static PBComponentInfo PBComponentInfo(ComponentType type,
//			String version, String uniqueId, String contactUrl,
//			String resouceInfo) {
//		PBComponentInfo.Builder componentInfoBuilder = PBComponentInfo
//				.newBuilder();
//
//		componentInfoBuilder.setComponent(type);
//		componentInfoBuilder.setVersion(version);
//		componentInfoBuilder.setUniqueId(uniqueId);
//		componentInfoBuilder.setContactUrl(contactUrl);
//
//		if (StringUtils.isBlank(resouceInfo)) {
//			return componentInfoBuilder.build();
//		}
//
//		String[] resourceInfo = StringUtils.split(resouceInfo, "-");
//		PBResourceInfo.Builder resourceInfoBuilder = componentInfoBuilder
//				.getResourceInfoBuilder();
//		String abilityInfo = resourceInfo[0];
//		if (!StringUtils.isBlank(abilityInfo)) {
//			String[] infos = StringUtils.split(abilityInfo, ",");
//			resourceInfoBuilder.getAbilityInfoBuilder()
//					.setPrimarySize(Integer.parseInt(infos[0]))
//					.setSecondarySize(Integer.parseInt(infos[1]));
//
//			if (!StringUtils.isBlank(infos[2])) {
//				resourceInfoBuilder.getAbilityInfoBuilder().setNumOfMatchers(
//						Integer.parseInt(infos[2]));
//			}
//			if (!StringUtils.isBlank(infos[3])) {
//				resourceInfoBuilder.getAbilityInfoBuilder().setNumOfExtractors(
//						Integer.parseInt(infos[3]));
//			}
//			if (infos.length >= 4 && !StringUtils.isBlank(infos[4])) {
//				resourceInfoBuilder.getAbilityInfoBuilder()
//						.setPerformanceFactor(Integer.parseInt(infos[4]));
//			}
//		}
//		if (resourceInfo.length > 1) {
//
//			String[] infos = StringUtils.split(resourceInfo[1], "/");
//
//			if (infos.length > 1 && !StringUtils.isBlank(infos[1])) {
//				resourceInfoBuilder.setSegmentMapChanged(false);
//				if (infos[1].equals("0")) {
//					resourceInfoBuilder.setSegmentMapChanged(true);
//				}
//
//			}
//			String[] segmentInfos = StringUtils.split(infos[0], "@");
//			if (!StringUtils.isBlank(segmentInfos[0])) {
//				StringUtils.split(resourceInfo[1], "/");
//				List<PBSegmentInfo> pbSegInfos = Lists.newArrayList();
//				for (String segmentInfo : segmentInfos) {
//					String[] segInfos = StringUtils.split(segmentInfo, "||");
//					PBSegmentInfo.Builder segBuilder = PBSegmentInfo
//							.newBuilder();
//					if (!StringUtils.isBlank(segInfos[0])) {
//						String[] segInfo = StringUtils.split(segInfos[0], ",");
//
//						segBuilder.setId(Integer.parseInt(segInfo[0]));
//						if (segInfo[1].equals("0")) {
//							segBuilder
//									.setState(SegmentStateType.SEGMENT_STATE_MEMORY);
//						}
//						if (segInfo[1].equals("1")) {
//							segBuilder
//									.setState(SegmentStateType.SEGMENT_STATE_DISK);
//						}
//						if (segInfo[1].equals("2")) {
//							segBuilder
//									.setState(SegmentStateType.SEGMENT_STATE_ERROR);
//						}
//						segBuilder.setVersion(Long.parseLong(segInfo[2]));
//						segBuilder.setQueuedVersion(Long.parseLong(segInfo[3]));
//					}
//					if (!StringUtils.isBlank(segInfos[1])) {
//						String[] ids = StringUtils.split(segInfos[1], ",");
//						PBCorruptTempalte.Builder builder = PBCorruptTempalte
//								.newBuilder();
//						for (int i = 0; i < ids.length; i++) {
//							builder.addId(Long.parseLong(ids[i]));
//						}
//						segBuilder.setCorruptTemplates(builder);
//					}
//					pbSegInfos.add(segBuilder.build());
//				}
//				resourceInfoBuilder.addAllSegmentInfo(pbSegInfos);
//			}
//		}
//
//		return componentInfoBuilder.build();
//	}
//
//	public static PBMapInquiryJobResult MapInquiryJobResultFailure01(
//			long topLevelJobId, long planId, ServiceStateType stateType) {
//		int requestIndex = 7;
//		int containerId = 1;
//		long jobTimeout = 10;
//		int internalMaxCandidates = 10;
//		int mrId = 10;
//
//		PBMapInquiryJobResult.Builder builder = PBMapInquiryJobResult
//				.newBuilder();
//		builder.setMrId(mrId);
//		builder.setPlanId(planId);
//		PBInquiryJobInfoInternal.Builder jobInfo = builder.getJobInfoBuilder();
//		jobInfo.setTopLevelJobId(topLevelJobId);
//		jobInfo.setRequestIndex(requestIndex);
//		jobInfo.setContainerId(containerId);
//		jobInfo.setMessageSequence(0);
//		jobInfo.setJobTimeout(jobTimeout);
//		jobInfo.setInternalMaxCandidates(internalMaxCandidates);
//		jobInfo.setMuJobPopTime(7);
//
//		PBInquiryJobResultInternal.Builder result = builder.getResultBuilder();
//
//		result.getServiceStateBuilder().setState(stateType);
//		return builder.build();
//	}
//
//	public static PBMapInquiryJobResult MapInquiryJobResultFailure02(
//			long topLevelJobId, long planId, ServiceStateType stateType,
//			String description) {
//		int requestIndex = 7;
//		int containerId = 1;
//		long jobTimeout = 10;
//		int internalMaxCandidates = 10;
//		int mrId = 10;
//
//		PBMapInquiryJobResult.Builder builder = PBMapInquiryJobResult
//				.newBuilder();
//		builder.setMrId(mrId);
//		builder.setPlanId(planId);
//		PBInquiryJobInfoInternal.Builder jobInfo = builder.getJobInfoBuilder();
//		jobInfo.setTopLevelJobId(topLevelJobId);
//		jobInfo.setRequestIndex(requestIndex);
//		jobInfo.setContainerId(containerId);
//		jobInfo.setMessageSequence(0);
//		jobInfo.setJobTimeout(jobTimeout);
//		jobInfo.setInternalMaxCandidates(internalMaxCandidates);
//		jobInfo.setMuJobPopTime(7);
//
//		PBInquiryJobResultInternal result = InquiryJobResultInternalFailure(
//				topLevelJobId, stateType, description);
//		builder.setResult(result);
//		builder.getErrorBuilder().setMuId(10).setSegmentId(1);
//		return builder.build();
//	}
//
//}
