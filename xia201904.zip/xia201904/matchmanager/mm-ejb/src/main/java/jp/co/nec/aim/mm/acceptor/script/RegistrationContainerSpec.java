package jp.co.nec.aim.mm.acceptor.script;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "containerSpec", propOrder = { "scope", "containerId" })
public class RegistrationContainerSpec {
	@XmlElement(required = true)
	protected Integer containerId;
	@XmlElement(required = true)
	protected Integer scope;

	/**
	 * Gets the value of the containerId property.
	 * 
	 * @return possible object is {@link Integer }
	 * 
	 */
	public Integer getContainerId() {
		return containerId;
	}

	/**
	 * Sets the value of the containerId property.
	 * 
	 * @param value
	 *            allowed object is {@link Integer }
	 * 
	 */
	public void setContainerId(Integer value) {
		this.containerId = value;
	}

	/**
	 * Gets the value of the afisSpec property.
	 * 
	 * @return possible object is {@link RegistrationContainerSpec.AfisSpec }
	 * 
	 */
	public Integer getScope() {
		return scope;
	}

	/**
	 * Sets the value of the Scope.
	 * 
	 * @param value
	 *            allowed object is
	 * 
	 */
	public void setScope(Integer value) {
		this.scope = value;
	}
}
