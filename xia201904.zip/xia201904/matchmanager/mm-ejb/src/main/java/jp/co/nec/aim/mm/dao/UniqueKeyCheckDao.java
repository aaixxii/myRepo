package jp.co.nec.aim.mm.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.aim.mm.entities.BatchJobInfoEntity;
import jp.co.nec.aim.mm.entities.PersonBiometricEntity;

public class UniqueKeyCheckDao {

	/** log instance **/
	private static final Logger log = LoggerFactory.getLogger(UniqueKeyCheckDao.class);
	private EntityManager em;

	public UniqueKeyCheckDao(EntityManager em) {
		this.em = em;
	}
	
	@SuppressWarnings("unchecked")
	public  List<BatchJobInfoEntity> checkBatchJobId(long batchJobId, String batchType) {
		try {
			Query q = em.createNamedQuery("NQ::checkBatchJobId");
			q.setParameter("batchJobId", batchJobId);
			q.setParameter("batchType", batchType);
			return (List<BatchJobInfoEntity>) q.getResultList();
		} catch (Exception e) {
			return null;
		}

	}
	
	@SuppressWarnings("unchecked")
	public  List<BatchJobInfoEntity> checkRequestId(String reqeustId, String batchType) {
		try {
			Query q = em.createNamedQuery("NQ::checkRequestId");
			q.setParameter("reqId", reqeustId);
			q.setParameter("batchType", batchType);
			return (List<BatchJobInfoEntity>) q.getResultList();
		} catch (Exception e) {
			return null;
		}
	}
	
	@SuppressWarnings("unchecked")
	public  List<PersonBiometricEntity> checkEnrollmentID(String enrollId) {
		Query q = em.createNamedQuery("NQ::checkEnrollmentID");
		q.setParameter("enrollId", enrollId);
		List<PersonBiometricEntity> results = q.getResultList();
		return results;
	}
	
	
	
	

	
}
