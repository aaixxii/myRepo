package jp.co.nec.aim.mm.identify.planner;

public class JobPlan {
	private Integer containerId;
	private String muPlanString;

	// imuId,segmentId:version,segmentId:version/muId,segmentId:vesion
	public Integer getContainerId() {
		return containerId;
	}

	public void setContainerId(Integer containerId) {
		this.containerId = containerId;
	}

	public String getMuPlanString() {
		return muPlanString;
	}

	public void setMuPlanString(String muPlanString) {
		this.muPlanString = muPlanString;
	}

}
