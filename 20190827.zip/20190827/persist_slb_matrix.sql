CREATE DEFINER=`aimuser`@`%` PROCEDURE `persist_slb_matrix`(
 in  p_slb_matrix   varchar(2048),
 in  p_container_id   int,
 in   p_component_type  int
)
  MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN
    DECLARE t_error INTEGER DEFAULT 0;  
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1;   
      DROP TEMPORARY TABLE IF EXISTS list_tmp;
    create temporary table list_tmp(id VARCHAR(32));

END