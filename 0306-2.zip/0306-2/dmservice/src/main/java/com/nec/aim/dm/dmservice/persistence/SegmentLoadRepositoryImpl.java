package com.nec.aim.dm.dmservice.persistence;

import com.nec.aim.dm.dmservice.entity.SegmentLoading;

public class SegmentLoadRepositoryImpl implements SegmentLoadRepository{

	@Override
	public void updateSegmentLoad(SegmentLoading segLoad) {
		// TODO Auto-generated method stub
		
	}

}
