package com.nec.aim.dm.dmservice.entity;

public class DmConfigInfo {
	int redundancy;
	int maxSegmentSize;
	public int getRedundancy() {
		return redundancy;
	}
	public void setRedundancy(int redundancy) {
		this.redundancy = redundancy;
	}
	public int getMaxSegmentSize() {
		return maxSegmentSize;
	}
	public void setMaxSegmentSize(int maxSegmentSize) {
		this.maxSegmentSize = maxSegmentSize;
	}
	

}
