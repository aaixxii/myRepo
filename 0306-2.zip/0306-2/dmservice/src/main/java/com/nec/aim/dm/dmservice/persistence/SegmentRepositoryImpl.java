package com.nec.aim.dm.dmservice.persistence;

import com.nec.aim.dm.dmservice.entity.SegmentInfo;

public class SegmentRepositoryImpl implements SegmentRepository {

	@Override
	public void updateSegment(SegmentInfo segInfo) {
		// TODO Auto-generated method stub
		
	}

}
