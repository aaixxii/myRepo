package com.nec.aim.dm.dmservice.persistence;

import java.sql.SQLException;

import com.nec.aim.dm.dmservice.entity.SegmentLoading;

public interface SegmentLoadRepository {
	public void updateSegmentLoad(SegmentLoading segLoad)  throws SQLException;

}
