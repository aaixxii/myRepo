/* charting.js */
var DOT_TYPE = "dot";
var RECT_TYPE = "rect";
var PROBE = "probe";
var TARGET = "target";

var canvasi;
var context;
var canvas_rect;

var win_width;
var win_height;
var first_start_x;
var first_start_y;
var second_start_x;
var second_start_y;

var radius = 10;
var strokelineWith = 1;

var hasFirstImage = false;
var hasSecondImage = false;
var xmlOrTxtFileInUsing = false;

var minutiaPairList = []; //gobal
var verifyJobResult; //gobal

function Point(x, y) {
  this.x = x;
  this.y = y;
}

function VerifyJobResult(jobId, candidateResultList) {
  this.jobId = jobId;
  this.candidateResultList = candidateResultList;
}

function CandidateResultList(candidateId, modalScoreList) {
  this.candidateId = candidateId;
  this.modalScoreList = modalScoreList;
}

function ModalScoreList(modal, rawScoreList) {
  this.modal = modal;
  this.rawScoreList = rawScoreList;
}

function RawScoreList(algorithmType, probePosition, targetPosition, matchedDataList) {
  this.algorithmType = algorithmType;
  this.probePosition = probePosition;
  this.targetPosition = targetPosition;
  this.matchedDataList = matchedDataList;
}

function MatchedData(similitude, pn, px, py, tn, tx, ty) {
  this.similitude = similitude;
  this.pn = pn;
  this.px = px;
  this.py = py;
  this.tn = tn;
  this.tx = tx;
  this.ty = ty;
}

window.onload = function () {
  //window.addEventListener('resize', resizeCanvas, false);
  canvasi = document.getElementById("canvas_i");
  context = canvasi.getContext("2d");
  canvasi.addEventListener('click', onCanvasClick, false);
  canvas_rect = canvasi.getBoundingClientRect();
  calculateSize();
  //canvas.addEventListener('mouseover', onCanvasClick, false);
  //canvas.addEventListener('mouseout', onMouseout, false);
  //canvas.addEventListener('mousemove', onMousemove, false); 
  $("#imageFile").change(function (e) {
    if (!this.files.length) {
      alert('File is not selected.');
      return;
    }
    var file = this.files[0];
    if (!hasFirstImage) {
      readImage1(file, e);
      hasFirstImage = true;
    } else if (!hasSecondImage) {
      readImage2(file, e);
      hasSecondImage = true;
    }
  });

  $("#xmlFile").change(function (e) {
    // if (xmlOrTxtFileInUsing) {
    //   alert("There are minutia file in using!!");
    //   return;
    // }
    var fileToLoad = e.target.files[0];
    var fileName = fileToLoad.name;
    if (fileName.toLowerCase().endsWith("xml")) {
      readXml(this.files, e);
    } else if (fileName.toLowerCase().endsWith("txt")) {
      readMinutia(e);
    }
  });

  $('#mapping').click(function (e) {
    test();
    mapping(e);
    //allMapingWithDot();
  });

  $('#onebyone').click(function (e) {
    test();
    drawDotWithNum();
  });

  $('#clear').click(function (e) {
    clearAll();
  });

}; //end windows.onload

function readImage1(file, evt) {
  calculateSize();
  var image = new Image();
  var fr = new FileReader();
  fr.onload = function (evt) {
    image.onload = function () {
      context.drawImage(image, first_start_x, first_start_y, 512, 512);
    };
    image.src = evt.target.result;
  };
  fr.readAsDataURL(file);
}

function readImage2(file, evt) {
  calculateSize();
  var image = new Image();
  var fr = new FileReader();
  fr.onload = function (evt) {
    image.onload = function () {
      context.drawImage(image, second_start_x, second_start_y, 512, 512);
    };
    image.src = evt.target.result;
  };
  fr.readAsDataURL(file);
}

function mapping(e) {
  calculateSize();
  for (var i = 0; i < minutiaPairList.length; i++) {
    var orrObj = minutiaPairList[i];
    var score = orrObj.similitude;
    var px = orrObj.px;
    var py = orrObj.py;
    var newPositonP = calculateNewPostion(first_start_x, first_start_y, px, py);
    var tx = orrObj.tx;
    var ty = orrObj.ty;
    var newPositonT = calculateNewPostion(second_start_x, second_start_y, px, py);
    var canvasi = document.getElementById("canvas_i");
    var context = canvasi.getContext("2d");
    drawMapingData_dot(context, score, newPositonP.x, newPositonP.y, newPositonT.x, newPositonT.y);
  }
}

function readMinutia(evt) {
  var fileToLoad = evt.target.files[0];
  if (fileToLoad) {
    var reader = new FileReader();
    var fileName = fileToLoad.name;
    reader.onload = function (fileLoadedEvent) {
      var data = fileLoadedEvent.target.result;
      var json = JSON.parse(data);
      var minutias = json.minutia;
      if (!minutias || minutias.length < 1) {
        alert("There some wrong, get data failed!");
        return;
      }
      var updateCountP = 0;
      var updateCountT = 0;
      for (var i = 0; i < minutiaPairList.length; i++) {
        for (var j = 0; j < minutias.length; j++) {
          var vi = Number(minutiaPairList[i].pn);
          var vj = minutias[j]["number"];
          if (fileName.toLowerCase().startsWith(PROBE) && Number(minutiaPairList[i].pn) == minutias[j]["number"]) {
            var tmp = minutias[j].x;
            minutiaPairList[i].px = minutias[j].x;
            minutiaPairList[i].py = minutias[j].y;
            updateCountP++;
          } else if (fileName.toLowerCase().startsWith(TARGET) && Number(minutiaPairList[i].tn) == minutias[j]["number"]) {
            minutiaPairList[i].tx = minutias[j].x;
            minutiaPairList[i].ty = minutias[j].y;
            updateCountT++;
          }
        }
      }
      alert("updateCountP=" + updateCountP + " updateCountT=" + updateCountT);
    };
    reader.readAsText(fileToLoad, 'UTF-8');
  }
}

function readXml(fileList, evt) {
  if (!fileList.length) {
    alert('File is not selected.');
    return;
  }
  var fileToLoad = evt.target.files[0];
  if (fileToLoad) {
    var reader = new FileReader();
    reader.onload = function (fileLoadedEvent) {
      var data = fileLoadedEvent.target.result;
      var x2js = new X2JS();
      var jsonTmp = x2js.xml_str2json(data);
      //var candiateList = jsonTmp["verifyJobResultDto"]["candidateResultList"]; 
      // var mpList = jsonTmp["verifyJobResultDto"]["candidateResultList"]["modalScoreList"]["rawScoreList"]["minutiaPairList"];
      var jobId = jsonTmp.verifyJobResultDto.jobId;
      var candidateId = jsonTmp.verifyJobResultDto.candidateResultList.candidateId;
      var modal = jsonTmp.verifyJobResultDto.candidateResultList.modalScoreList.modal;
      var algorithmType = jsonTmp.verifyJobResultDto.candidateResultList.modalScoreList.rawScoreList.algorithmType;
      var probePosition = jsonTmp.verifyJobResultDto.candidateResultList.modalScoreList.rawScoreList.probePosition;
      var targetPosition = jsonTmp.verifyJobResultDto.candidateResultList.modalScoreList.rawScoreList.position;
      var mpList = jsonTmp.verifyJobResultDto.candidateResultList.modalScoreList.rawScoreList.minutiaPairList;
      var updateMinutiaPairCount = 0;
      for (var i = 0; i < mpList.length; i++) {
        var temp = mpList[i];
        var matchedData = new MatchedData(temp._similitude, temp._probeMinutiaNumber, null, null, temp._targetMinutiaNumber, null, null);
        minutiaPairList.push(matchedData);
        updateMinutiaPairCount++;
      }
      var rawScoreList = new RawScoreList(algorithmType, probePosition, targetPosition, minutiaPairList);
      var modalScoreList = new ModalScoreList(modal, rawScoreList);
      var candidateResultList = new CandidateResultList(candidateId, modalScoreList);
      verifyJobResult = new VerifyJobResult(jobId, candidateResultList);
      alert("updateMinutiaPairCount=" + updateMinutiaPairCount);
    };
    reader.readAsText(fileToLoad, 'UTF-8');
  }
}

function allMapingWithDot() {
  calculateSize();
  for (var i = 0; i < minutiaPairList.length; i++) {
    var orrObj = minutiaPairList[i];
    var score = orrObj.similitude;
    var px = orrObj.px;
    var py = orrObj.py;
    var newPositonP = calculateNewPostion(first_start_x, first_start_y, px, py);
    var tx = orrObj.tx;
    var ty = orrObj.ty;
    var newPositonT = calculateNewPostion(second_start_x, second_start_y, px, py);
    var canvasi = document.getElementById("canvas_i");
    var context = canvasi.getContext("2d");
    drawMapingData_dot(context, score, newPositonP.x, newPositonP.y, newPositonT.x, newPositonT.y);
  }
}

function allMapingWithRect() {
  calculateSize();
  for (var i = 0; i < minutiaPairList.length; i++) {
    var orrObj = minutiaPairList[i];
    var score = orrObj.similitude;
    var px = orrObj.px;
    var py = orrObj.py;
    var newPositonP = calculateNewPostion(first_start_x, first_start_y, px, py);
    var tx = orrObj.tx;
    var ty = orrObj.ty;
    var newPositonT = calculateNewPostion(second_start_x, second_start_y, px, py);
    var canvasi = document.getElementById("canvas_i");
    var context = canvasi.getContext("2d");
    drawMapingData_rect(context, score, newPositonP.x, newPositonP.y, newPositonT.x, newPositonT.y);
  }
}

function calculateSize() {
  win_width = $(window).width();
  win_height = $(window).height();

  first_start_x = Math.floor((win_width / 2 - 512) / 2);
  first_start_y = Math.floor((win_height * 0.6 - 512) / 2);
  second_start_x = Math.floor(win_width / 2 + (win_width / 2 - 512) / 2);
  second_start_y = first_start_y;
  var firstImageNewCoordinateOriginX = -(first_start_x + 512 / 2);
  var firstImageNewCoordinateOriginY = first_start_y + 512 / 2;
  var secondImageNewCoordinateOriginX = -(second_start_x + 512 / 2);
  var secondImageNewCoordinateOriginY = second_start_y + 512 / 2;
}

function resizeCanvas() {
  var canvas = document.getElementById("canvas_i");
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
  calculateSize();
}

function drawMapingData_dot(context, score, lx, ly, rx, ry) {
  context.beginPath();
  context.arc(lx, ly, radius, 0, Math.PI * 2, true);
  context.strokeStyle = "red";
  context.lineWidth = strokelineWith;
  context.stroke();

  context.beginPath();
  context.moveTo(lx + radius, ly);
  context.lineTo(rx - radius, ry);
  context.strokeStyle = "green";
  context.stroke();

  context.beginPath();
  context.arc(rx, ry, radius, 0, Math.PI * 2, true);
  context.strokeStyle = "red";
  context.stroke();

  var sx = Math.abs((rx - lx) / 2 + lx);
  var sy = Math.abs((ry - ly) / 2 + ly);
  context.beginPath();
  context.fillStyle = 'blue';
  context.font = "12px Arial";
  context.fillText(score, sx, sy);
  // context.strokeText(score, sx, sy);
  //context.closePath();
}

function drawMapingData_rect(context, score, lx, ly, rx, ry) {
  context.beginPath();
  var size = radius;
  context.rect(lx - (size / 2), ly - (size / 2), size, size);
  context.strokeStyle = "red";
  context.lineWidth = strokelineWith;
  context.stroke();

  context.beginPath();
  context.moveTo(lx + (size / 2), ly);
  context.lineTo(rx - (size / 2), ry);
  context.strokeStyle = "green";
  context.stroke();

  context.beginPath();
  context.rect(rx - (size / 2), ry - (size / 2), size, size);
  context.strokeStyle = "red";
  context.closePath();
  context.stroke();

  var sx = Math.abs((rx - lx) / 2 + lx);
  var sy = Math.abs((ry - ly) / 2 + ly);
  context.beginPath();
  context.fillStyle = 'blue';
  context.font = "12px Arial";
  context.fillText(score, sx, sy);
}

function calculateNewPostion(start_x, start_y, x, y) {
  var newPositon = new Point();
  if (x < 0) {
    newPositon.x = start_x + (256 - (-1) * x);
  } else if (x >= 0) {
    newPositon.x = start_x + (256 + x);
  }
  if (y < 0) {
    newPositon.y = start_y + (256 + y);
  } else if (y >= 0) {
    newPositon.y = start_y + (256 - (-1) * y);
  }
  return newPositon;
}

function drawOneDot(imageNum, matchedData) {
  var orrObj = matchedData;
  if (imageNum === 1) {
    var pn = orrObj.pn;
    var px = orrObj.px;
    var py = orrObj.py;
    var newPositonP = calculateNewPostion(first_start_x, first_start_y, px, py);
    context.beginPath();
    context.arc(newPositonP.x, newPositonP.y, radius, 0, Math.PI * 2, true);
    context.strokeStyle = "red";
    context.lineWidth = 1;
  }
}

function drawDotWithNum() {
  calculateSize();
  canvasi = document.getElementById("canvas_i");
  context = canvasi.getContext("2d");
  for (var i = 0; i < minutiaPairList.length; i++) {
    var orrObj = minutiaPairList[i];
    var pn = orrObj.pn;
    var px = orrObj.px;
    var py = orrObj.py;
    var newPositonP = calculateNewPostion(first_start_x, first_start_y, px, py);

    var tn = orrObj.tn;
    var tx = orrObj.tx;
    var ty = orrObj.ty;
    var newPositonT = calculateNewPostion(second_start_x, second_start_y, tx, ty);

    context.beginPath();
    context.arc(newPositonP.x, newPositonP.y, radius, 0, Math.PI * 2, true);
    context.strokeStyle = "red";
    context.lineWidth = 1;
    context.stroke();
    var pnx = newPositonP.x - 6;
    var pny = newPositonP.y - radius - 3;
    context.beginPath();
    context.fillStyle = 'blue';
    context.font = "12px Arial";
    context.fillText(pn, pnx, pny);

    context.beginPath();
    context.arc(newPositonT.x, newPositonT.y, radius, 0, Math.PI * 2, true);
    context.strokeStyle = "red";
    context.lineWidth = 1;
    context.stroke();

    var tnx = newPositonT.x - 6;
    var tny = newPositonT.y - radius - 3;
    context.beginPath();
    context.fillStyle = 'blue';
    context.font = "12px Arial";
    context.fillText(tn, tnx, tny);
  }
}

function drawRectWithNum() {
  calculateSize();
  canvasi = document.getElementById("canvas_i");
  context = canvasi.getContext("2d");
  for (var i = 0; i < minutiaPairList.length; i++) {
    var orrObj = minutiaPairList[i];
    var pn = orrObj.pn;
    var px = orrObj.px;
    var py = orrObj.py;
    var newPositonP = calculateNewPostion(first_start_x, first_start_y, px, py);

    var tn = orrObj.tn;
    var tx = orrObj.tx;
    var ty = orrObj.ty;
    var newPositonT = calculateNewPostion(second_start_x, second_start_y, tx, ty);

    context.beginPath();
    context.rect(newPositonP.x - (radius / 2), newPositonP.y - (radius / 2), radius, radius);
    context.strokeStyle = "red";
    context.lineWidth = 1;
    context.stroke();
    var pnx = newPositonP.x - 6;
    var pny = newPositonP.y - radius / 2 - 3;
    context.beginPath();
    context.fillStyle = 'blue';
    context.font = "12px Arial";
    context.fillText(pn, pnx, pny);

    context.beginPath();
    context.rect(newPositonT.x - (radius / 2), newPositonT.y - (radius / 2), radius, radius);
    context.strokeStyle = "red";
    context.lineWidth = 1;
    context.stroke();

    var tnx = newPositonT.x - 6;
    var tny = newPositonT.y - radius / 2 - 3;
    context.beginPath();
    context.fillStyle = 'blue';
    context.font = "12px Arial";
    context.fillText(tn, tnx, tny);
  }
}

function drawLine(pointP, pointT, score, imageNum) {
  canvasi = document.getElementById("canvas_i");
  context = canvasi.getContext("2d");
  px = pointP.x;
  py = pointP.y;
  tx = pointT.x;
  ty = pointT.y;
  if (imageNum === 1) {
    context.beginPath();
    context.moveTo(px + radius, py);
    context.lineTo(tx - radius, ty);
    context.strokeStyle = "green";
    context.stroke();
    var sx = Math.abs((tx - px) / 2 + px);
    var sy = Math.abs((ty - py) / 2 + py);
    context.beginPath();
    context.fillStyle = 'blue';
    context.font = "12px Arial";
    context.fillText(score, sx, sy);
  } else if (imageNum === 2) {
    context.beginPath();
    context.moveTo(tx - radius, ty);
    context.lineTo(px + radius, py);
    context.strokeStyle = "green";
    context.stroke();
    var sx = Math.abs((px - tx) / 2 + tx);
    var sy = Math.abs((py - ty) / 2 + ty);
    context.beginPath();
    context.fillStyle = 'blue';
    context.font = "12px Arial";
    context.fillText(score, sx, sy);
  } else {
    alert("unknown image number!!");
  }
}

function clearDot(ox, oy, radius) {
  canvasi = document.getElementById("canvas_i");
  context = canvasi.getContext("2d");
  var lx = ox - radius - strokelineWith;
  var ly = oy - radius - strokelineWith;
  context.clearRect(lx, ly, radius * 2 + strokelineWith, radius * 2 + strokelineWith);
}

function clearRect(ox, oy, rectSize) {
  canvasi = document.getElementById("canvas_i");
  context = canvasi.getContext("2d");
  var lx = ox - (rectSize / 2) - strokelineWith;
  var ly = oy - (rectSize / 2) - strokelineWith;
  context.clearRect(lx, ly, rectSize + (strokelineWith * 2), rectSize + (strokelineWith * 2));
}


function clearText(lx, ly, rx, ry, radius) {
  canvasi = document.getElementById("canvas_i");
  context = canvasi.getContext("2d");
  var sx = Math.abs((rx - lx) / 2 + lx);
  var sy = Math.abs((ry - ly) / 2 + ly);

  var dwith = 8;
  var dheight = 8;
  context.clearRect(sx, sy, dwith, dheight);
}

function clearLineWithDot(lx, ly, rx, ry, radius) {
  canvasi = document.getElementById("canvas_i");
  context = canvasi.getContext("2d");
  var clx = lx - radius - strokelineWith;
  var cly = ly - radius - strokelineWith;
  var dwith = rx - lx + radius + strokelineWith + radius + strokelineWith;
  var dheight = radius * 2 + strokelineWith * 2;
  context.clearRect(clx, cly, dwith, dheight);
}

function clearLineWithRect(lx, ly, rx, ry, rectSize) {
  canvasi = document.getElementById("canvas_i");
  context = canvasi.getContext("2d");
  var clx = lx - (rectSize / 2) - strokelineWith;
  var cly = ly - (rectSize / 2) - strokelineWith;
  var dwith = rx - lx + rectSize + (strokelineWith * 4);
  var dheight = rectSize + strokelineWith * 2;
  context.clearRect(clx, cly, dwith, dheight);
}

function clearAll() {
  var hasFirstImage = false;
  var hasSecondImage = false;
  var xmlOrTxtFileInUsing = false;
  context.clearRect(first_start_x - 20, first_start_y - 20, (second_start_x - first_start_x + 512 + 20), 512);
  document.location.reload();
}

function doExit() {
  verifyJobResult = null;
  minutiaPairList = null;
  clearAll();
}

function onCanvasClick(e) {
  canvasi = document.getElementById("canvas_i");
  //var rect = canvasi.getBoundingClientRect();
  var rect = e.target.getBoundingClientRect();
  var x = e.offsetX;
  var y = e.offsetY;
  //var x = e.pageX - rect.left;
  //var y = e.pageY - rect.top;
  var imageNum;
  if (x >= first_start_x && x <= first_start_x + 512) {
    imageNum = 1;
  } else if (x >= second_start_x && x <= second_start_x + 512) {
    imageNum = 2;
  }
  for (var i = 0; i < minutiaPairList.length; i++) {
    var orrObj = minutiaPairList[i];
    var pn = orrObj.pn;
    var px = orrObj.px;
    var py = orrObj.py;
    var newPositonP = calculateNewPostion(first_start_x, first_start_y, px, py);

    var tn = orrObj.tn;
    var tx = orrObj.tx;
    var ty = orrObj.ty;
    var newPositonT = calculateNewPostion(second_start_x, second_start_y, tx, ty);
    context.beginPath();
    context.arc(newPositonP.x, newPositonP.y, radius, 0, Math.PI * 2, true);
    context.strokeStyle = "red";
    context.lineWidth = 1;
    if (context.isPointInPath(x, y)) {
      if (e.type == "click") {
        context.closePath();
        drawLine(newPositonP, newPositonT, orrObj.similitude, imageNum);
        return;
      } else if (e.type == "dbClick") {
        clearLineWithDot(newPositonP.x, newPositonP.y, newPositonT.y, newPositonT.y, radius);
      }
    }
  }
}

function test() {
  for (var i = 0; i < 20; i++) {
    var similitude = Math.floor(Math.random() * 100 + 2);
    var pn = Math.floor(Math.random() * 64 + 1);
    var tn = Math.floor(Math.random() * 64 + 1);
    if (i % 2 === 0) {
      var px = Math.floor(Math.random() * 256);
      var py = Math.floor(Math.random() * 256);
      var tx = Math.floor(Math.random() * 256);
      var ty = Math.floor(Math.random() * 256);
    } else {
      var px = (-1) * Math.floor(Math.random() * 256);
      var py = (-1) * Math.floor(Math.random() * 256);
      var tx = (-1) * Math.floor(Math.random() * 256);
      var ty = (-1) * Math.floor(Math.random() * 256);
    }
    var matchedData = new MatchedData(similitude, pn, px, py, tn, tx, ty);
    minutiaPairList.push(matchedData);
  }
}

function test1() {
  test();
  drawDotWithNum();
}

// flow is not used
function init_load() {
  var win_width = $(window).width();
  var win_height = $(window).height();

  var second_start_x = win_width / 2 + (win_width / 2 - 512) / 2;
  var second_start_y = first_start_y;
  var canvasi = document.getElementById("canvas_i");
  var context = canvasi.getContext("2d");
  var imgf = new Image();
  imgf.onload = function () {
    drawOneImage(context, this, first_start_x, first_start_y, 512, 512);
  };
  imgf.src = 'image/f_data.bmp';

  var imgs = new Image();
  imgs.onload = function () {
    drawOneImage(context, this, second_start_x, second_start_y, 512, 512);
  };
  imgs.src = "image/s_data.bmp";
}

function drawOneImage(context, imageObj, x, y, dx, dy) {
  context.drawImage(imageObj, x, y, dx, dy);
}

function randomRGB() {
  var r = Math.floor(Math.random() * 256);
  var g = Math.floor(Math.random() * 256);
  var b = Math.floor(Math.random() * 256);
  return `rgb(${r},${g},${b})`;
}

