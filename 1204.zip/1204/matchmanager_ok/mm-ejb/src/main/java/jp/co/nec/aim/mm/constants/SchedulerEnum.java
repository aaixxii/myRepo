package jp.co.nec.aim.mm.constants;

import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.scheduler.AggregationSchedulable;
import jp.co.nec.aim.mm.scheduler.DefragSchedulable;
import jp.co.nec.aim.mm.scheduler.FePlannerSchedulable;
import jp.co.nec.aim.mm.scheduler.IdentifyPlannerSchedulable;
import jp.co.nec.aim.mm.scheduler.LoadBalanceSchedulable;
import jp.co.nec.aim.mm.scheduler.MMHeartBeatSchedulable;
import jp.co.nec.aim.mm.scheduler.PollSchedulable;
import jp.co.nec.aim.mm.scheduler.PurgeJobQueueSchedulable;

import org.quartz.Job;
import org.quartz.JobKey;
import org.quartz.TriggerKey;

public enum SchedulerEnum {

	MMHeartBeatSchedulable(MMHeartBeatSchedulable.class, null, null, null, 5000), PurgeJobQueueSchedulable(
			PurgeJobQueueSchedulable.class,
			MMConfigProperty.INTERVAL_PURGE_JOB_QUEUE,
			MMConfigProperty.TIMELIMIT_PURGE_JOB_QUEUE,
			MMEventType.PURGE_JOB_QUEUE, 2000),

	DefragSchedulable(DefragSchedulable.class,
			MMConfigProperty.INTERVAL_DEFRAG_HYPERSONIC,
			MMConfigProperty.TIMELIMIT_DEFRAG_HYPERSONIC,
			MMEventType.DEFRAG_HYPERSONIC, 2000),

	PollSchedulable(PollSchedulable.class, MMConfigProperty.INTERVAL_POLLING,//
			MMConfigProperty.TIMELIMIT_POLLING,//
			MMEventType.POLL, 2000),

	LoadBalanceSchedulable(LoadBalanceSchedulable.class,
			MMConfigProperty.INTERVAL_LOADBALANCING,
			MMConfigProperty.TIMELIMIT_LOADBALANCING,
			MMEventType.SEGMENT_LOAD_BALANCING, 2000),

	AggregationSchedulable(AggregationSchedulable.class,
			MMConfigProperty.INTERVAL_JOB_AGGREGATION,
			MMConfigProperty.TIMELIMIT_JOB_AGGREGATION,
			MMEventType.JOB_AGGREGATION, 2000),

	IdentifyPlannerSchedulable(IdentifyPlannerSchedulable.class,
			MMConfigProperty.INTERVAL_JOB_PLANNER,
			MMConfigProperty.TIMELIMIT_JOB_PLANNER, MMEventType.JOB_PLANNER,
			2000),

	FePlannerSchedulable(FePlannerSchedulable.class,
			MMConfigProperty.INTERVAL_FEJOB_PLANNER,
			MMConfigProperty.TIMELIMIT_FEJOB_PLANNER,
			MMEventType.FEJOB_PLANNER, 2000);

	private Class<? extends Job> clazz;
	/** Service Name defined in scheduler-service.xml */
	private String schedulerName;
	/** MMConfigProperty which is the key of interval. */
	private MMConfigProperty intervalProperty;
	/** MMConfigProperty which is the key of timelimit. */
	private MMConfigProperty limitProperty;
	/** MMTimeType which is correspond to NAME column in MATCH_MANAGER_TIMES */
	private MMEventType mmTimeType;

	private long intervalInMillis;
	private long timeoutInMillis;
	private int delayMillis;
	private long currentTime;

	private SchedulerEnum(Class<? extends Job> clazz,
			MMConfigProperty intervalProperty, MMConfigProperty limitProperty,
			MMEventType mmTimeType, long intervalInMillis) {
		this.clazz = clazz;
		this.intervalProperty = intervalProperty;
		this.limitProperty = limitProperty;
		this.mmTimeType = mmTimeType;
		this.schedulerName = clazz.getName();
		this.intervalInMillis = intervalInMillis;
		this.delayMillis = 0;
		this.currentTime = 0;
	}

	public static SchedulerEnum findJob(Class<? extends Job> clazz) {
		for (SchedulerEnum schedulerenum : SchedulerEnum.values()) {
			if (schedulerenum.getClazz().equals(clazz)) {
				return schedulerenum;
			}
		}
		throw new AimRuntimeException("can not find job with class "
				+ clazz.getSimpleName());
	}

	public Class<? extends Job> getClazz() {
		return clazz;
	}

	public long getIntervalInMillis() {
		return intervalInMillis;
	}

	public void setIntervalInMillis(long intervalInMillis) {
		this.intervalInMillis = intervalInMillis;
	}

	public JobKey getJobkey() {
		String jobName = schedulerName + "job";
		String jobgroup = schedulerName + "jobGroup";
		return JobKey.jobKey(jobName, jobgroup);
	}

	public TriggerKey getTriggerKey() {
		String triggerName = schedulerName + "trigger";
		String triggergroup = schedulerName + "triggerGroup";
		return TriggerKey.triggerKey(triggerName, triggergroup);
	}

	public String getSchedulerName() {
		return schedulerName;
	}

	public MMConfigProperty getIntervalProperty() {
		return intervalProperty;
	}

	public MMConfigProperty getLimitProperty() {
		return limitProperty;
	}

	public MMEventType getMMEventType() {
		return mmTimeType;
	}

	public int getDelayMillis() {
		return delayMillis;
	}

	public void setDelayMillis(int delayMillis) {
		this.delayMillis = delayMillis;
	}

	public long getCurrentTime() {
		return currentTime;
	}

	public void setCurrentTime(long currentTime) {
		this.currentTime = currentTime;
	}

	/**
	 * @return the timeoutInMillis
	 */
	public long getTimeoutInMillis() {
		return timeoutInMillis;
	}

	/**
	 * @param timeoutInMillis
	 *            the timeoutInMillis to set
	 */
	public void setTimeoutInMillis(long timeoutInMillis) {
		this.timeoutInMillis = timeoutInMillis;
	}

}
