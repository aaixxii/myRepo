package jp.co.nec.aim.mm.segment.sync;

import static jp.co.nec.aim.message.proto.AIMEnumTypes.ComponentType.*;
import static jp.co.nec.aim.message.proto.AIMEnumTypes.SegmentAssignedStateType.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.protobuf.ByteString;

import jp.co.nec.aim.message.proto.AIMEnumTypes.ComponentType;
import jp.co.nec.aim.message.proto.AIMEnumTypes.SegmentAssignedStateType;
import jp.co.nec.aim.message.proto.AIMEnumTypes.SegmentStateType;
import jp.co.nec.aim.message.proto.AIMEnumTypes.SegmentSyncCommandType;
import jp.co.nec.aim.message.proto.AIMMessages.PBSegmentCatchUpInfo;
import jp.co.nec.aim.message.proto.AIMMessages.PBSegmentCatchUpItem;
import jp.co.nec.aim.message.proto.AIMMessages.PBSegmentSyncInfo;
import jp.co.nec.aim.message.proto.AIMMessages.PBSegmentSyncItem;
import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.constants.MMConfigProperty;
import jp.co.nec.aim.mm.dao.DateDao;
import jp.co.nec.aim.mm.dao.SegmentDiffDao;
import jp.co.nec.aim.mm.dao.SegmentDiffDao.MapReportCombined;
import jp.co.nec.aim.mm.dao.SystemConfigDao;
import jp.co.nec.aim.mm.dao.UnitDao;
import jp.co.nec.aim.mm.dm.client.mgmt.UidDmJobRunManager;
import jp.co.nec.aim.mm.entities.MatchUnitEntity;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.exception.ExceptionHelper;
import jp.co.nec.aim.mm.procedure.GetSegCatupInfoProcedure;
import jp.co.nec.aim.mm.util.CollectionsUtil;
import jp.co.nec.aim.mm.util.TimeHelper;

/**
 * Segment Updates Management
 *
 * If MU,DM segment version exists different, we will try to sync the segment
 * data if the different between latest version and the report version is not
 * too huge, try to catch up the different(DB IO once), otherwise, gave the
 * segment download URL, MU DM will download directly..
 *
 * @author liuyq
 *
 */
public class SegUpdatesManager {
	/** log instance **/
	private static Logger log = LoggerFactory.getLogger(SegUpdatesManager.class);

	/** EntityManager instance **/
	private EntityManager manager;
	/** EntityManager instance **/
	private DataSource dataSource;
	/** UnitDao instance **/
	private UnitDao unitDao;
	/** SystemConfigDao instance **/
	private SystemConfigDao configDao;
	private DateDao dateDao; // dateDao
	private SegmentDiffDao diffDao; // diffDao
	private ExceptionHelper exception; // exception

	/**
	 * SegUpdatesManager constructor
	 *
	 * @param entityManager EntityManager instance
	 * @param dataSource    DataSource instance
	 */
	public SegUpdatesManager(EntityManager entityManager, DataSource dataSource) {
		this.manager = entityManager;
		this.dataSource = dataSource;
		this.configDao = new SystemConfigDao(entityManager);
		this.unitDao = new UnitDao(manager);
		this.dateDao = new DateDao(dataSource);
		this.diffDao = new SegmentDiffDao(dataSource);
		this.exception = new ExceptionHelper(dateDao);
	}

	// ////////////////////////////////////////////////////////////////////////
	// //////////////////////////public method/////////////////////////////////
	// ////////////////////////////////////////////////////////////////////////

	/**
	 * getSegmentUpdates
	 *
	 * @param type      ComponentType
	 * @param segmentId segmentId
	 * @param unitIds   out unit Id set
	 * @return PBSegmentSyncRequest instance
	 */
	public PBSegmentSyncInfo getSegmentUpdates(ComponentType type, final Long segmentId,
			final List<SegSyncInfos> syncInfos, Set<Long> unitIds) {
		if (type == null) {
			throw new IllegalArgumentException("ComponentType is null..");
		}

		switch (type) {
		case MATCH_UNIT:
			final List<MapReportCombined> muResults = diffDao.getSegMuDiffInfos(segmentId);
			if (CollectionsUtil.isEmpty(muResults)) {
				if (log.isDebugEnabled()) {
					log.debug("Nothing to get the information of Segment id: {} ", segmentId);
				}
				return null;
			}

			return createSyncInfo(segmentId, syncInfos, unitIds, muResults);
		default:
			throw new IllegalArgumentException("ComponentType is not support..");
		}
	}

	/**
	 * createSyncInfo
	 *
	 * @param segmentId
	 * @param syncInfos
	 * @param unitIds
	 * @param muResults
	 * @return PBSegmentSyncInfo instance
	 */
	@SuppressWarnings("unchecked")
	private PBSegmentSyncInfo createSyncInfo(Long segmentId, final List<SegSyncInfos> syncInfos, Set<Long> unitIds,
			final List<MapReportCombined> muResults) {
		PBSegmentSyncInfo.Builder builder = PBSegmentSyncInfo.newBuilder().setId(segmentId);

		unitIds.addAll(CollectionsUtil.extractToList(muResults, "unitId"));
		if (CollectionsUtil.isEmpty(unitIds)) {
			log.info("Nothing to push due to without push destination..");
			return null;
		}

		if (log.isDebugEnabled()) {
			log.debug("Ready to push the diff to unitIds: {}", unitIds.toString());
		}

		final MapReportCombined first = CollectionsUtil.getFirst(muResults);
		if (first.getLatestVersion() == null) {
			builder.setAssignedState(SegmentAssignedStateType.SEGMENT_DEFUNCT);
		} else if (first.getRank() == null) {
			builder.setAssignedState(SEGMENT_UNASSIGNED);
		} else {
			builder.setAssignedState(SEGMENT_ASSIGNED);
		}

		PBSegmentCatchUpInfo.Builder catchUpInfo = builder.getSyncItemBuilder().getCatUpInfoBuilder();
		for (final SegSyncInfos sync : syncInfos) {
			PBSegmentCatchUpItem.Builder item = PBSegmentCatchUpItem.newBuilder();

			// Command and version is required
			item.setCommand(SegmentSyncCommandType.valueOf(sync.getCommand().name())).setVersion(sync.getSegVersion());

			item.setBiometricsId(sync.getTemplateId());
			// template id set up only delete
			switch (item.getCommand()) {
			case SEGMENT_SYNC_COMMAND_INSERT:
				// set template when command is insert
				ByteString binary = ByteString.copyFrom(sync.getTemplateData());
				if (binary != null && !binary.isEmpty()) {
					item.setBinaryTemplate(binary);
				}
				break;
			case SEGMENT_SYNC_COMMAND_DELETE:
				// There is no processing only at the time of Delete,
				// but this CASE statement is left to allow it.
				break;
			default:
				throw new AimRuntimeException("Command: " + item.getCommand().name() + "is not support..");
			}
			catchUpInfo.addCatchUpItems(item);
		}
		return builder.build();
	}

	/**
	 * getMuSegUpdates
	 *
	 * @param muId the match unit id
	 * @return PBSegmentSyncInfo.Builder list
	 */
	public List<PBSegmentSyncInfo> getMuSegUpdates(long muId) {
		MatchUnitEntity mu = unitDao.findMU(muId);
		if (mu == null) {
			throw new AimRuntimeException("Can not found Match Unit with id:" + muId);
		}

		TimeHelper timeHelper = new TimeHelper("getMuSegUpdates()");
		timeHelper.t();
		List<MapReportCombined> results = diffDao.getMuDiffInfos(muId);
		timeHelper.t();

		// if the result is empty, nothing to sync
		if (CollectionsUtil.isEmpty(results)) {
			if (log.isDebugEnabled()) {
				log.debug(timeHelper.message());
				log.debug("Nothing to Sync Segment data, MU id:{}..", muId);
			}
			return Lists.newArrayList();
		}
		return createSyncInfos(muId, true, results);
	}

	// ////////////////////////////////////////////////////////////////////////
	// //////////////////////////private method////////////////////////////////
	// ////////////////////////////////////////////////////////////////////////
	/**
	 * createSyncInfos
	 *
	 * @param unitId  unit id
	 * @param results MapReportCombined list
	 * @return PBSegmentSyncInfo.Builder list
	 */
	private List<PBSegmentSyncInfo> createSyncInfos(long unitId, boolean isMU, List<MapReportCombined> results) {
		final List<PBSegmentSyncInfo> segUpdates = Lists.newArrayList();
		TimeHelper timeHelper = new TimeHelper("createSyncInfos()");
		timeHelper.t();
		final Map<Long, SegDiffPara> catchUpMaps = addSegUpdates(segUpdates, results);
		timeHelper.t();
		// nothing to catch up, return segUpdates list directly..
		if (CollectionsUtil.isEmpty(catchUpMaps)) {
			log.info("Nothing to catch up, unit id: {}..", unitId);
			return segUpdates;
		}

		timeHelper.t();
		List<PBSegmentSyncInfo> catchUpBuilders = getCatchUpSegsInfo(catchUpMaps, isMU);
		timeHelper.t();
		// at last add all segment catch up informations
		// segUpdates list ignore the order of the segment id
		// i think it is not necessary to sort anyway
		segUpdates.addAll(catchUpBuilders);

		if (log.isDebugEnabled()) {
			log.debug(timeHelper.message());
			log.debug("Get Sync Segment data completely, Unit id:{}..", unitId);
		}
		return segUpdates;
	}

	/**
	 * add PBSegmentSyncInfo to segUpdates (do not need to catch up) <br>
	 * put the segment that need to catch up into map <br>
	 *
	 * @param segUpdates PBSegmentSyncInfo.Builder list
	 * @param results    MapReportCombined list
	 * @return Map<Long, SegDiffPara>
	 */
	private Map<Long, SegDiffPara> addSegUpdates(final List<PBSegmentSyncInfo> segUpdates,
			List<MapReportCombined> results) {
		final Map<Long, SegDiffPara> catchUpMaps = Maps.newHashMap();
		for (final MapReportCombined result : results) {
			final PBSegmentSyncInfo.Builder syncInfo = PBSegmentSyncInfo.newBuilder();
			final PBSegmentSyncItem.Builder syncItem = syncInfo.getSyncItemBuilder();

			final long segId = result.getSegmentId(); // segment id
			final Integer latestVer = result.getLatestVersion(); // segment
																	// latest
																	// version
			// segment report version
			final Integer reportVer = (result.getReportVersion() != null) ? result.getReportVersion()
					: result.getReportQueuedVersion();
			final Integer queueVer = result.getReportQueuedVersion();
			final Integer rank = result.getRank();

			syncInfo.setId(segId); // set segment id

			String dmUrl = UidDmJobRunManager.getOneActiveDm();
			if (dmUrl == null) {
				// ToDo
				log.warn("No active dm!");
				return catchUpMaps;
			}
			String sourceURL = constructURL(dmUrl, segId);// downloadurl
			log.info("Download url={}", sourceURL);

			if (latestVer == null) {
				// segment does not exist (DEFUNCT). need to send update.
				syncInfo.setAssignedState(SEGMENT_DEFUNCT);
			} else {
				// item.setVersion(result.getLatestVersion());
				// segment exists. may or may not need an update.
				if (rank == null) {
					// segment is not assigned.
					syncInfo.setAssignedState(SEGMENT_UNASSIGNED);
					if (requiresDiffs(result)) {
						Boolean updateUnassignedSegs = Boolean
								.parseBoolean(configDao.getMMProperty(MMConfigProperty.UPDATE_UNASSIGNED_SEGS));
						if (updateUnassignedSegs) {
							if (addCatupOrDownload(syncItem, result, sourceURL, catchUpMaps, segId, reportVer,
									latestVer, rank, SEGMENT_UNASSIGNED)) {
								continue;
							}
						}
					}
				} else {
					// segment is assigned.
					syncInfo.setAssignedState(SEGMENT_ASSIGNED);
					syncInfo.setRank(rank);
					if (!isDownloaded(result)) {
						syncItem.getDownloadBuilder().setSource((sourceURL == null) ? "" : sourceURL);
					} else {
						if (requiresDiffs(result)) {
							// catch up is necessary, put into map
							if (addCatupOrDownload(syncItem, result, sourceURL, catchUpMaps, segId, reportVer,
									latestVer, rank, SEGMENT_ASSIGNED)) {
								continue;
							}
						} else {
							log.warn(
									"segmentId:{}  latestVerson:{}  reportVersion:{} "
											+ " queuedVersion:{} Received a no-op segment update... "
											+ "these should be filtered out now!",
									new Object[] { segId, latestVer, reportVer, queueVer });
							continue; // as an optimization, don't bother
							// sending segment update item if it's
							// assigned and up-to-date.
						}
					}
				}
			}
			segUpdates.add(syncInfo.build()); // add to list
		}
		return catchUpMaps;
	}

	/**
	 * Get Segment CatchUp Info with MULTIP-segmentInfo <br>
	 * and return the PBSegmentSyncInfo list
	 *
	 * @param catchUpMaps the instance of catchUpMaps
	 * @return PBSegmentSyncInfo.Builder list
	 */
	private List<PBSegmentSyncInfo> getCatchUpSegsInfo(final Map<Long, SegDiffPara> catchUpMaps, boolean isMU) {
		final List<PBSegmentSyncInfo> syncInfos = Lists.newArrayList();

		// fetch the segment catch up informations from
		// database with specified SegDiffPara list only once
		List<CatchUpInfo> catchUpInfos = Lists.newArrayList();
		try {
			GetSegCatupInfoProcedure procedure = new GetSegCatupInfoProcedure(dataSource);
			procedure.getSegDiffParas().addAll(catchUpMaps.values());
			procedure.setUnitType(isMU ? MATCH_UNIT.ordinal() : DATA_MANAGER.ordinal());

			catchUpInfos = procedure.execute();
		} catch (DataAccessException ex) {
			exception.throwDBException(AimError.SYNC_DB, ex,
					"DataAccessException occurred " + "when call GetSegCatupInfoProcedure..");
		}

		// nothing fetched from database, return directly
		if (CollectionsUtil.isEmpty(catchUpInfos)) {
			log.warn("GetSegCatupInfoProcedure returned " + "without any segment catch up information.. ");
			return syncInfos;
		}

		final Map<Long, List<CatchUpInfo>> map = categoryCatchUp(catchUpInfos);
		for (final Long segId : map.keySet()) {
			List<CatchUpInfo> oneSeg = map.get(segId);
			if (CollectionsUtil.isEmpty(oneSeg)) {
				log.warn("Segment id {} without any CatchUpInfo after category" + ", do get next segment..", segId);
				continue;
			}

			final PBSegmentSyncInfo.Builder b = PBSegmentSyncInfo.newBuilder();
			b.setId(segId); // segment id
			final SegDiffPara para = catchUpMaps.get(segId);
			if (para == null) {
				throw new AimRuntimeException("can not found the SegDiffPara with segId:" + segId);
			}
			b.setAssignedState(para.getState()); // AssignedState
			// if (para.getRank() != null)
			// b.setRank(para.getRank()); // segment assigned rank
			// set PBSegmentDownloadInfo is not necessary

			PBSegmentCatchUpInfo.Builder catchUpInfo = b.getSyncItemBuilder().getCatUpInfoBuilder();
			for (final CatchUpInfo info : oneSeg) {
				PBSegmentCatchUpItem.Builder item = PBSegmentCatchUpItem.newBuilder();

				// command and version is required
				item.setCommand(info.getCommand()).setVersion(info.getVersion());
				item.setBiometricsId(info.getTemplateId());
				switch (item.getCommand()) {
				case SEGMENT_SYNC_COMMAND_INSERT:
					// set template when command is insert
					if (isMU && !info.isBytesEmpty()) {
						// DM do not need to set binary template
						item.setBinaryTemplate(ByteString.copyFrom(info.getBytes()));
					}
					break;
				case SEGMENT_SYNC_COMMAND_DELETE:
					// There is no processing only at the time of Delete,
					// but this CASE statement is left to allow it.
					break;
				default:
					throw new AimRuntimeException("Command: " + item.getCommand().name() + "is not support..");
				}
				catchUpInfo.addCatchUpItems(item);
			}
			syncInfos.add(b.build());
		}
		return syncInfos;
	}

	/**
	 * add Segment Cat up information Or Download URL
	 *
	 * @param syncInfo    PBSegmentSyncInfo builder
	 * @param result      the instance of MapReportCombined
	 * @param sourceURL   DM download source URL
	 * @param catchUpMaps catchUpMaps
	 * @param segId       segment id
	 * @param reportVer   segment report version
	 * @param latestVer   segment latest version
	 * @param rank        rank
	 * @return is catch up or download
	 */
	boolean addCatupOrDownload(PBSegmentSyncItem.Builder syncItem, MapReportCombined result, String sourceURL,
			final Map<Long, SegDiffPara> catchUpMaps, long segId, Integer reportVer, Integer latestVer, Integer rank,
			SegmentAssignedStateType state) {
		// if the MU has given a 'queued' version, use that
		// to determine what
		// diffs to send. otherwise,
		// use the standard 'version' attribute.
		Integer maxSegmentDiffs = Integer.parseInt(configDao.getMMProperty(MMConfigProperty.MAX_SEGMENT_DIFFS));
		int reportVersionForDiffs = result.getReportQueuedVersion() == null ? result.getReportVersion().intValue()
				: result.getReportQueuedVersion().intValue();
		int latestVersion = result.getLatestVersion().intValue();
		if (reportVersionForDiffs < latestVersion - maxSegmentDiffs) {
			// too many diffs to send; MU/SMS should
			// re-download.
			syncItem.getDownloadBuilder().setSource((sourceURL == null) ? "" : sourceURL);
		} else {
			// catch up is necessary, put into map
			catchUpMaps.put(segId, new SegDiffPara(segId, reportVer, latestVer, state, rank));
			return true;
		}
		return false;
	}

	/**
	 * categorize CatchUp list to map <br>
	 * key is segment id
	 *
	 * @param all CatchUpInfo list that will be categorized
	 */
	private Map<Long, List<CatchUpInfo>> categoryCatchUp(List<CatchUpInfo> all) {
		Map<Long, List<CatchUpInfo>> map = Maps.newHashMap();
		for (final CatchUpInfo i : all) {
			long segmentId = i.getSegmentId();
			if (!map.containsKey(segmentId)) {
				map.put(segmentId, new ArrayList<CatchUpInfo>());
			}
			map.get(segmentId).add(i);
		}
		return map;
	}

	/**
	 * constructURL
	 *
	 * @param sourceURLBase
	 * @param segmentId
	 * @return Segment download URL
	 */
	private String constructURL(String url, long segmentId) {
		url = url.endsWith("/") ? url : url + "/";
		return url + "seg/" + segmentId;
		// return (url == null) ? null : url + "/" + DATAMANAGER_CONTENT

	}

	/**
	 * requiresDiffs
	 *
	 * @param result the instance of MapReportCombined
	 * @return requires DIFF or not
	 */
	private boolean requiresDiffs(MapReportCombined result) {
		return result.getLatestVersion() != null && // segment exists
				isDownloaded(result) && // segment has been download
				result.getReportVersion() < result.getLatestVersion(); // segment
		// is
		// out-of-date
	}

	/**
	 * check the segment has been downloaded
	 *
	 * @param result MapReportCombined instance
	 * @return has been download or not
	 */
	private boolean isDownloaded(MapReportCombined result) {
		return result.getStatus() != null && (result.getStatus() == SegmentStateType.SEGMENT_STATE_MEMORY.ordinal()
				|| result.getStatus() == SegmentStateType.SEGMENT_STATE_DISK.ordinal()
				|| result.getStatus() == SegmentStateType.SEGMENT_STATE_DOWNLOADING.ordinal()
				|| result.getStatus() == SegmentStateType.SEGMENT_STATE_DOWNLOADQUEUING.ordinal());
	}
}
