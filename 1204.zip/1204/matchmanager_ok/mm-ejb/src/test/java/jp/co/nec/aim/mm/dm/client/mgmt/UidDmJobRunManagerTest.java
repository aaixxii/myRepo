/**this is file UidDmJobRunManagerTest.java
 * @author xia
   @date 2020/11/25
 */
package jp.co.nec.aim.mm.dm.client.mgmt;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import jp.co.nec.aim.mm.dm.client.DmIndexInfo;
import jp.co.nec.aim.mm.entities.DmServiceEntity;

/**
 * @author xia
 *
 */
public class UidDmJobRunManagerTest {

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	/**
	 * Test method for {@link jp.co.nec.aim.mm.dm.client.mgmt.UidDmJobRunManager#readDmToArray(java.util.List)}.
	 */
	@Test
	public void testReadDmToArray() {
		List<DmServiceEntity> dmsList = new ArrayList<>();
		DmServiceEntity dm1 = new DmServiceEntity();
		dm1.setDmId(1);
		dm1.setContactUrl("http://127.0.0.1:8083/dm");
		dmsList.add(dm1);
		
		DmServiceEntity dm2 = new DmServiceEntity();
		dm2.setDmId(2);
		dm2.setContactUrl("http://127.0.0.1:8183/dm");
		dmsList.add(dm2);
		UidDmJobRunManager.readDmToArray(dmsList);
		DmIndexInfo[] dmArr = UidDmJobRunManager.getDM_LIST();
		
		
	}

}
