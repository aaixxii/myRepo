package com.nec.biomatcher.client.util;

import static com.nec.biomatcher.client.common.XmClientConstants.CLIENT_CALLBACK_IP;
import static com.nec.biomatcher.client.common.XmClientConstants.CLIENT_CALLBACK_PORT;

import java.util.concurrent.TimeUnit;

import javax.xml.bind.JAXBElement;

import com.nec.biomatcher.client.manager.XmClientManager;
import com.nec.biomatcher.webservices.ExtractInputPayloadDto;
import com.nec.biomatcher.webservices.ExtractJobRequestDto;
import com.nec.biomatcher.webservices.FingerExtractInputImage;
import com.nec.biomatcher.webservices.GenderEnum;
import com.nec.biomatcher.webservices.Image;
import com.nec.biomatcher.webservices.ImageFormat;
import com.nec.biomatcher.webservices.ImagePosition;
import com.nec.biomatcher.webservices.MetaInfoCommon;
import com.nec.biomatcher.webservices.ObjectFactory;
import com.nec.biomatcher.webservices.TemplateExtractInputImage;

public class ExtractJobReqeustCreater {	
	//private static Logger logger = LoggerFactory.getLogger(SearchJobReqeustCreater.class);
	long jobTimeoutMilli = TimeUnit.SECONDS.toMillis(60);
	private static GenderEnum Gender = GenderEnum.M;
	private static Integer Yob = 1977;	
	private static String Race = "B";	
	private static String templateType = "TEMPLATE_TYPE_35";


	public ExtractJobReqeustCreater() {		
	}

	public ExtractJobRequestDto buildExtractJobRequest(String dataFile) {	
		ExtractJobRequestDto extractJobRequestDto = new ExtractJobRequestDto();		
		String callbackIp = XmClientManager.getInstance().getValue(CLIENT_CALLBACK_IP);
		String callbackPort = XmClientManager.getInstance().getValue(CLIENT_CALLBACK_PORT);
		String callbackUrl = "http://" + callbackIp + ":" + callbackPort;
		extractJobRequestDto.setCallbackUrl(callbackUrl);
		ObjectFactory objectFactory = new ObjectFactory();
		JAXBElement<Integer> priority = objectFactory.createExtractJobRequestDtoPriority(10);
		extractJobRequestDto.setPriority(priority);
		extractJobRequestDto.setJobTimeoutMill(jobTimeoutMilli);
		extractJobRequestDto.setJobMode("live");
		ExtractInputPayloadDto extractInputPayloadDto = buildExtractInputPayloadDto(dataFile);
		extractJobRequestDto.setExtractInputPayload(extractInputPayloadDto);
		return extractJobRequestDto;
	}

	private ExtractInputPayloadDto buildExtractInputPayloadDto(String imageFileName) {
		ExtractInputPayloadDto epDto = new ExtractInputPayloadDto();		
		TemplateExtractInputImage templateImage = new TemplateExtractInputImage();	
		FingerExtractInputImage fingerExtractInputImag = new FingerExtractInputImage();
		//List<Image> images = new ArrayList<>();		
		Image rollImage = new Image();
		FileUtil fu = new FileUtil();
        byte[] imageRollData = fu.getDataFromFile(imageFileName);      
        rollImage.setType(ImageFormat.WSQ);
        rollImage.setPosition(ImagePosition.ROLL_RRING);
        rollImage.setData(imageRollData);        
        fingerExtractInputImag.getImages().add(rollImage);
        
        ObjectFactory objectFactory = new ObjectFactory();
        MetaInfoCommon metaInfoCommon = new MetaInfoCommon();
        metaInfoCommon.setGender(GenderEnum.M);
        JAXBElement<Integer> yob = objectFactory.createMetaInfoCommonYob(Yob);
        metaInfoCommon.setYob(yob);
        metaInfoCommon.setRace(Race);
        metaInfoCommon.setGender(Gender);       
        JAXBElement<MetaInfoCommon> mm = objectFactory.createExtractInputPayloadDtoMetaInfoCommon(metaInfoCommon);
        epDto.setMetaInfoCommon(mm);
        
        
//  	Image slapImage = new Image();
//      byte[] imageSlapData = getTemplateData("SLAP_12.wsq");      
//      rollImage.setType(ImageFormat.WSQ);
//      rollImage.setPosition(ImagePosition.SLAP_RRING);
//      rollImage.setData(imageSlapData); 
//      images.add(slapImage);
     
      fingerExtractInputImag.getImages().add(rollImage);
      //fingerExtractInputImag.getImages().add(slapImage);  
  
      templateImage.setExtractInputImage(fingerExtractInputImag);
      templateImage.getTemplateTypes().add(templateType);
      epDto.getTemplateExtractInputImageList().add(templateImage);
      fu = null;
      return epDto;	
	}
}
