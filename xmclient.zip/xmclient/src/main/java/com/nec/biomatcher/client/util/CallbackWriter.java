package com.nec.biomatcher.client.util;

import static com.nec.biomatcher.client.common.XmClientConstants.ONE_BY_ONE;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;

import javax.xml.bind.JAXBException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;

import com.nec.biomatcher.client.logger.PerformanceLogger;
import com.nec.biomatcher.client.manager.XmClientManager;
import com.nec.biomatcher.webservices.SyncJobResultDto;

public class CallbackWriter implements Runnable {
	private Socket socket;
	private String outPath;
	private static Logger logger = LoggerFactory.getLogger("CallbackLogger");

	public CallbackWriter(Socket socket, String outPath) {
		this.socket = socket;
		this.outPath = outPath;
	}

	public void writeResultToFile() {
		String stringData = null;
		BufferedInputStream bis = null;
		DataOutputStream dOut = null;
		FileWriter fileWriter = null;
		try {
			dOut = new DataOutputStream(socket.getOutputStream());
			bis = new BufferedInputStream(socket.getInputStream());
			byte[] temp = new byte[4096];
			bis.read(temp);
			stringData = new String(temp, "utf-8");
			stringData = stringData.trim();
			temp = null;
			int index = stringData.indexOf("<");
			String oldString = stringData;
			System.setProperty("file.encoding", "UTF-8");
			stringData = stringData.substring(index, stringData.length());
			int beginIndex = stringData.indexOf("<jobId>");
			int endIndex = stringData.indexOf("</jobId>");
			String jobId = stringData.substring(beginIndex + 7, endIndex);
			String outputFullName = outPath + jobId + ".xml";
			stringData = ClientUtil.getInstance().formatXml(stringData);
			if (stringData == null || stringData.isEmpty()) {
				stringData = oldString;
			}			
			String oneByOne = XmClientManager.getInstance().getValue(ONE_BY_ONE);
			if (oneByOne != null) {
				Object locker = XmClientManager.getLock(jobId);
				if (locker != null) {
					 synchronized (locker) {
						 locker.notify();
						 logger.info("Sucess notify to OneByOneInsertRequester!");
					 }
				}
			}			
			Long startTime = XmClientManager.getTimesMap().get(jobId);
			if (startTime != null) {				
				PerformanceLogger.trace(CallbackWriter.class.getSimpleName(), "getCallbackResult", jobId, null, XmClientManager.getPriority(jobId), System.currentTimeMillis() - startTime.longValue());
			} else {
				PerformanceLogger.trace(CallbackWriter.class.getSimpleName(), "getCallbackResult", jobId, null, null, -1);
			}	
			XmClientManager.getTimesMap().remove(jobId);
			XmClientManager.removeLock(jobId);
			XmClientManager.removePriority(jobId);
			File file = new File(outputFullName);
			fileWriter = new FileWriter(file);
			fileWriter.write(stringData);			
			logger.info("success to save callback job result to file:{}", jobId);
			dOut.writeBytes("HTTP/1.1 200 OK\r\n");
		} catch (IOException e) {
			try {
				dOut.writeBytes("HTTP/1.1 500 server error!\r\n");
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			logger.error(e.getMessage(), e);

		} finally {
			try {
				fileWriter.close();
				bis.close();
				socket.close();
				dOut.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public void writeXmlDataToFile() {
		String stringData = null;
		DataOutputStream dOut = null;
		BufferedInputStream bis = null;
		try {
			dOut = new DataOutputStream(socket.getOutputStream());
			bis = new BufferedInputStream(socket.getInputStream());
			byte[] temp = new byte[4096];
			bis.read(temp);
			stringData = new String(temp, "utf-8");
			stringData = stringData.trim();

			int index = stringData.indexOf("<");
			System.setProperty("file.encoding", "UTF-8");
			stringData = stringData.substring(index, stringData.length());
			int beginIndex = stringData.indexOf("<jobId>");
			int endIndex = stringData.indexOf("</jobId>");
			String jobId = stringData.substring(beginIndex + 7, endIndex);
			String outputFullName = outPath + jobId + ".xml";
			JaxBUtil<SyncJobResultDto> jaxb = new JaxBUtil<SyncJobResultDto>();
			SyncJobResultDto syncResult = jaxb.unmarshal(SyncJobResultDto.class, stringData);
			jaxb.marshalToFile(SyncJobResultDto.class, syncResult, outputFullName);
			dOut.writeBytes("HTTP/1.1 200 OK\r\n");
			temp = null;
			jaxb = null;
			logger.info("Success received syncJob result, jobId={}", jobId);
		} catch (JAXBException | IOException e) {
			logger.error(e.getMessage(), e);
			try {
				dOut.writeBytes("HTTP/1.1 500 Server error!\r\n");
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		} finally {
			try {
				socket.close();
				bis.close();
				dOut.close();
			} catch (IOException e) {
				logger.error(e.getMessage(), e);
			}
		}
	}

	public void writeResultToFileUsingDom() {
		String stringData = null;
		DataOutputStream dOut = null;
		BufferedInputStream bis = null;
		InputStream in = null;
		FileWriter fileWriter = null;
		try {
			dOut = new DataOutputStream(socket.getOutputStream());
			bis = new BufferedInputStream(socket.getInputStream());
			byte[] temp = new byte[4096];
			bis.read(temp);
			stringData = new String(temp, "utf-8");
			stringData = stringData.trim();
			int index = stringData.indexOf("<");
			System.setProperty("file.encoding", "UTF-8");
			stringData = stringData.substring(index, stringData.length());
			int beginIndex = stringData.indexOf("<jobId>");
			int endIndex = stringData.indexOf("</jobId>");
			String jobId = stringData.substring(beginIndex + 7, endIndex);
			String oneByOne = XmClientManager.getInstance().getValue(ONE_BY_ONE);
			if (oneByOne != null) {
				Object locker = XmClientManager.getLock(jobId);
				if (locker != null) {
					 synchronized (locker) {
						 locker.notify();
					 }
					 logger.info("Sucess notify to OneByOneInsertRequester!");
				}
			}			
			Long startTime = XmClientManager.getTimesMap().get(jobId);
			if (startTime != null) {
				PerformanceLogger.trace(CallbackWriter.class.getSimpleName(), "getCallbackResult", jobId, null, XmClientManager.getPriority(jobId), System.currentTimeMillis() - startTime.longValue());
			} else {
				PerformanceLogger.trace(CallbackWriter.class.getSimpleName(), "getCallbackResult", jobId, null, null, -1);
			}
			XmClientManager.getTimesMap().remove(jobId);
			XmClientManager.removeLock(jobId);
			XmClientManager.removePriority(jobId);
			String outputFullName = outPath + jobId + ".xml";
			try {
				in = new ByteArrayInputStream(stringData.getBytes("UTF-8"));					
				DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
				DocumentBuilder builder = factory.newDocumentBuilder();			
				Document document = builder.parse(in);
				document.setXmlStandalone(true);  
		    	Transformer tf = TransformerFactory.newInstance().newTransformer();
		    	tf.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
		    	tf.setOutputProperty(OutputKeys.METHOD, "xml");
		    	tf.setOutputProperty(OutputKeys.INDENT, "yes");
		    	tf.setOutputProperty(OutputKeys.STANDALONE, "yes");
		    	tf.setOutputProperty("{http://xml.apache.org/xslt}indent-amount","4");
				DOMSource source = new DOMSource(document);			
				File f = new File(outputFullName);
				 fileWriter  = new  FileWriter (f);	
				StreamResult result = new StreamResult(fileWriter);			
				tf.transform(source, result);	
				dOut.writeBytes("HTTP/1.1 200 OK\r\n");
				temp = null;			
				logger.info("Success received syncJob result, jobId={}", jobId);
			} catch (Exception e) {
				if (stringData != null) {
					FileUtil util = new FileUtil();
					util.saveStringToFile(stringData, outputFullName);
					dOut.writeBytes("HTTP/1.1 200 OK\r\n");
				}
			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
			try {
				dOut.writeBytes("HTTP/1.1 500 Server error!\r\n");
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		} finally {
			try {
				socket.close();
				bis.close();
				dOut.close();
				in.close();
				fileWriter.close();
			} catch (IOException e) {
				logger.error(e.getMessage(), e);
			}
		}
	}

	@Override
	public void run() {
		//writeResultToFile();
		writeResultToFileUsingDom();
		// writeXmlDataToFile();
		
	}
}
