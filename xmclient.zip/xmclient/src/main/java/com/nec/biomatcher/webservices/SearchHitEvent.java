
package com.nec.biomatcher.webservices;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for searchHitEvent complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="searchHitEvent">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="eventId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="compositeScore" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="rawScoreList" type="{http://webservices.biomatcher.nec.com/}searchRawScoreDto" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "searchHitEvent", propOrder = {
    "eventId",
    "compositeScore",
    "rawScoreList"
})
public class SearchHitEvent {

    protected String eventId;
    protected Integer compositeScore;
    @XmlElement(nillable = true)
    protected List<SearchRawScoreDto> rawScoreList;

    /**
     * Gets the value of the eventId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEventId() {
        return eventId;
    }

    /**
     * Sets the value of the eventId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEventId(String value) {
        this.eventId = value;
    }

    /**
     * Gets the value of the compositeScore property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getCompositeScore() {
        return compositeScore;
    }

    /**
     * Sets the value of the compositeScore property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setCompositeScore(Integer value) {
        this.compositeScore = value;
    }

    /**
     * Gets the value of the rawScoreList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the rawScoreList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRawScoreList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SearchRawScoreDto }
     * 
     * 
     */
    public List<SearchRawScoreDto> getRawScoreList() {
        if (rawScoreList == null) {
            rawScoreList = new ArrayList<SearchRawScoreDto>();
        }
        return this.rawScoreList;
    }

}
