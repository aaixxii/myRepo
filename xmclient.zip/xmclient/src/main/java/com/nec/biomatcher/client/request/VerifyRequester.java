package com.nec.biomatcher.client.request;

import static com.nec.biomatcher.client.common.XmClientConstants.JOB_RESULT_PATH_XML;
import static com.nec.biomatcher.client.common.XmClientConstants.VERIFY_JOB_TIMEOUT;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.biomatcher.client.logger.PerformanceLogger;
import com.nec.biomatcher.client.manager.XmClientManager;
import com.nec.biomatcher.client.request.creater.VerifyJobReqeustCreater;
import com.nec.biomatcher.client.util.JaxBUtil;
import com.nec.biomatcher.client.util.WsdlUtil;
import com.nec.biomatcher.webservices.BioJobStatus;
import com.nec.biomatcher.webservices.BioMatcherWebServiceInterface;
import com.nec.biomatcher.webservices.VerifyJobRequestDto;
import com.nec.biomatcher.webservices.VerifyJobResultDto;

public class VerifyRequester {
	private String jobId;	
	private String reqeustFileFullName;
	private long jobTimeOutLimit;
	private Integer priority;
	private static Logger logger = LoggerFactory.getLogger(VerifyRequester.class);

	
	public VerifyRequester(String requestFile) {
		this.reqeustFileFullName = requestFile;
	}
	
	public VerifyJobResultDto submitVerifyRequest() {
		VerifyJobResultDto jobResuslts = null;
		VerifyJobRequestDto verifyJobRequest = null;
		if (reqeustFileFullName == null && reqeustFileFullName.isEmpty()) {
			logger.warn("Reqeust file is null! skip...");
			return null;
		}
		VerifyJobReqeustCreater qc;
		try {
			BioMatcherWebServiceInterface xmWebService = WsdlUtil.getXmWebService();
			if (reqeustFileFullName.endsWith(".xml")) {
				JaxBUtil<VerifyJobRequestDto> jaxbUtil = new JaxBUtil<VerifyJobRequestDto>();
				verifyJobRequest = jaxbUtil.unmarshalFromFile(VerifyJobRequestDto.class,reqeustFileFullName);
			} else if (reqeustFileFullName.endsWith(".dat")) {
				qc = new VerifyJobReqeustCreater();
				verifyJobRequest = qc.buildVerifyJobRequest(reqeustFileFullName);
			} else {
				logger.warn("Request file is worng , it is not a xml or dat file. skip...");
			}			
			try {
				this.jobTimeOutLimit = verifyJobRequest.getJobTimeoutMill();
			} catch (Exception e) {
				this.jobTimeOutLimit = Long.parseLong(XmClientManager.getInstance().getValue(VERIFY_JOB_TIMEOUT));
			}
			this.priority = verifyJobRequest.getPriority().getValue();
			jobId = xmWebService.submitVerificationJob(verifyJobRequest);
			XmClientManager.putPriority(jobId, priority);
			long startTime = System.currentTimeMillis();
			XmClientManager.getTimesMap().put(jobId, Long.valueOf(startTime));
			jobResuslts = getVerifyJobResult(System.currentTimeMillis());
			qc = null;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return null;
		}
		return jobResuslts;		
		
	}
	
	@SuppressWarnings("static-access")
	public VerifyJobResultDto getVerifyJobResult(long startTime) {
		VerifyJobResultDto results = null;	
		try {
			Thread.currentThread().sleep(2000);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
				BioMatcherWebServiceInterface xmWebService = WsdlUtil.getXmWebService();
			while (System.currentTimeMillis() - startTime <= jobTimeOutLimit) {	
				if (xmWebService.getVerificationJobStatus(jobId).equals(BioJobStatus.PENDING)) continue;
				results = xmWebService.getVerificationJobResult(jobId);
				if (results != null  && results.getStatus() == BioJobStatus.COMPLETED) {					
					logger.info("SearchJobResult jobId:{}", results.getJobId());
					logger.info("SearchJobResult status:{}", results.getStatus().name());
					break;
				}				
			}			
			long usedTime = System.currentTimeMillis() - startTime;
			PerformanceLogger.trace(InquiryRequester.class.getSimpleName(), "submitVerifyRequest", jobId, null, this.priority, usedTime);
			if (results != null) {
				String resultXmlPath = XmClientManager.getInstance().getValue(JOB_RESULT_PATH_XML);
				resultXmlPath = resultXmlPath + "/" + jobId + ".xml";
				JaxBUtil<VerifyJobResultDto> jaxbUtil = new JaxBUtil<VerifyJobResultDto>();
				jaxbUtil.marshalToFile(VerifyJobResultDto.class, results, resultXmlPath);
			} else {
				logger.warn("Job result is empty, skip save to file. jobId={}", jobId);
			}
		} catch (Exception e) {
			//logger.error(e.getMessage(), e);
			return null;
		}
		return results;
	}	
}
