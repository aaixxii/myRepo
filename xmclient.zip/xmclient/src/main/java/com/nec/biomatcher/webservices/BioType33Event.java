
package com.nec.biomatcher.webservices;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for bioType33Event complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="bioType33Event">
 *   &lt;complexContent>
 *     &lt;extension base="{http://webservices.biomatcher.nec.com/}bioTemplateEvent">
 *       &lt;sequence>
 *         &lt;element name="algorithmType" type="{http://webservices.biomatcher.nec.com/}algorithmType" minOccurs="0"/>
 *         &lt;element name="feType" type="{http://webservices.biomatcher.nec.com/}bioFeType" minOccurs="0"/>
 *         &lt;element name="fingerInfoList" type="{http://webservices.biomatcher.nec.com/}bioFingerFeatureInfo" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "bioType33Event", propOrder = {
    "algorithmType",
    "feType",
    "fingerInfoList"
})
public class BioType33Event
    extends BioTemplateEvent
{

    protected AlgorithmType algorithmType;
    protected BioFeType feType;
    @XmlElement(nillable = true)
    protected List<BioFingerFeatureInfo> fingerInfoList;

    /**
     * Gets the value of the algorithmType property.
     * 
     * @return
     *     possible object is
     *     {@link AlgorithmType }
     *     
     */
    public AlgorithmType getAlgorithmType() {
        return algorithmType;
    }

    /**
     * Sets the value of the algorithmType property.
     * 
     * @param value
     *     allowed object is
     *     {@link AlgorithmType }
     *     
     */
    public void setAlgorithmType(AlgorithmType value) {
        this.algorithmType = value;
    }

    /**
     * Gets the value of the feType property.
     * 
     * @return
     *     possible object is
     *     {@link BioFeType }
     *     
     */
    public BioFeType getFeType() {
        return feType;
    }

    /**
     * Sets the value of the feType property.
     * 
     * @param value
     *     allowed object is
     *     {@link BioFeType }
     *     
     */
    public void setFeType(BioFeType value) {
        this.feType = value;
    }

    /**
     * Gets the value of the fingerInfoList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the fingerInfoList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFingerInfoList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link BioFingerFeatureInfo }
     * 
     * 
     */
    public List<BioFingerFeatureInfo> getFingerInfoList() {
        if (fingerInfoList == null) {
            fingerInfoList = new ArrayList<BioFingerFeatureInfo>();
        }
        return this.fingerInfoList;
    }

}
