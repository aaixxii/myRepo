package com.nec.biomatcher.client.manager;

import static com.nec.biomatcher.client.common.XmClientConstants.CLIENT_CALLBACK_PORT;
import static com.nec.biomatcher.client.common.XmClientConstants.CLINET_CALLBACK_PATH;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.biomatcher.client.util.CallbackWriter;

public class CallbackServer implements Runnable {
	private int callbackPort;
	private ServerSocket serverSocket;
	private String outPath;
	//private Object locker = new Object();

	private static Logger logger = LoggerFactory.getLogger("CallbackLogger");

	public CallbackServer() {
		try {
			outPath = XmClientManager.getInstance().getValue(CLINET_CALLBACK_PATH);
			outPath = outPath.endsWith("/") ? outPath : outPath + "/";
			callbackPort = Integer.valueOf(XmClientManager.getInstance().getValue(CLIENT_CALLBACK_PORT));
			serverSocket = new ServerSocket(callbackPort);
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
			logger.error("Faild to start CallbackServer!");
			System.exit(1);
		}
		logger.info("Calllback Server is started!");
	}

	@Override
	public void run() {
		while (true) {
			try {
				Socket socket = serverSocket.accept();
				logger.info("Megha is connectecd to me! ip:{}", socket.getRemoteSocketAddress());				
				CallbackWriter cw = new CallbackWriter(socket, outPath);
				XmClientManager.getInstance().commitCallbackJob(cw);
			} catch (Exception e) {
				logger.error(e.getMessage(), e);
			}
		}
	}
}
