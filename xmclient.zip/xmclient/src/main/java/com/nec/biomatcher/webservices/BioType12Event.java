
package com.nec.biomatcher.webservices;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for bioType12Event complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="bioType12Event">
 *   &lt;complexContent>
 *     &lt;extension base="{http://webservices.biomatcher.nec.com/}bioTemplateEvent">
 *       &lt;sequence>
 *         &lt;element name="irisRightQuality" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="irisLeftQuality" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="irisRightDeltaIdFeatureData" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/>
 *         &lt;element name="irisLeftDeltaIdFeatureData" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "bioType12Event", propOrder = {
    "irisRightQuality",
    "irisLeftQuality",
    "irisRightDeltaIdFeatureData",
    "irisLeftDeltaIdFeatureData"
})
public class BioType12Event
    extends BioTemplateEvent
{

    protected Integer irisRightQuality;
    protected Integer irisLeftQuality;
    protected byte[] irisRightDeltaIdFeatureData;
    protected byte[] irisLeftDeltaIdFeatureData;

    /**
     * Gets the value of the irisRightQuality property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getIrisRightQuality() {
        return irisRightQuality;
    }

    /**
     * Sets the value of the irisRightQuality property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setIrisRightQuality(Integer value) {
        this.irisRightQuality = value;
    }

    /**
     * Gets the value of the irisLeftQuality property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getIrisLeftQuality() {
        return irisLeftQuality;
    }

    /**
     * Sets the value of the irisLeftQuality property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setIrisLeftQuality(Integer value) {
        this.irisLeftQuality = value;
    }

    /**
     * Gets the value of the irisRightDeltaIdFeatureData property.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getIrisRightDeltaIdFeatureData() {
        return irisRightDeltaIdFeatureData;
    }

    /**
     * Sets the value of the irisRightDeltaIdFeatureData property.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setIrisRightDeltaIdFeatureData(byte[] value) {
        this.irisRightDeltaIdFeatureData = ((byte[]) value);
    }

    /**
     * Gets the value of the irisLeftDeltaIdFeatureData property.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getIrisLeftDeltaIdFeatureData() {
        return irisLeftDeltaIdFeatureData;
    }

    /**
     * Sets the value of the irisLeftDeltaIdFeatureData property.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setIrisLeftDeltaIdFeatureData(byte[] value) {
        this.irisLeftDeltaIdFeatureData = ((byte[]) value);
    }

}
