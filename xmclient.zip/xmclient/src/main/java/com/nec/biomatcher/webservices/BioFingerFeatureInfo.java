
package com.nec.biomatcher.webservices;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for bioFingerFeatureInfo complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="bioFingerFeatureInfo">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="fingerPosition" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="primaryPatternType" type="{http://webservices.biomatcher.nec.com/}patternType" minOccurs="0"/>
 *         &lt;element name="secondaryPatternType" type="{http://webservices.biomatcher.nec.com/}patternType" minOccurs="0"/>
 *         &lt;element name="quality" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="featureData" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "bioFingerFeatureInfo", propOrder = {
    "fingerPosition",
    "primaryPatternType",
    "secondaryPatternType",
    "quality",
    "featureData"
})
public class BioFingerFeatureInfo {

    protected int fingerPosition;
    protected PatternType primaryPatternType;
    protected PatternType secondaryPatternType;
    protected Integer quality;
    protected byte[] featureData;

    /**
     * Gets the value of the fingerPosition property.
     * 
     */
    public int getFingerPosition() {
        return fingerPosition;
    }

    /**
     * Sets the value of the fingerPosition property.
     * 
     */
    public void setFingerPosition(int value) {
        this.fingerPosition = value;
    }

    /**
     * Gets the value of the primaryPatternType property.
     * 
     * @return
     *     possible object is
     *     {@link PatternType }
     *     
     */
    public PatternType getPrimaryPatternType() {
        return primaryPatternType;
    }

    /**
     * Sets the value of the primaryPatternType property.
     * 
     * @param value
     *     allowed object is
     *     {@link PatternType }
     *     
     */
    public void setPrimaryPatternType(PatternType value) {
        this.primaryPatternType = value;
    }

    /**
     * Gets the value of the secondaryPatternType property.
     * 
     * @return
     *     possible object is
     *     {@link PatternType }
     *     
     */
    public PatternType getSecondaryPatternType() {
        return secondaryPatternType;
    }

    /**
     * Sets the value of the secondaryPatternType property.
     * 
     * @param value
     *     allowed object is
     *     {@link PatternType }
     *     
     */
    public void setSecondaryPatternType(PatternType value) {
        this.secondaryPatternType = value;
    }

    /**
     * Gets the value of the quality property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getQuality() {
        return quality;
    }

    /**
     * Sets the value of the quality property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setQuality(Integer value) {
        this.quality = value;
    }

    /**
     * Gets the value of the featureData property.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getFeatureData() {
        return featureData;
    }

    /**
     * Sets the value of the featureData property.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setFeatureData(byte[] value) {
        this.featureData = ((byte[]) value);
    }

}
