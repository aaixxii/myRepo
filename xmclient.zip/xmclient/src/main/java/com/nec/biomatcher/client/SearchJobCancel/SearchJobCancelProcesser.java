package com.nec.biomatcher.client.SearchJobCancel;

import static com.nec.biomatcher.client.common.XmClientConstants.SEARCH_JOB_TIMEOUT;

import java.util.Collections;
import java.util.Random;
import java.util.concurrent.CopyOnWriteArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.biomatcher.client.manager.XmClientManager;
import com.nec.biomatcher.client.request.creater.SearchJobReqeustCreater;
import com.nec.biomatcher.client.util.JaxBUtil;
import com.nec.biomatcher.client.util.WsdlUtil;
import com.nec.biomatcher.webservices.BioMatcherWebServiceInterface;
import com.nec.biomatcher.webservices.SearchJobRequestDto;

public class SearchJobCancelProcesser {
	private String searchJobCancelInfo;
	private String reqeustFileFullName;	
	private Integer searchJobCount;
	private Integer deleteCount;	
	private CopyOnWriteArrayList<String> searJobList = new  CopyOnWriteArrayList<>();
	private Random rand;

	private static Logger logger = LoggerFactory.getLogger(SearchJobCancelProcesser.class);
	
	public SearchJobCancelProcesser(String schCacelInfo, String fullReqeustFilePath) {
		this.searchJobCancelInfo = schCacelInfo;
		this.reqeustFileFullName = fullReqeustFilePath;	
		rand = new Random();
	}
	
	public void processSearchJobCanceling() {
		if (reqeustFileFullName == null && reqeustFileFullName.isEmpty()) {
			logger.warn("Reqeust file is null! skip...");
			return ;
		}
		if (searchJobCancelInfo == null || searchJobCancelInfo.isEmpty()) {
			logger.warn("searchJobCancelInfo is empty! skip...");
			return;			
		}		
		searchJobCount = Integer.parseInt(searchJobCancelInfo.split(",")[0].split(":")[1]);
		deleteCount = Integer.parseInt(searchJobCancelInfo.split(",")[1].split(":")[1]);
		
		SearchJobRequestDto searchJobRequestDto = new SearchJobRequestDto();
		try {
			BioMatcherWebServiceInterface xmWebService = WsdlUtil.getXmWebService();
			if (reqeustFileFullName.endsWith(".xml")) {
				JaxBUtil<SearchJobRequestDto> jaxbUtil = new JaxBUtil<SearchJobRequestDto>();				
				searchJobRequestDto = jaxbUtil.unmarshalFromFile(SearchJobRequestDto.class, reqeustFileFullName);
			} else if (reqeustFileFullName.endsWith(".dat")) {				
				SearchJobReqeustCreater creater = new SearchJobReqeustCreater();
				searchJobRequestDto = creater.buildSeachJobRequest(reqeustFileFullName);
			} else {
				logger.warn("Request file is worng , it is not a xml or dat file. skip...");
			}	
			for (int i = 0; i < searchJobCount; i++) {
				String jobId = xmWebService.submitSearchJob(searchJobRequestDto);
				searJobList.add(jobId);		
			}	
			 Collections.shuffle(searJobList);
			for (int i = 0; i < deleteCount; i++) {
				int deleteJobId = getRandomUderDeleteCount(deleteCount - i);
				xmWebService.deleteSearchJob(String.valueOf(deleteJobId));
			}						
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		}		
	}
	
	private int getRandomUderDeleteCount(int bound) {
		return rand.nextInt(bound);
	}
}
