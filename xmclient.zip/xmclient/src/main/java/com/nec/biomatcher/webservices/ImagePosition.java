
package com.nec.biomatcher.webservices;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for imagePosition.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="imagePosition">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="UNKNOWN"/>
 *     &lt;enumeration value="ROLL_RTHUMB"/>
 *     &lt;enumeration value="ROLL_RINDEX"/>
 *     &lt;enumeration value="ROLL_RMIDDLE"/>
 *     &lt;enumeration value="ROLL_RRING"/>
 *     &lt;enumeration value="ROLL_RLITTLE"/>
 *     &lt;enumeration value="ROLL_LTHUMB"/>
 *     &lt;enumeration value="ROLL_LINDEX"/>
 *     &lt;enumeration value="ROLL_LMIDDLE"/>
 *     &lt;enumeration value="ROLL_LRING"/>
 *     &lt;enumeration value="ROLL_LLITTLE"/>
 *     &lt;enumeration value="SLAP_RTHUMB"/>
 *     &lt;enumeration value="SLAP_LTHUMB"/>
 *     &lt;enumeration value="SLAP_RFOUR"/>
 *     &lt;enumeration value="SLAP_LFOUR"/>
 *     &lt;enumeration value="SLAP_THUMBS"/>
 *     &lt;enumeration value="SLAP_RINDEX"/>
 *     &lt;enumeration value="SLAP_RMIDDLE"/>
 *     &lt;enumeration value="SLAP_RRING"/>
 *     &lt;enumeration value="SLAP_RLITTLE"/>
 *     &lt;enumeration value="SLAP_LINDEX"/>
 *     &lt;enumeration value="SLAP_LMIDDLE"/>
 *     &lt;enumeration value="SLAP_LRING"/>
 *     &lt;enumeration value="SLAP_LLITTLE"/>
 *     &lt;enumeration value="PALM_UNKNOWN"/>
 *     &lt;enumeration value="PALM_RFULL"/>
 *     &lt;enumeration value="PALM_RWRITER"/>
 *     &lt;enumeration value="PALM_LFULL"/>
 *     &lt;enumeration value="PALM_LWRITER"/>
 *     &lt;enumeration value="PALM_RLOWER"/>
 *     &lt;enumeration value="PALM_RUPPER"/>
 *     &lt;enumeration value="PALM_LLOWER"/>
 *     &lt;enumeration value="PALM_LUPPER"/>
 *     &lt;enumeration value="PALM_ROTHER"/>
 *     &lt;enumeration value="PALM_LOTHER"/>
 *     &lt;enumeration value="PALM_RINTERDIGITAL"/>
 *     &lt;enumeration value="PALM_RTHENAR"/>
 *     &lt;enumeration value="PALM_RHYPOTHENAR"/>
 *     &lt;enumeration value="PALM_LINTERDIGITAL"/>
 *     &lt;enumeration value="PALM_LTHENAR"/>
 *     &lt;enumeration value="PALM_LHYPOTHENAR"/>
 *     &lt;enumeration value="FRONTAL_FACE"/>
 *     &lt;enumeration value="RIGHT_IRIS"/>
 *     &lt;enumeration value="LEFT_IRIS"/>
 *     &lt;enumeration value="PLANTAR_UNKNOWN"/>
 *     &lt;enumeration value="PLANTAR_RSOLE"/>
 *     &lt;enumeration value="PLANTAR_LSOLE"/>
 *     &lt;enumeration value="PLANTAR_UNKNOWN_TOE"/>
 *     &lt;enumeration value="PLANTAR_RBIG_TOE"/>
 *     &lt;enumeration value="PLANTAR_R2ND_TOE"/>
 *     &lt;enumeration value="PLANTAR_RMIDDLE_TOE"/>
 *     &lt;enumeration value="PLANTAR_R4TH_TOE"/>
 *     &lt;enumeration value="PLANTAR_RLITTLE_TOE"/>
 *     &lt;enumeration value="PLANTAR_LBIG_TOE"/>
 *     &lt;enumeration value="PLANTAR_L2ND_TOE"/>
 *     &lt;enumeration value="PLANTAR_LMIDDLE_TOE"/>
 *     &lt;enumeration value="PLANTAR_L4TH_TOE"/>
 *     &lt;enumeration value="PLANTAR_LLITTLE_TOE"/>
 *     &lt;enumeration value="PLANTAR_RFRONT"/>
 *     &lt;enumeration value="PLANTAR_RBACK"/>
 *     &lt;enumeration value="PLANTAR_LFRONT"/>
 *     &lt;enumeration value="PLANTAR_LBACK"/>
 *     &lt;enumeration value="PLANTAR_RMIDDLE"/>
 *     &lt;enumeration value="PLANTAR_LMIDDLE"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "imagePosition")
@XmlEnum
public enum ImagePosition {

    UNKNOWN("UNKNOWN"),
    ROLL_RTHUMB("ROLL_RTHUMB"),
    ROLL_RINDEX("ROLL_RINDEX"),
    ROLL_RMIDDLE("ROLL_RMIDDLE"),
    ROLL_RRING("ROLL_RRING"),
    ROLL_RLITTLE("ROLL_RLITTLE"),
    ROLL_LTHUMB("ROLL_LTHUMB"),
    ROLL_LINDEX("ROLL_LINDEX"),
    ROLL_LMIDDLE("ROLL_LMIDDLE"),
    ROLL_LRING("ROLL_LRING"),
    ROLL_LLITTLE("ROLL_LLITTLE"),
    SLAP_RTHUMB("SLAP_RTHUMB"),
    SLAP_LTHUMB("SLAP_LTHUMB"),
    SLAP_RFOUR("SLAP_RFOUR"),
    SLAP_LFOUR("SLAP_LFOUR"),
    SLAP_THUMBS("SLAP_THUMBS"),
    SLAP_RINDEX("SLAP_RINDEX"),
    SLAP_RMIDDLE("SLAP_RMIDDLE"),
    SLAP_RRING("SLAP_RRING"),
    SLAP_RLITTLE("SLAP_RLITTLE"),
    SLAP_LINDEX("SLAP_LINDEX"),
    SLAP_LMIDDLE("SLAP_LMIDDLE"),
    SLAP_LRING("SLAP_LRING"),
    SLAP_LLITTLE("SLAP_LLITTLE"),
    PALM_UNKNOWN("PALM_UNKNOWN"),
    PALM_RFULL("PALM_RFULL"),
    PALM_RWRITER("PALM_RWRITER"),
    PALM_LFULL("PALM_LFULL"),
    PALM_LWRITER("PALM_LWRITER"),
    PALM_RLOWER("PALM_RLOWER"),
    PALM_RUPPER("PALM_RUPPER"),
    PALM_LLOWER("PALM_LLOWER"),
    PALM_LUPPER("PALM_LUPPER"),
    PALM_ROTHER("PALM_ROTHER"),
    PALM_LOTHER("PALM_LOTHER"),
    PALM_RINTERDIGITAL("PALM_RINTERDIGITAL"),
    PALM_RTHENAR("PALM_RTHENAR"),
    PALM_RHYPOTHENAR("PALM_RHYPOTHENAR"),
    PALM_LINTERDIGITAL("PALM_LINTERDIGITAL"),
    PALM_LTHENAR("PALM_LTHENAR"),
    PALM_LHYPOTHENAR("PALM_LHYPOTHENAR"),
    FRONTAL_FACE("FRONTAL_FACE"),
    RIGHT_IRIS("RIGHT_IRIS"),
    LEFT_IRIS("LEFT_IRIS"),
    PLANTAR_UNKNOWN("PLANTAR_UNKNOWN"),
    PLANTAR_RSOLE("PLANTAR_RSOLE"),
    PLANTAR_LSOLE("PLANTAR_LSOLE"),
    PLANTAR_UNKNOWN_TOE("PLANTAR_UNKNOWN_TOE"),
    PLANTAR_RBIG_TOE("PLANTAR_RBIG_TOE"),
    @XmlEnumValue("PLANTAR_R2ND_TOE")
    PLANTAR_R_2_ND_TOE("PLANTAR_R2ND_TOE"),
    PLANTAR_RMIDDLE_TOE("PLANTAR_RMIDDLE_TOE"),
    @XmlEnumValue("PLANTAR_R4TH_TOE")
    PLANTAR_R_4_TH_TOE("PLANTAR_R4TH_TOE"),
    PLANTAR_RLITTLE_TOE("PLANTAR_RLITTLE_TOE"),
    PLANTAR_LBIG_TOE("PLANTAR_LBIG_TOE"),
    @XmlEnumValue("PLANTAR_L2ND_TOE")
    PLANTAR_L_2_ND_TOE("PLANTAR_L2ND_TOE"),
    PLANTAR_LMIDDLE_TOE("PLANTAR_LMIDDLE_TOE"),
    @XmlEnumValue("PLANTAR_L4TH_TOE")
    PLANTAR_L_4_TH_TOE("PLANTAR_L4TH_TOE"),
    PLANTAR_LLITTLE_TOE("PLANTAR_LLITTLE_TOE"),
    PLANTAR_RFRONT("PLANTAR_RFRONT"),
    PLANTAR_RBACK("PLANTAR_RBACK"),
    PLANTAR_LFRONT("PLANTAR_LFRONT"),
    PLANTAR_LBACK("PLANTAR_LBACK"),
    PLANTAR_RMIDDLE("PLANTAR_RMIDDLE"),
    PLANTAR_LMIDDLE("PLANTAR_LMIDDLE");
    private final String value;

    ImagePosition(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ImagePosition fromValue(String v) {
        for (ImagePosition c: ImagePosition.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
