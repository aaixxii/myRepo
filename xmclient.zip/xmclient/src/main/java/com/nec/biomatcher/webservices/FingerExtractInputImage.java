
package com.nec.biomatcher.webservices;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for fingerExtractInputImage complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="fingerExtractInputImage">
 *   &lt;complexContent>
 *     &lt;extension base="{http://webservices.biomatcher.nec.com/}extractInputImage">
 *       &lt;sequence>
 *         &lt;element name="images" type="{http://webservices.biomatcher.nec.com/}image" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="extractionParameters" type="{http://webservices.biomatcher.nec.com/}extractInputParameter" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "fingerExtractInputImage", propOrder = {
    "images",
    "extractionParameters"
})
public class FingerExtractInputImage
    extends ExtractInputImage
{

    @XmlElement(nillable = true)
    protected List<Image> images;
    @XmlElement(nillable = true)
    protected List<ExtractInputParameter> extractionParameters;

    /**
     * Gets the value of the images property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the images property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getImages().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Image }
     * 
     * 
     */
    public List<Image> getImages() {
        if (images == null) {
            images = new ArrayList<Image>();
        }
        return this.images;
    }

    /**
     * Gets the value of the extractionParameters property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the extractionParameters property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getExtractionParameters().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ExtractInputParameter }
     * 
     * 
     */
    public List<ExtractInputParameter> getExtractionParameters() {
        if (extractionParameters == null) {
            extractionParameters = new ArrayList<ExtractInputParameter>();
        }
        return this.extractionParameters;
    }

}
