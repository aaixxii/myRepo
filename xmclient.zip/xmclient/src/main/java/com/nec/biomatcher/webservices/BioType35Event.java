
package com.nec.biomatcher.webservices;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for bioType35Event complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="bioType35Event">
 *   &lt;complexContent>
 *     &lt;extension base="{http://webservices.biomatcher.nec.com/}bioTemplateEvent">
 *       &lt;sequence>
 *         &lt;element name="isRolledFlag" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="matchConfig" type="{http://www.w3.org/2001/XMLSchema}byte"/>
 *         &lt;element name="fingerQualities" type="{http://www.w3.org/2001/XMLSchema}int" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="cmlFeatureData" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "bioType35Event", propOrder = {
    "isRolledFlag",
    "matchConfig",
    "fingerQualities",
    "cmlFeatureData"
})
public class BioType35Event
    extends BioTemplateEvent
{

    protected Boolean isRolledFlag;
    protected byte matchConfig;
    @XmlElement(nillable = true)
    protected List<Integer> fingerQualities;
    protected byte[] cmlFeatureData;

    /**
     * Gets the value of the isRolledFlag property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsRolledFlag() {
        return isRolledFlag;
    }

    /**
     * Sets the value of the isRolledFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsRolledFlag(Boolean value) {
        this.isRolledFlag = value;
    }

    /**
     * Gets the value of the matchConfig property.
     * 
     */
    public byte getMatchConfig() {
        return matchConfig;
    }

    /**
     * Sets the value of the matchConfig property.
     * 
     */
    public void setMatchConfig(byte value) {
        this.matchConfig = value;
    }

    /**
     * Gets the value of the fingerQualities property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the fingerQualities property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFingerQualities().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Integer }
     * 
     * 
     */
    public List<Integer> getFingerQualities() {
        if (fingerQualities == null) {
            fingerQualities = new ArrayList<Integer>();
        }
        return this.fingerQualities;
    }

    /**
     * Gets the value of the cmlFeatureData property.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getCmlFeatureData() {
        return cmlFeatureData;
    }

    /**
     * Sets the value of the cmlFeatureData property.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setCmlFeatureData(byte[] value) {
        this.cmlFeatureData = ((byte[]) value);
    }

}
