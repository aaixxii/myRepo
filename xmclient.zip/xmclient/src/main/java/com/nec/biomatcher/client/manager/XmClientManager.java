package com.nec.biomatcher.client.manager;

import static com.nec.biomatcher.client.common.XmClientConstants.CIRCLE_THREAD_CURRENET_COUNT;
import static com.nec.biomatcher.client.common.XmClientConstants.CLIENT_CALLBACK_IP;
import static com.nec.biomatcher.client.common.XmClientConstants.CLIENT_CALLBACK_PORT;
import static com.nec.biomatcher.client.common.XmClientConstants.CLINET_CALLBACK_PATH;
import static com.nec.biomatcher.client.common.XmClientConstants.JOB_REQUEST_PATH;
import static com.nec.biomatcher.client.common.XmClientConstants.JOB_RESULT_PATH_XLSX;
import static com.nec.biomatcher.client.common.XmClientConstants.JOB_RESULT_PATH_XML;
import static com.nec.biomatcher.client.common.XmClientConstants.JOB_TEMPLATES_PATH;
import static com.nec.biomatcher.client.common.XmClientConstants.MEGHA_CONTEXT_NAME;
import static com.nec.biomatcher.client.common.XmClientConstants.MEGHA_WSDL_PATTEN;
import static com.nec.biomatcher.client.common.XmClientConstants.ONE_BY_ONE;
import static com.nec.biomatcher.client.common.XmClientConstants.ONE_CIRCLE_JOB_COUNT;
import static com.nec.biomatcher.client.common.XmClientConstants.PRIORITY_JOB;
import static com.nec.biomatcher.client.common.XmClientConstants.SEARCH_JOB_CANCEL_INFO;
import static com.nec.biomatcher.client.common.XmClientConstants.PROPERTY_FULL_NAME;
import static com.nec.biomatcher.client.common.XmClientConstants.SEARCH_JOB_TIMEOUT;
import static com.nec.biomatcher.client.common.XmClientConstants.SERVER_ID;
import static com.nec.biomatcher.client.common.XmClientConstants.SERVER_PORT;
import static com.nec.biomatcher.client.common.XmClientConstants.WSDL_URL;
import static com.nec.biomatcher.client.common.XmClientConstants.XM_SERVICE_NAME;

import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import org.apache.log4j.PropertyConfigurator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.biomatcher.client.properties.PropertyNames;
import com.nec.biomatcher.client.properties.PropertyUtil;
import com.nec.biomatcher.client.util.ClientUtil;

public class XmClientManager {
	public static final XmClientManager manager = new XmClientManager();
	private static final ConcurrentHashMap<String, String> keyValueMap = new ConcurrentHashMap<>();
	private static Logger logger = LoggerFactory.getLogger(XmClientManager.class);
	private ExecutorService clientExecutor;	
	private ExecutorService callbacExecutor;	
	private static final Random sRandom = new Random(System.currentTimeMillis());
	
	private static final ConcurrentHashMap<String, Long> timesMap = new ConcurrentHashMap<>();
	private static final ConcurrentHashMap<String, Integer> priorityMap = new ConcurrentHashMap<>();
	private static final ConcurrentHashMap<String, Object> lockerMap = new ConcurrentHashMap<>();
	private static final Lock timesMapLock = new ReentrantLock();

	public XmClientManager() {
		clientExecutor = Executors.newCachedThreadPool();
		callbacExecutor = Executors.newCachedThreadPool();
		
//		ThreadPoolExecutor executor = 
//				new ThreadPoolExecutor(0, Integer.MAX_VALUE, 60L, TimeUnit.SECONDS,
//				new LinkedBlockingQueue<Runnable>());
				
	}
	
	public static Object getLock(String jobId) {
		if (jobId == null) {
			return null;
		} else {
			return lockerMap.get(jobId);
		}
	}
	
	public static void putLocker(String jobId, Object locker) {
		if (jobId != null && locker != null) {
			lockerMap.put(jobId, locker);
		}
	}
	
	public static void removeLock(String jobId) {
		if (jobId != null) {
			lockerMap.remove(jobId);
		}
	}	
	
	public static ConcurrentHashMap<String, Long> getTimesMap() {
		timesMapLock.lock();
		try {
			return timesMap;
		} finally {
			timesMapLock.unlock();
		}
	}

	public static XmClientManager getInstance() {
		return manager;
	}

	public void commitJob(Runnable task) {
		clientExecutor.submit(task);
	}
	
	public void commitCallbackJob(Runnable task) {
		callbacExecutor.submit(task);
	}
	
	public int getMapSize() {
		return keyValueMap.size();
	}

	public void putData(String key, String value) {
		keyValueMap.putIfAbsent(key, value);
	}

	public String getValue(String key) {
		return keyValueMap.get(key);
	}
	
	public static void  putPriority(String jobId, Integer priroty) {
		priorityMap.putIfAbsent(jobId, priroty);
	}
	
	public static Integer getPriority(String jobId) {
		return priorityMap.get(jobId);
	}
	
	public static void removePriority(String jobId) {
		priorityMap.remove(jobId);
	}
	
	public void getBasePath() {
		String properyFullPath = null;
		String jobReqeustPath = null;
		String templatesPath = null;
		String jobresultPathXml = null;		
		String jobresultPathXlsx = null;
		String callbackpath = null;
		String loggerPath = null;		
		
		String myPath = XmClientManager.class.getProtectionDomain().getCodeSource().getLocation().getPath();
		String xmBaseDir = myPath.substring(0, myPath.length() - 16);
		xmBaseDir = xmBaseDir.endsWith("/") ? xmBaseDir.substring(0,xmBaseDir.length() - 1) : xmBaseDir;
		properyFullPath = xmBaseDir + "/" + "config" + "/" + "xm.client.properties";
		loggerPath =  xmBaseDir + "/" + "config" + "/" + "log4j.properties";		
		jobReqeustPath = xmBaseDir + "/" + "jobrequests";
		templatesPath = xmBaseDir + "/" + "templates";
		jobresultPathXml = xmBaseDir + "/" + "jobresults" + "/" + "xml";		
		jobresultPathXlsx = xmBaseDir + "/" + "jobresults" + "/" + "xlsx";
		callbackpath =  xmBaseDir + "/" + "callbackpath";
		PropertyConfigurator.configure(loggerPath);
		
//		File file = new File(jarPath).getParentFile().getParentFile();
		
		keyValueMap.putIfAbsent(PROPERTY_FULL_NAME, properyFullPath);
		keyValueMap.putIfAbsent(JOB_REQUEST_PATH, jobReqeustPath);
		keyValueMap.putIfAbsent(JOB_RESULT_PATH_XML, jobresultPathXml);
		keyValueMap.putIfAbsent(JOB_RESULT_PATH_XLSX, jobresultPathXlsx);
		keyValueMap.putIfAbsent(CLINET_CALLBACK_PATH, callbackpath);
		keyValueMap.putIfAbsent(JOB_TEMPLATES_PATH, templatesPath);
	}
	
	public String buildMehgaUrl(String meghaIds, String ports) {
		int serverIpCount = meghaIds.split(",").length;
		int serverPortCount = ports.split(",").length;		
		if (serverIpCount != serverPortCount) {	
			logger.error("There are miss in xm.client.properties file, the count of MEGHA_WS_IP_ADDRESS is not equal the count of MEGHA_WS_PORT_NUM");
			return null;
		}		
		String[] serIps = new String[serverIpCount];
		String[] serPorts = new String[serverIpCount];
		
		for (int i = 0; i < serverIpCount; i++) {
			int ipIndex = meghaIds.indexOf(",");
			if (ipIndex < 0) {
				serIps[i] = meghaIds;
			} else {
				String ip = meghaIds.substring(0, ipIndex);
				serIps[i] = ip;
				meghaIds = meghaIds.substring(ipIndex + 1, meghaIds.length());				
			}			
			int portIndex = ports.indexOf(",");
			if (portIndex < 0) {
				serPorts[i] = ports;				
			} else {
				String port = ports.substring(0, portIndex);
				serPorts[i] = port;	
				ports = ports.substring(portIndex + 1, ports.length());
				}			
			}
		int pickUp = sRandom.nextInt(serverIpCount);
		return serIps[pickUp] + ":" + serPorts[pickUp];		
		}	

	public boolean getAllProperties() {
		getBasePath();
		String propertyFileFullName = keyValueMap.get(PROPERTY_FULL_NAME);	
		try {
			PropertyUtil util = new PropertyUtil(propertyFileFullName);
			String serverIds = util.getPropertyValue(PropertyNames.MEGHA_WS_IP_ADDRESS.name());
			String serverPorts = util.getPropertyValue(PropertyNames.MEGHA_WS_PORT_NUM.name());	
			
			String callbackPort = util.getPropertyValue(PropertyNames.CLIENT_CALLBACK_PORT.name());
			String callbackIp = util.getPropertyValue(PropertyNames.CLIENT_CALLBACK_IP.name());
			if (serverIds == null || serverPorts == null || serverIds.isEmpty() || serverPorts.isEmpty()) {
				String error = "There are miss in xm.client.properties is! serverId or port is empty!";
				logger.error(error);
				return false;
			}
			String useMehgaIpAndPort = buildMehgaUrl(serverIds, serverPorts);
			if (useMehgaIpAndPort == null || useMehgaIpAndPort.isEmpty()) {
				return false;
			}
			int idx = useMehgaIpAndPort.indexOf(":");
			String serverId = useMehgaIpAndPort.substring(0, idx);
			String serverPort = useMehgaIpAndPort.substring(idx + 1, useMehgaIpAndPort.length());
			ClientUtil cu = new ClientUtil();
			if (!cu.checkIP(serverId)) {
				logger.error("Server ip is incorrect! ip:" + serverId);
				return false;
			}
			String circleThreadCurrentCount = util.getPropertyValue(PropertyNames.CIRCLE_THREAD_CURRENET_COUNT.name());
			String oneCircleJobCount = util.getPropertyValue(PropertyNames.ONE_CIRCLE_JOB_COUNT.name());			
			String jobTimeout = util.getPropertyValue(PropertyNames.CLIENT_JOB_TIME_OUT.name());
			String oneByOne = util.getPropertyValue(PropertyNames.ONE_BY_ONE.name());
			String prioryJobInfo = util.getPropertyValue(PropertyNames.PRIORITY_JOB.name());
			String searchJobCancelInfo = util.getPropertyValue(PropertyNames.SEARCH_JOB_CANCEL_INFO.name());

			if (circleThreadCurrentCount == null || circleThreadCurrentCount.isEmpty()) {
				circleThreadCurrentCount = "5";
			}
			
			if (oneCircleJobCount == null || oneCircleJobCount.isEmpty()) {
				oneCircleJobCount = "100";
			}
			
			if (jobTimeout == null || jobTimeout.isEmpty()) {
				jobTimeout = "5000";
			}			
			String wsdlUrl = "http://" + serverId + ":" + serverPort;
			wsdlUrl = wsdlUrl.endsWith("/") ? wsdlUrl : wsdlUrl + "/";
			wsdlUrl = wsdlUrl + MEGHA_CONTEXT_NAME + XM_SERVICE_NAME + MEGHA_WSDL_PATTEN;

			keyValueMap.putIfAbsent(WSDL_URL, wsdlUrl);
			keyValueMap.putIfAbsent(SERVER_ID, serverId);
			keyValueMap.putIfAbsent(SERVER_PORT, serverPort);
			keyValueMap.putIfAbsent(CIRCLE_THREAD_CURRENET_COUNT, circleThreadCurrentCount);
			keyValueMap.putIfAbsent(ONE_CIRCLE_JOB_COUNT, oneCircleJobCount);
			keyValueMap.putIfAbsent(SEARCH_JOB_TIMEOUT, jobTimeout);
			keyValueMap.putIfAbsent(CLIENT_CALLBACK_PORT, callbackPort);
			keyValueMap.putIfAbsent(CLIENT_CALLBACK_IP, callbackIp);
			keyValueMap.putIfAbsent(ONE_BY_ONE, oneByOne);
			keyValueMap.putIfAbsent(PRIORITY_JOB, prioryJobInfo);
			keyValueMap.putIfAbsent(SEARCH_JOB_CANCEL_INFO, searchJobCancelInfo);	
			return true;
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			return false;
		}
	}

	public void shutdown() {		
		clientExecutor.shutdown();
		callbacExecutor.shutdown();
		keyValueMap.clear();
	}
}
