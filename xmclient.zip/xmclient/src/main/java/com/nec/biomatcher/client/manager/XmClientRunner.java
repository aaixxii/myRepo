package com.nec.biomatcher.client.manager;

import static com.nec.biomatcher.client.common.XmClientConstants.CIRCLE_THREAD_CURRENET_COUNT;
import static com.nec.biomatcher.client.common.XmClientConstants.EXTRACT_JOB_START_WITH;
import static com.nec.biomatcher.client.common.XmClientConstants.JOB_REQUEST_PATH;
import static com.nec.biomatcher.client.common.XmClientConstants.JOB_TEMPLATES_PATH;
import static com.nec.biomatcher.client.common.XmClientConstants.ONE_BY_ONE;
import static com.nec.biomatcher.client.common.XmClientConstants.ONE_CIRCLE_JOB_COUNT;
import static com.nec.biomatcher.client.common.XmClientConstants.PRIORITY_JOB;
import static com.nec.biomatcher.client.common.XmClientConstants.SEARCH_JOB_CANCEL_INFO;
import static com.nec.biomatcher.client.common.XmClientConstants.SEARCH_JOB_START_WITH;
import static com.nec.biomatcher.client.common.XmClientConstants.SYNC_DELETE_START_WITH;
import static com.nec.biomatcher.client.common.XmClientConstants.SYNC_INSERT_START_WITH;
import static com.nec.biomatcher.client.common.XmClientConstants.SYNC_UPDATE_START_WITH;
import static com.nec.biomatcher.client.common.XmClientConstants.VERIFY_JOB_START_WITH;

import java.io.File;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.biomatcher.client.priority.ProrityJobProcesser;
import com.nec.biomatcher.client.request.OneByOneInsertRequester;

public class XmClientRunner {
	private static final XmClientRunner INSTANCE = new XmClientRunner();
	private boolean mustRun = true;
	private static Logger logger = LoggerFactory.getLogger(XmClientRunner.class);

	public XmClientRunner() {
	}

	public static XmClientRunner getInstance() {
		return INSTANCE;
	}

	public void run() {
		XmClientManager manager = XmClientManager.getInstance();
		String oneByOne = manager.getValue(ONE_BY_ONE);
		String reqeustPath = manager.getValue(JOB_REQUEST_PATH);	
		int circleThreadCurrentCount = Integer.parseInt(manager.getValue(CIRCLE_THREAD_CURRENET_COUNT));
		int oneCircleJobCount = Integer.parseInt(manager.getValue(ONE_CIRCLE_JOB_COUNT));
		String priorityJobInfo = manager.getValue(PRIORITY_JOB);
		String searchJobCancelInfo = manager.getValue(SEARCH_JOB_CANCEL_INFO);
		while (mustRun) {
			if (priorityJobInfo != "-1" && priorityJobInfo.length() > 3) {	
				String temPath = manager.getValue(JOB_TEMPLATES_PATH);
				ProrityJobProcesser parser = new ProrityJobProcesser(priorityJobInfo, temPath);
				parser.parsePrirotyJobInfo();				
				return;
			}			
			try {
				File file = new File(reqeustPath);
				if (file.isDirectory()) {
					if (file.listFiles(fileNameFilter).length == 0) {
						logger.error("No reqeust data to run!");
						mustRun = false;
						return;
					}
					int fileCount = file.listFiles(fileNameFilter).length;
					if (fileCount == 1) {					
						File[] jobRequest = file.listFiles(fileNameFilter);
						if (jobRequest[0].isFile()) {
							if (oneByOne != null && Integer.valueOf(oneByOne) > 0) {
								OneByOneInsertRequester runner = new OneByOneInsertRequester(jobRequest[0].getAbsolutePath(), Integer.valueOf(oneByOne));
								runner.submitSyncInsertJob();								
							} else if (searchJobCancelInfo != "-1") {
								//ToDo
							 				
							} else {
								for (int i = 0; i < circleThreadCurrentCount; i++) {
									Runnable toBeSubmitJob = generateReqeust(oneCircleJobCount, jobRequest[0]);								
									manager.commitJob(toBeSubmitJob);
								}
							}				
						}	
						mustRun = false;
					} else if (fileCount > 1) {
						File[] datFiles = file.listFiles(datNameFilter);
						File[] xmlFiles = file.listFiles(xmlNameFilter);
						if (datFiles.length > 0) {
							for (File one : datFiles) {
								if (one.exists() && one.isFile()) {	
									if (oneByOne != null && Integer.valueOf(oneByOne) > 0) {
										OneByOneInsertRequester runner = new OneByOneInsertRequester(one.getAbsolutePath(), Integer.valueOf(1));
										runner.submitSyncInsertJob();
									} else {
										Runnable toBeSubmitJob = generateReqeust(1, one);	
										if (toBeSubmitJob != null) {
											manager.commitJob(toBeSubmitJob);
										}											
									}
								
								}
							}
						}

						if (xmlFiles.length > 0) {
							for (File one : xmlFiles) {								
								if (one.exists() && one.isFile()) {	
									if (oneByOne != null && Integer.valueOf(oneByOne) > 0) {
										OneByOneInsertRequester runner = new OneByOneInsertRequester(one.getAbsolutePath(), Integer.valueOf(1));
										runner.submitSyncInsertJob();
									} else {
										Runnable myJob = generateReqeust(1, one);									
										manager.commitJob(myJob);
									}									
								}
							}
						}
						mustRun = false;
					}
				} else {
					logger.error("There are some worng in setting of reqeustPath, it is not a folder! skip process!");
					mustRun = false;
					return;
				}

			} catch (Exception e) {
				e.printStackTrace();
				logger.error(e.getMessage(), e);
			}
		}
	}	

	private Runnable generateReqeust(int oneCircleJobCount, File file) {
		Runnable circleJob = null;
		String simpleFileName = file.getName().toLowerCase();
		if (simpleFileName == null || simpleFileName.isEmpty()) {
			return circleJob;
		}			
		if (simpleFileName.startsWith(SEARCH_JOB_START_WITH)) {
			circleJob = new OneCircleSearchRunner(oneCircleJobCount, file.getAbsolutePath());
		} else if (simpleFileName.startsWith(VERIFY_JOB_START_WITH)) {
			circleJob = new OneCircleVerifyRunner(oneCircleJobCount, file.getAbsolutePath());
		} else if (simpleFileName.startsWith(EXTRACT_JOB_START_WITH)) {
			circleJob = new OneCircleExtractRunner(oneCircleJobCount, file.getAbsolutePath());
		} else if (simpleFileName.startsWith(SYNC_INSERT_START_WITH)) {
			circleJob = new OneCircleSyncInsertRunner(oneCircleJobCount, file.getAbsolutePath());			
		} else if (simpleFileName.startsWith(SYNC_DELETE_START_WITH)) {
			circleJob = new OneCircleSyncDeleteRunner(oneCircleJobCount, file.getAbsolutePath());
		} else if (simpleFileName.startsWith(SYNC_UPDATE_START_WITH)) {
			circleJob = new OneCircleSyncUpdateRunner(oneCircleJobCount, file.getAbsolutePath());
		} else {
			logger.warn("Request Job is not suported. skip...");
			printRequestFileRule() ;
			mustRun = false;
		}
		return circleJob;
	}	

	public boolean isMustRun() {
		return mustRun;
	}

	public void setMustRun(boolean mustRun) {
		this.mustRun = mustRun;
	}

	FilenameFilter fileNameFilter = new FilenameFilter() {
		@Override
		public boolean accept(File dir, String name) {
			if (name.lastIndexOf('.') > 0) {
				int lastIndex = name.lastIndexOf('.');
				String str = name.substring(lastIndex);				
				if (str.equals(".xml") || str.equals(".dat")) {
					return true;
				}
			}
			return false;
		}
	};

	FilenameFilter xmlNameFilter = new FilenameFilter() {
		@Override
		public boolean accept(File dir, String name) {
			if (name.lastIndexOf('.') > 0) {
				int lastIndex = name.lastIndexOf('.');
				String str = name.substring(lastIndex);				
				if (str.equals(".xml")) {
					return true;
				}
			}
			return false;
		}
	};

	FilenameFilter datNameFilter = new FilenameFilter() {
		@Override
		public boolean accept(File dir, String name) {
			if (name.lastIndexOf('.') > 0) {
				int lastIndex = name.lastIndexOf('.');
				String str = name.substring(lastIndex);				
				if (str.equals(".dat")) {
					return true;
				}
			}
			return false;
		}
	};
	
	@SuppressWarnings("unused")
	private void generateReqeustList(XmClientManager manager, int oneCircleJobCount, File[] files) {
		List<File> searchRequestFiles = new ArrayList<>();
		List<File> syncInsertFiles = new ArrayList<>();
		for (File one : files) {
			if (!one.exists() || !one.isFile())
				return;
			String simpleFileName = one.getName().toLowerCase();
			if (simpleFileName.startsWith(SEARCH_JOB_START_WITH)) {
				searchRequestFiles.add(one);
			} else if (simpleFileName.startsWith(VERIFY_JOB_START_WITH)) {
				// Todo
			} else if (simpleFileName.startsWith(EXTRACT_JOB_START_WITH)) {
				// Todo
			} else if (simpleFileName.startsWith(SYNC_INSERT_START_WITH)) {
				syncInsertFiles.add(one);
			} else if (simpleFileName.startsWith(SYNC_DELETE_START_WITH)) {
				// Todo
			} else if (simpleFileName.startsWith(SYNC_UPDATE_START_WITH)) {
				// Todo
			}
		}
		
		int searchCount = searchRequestFiles.size();
		if (searchCount <= oneCircleJobCount) {
			File[] arrays = new File[searchCount];
			searchRequestFiles.toArray(arrays);
			OneCircleSyncInsertRunner circleJob = new OneCircleSyncInsertRunner(arrays);
			manager.commitJob(circleJob);
		} else {
			while (searchCount >= oneCircleJobCount) {
				List<File> tmp = searchRequestFiles.subList(0, oneCircleJobCount);
				File[] arrFils = new File[tmp.size()];
				searchRequestFiles.toArray(arrFils);
				searchRequestFiles.removeAll(tmp);
				OneCircleSyncInsertRunner circleJob = new OneCircleSyncInsertRunner(arrFils);
				manager.commitJob(circleJob);
				searchCount = searchCount - oneCircleJobCount;				
			}			
			if (searchRequestFiles.size() > 0) {
				File[] arrays = new File[searchRequestFiles.size()];
				searchRequestFiles.toArray(arrays);
				OneCircleSyncInsertRunner circleJob = new OneCircleSyncInsertRunner(arrays);
				manager.commitJob(circleJob);
			}			
		}		
	}
	
	@SuppressWarnings("unused")
	private File foundXml(File[] fileList, String prefix) {
		for (int i = 0; i < fileList.length; i++) {
			File file = fileList[i];
			String tmp = file.getName();
			if (tmp.startsWith(prefix)) {
				return file;
			}
		}
		return null;
	}
	
	private void printRequestFileRule() {
		String lineSeparater = System.getProperties().getProperty("line.separator");
		StringBuilder sb = new StringBuilder();
		sb.append("xm client request file rule:");
		sb.append(lineSeparater);
		sb.append("Sync insert job must start with:" + SYNC_INSERT_START_WITH);
		sb.append(lineSeparater);
		sb.append("Sync insert job must start with:" + SYNC_INSERT_START_WITH);
		sb.append(lineSeparater);
		sb.append("Sync delete job must start with:" + SYNC_DELETE_START_WITH);
		sb.append(lineSeparater);
		sb.append("Sync update job must start with:" + SYNC_UPDATE_START_WITH);
		sb.append(lineSeparater);
		sb.append("Search job must start with:" + SEARCH_JOB_START_WITH);
		sb.append(lineSeparater);
		sb.append("Extract job must start with:" + EXTRACT_JOB_START_WITH);
		sb.append(lineSeparater);
		sb.append("Verify job must start with:" + VERIFY_JOB_START_WITH);
		logger.info(sb.toString());	
	}
}
