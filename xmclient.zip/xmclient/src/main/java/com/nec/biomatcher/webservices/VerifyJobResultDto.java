
package com.nec.biomatcher.webservices;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for verifyJobResultDto complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="verifyJobResultDto">
 *   &lt;complexContent>
 *     &lt;extension base="{http://webservices.biomatcher.nec.com/}bioMatcherJobResult">
 *       &lt;sequence>
 *         &lt;element name="jobId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="candidateResultList" type="{http://webservices.biomatcher.nec.com/}verifyCandidateResult" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="probeInfoList" type="{http://webservices.biomatcher.nec.com/}probeInfoDto" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="errorList" type="{http://webservices.biomatcher.nec.com/}errorMessageDto" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="featureData" type="{http://webservices.biomatcher.nec.com/}featureData" minOccurs="0"/>
 *         &lt;element name="status" type="{http://webservices.biomatcher.nec.com/}bioJobStatus" minOccurs="0"/>
 *         &lt;element name="jobMode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "verifyJobResultDto", propOrder = {
    "jobId",
    "candidateResultList",
    "probeInfoList",
    "errorList",
    "featureData",
    "status",
    "jobMode"
})
public class VerifyJobResultDto
    extends BioMatcherJobResult
{

    protected String jobId;
    @XmlElement(nillable = true)
    protected List<VerifyCandidateResult> candidateResultList;
    @XmlElement(nillable = true)
    protected List<ProbeInfoDto> probeInfoList;
    @XmlElement(nillable = true)
    protected List<ErrorMessageDto> errorList;
    protected FeatureData featureData;
    protected BioJobStatus status;
    protected String jobMode;

    /**
     * Gets the value of the jobId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJobId() {
        return jobId;
    }

    /**
     * Sets the value of the jobId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJobId(String value) {
        this.jobId = value;
    }

    /**
     * Gets the value of the candidateResultList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the candidateResultList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCandidateResultList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link VerifyCandidateResult }
     * 
     * 
     */
    public List<VerifyCandidateResult> getCandidateResultList() {
        if (candidateResultList == null) {
            candidateResultList = new ArrayList<VerifyCandidateResult>();
        }
        return this.candidateResultList;
    }

    /**
     * Gets the value of the probeInfoList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the probeInfoList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProbeInfoList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProbeInfoDto }
     * 
     * 
     */
    public List<ProbeInfoDto> getProbeInfoList() {
        if (probeInfoList == null) {
            probeInfoList = new ArrayList<ProbeInfoDto>();
        }
        return this.probeInfoList;
    }

    /**
     * Gets the value of the errorList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the errorList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getErrorList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ErrorMessageDto }
     * 
     * 
     */
    public List<ErrorMessageDto> getErrorList() {
        if (errorList == null) {
            errorList = new ArrayList<ErrorMessageDto>();
        }
        return this.errorList;
    }

    /**
     * Gets the value of the featureData property.
     * 
     * @return
     *     possible object is
     *     {@link FeatureData }
     *     
     */
    public FeatureData getFeatureData() {
        return featureData;
    }

    /**
     * Sets the value of the featureData property.
     * 
     * @param value
     *     allowed object is
     *     {@link FeatureData }
     *     
     */
    public void setFeatureData(FeatureData value) {
        this.featureData = value;
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link BioJobStatus }
     *     
     */
    public BioJobStatus getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link BioJobStatus }
     *     
     */
    public void setStatus(BioJobStatus value) {
        this.status = value;
    }

    /**
     * Gets the value of the jobMode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJobMode() {
        return jobMode;
    }

    /**
     * Sets the value of the jobMode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJobMode(String value) {
        this.jobMode = value;
    }

}
