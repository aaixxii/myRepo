package com.nec.biomatcher.client.properties;

public enum PropertyNames {
	MEGHA_WEB_CONTENT, //
	MEGHA_WS_IP_ADDRESS, //
	MEGHA_WS_PORT_NUM, //
	CLIENT_CALLBACK_PORT, //
	CLIENT_CALLBACK_IP, //
	ONE_CIRCLE_JOB_COUNT,//
	ONE_BY_ONE,//
	PRIORITY_JOB,//
	SEARCH_JOB_CANCEL_INFO,//
	CIRCLE_THREAD_CURRENET_COUNT,//
	CLIENT_JOB_TIME_OUT; //
}
