
package com.nec.biomatcher.webservices;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for extractJobRequestDto complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="extractJobRequestDto">
 *   &lt;complexContent>
 *     &lt;extension base="{http://webservices.biomatcher.nec.com/}bioMatcherJobRequest">
 *       &lt;sequence>
 *         &lt;element name="extractInputPayload" type="{http://webservices.biomatcher.nec.com/}extractInputPayloadDto" minOccurs="0"/>
 *         &lt;element name="callbackUrl" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="jobTimeoutMill" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="jobMode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="priority" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "extractJobRequestDto", propOrder = {
    "extractInputPayload",
    "callbackUrl",
    "jobTimeoutMill",
    "jobMode",
    "priority"
})
public class ExtractJobRequestDto
    extends BioMatcherJobRequest
{

    protected ExtractInputPayloadDto extractInputPayload;
    protected String callbackUrl;
    protected Long jobTimeoutMill;
    protected String jobMode;
    @XmlElementRef(name = "priority", type = JAXBElement.class)
    protected JAXBElement<Integer> priority;

    /**
     * Gets the value of the extractInputPayload property.
     * 
     * @return
     *     possible object is
     *     {@link ExtractInputPayloadDto }
     *     
     */
    public ExtractInputPayloadDto getExtractInputPayload() {
        return extractInputPayload;
    }

    /**
     * Sets the value of the extractInputPayload property.
     * 
     * @param value
     *     allowed object is
     *     {@link ExtractInputPayloadDto }
     *     
     */
    public void setExtractInputPayload(ExtractInputPayloadDto value) {
        this.extractInputPayload = value;
    }

    /**
     * Gets the value of the callbackUrl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCallbackUrl() {
        return callbackUrl;
    }

    /**
     * Sets the value of the callbackUrl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCallbackUrl(String value) {
        this.callbackUrl = value;
    }

    /**
     * Gets the value of the jobTimeoutMill property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getJobTimeoutMill() {
        return jobTimeoutMill;
    }

    /**
     * Sets the value of the jobTimeoutMill property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setJobTimeoutMill(Long value) {
        this.jobTimeoutMill = value;
    }

    /**
     * Gets the value of the jobMode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJobMode() {
        return jobMode;
    }

    /**
     * Sets the value of the jobMode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJobMode(String value) {
        this.jobMode = value;
    }

    /**
     * Gets the value of the priority property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public JAXBElement<Integer> getPriority() {
        return priority;
    }

    /**
     * Sets the value of the priority property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public void setPriority(JAXBElement<Integer> value) {
        this.priority = ((JAXBElement<Integer> ) value);
    }

}
