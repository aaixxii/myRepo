package com.nec.biomatcher.client.request;

import com.nec.biomatcher.webservices.BioMatcherJobRequest;
import com.nec.biomatcher.webservices.BioMatcherJobResult;

public interface Requester<Q extends BioMatcherJobRequest, R extends BioMatcherJobResult> {
	public R submitJobRequest(String requestFilePath);
	
	public R getJobResult(long startTime);

}
