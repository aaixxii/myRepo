
package com.nec.biomatcher.webservices;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for metaInfoCommon complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="metaInfoCommon">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="regionFlags" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="userFlags" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="yob" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="yobRange" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="targetQualityThreshold" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="parameters" type="{http://webservices.biomatcher.nec.com/}bioParameterDto" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="gender" type="{http://webservices.biomatcher.nec.com/}genderEnum" />
 *       &lt;attribute name="race" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "metaInfoCommon", propOrder = {
    "regionFlags",
    "userFlags",
    "yob",
    "yobRange",
    "targetQualityThreshold",
    "parameters"
})
public class MetaInfoCommon {

    @XmlElementRef(name = "regionFlags", type = JAXBElement.class)
    protected JAXBElement<Long> regionFlags;
    @XmlElementRef(name = "userFlags", type = JAXBElement.class)
    protected JAXBElement<String> userFlags;
    @XmlElementRef(name = "yob", type = JAXBElement.class)
    protected JAXBElement<Integer> yob;
    @XmlElementRef(name = "yobRange", type = JAXBElement.class)
    protected JAXBElement<Integer> yobRange;
    @XmlElementRef(name = "targetQualityThreshold", type = JAXBElement.class)
    protected JAXBElement<Integer> targetQualityThreshold;
    @XmlElement(nillable = true)
    protected List<BioParameterDto> parameters;
    @XmlAttribute
    protected GenderEnum gender;
    @XmlAttribute
    protected String race;

    /**
     * Gets the value of the regionFlags property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getRegionFlags() {
        return regionFlags;
    }

    /**
     * Sets the value of the regionFlags property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setRegionFlags(JAXBElement<Long> value) {
        this.regionFlags = ((JAXBElement<Long> ) value);
    }

    /**
     * Gets the value of the userFlags property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getUserFlags() {
        return userFlags;
    }

    /**
     * Sets the value of the userFlags property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setUserFlags(JAXBElement<String> value) {
        this.userFlags = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the yob property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public JAXBElement<Integer> getYob() {
        return yob;
    }

    /**
     * Sets the value of the yob property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public void setYob(JAXBElement<Integer> value) {
        this.yob = ((JAXBElement<Integer> ) value);
    }

    /**
     * Gets the value of the yobRange property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public JAXBElement<Integer> getYobRange() {
        return yobRange;
    }

    /**
     * Sets the value of the yobRange property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public void setYobRange(JAXBElement<Integer> value) {
        this.yobRange = ((JAXBElement<Integer> ) value);
    }

    /**
     * Gets the value of the targetQualityThreshold property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public JAXBElement<Integer> getTargetQualityThreshold() {
        return targetQualityThreshold;
    }

    /**
     * Sets the value of the targetQualityThreshold property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public void setTargetQualityThreshold(JAXBElement<Integer> value) {
        this.targetQualityThreshold = ((JAXBElement<Integer> ) value);
    }

    /**
     * Gets the value of the parameters property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the parameters property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getParameters().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link BioParameterDto }
     * 
     * 
     */
    public List<BioParameterDto> getParameters() {
        if (parameters == null) {
            parameters = new ArrayList<BioParameterDto>();
        }
        return this.parameters;
    }

    /**
     * Gets the value of the gender property.
     * 
     * @return
     *     possible object is
     *     {@link GenderEnum }
     *     
     */
    public GenderEnum getGender() {
        return gender;
    }

    /**
     * Sets the value of the gender property.
     * 
     * @param value
     *     allowed object is
     *     {@link GenderEnum }
     *     
     */
    public void setGender(GenderEnum value) {
        this.gender = value;
    }

    /**
     * Gets the value of the race property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRace() {
        return race;
    }

    /**
     * Sets the value of the race property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRace(String value) {
        this.race = value;
    }

}
