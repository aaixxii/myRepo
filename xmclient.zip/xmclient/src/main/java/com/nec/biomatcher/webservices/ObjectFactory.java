
package com.nec.biomatcher.webservices;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.nec.biomatcher.webservices package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _SearchJobRequestDtoSearchFunctionId_QNAME = new QName("", "searchFunctionId");
    private final static QName _SearchJobRequestDtoPriority_QNAME = new QName("", "priority");
    private final static QName _SearchJobRequestDtoCapacityGroupKey_QNAME = new QName("", "capacityGroupKey");
    private final static QName _SearchJobRequestDtoIncludeExtractionResult_QNAME = new QName("", "includeExtractionResult");
    private final static QName _ExtractInputImage_QNAME = new QName("http://webservices.biomatcher.nec.com/", "extractInputImage");
    private final static QName _BioType42Event_QNAME = new QName("http://webservices.biomatcher.nec.com/", "bioType42Event");
    private final static QName _BioType45Event_QNAME = new QName("http://webservices.biomatcher.nec.com/", "bioType45Event");
    private final static QName _BioType3Event_QNAME = new QName("http://webservices.biomatcher.nec.com/", "bioType3Event");
    private final static QName _SearchItemInputPayloadDto_QNAME = new QName("http://webservices.biomatcher.nec.com/", "searchItemInputPayloadDto");
    private final static QName _SyncJobResultDto_QNAME = new QName("http://webservices.biomatcher.nec.com/", "syncJobResultDto");
    private final static QName _DeleteSearchJobResponse_QNAME = new QName("http://webservices.biomatcher.nec.com/", "deleteSearchJobResponse");
    private final static QName _BioType37Event_QNAME = new QName("http://webservices.biomatcher.nec.com/", "bioType37Event");
    private final static QName _MinutiaData_QNAME = new QName("http://webservices.biomatcher.nec.com/", "minutiaData");
    private final static QName _BioTemplateHeader_QNAME = new QName("http://webservices.biomatcher.nec.com/", "bioTemplateHeader");
    private final static QName _InsertBiometricEventDto_QNAME = new QName("http://webservices.biomatcher.nec.com/", "insertBiometricEventDto");
    private final static QName _SubmitVerificationJob_QNAME = new QName("http://webservices.biomatcher.nec.com/", "submitVerificationJob");
    private final static QName _ExtractManualData_QNAME = new QName("http://webservices.biomatcher.nec.com/", "extractManualData");
    private final static QName _GetExtractionJobStatusResponse_QNAME = new QName("http://webservices.biomatcher.nec.com/", "getExtractionJobStatusResponse");
    private final static QName _BioType44Event_QNAME = new QName("http://webservices.biomatcher.nec.com/", "bioType44Event");
    private final static QName _GetBiometricEventStatusInfoListResponse_QNAME = new QName("http://webservices.biomatcher.nec.com/", "getBiometricEventStatusInfoListResponse");
    private final static QName _FeatureData_QNAME = new QName("http://webservices.biomatcher.nec.com/", "featureData");
    private final static QName _GetExtractionJobResultResponse_QNAME = new QName("http://webservices.biomatcher.nec.com/", "getExtractionJobResultResponse");
    private final static QName _SubmitExtractionJobResponse_QNAME = new QName("http://webservices.biomatcher.nec.com/", "submitExtractionJobResponse");
    private final static QName _ExtractJobRequestDto_QNAME = new QName("http://webservices.biomatcher.nec.com/", "extractJobRequestDto");
    private final static QName _DeleteExtractionJob_QNAME = new QName("http://webservices.biomatcher.nec.com/", "deleteExtractionJob");
    private final static QName _BioType43Event_QNAME = new QName("http://webservices.biomatcher.nec.com/", "bioType43Event");
    private final static QName _MatchInputParameter_QNAME = new QName("http://webservices.biomatcher.nec.com/", "matchInputParameter");
    private final static QName _BioParameterGroupDto_QNAME = new QName("http://webservices.biomatcher.nec.com/", "bioParameterGroupDto");
    private final static QName _SubmitSyncJobResponse_QNAME = new QName("http://webservices.biomatcher.nec.com/", "submitSyncJobResponse");
    private final static QName _BioType2Event_QNAME = new QName("http://webservices.biomatcher.nec.com/", "bioType2Event");
    private final static QName _BioTemplateEvent_QNAME = new QName("http://webservices.biomatcher.nec.com/", "bioTemplateEvent");
    private final static QName _GetBiometricEventStatusInfoResponse_QNAME = new QName("http://webservices.biomatcher.nec.com/", "getBiometricEventStatusInfoResponse");
    private final static QName _VerifyJobResultDto_QNAME = new QName("http://webservices.biomatcher.nec.com/", "verifyJobResultDto");
    private final static QName _ExtractJobResultDto_QNAME = new QName("http://webservices.biomatcher.nec.com/", "extractJobResultDto");
    private final static QName _BioType39Event_QNAME = new QName("http://webservices.biomatcher.nec.com/", "bioType39Event");
    private final static QName _BioType34Event_QNAME = new QName("http://webservices.biomatcher.nec.com/", "bioType34Event");
    private final static QName _BioType11Event_QNAME = new QName("http://webservices.biomatcher.nec.com/", "bioType11Event");
    private final static QName _SubmitVerificationJobResponse_QNAME = new QName("http://webservices.biomatcher.nec.com/", "submitVerificationJobResponse");
    private final static QName _GetSearchJobStatusResponse_QNAME = new QName("http://webservices.biomatcher.nec.com/", "getSearchJobStatusResponse");
    private final static QName _GetSyncJobStatus_QNAME = new QName("http://webservices.biomatcher.nec.com/", "getSyncJobStatus");
    private final static QName _BioTemplatePayload_QNAME = new QName("http://webservices.biomatcher.nec.com/", "bioTemplatePayload");
    private final static QName _GetBiometricEventStatusInfoList_QNAME = new QName("http://webservices.biomatcher.nec.com/", "getBiometricEventStatusInfoList");
    private final static QName _GetVerificationJobResultResponse_QNAME = new QName("http://webservices.biomatcher.nec.com/", "getVerificationJobResultResponse");
    private final static QName _DeleteExtractionJobResponse_QNAME = new QName("http://webservices.biomatcher.nec.com/", "deleteExtractionJobResponse");
    private final static QName _DeleteVerificationJobResponse_QNAME = new QName("http://webservices.biomatcher.nec.com/", "deleteVerificationJobResponse");
    private final static QName _BioType35Event_QNAME = new QName("http://webservices.biomatcher.nec.com/", "bioType35Event");
    private final static QName _ExtractInputParameter_QNAME = new QName("http://webservices.biomatcher.nec.com/", "extractInputParameter");
    private final static QName _PalmExtractInputImage_QNAME = new QName("http://webservices.biomatcher.nec.com/", "palmExtractInputImage");
    private final static QName _FingerExtractInputImage_QNAME = new QName("http://webservices.biomatcher.nec.com/", "fingerExtractInputImage");
    private final static QName _SearchJobRequestDto_QNAME = new QName("http://webservices.biomatcher.nec.com/", "searchJobRequestDto");
    private final static QName _BioType31Event_QNAME = new QName("http://webservices.biomatcher.nec.com/", "bioType31Event");
    private final static QName _GetExtractionJobStatus_QNAME = new QName("http://webservices.biomatcher.nec.com/", "getExtractionJobStatus");
    private final static QName _SubmitSyncJob_QNAME = new QName("http://webservices.biomatcher.nec.com/", "submitSyncJob");
    private final static QName _Echo_QNAME = new QName("http://webservices.biomatcher.nec.com/", "echo");
    private final static QName _DeleteVerificationJob_QNAME = new QName("http://webservices.biomatcher.nec.com/", "deleteVerificationJob");
    private final static QName _GetSyncJobResultResponse_QNAME = new QName("http://webservices.biomatcher.nec.com/", "getSyncJobResultResponse");
    private final static QName _DeleteBiometricEventDto_QNAME = new QName("http://webservices.biomatcher.nec.com/", "deleteBiometricEventDto");
    private final static QName _BioType4Event_QNAME = new QName("http://webservices.biomatcher.nec.com/", "bioType4Event");
    private final static QName _BioPalmFeatureInfo_QNAME = new QName("http://webservices.biomatcher.nec.com/", "bioPalmFeatureInfo");
    private final static QName _TemplateInfo_QNAME = new QName("http://webservices.biomatcher.nec.com/", "templateInfo");
    private final static QName _GetSearchJobResult_QNAME = new QName("http://webservices.biomatcher.nec.com/", "getSearchJobResult");
    private final static QName _GetVerificationJobStatusResponse_QNAME = new QName("http://webservices.biomatcher.nec.com/", "getVerificationJobStatusResponse");
    private final static QName _Minutia_QNAME = new QName("http://webservices.biomatcher.nec.com/", "minutia");
    private final static QName _BioType33Event_QNAME = new QName("http://webservices.biomatcher.nec.com/", "bioType33Event");
    private final static QName _IrisExtractInputImage_QNAME = new QName("http://webservices.biomatcher.nec.com/", "irisExtractInputImage");
    private final static QName _VerifyJobRequestDto_QNAME = new QName("http://webservices.biomatcher.nec.com/", "verifyJobRequestDto");
    private final static QName _BioType48Event_QNAME = new QName("http://webservices.biomatcher.nec.com/", "bioType48Event");
    private final static QName _EchoResponse_QNAME = new QName("http://webservices.biomatcher.nec.com/", "echoResponse");
    private final static QName _BioType38Event_QNAME = new QName("http://webservices.biomatcher.nec.com/", "bioType38Event");
    private final static QName _SubmitExtractionJob_QNAME = new QName("http://webservices.biomatcher.nec.com/", "submitExtractionJob");
    private final static QName _VerifyResponse_QNAME = new QName("http://webservices.biomatcher.nec.com/", "verifyResponse");
    private final static QName _BioParameterDto_QNAME = new QName("http://webservices.biomatcher.nec.com/", "bioParameterDto");
    private final static QName _BioType12Event_QNAME = new QName("http://webservices.biomatcher.nec.com/", "bioType12Event");
    private final static QName _BioType32Event_QNAME = new QName("http://webservices.biomatcher.nec.com/", "bioType32Event");
    private final static QName _SearchStatistics_QNAME = new QName("http://webservices.biomatcher.nec.com/", "searchStatistics");
    private final static QName _FeatureExtractInputImage_QNAME = new QName("http://webservices.biomatcher.nec.com/", "featureExtractInputImage");
    private final static QName _DeleteSyncJob_QNAME = new QName("http://webservices.biomatcher.nec.com/", "deleteSyncJob");
    private final static QName _DeleteSyncJobResponse_QNAME = new QName("http://webservices.biomatcher.nec.com/", "deleteSyncJobResponse");
    private final static QName _UpdateBiometricEventUserFlagDto_QNAME = new QName("http://webservices.biomatcher.nec.com/", "updateBiometricEventUserFlagDto");
    private final static QName _SearchRequestItemDto_QNAME = new QName("http://webservices.biomatcher.nec.com/", "searchRequestItemDto");
    private final static QName _BioType47Event_QNAME = new QName("http://webservices.biomatcher.nec.com/", "bioType47Event");
    private final static QName _ErrorMessageDto_QNAME = new QName("http://webservices.biomatcher.nec.com/", "errorMessageDto");
    private final static QName _ProbeInfoDto_QNAME = new QName("http://webservices.biomatcher.nec.com/", "probeInfoDto");
    private final static QName _InsertTemplateInfo_QNAME = new QName("http://webservices.biomatcher.nec.com/", "insertTemplateInfo");
    private final static QName _BioFingerFeatureInfo_QNAME = new QName("http://webservices.biomatcher.nec.com/", "bioFingerFeatureInfo");
    private final static QName _GetBiometricEventStatusInfo_QNAME = new QName("http://webservices.biomatcher.nec.com/", "getBiometricEventStatusInfo");
    private final static QName _Image_QNAME = new QName("http://webservices.biomatcher.nec.com/", "image");
    private final static QName _SearchJobResultDto_QNAME = new QName("http://webservices.biomatcher.nec.com/", "searchJobResultDto");
    private final static QName _GetSyncJobStatusResponse_QNAME = new QName("http://webservices.biomatcher.nec.com/", "getSyncJobStatusResponse");
    private final static QName _BioType46Event_QNAME = new QName("http://webservices.biomatcher.nec.com/", "bioType46Event");
    private final static QName _MultiModalExtractInputImage_QNAME = new QName("http://webservices.biomatcher.nec.com/", "multiModalExtractInputImage");
    private final static QName _BioType41Event_QNAME = new QName("http://webservices.biomatcher.nec.com/", "bioType41Event");
    private final static QName _GetSearchJobStatus_QNAME = new QName("http://webservices.biomatcher.nec.com/", "getSearchJobStatus");
    private final static QName _SubmitSearchJob_QNAME = new QName("http://webservices.biomatcher.nec.com/", "submitSearchJob");
    private final static QName _DeleteSearchJob_QNAME = new QName("http://webservices.biomatcher.nec.com/", "deleteSearchJob");
    private final static QName _ExtractInputPayloadDto_QNAME = new QName("http://webservices.biomatcher.nec.com/", "extractInputPayloadDto");
    private final static QName _SyncJobRequestDto_QNAME = new QName("http://webservices.biomatcher.nec.com/", "syncJobRequestDto");
    private final static QName _BioType1Event_QNAME = new QName("http://webservices.biomatcher.nec.com/", "bioType1Event");
    private final static QName _GetVerificationJobResult_QNAME = new QName("http://webservices.biomatcher.nec.com/", "getVerificationJobResult");
    private final static QName _Verify_QNAME = new QName("http://webservices.biomatcher.nec.com/", "verify");
    private final static QName _GetSyncJobResult_QNAME = new QName("http://webservices.biomatcher.nec.com/", "getSyncJobResult");
    private final static QName _SubmitSearchJobResponse_QNAME = new QName("http://webservices.biomatcher.nec.com/", "submitSearchJobResponse");
    private final static QName _BioType40Event_QNAME = new QName("http://webservices.biomatcher.nec.com/", "bioType40Event");
    private final static QName _SearchOptionsDto_QNAME = new QName("http://webservices.biomatcher.nec.com/", "searchOptionsDto");
    private final static QName _VerifyBiometricData_QNAME = new QName("http://webservices.biomatcher.nec.com/", "verifyBiometricData");
    private final static QName _GetVerificationJobStatus_QNAME = new QName("http://webservices.biomatcher.nec.com/", "getVerificationJobStatus");
    private final static QName _BioType36Event_QNAME = new QName("http://webservices.biomatcher.nec.com/", "bioType36Event");
    private final static QName _GetExtractionJobResult_QNAME = new QName("http://webservices.biomatcher.nec.com/", "getExtractionJobResult");
    private final static QName _GetSearchJobResultResponse_QNAME = new QName("http://webservices.biomatcher.nec.com/", "getSearchJobResultResponse");
    private final static QName _TemplateExtractInputImage_QNAME = new QName("http://webservices.biomatcher.nec.com/", "templateExtractInputImage");
    private final static QName _FaceExtractInputImage_QNAME = new QName("http://webservices.biomatcher.nec.com/", "faceExtractInputImage");
    private final static QName _SearchJobResultDtoExtractJobResult_QNAME = new QName("", "extractJobResult");
    private final static QName _VerifyJobRequestDtoProbeBiomericData_QNAME = new QName("", "probeBiomericData");
    private final static QName _ExtractInputPayloadDtoCandidateId_QNAME = new QName("", "candidateId");
    private final static QName _ExtractInputPayloadDtoMetaInfoCommon_QNAME = new QName("", "metaInfoCommon");
    private final static QName _ExtractInputPayloadDtoBiometricId_QNAME = new QName("", "biometricId");
    private final static QName _ExtractInputPayloadDtoEventId_QNAME = new QName("", "eventId");
    private final static QName _MetaInfoCommonRegionFlags_QNAME = new QName("", "regionFlags");
    private final static QName _MetaInfoCommonTargetQualityThreshold_QNAME = new QName("", "targetQualityThreshold");
    private final static QName _MetaInfoCommonYob_QNAME = new QName("", "yob");
    private final static QName _MetaInfoCommonYobRange_QNAME = new QName("", "yobRange");
    private final static QName _MetaInfoCommonUserFlags_QNAME = new QName("", "userFlags");
    private final static QName _ImageHeight_QNAME = new QName("", "height");
    private final static QName _ImageWidth_QNAME = new QName("", "width");
    private final static QName _ImageModality_QNAME = new QName("", "modality");
    private final static QName _ImageDpi_QNAME = new QName("", "dpi");
    private final static QName _ImageManualData_QNAME = new QName("", "manualData");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.nec.biomatcher.webservices
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link BioType38Event }
     * 
     */
    public BioType38Event createBioType38Event() {
        return new BioType38Event();
    }

    /**
     * Create an instance of {@link GetSyncJobStatus }
     * 
     */
    public GetSyncJobStatus createGetSyncJobStatus() {
        return new GetSyncJobStatus();
    }

    /**
     * Create an instance of {@link GetSearchJobStatus }
     * 
     */
    public GetSearchJobStatus createGetSearchJobStatus() {
        return new GetSearchJobStatus();
    }

    /**
     * Create an instance of {@link TemplateExtractInputImage }
     * 
     */
    public TemplateExtractInputImage createTemplateExtractInputImage() {
        return new TemplateExtractInputImage();
    }

    /**
     * Create an instance of {@link VerifyRawScoreDto }
     * 
     */
    public VerifyRawScoreDto createVerifyRawScoreDto() {
        return new VerifyRawScoreDto();
    }

    /**
     * Create an instance of {@link TemplateInfo }
     * 
     */
    public TemplateInfo createTemplateInfo() {
        return new TemplateInfo();
    }

    /**
     * Create an instance of {@link GetSyncJobStatusResponse }
     * 
     */
    public GetSyncJobStatusResponse createGetSyncJobStatusResponse() {
        return new GetSyncJobStatusResponse();
    }

    /**
     * Create an instance of {@link GetSyncJobResultResponse }
     * 
     */
    public GetSyncJobResultResponse createGetSyncJobResultResponse() {
        return new GetSyncJobResultResponse();
    }

    /**
     * Create an instance of {@link SearchJobRequestDto }
     * 
     */
    public SearchJobRequestDto createSearchJobRequestDto() {
        return new SearchJobRequestDto();
    }

    /**
     * Create an instance of {@link IrisExtractInputImage }
     * 
     */
    public IrisExtractInputImage createIrisExtractInputImage() {
        return new IrisExtractInputImage();
    }

    /**
     * Create an instance of {@link BioType45Event }
     * 
     */
    public BioType45Event createBioType45Event() {
        return new BioType45Event();
    }

    /**
     * Create an instance of {@link GetExtractionJobResultResponse }
     * 
     */
    public GetExtractionJobResultResponse createGetExtractionJobResultResponse() {
        return new GetExtractionJobResultResponse();
    }

    /**
     * Create an instance of {@link BioRectangle }
     * 
     */
    public BioRectangle createBioRectangle() {
        return new BioRectangle();
    }

    /**
     * Create an instance of {@link ExtractInputImage }
     * 
     */
    public ExtractInputImage createExtractInputImage() {
        return new ExtractInputImage();
    }

    /**
     * Create an instance of {@link BioParameterDto }
     * 
     */
    public BioParameterDto createBioParameterDto() {
        return new BioParameterDto();
    }

    /**
     * Create an instance of {@link BioType37Event }
     * 
     */
    public BioType37Event createBioType37Event() {
        return new BioType37Event();
    }

    /**
     * Create an instance of {@link BioType40Event }
     * 
     */
    public BioType40Event createBioType40Event() {
        return new BioType40Event();
    }

    /**
     * Create an instance of {@link SubmitVerificationJobResponse }
     * 
     */
    public SubmitVerificationJobResponse createSubmitVerificationJobResponse() {
        return new SubmitVerificationJobResponse();
    }

    /**
     * Create an instance of {@link DeleteSearchJob }
     * 
     */
    public DeleteSearchJob createDeleteSearchJob() {
        return new DeleteSearchJob();
    }

    /**
     * Create an instance of {@link ProbeInfoDto }
     * 
     */
    public ProbeInfoDto createProbeInfoDto() {
        return new ProbeInfoDto();
    }

    /**
     * Create an instance of {@link ExtractInputPayloadDto }
     * 
     */
    public ExtractInputPayloadDto createExtractInputPayloadDto() {
        return new ExtractInputPayloadDto();
    }

    /**
     * Create an instance of {@link DeleteVerificationJobResponse }
     * 
     */
    public DeleteVerificationJobResponse createDeleteVerificationJobResponse() {
        return new DeleteVerificationJobResponse();
    }

    /**
     * Create an instance of {@link GetExtractionJobResult }
     * 
     */
    public GetExtractionJobResult createGetExtractionJobResult() {
        return new GetExtractionJobResult();
    }

    /**
     * Create an instance of {@link SearchJobResultDto }
     * 
     */
    public SearchJobResultDto createSearchJobResultDto() {
        return new SearchJobResultDto();
    }

    /**
     * Create an instance of {@link BioType44Event }
     * 
     */
    public BioType44Event createBioType44Event() {
        return new BioType44Event();
    }

    /**
     * Create an instance of {@link SearchHitEvent }
     * 
     */
    public SearchHitEvent createSearchHitEvent() {
        return new SearchHitEvent();
    }

    /**
     * Create an instance of {@link SubmitSyncJobResponse }
     * 
     */
    public SubmitSyncJobResponse createSubmitSyncJobResponse() {
        return new SubmitSyncJobResponse();
    }

    /**
     * Create an instance of {@link VerifyJobRequestDto }
     * 
     */
    public VerifyJobRequestDto createVerifyJobRequestDto() {
        return new VerifyJobRequestDto();
    }

    /**
     * Create an instance of {@link BioType39Event }
     * 
     */
    public BioType39Event createBioType39Event() {
        return new BioType39Event();
    }

    /**
     * Create an instance of {@link PalmExtractInputImage }
     * 
     */
    public PalmExtractInputImage createPalmExtractInputImage() {
        return new PalmExtractInputImage();
    }

    /**
     * Create an instance of {@link VerifyResponse }
     * 
     */
    public VerifyResponse createVerifyResponse() {
        return new VerifyResponse();
    }

    /**
     * Create an instance of {@link FingerExtractInputImage }
     * 
     */
    public FingerExtractInputImage createFingerExtractInputImage() {
        return new FingerExtractInputImage();
    }

    /**
     * Create an instance of {@link BioParameterGroupDto }
     * 
     */
    public BioParameterGroupDto createBioParameterGroupDto() {
        return new BioParameterGroupDto();
    }

    /**
     * Create an instance of {@link FeatureExtractInputImage }
     * 
     */
    public FeatureExtractInputImage createFeatureExtractInputImage() {
        return new FeatureExtractInputImage();
    }

    /**
     * Create an instance of {@link VerifyCandidateResult }
     * 
     */
    public VerifyCandidateResult createVerifyCandidateResult() {
        return new VerifyCandidateResult();
    }

    /**
     * Create an instance of {@link BioType11Event }
     * 
     */
    public BioType11Event createBioType11Event() {
        return new BioType11Event();
    }

    /**
     * Create an instance of {@link BioType36Event }
     * 
     */
    public BioType36Event createBioType36Event() {
        return new BioType36Event();
    }

    /**
     * Create an instance of {@link ExtractInputParameter }
     * 
     */
    public ExtractInputParameter createExtractInputParameter() {
        return new ExtractInputParameter();
    }

    /**
     * Create an instance of {@link GetExtractionJobStatusResponse }
     * 
     */
    public GetExtractionJobStatusResponse createGetExtractionJobStatusResponse() {
        return new GetExtractionJobStatusResponse();
    }

    /**
     * Create an instance of {@link InsertTemplateInfo }
     * 
     */
    public InsertTemplateInfo createInsertTemplateInfo() {
        return new InsertTemplateInfo();
    }

    /**
     * Create an instance of {@link MatchInputParameter }
     * 
     */
    public MatchInputParameter createMatchInputParameter() {
        return new MatchInputParameter();
    }

    /**
     * Create an instance of {@link BioTemplatePayload }
     * 
     */
    public BioTemplatePayload createBioTemplatePayload() {
        return new BioTemplatePayload();
    }

    /**
     * Create an instance of {@link BioType43Event }
     * 
     */
    public BioType43Event createBioType43Event() {
        return new BioType43Event();
    }

    /**
     * Create an instance of {@link Image }
     * 
     */
    public Image createImage() {
        return new Image();
    }

    /**
     * Create an instance of {@link SubmitSyncJob }
     * 
     */
    public SubmitSyncJob createSubmitSyncJob() {
        return new SubmitSyncJob();
    }

    /**
     * Create an instance of {@link DeleteSearchJobResponse }
     * 
     */
    public DeleteSearchJobResponse createDeleteSearchJobResponse() {
        return new DeleteSearchJobResponse();
    }

    /**
     * Create an instance of {@link BioType1Event }
     * 
     */
    public BioType1Event createBioType1Event() {
        return new BioType1Event();
    }

    /**
     * Create an instance of {@link GetExtractionJobStatus }
     * 
     */
    public GetExtractionJobStatus createGetExtractionJobStatus() {
        return new GetExtractionJobStatus();
    }

    /**
     * Create an instance of {@link UpdateBiometricEventUserFlagDto }
     * 
     */
    public UpdateBiometricEventUserFlagDto createUpdateBiometricEventUserFlagDto() {
        return new UpdateBiometricEventUserFlagDto();
    }

    /**
     * Create an instance of {@link BioType41Event }
     * 
     */
    public BioType41Event createBioType41Event() {
        return new BioType41Event();
    }

    /**
     * Create an instance of {@link GetSearchJobStatusResponse }
     * 
     */
    public GetSearchJobStatusResponse createGetSearchJobStatusResponse() {
        return new GetSearchJobStatusResponse();
    }

    /**
     * Create an instance of {@link FeatureData }
     * 
     */
    public FeatureData createFeatureData() {
        return new FeatureData();
    }

    /**
     * Create an instance of {@link BioType47Event }
     * 
     */
    public BioType47Event createBioType47Event() {
        return new BioType47Event();
    }

    /**
     * Create an instance of {@link BiometricEventStatusInfoDto }
     * 
     */
    public BiometricEventStatusInfoDto createBiometricEventStatusInfoDto() {
        return new BiometricEventStatusInfoDto();
    }

    /**
     * Create an instance of {@link ExtractJobResultDto }
     * 
     */
    public ExtractJobResultDto createExtractJobResultDto() {
        return new ExtractJobResultDto();
    }

    /**
     * Create an instance of {@link GetVerificationJobStatusResponse }
     * 
     */
    public GetVerificationJobStatusResponse createGetVerificationJobStatusResponse() {
        return new GetVerificationJobStatusResponse();
    }

    /**
     * Create an instance of {@link EchoResponse }
     * 
     */
    public EchoResponse createEchoResponse() {
        return new EchoResponse();
    }

    /**
     * Create an instance of {@link BioType31Event }
     * 
     */
    public BioType31Event createBioType31Event() {
        return new BioType31Event();
    }

    /**
     * Create an instance of {@link BioTemplateHeader }
     * 
     */
    public BioTemplateHeader createBioTemplateHeader() {
        return new BioTemplateHeader();
    }

    /**
     * Create an instance of {@link BioType42Event }
     * 
     */
    public BioType42Event createBioType42Event() {
        return new BioType42Event();
    }

    /**
     * Create an instance of {@link SearchRegionScore }
     * 
     */
    public SearchRegionScore createSearchRegionScore() {
        return new SearchRegionScore();
    }

    /**
     * Create an instance of {@link DeleteBiometricEventDto }
     * 
     */
    public DeleteBiometricEventDto createDeleteBiometricEventDto() {
        return new DeleteBiometricEventDto();
    }

    /**
     * Create an instance of {@link SyncJobRequestDto }
     * 
     */
    public SyncJobRequestDto createSyncJobRequestDto() {
        return new SyncJobRequestDto();
    }

    /**
     * Create an instance of {@link MinutiaData }
     * 
     */
    public MinutiaData createMinutiaData() {
        return new MinutiaData();
    }

    /**
     * Create an instance of {@link SubmitExtractionJob }
     * 
     */
    public SubmitExtractionJob createSubmitExtractionJob() {
        return new SubmitExtractionJob();
    }

    /**
     * Create an instance of {@link MetaInfoCommon }
     * 
     */
    public MetaInfoCommon createMetaInfoCommon() {
        return new MetaInfoCommon();
    }

    /**
     * Create an instance of {@link SearchItemInputPayloadDto }
     * 
     */
    public SearchItemInputPayloadDto createSearchItemInputPayloadDto() {
        return new SearchItemInputPayloadDto();
    }

    /**
     * Create an instance of {@link BioType2Event }
     * 
     */
    public BioType2Event createBioType2Event() {
        return new BioType2Event();
    }

    /**
     * Create an instance of {@link MinutiaPairDto }
     * 
     */
    public MinutiaPairDto createMinutiaPairDto() {
        return new MinutiaPairDto();
    }

    /**
     * Create an instance of {@link MultiModalExtractInputImage }
     * 
     */
    public MultiModalExtractInputImage createMultiModalExtractInputImage() {
        return new MultiModalExtractInputImage();
    }

    /**
     * Create an instance of {@link DeleteSyncJob }
     * 
     */
    public DeleteSyncJob createDeleteSyncJob() {
        return new DeleteSyncJob();
    }

    /**
     * Create an instance of {@link GetVerificationJobStatus }
     * 
     */
    public GetVerificationJobStatus createGetVerificationJobStatus() {
        return new GetVerificationJobStatus();
    }

    /**
     * Create an instance of {@link BioType33Event }
     * 
     */
    public BioType33Event createBioType33Event() {
        return new BioType33Event();
    }

    /**
     * Create an instance of {@link BioType3Event }
     * 
     */
    public BioType3Event createBioType3Event() {
        return new BioType3Event();
    }

    /**
     * Create an instance of {@link BioPalmFeatureInfo }
     * 
     */
    public BioPalmFeatureInfo createBioPalmFeatureInfo() {
        return new BioPalmFeatureInfo();
    }

    /**
     * Create an instance of {@link GetBiometricEventStatusInfoResponse }
     * 
     */
    public GetBiometricEventStatusInfoResponse createGetBiometricEventStatusInfoResponse() {
        return new GetBiometricEventStatusInfoResponse();
    }

    /**
     * Create an instance of {@link PointDto }
     * 
     */
    public PointDto createPointDto() {
        return new PointDto();
    }

    /**
     * Create an instance of {@link GetBiometricEventStatusInfoListResponse }
     * 
     */
    public GetBiometricEventStatusInfoListResponse createGetBiometricEventStatusInfoListResponse() {
        return new GetBiometricEventStatusInfoListResponse();
    }

    /**
     * Create an instance of {@link BioType48Event }
     * 
     */
    public BioType48Event createBioType48Event() {
        return new BioType48Event();
    }

    /**
     * Create an instance of {@link DeleteSyncJobResponse }
     * 
     */
    public DeleteSyncJobResponse createDeleteSyncJobResponse() {
        return new DeleteSyncJobResponse();
    }

    /**
     * Create an instance of {@link InsertBiometricEventDto }
     * 
     */
    public InsertBiometricEventDto createInsertBiometricEventDto() {
        return new InsertBiometricEventDto();
    }

    /**
     * Create an instance of {@link SubmitVerificationJob }
     * 
     */
    public SubmitVerificationJob createSubmitVerificationJob() {
        return new SubmitVerificationJob();
    }

    /**
     * Create an instance of {@link ExtractManualData }
     * 
     */
    public ExtractManualData createExtractManualData() {
        return new ExtractManualData();
    }

    /**
     * Create an instance of {@link BioType12Event }
     * 
     */
    public BioType12Event createBioType12Event() {
        return new BioType12Event();
    }

    /**
     * Create an instance of {@link BioType35Event }
     * 
     */
    public BioType35Event createBioType35Event() {
        return new BioType35Event();
    }

    /**
     * Create an instance of {@link VerifyModalScore }
     * 
     */
    public VerifyModalScore createVerifyModalScore() {
        return new VerifyModalScore();
    }

    /**
     * Create an instance of {@link FaceExtractInputImage }
     * 
     */
    public FaceExtractInputImage createFaceExtractInputImage() {
        return new FaceExtractInputImage();
    }

    /**
     * Create an instance of {@link ExtractJobRequestDto }
     * 
     */
    public ExtractJobRequestDto createExtractJobRequestDto() {
        return new ExtractJobRequestDto();
    }

    /**
     * Create an instance of {@link SearchOptionsDto }
     * 
     */
    public SearchOptionsDto createSearchOptionsDto() {
        return new SearchOptionsDto();
    }

    /**
     * Create an instance of {@link SubmitSearchJob }
     * 
     */
    public SubmitSearchJob createSubmitSearchJob() {
        return new SubmitSearchJob();
    }

    /**
     * Create an instance of {@link GetSearchJobResultResponse }
     * 
     */
    public GetSearchJobResultResponse createGetSearchJobResultResponse() {
        return new GetSearchJobResultResponse();
    }

    /**
     * Create an instance of {@link BiometricEventSyncTypeDto }
     * 
     */
    public BiometricEventSyncTypeDto createBiometricEventSyncTypeDto() {
        return new BiometricEventSyncTypeDto();
    }

    /**
     * Create an instance of {@link SearchRequestItemDto }
     * 
     */
    public SearchRequestItemDto createSearchRequestItemDto() {
        return new SearchRequestItemDto();
    }

    /**
     * Create an instance of {@link BioType34Event }
     * 
     */
    public BioType34Event createBioType34Event() {
        return new BioType34Event();
    }

    /**
     * Create an instance of {@link DeleteExtractionJob }
     * 
     */
    public DeleteExtractionJob createDeleteExtractionJob() {
        return new DeleteExtractionJob();
    }

    /**
     * Create an instance of {@link GetVerificationJobResult }
     * 
     */
    public GetVerificationJobResult createGetVerificationJobResult() {
        return new GetVerificationJobResult();
    }

    /**
     * Create an instance of {@link GetBiometricEventStatusInfoList }
     * 
     */
    public GetBiometricEventStatusInfoList createGetBiometricEventStatusInfoList() {
        return new GetBiometricEventStatusInfoList();
    }

    /**
     * Create an instance of {@link BioCropInfo }
     * 
     */
    public BioCropInfo createBioCropInfo() {
        return new BioCropInfo();
    }

    /**
     * Create an instance of {@link GetVerificationJobResultResponse }
     * 
     */
    public GetVerificationJobResultResponse createGetVerificationJobResultResponse() {
        return new GetVerificationJobResultResponse();
    }

    /**
     * Create an instance of {@link GetBiometricEventStatusInfo }
     * 
     */
    public GetBiometricEventStatusInfo createGetBiometricEventStatusInfo() {
        return new GetBiometricEventStatusInfo();
    }

    /**
     * Create an instance of {@link BioType4Event }
     * 
     */
    public BioType4Event createBioType4Event() {
        return new BioType4Event();
    }

    /**
     * Create an instance of {@link ErrorMessageDto }
     * 
     */
    public ErrorMessageDto createErrorMessageDto() {
        return new ErrorMessageDto();
    }

    /**
     * Create an instance of {@link VerifyBiometricData }
     * 
     */
    public VerifyBiometricData createVerifyBiometricData() {
        return new VerifyBiometricData();
    }

    /**
     * Create an instance of {@link BioFingerFeatureInfo }
     * 
     */
    public BioFingerFeatureInfo createBioFingerFeatureInfo() {
        return new BioFingerFeatureInfo();
    }

    /**
     * Create an instance of {@link Minutia }
     * 
     */
    public Minutia createMinutia() {
        return new Minutia();
    }

    /**
     * Create an instance of {@link SyncJobResultDto }
     * 
     */
    public SyncJobResultDto createSyncJobResultDto() {
        return new SyncJobResultDto();
    }

    /**
     * Create an instance of {@link SearchFusedScoreDto }
     * 
     */
    public SearchFusedScoreDto createSearchFusedScoreDto() {
        return new SearchFusedScoreDto();
    }

    /**
     * Create an instance of {@link GetSearchJobResult }
     * 
     */
    public GetSearchJobResult createGetSearchJobResult() {
        return new GetSearchJobResult();
    }

    /**
     * Create an instance of {@link Verify }
     * 
     */
    public Verify createVerify() {
        return new Verify();
    }

    /**
     * Create an instance of {@link Echo }
     * 
     */
    public Echo createEcho() {
        return new Echo();
    }

    /**
     * Create an instance of {@link BioType46Event }
     * 
     */
    public BioType46Event createBioType46Event() {
        return new BioType46Event();
    }

    /**
     * Create an instance of {@link DeleteExtractionJobResponse }
     * 
     */
    public DeleteExtractionJobResponse createDeleteExtractionJobResponse() {
        return new DeleteExtractionJobResponse();
    }

    /**
     * Create an instance of {@link BioTemplateEvent }
     * 
     */
    public BioTemplateEvent createBioTemplateEvent() {
        return new BioTemplateEvent();
    }

    /**
     * Create an instance of {@link GetSyncJobResult }
     * 
     */
    public GetSyncJobResult createGetSyncJobResult() {
        return new GetSyncJobResult();
    }

    /**
     * Create an instance of {@link SubmitSearchJobResponse }
     * 
     */
    public SubmitSearchJobResponse createSubmitSearchJobResponse() {
        return new SubmitSearchJobResponse();
    }

    /**
     * Create an instance of {@link SearchHitCandidate }
     * 
     */
    public SearchHitCandidate createSearchHitCandidate() {
        return new SearchHitCandidate();
    }

    /**
     * Create an instance of {@link SubmitExtractionJobResponse }
     * 
     */
    public SubmitExtractionJobResponse createSubmitExtractionJobResponse() {
        return new SubmitExtractionJobResponse();
    }

    /**
     * Create an instance of {@link SearchStatistics }
     * 
     */
    public SearchStatistics createSearchStatistics() {
        return new SearchStatistics();
    }

    /**
     * Create an instance of {@link DeleteVerificationJob }
     * 
     */
    public DeleteVerificationJob createDeleteVerificationJob() {
        return new DeleteVerificationJob();
    }

    /**
     * Create an instance of {@link VerifyJobResultDto }
     * 
     */
    public VerifyJobResultDto createVerifyJobResultDto() {
        return new VerifyJobResultDto();
    }

    /**
     * Create an instance of {@link BioType32Event }
     * 
     */
    public BioType32Event createBioType32Event() {
        return new BioType32Event();
    }

    /**
     * Create an instance of {@link SearchRawScoreDto }
     * 
     */
    public SearchRawScoreDto createSearchRawScoreDto() {
        return new SearchRawScoreDto();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "searchFunctionId", scope = SearchJobRequestDto.class)
    public JAXBElement<String> createSearchJobRequestDtoSearchFunctionId(String value) {
        return new JAXBElement<String>(_SearchJobRequestDtoSearchFunctionId_QNAME, String.class, SearchJobRequestDto.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "priority", scope = SearchJobRequestDto.class)
    public JAXBElement<Integer> createSearchJobRequestDtoPriority(Integer value) {
        return new JAXBElement<Integer>(_SearchJobRequestDtoPriority_QNAME, Integer.class, SearchJobRequestDto.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "capacityGroupKey", scope = SearchJobRequestDto.class)
    public JAXBElement<String> createSearchJobRequestDtoCapacityGroupKey(String value) {
        return new JAXBElement<String>(_SearchJobRequestDtoCapacityGroupKey_QNAME, String.class, SearchJobRequestDto.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "includeExtractionResult", scope = SearchJobRequestDto.class)
    public JAXBElement<Boolean> createSearchJobRequestDtoIncludeExtractionResult(Boolean value) {
        return new JAXBElement<Boolean>(_SearchJobRequestDtoIncludeExtractionResult_QNAME, Boolean.class, SearchJobRequestDto.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ExtractInputImage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "extractInputImage")
    public JAXBElement<ExtractInputImage> createExtractInputImage(ExtractInputImage value) {
        return new JAXBElement<ExtractInputImage>(_ExtractInputImage_QNAME, ExtractInputImage.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BioType42Event }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "bioType42Event")
    public JAXBElement<BioType42Event> createBioType42Event(BioType42Event value) {
        return new JAXBElement<BioType42Event>(_BioType42Event_QNAME, BioType42Event.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BioType45Event }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "bioType45Event")
    public JAXBElement<BioType45Event> createBioType45Event(BioType45Event value) {
        return new JAXBElement<BioType45Event>(_BioType45Event_QNAME, BioType45Event.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BioType3Event }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "bioType3Event")
    public JAXBElement<BioType3Event> createBioType3Event(BioType3Event value) {
        return new JAXBElement<BioType3Event>(_BioType3Event_QNAME, BioType3Event.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SearchItemInputPayloadDto }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "searchItemInputPayloadDto")
    public JAXBElement<SearchItemInputPayloadDto> createSearchItemInputPayloadDto(SearchItemInputPayloadDto value) {
        return new JAXBElement<SearchItemInputPayloadDto>(_SearchItemInputPayloadDto_QNAME, SearchItemInputPayloadDto.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SyncJobResultDto }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "syncJobResultDto")
    public JAXBElement<SyncJobResultDto> createSyncJobResultDto(SyncJobResultDto value) {
        return new JAXBElement<SyncJobResultDto>(_SyncJobResultDto_QNAME, SyncJobResultDto.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteSearchJobResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "deleteSearchJobResponse")
    public JAXBElement<DeleteSearchJobResponse> createDeleteSearchJobResponse(DeleteSearchJobResponse value) {
        return new JAXBElement<DeleteSearchJobResponse>(_DeleteSearchJobResponse_QNAME, DeleteSearchJobResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BioType37Event }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "bioType37Event")
    public JAXBElement<BioType37Event> createBioType37Event(BioType37Event value) {
        return new JAXBElement<BioType37Event>(_BioType37Event_QNAME, BioType37Event.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MinutiaData }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "minutiaData")
    public JAXBElement<MinutiaData> createMinutiaData(MinutiaData value) {
        return new JAXBElement<MinutiaData>(_MinutiaData_QNAME, MinutiaData.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BioTemplateHeader }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "bioTemplateHeader")
    public JAXBElement<BioTemplateHeader> createBioTemplateHeader(BioTemplateHeader value) {
        return new JAXBElement<BioTemplateHeader>(_BioTemplateHeader_QNAME, BioTemplateHeader.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link InsertBiometricEventDto }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "insertBiometricEventDto")
    public JAXBElement<InsertBiometricEventDto> createInsertBiometricEventDto(InsertBiometricEventDto value) {
        return new JAXBElement<InsertBiometricEventDto>(_InsertBiometricEventDto_QNAME, InsertBiometricEventDto.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SubmitVerificationJob }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "submitVerificationJob")
    public JAXBElement<SubmitVerificationJob> createSubmitVerificationJob(SubmitVerificationJob value) {
        return new JAXBElement<SubmitVerificationJob>(_SubmitVerificationJob_QNAME, SubmitVerificationJob.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ExtractManualData }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "extractManualData")
    public JAXBElement<ExtractManualData> createExtractManualData(ExtractManualData value) {
        return new JAXBElement<ExtractManualData>(_ExtractManualData_QNAME, ExtractManualData.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetExtractionJobStatusResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "getExtractionJobStatusResponse")
    public JAXBElement<GetExtractionJobStatusResponse> createGetExtractionJobStatusResponse(GetExtractionJobStatusResponse value) {
        return new JAXBElement<GetExtractionJobStatusResponse>(_GetExtractionJobStatusResponse_QNAME, GetExtractionJobStatusResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BioType44Event }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "bioType44Event")
    public JAXBElement<BioType44Event> createBioType44Event(BioType44Event value) {
        return new JAXBElement<BioType44Event>(_BioType44Event_QNAME, BioType44Event.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetBiometricEventStatusInfoListResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "getBiometricEventStatusInfoListResponse")
    public JAXBElement<GetBiometricEventStatusInfoListResponse> createGetBiometricEventStatusInfoListResponse(GetBiometricEventStatusInfoListResponse value) {
        return new JAXBElement<GetBiometricEventStatusInfoListResponse>(_GetBiometricEventStatusInfoListResponse_QNAME, GetBiometricEventStatusInfoListResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FeatureData }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "featureData")
    public JAXBElement<FeatureData> createFeatureData(FeatureData value) {
        return new JAXBElement<FeatureData>(_FeatureData_QNAME, FeatureData.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetExtractionJobResultResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "getExtractionJobResultResponse")
    public JAXBElement<GetExtractionJobResultResponse> createGetExtractionJobResultResponse(GetExtractionJobResultResponse value) {
        return new JAXBElement<GetExtractionJobResultResponse>(_GetExtractionJobResultResponse_QNAME, GetExtractionJobResultResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SubmitExtractionJobResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "submitExtractionJobResponse")
    public JAXBElement<SubmitExtractionJobResponse> createSubmitExtractionJobResponse(SubmitExtractionJobResponse value) {
        return new JAXBElement<SubmitExtractionJobResponse>(_SubmitExtractionJobResponse_QNAME, SubmitExtractionJobResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ExtractJobRequestDto }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "extractJobRequestDto")
    public JAXBElement<ExtractJobRequestDto> createExtractJobRequestDto(ExtractJobRequestDto value) {
        return new JAXBElement<ExtractJobRequestDto>(_ExtractJobRequestDto_QNAME, ExtractJobRequestDto.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteExtractionJob }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "deleteExtractionJob")
    public JAXBElement<DeleteExtractionJob> createDeleteExtractionJob(DeleteExtractionJob value) {
        return new JAXBElement<DeleteExtractionJob>(_DeleteExtractionJob_QNAME, DeleteExtractionJob.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BioType43Event }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "bioType43Event")
    public JAXBElement<BioType43Event> createBioType43Event(BioType43Event value) {
        return new JAXBElement<BioType43Event>(_BioType43Event_QNAME, BioType43Event.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MatchInputParameter }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "matchInputParameter")
    public JAXBElement<MatchInputParameter> createMatchInputParameter(MatchInputParameter value) {
        return new JAXBElement<MatchInputParameter>(_MatchInputParameter_QNAME, MatchInputParameter.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BioParameterGroupDto }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "bioParameterGroupDto")
    public JAXBElement<BioParameterGroupDto> createBioParameterGroupDto(BioParameterGroupDto value) {
        return new JAXBElement<BioParameterGroupDto>(_BioParameterGroupDto_QNAME, BioParameterGroupDto.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SubmitSyncJobResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "submitSyncJobResponse")
    public JAXBElement<SubmitSyncJobResponse> createSubmitSyncJobResponse(SubmitSyncJobResponse value) {
        return new JAXBElement<SubmitSyncJobResponse>(_SubmitSyncJobResponse_QNAME, SubmitSyncJobResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BioType2Event }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "bioType2Event")
    public JAXBElement<BioType2Event> createBioType2Event(BioType2Event value) {
        return new JAXBElement<BioType2Event>(_BioType2Event_QNAME, BioType2Event.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BioTemplateEvent }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "bioTemplateEvent")
    public JAXBElement<BioTemplateEvent> createBioTemplateEvent(BioTemplateEvent value) {
        return new JAXBElement<BioTemplateEvent>(_BioTemplateEvent_QNAME, BioTemplateEvent.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetBiometricEventStatusInfoResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "getBiometricEventStatusInfoResponse")
    public JAXBElement<GetBiometricEventStatusInfoResponse> createGetBiometricEventStatusInfoResponse(GetBiometricEventStatusInfoResponse value) {
        return new JAXBElement<GetBiometricEventStatusInfoResponse>(_GetBiometricEventStatusInfoResponse_QNAME, GetBiometricEventStatusInfoResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link VerifyJobResultDto }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "verifyJobResultDto")
    public JAXBElement<VerifyJobResultDto> createVerifyJobResultDto(VerifyJobResultDto value) {
        return new JAXBElement<VerifyJobResultDto>(_VerifyJobResultDto_QNAME, VerifyJobResultDto.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ExtractJobResultDto }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "extractJobResultDto")
    public JAXBElement<ExtractJobResultDto> createExtractJobResultDto(ExtractJobResultDto value) {
        return new JAXBElement<ExtractJobResultDto>(_ExtractJobResultDto_QNAME, ExtractJobResultDto.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BioType39Event }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "bioType39Event")
    public JAXBElement<BioType39Event> createBioType39Event(BioType39Event value) {
        return new JAXBElement<BioType39Event>(_BioType39Event_QNAME, BioType39Event.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BioType34Event }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "bioType34Event")
    public JAXBElement<BioType34Event> createBioType34Event(BioType34Event value) {
        return new JAXBElement<BioType34Event>(_BioType34Event_QNAME, BioType34Event.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BioType11Event }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "bioType11Event")
    public JAXBElement<BioType11Event> createBioType11Event(BioType11Event value) {
        return new JAXBElement<BioType11Event>(_BioType11Event_QNAME, BioType11Event.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SubmitVerificationJobResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "submitVerificationJobResponse")
    public JAXBElement<SubmitVerificationJobResponse> createSubmitVerificationJobResponse(SubmitVerificationJobResponse value) {
        return new JAXBElement<SubmitVerificationJobResponse>(_SubmitVerificationJobResponse_QNAME, SubmitVerificationJobResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetSearchJobStatusResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "getSearchJobStatusResponse")
    public JAXBElement<GetSearchJobStatusResponse> createGetSearchJobStatusResponse(GetSearchJobStatusResponse value) {
        return new JAXBElement<GetSearchJobStatusResponse>(_GetSearchJobStatusResponse_QNAME, GetSearchJobStatusResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetSyncJobStatus }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "getSyncJobStatus")
    public JAXBElement<GetSyncJobStatus> createGetSyncJobStatus(GetSyncJobStatus value) {
        return new JAXBElement<GetSyncJobStatus>(_GetSyncJobStatus_QNAME, GetSyncJobStatus.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BioTemplatePayload }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "bioTemplatePayload")
    public JAXBElement<BioTemplatePayload> createBioTemplatePayload(BioTemplatePayload value) {
        return new JAXBElement<BioTemplatePayload>(_BioTemplatePayload_QNAME, BioTemplatePayload.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetBiometricEventStatusInfoList }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "getBiometricEventStatusInfoList")
    public JAXBElement<GetBiometricEventStatusInfoList> createGetBiometricEventStatusInfoList(GetBiometricEventStatusInfoList value) {
        return new JAXBElement<GetBiometricEventStatusInfoList>(_GetBiometricEventStatusInfoList_QNAME, GetBiometricEventStatusInfoList.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetVerificationJobResultResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "getVerificationJobResultResponse")
    public JAXBElement<GetVerificationJobResultResponse> createGetVerificationJobResultResponse(GetVerificationJobResultResponse value) {
        return new JAXBElement<GetVerificationJobResultResponse>(_GetVerificationJobResultResponse_QNAME, GetVerificationJobResultResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteExtractionJobResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "deleteExtractionJobResponse")
    public JAXBElement<DeleteExtractionJobResponse> createDeleteExtractionJobResponse(DeleteExtractionJobResponse value) {
        return new JAXBElement<DeleteExtractionJobResponse>(_DeleteExtractionJobResponse_QNAME, DeleteExtractionJobResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteVerificationJobResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "deleteVerificationJobResponse")
    public JAXBElement<DeleteVerificationJobResponse> createDeleteVerificationJobResponse(DeleteVerificationJobResponse value) {
        return new JAXBElement<DeleteVerificationJobResponse>(_DeleteVerificationJobResponse_QNAME, DeleteVerificationJobResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BioType35Event }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "bioType35Event")
    public JAXBElement<BioType35Event> createBioType35Event(BioType35Event value) {
        return new JAXBElement<BioType35Event>(_BioType35Event_QNAME, BioType35Event.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ExtractInputParameter }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "extractInputParameter")
    public JAXBElement<ExtractInputParameter> createExtractInputParameter(ExtractInputParameter value) {
        return new JAXBElement<ExtractInputParameter>(_ExtractInputParameter_QNAME, ExtractInputParameter.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PalmExtractInputImage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "palmExtractInputImage")
    public JAXBElement<PalmExtractInputImage> createPalmExtractInputImage(PalmExtractInputImage value) {
        return new JAXBElement<PalmExtractInputImage>(_PalmExtractInputImage_QNAME, PalmExtractInputImage.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FingerExtractInputImage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "fingerExtractInputImage")
    public JAXBElement<FingerExtractInputImage> createFingerExtractInputImage(FingerExtractInputImage value) {
        return new JAXBElement<FingerExtractInputImage>(_FingerExtractInputImage_QNAME, FingerExtractInputImage.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SearchJobRequestDto }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "searchJobRequestDto")
    public JAXBElement<SearchJobRequestDto> createSearchJobRequestDto(SearchJobRequestDto value) {
        return new JAXBElement<SearchJobRequestDto>(_SearchJobRequestDto_QNAME, SearchJobRequestDto.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BioType31Event }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "bioType31Event")
    public JAXBElement<BioType31Event> createBioType31Event(BioType31Event value) {
        return new JAXBElement<BioType31Event>(_BioType31Event_QNAME, BioType31Event.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetExtractionJobStatus }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "getExtractionJobStatus")
    public JAXBElement<GetExtractionJobStatus> createGetExtractionJobStatus(GetExtractionJobStatus value) {
        return new JAXBElement<GetExtractionJobStatus>(_GetExtractionJobStatus_QNAME, GetExtractionJobStatus.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SubmitSyncJob }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "submitSyncJob")
    public JAXBElement<SubmitSyncJob> createSubmitSyncJob(SubmitSyncJob value) {
        return new JAXBElement<SubmitSyncJob>(_SubmitSyncJob_QNAME, SubmitSyncJob.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Echo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "echo")
    public JAXBElement<Echo> createEcho(Echo value) {
        return new JAXBElement<Echo>(_Echo_QNAME, Echo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteVerificationJob }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "deleteVerificationJob")
    public JAXBElement<DeleteVerificationJob> createDeleteVerificationJob(DeleteVerificationJob value) {
        return new JAXBElement<DeleteVerificationJob>(_DeleteVerificationJob_QNAME, DeleteVerificationJob.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetSyncJobResultResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "getSyncJobResultResponse")
    public JAXBElement<GetSyncJobResultResponse> createGetSyncJobResultResponse(GetSyncJobResultResponse value) {
        return new JAXBElement<GetSyncJobResultResponse>(_GetSyncJobResultResponse_QNAME, GetSyncJobResultResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteBiometricEventDto }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "deleteBiometricEventDto")
    public JAXBElement<DeleteBiometricEventDto> createDeleteBiometricEventDto(DeleteBiometricEventDto value) {
        return new JAXBElement<DeleteBiometricEventDto>(_DeleteBiometricEventDto_QNAME, DeleteBiometricEventDto.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BioType4Event }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "bioType4Event")
    public JAXBElement<BioType4Event> createBioType4Event(BioType4Event value) {
        return new JAXBElement<BioType4Event>(_BioType4Event_QNAME, BioType4Event.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BioPalmFeatureInfo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "bioPalmFeatureInfo")
    public JAXBElement<BioPalmFeatureInfo> createBioPalmFeatureInfo(BioPalmFeatureInfo value) {
        return new JAXBElement<BioPalmFeatureInfo>(_BioPalmFeatureInfo_QNAME, BioPalmFeatureInfo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TemplateInfo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "templateInfo")
    public JAXBElement<TemplateInfo> createTemplateInfo(TemplateInfo value) {
        return new JAXBElement<TemplateInfo>(_TemplateInfo_QNAME, TemplateInfo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetSearchJobResult }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "getSearchJobResult")
    public JAXBElement<GetSearchJobResult> createGetSearchJobResult(GetSearchJobResult value) {
        return new JAXBElement<GetSearchJobResult>(_GetSearchJobResult_QNAME, GetSearchJobResult.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetVerificationJobStatusResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "getVerificationJobStatusResponse")
    public JAXBElement<GetVerificationJobStatusResponse> createGetVerificationJobStatusResponse(GetVerificationJobStatusResponse value) {
        return new JAXBElement<GetVerificationJobStatusResponse>(_GetVerificationJobStatusResponse_QNAME, GetVerificationJobStatusResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Minutia }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "minutia")
    public JAXBElement<Minutia> createMinutia(Minutia value) {
        return new JAXBElement<Minutia>(_Minutia_QNAME, Minutia.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BioType33Event }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "bioType33Event")
    public JAXBElement<BioType33Event> createBioType33Event(BioType33Event value) {
        return new JAXBElement<BioType33Event>(_BioType33Event_QNAME, BioType33Event.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IrisExtractInputImage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "irisExtractInputImage")
    public JAXBElement<IrisExtractInputImage> createIrisExtractInputImage(IrisExtractInputImage value) {
        return new JAXBElement<IrisExtractInputImage>(_IrisExtractInputImage_QNAME, IrisExtractInputImage.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link VerifyJobRequestDto }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "verifyJobRequestDto")
    public JAXBElement<VerifyJobRequestDto> createVerifyJobRequestDto(VerifyJobRequestDto value) {
        return new JAXBElement<VerifyJobRequestDto>(_VerifyJobRequestDto_QNAME, VerifyJobRequestDto.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BioType48Event }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "bioType48Event")
    public JAXBElement<BioType48Event> createBioType48Event(BioType48Event value) {
        return new JAXBElement<BioType48Event>(_BioType48Event_QNAME, BioType48Event.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EchoResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "echoResponse")
    public JAXBElement<EchoResponse> createEchoResponse(EchoResponse value) {
        return new JAXBElement<EchoResponse>(_EchoResponse_QNAME, EchoResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BioType38Event }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "bioType38Event")
    public JAXBElement<BioType38Event> createBioType38Event(BioType38Event value) {
        return new JAXBElement<BioType38Event>(_BioType38Event_QNAME, BioType38Event.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SubmitExtractionJob }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "submitExtractionJob")
    public JAXBElement<SubmitExtractionJob> createSubmitExtractionJob(SubmitExtractionJob value) {
        return new JAXBElement<SubmitExtractionJob>(_SubmitExtractionJob_QNAME, SubmitExtractionJob.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link VerifyResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "verifyResponse")
    public JAXBElement<VerifyResponse> createVerifyResponse(VerifyResponse value) {
        return new JAXBElement<VerifyResponse>(_VerifyResponse_QNAME, VerifyResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BioParameterDto }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "bioParameterDto")
    public JAXBElement<BioParameterDto> createBioParameterDto(BioParameterDto value) {
        return new JAXBElement<BioParameterDto>(_BioParameterDto_QNAME, BioParameterDto.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BioType12Event }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "bioType12Event")
    public JAXBElement<BioType12Event> createBioType12Event(BioType12Event value) {
        return new JAXBElement<BioType12Event>(_BioType12Event_QNAME, BioType12Event.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BioType32Event }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "bioType32Event")
    public JAXBElement<BioType32Event> createBioType32Event(BioType32Event value) {
        return new JAXBElement<BioType32Event>(_BioType32Event_QNAME, BioType32Event.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SearchStatistics }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "searchStatistics")
    public JAXBElement<SearchStatistics> createSearchStatistics(SearchStatistics value) {
        return new JAXBElement<SearchStatistics>(_SearchStatistics_QNAME, SearchStatistics.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FeatureExtractInputImage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "featureExtractInputImage")
    public JAXBElement<FeatureExtractInputImage> createFeatureExtractInputImage(FeatureExtractInputImage value) {
        return new JAXBElement<FeatureExtractInputImage>(_FeatureExtractInputImage_QNAME, FeatureExtractInputImage.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteSyncJob }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "deleteSyncJob")
    public JAXBElement<DeleteSyncJob> createDeleteSyncJob(DeleteSyncJob value) {
        return new JAXBElement<DeleteSyncJob>(_DeleteSyncJob_QNAME, DeleteSyncJob.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteSyncJobResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "deleteSyncJobResponse")
    public JAXBElement<DeleteSyncJobResponse> createDeleteSyncJobResponse(DeleteSyncJobResponse value) {
        return new JAXBElement<DeleteSyncJobResponse>(_DeleteSyncJobResponse_QNAME, DeleteSyncJobResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateBiometricEventUserFlagDto }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "updateBiometricEventUserFlagDto")
    public JAXBElement<UpdateBiometricEventUserFlagDto> createUpdateBiometricEventUserFlagDto(UpdateBiometricEventUserFlagDto value) {
        return new JAXBElement<UpdateBiometricEventUserFlagDto>(_UpdateBiometricEventUserFlagDto_QNAME, UpdateBiometricEventUserFlagDto.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SearchRequestItemDto }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "searchRequestItemDto")
    public JAXBElement<SearchRequestItemDto> createSearchRequestItemDto(SearchRequestItemDto value) {
        return new JAXBElement<SearchRequestItemDto>(_SearchRequestItemDto_QNAME, SearchRequestItemDto.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BioType47Event }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "bioType47Event")
    public JAXBElement<BioType47Event> createBioType47Event(BioType47Event value) {
        return new JAXBElement<BioType47Event>(_BioType47Event_QNAME, BioType47Event.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ErrorMessageDto }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "errorMessageDto")
    public JAXBElement<ErrorMessageDto> createErrorMessageDto(ErrorMessageDto value) {
        return new JAXBElement<ErrorMessageDto>(_ErrorMessageDto_QNAME, ErrorMessageDto.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ProbeInfoDto }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "probeInfoDto")
    public JAXBElement<ProbeInfoDto> createProbeInfoDto(ProbeInfoDto value) {
        return new JAXBElement<ProbeInfoDto>(_ProbeInfoDto_QNAME, ProbeInfoDto.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link InsertTemplateInfo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "insertTemplateInfo")
    public JAXBElement<InsertTemplateInfo> createInsertTemplateInfo(InsertTemplateInfo value) {
        return new JAXBElement<InsertTemplateInfo>(_InsertTemplateInfo_QNAME, InsertTemplateInfo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BioFingerFeatureInfo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "bioFingerFeatureInfo")
    public JAXBElement<BioFingerFeatureInfo> createBioFingerFeatureInfo(BioFingerFeatureInfo value) {
        return new JAXBElement<BioFingerFeatureInfo>(_BioFingerFeatureInfo_QNAME, BioFingerFeatureInfo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetBiometricEventStatusInfo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "getBiometricEventStatusInfo")
    public JAXBElement<GetBiometricEventStatusInfo> createGetBiometricEventStatusInfo(GetBiometricEventStatusInfo value) {
        return new JAXBElement<GetBiometricEventStatusInfo>(_GetBiometricEventStatusInfo_QNAME, GetBiometricEventStatusInfo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Image }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "image")
    public JAXBElement<Image> createImage(Image value) {
        return new JAXBElement<Image>(_Image_QNAME, Image.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SearchJobResultDto }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "searchJobResultDto")
    public JAXBElement<SearchJobResultDto> createSearchJobResultDto(SearchJobResultDto value) {
        return new JAXBElement<SearchJobResultDto>(_SearchJobResultDto_QNAME, SearchJobResultDto.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetSyncJobStatusResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "getSyncJobStatusResponse")
    public JAXBElement<GetSyncJobStatusResponse> createGetSyncJobStatusResponse(GetSyncJobStatusResponse value) {
        return new JAXBElement<GetSyncJobStatusResponse>(_GetSyncJobStatusResponse_QNAME, GetSyncJobStatusResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BioType46Event }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "bioType46Event")
    public JAXBElement<BioType46Event> createBioType46Event(BioType46Event value) {
        return new JAXBElement<BioType46Event>(_BioType46Event_QNAME, BioType46Event.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MultiModalExtractInputImage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "multiModalExtractInputImage")
    public JAXBElement<MultiModalExtractInputImage> createMultiModalExtractInputImage(MultiModalExtractInputImage value) {
        return new JAXBElement<MultiModalExtractInputImage>(_MultiModalExtractInputImage_QNAME, MultiModalExtractInputImage.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BioType41Event }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "bioType41Event")
    public JAXBElement<BioType41Event> createBioType41Event(BioType41Event value) {
        return new JAXBElement<BioType41Event>(_BioType41Event_QNAME, BioType41Event.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetSearchJobStatus }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "getSearchJobStatus")
    public JAXBElement<GetSearchJobStatus> createGetSearchJobStatus(GetSearchJobStatus value) {
        return new JAXBElement<GetSearchJobStatus>(_GetSearchJobStatus_QNAME, GetSearchJobStatus.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SubmitSearchJob }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "submitSearchJob")
    public JAXBElement<SubmitSearchJob> createSubmitSearchJob(SubmitSearchJob value) {
        return new JAXBElement<SubmitSearchJob>(_SubmitSearchJob_QNAME, SubmitSearchJob.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteSearchJob }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "deleteSearchJob")
    public JAXBElement<DeleteSearchJob> createDeleteSearchJob(DeleteSearchJob value) {
        return new JAXBElement<DeleteSearchJob>(_DeleteSearchJob_QNAME, DeleteSearchJob.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ExtractInputPayloadDto }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "extractInputPayloadDto")
    public JAXBElement<ExtractInputPayloadDto> createExtractInputPayloadDto(ExtractInputPayloadDto value) {
        return new JAXBElement<ExtractInputPayloadDto>(_ExtractInputPayloadDto_QNAME, ExtractInputPayloadDto.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SyncJobRequestDto }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "syncJobRequestDto")
    public JAXBElement<SyncJobRequestDto> createSyncJobRequestDto(SyncJobRequestDto value) {
        return new JAXBElement<SyncJobRequestDto>(_SyncJobRequestDto_QNAME, SyncJobRequestDto.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BioType1Event }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "bioType1Event")
    public JAXBElement<BioType1Event> createBioType1Event(BioType1Event value) {
        return new JAXBElement<BioType1Event>(_BioType1Event_QNAME, BioType1Event.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetVerificationJobResult }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "getVerificationJobResult")
    public JAXBElement<GetVerificationJobResult> createGetVerificationJobResult(GetVerificationJobResult value) {
        return new JAXBElement<GetVerificationJobResult>(_GetVerificationJobResult_QNAME, GetVerificationJobResult.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Verify }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "verify")
    public JAXBElement<Verify> createVerify(Verify value) {
        return new JAXBElement<Verify>(_Verify_QNAME, Verify.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetSyncJobResult }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "getSyncJobResult")
    public JAXBElement<GetSyncJobResult> createGetSyncJobResult(GetSyncJobResult value) {
        return new JAXBElement<GetSyncJobResult>(_GetSyncJobResult_QNAME, GetSyncJobResult.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SubmitSearchJobResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "submitSearchJobResponse")
    public JAXBElement<SubmitSearchJobResponse> createSubmitSearchJobResponse(SubmitSearchJobResponse value) {
        return new JAXBElement<SubmitSearchJobResponse>(_SubmitSearchJobResponse_QNAME, SubmitSearchJobResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BioType40Event }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "bioType40Event")
    public JAXBElement<BioType40Event> createBioType40Event(BioType40Event value) {
        return new JAXBElement<BioType40Event>(_BioType40Event_QNAME, BioType40Event.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SearchOptionsDto }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "searchOptionsDto")
    public JAXBElement<SearchOptionsDto> createSearchOptionsDto(SearchOptionsDto value) {
        return new JAXBElement<SearchOptionsDto>(_SearchOptionsDto_QNAME, SearchOptionsDto.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link VerifyBiometricData }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "verifyBiometricData")
    public JAXBElement<VerifyBiometricData> createVerifyBiometricData(VerifyBiometricData value) {
        return new JAXBElement<VerifyBiometricData>(_VerifyBiometricData_QNAME, VerifyBiometricData.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetVerificationJobStatus }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "getVerificationJobStatus")
    public JAXBElement<GetVerificationJobStatus> createGetVerificationJobStatus(GetVerificationJobStatus value) {
        return new JAXBElement<GetVerificationJobStatus>(_GetVerificationJobStatus_QNAME, GetVerificationJobStatus.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BioType36Event }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "bioType36Event")
    public JAXBElement<BioType36Event> createBioType36Event(BioType36Event value) {
        return new JAXBElement<BioType36Event>(_BioType36Event_QNAME, BioType36Event.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetExtractionJobResult }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "getExtractionJobResult")
    public JAXBElement<GetExtractionJobResult> createGetExtractionJobResult(GetExtractionJobResult value) {
        return new JAXBElement<GetExtractionJobResult>(_GetExtractionJobResult_QNAME, GetExtractionJobResult.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetSearchJobResultResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "getSearchJobResultResponse")
    public JAXBElement<GetSearchJobResultResponse> createGetSearchJobResultResponse(GetSearchJobResultResponse value) {
        return new JAXBElement<GetSearchJobResultResponse>(_GetSearchJobResultResponse_QNAME, GetSearchJobResultResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TemplateExtractInputImage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "templateExtractInputImage")
    public JAXBElement<TemplateExtractInputImage> createTemplateExtractInputImage(TemplateExtractInputImage value) {
        return new JAXBElement<TemplateExtractInputImage>(_TemplateExtractInputImage_QNAME, TemplateExtractInputImage.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FaceExtractInputImage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservices.biomatcher.nec.com/", name = "faceExtractInputImage")
    public JAXBElement<FaceExtractInputImage> createFaceExtractInputImage(FaceExtractInputImage value) {
        return new JAXBElement<FaceExtractInputImage>(_FaceExtractInputImage_QNAME, FaceExtractInputImage.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ExtractJobResultDto }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "extractJobResult", scope = SearchJobResultDto.class)
    public JAXBElement<ExtractJobResultDto> createSearchJobResultDtoExtractJobResult(ExtractJobResultDto value) {
        return new JAXBElement<ExtractJobResultDto>(_SearchJobResultDtoExtractJobResult_QNAME, ExtractJobResultDto.class, SearchJobResultDto.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link VerifyBiometricData }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "probeBiomericData", scope = VerifyJobRequestDto.class)
    public JAXBElement<VerifyBiometricData> createVerifyJobRequestDtoProbeBiomericData(VerifyBiometricData value) {
        return new JAXBElement<VerifyBiometricData>(_VerifyJobRequestDtoProbeBiomericData_QNAME, VerifyBiometricData.class, VerifyJobRequestDto.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "priority", scope = VerifyJobRequestDto.class)
    public JAXBElement<Integer> createVerifyJobRequestDtoPriority(Integer value) {
        return new JAXBElement<Integer>(_SearchJobRequestDtoPriority_QNAME, Integer.class, VerifyJobRequestDto.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "candidateId", scope = ExtractInputPayloadDto.class)
    public JAXBElement<String> createExtractInputPayloadDtoCandidateId(String value) {
        return new JAXBElement<String>(_ExtractInputPayloadDtoCandidateId_QNAME, String.class, ExtractInputPayloadDto.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MetaInfoCommon }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "metaInfoCommon", scope = ExtractInputPayloadDto.class)
    public JAXBElement<MetaInfoCommon> createExtractInputPayloadDtoMetaInfoCommon(MetaInfoCommon value) {
        return new JAXBElement<MetaInfoCommon>(_ExtractInputPayloadDtoMetaInfoCommon_QNAME, MetaInfoCommon.class, ExtractInputPayloadDto.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "biometricId", scope = ExtractInputPayloadDto.class)
    public JAXBElement<Long> createExtractInputPayloadDtoBiometricId(Long value) {
        return new JAXBElement<Long>(_ExtractInputPayloadDtoBiometricId_QNAME, Long.class, ExtractInputPayloadDto.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "eventId", scope = ExtractInputPayloadDto.class)
    public JAXBElement<String> createExtractInputPayloadDtoEventId(String value) {
        return new JAXBElement<String>(_ExtractInputPayloadDtoEventId_QNAME, String.class, ExtractInputPayloadDto.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "regionFlags", scope = MetaInfoCommon.class)
    public JAXBElement<Long> createMetaInfoCommonRegionFlags(Long value) {
        return new JAXBElement<Long>(_MetaInfoCommonRegionFlags_QNAME, Long.class, MetaInfoCommon.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "targetQualityThreshold", scope = MetaInfoCommon.class)
    public JAXBElement<Integer> createMetaInfoCommonTargetQualityThreshold(Integer value) {
        return new JAXBElement<Integer>(_MetaInfoCommonTargetQualityThreshold_QNAME, Integer.class, MetaInfoCommon.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "yob", scope = MetaInfoCommon.class)
    public JAXBElement<Integer> createMetaInfoCommonYob(Integer value) {
        return new JAXBElement<Integer>(_MetaInfoCommonYob_QNAME, Integer.class, MetaInfoCommon.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "yobRange", scope = MetaInfoCommon.class)
    public JAXBElement<Integer> createMetaInfoCommonYobRange(Integer value) {
        return new JAXBElement<Integer>(_MetaInfoCommonYobRange_QNAME, Integer.class, MetaInfoCommon.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "userFlags", scope = MetaInfoCommon.class)
    public JAXBElement<String> createMetaInfoCommonUserFlags(String value) {
        return new JAXBElement<String>(_MetaInfoCommonUserFlags_QNAME, String.class, MetaInfoCommon.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "height", scope = Image.class)
    public JAXBElement<Integer> createImageHeight(Integer value) {
        return new JAXBElement<Integer>(_ImageHeight_QNAME, Integer.class, Image.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "width", scope = Image.class)
    public JAXBElement<Integer> createImageWidth(Integer value) {
        return new JAXBElement<Integer>(_ImageWidth_QNAME, Integer.class, Image.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Modality }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "modality", scope = Image.class)
    public JAXBElement<Modality> createImageModality(Modality value) {
        return new JAXBElement<Modality>(_ImageModality_QNAME, Modality.class, Image.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "dpi", scope = Image.class)
    public JAXBElement<Integer> createImageDpi(Integer value) {
        return new JAXBElement<Integer>(_ImageDpi_QNAME, Integer.class, Image.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ExtractManualData }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "manualData", scope = Image.class)
    public JAXBElement<ExtractManualData> createImageManualData(ExtractManualData value) {
        return new JAXBElement<ExtractManualData>(_ImageManualData_QNAME, ExtractManualData.class, Image.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "priority", scope = ExtractJobRequestDto.class)
    public JAXBElement<Integer> createExtractJobRequestDtoPriority(Integer value) {
        return new JAXBElement<Integer>(_SearchJobRequestDtoPriority_QNAME, Integer.class, ExtractJobRequestDto.class, value);
    }

}
