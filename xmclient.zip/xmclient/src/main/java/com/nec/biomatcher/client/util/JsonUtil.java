package com.nec.biomatcher.client.util;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Paths;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.nec.biomatcher.webservices.SearchJobResultDto;

public class JsonUtil {

	public JsonUtil() {
	}

	private static final JsonUtil INSTANCE = new JsonUtil();

	public JsonUtil getInstance() {
		return INSTANCE;
	}

	public void toJson(SearchJobResultDto result) {
		ObjectMapper mapper = new ObjectMapper();
		try {
			mapper.writeValue(new File("D:\\result.json"), result);
			String jsonInString = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(result);
			System.out.println(jsonInString);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public SearchJobResultDto json2Java() {
		ObjectMapper mapper = new ObjectMapper();
		SearchJobResultDto result = null;
		try {
			result = mapper.readValue(new File("D:\\result.json"), SearchJobResultDto.class);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return result;
	}

	public void gsonToJson(SearchJobResultDto result) {
		Gson gson = new Gson();
		String json = gson.toJson(result);
		System.out.println(json);
		try (FileWriter writer = new FileWriter("D:\\result.json")) {
			gson.toJson(result, writer);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public SearchJobResultDto gson2java() {
		Gson gson = new Gson();
		SearchJobResultDto result = null;
		try (Reader reader = new FileReader("D:\\result.json")) {
			result = gson.fromJson(reader, SearchJobResultDto.class);
			JsonElement json = gson.fromJson(reader, JsonElement.class);
			String jsonInString = gson.toJson(json);
			System.out.println(jsonInString);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return result;
	}
	
	public void moreOne() {
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		try {
			String fileData = new String(Files.readAllBytes(Paths.get("SearchJobResultDto.json")));
			SearchJobResultDto result = gson.fromJson(fileData, SearchJobResultDto.class);
			String jsonEmp = gson.toJson(result);
			System.out.print(jsonEmp);

		} catch (IOException e) {			
			e.printStackTrace();
		}
	}

}
