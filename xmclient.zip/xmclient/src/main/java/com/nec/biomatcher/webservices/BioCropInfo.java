
package com.nec.biomatcher.webservices;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for bioCropInfo complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="bioCropInfo">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="center" type="{http://webservices.biomatcher.nec.com/}pointDto" minOccurs="0"/>
 *         &lt;element name="rectangle" type="{http://webservices.biomatcher.nec.com/}bioRectangle" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="angle" type="{http://www.w3.org/2001/XMLSchema}int" />
 *       &lt;attribute name="amputation" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *       &lt;attribute name="position" type="{http://webservices.biomatcher.nec.com/}imagePosition" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "bioCropInfo", propOrder = {
    "center",
    "rectangle"
})
public class BioCropInfo {

    protected PointDto center;
    protected BioRectangle rectangle;
    @XmlAttribute
    protected Integer angle;
    @XmlAttribute
    protected Boolean amputation;
    @XmlAttribute
    protected ImagePosition position;

    /**
     * Gets the value of the center property.
     * 
     * @return
     *     possible object is
     *     {@link PointDto }
     *     
     */
    public PointDto getCenter() {
        return center;
    }

    /**
     * Sets the value of the center property.
     * 
     * @param value
     *     allowed object is
     *     {@link PointDto }
     *     
     */
    public void setCenter(PointDto value) {
        this.center = value;
    }

    /**
     * Gets the value of the rectangle property.
     * 
     * @return
     *     possible object is
     *     {@link BioRectangle }
     *     
     */
    public BioRectangle getRectangle() {
        return rectangle;
    }

    /**
     * Sets the value of the rectangle property.
     * 
     * @param value
     *     allowed object is
     *     {@link BioRectangle }
     *     
     */
    public void setRectangle(BioRectangle value) {
        this.rectangle = value;
    }

    /**
     * Gets the value of the angle property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getAngle() {
        return angle;
    }

    /**
     * Sets the value of the angle property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setAngle(Integer value) {
        this.angle = value;
    }

    /**
     * Gets the value of the amputation property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isAmputation() {
        return amputation;
    }

    /**
     * Sets the value of the amputation property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setAmputation(Boolean value) {
        this.amputation = value;
    }

    /**
     * Gets the value of the position property.
     * 
     * @return
     *     possible object is
     *     {@link ImagePosition }
     *     
     */
    public ImagePosition getPosition() {
        return position;
    }

    /**
     * Sets the value of the position property.
     * 
     * @param value
     *     allowed object is
     *     {@link ImagePosition }
     *     
     */
    public void setPosition(ImagePosition value) {
        this.position = value;
    }

}
