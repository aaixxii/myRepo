
package com.nec.biomatcher.webservices;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for lfmlData complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="lfmlData">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="minutia" type="{http://webservices.biomatcher.nec.com/}minutia" minOccurs="0"/>
 *         &lt;element name="skeleton" type="{http://webservices.biomatcher.nec.com/}skeleton"/>
 *       &lt;/sequence>
 *       &lt;attribute name="index" use="required" type="{http://www.w3.org/2001/XMLSchema}int" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "lfmlData", propOrder = {
    "minutia",
    "skeleton"
})
public class LfmlData {

    protected Minutia minutia;
    @XmlElement(required = true)
    protected Skeleton skeleton;
    @XmlAttribute(required = true)
    protected int index;

    /**
     * Gets the value of the minutia property.
     * 
     * @return
     *     possible object is
     *     {@link Minutia }
     *     
     */
    public Minutia getMinutia() {
        return minutia;
    }

    /**
     * Sets the value of the minutia property.
     * 
     * @param value
     *     allowed object is
     *     {@link Minutia }
     *     
     */
    public void setMinutia(Minutia value) {
        this.minutia = value;
    }

    /**
     * Gets the value of the skeleton property.
     * 
     * @return
     *     possible object is
     *     {@link Skeleton }
     *     
     */
    public Skeleton getSkeleton() {
        return skeleton;
    }

    /**
     * Sets the value of the skeleton property.
     * 
     * @param value
     *     allowed object is
     *     {@link Skeleton }
     *     
     */
    public void setSkeleton(Skeleton value) {
        this.skeleton = value;
    }

    /**
     * Gets the value of the index property.
     * 
     */
    public int getIndex() {
        return index;
    }

    /**
     * Sets the value of the index property.
     * 
     */
    public void setIndex(int value) {
        this.index = value;
    }

}
