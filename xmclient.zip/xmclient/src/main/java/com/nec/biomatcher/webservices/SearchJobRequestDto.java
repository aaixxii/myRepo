
package com.nec.biomatcher.webservices;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for searchJobRequestDto complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="searchJobRequestDto">
 *   &lt;complexContent>
 *     &lt;extension base="{http://webservices.biomatcher.nec.com/}bioMatcherJobRequest">
 *       &lt;sequence>
 *         &lt;element name="extractInputPayloadDto" type="{http://webservices.biomatcher.nec.com/}extractInputPayloadDto" minOccurs="0"/>
 *         &lt;element name="searchRequestItemList" type="{http://webservices.biomatcher.nec.com/}searchRequestItemDto" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="callbackUrl" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="jobTimeoutMill" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="jobMode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="matchInputParameterList" type="{http://webservices.biomatcher.nec.com/}matchInputParameter" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="priority" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="capacityGroupKey" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="searchFunctionId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="includeExtractionResult" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "searchJobRequestDto", propOrder = {
    "extractInputPayloadDto",
    "searchRequestItemList",
    "callbackUrl",
    "jobTimeoutMill",
    "jobMode",
    "matchInputParameterList",
    "priority",
    "capacityGroupKey",
    "searchFunctionId",
    "includeExtractionResult"
})
public class SearchJobRequestDto
    extends BioMatcherJobRequest
{

    protected ExtractInputPayloadDto extractInputPayloadDto;
    @XmlElement(nillable = true)
    protected List<SearchRequestItemDto> searchRequestItemList;
    protected String callbackUrl;
    protected Long jobTimeoutMill;
    protected String jobMode;
    @XmlElement(nillable = true)
    protected List<MatchInputParameter> matchInputParameterList;
    @XmlElementRef(name = "priority", type = JAXBElement.class)
    protected JAXBElement<Integer> priority;
    @XmlElementRef(name = "capacityGroupKey", type = JAXBElement.class)
    protected JAXBElement<String> capacityGroupKey;
    @XmlElementRef(name = "searchFunctionId", type = JAXBElement.class)
    protected JAXBElement<String> searchFunctionId;
    @XmlElementRef(name = "includeExtractionResult", type = JAXBElement.class)
    protected JAXBElement<Boolean> includeExtractionResult;

    /**
     * Gets the value of the extractInputPayloadDto property.
     * 
     * @return
     *     possible object is
     *     {@link ExtractInputPayloadDto }
     *     
     */
    public ExtractInputPayloadDto getExtractInputPayloadDto() {
        return extractInputPayloadDto;
    }

    /**
     * Sets the value of the extractInputPayloadDto property.
     * 
     * @param value
     *     allowed object is
     *     {@link ExtractInputPayloadDto }
     *     
     */
    public void setExtractInputPayloadDto(ExtractInputPayloadDto value) {
        this.extractInputPayloadDto = value;
    }

    /**
     * Gets the value of the searchRequestItemList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the searchRequestItemList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSearchRequestItemList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SearchRequestItemDto }
     * 
     * 
     */
    public List<SearchRequestItemDto> getSearchRequestItemList() {
        if (searchRequestItemList == null) {
            searchRequestItemList = new ArrayList<SearchRequestItemDto>();
        }
        return this.searchRequestItemList;
    }

    /**
     * Gets the value of the callbackUrl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCallbackUrl() {
        return callbackUrl;
    }

    /**
     * Sets the value of the callbackUrl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCallbackUrl(String value) {
        this.callbackUrl = value;
    }

    /**
     * Gets the value of the jobTimeoutMill property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getJobTimeoutMill() {
        return jobTimeoutMill;
    }

    /**
     * Sets the value of the jobTimeoutMill property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setJobTimeoutMill(Long value) {
        this.jobTimeoutMill = value;
    }

    /**
     * Gets the value of the jobMode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJobMode() {
        return jobMode;
    }

    /**
     * Sets the value of the jobMode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJobMode(String value) {
        this.jobMode = value;
    }

    /**
     * Gets the value of the matchInputParameterList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the matchInputParameterList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMatchInputParameterList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link MatchInputParameter }
     * 
     * 
     */
    public List<MatchInputParameter> getMatchInputParameterList() {
        if (matchInputParameterList == null) {
            matchInputParameterList = new ArrayList<MatchInputParameter>();
        }
        return this.matchInputParameterList;
    }

    /**
     * Gets the value of the priority property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public JAXBElement<Integer> getPriority() {
        return priority;
    }

    /**
     * Sets the value of the priority property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public void setPriority(JAXBElement<Integer> value) {
        this.priority = ((JAXBElement<Integer> ) value);
    }

    /**
     * Gets the value of the capacityGroupKey property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCapacityGroupKey() {
        return capacityGroupKey;
    }

    /**
     * Sets the value of the capacityGroupKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCapacityGroupKey(JAXBElement<String> value) {
        this.capacityGroupKey = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the searchFunctionId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSearchFunctionId() {
        return searchFunctionId;
    }

    /**
     * Sets the value of the searchFunctionId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSearchFunctionId(JAXBElement<String> value) {
        this.searchFunctionId = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the includeExtractionResult property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Boolean }{@code >}
     *     
     */
    public JAXBElement<Boolean> getIncludeExtractionResult() {
        return includeExtractionResult;
    }

    /**
     * Sets the value of the includeExtractionResult property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Boolean }{@code >}
     *     
     */
    public void setIncludeExtractionResult(JAXBElement<Boolean> value) {
        this.includeExtractionResult = ((JAXBElement<Boolean> ) value);
    }

}
