package com.nec.biomatcher.client.request.creater;

import static com.nec.biomatcher.client.common.XmClientConstants.CLIENT_CALLBACK_IP;
import static com.nec.biomatcher.client.common.XmClientConstants.CLIENT_CALLBACK_PORT;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.biomatcher.client.manager.XmClientManager;
import com.nec.biomatcher.webservices.BiometricEventSyncTypeDto;
import com.nec.biomatcher.webservices.DeleteBiometricEventDto;
import com.nec.biomatcher.webservices.SyncJobRequestDto;

public class SyncDeleteJobRequestCreater {	
	private String reqeustFileFullName;	
		
	private String eventId;
	private String externalId;	   
	private List<Integer> binIdSet;	
	private static Logger logger = LoggerFactory.getLogger(SyncUpdateJobRequestCreater.class);	
	
	public SyncDeleteJobRequestCreater(String reqeustFileFullName) {
		this.reqeustFileFullName = reqeustFileFullName;
	}
	
	
	public SyncJobRequestDto buildSyncDeleteRequest() {		
		String callbackIp = XmClientManager.getInstance().getValue(CLIENT_CALLBACK_IP);
		String callbackPort = XmClientManager.getInstance().getValue(CLIENT_CALLBACK_PORT);
		String callbackUrl = "http://" + callbackIp + ":" + callbackPort;		
		SyncJobRequestDto syncJobRequestDto = new SyncJobRequestDto();
		syncJobRequestDto.setCallbackUrl(callbackUrl);				
		syncJobRequestDto.setJobMode("strict");
		syncJobRequestDto.setJobTimeoutMill(3600000L);		
		List<BiometricEventSyncTypeDto>  syncList = new ArrayList<>();
		syncList.add(buildDeleteBiometricEventDto());
		syncJobRequestDto.getEventSyncDtoList().addAll(syncList);
		return syncJobRequestDto;		
	}
	
	private DeleteBiometricEventDto buildDeleteBiometricEventDto() {
		readDatFileData();
		DeleteBiometricEventDto dbeDto = new DeleteBiometricEventDto();		
		//dbeDto.getBinIdSet().addAll(Arrays.asList( new Integer[] {35}));
		dbeDto.getBinIdSet().addAll(binIdSet);
		dbeDto.setEventId(eventId);
		dbeDto.setExternalId(externalId);
		return dbeDto;		
	}
	
	private void readDatFileData() {
		File templateFile = new File(reqeustFileFullName);
		if (!templateFile.exists() || !templateFile.isFile()) {
			logger.error("The template file is wrong. skip process...");			
		}		
	}
}
