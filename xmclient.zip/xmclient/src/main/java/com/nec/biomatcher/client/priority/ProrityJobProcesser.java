package com.nec.biomatcher.client.priority;

import static com.nec.biomatcher.client.common.XmClientConstants.PRIORITY_JOB_INFO_FIRST_SEPARATOR;
import static com.nec.biomatcher.client.common.XmClientConstants.PRIORITY_JOB_INFO_SECOND_SEPARATOR;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.biomatcher.client.util.WsdlUtil;
import com.nec.biomatcher.webservices.BioMatcherWebServiceInterface;
import com.nec.biomatcher.webservices.ExtractJobRequestDto;
import com.nec.biomatcher.webservices.SearchJobRequestDto;
import com.nec.biomatcher.webservices.VerifyJobRequestDto;

public class ProrityJobProcesser {
	private String prirotyJobInfo;
	private String templatePath;
	

	private static Logger logger = LoggerFactory.getLogger(ProrityJobProcesser.class);

	public ProrityJobProcesser(String prirotyJobInfo, String templatePath) {
		this.prirotyJobInfo = prirotyJobInfo;
		this.templatePath = templatePath;
	}

	public void parsePrirotyJobInfo() {
		prirotyJobInfo = prirotyJobInfo.substring(1, prirotyJobInfo.length() -1);
		String[] firstArry = prirotyJobInfo.split(PRIORITY_JOB_INFO_FIRST_SEPARATOR);
		for (int i = 0; i < firstArry.length; i++) {
			String[] secondArry = firstArry[i].split(PRIORITY_JOB_INFO_SECOND_SEPARATOR);			
				submitPrirotyJob(secondArry[0], Integer.valueOf(secondArry[1]), Integer.valueOf(secondArry[2]));		
		}
	}
	
	private void submitPrirotyJob(String function, Integer priority, Integer jobCount) {
		BioMatcherWebServiceInterface xmWebService = WsdlUtil.getXmWebService();
		switch (function.toUpperCase()) {
		case "TI":
			TIPriorityJobReqeustCreater create = new TIPriorityJobReqeustCreater(priority, jobCount, templatePath);
			List<SearchJobRequestDto> tiReqs = create.createSeachJobRequest();
			for (SearchJobRequestDto exq : tiReqs) {
				String jobId = xmWebService.submitSearchJob(exq);
				logger.info("Send searchJob to megha is competed. jobId=" + jobId);		
			}			
			break;
		case "FI":
			FIPriorityJobReqeustCreater fiCreater = new FIPriorityJobReqeustCreater(priority, jobCount, templatePath);
			List<SearchJobRequestDto> fiReqs = fiCreater.createSeachJobRequest();
			for (SearchJobRequestDto exq : fiReqs) {
				String jobId = xmWebService.submitSearchJob(exq);
				logger.info("Send searchJob to megha is competed. jobId=" + jobId);		
			}			
			break;
		case "II":
			IIPriorityJobReqeustCreater iiCreater = new IIPriorityJobReqeustCreater(priority, jobCount, templatePath);
			List<SearchJobRequestDto> iiReqs = iiCreater.createSeachJobRequest();
			for (SearchJobRequestDto exq : iiReqs) {
				String jobId = xmWebService.submitSearchJob(exq);
				logger.info("Send searchJob to megha is competed. jobId=" + jobId);		
			}			
			break;
		case "EXTRACT":
			ExtractPriorityJobReqeustCreater exCreater = new ExtractPriorityJobReqeustCreater(priority, jobCount, templatePath);
			 List<ExtractJobRequestDto> exRequests = exCreater.createExtractJobRequest();
			 for (ExtractJobRequestDto exq : exRequests)  {
					String jobId = xmWebService.submitExtractionJob(exq);
					logger.info("Send extractJob to megha is competed. jobId=" + jobId);
			 }
			break;
		case "VERIFY":
			VerifyPriorityJobReqeustCreater veCreater = new VerifyPriorityJobReqeustCreater(priority, jobCount, templatePath);
			 List<VerifyJobRequestDto> veRequests = veCreater.createVerifyJobRequest();
			 for (VerifyJobRequestDto veq : veRequests)  {
					String jobId = xmWebService.submitVerificationJob(veq);
					logger.info("Send verifyJob to megha is competed. jobId=" + jobId);
			 }			
			break;
		case "TI_36":
			//ToDo
			FIImagePriorityJobReqeustCreater fiImageCreater = new FIImagePriorityJobReqeustCreater(priority, jobCount, templatePath);
			List<SearchJobRequestDto> fiImageReqs = fiImageCreater.createSeachJobRequest();
			for (SearchJobRequestDto exq : fiImageReqs) {
				String jobId = xmWebService.submitSearchJob(exq);
				logger.info("Send searchJob to megha is competed. jobId=" + jobId);		
			}					
			break;
			
		case "LI":
			//ToDo
			TILIPriorityJobReqeustCreater tiLICreater = new TILIPriorityJobReqeustCreater(jobCount, templatePath);			
			 List<SearchJobRequestDto> tiLiRequests = tiLICreater.createSeachJobRequest();
			 for (SearchJobRequestDto seq : tiLiRequests)  {
					String jobId = xmWebService.submitSearchJob(seq);
					logger.info("Send searchJob to megha is competed. jobId=" + jobId);
			 }			
			break;			
			
		default:
			logger.warn("No support function!");
		}
	}

}
