package com.nec.biomatcher.client.util;

public interface JaxbFunction<T> {
	
	public T unmarshal(String path);	
	public void marshal(T t, String path) ;
}
