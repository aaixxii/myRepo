
package com.nec.biomatcher.webservices;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for modality.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="modality">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="FACE"/>
 *     &lt;enumeration value="IRIS"/>
 *     &lt;enumeration value="FINGER"/>
 *     &lt;enumeration value="PALM"/>
 *     &lt;enumeration value="MULTI_MODAL"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "modality")
@XmlEnum
public enum Modality {

    FACE,
    IRIS,
    FINGER,
    PALM,
    MULTI_MODAL;

    public String value() {
        return name();
    }

    public static Modality fromValue(String v) {
        return valueOf(v);
    }

}
