package com.nec.biomatcher.client.util;

import static com.nec.biomatcher.client.common.XmClientConstants.NAMESPACE_URL;
import static com.nec.biomatcher.client.common.XmClientConstants.WSDL_URL;

import java.net.URL;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;

import com.nec.biomatcher.client.exception.XmClientException;
import com.nec.biomatcher.client.manager.XmClientManager;
import com.nec.biomatcher.webservices.BioMatcherWebServiceInterface;

public class WsdlUtil {	
	private static final BioMatcherWebServiceInterface xmWebService = buildXmWebService();
	
	private static BioMatcherWebServiceInterface buildXmWebService() {		
		BioMatcherWebServiceInterface xmWebService = null;
		XmClientManager manager = XmClientManager.getInstance();
		if (manager.getMapSize() < 1 ) {
			manager.getAllProperties();
		}
		try {
			String wsdlUrl = manager.getValue(WSDL_URL);
			URL url = new URL(wsdlUrl);
			QName qname = new QName(NAMESPACE_URL, "bioMatcherWebService");
			Service service = Service.create(url, qname);
			xmWebService = service.getPort(BioMatcherWebServiceInterface.class);		
		} catch (Exception e) {			
			throw new XmClientException(e.getMessage(), e);
		}
		return xmWebService;
	}	
	public static BioMatcherWebServiceInterface getXmWebService() {
		return xmWebService;
	}
}
