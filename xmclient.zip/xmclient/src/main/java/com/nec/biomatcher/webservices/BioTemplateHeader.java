
package com.nec.biomatcher.webservices;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for bioTemplateHeader complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="bioTemplateHeader">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="externalId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="gender" type="{http://webservices.biomatcher.nec.com/}genderEnum" minOccurs="0"/>
 *         &lt;element name="yob" type="{http://www.w3.org/2001/XMLSchema}short"/>
 *         &lt;element name="race" type="{http://www.w3.org/2001/XMLSchema}byte"/>
 *         &lt;element name="userFlags" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/>
 *         &lt;element name="regionFlags" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "bioTemplateHeader", propOrder = {
    "externalId",
    "gender",
    "yob",
    "race",
    "userFlags",
    "regionFlags"
})
public class BioTemplateHeader {

    protected String externalId;
    protected GenderEnum gender;
    protected short yob;
    protected byte race;
    protected byte[] userFlags;
    protected byte[] regionFlags;

    /**
     * Gets the value of the externalId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExternalId() {
        return externalId;
    }

    /**
     * Sets the value of the externalId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExternalId(String value) {
        this.externalId = value;
    }

    /**
     * Gets the value of the gender property.
     * 
     * @return
     *     possible object is
     *     {@link GenderEnum }
     *     
     */
    public GenderEnum getGender() {
        return gender;
    }

    /**
     * Sets the value of the gender property.
     * 
     * @param value
     *     allowed object is
     *     {@link GenderEnum }
     *     
     */
    public void setGender(GenderEnum value) {
        this.gender = value;
    }

    /**
     * Gets the value of the yob property.
     * 
     */
    public short getYob() {
        return yob;
    }

    /**
     * Sets the value of the yob property.
     * 
     */
    public void setYob(short value) {
        this.yob = value;
    }

    /**
     * Gets the value of the race property.
     * 
     */
    public byte getRace() {
        return race;
    }

    /**
     * Sets the value of the race property.
     * 
     */
    public void setRace(byte value) {
        this.race = value;
    }

    /**
     * Gets the value of the userFlags property.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getUserFlags() {
        return userFlags;
    }

    /**
     * Sets the value of the userFlags property.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setUserFlags(byte[] value) {
        this.userFlags = ((byte[]) value);
    }

    /**
     * Gets the value of the regionFlags property.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getRegionFlags() {
        return regionFlags;
    }

    /**
     * Sets the value of the regionFlags property.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setRegionFlags(byte[] value) {
        this.regionFlags = ((byte[]) value);
    }

}
