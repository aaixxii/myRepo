package com.nec.biomatcher.client.manager;

import java.io.File;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.biomatcher.client.logger.PerformanceLogger;
import com.nec.biomatcher.client.request.InquiryRequester;
import com.nec.biomatcher.webservices.SearchJobResultDto;

public class OneCircleSearchRunner implements Runnable {
	private int jobCount;
	private String reqeustFileFullName;
	private File[] files;
	private static Logger logger = LoggerFactory.getLogger(OneCircleSearchRunner.class);
	
	public OneCircleSearchRunner(int jobCount, String reqFileFullPath) {
		this.jobCount = jobCount;
		this.reqeustFileFullName = reqFileFullPath;
	}
	
	public OneCircleSearchRunner(File[] fileList) {	
		this.files = fileList;
		this.reqeustFileFullName = null;
	}
	
	public void runCircleJobByFileList() {	
		int count = files.length;
		long oneCircleStart = System.currentTimeMillis();		
		for (File one : files) {
			if (!one.exists() || !one.isFile())
				return;
			InquiryRequester inquriy = new InquiryRequester(one.getAbsolutePath());
			SearchJobResultDto result = inquriy.submitInquiryRequest();
			if (result != null && result.getJobId() != null) {
				logger.info("success get one job results.");						
			} else if (result == null) {
				logger.info("One job is faild!");
			}
			inquriy = null;
			result = null;
		}
		logger.info("Success finished run one circle search jobs. jobCount={}", count);		
		PerformanceLogger.trace(OneCircleSyncInsertRunner.class.getSimpleName(), "runOneCircleJobs", null, String.valueOf(count),null, System.currentTimeMillis() - oneCircleStart);
	}	
	
	public void runOneCircleJobs() {
		long oneCircleStart = System.currentTimeMillis();
		int originalJobCount = this.jobCount;
		while(jobCount > 0) {
			InquiryRequester inquriy = new InquiryRequester(reqeustFileFullName);
			SearchJobResultDto result = inquriy.submitInquiryRequest();
			if (result != null) {
				logger.info("success get one job results.");							
			} else {
				logger.info("One job is faild!");
			}
			jobCount--;	
			inquriy = null;
			result = null;
		}
		logger.info("Success finished run one circle jobs.jobCount={}", originalJobCount);		
		PerformanceLogger.trace(OneCircleSearchRunner.class.getSimpleName(), "runOneCircleJobs", null,String.valueOf(originalJobCount),null, System.currentTimeMillis() - oneCircleStart);
	}

	@Override
	public void run() {
		if (this.files != null) {
			runCircleJobByFileList();
		} else if (this.reqeustFileFullName != null && this.jobCount > 0) {
			runOneCircleJobs();
		}
	}
}
