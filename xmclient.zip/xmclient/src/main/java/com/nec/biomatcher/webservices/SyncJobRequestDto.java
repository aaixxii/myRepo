
package com.nec.biomatcher.webservices;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for syncJobRequestDto complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="syncJobRequestDto">
 *   &lt;complexContent>
 *     &lt;extension base="{http://webservices.biomatcher.nec.com/}bioMatcherJobRequest">
 *       &lt;sequence>
 *         &lt;element name="eventSyncDtoList" type="{http://webservices.biomatcher.nec.com/}biometricEventSyncTypeDto" maxOccurs="unbounded"/>
 *         &lt;element name="callbackUrl" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="jobTimeoutMill" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="jobMode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "syncJobRequestDto", propOrder = {
    "eventSyncDtoList",
    "callbackUrl",
    "jobTimeoutMill",
    "jobMode"
})
public class SyncJobRequestDto
    extends BioMatcherJobRequest
{

    @XmlElement(required = true)
    protected List<BiometricEventSyncTypeDto> eventSyncDtoList;
    protected String callbackUrl;
    protected Long jobTimeoutMill;
    protected String jobMode;

    /**
     * Gets the value of the eventSyncDtoList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the eventSyncDtoList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getEventSyncDtoList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link BiometricEventSyncTypeDto }
     * 
     * 
     */
    public List<BiometricEventSyncTypeDto> getEventSyncDtoList() {
        if (eventSyncDtoList == null) {
            eventSyncDtoList = new ArrayList<BiometricEventSyncTypeDto>();
        }
        return this.eventSyncDtoList;
    }

    /**
     * Gets the value of the callbackUrl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCallbackUrl() {
        return callbackUrl;
    }

    /**
     * Sets the value of the callbackUrl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCallbackUrl(String value) {
        this.callbackUrl = value;
    }

    /**
     * Gets the value of the jobTimeoutMill property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getJobTimeoutMill() {
        return jobTimeoutMill;
    }

    /**
     * Sets the value of the jobTimeoutMill property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setJobTimeoutMill(Long value) {
        this.jobTimeoutMill = value;
    }

    /**
     * Gets the value of the jobMode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJobMode() {
        return jobMode;
    }

    /**
     * Sets the value of the jobMode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJobMode(String value) {
        this.jobMode = value;
    }

}
