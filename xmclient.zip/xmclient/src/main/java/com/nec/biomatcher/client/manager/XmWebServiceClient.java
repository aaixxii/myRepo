package com.nec.biomatcher.client.manager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class XmWebServiceClient {
	private static Logger logger = LoggerFactory.getLogger(XmWebServiceClient.class);
	private static final String START = "start";
	private static final String STOP = "stop";

	public XmWebServiceClient() {
	}

	public static void main(String[] args) {		
		XmWebServiceClient client = new XmWebServiceClient();
		client.handleParameter(args);
	}

	private void pringUsage() {
		String lineSeparater = System.getProperties().getProperty("line.separator");
		StringBuilder sb = new StringBuilder();
		sb.append("Usage for start xm client:");
		sb.append(lineSeparater);
		sb.append("XmWebServiceClient start");
		logger.info(sb.toString());		
		sb.delete(0, sb.length());

		sb.append("Usage for stop xm client:");
		sb.append(lineSeparater);
		sb.append("XmWebServiceClient stop");
		logger.info(sb.toString());		

	}

	private void handleParameter(String[] args) {
		if (args.length < 1) {
			pringUsage();
			System.exit(0);
		}
		if (START.equals(args[0].toLowerCase())) {
			start();
		} else if (STOP.equals(args[0].toLowerCase())) {
			stop();
		} else {
			pringUsage();
			System.exit(0);
		}
	}

	public void start() {
		System.setProperty("file.encoding", "UTF-8");
		XmClientManager clietnManager = XmClientManager.getInstance();			
		if (clietnManager.getMapSize() == 0) {
			if (!clietnManager.getAllProperties()) {	
				String errMsg = "There are some wrong in xm.client.properties. or isn't exist!. stop process!";				
				logger.error(errMsg);			
				System.exit(0);	
			} 
			CallbackServer callbackServer = new CallbackServer();
			clietnManager.commitCallbackJob(callbackServer);			
			XmClientRunner.getInstance().run();
			logger.info("XM client is started!");	
			
		}
	}	

	public void stop() {
		XmClientManager.getInstance().shutdown();
		XmClientRunner.getInstance().setMustRun(false);			
		logger.info("XM client is stoped!");
		System.exit(0);
	}
}
