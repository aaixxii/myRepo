
package com.nec.biomatcher.webservices;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for searchItemInputPayloadDto complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="searchItemInputPayloadDto">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="functionId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="templateType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="templateData" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/>
 *         &lt;element name="templatePayload" type="{http://webservices.biomatcher.nec.com/}bioTemplatePayload" minOccurs="0"/>
 *         &lt;element name="maxHitCount" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="minScoreThreshold" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="searchOptions" type="{http://webservices.biomatcher.nec.com/}searchOptionsDto" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "searchItemInputPayloadDto", propOrder = {
    "functionId",
    "templateType",
    "templateData",
    "templatePayload",
    "maxHitCount",
    "minScoreThreshold",
    "searchOptions"
})
public class SearchItemInputPayloadDto {

    protected String functionId;
    protected String templateType;
    protected byte[] templateData;
    protected BioTemplatePayload templatePayload;
    protected Integer maxHitCount;
    protected Integer minScoreThreshold;
    protected SearchOptionsDto searchOptions;

    /**
     * Gets the value of the functionId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFunctionId() {
        return functionId;
    }

    /**
     * Sets the value of the functionId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFunctionId(String value) {
        this.functionId = value;
    }

    /**
     * Gets the value of the templateType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTemplateType() {
        return templateType;
    }

    /**
     * Sets the value of the templateType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTemplateType(String value) {
        this.templateType = value;
    }

    /**
     * Gets the value of the templateData property.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getTemplateData() {
        return templateData;
    }

    /**
     * Sets the value of the templateData property.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setTemplateData(byte[] value) {
        this.templateData = ((byte[]) value);
    }

    /**
     * Gets the value of the templatePayload property.
     * 
     * @return
     *     possible object is
     *     {@link BioTemplatePayload }
     *     
     */
    public BioTemplatePayload getTemplatePayload() {
        return templatePayload;
    }

    /**
     * Sets the value of the templatePayload property.
     * 
     * @param value
     *     allowed object is
     *     {@link BioTemplatePayload }
     *     
     */
    public void setTemplatePayload(BioTemplatePayload value) {
        this.templatePayload = value;
    }

    /**
     * Gets the value of the maxHitCount property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getMaxHitCount() {
        return maxHitCount;
    }

    /**
     * Sets the value of the maxHitCount property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setMaxHitCount(Integer value) {
        this.maxHitCount = value;
    }

    /**
     * Gets the value of the minScoreThreshold property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getMinScoreThreshold() {
        return minScoreThreshold;
    }

    /**
     * Sets the value of the minScoreThreshold property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setMinScoreThreshold(Integer value) {
        this.minScoreThreshold = value;
    }

    /**
     * Gets the value of the searchOptions property.
     * 
     * @return
     *     possible object is
     *     {@link SearchOptionsDto }
     *     
     */
    public SearchOptionsDto getSearchOptions() {
        return searchOptions;
    }

    /**
     * Sets the value of the searchOptions property.
     * 
     * @param value
     *     allowed object is
     *     {@link SearchOptionsDto }
     *     
     */
    public void setSearchOptions(SearchOptionsDto value) {
        this.searchOptions = value;
    }

}
