
package com.nec.biomatcher.webservices;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for searchHitCandidate complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="searchHitCandidate">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="externalId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="binId" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="score" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="requestItemKey" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="searchNodeId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="fusedScoreList" type="{http://webservices.biomatcher.nec.com/}searchFusedScoreDto" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="hitEventList" type="{http://webservices.biomatcher.nec.com/}searchHitEvent" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "searchHitCandidate", propOrder = {
    "externalId",
    "binId",
    "score",
    "requestItemKey",
    "searchNodeId",
    "fusedScoreList",
    "hitEventList"
})
public class SearchHitCandidate {

    protected String externalId;
    protected Integer binId;
    protected Integer score;
    protected String requestItemKey;
    protected String searchNodeId;
    @XmlElement(nillable = true)
    protected List<SearchFusedScoreDto> fusedScoreList;
    @XmlElement(nillable = true)
    protected List<SearchHitEvent> hitEventList;

    /**
     * Gets the value of the externalId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExternalId() {
        return externalId;
    }

    /**
     * Sets the value of the externalId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExternalId(String value) {
        this.externalId = value;
    }

    /**
     * Gets the value of the binId property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getBinId() {
        return binId;
    }

    /**
     * Sets the value of the binId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setBinId(Integer value) {
        this.binId = value;
    }

    /**
     * Gets the value of the score property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getScore() {
        return score;
    }

    /**
     * Sets the value of the score property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setScore(Integer value) {
        this.score = value;
    }

    /**
     * Gets the value of the requestItemKey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestItemKey() {
        return requestItemKey;
    }

    /**
     * Sets the value of the requestItemKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestItemKey(String value) {
        this.requestItemKey = value;
    }

    /**
     * Gets the value of the searchNodeId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSearchNodeId() {
        return searchNodeId;
    }

    /**
     * Sets the value of the searchNodeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSearchNodeId(String value) {
        this.searchNodeId = value;
    }

    /**
     * Gets the value of the fusedScoreList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the fusedScoreList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFusedScoreList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SearchFusedScoreDto }
     * 
     * 
     */
    public List<SearchFusedScoreDto> getFusedScoreList() {
        if (fusedScoreList == null) {
            fusedScoreList = new ArrayList<SearchFusedScoreDto>();
        }
        return this.fusedScoreList;
    }

    /**
     * Gets the value of the hitEventList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the hitEventList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getHitEventList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SearchHitEvent }
     * 
     * 
     */
    public List<SearchHitEvent> getHitEventList() {
        if (hitEventList == null) {
            hitEventList = new ArrayList<SearchHitEvent>();
        }
        return this.hitEventList;
    }

}
