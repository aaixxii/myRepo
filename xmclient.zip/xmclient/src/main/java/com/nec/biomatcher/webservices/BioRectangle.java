
package com.nec.biomatcher.webservices;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for bioRectangle complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="bioRectangle">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="lowerLeft" type="{http://webservices.biomatcher.nec.com/}pointDto" minOccurs="0"/>
 *         &lt;element name="lowerRight" type="{http://webservices.biomatcher.nec.com/}pointDto" minOccurs="0"/>
 *         &lt;element name="upperLeft" type="{http://webservices.biomatcher.nec.com/}pointDto" minOccurs="0"/>
 *         &lt;element name="upperRight" type="{http://webservices.biomatcher.nec.com/}pointDto" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "bioRectangle", propOrder = {
    "lowerLeft",
    "lowerRight",
    "upperLeft",
    "upperRight"
})
public class BioRectangle {

    protected PointDto lowerLeft;
    protected PointDto lowerRight;
    protected PointDto upperLeft;
    protected PointDto upperRight;

    /**
     * Gets the value of the lowerLeft property.
     * 
     * @return
     *     possible object is
     *     {@link PointDto }
     *     
     */
    public PointDto getLowerLeft() {
        return lowerLeft;
    }

    /**
     * Sets the value of the lowerLeft property.
     * 
     * @param value
     *     allowed object is
     *     {@link PointDto }
     *     
     */
    public void setLowerLeft(PointDto value) {
        this.lowerLeft = value;
    }

    /**
     * Gets the value of the lowerRight property.
     * 
     * @return
     *     possible object is
     *     {@link PointDto }
     *     
     */
    public PointDto getLowerRight() {
        return lowerRight;
    }

    /**
     * Sets the value of the lowerRight property.
     * 
     * @param value
     *     allowed object is
     *     {@link PointDto }
     *     
     */
    public void setLowerRight(PointDto value) {
        this.lowerRight = value;
    }

    /**
     * Gets the value of the upperLeft property.
     * 
     * @return
     *     possible object is
     *     {@link PointDto }
     *     
     */
    public PointDto getUpperLeft() {
        return upperLeft;
    }

    /**
     * Sets the value of the upperLeft property.
     * 
     * @param value
     *     allowed object is
     *     {@link PointDto }
     *     
     */
    public void setUpperLeft(PointDto value) {
        this.upperLeft = value;
    }

    /**
     * Gets the value of the upperRight property.
     * 
     * @return
     *     possible object is
     *     {@link PointDto }
     *     
     */
    public PointDto getUpperRight() {
        return upperRight;
    }

    /**
     * Sets the value of the upperRight property.
     * 
     * @param value
     *     allowed object is
     *     {@link PointDto }
     *     
     */
    public void setUpperRight(PointDto value) {
        this.upperRight = value;
    }

}
