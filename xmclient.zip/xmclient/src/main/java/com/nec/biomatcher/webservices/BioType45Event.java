
package com.nec.biomatcher.webservices;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for bioType45Event complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="bioType45Event">
 *   &lt;complexContent>
 *     &lt;extension base="{http://webservices.biomatcher.nec.com/}bioTemplateEvent">
 *       &lt;sequence>
 *         &lt;element name="fullRight" type="{http://webservices.biomatcher.nec.com/}bioPalmFeatureInfo" minOccurs="0"/>
 *         &lt;element name="fullLeft" type="{http://webservices.biomatcher.nec.com/}bioPalmFeatureInfo" minOccurs="0"/>
 *         &lt;element name="writerRight" type="{http://webservices.biomatcher.nec.com/}bioPalmFeatureInfo" minOccurs="0"/>
 *         &lt;element name="writerLeft" type="{http://webservices.biomatcher.nec.com/}bioPalmFeatureInfo" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "bioType45Event", propOrder = {
    "fullRight",
    "fullLeft",
    "writerRight",
    "writerLeft"
})
public class BioType45Event
    extends BioTemplateEvent
{

    protected BioPalmFeatureInfo fullRight;
    protected BioPalmFeatureInfo fullLeft;
    protected BioPalmFeatureInfo writerRight;
    protected BioPalmFeatureInfo writerLeft;

    /**
     * Gets the value of the fullRight property.
     * 
     * @return
     *     possible object is
     *     {@link BioPalmFeatureInfo }
     *     
     */
    public BioPalmFeatureInfo getFullRight() {
        return fullRight;
    }

    /**
     * Sets the value of the fullRight property.
     * 
     * @param value
     *     allowed object is
     *     {@link BioPalmFeatureInfo }
     *     
     */
    public void setFullRight(BioPalmFeatureInfo value) {
        this.fullRight = value;
    }

    /**
     * Gets the value of the fullLeft property.
     * 
     * @return
     *     possible object is
     *     {@link BioPalmFeatureInfo }
     *     
     */
    public BioPalmFeatureInfo getFullLeft() {
        return fullLeft;
    }

    /**
     * Sets the value of the fullLeft property.
     * 
     * @param value
     *     allowed object is
     *     {@link BioPalmFeatureInfo }
     *     
     */
    public void setFullLeft(BioPalmFeatureInfo value) {
        this.fullLeft = value;
    }

    /**
     * Gets the value of the writerRight property.
     * 
     * @return
     *     possible object is
     *     {@link BioPalmFeatureInfo }
     *     
     */
    public BioPalmFeatureInfo getWriterRight() {
        return writerRight;
    }

    /**
     * Sets the value of the writerRight property.
     * 
     * @param value
     *     allowed object is
     *     {@link BioPalmFeatureInfo }
     *     
     */
    public void setWriterRight(BioPalmFeatureInfo value) {
        this.writerRight = value;
    }

    /**
     * Gets the value of the writerLeft property.
     * 
     * @return
     *     possible object is
     *     {@link BioPalmFeatureInfo }
     *     
     */
    public BioPalmFeatureInfo getWriterLeft() {
        return writerLeft;
    }

    /**
     * Sets the value of the writerLeft property.
     * 
     * @param value
     *     allowed object is
     *     {@link BioPalmFeatureInfo }
     *     
     */
    public void setWriterLeft(BioPalmFeatureInfo value) {
        this.writerLeft = value;
    }

}
