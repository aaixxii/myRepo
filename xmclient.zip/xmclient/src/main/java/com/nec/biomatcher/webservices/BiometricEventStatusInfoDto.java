
package com.nec.biomatcher.webservices;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for biometricEventStatusInfoDto complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="biometricEventStatusInfoDto">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="binId" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="biometricId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="errorDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="errorLogId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="eventId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="externalId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="phase" type="{http://webservices.biomatcher.nec.com/}biometricEventPhase" minOccurs="0"/>
 *         &lt;element name="status" type="{http://webservices.biomatcher.nec.com/}biometricEventStatus" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "biometricEventStatusInfoDto", propOrder = {
    "binId",
    "biometricId",
    "errorDateTime",
    "errorLogId",
    "eventId",
    "externalId",
    "phase",
    "status"
})
public class BiometricEventStatusInfoDto {

    protected Integer binId;
    protected Long biometricId;
    protected XMLGregorianCalendar errorDateTime;
    protected String errorLogId;
    protected String eventId;
    protected String externalId;
    protected BiometricEventPhase phase;
    protected BiometricEventStatus status;

    /**
     * Gets the value of the binId property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getBinId() {
        return binId;
    }

    /**
     * Sets the value of the binId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setBinId(Integer value) {
        this.binId = value;
    }

    /**
     * Gets the value of the biometricId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getBiometricId() {
        return biometricId;
    }

    /**
     * Sets the value of the biometricId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setBiometricId(Long value) {
        this.biometricId = value;
    }

    /**
     * Gets the value of the errorDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getErrorDateTime() {
        return errorDateTime;
    }

    /**
     * Sets the value of the errorDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setErrorDateTime(XMLGregorianCalendar value) {
        this.errorDateTime = value;
    }

    /**
     * Gets the value of the errorLogId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getErrorLogId() {
        return errorLogId;
    }

    /**
     * Sets the value of the errorLogId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setErrorLogId(String value) {
        this.errorLogId = value;
    }

    /**
     * Gets the value of the eventId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEventId() {
        return eventId;
    }

    /**
     * Sets the value of the eventId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEventId(String value) {
        this.eventId = value;
    }

    /**
     * Gets the value of the externalId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExternalId() {
        return externalId;
    }

    /**
     * Sets the value of the externalId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExternalId(String value) {
        this.externalId = value;
    }

    /**
     * Gets the value of the phase property.
     * 
     * @return
     *     possible object is
     *     {@link BiometricEventPhase }
     *     
     */
    public BiometricEventPhase getPhase() {
        return phase;
    }

    /**
     * Sets the value of the phase property.
     * 
     * @param value
     *     allowed object is
     *     {@link BiometricEventPhase }
     *     
     */
    public void setPhase(BiometricEventPhase value) {
        this.phase = value;
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link BiometricEventStatus }
     *     
     */
    public BiometricEventStatus getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link BiometricEventStatus }
     *     
     */
    public void setStatus(BiometricEventStatus value) {
        this.status = value;
    }

}
