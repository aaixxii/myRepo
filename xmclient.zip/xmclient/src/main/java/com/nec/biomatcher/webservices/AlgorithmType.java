
package com.nec.biomatcher.webservices;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for algorithmType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="algorithmType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="FACE_NEC_S17"/>
 *     &lt;enumeration value="FACE_NEC_S18"/>
 *     &lt;enumeration value="FACE_NEC_NFV2"/>
 *     &lt;enumeration value="FACE_NEC_NFG2"/>
 *     &lt;enumeration value="IRIS_NEC"/>
 *     &lt;enumeration value="IRIS_DELTA_ID"/>
 *     &lt;enumeration value="FINGER_CMLAF"/>
 *     &lt;enumeration value="FINGER_PC2"/>
 *     &lt;enumeration value="FINGER_FMP5"/>
 *     &lt;enumeration value="FINGER_PC3R"/>
 *     &lt;enumeration value="FINGER_LFML"/>
 *     &lt;enumeration value="FINGER_ELFT"/>
 *     &lt;enumeration value="FINGER_CML"/>
 *     &lt;enumeration value="FINGER_BT5"/>
 *     &lt;enumeration value="PALM_PC3R"/>
 *     &lt;enumeration value="PALM_LFML"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "algorithmType")
@XmlEnum
public enum AlgorithmType {

    @XmlEnumValue("FACE_NEC_S17")
    FACE_NEC_S_17("FACE_NEC_S17"),
    @XmlEnumValue("FACE_NEC_S18")
    FACE_NEC_S_18("FACE_NEC_S18"),
    @XmlEnumValue("FACE_NEC_NFV2")
    FACE_NEC_NFV_2("FACE_NEC_NFV2"),
    @XmlEnumValue("FACE_NEC_NFG2")
    FACE_NEC_NFG_2("FACE_NEC_NFG2"),
    IRIS_NEC("IRIS_NEC"),
    IRIS_DELTA_ID("IRIS_DELTA_ID"),
    FINGER_CMLAF("FINGER_CMLAF"),
    @XmlEnumValue("FINGER_PC2")
    FINGER_PC_2("FINGER_PC2"),
    @XmlEnumValue("FINGER_FMP5")
    FINGER_FMP_5("FINGER_FMP5"),
    @XmlEnumValue("FINGER_PC3R")
    FINGER_PC_3_R("FINGER_PC3R"),
    FINGER_LFML("FINGER_LFML"),
    FINGER_ELFT("FINGER_ELFT"),
    FINGER_CML("FINGER_CML"),
    @XmlEnumValue("FINGER_BT5")
    FINGER_BT_5("FINGER_BT5"),
    @XmlEnumValue("PALM_PC3R")
    PALM_PC_3_R("PALM_PC3R"),
    PALM_LFML("PALM_LFML");
    private final String value;

    AlgorithmType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static AlgorithmType fromValue(String v) {
        for (AlgorithmType c: AlgorithmType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
