package com.nec.biomatcher.client.common;

public enum FunctionEnum {
	TI(0), //
	LI(1), //
	FI(2), //
	II(3), //
	EXTRACT(4), //
	VERIFY(5);

	private int val;

	private FunctionEnum(int val) {
		this.val = val;
	}

	public int getVal() {
		return val;
	}
}
