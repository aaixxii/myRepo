
package com.nec.biomatcher.webservices;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for minutiaData complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="minutiaData">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="minutia" type="{http://webservices.biomatcher.nec.com/}minutia"/>
 *       &lt;/sequence>
 *       &lt;attribute name="index" use="required" type="{http://www.w3.org/2001/XMLSchema}int" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "minutiaData", propOrder = {
    "minutia"
})
public class MinutiaData {

    @XmlElement(required = true)
    protected Minutia minutia;
    @XmlAttribute(required = true)
    protected int index;

    /**
     * Gets the value of the minutia property.
     * 
     * @return
     *     possible object is
     *     {@link Minutia }
     *     
     */
    public Minutia getMinutia() {
        return minutia;
    }

    /**
     * Sets the value of the minutia property.
     * 
     * @param value
     *     allowed object is
     *     {@link Minutia }
     *     
     */
    public void setMinutia(Minutia value) {
        this.minutia = value;
    }

    /**
     * Gets the value of the index property.
     * 
     */
    public int getIndex() {
        return index;
    }

    /**
     * Sets the value of the index property.
     * 
     */
    public void setIndex(int value) {
        this.index = value;
    }

}
