
package com.nec.biomatcher.webservices;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for fisData complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="fisData">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="skeleton" type="{http://webservices.biomatcher.nec.com/}skeleton"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "fisData", propOrder = {
    "skeleton"
})
public class FisData {

    @XmlElement(required = true)
    protected Skeleton skeleton;

    /**
     * Gets the value of the skeleton property.
     * 
     * @return
     *     possible object is
     *     {@link Skeleton }
     *     
     */
    public Skeleton getSkeleton() {
        return skeleton;
    }

    /**
     * Sets the value of the skeleton property.
     * 
     * @param value
     *     allowed object is
     *     {@link Skeleton }
     *     
     */
    public void setSkeleton(Skeleton value) {
        this.skeleton = value;
    }

}
