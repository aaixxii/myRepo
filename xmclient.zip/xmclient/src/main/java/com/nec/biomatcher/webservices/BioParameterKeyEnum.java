
package com.nec.biomatcher.webservices;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for bioParameterKeyEnum.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="bioParameterKeyEnum">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="EyeRoll"/>
 *     &lt;enumeration value="MaxEyeDistance"/>
 *     &lt;enumeration value="MinEyeDistance"/>
 *     &lt;enumeration value="Reliability"/>
 *     &lt;enumeration value="Algorithm"/>
 *     &lt;enumeration value="ShrinkFactor"/>
 *     &lt;enumeration value="Rotation"/>
 *     &lt;enumeration value="Speed"/>
 *     &lt;enumeration value="MATCH_THRESHOLD"/>
 *     &lt;enumeration value="USER_FLAG"/>
 *     &lt;enumeration value="REGION_FLAG"/>
 *     &lt;enumeration value="YOB"/>
 *     &lt;enumeration value="YOB_RANGE"/>
 *     &lt;enumeration value="GENDER"/>
 *     &lt;enumeration value="RACE"/>
 *     &lt;enumeration value="TARGET_QUALITY_THRESHOLD"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "bioParameterKeyEnum")
@XmlEnum
public enum BioParameterKeyEnum {

    @XmlEnumValue("EyeRoll")
    EYE_ROLL("EyeRoll"),
    @XmlEnumValue("MaxEyeDistance")
    MAX_EYE_DISTANCE("MaxEyeDistance"),
    @XmlEnumValue("MinEyeDistance")
    MIN_EYE_DISTANCE("MinEyeDistance"),
    @XmlEnumValue("Reliability")
    RELIABILITY("Reliability"),
    @XmlEnumValue("Algorithm")
    ALGORITHM("Algorithm"),
    @XmlEnumValue("ShrinkFactor")
    SHRINK_FACTOR("ShrinkFactor"),
    @XmlEnumValue("Rotation")
    ROTATION("Rotation"),
    @XmlEnumValue("Speed")
    SPEED("Speed"),
    MATCH_THRESHOLD("MATCH_THRESHOLD"),
    USER_FLAG("USER_FLAG"),
    REGION_FLAG("REGION_FLAG"),
    YOB("YOB"),
    YOB_RANGE("YOB_RANGE"),
    GENDER("GENDER"),
    RACE("RACE"),
    TARGET_QUALITY_THRESHOLD("TARGET_QUALITY_THRESHOLD");
    private final String value;

    BioParameterKeyEnum(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static BioParameterKeyEnum fromValue(String v) {
        for (BioParameterKeyEnum c: BioParameterKeyEnum.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
