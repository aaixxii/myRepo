package com.nec.biomatcher.client.priority;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import javax.xml.bind.JAXBElement;

import com.nec.biomatcher.client.util.FileUtil;
import com.nec.biomatcher.webservices.AlgorithmType;
import com.nec.biomatcher.webservices.BioTemplateHeader;
import com.nec.biomatcher.webservices.BioTemplatePayload;
import com.nec.biomatcher.webservices.BioType1Event;
import com.nec.biomatcher.webservices.ExtractInputParameter;
import com.nec.biomatcher.webservices.ExtractInputPayloadDto;
import com.nec.biomatcher.webservices.FaceExtractInputImage;
import com.nec.biomatcher.webservices.GenderEnum;
import com.nec.biomatcher.webservices.Image;
import com.nec.biomatcher.webservices.ImageFormat;
import com.nec.biomatcher.webservices.ImagePosition;
import com.nec.biomatcher.webservices.MetaInfoCommon;
import com.nec.biomatcher.webservices.Modality;
import com.nec.biomatcher.webservices.ObjectFactory;
import com.nec.biomatcher.webservices.SearchItemInputPayloadDto;
import com.nec.biomatcher.webservices.SearchJobRequestDto;
import com.nec.biomatcher.webservices.SearchOptionsDto;
import com.nec.biomatcher.webservices.SearchRequestItemDto;
import com.nec.biomatcher.webservices.TemplateExtractInputImage;

public class FIImagePriorityJobReqeustCreater {
	
	private static final  String FunctionId = "FI";
	private static final  Integer binIds[]  = {1};	
	
	private String dataFile = "face0.jpg";	
	
	String templateType = "TEMPLATE_TYPE_1";
	long jobTimeoutMilli = TimeUnit.SECONDS.toMillis(120);

	int MAX_HIT_CANDIDATES = 20;
	int MIN_HIT_SCORE_THRESHOLD = 1;	
	
	public static GenderEnum searchGender = GenderEnum.M;
	public static Integer searchYob = 1977;
	public static Integer searchYobRange = 10;
	public static char searchRace = 'B';
	public static String searchRegionFlags = "32";
	public static String searchUserFlags = "face17TR";
	
	Random rnd = new Random();

	
	private Integer priority;
	private Integer jobCount;	
	
	
	public FIImagePriorityJobReqeustCreater(Integer priority, Integer jobCount, String templatePath) {		
		this.priority = priority;
		this.jobCount = jobCount;
		this.dataFile = templatePath + "/" + dataFile;
	}
	
	public List<SearchJobRequestDto> createSeachJobRequest() {
		List<SearchJobRequestDto> jobRequests = new ArrayList<>();
		for (int i = 0; i < jobCount; i++) {
			SearchJobRequestDto searchRq =  buildSeachJobRequest();
			jobRequests.add(searchRq);
		}
		return jobRequests;		
	}
	
	public SearchJobRequestDto buildSeachJobRequest() {		
		SearchJobRequestDto searchJobRequestDto = new SearchJobRequestDto();	
		String callbackUrl = "http://" + "192.168.22.118" + ":" + "5679";
		searchJobRequestDto.setCallbackUrl(callbackUrl);		
		ObjectFactory objectFactory = new ObjectFactory();		
		JAXBElement<Integer> rqPriority = objectFactory.createSearchJobRequestDtoPriority(priority);		
		searchJobRequestDto.setPriority(rqPriority);
		searchJobRequestDto.setJobTimeoutMill(jobTimeoutMilli);
		searchJobRequestDto.setJobMode("live");
		JAXBElement<String> functionId = objectFactory.createSearchJobRequestDtoSearchFunctionId(FunctionId);
		searchJobRequestDto.setSearchFunctionId(functionId);
		SearchRequestItemDto searchRequestItemDto = new SearchRequestItemDto();
		searchRequestItemDto.setSearchItemPayloadDto(buildSearchItemInputPayload());
		searchRequestItemDto.getBinIdList().addAll(Arrays.asList(binIds));
		searchJobRequestDto.getSearchRequestItemList().add(searchRequestItemDto);
		ExtractInputPayloadDto exinput = buildExtractInputPayloadDto();
		searchJobRequestDto.setExtractInputPayloadDto(exinput);
		return searchJobRequestDto;
	}
	
	public SearchItemInputPayloadDto buildSearchItemInputPayload() {
		int exteralId = rnd.nextInt();
		int eventId = rnd.nextInt();
		SearchItemInputPayloadDto searchItemInputPayloadDto = new SearchItemInputPayloadDto();
		searchItemInputPayloadDto.setFunctionId(FunctionId);
		searchItemInputPayloadDto.setTemplateType(templateType);
		searchItemInputPayloadDto.setMaxHitCount(MAX_HIT_CANDIDATES);
		searchItemInputPayloadDto.setMinScoreThreshold(MIN_HIT_SCORE_THRESHOLD);		

		SearchOptionsDto searchOption = new SearchOptionsDto();		
		MetaInfoCommon metaInfoCommon = new MetaInfoCommon();
		metaInfoCommon.setGender(searchGender);
		metaInfoCommon.setRace(String.valueOf(searchRace));
		ObjectFactory objectFactory = new ObjectFactory();			
		JAXBElement<Long> jaxLong = objectFactory.createMetaInfoCommonRegionFlags(Long.valueOf(searchRegionFlags));
		metaInfoCommon.setRegionFlags(jaxLong);		
		JAXBElement<String> userFlags = objectFactory.createMetaInfoCommonUserFlags("false");
		metaInfoCommon.setUserFlags(userFlags);		
		JAXBElement<Integer> yob = objectFactory.createMetaInfoCommonYob(searchYob);
		metaInfoCommon.setYob(yob);
		JAXBElement<Integer> yobRange = objectFactory.createMetaInfoCommonYobRange(searchYobRange);
		metaInfoCommon.setYobRange(yobRange);		
		searchOption.setMetaInfoCommon(metaInfoCommon);					
		searchItemInputPayloadDto.setSearchOptions(searchOption);		
		
		BioTemplatePayload bioTemplatePayload = new BioTemplatePayload();
		BioTemplateHeader bioTemplateHeader = new BioTemplateHeader();
		bioTemplateHeader.setExternalId(String.valueOf(exteralId));
		bioTemplateHeader.setGender(searchGender);
		bioTemplateHeader.setRace((byte)searchRace);
		bioTemplateHeader.setRegionFlags( searchRegionFlags.getBytes());
		bioTemplateHeader.setUserFlags(searchUserFlags.getBytes());
		bioTemplateHeader.setYob(searchYob.shortValue());
		bioTemplatePayload.setTemplateHeader(bioTemplateHeader);
		
		BioType1Event bioEvent = new BioType1Event();
		bioEvent.setEventId(String.valueOf(eventId));
		bioEvent.setQuality(60);
		FileUtil fu = new FileUtil();
		 byte[] face17Data =
		 fu.getDataFromFile(dataFile);
		 bioEvent.setFaceS17FeatureData(face17Data);	
			
		bioTemplatePayload.getEvents().add(bioEvent);		
		searchItemInputPayloadDto.setTemplatePayload(bioTemplatePayload);	
		return searchItemInputPayloadDto;
	}
	
	private ExtractInputPayloadDto buildExtractInputPayloadDto() {		
		 ObjectFactory objectFactory = new ObjectFactory();
		ExtractInputPayloadDto epDto = new ExtractInputPayloadDto();
		JAXBElement<String> candidateId = objectFactory.createExtractInputPayloadDtoCandidateId("mysql_test");
		epDto.setCandidateId(candidateId);
		TemplateExtractInputImage templateImage = new TemplateExtractInputImage();	
		FaceExtractInputImage faceExtractInputImag = new FaceExtractInputImage();			
		Image faceImage = new Image();
		FileUtil fu = new FileUtil();
       byte[] imageRollData = fu.readImageFromFile("jpg", dataFile);      
       faceImage.setType(ImageFormat.JPEG);
       faceImage.setPosition(ImagePosition.FRONTAL_FACE);
       faceImage.setData(imageRollData);        
       faceExtractInputImag.setFaceImage(faceImage);
       
		ExtractInputParameter parameter = new ExtractInputParameter();
		parameter.setAlgorithmType(AlgorithmType.FACE_NEC_S_17);
		parameter.setModality(Modality.FACE);		
		faceExtractInputImag.getExtractionParameters().add(parameter);        
      
       MetaInfoCommon metaInfoCommon = new MetaInfoCommon();
       metaInfoCommon.setGender(searchGender);
       JAXBElement<Integer> yob = objectFactory.createMetaInfoCommonYob(searchYob);
       metaInfoCommon.setYob(yob);
       metaInfoCommon.setRace(String.valueOf( searchRace));            
       JAXBElement<MetaInfoCommon> mm = objectFactory.createExtractInputPayloadDtoMetaInfoCommon(metaInfoCommon);
       epDto.setMetaInfoCommon(mm); 

     templateImage.setExtractInputImage(faceExtractInputImag);
     templateImage.getTemplateTypes().add(templateType);
     epDto.getTemplateExtractInputImageList().add(templateImage);
     fu = null;
     return epDto;	
	}
}
