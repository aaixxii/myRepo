package com.nec.biomatcher.client.manager;


import java.util.Random;

import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;


public class XmClientManagerTest {	
	private static final Random sRandom = new Random(System.currentTimeMillis());

	@Test
	public void testGetValue() {
	}

	@Test
	@Ignore
	public void testGetAllProperties() {
		//URL url = Thread.currentThread().getContextClassLoader().getResource("xm.client.properties");
		Assert.assertTrue(XmClientManager.getInstance().getAllProperties());
	}
	
	@Test	
	public void testBuildMehgaUrl() {
		String scIps = "192.168.22.105,192.168.22.110";
		String scPorts = "8080,8081";
		String result = XmClientManager.getInstance().buildMehgaUrl(scIps, scPorts);
		int indx = result.indexOf(":");
		String ip = result.substring(0, indx);
		String port = result.substring(indx + 1, result.length());
		Assert.assertTrue(scIps.contains(ip));
		Assert.assertTrue(scPorts.contains(port));		
	}
	
	@Test
	public void testBuildMehgaUrl1() {
		String scIps = "192.168.22.105";
		String scPorts = "8080";
		String result = XmClientManager.getInstance().buildMehgaUrl(scIps, scPorts);
		int indx = result.indexOf(":");
		String ip = result.substring(0, indx);
		String port = result.substring(indx + 1, result.length());
		Assert.assertTrue(scIps.contains(ip));
		Assert.assertTrue(scPorts.contains(port));		
	}
	
	@Test
	public void testBuildMehgaUrl2() {
		String scIps = "192.168.22.105,192.168.22.110,192.168.22.111";
		String scPorts = "8080,8081,8082";
		String result = XmClientManager.getInstance().buildMehgaUrl(scIps, scPorts);
		int indx = result.indexOf(":");
		String ip = result.substring(0, indx);
		String port = result.substring(indx + 1, result.length());
		Assert.assertTrue(scIps.contains(ip));
		Assert.assertTrue(scPorts.contains(port));		
	}
	
	@Test
	public void testBuildMehgaUrl3() {
		String scIps = "192.168.22.105,192.168.22.110,192.168.22.111,192.168.22.112";
		String scPorts = "8080,8081,8082,8083";
		String result = XmClientManager.getInstance().buildMehgaUrl(scIps, scPorts);
		int indx = result.indexOf(":");
		String ip = result.substring(0, indx);
		String port = result.substring(indx + 1, result.length());
		Assert.assertTrue(scIps.contains(ip));
		Assert.assertTrue(scPorts.contains(port));		
	}
	
	@Test
	public void testJavaRandom() {
		int picked = sRandom.nextInt(5);
		Assert.assertTrue(picked >= 0);
		Assert.assertTrue(picked < 5);
		System.out.println(picked);
		
		int picked1 = sRandom.nextInt(5);
		Assert.assertTrue(picked1 >= 0);
		Assert.assertTrue(picked1 < 5);
		System.out.println(picked1);
		
		int picked2 = sRandom.nextInt(5);
		Assert.assertTrue(picked2 >= 0);
		Assert.assertTrue(picked2 < 5);
		System.out.println(picked2);
		
		int picked3 = sRandom.nextInt(5);
		Assert.assertTrue(picked3 >= 0);
		Assert.assertTrue(picked3 < 5);
		System.out.println(picked3);
	}
}
