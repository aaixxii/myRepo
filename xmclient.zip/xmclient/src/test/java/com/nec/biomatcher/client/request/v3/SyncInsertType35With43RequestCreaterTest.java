package com.nec.biomatcher.client.request.v3;


import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.junit.Test;

import com.nec.biomatcher.client.util.FileUtil;
import com.nec.biomatcher.client.util.JaxBUtil;
import com.nec.biomatcher.webservices.AlgorithmType;
import com.nec.biomatcher.webservices.BioFeType;
import com.nec.biomatcher.webservices.BioFingerFeatureInfo;
import com.nec.biomatcher.webservices.BioTemplateEvent;
import com.nec.biomatcher.webservices.BioTemplateHeader;
import com.nec.biomatcher.webservices.BioTemplatePayload;
import com.nec.biomatcher.webservices.BioType35Event;
import com.nec.biomatcher.webservices.BioType43Event;
import com.nec.biomatcher.webservices.BiometricEventSyncTypeDto;
import com.nec.biomatcher.webservices.GenderEnum;
import com.nec.biomatcher.webservices.InsertBiometricEventDto;
import com.nec.biomatcher.webservices.InsertTemplateInfo;
import com.nec.biomatcher.webservices.PatternType;
import com.nec.biomatcher.webservices.SyncJobRequestDto;
import com.nec.biomatcher.webservices.test.TestUtil.ParamKey;

public class SyncInsertType35With43RequestCreaterTest {
	Random rnd = new Random();	
	private static String templateType35 = "TEMPLATE_TYPE_35";
	
	private static String templateType43 = "TEMPLATE_TYPE_43";
	
	public static GenderEnum gender = GenderEnum.M;
	public static Integer yob = 1977;
	public static char race = 'B';
	public static String regionFlags = "32";
	public static String userFlag = "aaaaaaaa";
	
	private static final  String dataFilePath = "/C:/Users/000001A006PBP/Desktop/test/";

	long jobTimeoutMilli = TimeUnit.SECONDS.toMillis(120);	
	
	@Test
	public void testBuildSyncUpdateRequest() throws Exception {
		SyncJobRequestDto insertRequest = buildSyncInsertRequest();
		JaxBUtil<SyncJobRequestDto> jaxb = new JaxBUtil<SyncJobRequestDto>();
		 jaxb.marshalToFile(SyncJobRequestDto.class, insertRequest,
		 "/C:/Users/000001A006PBP/Desktop/test/sync_insert_request_35_43.xml");		
		System.out.println("OKOKOK");
	}

	public SyncJobRequestDto buildSyncInsertRequest() throws Exception {
		String callbackIp = "192.168.22.118";
		String callbackPort = "5679";
		String callbackUrl = "http://" + callbackIp + ":" + callbackPort;
		SyncJobRequestDto syncJobRequestDto = new SyncJobRequestDto();
		syncJobRequestDto.setCallbackUrl(callbackUrl);
		syncJobRequestDto.setJobMode("strict");
		syncJobRequestDto.setJobTimeoutMill(jobTimeoutMilli);
		
		List<BiometricEventSyncTypeDto> syncList = new ArrayList<>();
		InsertBiometricEventDto insertBiometricEventDto = new InsertBiometricEventDto();
		insertBiometricEventDto.getInsertTemplateInfoList().add(buildTemplateInsertTemplateInfo("exnternal35", "evnet35", templateType35));
		insertBiometricEventDto.getInsertTemplateInfoList().add(buildTemplateInsertTemplateInfo("exnternal43", "evnet43", templateType43));
		syncList.add(insertBiometricEventDto);
		syncJobRequestDto.getEventSyncDtoList().addAll(syncList);
		return syncJobRequestDto;
	}
	
	private InsertTemplateInfo buildTemplateInsertTemplateInfo(String extId, String eventId,  String templateType) {
		InsertTemplateInfo insertTemplateInfo = new InsertTemplateInfo();		
		insertTemplateInfo.setBinId(Integer.valueOf(templateType.substring(templateType.length() -2 , templateType.length())));
		FileUtil fu = new FileUtil();		
		BioTemplateEvent bioTemplateEvent = new BioTemplateEvent();		
		byte[] templateData = null;
		byte[] featureData = null;		
		if (templateType.equals(templateType35)) {			
			insertTemplateInfo.setBinId(35);
			insertTemplateInfo.setTemplateData(fu.getDataFromFile(dataFilePath + "capsule_type_35.bin"));			
		} else if (templateType.equals(templateType43)){
			insertTemplateInfo.setBinId(43);
			insertTemplateInfo.setTemplateData(fu.getDataFromFile(dataFilePath + "capsule_type_43.bin"));	
		}	
		insertTemplateInfo.setTemplateType(templateType);
		BioTemplatePayload  payload = new BioTemplatePayload();
		BioTemplateHeader header = new BioTemplateHeader();
		header.setExternalId(extId);
		header.setGender(gender);	
		header.setRace((byte)(race));
		header.setYob(yob.shortValue());	
		payload.setTemplateHeader(header);		
		payload.getEvents().addAll(events);
		insertTemplateInfo.setTemplatePayload(payload);
		insertTemplateInfo.setTemplateType(templateType);		
		return insertTemplateInfo;		
	}
	
	private static BioTemplateEvent buildType43Event(String eventId, String templateType) throws Exception {
		byte[] templateData = null;
		byte[] featureData = null;
		FileUtil fu = new FileUtil();		
		if (templateType.equals(templateType35)) {
			templateData = fu.getDataFromFile(dataFilePath + "capsule_type_35.bin");
			BioType35Event ev = new BioType35Event();			
			ev.setEventId(eventId);	
			ev.setIsRolledFlag(true);
			featureData = fu.getDataFromFile(dataFilePath + "feature_type_35.bin");
			ev.setCmlFeatureData(featureData);
		} else if (templateType.equals(templateType43)){
			templateData = fu.getDataFromFile(dataFilePath + "capsule_type_43.bin");
			BioType43Event ev = new BioType43Event();
			ev.setEventId(eventId);			
			featureData = fu.getDataFromFile(dataFilePath + "feature_type_43.bin");	
			BioFingerFeatureInfo bf = new BioFingerFeatureInfo();
			bf.setFeatureData(featureData);
			bf.setFingerPosition(1);
			bf.setPrimaryPatternType(PatternType.L);			
			ev.setFeType(BioFeType.ELFT);
			ev.setAlgorithmType(AlgorithmType.FINGER_LFML);
			ev.getFingerInfoList().add(bf);	
		}	
	}
	
	private  BioTemplateEvent buildType35Event(String eventId, String templateType)  {
		BioType35Event ev = null;
		FileUtil fu = new FileUtil();		
		if (templateType.equals(templateType35)) {			
			 ev = new BioType35Event();			
			ev.setEventId(eventId);	
			ev.setIsRolledFlag(true);			
			byte[] featureData = fu.getDataFromFile(dataFilePath + "feature_type_35.bin");
			ev.setCmlFeatureData(featureData);
		}
		return ev;
	}

}
