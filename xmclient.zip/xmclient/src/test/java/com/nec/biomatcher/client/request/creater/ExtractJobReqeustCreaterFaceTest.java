package com.nec.biomatcher.client.request.creater;

import java.util.concurrent.TimeUnit;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.nec.biomatcher.client.util.FileUtil;
import com.nec.biomatcher.client.util.JaxBUtil;
import com.nec.biomatcher.webservices.AlgorithmType;
import com.nec.biomatcher.webservices.ExtractInputParameter;
import com.nec.biomatcher.webservices.ExtractInputPayloadDto;
import com.nec.biomatcher.webservices.ExtractJobRequestDto;
import com.nec.biomatcher.webservices.FaceExtractInputImage;
import com.nec.biomatcher.webservices.GenderEnum;
import com.nec.biomatcher.webservices.Image;
import com.nec.biomatcher.webservices.ImageFormat;
import com.nec.biomatcher.webservices.ImagePosition;
import com.nec.biomatcher.webservices.MetaInfoCommon;
import com.nec.biomatcher.webservices.Modality;
import com.nec.biomatcher.webservices.ObjectFactory;
import com.nec.biomatcher.webservices.TemplateExtractInputImage;

public class ExtractJobReqeustCreaterFaceTest {
	
	private static GenderEnum Gender = GenderEnum.M;
	private static Integer Yob = 1977;	
	private static String Race = "B";	
	private static String templateType = "TEMPLATE_TYPE_1";
	


	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testBuildExtractJobRequest() throws JAXBException {
		ExtractJobRequestDto  exq = buildExtractJobRequest();
		JaxBUtil<ExtractJobRequestDto> jaxb = new JaxBUtil<ExtractJobRequestDto>();
		jaxb.marshalToFile(ExtractJobRequestDto.class, exq, "/C:/Users/000001A006PBP/Desktop/test/extract_request_jpg.xml");
		System.out.println("OKOKOK");
	}
	
	public ExtractJobRequestDto buildExtractJobRequest() {	
		long jobTimeoutMilli = TimeUnit.SECONDS.toMillis(60);
		ExtractJobRequestDto extractJobRequestDto = new ExtractJobRequestDto();		
		String callbackIp = "192.168.22.118";
		String callbackPort = "5679";
		String callbackUrl = "http://" + callbackIp + ":" + callbackPort;		
		extractJobRequestDto.setCallbackUrl(callbackUrl);
		ObjectFactory objectFactory = new ObjectFactory();
		JAXBElement<Integer> priority = objectFactory.createExtractJobRequestDtoPriority(10);
		extractJobRequestDto.setPriority(priority);
		extractJobRequestDto.setJobTimeoutMill(jobTimeoutMilli);
		extractJobRequestDto.setJobMode("live");
		ExtractInputPayloadDto extractInputPayloadDto = buildExtractInputPayloadDto();
		extractJobRequestDto.setExtractInputPayload(extractInputPayloadDto);
		return extractJobRequestDto;
	}

	private ExtractInputPayloadDto buildExtractInputPayloadDto() {
		//URL url = Thread.currentThread().getContextClassLoader().getResource("/C:/Users/000001A006PBP/Desktop/test/face0.neofaces17");
		 ObjectFactory objectFactory = new ObjectFactory();
		ExtractInputPayloadDto epDto = new ExtractInputPayloadDto();
		JAXBElement<String> candidateId = objectFactory.createExtractInputPayloadDtoCandidateId("ex_test");
		epDto.setCandidateId(candidateId);
		TemplateExtractInputImage templateImage = new TemplateExtractInputImage();	
		FaceExtractInputImage faceExtractInputImag = new FaceExtractInputImage();			
		Image faceImage = new Image();
		FileUtil fu = new FileUtil();
        byte[] imageRollData = fu.getDataFromFile("/C:/Users/000001A006PBP/Desktop/test/face0.jpg");      
        faceImage.setType(ImageFormat.JPEG);
        faceImage.setPosition(ImagePosition.FRONTAL_FACE);
        faceImage.setData(imageRollData);        
        faceExtractInputImag.setFaceImage(faceImage);
        
		ExtractInputParameter parameter = new ExtractInputParameter();
		parameter.setAlgorithmType(AlgorithmType.FACE_NEC_S_17);
		parameter.setModality(Modality.FACE);		
		faceExtractInputImag.getExtractionParameters().add(parameter);        
       
        MetaInfoCommon metaInfoCommon = new MetaInfoCommon();
        metaInfoCommon.setGender(GenderEnum.M);
        JAXBElement<Integer> yob = objectFactory.createMetaInfoCommonYob(Yob);
        metaInfoCommon.setYob(yob);
        metaInfoCommon.setRace(Race);
        metaInfoCommon.setGender(Gender);       
        JAXBElement<MetaInfoCommon> mm = objectFactory.createExtractInputPayloadDtoMetaInfoCommon(metaInfoCommon);
        epDto.setMetaInfoCommon(mm); 

      templateImage.setExtractInputImage(faceExtractInputImag);
      templateImage.getTemplateTypes().add(templateType);
      epDto.getTemplateExtractInputImageList().add(templateImage);
      fu = null;
      return epDto;	
	}

}
