package com.nec.biomatcher.client.request.v3;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.xml.bind.JAXBElement;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.nec.biomatcher.client.util.FileUtil;
import com.nec.biomatcher.client.util.JaxBUtil;
import com.nec.biomatcher.webservices.AlgorithmType;
import com.nec.biomatcher.webservices.BioParameterDto;
import com.nec.biomatcher.webservices.BioParameterGroupDto;
import com.nec.biomatcher.webservices.ExtractInputParameter;
import com.nec.biomatcher.webservices.ExtractInputPayloadDto;
import com.nec.biomatcher.webservices.ExtractJobRequestDto;
import com.nec.biomatcher.webservices.FingerExtractInputImage;
import com.nec.biomatcher.webservices.GenderEnum;
import com.nec.biomatcher.webservices.Image;
import com.nec.biomatcher.webservices.ImageFormat;
import com.nec.biomatcher.webservices.ImagePosition;
import com.nec.biomatcher.webservices.MetaInfoCommon;
import com.nec.biomatcher.webservices.Modality;
import com.nec.biomatcher.webservices.ObjectFactory;
import com.nec.biomatcher.webservices.TemplateExtractInputImage;

public class ExtractJobReqeustCreaterFinger35_43Test {

	private static GenderEnum Gender = GenderEnum.M;
	private static Integer Yob = 1977;
	private static String Race = "B";
	//private static String templateType35 = "TEMPLATE_TYPE_35";

	private static String templateType43 = "TEMPLATE_TYPE_43";

	private static String[] bioParameterKey = { "RollPrimaryPatterns", "RollReferencePatterns", "SlapPrimaryPatterns",
			"SlapReferencePatterns", "TenprintImageEnhancement", "FingerAutoCorrection", "SlapConfidenceThreshold",
			"SlapHandConfidenceThreshold", "DuplicationCheckScoreThreshold", "SequenceCheckScoreThreshold",
			"SequenceCheckScoreThresholdLittle" };

	private static String[] bioParameterValue = { "WSRLAWWLLL", "L WW   WW ", "RSSLAWWSSS", "   W      ",
			"SMOOTH,SMOOTH,AGC,HISTOGRAM", "true", "70", "2", "1600", "1600", "1000" };

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testBuildExtractJobRequest() throws Exception {
		ExtractJobRequestDto exq = buildExtractJobRequest();
		JaxBUtil<ExtractJobRequestDto> jaxb = new JaxBUtil<ExtractJobRequestDto>();
		jaxb.marshalToFile(ExtractJobRequestDto.class, exq,
				"/C:/Users/000001A006PBP/Desktop/test/extract_request_43.xml");
		System.out.println("OKOKOK");
	}

	public ExtractJobRequestDto buildExtractJobRequest() throws Exception {
		long jobTimeoutMilli = TimeUnit.SECONDS.toMillis(60);
		ExtractJobRequestDto extractJobRequestDto = new ExtractJobRequestDto();
		String callbackIp = "192.168.22.118";
		String callbackPort = "5679";
		String callbackUrl = "http://" + callbackIp + ":" + callbackPort;
		extractJobRequestDto.setCallbackUrl(callbackUrl);
		ObjectFactory objectFactory = new ObjectFactory();
		JAXBElement<Integer> priority = objectFactory.createExtractJobRequestDtoPriority(10);
		extractJobRequestDto.setPriority(priority);
		extractJobRequestDto.setJobTimeoutMill(jobTimeoutMilli);
		extractJobRequestDto.setJobMode("live");
		ExtractInputPayloadDto extractInputPayloadDto = buildExtractInputPayloadDto();
		extractJobRequestDto.setExtractInputPayload(extractInputPayloadDto);
		return extractJobRequestDto;
	}

	private ExtractInputPayloadDto buildExtractInputPayloadDto() throws Exception {
		// URL url =
		// Thread.currentThread().getContextClassLoader().getResource("/C:/Users/000001A006PBP/Desktop/test/face0.neofaces17");
		ObjectFactory objectFactory = new ObjectFactory();
		ExtractInputPayloadDto epDto = new ExtractInputPayloadDto();
		JAXBElement<String> candidateId = objectFactory.createExtractInputPayloadDtoCandidateId("ex_test");
		epDto.setCandidateId(candidateId);
		epDto.setTemplateExtractInputImageList(buildTemplateExtractInputImageList());
		MetaInfoCommon metaInfoCommon = new MetaInfoCommon();
		metaInfoCommon.setGender(GenderEnum.M);
		JAXBElement<Integer> yob = objectFactory.createMetaInfoCommonYob(Yob);
		metaInfoCommon.setYob(yob);
		metaInfoCommon.setRace(Race);
		metaInfoCommon.setGender(Gender);
		JAXBElement<MetaInfoCommon> mm = objectFactory.createExtractInputPayloadDtoMetaInfoCommon(metaInfoCommon);
		epDto.setMetaInfoCommon(mm);
		

		return epDto;
	}

	public static List<TemplateExtractInputImage> buildTemplateExtractInputImageList() throws Exception {
		List<TemplateExtractInputImage> templateImageList = new ArrayList<>();
		//templateImageList.add(buildTemplateExtractInputImage35());
		templateImageList.add(buildTemplateExtractInputImage43());
		
		return templateImageList;
	}

//	public static TemplateExtractInputImage buildTemplateExtractInputImage35() throws Exception {
//		TemplateExtractInputImage templateExtractInputImage = new TemplateExtractInputImage();
//		templateExtractInputImage.setExtractInputImage(buildTenprintFingerInputImage35());
//		templateExtractInputImage.getTemplateTypes().add(templateType35);
//		return templateExtractInputImage;
//	}

//	public static FingerExtractInputImage buildTenprintFingerInputImage35() throws Exception {
//		ImagePosition[] imagePositions = { ImagePosition.ROLL_RINDEX, ImagePosition.ROLL_RINDEX,
//				ImagePosition.ROLL_RINDEX, ImagePosition.ROLL_RINDEX };
//
//		FileUtil fu = new FileUtil();
//
//		FingerExtractInputImage tenprintFingerInputImage = new FingerExtractInputImage();
//	
//			byte[] imageData = fu.getDataFromFile("/C:/Users/000001A006PBP/Desktop/test/ROLL_" + 1 + ".wsq");
//			Image image = new Image();
//			image.setData(imageData);
//			image.setPosition(imagePositions[0]);
//			image.setType(ImageFormat.WSQ);
//			tenprintFingerInputImage.getImages().add(image);		
//
// 		ExtractInputParameter extParameter = new ExtractInputParameter();
// 	    extParameter.setAlgorithmType(AlgorithmType.FINGER_CML);
// 		extParameter.setModality(Modality.FINGER);
//		tenprintFingerInputImage.getExtractionParameters().add(extParameter);
//
//		return tenprintFingerInputImage;
//	}

	public static TemplateExtractInputImage buildTemplateExtractInputImage43() throws Exception {
		TemplateExtractInputImage templateExtractInputImage = new TemplateExtractInputImage();
		templateExtractInputImage.setExtractInputImage(buildTenprintFingerInputImage43());
		templateExtractInputImage.getTemplateTypes().add(templateType43);
		return templateExtractInputImage;
	}

	public static FingerExtractInputImage buildTenprintFingerInputImage43() throws Exception {
		ImagePosition[] imagePositions = { ImagePosition.UNKNOWN, ImagePosition.ROLL_RTHUMB, ImagePosition.ROLL_RINDEX,
				ImagePosition.ROLL_RMIDDLE };

		FileUtil fu = new FileUtil();

		FingerExtractInputImage tenprintFingerInputImage = new FingerExtractInputImage();
		for (int i = 1; i <= 3; i++) {
			byte[] imageData = fu.getDataFromFile("/C:/Users/000001A006PBP/Desktop/test/ROLL_" + i + ".wsq");
			Image image = new Image();
			image.setData(imageData);
			image.setPosition(imagePositions[i]);
			image.setType(ImageFormat.WSQ);
			tenprintFingerInputImage.getImages().add(image);
		}

		ExtractInputParameter extParameter = new ExtractInputParameter();
		extParameter.setAlgorithmType(AlgorithmType.FINGER_LFML);
		extParameter.setModality(Modality.FINGER);

//		List<BioParameterDto> parameters = new ArrayList<>();
//		BioParameterDto first = new BioParameterDto();
//		first.setKey("FisFeType");
//		first.setValue("C");
//		parameters.add(first);
//
//		for (int i = 0; i < bioParameterKey.length; i++) {
//			BioParameterDto bioParameterDto = new BioParameterDto();
//			bioParameterDto.setKey(bioParameterKey[i]);
//			bioParameterDto.setValue(bioParameterValue[i]);
//			parameters.add(bioParameterDto);
//		}
//
//		extParameter.getParameters().addAll(parameters);

//		tenprintFingerInputImage.getExtractionParameters().add(extParameter);

		return tenprintFingerInputImage;
	}

}
