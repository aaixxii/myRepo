package com.nec.biomatcher.client.request.creater;

import static com.nec.biomatcher.client.common.XmClientConstants.CLIENT_CALLBACK_IP;
import static com.nec.biomatcher.client.common.XmClientConstants.CLIENT_CALLBACK_PORT;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;

import org.junit.Test;

import com.nec.biomatcher.client.manager.XmClientManager;
import com.nec.biomatcher.client.util.FileUtil;
import com.nec.biomatcher.client.util.JaxBUtil;
import com.nec.biomatcher.webservices.AlgorithmType;
import com.nec.biomatcher.webservices.GenderEnum;
import com.nec.biomatcher.webservices.MatchInputParameter;
import com.nec.biomatcher.webservices.MetaInfoCommon;
import com.nec.biomatcher.webservices.Modality;
import com.nec.biomatcher.webservices.ObjectFactory;
import com.nec.biomatcher.webservices.SearchItemInputPayloadDto;
import com.nec.biomatcher.webservices.SearchJobRequestDto;
import com.nec.biomatcher.webservices.SearchOptionsDto;
import com.nec.biomatcher.webservices.SearchRequestItemDto;

public class SearchJobReqeust35Creater {	
	String templateType = "TEMPLATE_TYPE_35";
	long jobTimeoutMilli = TimeUnit.SECONDS.toMillis(60);

	public static GenderEnum searchGender = GenderEnum.M;
	public static Integer searchYob = 1977;
	public static Integer searchYobRange = 10;
	public static String searchRace = "B";
	public static String searchRegionFlags = "32";
	public static String searchUserFlags = "2,3";

	public SearchJobReqeust35Creater() {
	}
	
	@Test
	public void testBuildSeachJobRequest() throws JAXBException {
		SearchJobRequestDto searchRq =  buildSeachJobRequest("templates/TEMPLATE_TYPE_35_0.dat");
		JaxBUtil<SearchJobRequestDto> jaxb = new JaxBUtil<SearchJobRequestDto>();
		jaxb.marshalToFile(SearchJobRequestDto.class, searchRq, "/C:/Users/000001A006PBP/Desktop/test/search_request_36.xml");
		System.out.println("OKOKOK");
	}

	public SearchJobRequestDto buildSeachJobRequest(String dataFile) {
		SearchJobRequestDto searchJobRequestDto = new SearchJobRequestDto();
		String callbackIp = XmClientManager.getInstance().getValue(CLIENT_CALLBACK_IP);
		String callbackPort = XmClientManager.getInstance().getValue(CLIENT_CALLBACK_PORT);
		String callbackUrl = "http://" + callbackIp + ":" + callbackPort;
		searchJobRequestDto.setCallbackUrl(callbackUrl);
		//searchJobRequestDto.setCallbackUrl("http://192.168.22.118:8888");
		ObjectFactory objectFactory = new ObjectFactory();		
		JAXBElement<Integer> priority = objectFactory.createSearchJobRequestDtoPriority(10);		
		searchJobRequestDto.setPriority(priority);
		searchJobRequestDto.setJobTimeoutMill(3600000L);
		searchJobRequestDto.setJobMode("live");
		SearchRequestItemDto searchRequestItemDto = new SearchRequestItemDto();
		searchRequestItemDto.setSearchItemPayloadDto(buildSearchItemInputPayload(dataFile));
		searchRequestItemDto.getBinIdList().add(35);
		searchJobRequestDto.getSearchRequestItemList().add(searchRequestItemDto);
		return searchJobRequestDto;
	}

	public SearchItemInputPayloadDto buildSearchItemInputPayload(String templateFileName) {
		SearchItemInputPayloadDto searchItemInputPayloadDto = new SearchItemInputPayloadDto();
		searchItemInputPayloadDto.setFunctionId("35");
		searchItemInputPayloadDto.setTemplateType("TEMPLATE_TYPE_35");
		searchItemInputPayloadDto.setMaxHitCount(10);
		searchItemInputPayloadDto.setMinScoreThreshold(1);		

		SearchOptionsDto searchOptions = new SearchOptionsDto();
		MetaInfoCommon metaInfoCommon = new MetaInfoCommon();
		metaInfoCommon.setGender(GenderEnum.F);
		metaInfoCommon.setRace("1");
		ObjectFactory objectFactory = new ObjectFactory();		
		
		JAXBElement<Long> jaxLong = objectFactory.createMetaInfoCommonRegionFlags(1L);
		metaInfoCommon.setRegionFlags(jaxLong);
		
		JAXBElement<String> userFlags = objectFactory.createMetaInfoCommonUserFlags("false");
		metaInfoCommon.setUserFlags(userFlags);
		
		JAXBElement<Integer> yob = objectFactory.createMetaInfoCommonYob(1);
		metaInfoCommon.setYob(yob);
		JAXBElement<Integer> yobRange = objectFactory.createMetaInfoCommonYobRange(1);
		metaInfoCommon.setYobRange(yobRange);

		List<MatchInputParameter> matchInputParameterList = new ArrayList<MatchInputParameter>();
		MatchInputParameter mp = new MatchInputParameter();
		mp.setModality(Modality.FINGER);
		mp.setAlgorithmType(AlgorithmType.FINGER_CML);
		matchInputParameterList.add(mp);
		searchOptions.setMetaInfoCommon(metaInfoCommon);
		searchOptions.getMatchInputParameterList().addAll(matchInputParameterList);
		FileUtil fu = new FileUtil();
		byte[] templateData = fu.getDataFromFile(templateFileName);				
		searchItemInputPayloadDto.setSearchOptions(searchOptions);
		searchItemInputPayloadDto.setTemplateData(templateData);
		fu = null;
		return searchItemInputPayloadDto;
	}
}
