package com.nec.biomatcher.client.request.creater;

import javax.xml.bind.JAXBException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.nec.biomatcher.client.util.JaxBUtil;
import com.nec.biomatcher.webservices.SyncJobRequestDto;

public class SyncDeleteJobRequestCreaterTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testBuildSyncDeleteRequest() throws JAXBException {
		SyncDeleteJobRequestCreater creater = new SyncDeleteJobRequestCreater(null);
		SyncJobRequestDto delReqeust = creater.buildSyncDeleteRequest();
		JaxBUtil<SyncJobRequestDto> jaxb = new JaxBUtil<SyncJobRequestDto>();
		jaxb.marshalToFile(SyncJobRequestDto.class, delReqeust, "/C:/Users/000001A006PBP/Desktop/test/delete_request_1.xml");
		System.out.println("OKOKOK");
		
		
		
	}

}
