package com.nec.biomatcher.client.util;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ExcelWriterTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testPrepareExcellData() {
		String[][] jobInfoArr = new String[2][4];
		jobInfoArr[0] = new String[] { "jobid", "usedTimes", "jobStatus", "jobMode" };
		jobInfoArr[1] = new String[4];
		jobInfoArr[1][0] = "123456";
		jobInfoArr[1][1] = "5000";
		jobInfoArr[1][2] = "sucess";
		jobInfoArr[1][3] = "live";		
		
		String[][] candidatesArray = new String[3 + 1][5];
		candidatesArray[0] = new String[] { "ExternalId", "binId", "score", "requestItemKey", "searchNodeId" };
		for (int i = 1; i <= 3; i++) {
			candidatesArray[i] = new String[] { "externalId1" + String.valueOf(i), "232" + String.valueOf(i),
					"999" + String.valueOf(i), " testKey", "sn001" + String.valueOf(i) };
		}		
		
		String[][] statistaticsArray = new String[3 + 1][3];
		statistaticsArray[0] = new String[] { "binid", "readCout", "matchCount" };
		for (int i = 0; i < 3; i++) {
			statistaticsArray[i + 1] = new String[] { "232" + String.valueOf(i),
					"100" + String.valueOf(i) , "200" + String.valueOf(i) };					
		}
		
		Object[] excelData = new Object[3];
		excelData[0] = jobInfoArr;
		excelData[1] = candidatesArray;
		excelData[2] = statistaticsArray;
		
		ExcelWriterForTester ew = new ExcelWriterForTester("10000");
		ew.prepareExcellData(excelData);
	}
}
