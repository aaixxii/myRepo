package com.nec.biomatcher.client.manager;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.atomic.AtomicBoolean;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CallbackServerTester {
	private int callbackPort;
	private ServerSocket serverSocket;
	private static String outPath;	
	private AtomicBoolean mustStop = new AtomicBoolean(Boolean.FALSE);
	private static Logger logger = LoggerFactory.getLogger("CallbackLogger");
	

	public CallbackServerTester() {
		try {
			Path resourceDirectory = Paths.get("src/test/resources/resultdata");
			outPath = resourceDirectory.toString();
			outPath = outPath.endsWith("/") ? outPath : outPath + "/";
			callbackPort = 1234;
			serverSocket = new ServerSocket(callbackPort);
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
			System.out.println("Faild to start CallbackServer!");
			System.exit(1);
		}
		System.out.println("Calllback Server is started!");
	}
	
	public static void main(String[] args) {
		CallbackServerTester server = new CallbackServerTester();
		server.run();
	}
	
	public void run() {
		while (!mustStop.get()) {
			try {
				Socket socket = serverSocket.accept();
				logger.info("Megha is connectecd to me! ip:{}", socket.getRemoteSocketAddress());
					NewCallbackWriter cw = new NewCallbackWriter(socket, outPath);
				Thread task = new Thread(cw);
				task.start();
	
			} catch (Exception e) {
				logger.error(e.getMessage(), e);
			}
		}
	}

	public  void stop() {
		this.mustStop.getAndSet(Boolean.TRUE);
	}
}
