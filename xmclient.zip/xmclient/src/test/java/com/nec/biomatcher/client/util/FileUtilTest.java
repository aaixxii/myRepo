package com.nec.biomatcher.client.util;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class FileUtilTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testReadImageFromFile() {
		String imageFile = "/C:/Users/000001A006PBP/Desktop/test/face0.jpg";
		FileUtil util = new FileUtil();
		byte[] result = util.readImageFromFile("jpg", imageFile);
		System.out.println("OKOKOK");
		String savePath = "/C:/Users/000001A006PBP/Desktop/test/newImage";
		util.saveImageToFile("jpg", result, savePath);
	}

	@Test
	public void testSaveStringToFile() {
		FileUtil util = new FileUtil();
		byte[] result = util.getDataFromFile("/C:/Users/000001A006PBP/Desktop/test/search_image_FI_4_4.xml");
		String save = new String(result);		
		String saveFile =  "/C:/Users/000001A006PBP/Desktop/testNew/test.xml";
		util.saveStringToFile(save, saveFile);
	}

}
