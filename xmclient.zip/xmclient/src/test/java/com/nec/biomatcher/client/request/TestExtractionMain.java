package com.nec.biomatcher.client.request;

import java.net.URL;
import java.util.concurrent.TimeUnit;

import com.nec.biomatcher.client.util.JaxBUtil;
import com.nec.biomatcher.webservices.BioJobStatus;
import com.nec.biomatcher.webservices.BioMatcherWebServiceInterface;
import com.nec.biomatcher.webservices.ExtractJobRequestDto;
import com.nec.biomatcher.webservices.ExtractJobResultDto;

public class TestExtractionMain {	
	private static String reqeustFileFullName;
	private static String resultXmlPath;
	


	public static void main(String[] args) {
		URL requstUrl =Thread.currentThread().getContextClassLoader().getResource("requestdata/ROLL_5.wsq"); 
		reqeustFileFullName = requstUrl.getPath();
		
		URL resultUrl =Thread.currentThread().getContextClassLoader().getResource("resultdata"); 
		resultXmlPath = resultUrl.getPath();
		
		TestExtractionMain test = new TestExtractionMain();
		test.submitInquiryRequest();
	}
	
	
	
	
	public void submitInquiryRequest() {		
		ExtractJobReqeustCreater creater = null;
		ExtractJobRequestDto extractJobRequest = null;		
		try {
			BioMatcherWebServiceInterface xmWebService = WsdlUtilForTest.getXmWebService();
			if (reqeustFileFullName.endsWith(".xml")) {
				JaxBUtil<ExtractJobRequestDto> jaxbUtil = new JaxBUtil<ExtractJobRequestDto>();
				extractJobRequest = jaxbUtil.unmarshalFromFile(ExtractJobRequestDto.class,reqeustFileFullName);
			} else if (reqeustFileFullName.endsWith(".dat") || reqeustFileFullName.endsWith(".wsq")) {
				creater = new ExtractJobReqeustCreater(reqeustFileFullName);
				extractJobRequest =  creater.buildExtractJobRequest(reqeustFileFullName);
			} else {
				System.out.println("Request file is worng , it is not a xml or dat file. skip...");
			}			

			String jobId = xmWebService.submitExtractionJob(extractJobRequest);
			getExtractJobResult(jobId, System.currentTimeMillis());
			creater = null;
			System.out.println("Extract job sucess completed!!");	
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());			
		}		
	}
	
	
	public void getExtractJobResult(String jobId, long startTime) {
		ExtractJobResultDto results = null;	
		long jobTimeOutLimit = TimeUnit.MINUTES.toMillis(30);
		try {
				BioMatcherWebServiceInterface xmWebService = WsdlUtilForTest.getXmWebService();
			while (System.currentTimeMillis() - startTime <= jobTimeOutLimit) {
				results = xmWebService.getExtractionJobResult(jobId);
				if (results != null  && results.getStatus() == BioJobStatus.COMPLETED) {					
					System.out.println("ExtractJobResult jobId:" + results.getJobId());
					System.out.println("ExtractJobResult status:" +  results.getStatus().name());
					break;
				}				
			}
			if (results != null) {			
				resultXmlPath = resultXmlPath + "/" + jobId + ".xml";
				JaxBUtil<ExtractJobResultDto> jaxbUtil = new JaxBUtil<ExtractJobResultDto>();
				jaxbUtil.marshalToFile(ExtractJobResultDto.class, results, resultXmlPath);
			} else {
				System.out.println("Job result is empty, skip save to file. jobId=" +  jobId);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());			
		}		
	}	
}
