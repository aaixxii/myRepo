package com.nec.biomatcher.client.util;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Unmarshaller;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamReader;
import javax.xml.transform.stream.StreamSource;

import com.nec.biomatcher.webservices.SearchJobRequestDto;

public class Tester2 {

	public static void main(String[] args) throws Exception {
		XMLInputFactory xif = XMLInputFactory.newFactory();
		StreamSource xml = new StreamSource("D:/req.xml");
		XMLStreamReader xsr = xif.createXMLStreamReader(xml);
		xsr.nextTag();
		while (!xsr.getLocalName().equals("return")) {
			xsr.nextTag();
		}

		JAXBContext jc = JAXBContext.newInstance(Customer.class);
		Unmarshaller unmarshaller = jc.createUnmarshaller();
		JAXBElement<SearchJobRequestDto> jb = unmarshaller.unmarshal(xsr, SearchJobRequestDto.class);
		xsr.close();
		SearchJobRequestDto customer = jb.getValue();
		System.out.println(customer.getCallbackUrl());
	}

}
