package com.nec.biomatcher.client.request.creater;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.nec.biomatcher.client.util.FileUtil;
import com.nec.biomatcher.client.util.JaxBUtil;
import com.nec.biomatcher.webservices.AlgorithmType;
import com.nec.biomatcher.webservices.MatchInputParameter;
import com.nec.biomatcher.webservices.MetaInfoCommon;
import com.nec.biomatcher.webservices.Modality;
import com.nec.biomatcher.webservices.ObjectFactory;
import com.nec.biomatcher.webservices.SearchItemInputPayloadDto;
import com.nec.biomatcher.webservices.SearchJobRequestDto;
import com.nec.biomatcher.webservices.SearchOptionsDto;
import com.nec.biomatcher.webservices.SearchRequestItemDto;

public class SearchJob36ReqeustCreaterTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testBuildSeachJobRequest() throws JAXBException {
		SearchJobRequestDto searchRq =  buildSeachJobRequest();
		JaxBUtil<SearchJobRequestDto> jaxb = new JaxBUtil<SearchJobRequestDto>();
		jaxb.marshalToFile(SearchJobRequestDto.class, searchRq, "/C:/Users/000001A006PBP/Desktop/test/search_request_36.xml");
		System.out.println("OKOKOK");
	}


	public SearchJobRequestDto buildSeachJobRequest() {		
		SearchJobRequestDto searchJobRequestDto = new SearchJobRequestDto();	
		String callbackUrl = "http://" + "192.168.22.118" + ":" + "5679";
		searchJobRequestDto.setCallbackUrl(callbackUrl);		
		ObjectFactory objectFactory = new ObjectFactory();		
		JAXBElement<Integer> priority = objectFactory.createSearchJobRequestDtoPriority(1);		
		searchJobRequestDto.setPriority(priority);
		searchJobRequestDto.setJobTimeoutMill(3600000L);
		searchJobRequestDto.setJobMode("live");
		SearchRequestItemDto searchRequestItemDto = new SearchRequestItemDto();
		searchRequestItemDto.setSearchItemPayloadDto(buildSearchItemInputPayload());
		searchRequestItemDto.getBinIdList().add(36);
		searchJobRequestDto.getSearchRequestItemList().add(searchRequestItemDto);
		return searchJobRequestDto;
	}

	public SearchItemInputPayloadDto buildSearchItemInputPayload() {
		SearchItemInputPayloadDto searchItemInputPayloadDto = new SearchItemInputPayloadDto();
		searchItemInputPayloadDto.setFunctionId("36");
		searchItemInputPayloadDto.setTemplateType("TEMPLATE_TYPE_36");
		searchItemInputPayloadDto.setMaxHitCount(10);
		searchItemInputPayloadDto.setMinScoreThreshold(1);		

		SearchOptionsDto searchOptions = new SearchOptionsDto();
		MetaInfoCommon metaInfoCommon = new MetaInfoCommon();
//		metaInfoCommon.setGender(GenderEnum.F);
//		metaInfoCommon.setRace("1");
//		ObjectFactory objectFactory = new ObjectFactory();		
//		
//		JAXBElement<Long> jaxLong = objectFactory.createMetaInfoCommonRegionFlags(1L);
//		metaInfoCommon.setRegionFlags(jaxLong);
//		
//		JAXBElement<String> userFlags = objectFactory.createMetaInfoCommonUserFlags("false");
//		metaInfoCommon.setUserFlags(userFlags);
//		
//		JAXBElement<Integer> yob = objectFactory.createMetaInfoCommonYob(1);
//		metaInfoCommon.setYob(yob);
//		JAXBElement<Integer> yobRange = objectFactory.createMetaInfoCommonYobRange(1);
//		metaInfoCommon.setYobRange(yobRange);

		List<MatchInputParameter> matchInputParameterList = new ArrayList<MatchInputParameter>();
		MatchInputParameter mp = new MatchInputParameter();
		mp.setModality(Modality.FINGER);
		mp.setAlgorithmType(AlgorithmType.FINGER_CML);
		matchInputParameterList.add(mp);
		searchOptions.setMetaInfoCommon(metaInfoCommon);
		searchOptions.getMatchInputParameterList().addAll(matchInputParameterList);
		FileUtil fu = new FileUtil();
		byte[] templateData = fu.getDataFromFile("/C:/Users/000001A006PBP/Desktop/test/TEMPLATE_TYPE_36_0.dat");				
		searchItemInputPayloadDto.setSearchOptions(searchOptions);
		searchItemInputPayloadDto.setTemplateData(templateData);
		fu = null;
		return searchItemInputPayloadDto;
	}	

}
