package com.nec.biomatcher.client.request.creater;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import javax.xml.bind.JAXBException;

import org.junit.Test;

import com.nec.biomatcher.client.util.FileUtil;
import com.nec.biomatcher.client.util.JaxBUtil;
import com.nec.biomatcher.webservices.AlgorithmType;
import com.nec.biomatcher.webservices.BioFeType;
import com.nec.biomatcher.webservices.BioFingerFeatureInfo;
import com.nec.biomatcher.webservices.BioTemplateHeader;
import com.nec.biomatcher.webservices.BioTemplatePayload;
import com.nec.biomatcher.webservices.BioType42Event;
import com.nec.biomatcher.webservices.BiometricEventSyncTypeDto;
import com.nec.biomatcher.webservices.GenderEnum;
import com.nec.biomatcher.webservices.InsertBiometricEventDto;
import com.nec.biomatcher.webservices.InsertTemplateInfo;
import com.nec.biomatcher.webservices.PatternType;
import com.nec.biomatcher.webservices.SyncJobRequestDto;

public class SyncInsertJob42RequestCreaterTest {

	Random rnd = new Random();

	public static GenderEnum gender = GenderEnum.M;
	public static Integer yob = 1977;
	public static char race = 'B';
	public static String regionFlags = "32";
	public static String userFlag = "42Rolled";

	String templateType = "TEMPLATE_TYPE_42";
	long jobTimeoutMilli = TimeUnit.SECONDS.toMillis(120);

	//int MAX_HIT_CANDIDATES = 20;
	//int MIN_HIT_SCORE_THRESHOLD = 1;
	
	boolean isRolledFlag = true; 	
	
	String templatePath = "/C:/Users/000001A006PBP/Desktop/testOld";
	

	private static final Integer binId = 42;
	PatternType primaryPatten[] = { PatternType.A, PatternType.T, PatternType.R, PatternType.L, PatternType.W,
			PatternType.S, PatternType.N, PatternType.S, PatternType.S, PatternType.S };
	
	PatternType secondaryPatten[] = { PatternType.A, PatternType.T, PatternType.R, PatternType.L, PatternType.W,
			PatternType.S, PatternType.N, PatternType.S, PatternType.S, PatternType.S };
	
	
	Integer rolled_qualities[] = { 60, 50, 85, 80, 90, 60, 50, 85, 80, 90 };

	
	@Test
	public void testBuildSyncUpdateRequest() throws JAXBException {
		SyncJobRequestDto insertRequest = buildSyncInsertRequest();
		JaxBUtil<SyncJobRequestDto> jaxb = new JaxBUtil<SyncJobRequestDto>();
		 jaxb.marshalToFile(SyncJobRequestDto.class, insertRequest,
		 "/C:/Users/000001A006PBP/Desktop/test/sync_insert_request_42.xml");		
		System.out.println("OKOKOK");
	}

	public SyncJobRequestDto buildSyncInsertRequest() {
		String callbackIp = "192.168.22.118";
		String callbackPort = "5679";
		String callbackUrl = "http://" + callbackIp + ":" + callbackPort;
		SyncJobRequestDto syncJobRequestDto = new SyncJobRequestDto();
		syncJobRequestDto.setCallbackUrl(callbackUrl);
		syncJobRequestDto.setJobMode("strict");
		syncJobRequestDto.setJobTimeoutMill(jobTimeoutMilli);
		List<BiometricEventSyncTypeDto> syncList = new ArrayList<>();
		syncList.add(buildInsertBiometricEventDto());
		syncJobRequestDto.getEventSyncDtoList().addAll(syncList);
		return syncJobRequestDto;
	}

	private InsertBiometricEventDto buildInsertBiometricEventDto() {
		InsertBiometricEventDto insertBiometricEventDto = new InsertBiometricEventDto();
		int exteralId = rnd.nextInt();
		int eventId = rnd.nextInt();
		insertBiometricEventDto.setExternalId(String.valueOf(exteralId));
		insertBiometricEventDto.setEventId(String.valueOf(eventId));
		insertBiometricEventDto.setUpdateFlag(true);

		InsertTemplateInfo insertTemplate = new InsertTemplateInfo();
		insertTemplate.setBinId(binId);
		insertTemplate.setTemplateType(templateType);
		
		BioTemplatePayload bioTemplatePayload = new BioTemplatePayload();
		BioTemplateHeader bioTemplateHeader = new BioTemplateHeader();
		bioTemplateHeader.setExternalId(String.valueOf(exteralId));
		bioTemplateHeader.setGender(gender);
		bioTemplateHeader.setRace((byte) race);
		bioTemplateHeader.setRegionFlags(regionFlags.getBytes());
		bioTemplateHeader.setUserFlags(userFlag.getBytes());
		bioTemplateHeader.setYob(yob.shortValue());
		bioTemplatePayload.setTemplateHeader(bioTemplateHeader);
		
		BioType42Event bioEvent = new BioType42Event();
		bioEvent.setEventId(String.valueOf(eventId));
		bioEvent.setAlgorithmType(AlgorithmType.FINGER_LFML);
		bioEvent.setFeType(BioFeType.L);
		List<BioFingerFeatureInfo> fingerInfoList = new ArrayList<>();
		if (isRolledFlag) {
			for (int fingerPosition = 1; fingerPosition <= 10; fingerPosition++) {
				BioFingerFeatureInfo bioFingerFeatureInfo = buildLfmlBioFingerFeatureInfo(fingerPosition);
				fingerInfoList.add(bioFingerFeatureInfo);
			}
		}		
		bioEvent.getFingerInfoList().addAll(fingerInfoList);	
		bioTemplatePayload.getEvents().add(bioEvent);
		insertTemplate.setTemplatePayload(bioTemplatePayload);
		insertBiometricEventDto.getInsertTemplateInfoList().add(insertTemplate);		
		return insertBiometricEventDto;
	}
	
	private BioFingerFeatureInfo  buildLfmlBioFingerFeatureInfo(int fingerPosition) {
		BioFingerFeatureInfo bFeatureInfo = new BioFingerFeatureInfo();
		bFeatureInfo.setPrimaryPatternType(primaryPatten[fingerPosition -1]);
		bFeatureInfo.setSecondaryPatternType(secondaryPatten[fingerPosition -1]);
		bFeatureInfo.setFingerPosition(fingerPosition);
		bFeatureInfo.setQuality(rolled_qualities[fingerPosition -1]);
		FileUtil fu = new FileUtil();
		String fileName = "LFML_FINGER_" + fingerPosition + ".dat";		
		bFeatureInfo.setFeatureData(fu.getDataFromFile(templatePath + "/" + fileName));		
		return bFeatureInfo;		
	}
}
