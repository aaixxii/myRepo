package com.nec.biomatcher.client.request.creater;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import javax.xml.bind.JAXBException;

import org.junit.Test;

import com.nec.biomatcher.client.util.FileUtil;
import com.nec.biomatcher.client.util.JaxBUtil;
import com.nec.biomatcher.webservices.AlgorithmType;
import com.nec.biomatcher.webservices.BioFeType;
import com.nec.biomatcher.webservices.BioFingerFeatureInfo;
import com.nec.biomatcher.webservices.BioTemplateEvent;
import com.nec.biomatcher.webservices.BioTemplateHeader;
import com.nec.biomatcher.webservices.BioTemplatePayload;
import com.nec.biomatcher.webservices.BioType33Event;
import com.nec.biomatcher.webservices.BiometricEventSyncTypeDto;
import com.nec.biomatcher.webservices.GenderEnum;
import com.nec.biomatcher.webservices.InsertBiometricEventDto;
import com.nec.biomatcher.webservices.InsertTemplateInfo;
import com.nec.biomatcher.webservices.PatternType;
import com.nec.biomatcher.webservices.SyncJobRequestDto;

public class SyncInsertType33RequestCreaterTest {
	Random rnd = new Random();

	public static GenderEnum gender = GenderEnum.M;
	public static Integer yob = 1977;
	public static char race = 'B';
	public static String regionFlags = "32";
	public static String userFlag = "33Rolled";
	
	private static final  String dataFilePath = "/C:/Users/000001A006PBP/Desktop/test/";

	String templateType = "TEMPLATE_TYPE_33";
	long jobTimeoutMilli = TimeUnit.SECONDS.toMillis(120);

	//int MAX_HIT_CANDIDATES = 20;
	//int MIN_HIT_SCORE_THRESHOLD = 1;
	
	boolean isRolledFlag = true; 	

	private static final Integer binId = 33;
	
	public static final PatternType tp_primaryPatten[] = { PatternType.A, PatternType.T, PatternType.R, PatternType.L, PatternType.W,
			PatternType.S, PatternType.N, PatternType.S, PatternType.S, PatternType.S };
	
	public static final PatternType tp_secondaryPatten[] = { PatternType.A, PatternType.T, PatternType.R, PatternType.L, PatternType.W,
			PatternType.S, PatternType.N, PatternType.S, PatternType.S, PatternType.S };
	
	
	public static final Integer rolled_qualities[] = { 60, 50, 85, 80, 90, 60, 50, 85, 80, 90 };
	
	public static final int rolledFingerFileNumbers[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
	public static final int slapFingerFileNumbers[] = { 11, 12, 40, 41, 42, 43, 44, 45, 46, 47 };

	
	@Test
	public void testBuildSyncUpdateRequest() throws JAXBException {
		SyncJobRequestDto insertRequest = buildSyncInsertRequest();
		JaxBUtil<SyncJobRequestDto> jaxb = new JaxBUtil<SyncJobRequestDto>();
		 jaxb.marshalToFile(SyncJobRequestDto.class, insertRequest,
		 "/C:/Users/000001A006PBP/Desktop/test/sync_insert_request_33.xml");		
		System.out.println("OKOKOK");
	}

	public SyncJobRequestDto buildSyncInsertRequest() {
		String callbackIp = "192.168.22.118";
		String callbackPort = "5679";
		String callbackUrl = "http://" + callbackIp + ":" + callbackPort;
		SyncJobRequestDto syncJobRequestDto = new SyncJobRequestDto();
		syncJobRequestDto.setCallbackUrl(callbackUrl);
		syncJobRequestDto.setJobMode("strict");
		syncJobRequestDto.setJobTimeoutMill(jobTimeoutMilli);
		List<BiometricEventSyncTypeDto> syncList = new ArrayList<>();
		syncList.add(buildInsertBiometricEventDto());
		syncJobRequestDto.getEventSyncDtoList().addAll(syncList);
		return syncJobRequestDto;
	}

	private InsertBiometricEventDto buildInsertBiometricEventDto() {
		InsertBiometricEventDto insertBiometricEventDto = new InsertBiometricEventDto();
		int exteralId = rnd.nextInt();	
		exteralId = exteralId > 0 ? exteralId : -1 * exteralId;
		int eventId = rnd.nextInt();
		eventId = eventId > 0 ? eventId : -1 * eventId;
		insertBiometricEventDto.setExternalId(String.valueOf(exteralId));
		insertBiometricEventDto.setEventId(String.valueOf(eventId));
		insertBiometricEventDto.setUpdateFlag(true);

		InsertTemplateInfo insertTemplate = new InsertTemplateInfo();
		insertTemplate.setBinId(binId);
		insertTemplate.setTemplateType(templateType);
		
		BioTemplatePayload bioTemplatePayload = new BioTemplatePayload();
		BioTemplateHeader bioTemplateHeader = new BioTemplateHeader();
		bioTemplateHeader.setExternalId(String.valueOf(exteralId));
		bioTemplateHeader.setGender(gender);
		bioTemplateHeader.setRace((byte) race);
		bioTemplateHeader.setRegionFlags(regionFlags.getBytes());
		bioTemplateHeader.setUserFlags(userFlag.getBytes());
		bioTemplateHeader.setYob(yob.shortValue());
		bioTemplatePayload.setTemplateHeader(bioTemplateHeader);		
		
		BioTemplateEvent FINGER_PC2_E = buildType33Event(AlgorithmType.FINGER_PC_2, BioFeType.E, String.valueOf(eventId));
		BioTemplateEvent FINGER_FMP5_C = buildType33Event( AlgorithmType.FINGER_FMP_5,  BioFeType.C, String.valueOf(eventId));
		BioTemplateEvent FINGER_PC2_P = buildType33Event(AlgorithmType.FINGER_PC_2, BioFeType.P, String.valueOf(eventId));
	
	
		bioTemplatePayload.getEvents().add(FINGER_PC2_E);
		bioTemplatePayload.getEvents().add(FINGER_FMP5_C);
		bioTemplatePayload.getEvents().add(FINGER_PC2_P);
		
		insertTemplate.setTemplatePayload(bioTemplatePayload);
		insertBiometricEventDto.getInsertTemplateInfoList().add(insertTemplate);
		
		return insertBiometricEventDto;
	}
	
	private BioTemplateEvent buildType33Event (AlgorithmType algorithmType, BioFeType feType, String eventId)  {
		BioType33Event bioEvent = new BioType33Event();
		bioEvent.setEventId(eventId);
		bioEvent.setAlgorithmType(algorithmType);
		bioEvent.setFeType(feType);
		List<BioFingerFeatureInfo> fingerInfoList = new ArrayList<>();
		for (int fingerPosition = 1; fingerPosition <= 10; fingerPosition++) {
			BioFingerFeatureInfo bioFingerFeatureInfo = buildRdblBioFingerFeatureInfo(fingerPosition,
					algorithmType, feType);
			fingerInfoList.add(bioFingerFeatureInfo);
		}		
		bioEvent.getFingerInfoList().addAll(fingerInfoList);
		return bioEvent;
	}
	
	private  BioFingerFeatureInfo buildRdblBioFingerFeatureInfo(int fingerPosition, AlgorithmType algorithmType, BioFeType feType) {
		FileUtil fu = new FileUtil();
		BioFingerFeatureInfo bioFingerFeatureInfo = new BioFingerFeatureInfo();
		bioFingerFeatureInfo.setFingerPosition(fingerPosition);
		bioFingerFeatureInfo.setPrimaryPatternType(tp_primaryPatten[fingerPosition - 1]);
		bioFingerFeatureInfo.setSecondaryPatternType(tp_secondaryPatten[fingerPosition - 1]);
		
		bioFingerFeatureInfo.setQuality(rolled_qualities[fingerPosition - 1]);
		String filePart = AlgorithmType.FINGER_PC_2.equals(algorithmType) ? "RDBLS_PC2_SATOM" : "RDBL_LE_FMP5";		
		int fileNumber =  rolledFingerFileNumbers[fingerPosition - 1];
		String fileName = filePart + "_" + feType.name() + "_" + fileNumber + ".minutia.dat";	
		bioFingerFeatureInfo
				.setFeatureData(fu.getDataFromFile(dataFilePath + fileName));
		return bioFingerFeatureInfo;
	}
	
	
}
