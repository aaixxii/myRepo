package com.nec.biomatcher.client.request.creater;

import java.util.Arrays;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;

import org.junit.Test;

import com.nec.biomatcher.client.util.FileUtil;
import com.nec.biomatcher.client.util.JaxBUtil;
import com.nec.biomatcher.webservices.BioTemplateHeader;
import com.nec.biomatcher.webservices.BioTemplatePayload;
import com.nec.biomatcher.webservices.BioType1Event;
import com.nec.biomatcher.webservices.GenderEnum;
import com.nec.biomatcher.webservices.MetaInfoCommon;
import com.nec.biomatcher.webservices.ObjectFactory;
import com.nec.biomatcher.webservices.SearchItemInputPayloadDto;
import com.nec.biomatcher.webservices.SearchJobRequestDto;
import com.nec.biomatcher.webservices.SearchOptionsDto;
import com.nec.biomatcher.webservices.SearchRequestItemDto;

public class FIPriorityJobReqeustCreaterTest {
	private static final String outputDir = "/C:/Users/000001A006PBP/Desktop/test/";	
	private static final  Integer priority = 4;
	private static final  Integer jobCount = 5;
	private static final  String FunctionId = "FI";
	private static final  Integer binIds[]  = {1};	
	
	String templateType = "TEMPLATE_TYPE_1";
	long jobTimeoutMilli = TimeUnit.SECONDS.toMillis(120);

	int MAX_HIT_CANDIDATES = 20;
	int MIN_HIT_SCORE_THRESHOLD = 1;	
	
	public static GenderEnum searchGender = GenderEnum.M;
	public static Integer searchYob = 1977;
	public static Integer searchYobRange = 10;
	public static char searchRace = 'B';
	public static String searchRegionFlags = "32";
	public static String searchUserFlags = "face17TR";
	
	Random rnd = new Random();

	@Test
	public void testBuildSeachJobRequest() throws JAXBException {
		for (int i = 0; i < jobCount; i++) {
			SearchJobRequestDto searchRq =  buildSeachJobRequest();
			JaxBUtil<SearchJobRequestDto> jaxb = new JaxBUtil<SearchJobRequestDto>();
			String outputFileName = "search_template" + "_" + FunctionId + "_" + priority + "_" + i + ".xml";
			String outputFullName = outputDir + outputFileName;
			jaxb.marshalToFile(SearchJobRequestDto.class, searchRq, outputFullName);
			System.out.println("OKOKOK");
		}
	}


	public SearchJobRequestDto buildSeachJobRequest() {		
		SearchJobRequestDto searchJobRequestDto = new SearchJobRequestDto();	
		String callbackUrl = "http://" + "192.168.22.118" + ":" + "5679";
		searchJobRequestDto.setCallbackUrl(callbackUrl);		
		ObjectFactory objectFactory = new ObjectFactory();		
		JAXBElement<Integer> rqPriority = objectFactory.createSearchJobRequestDtoPriority(priority);		
		searchJobRequestDto.setPriority(rqPriority);
		searchJobRequestDto.setJobTimeoutMill(jobTimeoutMilli);
		searchJobRequestDto.setJobMode("live");
		JAXBElement<String> functionId = objectFactory.createSearchJobRequestDtoSearchFunctionId(FunctionId);
		searchJobRequestDto.setSearchFunctionId(functionId);
		SearchRequestItemDto searchRequestItemDto = new SearchRequestItemDto();
		searchRequestItemDto.setSearchItemPayloadDto(buildSearchItemInputPayload());
		searchRequestItemDto.getBinIdList().addAll(Arrays.asList(binIds));
		searchJobRequestDto.getSearchRequestItemList().add(searchRequestItemDto);
		return searchJobRequestDto;
	}

	public SearchItemInputPayloadDto buildSearchItemInputPayload() {
		int exteralId = rnd.nextInt();
		int eventId = rnd.nextInt();
		SearchItemInputPayloadDto searchItemInputPayloadDto = new SearchItemInputPayloadDto();
		searchItemInputPayloadDto.setFunctionId(FunctionId);
		searchItemInputPayloadDto.setTemplateType(templateType);
		searchItemInputPayloadDto.setMaxHitCount(MAX_HIT_CANDIDATES);
		searchItemInputPayloadDto.setMinScoreThreshold(MIN_HIT_SCORE_THRESHOLD);		

		SearchOptionsDto searchOption = new SearchOptionsDto();		
		MetaInfoCommon metaInfoCommon = new MetaInfoCommon();
		metaInfoCommon.setGender(searchGender);
		metaInfoCommon.setRace(String.valueOf(searchRace));
		ObjectFactory objectFactory = new ObjectFactory();			
		JAXBElement<Long> jaxLong = objectFactory.createMetaInfoCommonRegionFlags(Long.valueOf(searchRegionFlags));
		metaInfoCommon.setRegionFlags(jaxLong);		
		JAXBElement<String> userFlags = objectFactory.createMetaInfoCommonUserFlags("false");
		metaInfoCommon.setUserFlags(userFlags);		
		JAXBElement<Integer> yob = objectFactory.createMetaInfoCommonYob(searchYob);
		metaInfoCommon.setYob(yob);
		JAXBElement<Integer> yobRange = objectFactory.createMetaInfoCommonYobRange(searchYobRange);
		metaInfoCommon.setYobRange(yobRange);		
		searchOption.setMetaInfoCommon(metaInfoCommon);					
		searchItemInputPayloadDto.setSearchOptions(searchOption);		
		
		BioTemplatePayload bioTemplatePayload = new BioTemplatePayload();
		BioTemplateHeader bioTemplateHeader = new BioTemplateHeader();
		bioTemplateHeader.setExternalId(String.valueOf(exteralId));
		bioTemplateHeader.setGender(searchGender);
		bioTemplateHeader.setRace((byte)searchRace);
		bioTemplateHeader.setRegionFlags( searchRegionFlags.getBytes());
		bioTemplateHeader.setUserFlags(searchUserFlags.getBytes());
		bioTemplateHeader.setYob(searchYob.shortValue());
		bioTemplatePayload.setTemplateHeader(bioTemplateHeader);
		
		BioType1Event bioEvent = new BioType1Event();
		bioEvent.setEventId(String.valueOf(eventId));
		bioEvent.setQuality(60);
		FileUtil fu = new FileUtil();
		 byte[] face17Data =
		 fu.getDataFromFile("/C:/Users/000001A006PBP/Desktop/test/FACE_NEC_S17_FRONTAL_FACE.dat");
		 bioEvent.setFaceS17FeatureData(face17Data);	
			
		bioTemplatePayload.getEvents().add(bioEvent);		
		searchItemInputPayloadDto.setTemplatePayload(bioTemplatePayload);	
		return searchItemInputPayloadDto;
	}	

}
