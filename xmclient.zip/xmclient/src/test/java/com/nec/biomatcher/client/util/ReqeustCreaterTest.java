package com.nec.biomatcher.client.util;

import java.io.File;
import java.net.URL;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.nec.biomatcher.client.request.creater.SearchJobReqeustCreater;
import com.nec.biomatcher.webservices.SearchJobRequestDto;
import com.nec.biomatcher.webservices.SearchJobResultDto;
import com.nec.biomatcher.webservices.SyncJobRequestDto;


public class ReqeustCreaterTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testBuildSeachJobRequest() {
		SearchJobReqeustCreater creater = new SearchJobReqeustCreater();
		SearchJobRequestDto request = creater.buildSeachJobRequest("requestdata/searchRequst.xml");
		try {
			JAXBContext jaxbContext = JAXBContext.newInstance(SearchJobResultDto.class);
			Marshaller marshal = jaxbContext.createMarshaller();
			marshal.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			marshal.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
			marshal.setProperty(Marshaller.JAXB_FRAGMENT, false);
			marshal.marshal(request, new File("D:/req15.xml"));

		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("OKOK");
	}
	
	@Test
	public void StringRead() {
		String testString = "abcefghijklmnmopqrslurvxyz1234567910abcdef";
		byte[] buffer = new byte[4096];
		byte[] tmp = testString.getBytes();
		for (int i = 0; i < tmp.length; i++) {
			buffer[i] =tmp[i];
		}
		String target = new String(buffer);
		target = target.trim();
		Assert.assertEquals(testString, target);				
	}
	
	@Test
	public void testMuiltInsertReqCreater() throws JAXBException {
		URL url = Thread.currentThread().getContextClassLoader().getResource("templatesdata");
		String path = url.getPath();		
		String[] fullNames = new String[]{path + "/TEMPLATE_TYPE_1.dat ",path +"/TEMPLATE_TYPE_35_0.dat"};
		SyncInsertJobMuitRequestCreater creater = new SyncInsertJobMuitRequestCreater();
		SyncJobRequestDto insertReq = creater.buildSyncInsertRequest(fullNames);
		JaxBUtil<SyncJobRequestDto> jaxb = new JaxBUtil<SyncJobRequestDto>();
		jaxb.marshalToFile(SyncJobRequestDto.class, insertReq, "/C:/Users/xia/Desktop/insert_request_2.xml");
	}

}
