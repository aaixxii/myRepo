package com.nec.biomatcher.client.request.creater;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import javax.xml.bind.JAXBException;

import org.junit.Test;

import com.nec.biomatcher.client.util.FileUtil;
import com.nec.biomatcher.client.util.JaxBUtil;
import com.nec.biomatcher.webservices.BioTemplateHeader;
import com.nec.biomatcher.webservices.BioTemplatePayload;
import com.nec.biomatcher.webservices.BioType11Event;
import com.nec.biomatcher.webservices.BiometricEventSyncTypeDto;
import com.nec.biomatcher.webservices.GenderEnum;
import com.nec.biomatcher.webservices.InsertBiometricEventDto;
import com.nec.biomatcher.webservices.InsertTemplateInfo;
import com.nec.biomatcher.webservices.SyncJobRequestDto;

public class SyncInsertJobIIRequestCreaterTest {

	Random rnd = new Random();

	public static GenderEnum gender = GenderEnum.M;
	public static Integer yob = 1977;
	public static char race = 'B';
	public static String regionFlags = "32";
	public static String userFlag = "iris1234";

	String templateType = "TEMPLATE_TYPE_11";
	long jobTimeoutMilli = TimeUnit.SECONDS.toMillis(120);

	int MAX_HIT_CANDIDATES = 20;
	int MIN_HIT_SCORE_THRESHOLD = 1;

	private static final Integer binId = 11;

	@Test
	public void testBuildSyncUpdateRequest() throws JAXBException {
		SyncJobRequestDto insertRequest = buildSyncInsertRequest();
		JaxBUtil<SyncJobRequestDto> jaxb = new JaxBUtil<SyncJobRequestDto>();
		 jaxb.marshalToFile(SyncJobRequestDto.class, insertRequest,
		 "/C:/Users/000001A006PBP/Desktop/test/sync_insert_request_new_II.xml");		
		System.out.println("OKOKOK");
	}

	public SyncJobRequestDto buildSyncInsertRequest() {
		String callbackIp = "192.168.22.118";
		String callbackPort = "5679";
		String callbackUrl = "http://" + callbackIp + ":" + callbackPort;
		SyncJobRequestDto syncJobRequestDto = new SyncJobRequestDto();
		syncJobRequestDto.setCallbackUrl(callbackUrl);
		syncJobRequestDto.setJobMode("strict");
		syncJobRequestDto.setJobTimeoutMill(jobTimeoutMilli);
		List<BiometricEventSyncTypeDto> syncList = new ArrayList<>();
		syncList.add(buildInsertBiometricEventDto());
		syncJobRequestDto.getEventSyncDtoList().addAll(syncList);
		return syncJobRequestDto;
	}

	private InsertBiometricEventDto buildInsertBiometricEventDto() {
		InsertBiometricEventDto insertBiometricEventDto = new InsertBiometricEventDto();
		int exteralId = rnd.nextInt();
		int eventId = rnd.nextInt();
		insertBiometricEventDto.setExternalId(String.valueOf(exteralId));
		insertBiometricEventDto.setEventId(String.valueOf(eventId));
		insertBiometricEventDto.setUpdateFlag(true);

		InsertTemplateInfo insertTemplate = new InsertTemplateInfo();
		insertTemplate.setBinId(binId);
		insertTemplate.setTemplateType(templateType);
		
		BioTemplatePayload bioTemplatePayload = new BioTemplatePayload();
		BioTemplateHeader bioTemplateHeader = new BioTemplateHeader();
		bioTemplateHeader.setExternalId(String.valueOf(exteralId));
		bioTemplateHeader.setGender(gender);
		bioTemplateHeader.setRace((byte) race);
		bioTemplateHeader.setRegionFlags(regionFlags.getBytes());
		bioTemplateHeader.setUserFlags(userFlag.getBytes());
		bioTemplateHeader.setYob(yob.shortValue());
		bioTemplatePayload.setTemplateHeader(bioTemplateHeader);
		
		BioType11Event bioEvent = new BioType11Event();
		bioEvent.setEventId(String.valueOf(eventId));
		FileUtil fu = new FileUtil();
		 byte[] leftData =
		 fu.getDataFromFile("/C:/Users/000001A006PBP/Desktop/test/IRIS_NEC_LEFT_IRIS.dat");		
		bioEvent.setIrisLeftNecFeatureData(leftData);
		 byte[] rightData =
		 fu.getDataFromFile("/C:/Users/000001A006PBP/Desktop/test/IRIS_NEC_RIGHT_IRIS.dat");		
		bioEvent.setIrisRightNecFeatureData(rightData);
		bioEvent.setIrisLeftQuality(50);
		bioEvent.setIrisRightQuality(60);
		
		bioTemplatePayload.getEvents().add(bioEvent);
		insertTemplate.setTemplatePayload(bioTemplatePayload);
		insertBiometricEventDto.getInsertTemplateInfoList().add(insertTemplate);
		fu = null;
		return insertBiometricEventDto;
	}
}
