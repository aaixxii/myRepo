package com.nec.biomatcher.client.request.creater;

import java.net.URL;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;

import org.junit.Test;

import com.nec.biomatcher.client.util.FileUtil;
import com.nec.biomatcher.client.util.JaxBUtil;
import com.nec.biomatcher.webservices.AlgorithmType;
import com.nec.biomatcher.webservices.ExtractInputParameter;
import com.nec.biomatcher.webservices.FaceExtractInputImage;
import com.nec.biomatcher.webservices.FeatureExtractInputImage;
import com.nec.biomatcher.webservices.Image;
import com.nec.biomatcher.webservices.ImageFormat;
import com.nec.biomatcher.webservices.MatchInputParameter;
import com.nec.biomatcher.webservices.Modality;
import com.nec.biomatcher.webservices.ObjectFactory;
import com.nec.biomatcher.webservices.VerifyBiometricData;
import com.nec.biomatcher.webservices.VerifyJobRequestDto;


public class VerifyPriorityJobReqeustCreaterTest {
	
	private static final String outputDir = "/C:/Users/000001A006PBP/Desktop/test/";	
	private static final  Integer priority = 4;
	private static final  Integer jobCount = 10;
	private static final  String FunctionId = "verify";	
	private static final  String dataFile = "requestdata/face0.jpg";

	

	@Test
	public void testBuildVerifyJobRequest() throws JAXBException {
		for (int i = 0; i < jobCount; i++) {
			VerifyJobRequestDto verifyJobRequestDto = new VerifyJobRequestDto();		
			String callbackIp = "192.168.22.118";
			String callbackPort = "5679";
			String callbackUrl = "http://" + callbackIp + ":" + callbackPort;
			verifyJobRequestDto.setCallbackUrl(callbackUrl);
			ObjectFactory objectFactory = new ObjectFactory();
			JAXBElement<Integer> vpriority = objectFactory.createExtractJobRequestDtoPriority(priority);
			verifyJobRequestDto.setPriority(vpriority);
			verifyJobRequestDto.setJobTimeoutMill(3600000L);
			verifyJobRequestDto.setJobMode("live");
			VerifyBiometricData probeBiomericData = buildVerifyBiometricData();
			VerifyBiometricData galleryBiomericData = buildVerifyBiometricData();		
			//JAXBElement<VerifyBiometricData> probe = objectFactory.createVerifyBiometricData(probeBiomericData);	
			verifyJobRequestDto.setProbeBiomericData(probeBiomericData);
			verifyJobRequestDto.getGalleryBiomericDataList().add(galleryBiomericData);
			MatchInputParameter parameter = new MatchInputParameter();
			parameter.setModality(Modality.FACE);
			parameter.setAlgorithmType(AlgorithmType.FACE_NEC_S_17);			
			verifyJobRequestDto.getMatchInputParameterList().add(parameter);
			JaxBUtil<VerifyJobRequestDto> jaxb = new JaxBUtil<VerifyJobRequestDto>();
			String outputFileName = "verify_request" + FunctionId + "_" + priority + "_" + i + ".xml";
			String outputFullName = outputDir + outputFileName;			
			jaxb.marshalToFile(VerifyJobRequestDto.class, verifyJobRequestDto, outputFullName);
			System.out.println("OKOKOK");
		}

	}
	
	public static VerifyBiometricData buildVerifyBiometricData()  {
		VerifyBiometricData probeBiometricData = new VerifyBiometricData();
		probeBiometricData.setCandidateId("FACE_PROBE_01");
		probeBiometricData.setContainerId(1);
		FaceExtractInputImage feImage = buildFaceExtractInputImage();
		FeatureExtractInputImage featureImage = new FeatureExtractInputImage();
		featureImage.setExtractInputImage(feImage);
		featureImage.getAlgorithmTypes().add(AlgorithmType.FACE_NEC_S_17);
		probeBiometricData.getImageList().add(featureImage);
		return probeBiometricData;
	}
	
	public static FaceExtractInputImage buildFaceExtractInputImage() {
		URL url = Thread.currentThread().getContextClassLoader().getResource(dataFile);
		ExtractInputParameter parameter = new ExtractInputParameter();
		parameter.setAlgorithmType(AlgorithmType.FACE_NEC_S_17);
		parameter.setModality(Modality.FACE);

//		List<BioParameterDto> kvList = new ArrayList<>();
//		kvList.add(new BioParameterDto("MaxEyeDist", "800"));
//		kvList.add(new BioParameterDto("MinEyeDist", "10"));
//		kvList.add(new BioParameterDto("Reliability", "0.6"));
//		kvList.add(new BioParameterDto("Algorithm", "1"));
//		
//		parameter.getParameters().addAll(kvList);
		
		FileUtil fu = new FileUtil();
        byte[] faceImageData = fu.getDataFromFile(url.getPath());
		Image image = new Image();
		image.setData(faceImageData);
		image.setType(ImageFormat.JPEG);

		FaceExtractInputImage faceExtractInputImage = new FaceExtractInputImage();
		faceExtractInputImage.setFaceImage(image);		
		faceExtractInputImage.getExtractionParameters().add(parameter);		
		return faceExtractInputImage;
	}

}
