package com.nec.biomatcher.client.util;

import java.io.FileWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Marshaller;
import javax.xml.namespace.QName;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamWriter;

public class Tester {

	public static void main(String[] args) throws Exception {
		Customer customer = new Customer();
		customer.setId(123);
		customer.setFirstName("Jane");
		customer.setLastName("Doe");
		QName root = new QName("response");
		JAXBElement<Customer> je = new JAXBElement<Customer>(root, Customer.class, customer);

		XMLOutputFactory xof = XMLOutputFactory.newFactory();
		FileWriter w = new FileWriter("D:/test.xml");
		XMLStreamWriter xsw = xof.createXMLStreamWriter(w);
		xsw.writeStartDocument();
		xsw.writeStartElement("S", "Envelope", "http://schemas.xmlsoap.org/soap/envelope/");
		xsw.writeStartElement("S", "Body", "http://schemas.xmlsoap.org/soap/envelope/");
		xsw.writeStartElement("ns0", "findCustomerResponse", "http://service.jaxws.blog/");

		JAXBContext jc = JAXBContext.newInstance(Customer.class);
		Marshaller marshaller = jc.createMarshaller();
		marshaller.setProperty(Marshaller.JAXB_FRAGMENT, true);
		marshaller.marshal(je, xsw);

		xsw.writeEndDocument();
		xsw.close();
	}

}
