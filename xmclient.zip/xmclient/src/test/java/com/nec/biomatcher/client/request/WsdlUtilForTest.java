package com.nec.biomatcher.client.request;

import java.net.URL;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;

import com.nec.biomatcher.client.exception.XmClientException;
import com.nec.biomatcher.webservices.BioMatcherWebServiceInterface;

public class WsdlUtilForTest {	
	
	public static final String MEGHA_CONTEXT_NAME = "bio-matcher-webservices/";
	public static final String XM_SERVICE_NAME = "bioMatcherWebservice/";
	public static final String MEGHA_WSDL_PATTEN = "bioMatcherWebService?wsdl";
	public static final String WSDL_URL = "wsdlUrl";
	public static final String NAMESPACE_URL = "http://webservices.biomatcher.nec.com/";

	public static final String XM_SUBMIT_SEARCH_JOB = "submitSearchJob";
	public static final String XM_GET_SEARCH_JOB_STATUS = "getSearchJobStatus";
	public static final String XM_GET_SEARCH_JOB_RESULT = "getSearchJobResult";
	public static final String XM_DELETE_SEARCH_JOB = "deleteSearchJob";

	public static final String SERVER_ID = "serverId";
	public static final String SERVER_PORT = "serverPort";

	public static final String CIRCLE_THREAD_CURRENET_COUNT = "circleThreadCurrentCount";
	public static final String ONE_CIRCLE_JOB_COUNT = "oneCircleJobCount";
	public static final String SEARCH_JOB_TIMEOUT = "searchJobTimeout";	
	public static final String EXTRACTION_JOB_TIMEOUT = "extractJobTimeout";	
	public static final String CLIENT_CALLBACK_PORT = "clientCallbackPort";	
	public static final String CLIENT_CALLBACK_IP = "clientCallbackIP";
	
	public static final String PROPERTY_FULL_NAME = "propertyFullName";	
	public static final String JOB_REQUEST_PATH = "jobReqeustPath";	
	public static final String JOB_RESULT_PATH_XML = "jobresultPathXml";
	public static final String JOB_RESULT_PATH_XLSX = "jobresultPathXlsx";
	public static final String CLINET_CALLBACK_PATH = "clientCallbackPath";
	
	public static final String SEARCH_JOB_START_WITH = "search";
	public static final String EXTRACT_JOB_START_WITH = "extract";
	public static final String VERIFY_JOB_START_WITH = "verify";
	public static final String SYNC_INSERT_START_WITH = "sync_insert";
	public static final String SYNC_DELETE_START_WITH = "sync_delete";
	public static final String SYNC_UPDATE_START_WITH = "sync_update";	
	
	private static String serverId= "10.197.23.100";
	private static String serverPort = "8882";
	
	
	public static final String SLASH = "/";
	
	private static final BioMatcherWebServiceInterface xmWebService = buildXmWebService();
	
	private static BioMatcherWebServiceInterface buildXmWebService() {		
		BioMatcherWebServiceInterface xmWebService = null;
		String wsdlUrl = "http://" + serverId + ":" + serverPort;
		wsdlUrl = wsdlUrl.endsWith("/") ? wsdlUrl : wsdlUrl + "/";
		wsdlUrl = wsdlUrl + MEGHA_CONTEXT_NAME + XM_SERVICE_NAME + MEGHA_WSDL_PATTEN;

		try {			
			URL url = new URL(wsdlUrl);
			QName qname = new QName(NAMESPACE_URL, "bioMatcherWebService");
			Service service = Service.create(url, qname);			
			xmWebService = service.getPort(BioMatcherWebServiceInterface.class);			
		} catch (Exception e) {			
			throw new XmClientException(e.getMessage(), e);
		}
		return xmWebService;
	}	
	public static BioMatcherWebServiceInterface getXmWebService() {
		return xmWebService;
	}
}
