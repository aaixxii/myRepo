package com.nec.biomatcher.client.util;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class ClientUtilTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testCheckIP() {
		ClientUtil cu = new ClientUtil();
		boolean result = cu.checkIP("192.168.22.3");
		Assert.assertTrue(result);		
		Assert.assertFalse(cu.checkIP("s92.168.22.3"));		
		Assert.assertFalse(cu.checkIP("9992.168.22.3"));
		Assert.assertFalse(cu.checkIP("-2.168.22.3"));		
	}
	
	@Test
	public void testXmlFormat() {
		String strXml ="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><searchJobResultDto><jobId>7eaf3b56-c961-452a-9f7c-14c64c6691f0</jobId><status>COMPLETED</status><jobMode>live</jobMode><extractJobResult xsi:nil=\"true\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"/></searchJobResultDto>";
		String test = ClientUtil.getInstance().formatXml(strXml);
		System.out.println( test);			 
	}
	
	@Test
	public void testSpilte() {
		String prirotyJobInfo = "TI:priotity:1:5,TI:priotity:4:5";
		String[] firstArry = prirotyJobInfo.split(",");
		for (int i = 0; i < firstArry.length; i++) {
			String[] secondArry = firstArry[i].split(":");
			for (int j = 0 ; j < secondArry.length; j++) {
				System.out.println(secondArry[j]+ " ");
			}
		}
		
	}
	

}
