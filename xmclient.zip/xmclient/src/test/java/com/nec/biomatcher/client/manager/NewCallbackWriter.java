package com.nec.biomatcher.client.manager;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;

import javax.xml.bind.JAXBException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import com.nec.biomatcher.client.util.JaxBUtil;
import com.nec.biomatcher.webservices.SyncJobResultDto;

public class NewCallbackWriter implements Runnable {
	private Socket socket;
	private String outPath;
	private static Logger logger = LoggerFactory.getLogger("CallbackLogger");

	public NewCallbackWriter(Socket socket, String outPath) {
		this.socket = socket;
		this.outPath = outPath;
	}

	public void writeXmlDataToFile() {
		String stringData = null;
		try {		
			BufferedInputStream bis = new BufferedInputStream(socket.getInputStream());						
			byte[] temp = new byte[4096];
			bis.read(temp);
			stringData = new String(temp, "utf-8");
			stringData = stringData.trim();
			bis.close();
			socket.close();
			temp = null;
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		
		if (stringData == null) {
			logger.warn("Get empty data!");
			return;
		}
		int index = stringData.indexOf("<");
		if (index < 0) {
			logger.warn("The data is incorrcted!");
			return;
		}		
		try {
			System.setProperty("file.encoding", "UTF-8");
			stringData = stringData.substring(index, stringData.length());
			int beginIndex = stringData.indexOf("<jobId>");
			int endIndex = stringData.indexOf("</jobId>");
			String jobId = stringData.substring(beginIndex + 7, endIndex);	
			String outputFullName = outPath + jobId + ".xml";
			JaxBUtil<SyncJobResultDto> jaxb = new JaxBUtil<SyncJobResultDto>();
			SyncJobResultDto syncResult = jaxb.unmarshal(SyncJobResultDto.class, stringData);		
			jaxb.marshalToFile(SyncJobResultDto.class, syncResult, outputFullName);			
			jaxb = null;
		} catch (JAXBException e) {
			logger.error(e.getMessage(), e);
		} 
	}
	
	public void writeResultToFileUsingDom() {
		String stringData = null;
		DataOutputStream dOut = null;
		BufferedInputStream bis = null;
		InputStream in = null;
		FileWriter fileWriter = null;
		try {
			dOut = new DataOutputStream(socket.getOutputStream());
			bis = new BufferedInputStream(socket.getInputStream());
			byte[] temp = new byte[4096];
			bis.read(temp);
			stringData = new String(temp, "utf-8");
			stringData = stringData.trim();

			int index = stringData.indexOf("<");
			System.setProperty("file.encoding", "UTF-8");
			stringData = stringData.substring(index, stringData.length());
			int beginIndex = stringData.indexOf("<jobId>");
			int endIndex = stringData.indexOf("</jobId>");
			String jobId = stringData.substring(beginIndex + 7, endIndex);
			String outputFullName = outPath + jobId + ".xml";

			in = new ByteArrayInputStream(stringData.getBytes("UTF-8"));					
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();			
			Document document = builder.parse(in);
			document.setXmlStandalone(true);  
	    	Transformer tf = TransformerFactory.newInstance().newTransformer();
	    	tf.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
	    	tf.setOutputProperty(OutputKeys.METHOD, "xml");
	    	tf.setOutputProperty(OutputKeys.INDENT, "yes");
	    	tf.setOutputProperty(OutputKeys.STANDALONE, "yes");
	    	tf.setOutputProperty("{http://xml.apache.org/xslt}indent-amount","4");
			DOMSource source = new DOMSource(document);
			File f = new File(outputFullName);
			 fileWriter  = new  FileWriter (f);	
			StreamResult result = new StreamResult(fileWriter);			
			tf.transform(source, result);	
			dOut.writeBytes("HTTP/1.1 200 OK\r\n");
			temp = null;			
			logger.info("Success received syncJob result, jobId={}", jobId);
		} catch (ParserConfigurationException | TransformerException | IOException | SAXException e) {
			logger.error(e.getMessage(), e);
			try {
				dOut.writeBytes("HTTP/1.1 500 Server error!\r\n");
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		} finally {
			try {
				socket.close();
				bis.close();
				dOut.close();
			} catch (IOException e) {
				logger.error(e.getMessage(), e);
			}
		}
	}

	@Override
	public void run() {
		writeResultToFileUsingDom();
		//writeXmlDataToFile();
		//writeResultToFile();
	}
}
