package com.nec.biomatcher.client.request.v3;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;

import org.junit.Test;

import com.nec.biomatcher.client.util.FileUtil;
import com.nec.biomatcher.client.util.JaxBUtil;
import com.nec.biomatcher.webservices.AlgorithmType;
import com.nec.biomatcher.webservices.BioFeType;
import com.nec.biomatcher.webservices.BioFingerFeatureInfo;
import com.nec.biomatcher.webservices.BioParameterDto;
import com.nec.biomatcher.webservices.BioTemplateEvent;
import com.nec.biomatcher.webservices.BioTemplateHeader;
import com.nec.biomatcher.webservices.BioTemplatePayload;
import com.nec.biomatcher.webservices.BioType33Event;
import com.nec.biomatcher.webservices.BiometricEventSyncTypeDto;
import com.nec.biomatcher.webservices.ExtractInputParameter;
import com.nec.biomatcher.webservices.ExtractInputPayloadDto;
import com.nec.biomatcher.webservices.ExtractJobRequestDto;
import com.nec.biomatcher.webservices.FingerExtractInputImage;
import com.nec.biomatcher.webservices.GenderEnum;
import com.nec.biomatcher.webservices.Image;
import com.nec.biomatcher.webservices.ImageFormat;
import com.nec.biomatcher.webservices.ImagePosition;
import com.nec.biomatcher.webservices.InsertBiometricEventDto;
import com.nec.biomatcher.webservices.InsertTemplateInfo;
import com.nec.biomatcher.webservices.Modality;
import com.nec.biomatcher.webservices.ObjectFactory;
import com.nec.biomatcher.webservices.PatternType;
import com.nec.biomatcher.webservices.SyncJobRequestDto;
import com.nec.biomatcher.webservices.TemplateExtractInputImage;

public class SyncInsertType33With42RequestCreaterTest {
	Random rnd = new Random();	
	private static String templateType33 = "TEMPLATE_TYPE_33";
	
	private static String templateType42 = "TEMPLATE_TYPE_42";
	
	private static String[] bioParameterKey = {"RollPrimaryPatterns", "RollReferencePatterns", "SlapPrimaryPatterns", "SlapReferencePatterns", "TenprintImageEnhancement",
			                            "FingerAutoCorrection", "SlapConfidenceThreshold", "SlapHandConfidenceThreshold", "DuplicationCheckScoreThreshold", "SequenceCheckScoreThreshold", "SequenceCheckScoreThresholdLittle"};
	
	private static String[] bioParameterValue = {"WSRLAWWLLL", "L WW   WW ", "RSSLAWWSSS", "   W      ", "SMOOTH,SMOOTH,AGC,HISTOGRAM", "true", "70", "2", "1600", "1600", "1000"};

	
	private static final  String dataFilePath = "/C:/Users/000001A006PBP/Desktop/test/";


	long jobTimeoutMilli = TimeUnit.SECONDS.toMillis(120);

	//int MAX_HIT_CANDIDATES = 20;
	//int MIN_HIT_SCORE_THRESHOLD = 1;
	
	boolean isRolledFlag = true; 
	
	public static final PatternType tp_primaryPatten[] = { PatternType.A, PatternType.T, PatternType.R, PatternType.L, PatternType.W,
			PatternType.S, PatternType.N, PatternType.S, PatternType.S, PatternType.S };
	
	public static final PatternType tp_secondaryPatten[] = { PatternType.A, PatternType.T, PatternType.R, PatternType.L, PatternType.W,
			PatternType.S, PatternType.N, PatternType.S, PatternType.S, PatternType.S };
	
	
	public static final Integer rolled_qualities[] = { 60, 50, 85, 80, 90, 60, 50, 85, 80, 90 };
	
	public static final int rolledFingerFileNumbers[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
	public static final int slapFingerFileNumbers[] = { 11, 12, 40, 41, 42, 43, 44, 45, 46, 47 };

	
	@Test
	public void testBuildSyncUpdateRequest() throws Exception {
		SyncJobRequestDto insertRequest = buildSyncInsertRequest();
		JaxBUtil<SyncJobRequestDto> jaxb = new JaxBUtil<SyncJobRequestDto>();
		 jaxb.marshalToFile(SyncJobRequestDto.class, insertRequest,
		 "/C:/Users/000001A006PBP/Desktop/test/sync_insert_request_33_xia1.xml");		
		System.out.println("OKOKOK");
	}

	public SyncJobRequestDto buildSyncInsertRequest() throws Exception {
		String callbackIp = "192.168.22.118";
		String callbackPort = "5679";
		String callbackUrl = "http://" + callbackIp + ":" + callbackPort;
		SyncJobRequestDto syncJobRequestDto = new SyncJobRequestDto();
		syncJobRequestDto.setCallbackUrl(callbackUrl);
		syncJobRequestDto.setJobMode("strict");
		syncJobRequestDto.setJobTimeoutMill(jobTimeoutMilli);
		
		List<BiometricEventSyncTypeDto> syncList = new ArrayList<>();
		syncList.add(buildInsertBiometricEventDto33());
		syncList.add(buildInsertBiometricEventDto42());
		syncJobRequestDto.getEventSyncDtoList().addAll(syncList);
		return syncJobRequestDto;
	}

	private InsertBiometricEventDto buildInsertBiometricEventDto33() throws Exception {
		InsertBiometricEventDto insertBiometricEventDto33 = new InsertBiometricEventDto();
		int exteralId = rnd.nextInt();	
		exteralId = exteralId > 0 ? exteralId : -1 * exteralId;
		int eventId = rnd.nextInt();
		eventId = eventId > 0 ? eventId : -1 * eventId;
		insertBiometricEventDto33.setExternalId(String.valueOf(exteralId));
		insertBiometricEventDto33.setEventId(String.valueOf(eventId));
		insertBiometricEventDto33.setUpdateFlag(true);
		
		insertBiometricEventDto33.setExtractInputPayloadDto(buildExtractInputPayloadDto());
		InsertTemplateInfo insertTemplateInfo = new InsertTemplateInfo();
		insertTemplateInfo.setBinId(33);
		insertTemplateInfo.setTemplateType(templateType33);
		insertBiometricEventDto33.getInsertTemplateInfoList().add(insertTemplateInfo);
		return insertBiometricEventDto33;
		}

	private ExtractInputPayloadDto buildExtractInputPayloadDto() throws Exception {		
		 ObjectFactory objectFactory = new ObjectFactory();
		ExtractInputPayloadDto extractInput = new ExtractInputPayloadDto();
		JAXBElement<String> candidateId = objectFactory.createExtractInputPayloadDtoCandidateId("ex_test");
		extractInput.setCandidateId(candidateId);	
		
		JAXBElement<String> evetnId = objectFactory.createExtractInputPayloadDtoEventId("event1");
		extractInput.setEventId(evetnId);		
		extractInput.setTemplateExtractInputImageList(buildTemplateExtractInputImageList());     
      return extractInput;	
	}
	
	public static List<TemplateExtractInputImage>  buildTemplateExtractInputImageList() throws Exception {
		List<TemplateExtractInputImage> templateImageList = new ArrayList<>();
		 templateImageList.add(buildTemplateExtractInputImage33());
		 templateImageList.add(buildTemplateExtractInputImage42());
		 return templateImageList;
	}
	
	public static TemplateExtractInputImage buildTemplateExtractInputImage33() throws Exception {	
	TemplateExtractInputImage templateExtractInputImage = new TemplateExtractInputImage();
	templateExtractInputImage.setExtractInputImage(buildTenprintFingerInputImage33());
	templateExtractInputImage.getTemplateTypes().add(templateType33);	
	return templateExtractInputImage;		
	}

	
	public static FingerExtractInputImage buildTenprintFingerInputImage33() throws Exception {
		ImagePosition[] imagePositions = { ImagePosition.ROLL_RINDEX, ImagePosition.ROLL_RINDEX, ImagePosition.ROLL_RINDEX,
				ImagePosition.ROLL_RINDEX };
		
		FileUtil fu = new FileUtil();

		FingerExtractInputImage tenprintFingerInputImage = new FingerExtractInputImage();
		for (int i = 1; i <= 1; i++) {
			byte[] imageData = fu.getDataFromFile("/C:/Users/000001A006PBP/Desktop/test/ROLL_" + i + ".wsq");
			Image image = new Image();
			image.setData(imageData);
			image.setPosition(ImagePosition.ROLL_RINDEX);
			image.setType(ImageFormat.WSQ);
			tenprintFingerInputImage.getImages().add(image);		
		}
		
		ExtractInputParameter extParameter = new ExtractInputParameter();
		extParameter.setAlgorithmType(AlgorithmType.FINGER_FMP_5);
		extParameter.setModality(Modality.FINGER);
		List<BioParameterDto> parameters = new ArrayList<>();
		
		BioParameterDto first = new BioParameterDto();
		first.setKey("FisFeType");
		first.setValue("E");
		parameters.add(first);
		
		for (int i = 0; i < bioParameterKey.length; i++) {
			BioParameterDto bioParameterDto = new BioParameterDto();
			bioParameterDto.setKey(bioParameterKey[i]);
			bioParameterDto.setValue(bioParameterValue[i]);
			parameters.add(bioParameterDto);
		}
		
		extParameter.getParameters().addAll(parameters);
		
		tenprintFingerInputImage.getExtractionParameters().add(extParameter);

		return tenprintFingerInputImage;
	}
	
	private InsertBiometricEventDto buildInsertBiometricEventDto42() throws Exception {
		InsertBiometricEventDto insertBiometricEventDto42 = new InsertBiometricEventDto();
		int exteralId = rnd.nextInt();	
		exteralId = exteralId > 0 ? exteralId : -1 * exteralId;
		int eventId = rnd.nextInt();
		eventId = eventId > 0 ? eventId : -1 * eventId;
		insertBiometricEventDto42.setExternalId(String.valueOf(exteralId));
		insertBiometricEventDto42.setEventId(String.valueOf(eventId));
		insertBiometricEventDto42.setUpdateFlag(true);
		
		insertBiometricEventDto42.setExtractInputPayloadDto(buildExtractInputPayloadDto());
		InsertTemplateInfo insertTemplateInfo = new InsertTemplateInfo();
		insertTemplateInfo.setBinId(42);
		insertTemplateInfo.setTemplateType(templateType42);
		insertBiometricEventDto42.getInsertTemplateInfoList().add(insertTemplateInfo);

		return insertBiometricEventDto42;
		}
	
	public static TemplateExtractInputImage buildTemplateExtractInputImage42() throws Exception {	
	TemplateExtractInputImage templateExtractInputImage = new TemplateExtractInputImage();
	templateExtractInputImage.setExtractInputImage(buildTenprintFingerInputImage42());
	templateExtractInputImage.getTemplateTypes().add(templateType42);	
	return templateExtractInputImage;		
	}
	
	
	public static FingerExtractInputImage buildTenprintFingerInputImage42() throws Exception {
		ImagePosition[] imagePositions = { ImagePosition.UNKNOWN, ImagePosition.ROLL_RTHUMB, ImagePosition.ROLL_RINDEX,
				ImagePosition.ROLL_RMIDDLE };
		
		FileUtil fu = new FileUtil();

		FingerExtractInputImage tenprintFingerInputImage = new FingerExtractInputImage();
		for (int i = 1; i <= 1; i++) {
			byte[] imageData = fu.getDataFromFile("/C:/Users/000001A006PBP/Desktop/test/ROLL_" + i + ".wsq");
			Image image = new Image();
			image.setData(imageData);
			image.setPosition(imagePositions[i]);
			image.setType(ImageFormat.WSQ);
			tenprintFingerInputImage.getImages().add(image);		
		}
		
		ExtractInputParameter extParameter = new ExtractInputParameter();
		extParameter.setAlgorithmType(AlgorithmType.FINGER_PC_2);
		extParameter.setModality(Modality.FINGER);		
		  
		
		List<BioParameterDto> parameters = new ArrayList<>();
		BioParameterDto first = new BioParameterDto();
		first.setKey("FisFeType");
		first.setValue("C");
		parameters.add(first);
		
		for (int i = 0; i < bioParameterKey.length; i++) {
			BioParameterDto bioParameterDto = new BioParameterDto();
			bioParameterDto.setKey(bioParameterKey[i]);
			bioParameterDto.setValue(bioParameterValue[i]);
			parameters.add(bioParameterDto);
		}
		
		extParameter.getParameters().addAll(parameters);
		
		tenprintFingerInputImage.getExtractionParameters().add(extParameter);

		return tenprintFingerInputImage;
	}
	
	
}
