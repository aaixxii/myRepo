﻿
*************************
*****xmclient readme******
*************************

一、構成
├─xmclient
│
├─bin
│      debug.bat
│      debug.sh
│      runclient.bat
│      runclient.sh
│      
│      stopclient.bat
│      
├─callbackpath
│      sample.xml
│      
├─config
│      log4j.properties
│      xm.client.properties
│      
├─jobrequests
│      searchRequest.xml
│      sync_insert_template_type35.xml
│      search_TEMPLATE_TYPE_35_0.dat
│      
├─jobresults
│  ├─xlsx
│  │      sample.xml
│  │      
│  └─xml
│          sample.xml
│          
├─lib
│      commons-codec.jar
│      commons-collections4.jar
│      curvesapi.jar
│      dom4j.jar
│      gson.jar
│      jackson-annotations.jar
│      jackson-core.jar
│      jackson-databind.jar
│      jcl-over-slf4j.jar
│      jul-to-slf4j.jar
│      log4j.jar
│      poi-ooxml-schemas.jar
│      poi-ooxml.jar
│      poi.jar
│      slf4j-api.jar
│      slf4j-log4j12.jar
│      stax-api.jar
│      xmclient.jar
│      xml-apis.jar
│      xmlbeans.jar
│      
└─log

二、構成説明
１、bin配下：起動スクリプト。作っていますが、自分がまだ多く使っていません。
２、callbackpath：CallbackよりのJob結果を格納場所。Callback実装していますが、現在コメントアウトして、出力を抑制しています。
３、config配下：clientの設定
　　a、log4j.properties：変更不要
　　ｂ、xm.client.properties：環境、テストCaseに合わせて修正。
　　　　　MEGHA_WS_IP_ADDRESS=192.168.22.105,192.168.22.110　←MeghaサーバーのIP、複数可能
　　　　　MEGHA_WS_PORT_NUM=8080,8081　←Meghaサーバーのport、複数可能
　　　　　　※1：MEGHA_WS_IP_ADDRESSに設定したIPの数は、MEGHA_WS_PORT_NUMに設定したPortの数とイコールする必要。
　　　　　　※2：IPとPortの対応付けは順番でマッピングするようにしました。上記の例では、
　　　　　　　　　　　192.168.22.105⇒8080
　　　　　　　　　　　192.168.22.110⇒8081
　　　　　　※3：複数のIP（Port）を設定する場合、RandomでひとつのIPを選択するようにしています。　　
　　　　　CLIENT_JOB_TIME_OUT=3600000　←ReqeustFileに設定していないばあい、こちらを参照。
　　　　　ONE_CIRCLE_JOB_COUNT=1000　←シリアル実行Jobの数
　　　　　CIRCLE_THREAD_CURRENET_COUNT=1　←上記シリアル実行のThreadの並列度。
　　　　　CLIENT_CALLBACK_PORT=8888　←Callback用のport
　　　　　CLIENT_CALLBACK_IP=192.168.21.119　←Callback用IP
４、jobrequests配下：
　　Meghaへ投げるRequestFileはこちらに置く。
５、jobresults配下：
　　　　　xml：MeghaからのgetJobResultよりのJob結果をこちらに格納。
　　　　　xlsx：MeghaからのJob結果をExcelに変換してこちらに格納。(実装していますが、現在コメントアウトして、出力を抑制しています。
　　　　　　　　CPS、MIN、Maxも自動計算してフラグをできるかと思っていますが、まだ未実装。
６、lib：xmclient実行用のLib群。

三、xmclientのルール：
　１、ユーザの入力を減らすため、設定Filesは上記ように決めています。
　　　　つまり、設定Files、ReqeustFileは必ず、上記説明したとおりにそれぞれ規定するフォルタに置く。
　　　　これで、xmclientは自動的、自分のJARの所在Pathより、各設定FileのPathを計算しています。
　２、reqeustFileの命名規則：
　　　　a、reqeustFileのタイプは二つがあり：
             　ｘｘｘｘｘ.xml： soap messageからのRequest（今野君からのFile）
	     　ｘｘｘｘｘ.dat: TemplateﾃﾞｰﾀだけのバイナリﾃﾞｰﾀFile。他の必要なパラメータはxmclientでハードコーディングしています。
	 b、reqeustFileもユーザの入力を省くため、以下のルールで、xmclientにて自動的に判断しています：
	 　　SearchJobの場合：「search」でスタート、小文字、大文字とも構いまっせん、
	 　　　　　　　　　　　　　　　例：searchRequest.xml、searchRequest.xml
	 　　SyncJobの登録の場合：「sync_insert」でスタート。例：sync_insert_template_type35.xml
	 ｃ、詳細はソースの XmClientConstants.javaを参照。
　３、ReqeustFileのサンプル：
　　　　sync_insert_template_type35.xml
　　　　sync_insert_TEMPLATE_TYPE_35.dat
　　　　search_TEMPLATE_TYPE_35.xml
　　　　search_template_type35.dat

四、jobrequests配下のReqeustFileの数について、
　　１、RqesutFileは1件である場合、xm.client.propertiesに設定したとおりに実行されます。
　　２、RqesutFileはXXXX件であるばあい、それぞれ一回のみ実行されます。
　　３、searchRequestFiles、syncRequestFiles混同に「jobrequests」配下に置くても構いませんが、
　　　　Job結果はすべて、JobIdをFile名として、「jobresults\xml」に保存されています。
　　　　searchjob結果であるか、InsertJob結果であるか、File名だけ区別はできなくなります。

五、起動コマンド
　　　 ●　cd \\xmclient\lib
　　　 ●　 java -jar xmclient.jar start
          　※：必ずxmclient.jarが所在するディレクトリへcd。
	  　　　JarよりPathを計算するため。　　

六、シャットダウンコマンド　　　
　　　 ●　cd \\xmclient\lib 
　　　 ●　 java -jar xmclient.jar stop	

七、現在はsearchJob、sync insertだけ実装しております。

==以上==











　　



