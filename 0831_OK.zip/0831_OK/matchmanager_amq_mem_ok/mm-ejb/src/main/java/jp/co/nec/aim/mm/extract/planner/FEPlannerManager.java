package jp.co.nec.aim.mm.extract.planner;

import java.sql.SQLException;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.Resource;
import javax.ejb.Asynchronous;
import javax.ejb.ConcurrencyManagement;
import javax.ejb.ConcurrencyManagementType;
import javax.ejb.EJB;
import javax.ejb.Lock;
import javax.ejb.LockType;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.sql.DataSource;
import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.NotSupportedException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;
import javax.transaction.UserTransaction;

import jp.co.nec.aim.mm.dao.FEPlannerDAO;
import jp.co.nec.aim.mm.dao.FEPlannerDAOImpl;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.logger.PerformanceLogger;
import jp.co.nec.aim.mm.notifier.FEplanCreatedEventNotifier;
import jp.co.nec.aim.mm.util.StopWatch;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;

/**
 * Extract plan creator to make extract task for mus.
 * 
 * @author xiazp
 */

@Singleton
@Startup
@Asynchronous
@TransactionManagement(TransactionManagementType.BEAN)
@ConcurrencyManagement(ConcurrencyManagementType.BEAN)
public class FEPlannerManager {
	private static Logger logger = LoggerFactory
			.getLogger(FEPlannerManager.class);

	private AtomicInteger maxMulots;

	@Resource
	private UserTransaction userTransaction;
	private FEPlannerDAO feDao;
	@EJB
	FEplanCreatedEventNotifier notifer;
	@Resource(mappedName = "java:jboss/MySqlDS")
	private DataSource dataSource;
	@PersistenceContext(unitName = "aim-db")
	private EntityManager entityManager;

	public FEPlannerManager() {
	}

	@PostConstruct
	public void fePlannerStartup() {
		feDao = new FEPlannerDAOImpl(dataSource, entityManager);
		maxMulots = new AtomicInteger(feDao.getMaxMuLots());
	}

	@PreDestroy
	public void fePlannerShutdown() {
		feDao = null;
	}

	/**
	 * <pre>
	 * first to get max_mu_lots.
	 * second to pickup one mu for assign extract jobs.
	 * then assign extract job to this mu.
	 * </pre>
	 * 
	 * @throws PersistenceException
	 * 
	 * @author xiazp
	 */
	@Lock(LockType.WRITE)
	public void makeFEPlans() {
		logger.debug("FEPlanner prepare to making extract job plans...");
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();

		if (maxMulots.intValue() <= 0) {
			String error = "The maxMulots is incorrect,it's less zero!";
			throw new AimRuntimeException(error);
		}
		// String transactionTimeOut = ConfigProperties.getInstance()
		// .getPropertyValue(
		// ConfigPropertyNames.FE_PLANNER_TRANSACTION_TIMEOUT);
		AtomicLong feLotJobId = new AtomicLong(-999L);
		AtomicBoolean mustFinish = new AtomicBoolean(false);
		MuRemainLots muRemainLot = new MuRemainLots();
		try {
			while (!mustFinish.get()) {
				// userTransaction.setTransactionTimeout(Integer.valueOf(
				// transactionTimeOut).intValue());
				userTransaction.begin();
				feDao.lockForFePlanner();
				muRemainLot = feDao.getfirstMuRemainLots(maxMulots.intValue());

				if (muRemainLot != null) {
					logger.debug("Extract remain lot job information:"
							+ muRemainLot.toString());
				}

				// muRemainLot =
				// feDao.lockAndGetfirstMuRemainLots(maxMulots.intValue());
				if (muRemainLot == null
						|| muRemainLot.getMuId().intValue() <= 0
						|| muRemainLot.getRemainLots() <= 0
						|| muRemainLot.getNumOfExtractor() <= 0) {
					logger.warn("There are no MUs which remain lots are larger than 1. Skip feJob Planning.");
					mustFinish.set(true);
					userTransaction.rollback();
					return;
				} else {
					Long results = feDao.processOneMuLot(muRemainLot);
					if (results == null || results.longValue() <= 0l) {
						logger.warn("No more feJob to assigning for mus!");
						mustFinish.set(true);
						userTransaction.rollback();
						return;
					}
					feLotJobId = new AtomicLong(results.longValue());
					if (feDao.getCurretMuLots(muRemainLot.getMuId()).intValue() > maxMulots
							.intValue()) {
						logger.warn(
								"Mu(ID={}) pressure({}) is larger than maxMuLot({})",
								muRemainLot.getMuId(),
								muRemainLot.getCureentLots(),
								maxMulots.intValue());
						feDao.setPressureToMaxLot(muRemainLot.getMuId(),
								new Long(maxMulots.longValue()));
					}
					logger.info(
							"FEPlanner success assigned feLotJob:{} to mu:{}",
							feLotJobId, muRemainLot.getMuId());
					userTransaction.commit();
					if (notifer.notify(feLotJobId.get())) {
						logger.info(
								"FePlanner success to send feLotJobId({}) to feDispatchQueue",
								feLotJobId.longValue());
					} else {
						logger.warn(
								"FePlanner failed to send feLotJobId({}) to feDispatchQueue",
								feLotJobId.longValue());
						feDao.rollbackFeLotJobRelated(feLotJobId.longValue(),
								muRemainLot.getMuId());
					}
				}
				stopWatch.stop();
				PerformanceLogger.log(getClass().getSimpleName(),
						"makeFEPlans", stopWatch.elapsedTime());
			}
		} catch (NotSupportedException | SystemException | SecurityException
				| IllegalStateException | RollbackException
				| NumberFormatException | HeuristicMixedException
				| HeuristicRollbackException | DataAccessException
				| SQLException e) {
			logger.error(e.getMessage(), e);
			logger.error("Transaction rollbacked due to exception:"
					+ e.getClass().getName());
			mustFinish.set(true);
			try {
				userTransaction.rollback();
			} catch (IllegalStateException | SecurityException
					| SystemException e1) {
				logger.error(e.getMessage(), e);
			}
		}
		logger.info("FEPlanner will be stop.");
		return;
	}
}
