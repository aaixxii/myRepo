package com.nec.aim.uid.zkpdm.segmenter;

import java.util.concurrent.ExecutionException;

import javax.annotation.PostConstruct;

import org.apache.zookeeper.CreateMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.google.protobuf.InvalidProtocolBufferException;
import com.nec.aim.uid.zkpdm.curator.CuratorPathCacher;

import jp.co.nec.aim.message.proto.AIMEnumTypes.SegmentSyncCommandType;
import jp.co.nec.aim.message.proto.AIMMessages.PBDmSyncRequest;
import lombok.extern.slf4j.Slf4j;

@Service
@Scope("prototype")
@Slf4j
public class SegmentOperationHandler {
	
	@Autowired	
	CuratorPathCacher curatorPathCacher;
	
	
	

	@PostConstruct
	public void init() {
	}	

	public Boolean handerRequest(PBDmSyncRequest dmSegRequest)
			throws InvalidProtocolBufferException, InterruptedException, ExecutionException {
		PBDmSyncRequest dmSegReq = PBDmSyncRequest.parseFrom(dmSegRequest.toByteString());
		String changeType = dmSegReq.getCmd().name().toUpperCase();
		long segId = dmSegReq.getTargetSegments().getId();
 		boolean resulst = false;
		if (changeType.equals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT.name())) {
			if (!curatorPathCacher.isExistNode(String.valueOf(segId))) {
				try {
					curatorPathCacher.init(segId);
					resulst = curatorPathCacher.createNode(CreateMode.PERSISTENT_SEQUENTIAL, String.valueOf(segId), dmSegReq.toByteArray());
				} catch (Exception e) {
					log.error(e.getMessage(), e);
					resulst = false;
				}				
			} else {
				if (changeType.equals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_DELETE.name())) {
					resulst = curatorPathCacher.deleteNode(String.valueOf(segId));
				} else {
					resulst = curatorPathCacher.createNode(CreateMode.PERSISTENT_SEQUENTIAL, String.valueOf(segId), dmSegReq.toByteArray());
				}
			}					
		} 
		return Boolean.valueOf(resulst);
	}
}




