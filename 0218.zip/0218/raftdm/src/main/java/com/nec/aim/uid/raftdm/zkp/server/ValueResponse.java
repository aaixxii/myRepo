package com.nec.aim.uid.raftdm.zkp.server;

import java.io.Serializable;

public class ValueResponse implements Serializable {

    private static final long serialVersionUID = -4220017686727146773L;

    private boolean segProcessResult;
    private boolean success;

    /**
     * redirect peer id
     */
    private String redirect;

    private String errorMsg;

    public String getErrorMsg() {
        return this.errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }

    public String getRedirect() {
        return this.redirect;
    }

    public void setRedirect(String redirect) {
        this.redirect = redirect;
    }

    public boolean isSuccess() {
        return this.success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }      

    public boolean isSegProcessResult() {
		return segProcessResult;
	}

	public void setSegProcessResult(boolean segProcessResult) {
		this.segProcessResult = segProcessResult;
	}

	public ValueResponse(boolean segOprValue, boolean success, String redirect, String errorMsg) {
        super();
        this.segProcessResult = segOprValue;
        this.success = success;
        this.redirect = redirect;
        this.errorMsg = errorMsg;
    }

    public ValueResponse() {
        super();
    }

    @Override
    public String toString() {
        return "ValueResponse [segmentProccessResult=" + this.segProcessResult + ", success=" + this.success + ", redirect=" + this.redirect
               + ", errorMsg=" + this.errorMsg + "]";
    }

}
