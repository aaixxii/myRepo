package com.nec.aim.uid.raftdm.zkp.server;

import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alipay.sofa.jraft.Closure;
import com.alipay.sofa.jraft.Iterator;
import com.alipay.sofa.jraft.Status;
import com.alipay.sofa.jraft.core.StateMachineAdapter;
import com.alipay.sofa.jraft.error.RaftError;
import com.alipay.sofa.jraft.error.RaftException;
import com.alipay.sofa.jraft.storage.snapshot.SnapshotReader;
import com.alipay.sofa.jraft.storage.snapshot.SnapshotWriter;
import com.alipay.sofa.jraft.util.Utils;
import com.google.protobuf.InvalidProtocolBufferException;
import com.nec.aim.uid.raftdm.segmenter.SegmentOperater;

import jp.co.nec.aim.message.proto.AIMMessages.PBDmSyncRequest;

public class SegmentSTatusMachine extends StateMachineAdapter {
	
	private static final Logger logger = LoggerFactory.getLogger(SegmentSTatusMachine.class);
	
	 private final AtomicBoolean resultValue  = new  AtomicBoolean(false);  
	private final AtomicLong leaderTerm = new AtomicLong(-1);
	private  String parent = "/SEGMENTS";
	
	  public boolean isLeader() {
	        return this.leaderTerm.get() > 0;
	    }
	  
	  public boolean getValue() {
	        return this.resultValue.get();
	    }

	  @Override
	    public void onApply(Iterator iter) {	        
	        while (iter.hasNext()) {
	            PBDmSyncRequest dmSyncRequest = null;
	            SegmentOprClosure segClosure = null;	           
	            if (iter.done() != null) {	                
	            	segClosure = (SegmentOprClosure) iter.done();
	            	dmSyncRequest = segClosure.getRequest();
	            } else {	                
	                ByteBuffer data = iter.getData();
	                try {  
	                	dmSyncRequest = HessianSerializer.unmarshal(data.array());
	                	//dmSyncRequest = PBDmSyncRequest.parseFrom(data.array()); 	  
	                } catch (Exception e) {
	                	logger.error("Fail to decode IncrementAndGetRequest", e);
	                }
	            }             	 
            	 long segId = dmSyncRequest.getTargetSegments().getId();	                	 
            	 SegmentOperater segmentOperater = SegmentOperater.getInstance();
            	 segmentOperater.init(parent, segId);            	
				try {
					 boolean realResult = segmentOperater.handerRequest(dmSyncRequest);
					resultValue.getAndSet(realResult);
				} catch (InvalidProtocolBufferException | InterruptedException | ExecutionException e) {
					logger.error(e.getMessage(), e);
				}            	 
	            if (segClosure != null) {
	            	segClosure.getResponse().setSegProcessResult(resultValue.get());
	            	segClosure.getResponse().setSuccess(true);	               
	            	segClosure.run(Status.OK());
	            }
	            logger.info("The result is {} fro The item:{}" , resultValue,  iter.getIndex());
	            iter.next();
	        }
	    }

	    @Override
	    public void onSnapshotSave(final SnapshotWriter writer, final Closure done) {
	        final boolean currVal = this.resultValue.get();
	        Utils.runInThread(() -> {
	            final SegmentOprSnapshotFile snapshot = new SegmentOprSnapshotFile(writer.getPath() + File.separator + "data");
	            if (snapshot.save(currVal)) {
	                if (writer.addFile("data")) {
	                    done.run(Status.OK());
	                } else {
	                    done.run(new Status(RaftError.EIO, "Fail to add file to writer"));
	                }
	            } else {
	                done.run(new Status(RaftError.EIO, "Fail to save counter snapshot %s", snapshot.getPath()));
	            }
	        });
	    }

	    @Override
	    public void onError(final RaftException e) {
	    	logger.error("Raft error: %s", e, e);
	    }

	    @Override
	    public boolean onSnapshotLoad(final SnapshotReader reader) {
	        if (isLeader()) {
	        	logger.warn("Leader is not supposed to load snapshot");
	            return false;
	        }
	        if (reader.getFileMeta("data") == null) {
	        	logger.error("Fail to find data file in {}", reader.getPath());
	            return false;
	        }
	        final SegmentOprSnapshotFile snapshot = new SegmentOprSnapshotFile(reader.getPath() + File.separator + "data");
	        try {
	            this.resultValue.set(snapshot.load());
	            return true;
	        } catch (final IOException e) {
	        	logger.error("Fail to load snapshot from {}", snapshot.getPath());
	            return false;
	        }
	    }

	    @Override
	    public void onLeaderStart(final long term) {
	        this.leaderTerm.set(term);
	        super.onLeaderStart(term);

	    }

	    @Override
	    public void onLeaderStop(final Status status) {
	        this.leaderTerm.set(-1);
	        super.onLeaderStop(status);
	    }


}
