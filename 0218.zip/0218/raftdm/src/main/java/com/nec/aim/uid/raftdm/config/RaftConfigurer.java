package com.nec.aim.uid.raftdm.config;

import java.io.IOException;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import com.alipay.sofa.jraft.entity.PeerId;
import com.alipay.sofa.jraft.option.NodeOptions;
import com.nec.aim.uid.raftdm.zkp.server.RaftServer;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Configuration
@Slf4j
@Data
public class RaftConfigurer implements InitializingBean, DisposableBean{
	@Value("${kafta.datapath}")
    private String datapath; //path for raft(log etc.)
	
	@Value("${raft.cluster.group}")
    private String rafeDmGroup;
	
	@Value("${raft.connection.string}")
    private String conectionString; //like 127.0.0.1:8081 127.0.0.1:8081,127.0.0.1:8082,127.0.0.1:8083
	
	@Value("${raft.first.server}")
    private String initServer; //like 127.0.0.1:8081 
	
	private void startRafteServer() throws IOException {	
	        NodeOptions nodeOptions = new NodeOptions();        
	        nodeOptions.setElectionTimeoutMs(5000);
	        nodeOptions.setDisableCli(false);
	        nodeOptions.setSnapshotIntervalSecs(30);       
	        PeerId serverId = new PeerId();
	        if (!serverId.parse(conectionString)) {
	            throw new IllegalArgumentException("Fail to parse serverId:" + conectionString);
	        }
	        com.alipay.sofa.jraft.conf.Configuration initConf = new com.alipay.sofa.jraft.conf.Configuration();
	        if (!initConf.parse(initServer)) {
	            throw new IllegalArgumentException("Fail to parse initConf:" + initServer);
	        }      
	        nodeOptions.setInitialConf(initConf);	       
	        RaftServer raftServer = new RaftServer(datapath, rafeDmGroup, serverId, nodeOptions);	        
	        log.info("Started counter server at port:"
	                           + raftServer.getNode().getNodeId().getPeerId().getPort());
	}

	@Override
	public void afterPropertiesSet()  {
		try {
			startRafteServer();
		} catch (IOException e) {
			log.error("Faild to start raft server", e);
		}		
	}

	@Override
	public void destroy() throws Exception {	
		
	}

}
