package com.nec.aim.uid.raftdm.zkp.server;

import java.nio.ByteBuffer;

import com.alipay.remoting.AsyncContext;
import com.alipay.remoting.BizContext;
import com.alipay.remoting.exception.CodecException;
import com.alipay.remoting.rpc.protocol.AsyncUserProcessor;
import com.alipay.sofa.jraft.Closure;
import com.alipay.sofa.jraft.Status;
import com.alipay.sofa.jraft.entity.Task;

import jp.co.nec.aim.message.proto.AIMMessages.PBDmSyncRequest;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DmSyncRequestProcessor  extends AsyncUserProcessor<PBDmSyncRequest> {
	
	private RaftServer rateServer;	
	  public DmSyncRequestProcessor(RaftServer dmServer) {
	        super();
	        this.rateServer = dmServer;
	    }

	@Override
	public void handleRequest(BizContext bizCtx, AsyncContext asyncCtx, PBDmSyncRequest request) {
		  if (!rateServer.getFsm().isLeader()) {
	            asyncCtx.sendResponse(rateServer.redirect());
	            return;
	        }		  
		  ValueResponse response = new ValueResponse();
		  Closure closure = new Closure() {
			@Override
			public void run(Status status) {	            
                if (!status.isOk()) {                    
                	 response.setErrorMsg(status.getErrorMsg());
                     response.setSuccess(false);
                }               
                asyncCtx.sendResponse(response);
            }			  
		  };
		  
		  SegmentOprClosure segClosure = new SegmentOprClosure(rateServer, request, response, closure) ;		  
	       try {	            
	            Task task = new Task();
	            task.setDone(segClosure); 
	            task.setData(ByteBuffer.wrap(HessianSerializer.marshal(request)));
	            rateServer.getNode().apply(task);
	        } catch (CodecException e) {	          
	            log.error("Fail to encode PBDmSyncRequest", e);
	            ValueResponse responseObject = response;
	            responseObject.setSuccess(false);
	            responseObject.setErrorMsg(e.getMessage());
	            asyncCtx.sendResponse(responseObject);
	        }
	    }

	 @Override
	    public String interest() {
	        return PBDmSyncRequest.class.getName();
	    }

}
