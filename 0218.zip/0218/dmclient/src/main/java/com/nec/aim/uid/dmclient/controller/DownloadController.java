package com.nec.aim.uid.dmclient.controller;

import static com.nec.aim.uid.dmclient.segment.DmConstants.SEG_FILE_EXTENSION;

import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;



import lombok.extern.slf4j.Slf4j;


@Controller
@Slf4j
public class DownloadController extends HttpServlet {
	
	
	private static final long serialVersionUID = -5673372086651421607L;

	@SuppressWarnings("unused")
	@Autowired
	private ServletContext servletContext;

	@GetMapping("/segs/")	
	public void downloadSegment(HttpServletRequest req, HttpServletResponse res) throws IOException {
	
		
	}
}
