package com.nec.aim.uid.dmclient.rpc;

import java.util.Objects;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.alipay.remoting.InvokeCallback;
import com.alipay.remoting.exception.RemotingException;
import com.alipay.sofa.jraft.RouteTable;
import com.alipay.sofa.jraft.conf.Configuration;
import com.alipay.sofa.jraft.entity.PeerId;
import com.alipay.sofa.jraft.option.CliOptions;
import com.alipay.sofa.jraft.rpc.impl.cli.BoltCliClientService;
import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;
import com.nec.aim.uid.dmclient.segment.SegmentInfo;
import com.nec.aim.uid.dmclient.segment.SegmentManager;

import jp.co.nec.aim.message.proto.AIMEnumTypes.SegmentSyncCommandType;
import jp.co.nec.aim.message.proto.AIMMessages.PBDmSyncRequest;
import jp.co.nec.aim.message.proto.AIMMessages.PBTargetSegmentVersion;
import jp.co.nec.aim.message.proto.BusinessMessage.PBTemplateInfo;
import lombok.extern.slf4j.Slf4j;

@Service
@Scope("prototype")
@Slf4j
public class RafeDmSyncRequestSender {
	
	@Value("${raft.cluster.group}")
    private String rafeDmGroup;
	
	@Value("${raft.connection.string}")
    private String conectionString; //like 127.0.0.1:8081 127.0.0.1:8081,127.0.0.1:8082,127.0.0.1:8083
	
	   @PostConstruct
	   public void init() throws Exception {     
	        final String groupId = rafeDmGroup;
	        final String confStr = conectionString;

	        final Configuration conf = new Configuration();
	        if (!conf.parse(confStr)) {
	            throw new IllegalArgumentException("Fail to parse conf:" + confStr);
	        }

	        RouteTable.getInstance().updateConfiguration(groupId, conf);

	        final BoltCliClientService cliClientService = new BoltCliClientService();
	        cliClientService.init(new CliOptions());

	        if (!RouteTable.getInstance().refreshLeader(cliClientService, groupId, 1000).isOk()) {
	            throw new IllegalStateException("Refresh leader failed");
	        }

	        final PeerId leader = RouteTable.getInstance().selectLeader(groupId);
	        System.out.println("Leader is " + leader);
	        final int n = 1;
	        final CountDownLatch latch = new CountDownLatch(n);
	        final long start = System.currentTimeMillis();
	        for (int i = 0; i < n; i++) {
	        	sendDmSyncInsertRequest(cliClientService, leader, i, latch);
	        }
	        latch.await();
	        System.out.println(n + " ops, cost : " + (System.currentTimeMillis() - start) + " ms.");
	        System.exit(0);
	    }
	   
	   @PreDestroy
	   public void stop() {
		   
	   }
	   
		public Boolean handerRequest(PBDmSyncRequest dmSegReq)
				throws InvalidProtocolBufferException, InterruptedException, ExecutionException {
			//PBDmSyncRequest dmSegReq = PBDmSyncRequest.parseFrom(dmSegRequest.toByteString());
			String changeType = dmSegReq.getCmd().name().toUpperCase();
			long bioId = dmSegReq.getBioId();
			PBTemplateInfo templateInfo = dmSegReq.getTemplateData();
				String externalId = null;
	  			byte[] templateData = null;
	  			if (templateInfo.hasReferenceId()) {
	  				externalId = templateInfo.getReferenceId();
	  			}
	  			if (templateInfo.hasData()) {
	  				templateData = templateInfo.getData().toByteArray();
	  			} 
			long segId = dmSegReq.getTargetSegments().getId();
			long segVer = dmSegReq.getTargetSegments().getVersion();
			if (Objects.isNull(templateData) || templateData.length < 0) {
				log.warn("Received empty template data!!");
				return false;
			}
			boolean resulst = false;
			SegmentInfo segInfo = SegmentManager.getSegmentInfo(segId);
			if (changeType.equals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT.name())) {
				if (Objects.isNull(segInfo)) {
					//resulst = newSegment(templateData, bioId, externalId, segVer);
				} else {
					//resulst = updateSegment(segInfo, templateData, bioId, externalId, segVer);
				}
			} else if (changeType.equals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_DELETE.name())) {
				if (Objects.isNull(segInfo)) {
					log.warn("can't found segment data for sementId={}", segId);
					resulst = false;
				} else {
					try {
						//resulst = deleteTemplate(segInfo, bioId, externalId);
					} catch (Exception e) {
						log.error(e.getMessage(), e);
						resulst = false;
					}
				}
			}
			return Boolean.valueOf(resulst);
		}


	

 
    private static void sendDmSyncInsertRequest(final BoltCliClientService cliClientService, final PeerId leader,
                                        final long delta, CountDownLatch latch) throws RemotingException,
                                                                               InterruptedException {
        final PBDmSyncRequest.Builder request = PBDmSyncRequest.newBuilder();
        request.setCmd(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT);
        request.setBioId(2);
        PBTemplateInfo.Builder templateInfo = PBTemplateInfo.newBuilder();
        templateInfo.setReferenceId("");
        templateInfo.setData(ByteString.copyFrom("test".getBytes()));
        PBTargetSegmentVersion.Builder segVer = PBTargetSegmentVersion.newBuilder();
        segVer.setId(1);
        segVer.setVersion(1000); 
        
        cliClientService.getRpcClient().invokeWithCallback(leader.getEndpoint().toString(), request,
            new InvokeCallback() {
                @Override
                public void onResponse(Object result) {
                    latch.countDown();
                    if (result != null) {
                    	System.out.println("DmSync result:" + result);
                    }                    
                }

                @Override
                public void onException(Throwable e) {
                    e.printStackTrace();
                    latch.countDown();
                }

                @Override
                public Executor getExecutor() {
                    return null;
                }
            }, 5000);
    }

}
