package com.nec.aim.dm.dmservice.entity;

import lombok.Data;

@Data
public class SegmentRefenceStorageInfo {
	 private Integer id;
	 private Integer storageId;
	 private Long segmentId;
	 private Long bioId;	
	 private String externalId;
}
