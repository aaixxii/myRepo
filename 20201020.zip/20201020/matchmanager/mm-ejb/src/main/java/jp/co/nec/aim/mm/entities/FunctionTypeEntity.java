package jp.co.nec.aim.mm.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The persistent class for the FUNCTION_TYPES database table.
 * 
 */
@Entity
@Table(name = "FUNCTION_TYPES")
public class FunctionTypeEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "FUNCTION_ID")
	private int id;

	@Column(name = "CONTAINER_JOB_TIMEOUTS")
	private long containerJobTimeouts;

	@Column(name = "FAMILY_ID")
	private Integer familyId;

	@Column(name = "FUNCTION_NAME")
	private String functionName;

	@Column(name = "INTERNAL_CANDIDATE_SIZE")
	private Integer internalCandidateSize;

	@Column(name = "QUEUE_TYPE")
	@Enumerated(EnumType.ORDINAL)
	private QueueType type;

	@Column(name = "TARGET_FORMAT_ID")
	private Integer targetFormatId;

	@Column(name = "TOP_LEVEL_JOB_TIMEOUTS")
	private long topLevelJobTimeouts;

	public FunctionTypeEntity() {
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public long getContainerJobTimeouts() {
		return containerJobTimeouts;
	}

	public void setContainerJobTimeouts(long containerJobTimeouts) {
		this.containerJobTimeouts = containerJobTimeouts;
	}

	public Integer getFamilyId() {
		return familyId;
	}

	public void setFamilyId(Integer familyId) {
		this.familyId = familyId;
	}

	public String getFunctionName() {
		return functionName;
	}

	public void setFunctionName(String functionName) {
		this.functionName = functionName;
	}

	public Integer getInternalCandidateSize() {
		return internalCandidateSize;
	}

	public void setInternalCandidateSize(Integer internalCandidateSize) {
		this.internalCandidateSize = internalCandidateSize;
	}

	public QueueType getType() {
		return type;
	}

	public void setType(QueueType type) {
		this.type = type;
	}

	public Integer getTargetFormatId() {
		return targetFormatId;
	}

	public void setTargetFormatId(Integer targetFormatId) {
		this.targetFormatId = targetFormatId;
	}

	public long getTopLevelJobTimeouts() {
		return topLevelJobTimeouts;
	}

	public void setTopLevelJobTimeouts(long topLevelJobTimeouts) {
		this.topLevelJobTimeouts = topLevelJobTimeouts;
	}

}