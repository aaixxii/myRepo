package jp.co.nec.aim.mm.sessionbeans;

import java.lang.management.ManagementFactory;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.management.MBeanServer;
import javax.management.MBeanServerInvocationHandler;
import javax.management.ObjectName;

import org.apache.activemq.artemis.api.core.management.QueueControl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.aim.mm.jms.JmsSender;
import jp.co.nec.aim.mm.jms.NotifierEnum;

/**
 * LoadStatusBean <br>
 * 
 * Update MU Load status <br>
 * 
 * @author liuyq
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class SendJMSBean {

	/** log instance **/
	private static Logger log = LoggerFactory.getLogger(SendJMSBean.class);

	public void addMessage() {
		int i = 0;
		while (i++ <= 200) {
			JmsSender.getInstance().sendToSLB(NotifierEnum.ExtractService,
					"test");
		}
	}

	/**
	 * remove JMS message
	 * 
	 * @param queueName
	 */
	public void clearAllMessage() {

		 QueueControl queueControl = null;
		try {
			MBeanServer mBeanServer = ManagementFactory
					.getPlatformMBeanServer();
			// ObjectName on =
			// ObjectNameBuilder.DEFAULT.getJMSServerObjectName();
			// JMSServerControl serverControl = (JMSServerControl)
			// MBeanServerInvocationHandler
			// .newProxyInstance(mBeanServer, on, JMSServerControl.class,
			// false);
			// serverControl.createQueue("liuyqQueue", "/queue/liuyqQueue");

			// ObjectName target = ObjectNameBuilder.DEFAULT
			// .getJMSQueueObjectName("loadbalancerQueue");

//			ObjectName target = new ObjectName(
//					"jboss.as:subsystem=messaging,hornetq-server=default,runtime-queue=jms.queue.liuQueue");
			ObjectName target = new ObjectName("jboss.as:subsystem=messaging-activemq,server=default,runtime-queue=jms.queue.liuQueue");

	 		queueControl = MBeanServerInvocationHandler.newProxyInstance(
					mBeanServer, target, QueueControl.class, false);

			// Object array = queueControl.listMessages("");
			// for (Map<String, Object> itemMap : array) {
			// for (String item : itemMap.keySet()) {
			// log.info("listMessages -> key: {}, value: {} ", item,
			// itemMap.get(item).toString());
			// }
			// }
			// queueControl.pause();
			// queueControl.resetMessageCounter();

			// queueControl.pause();
			//
			// queueControl.sendMessagesToDeadLetterAddress("");

			// int eCount = queueControl.expireMessages("");

			int count = queueControl.removeMessages("");			
			log.info("liuyqQueue Remove Message count: {}.",
					new Object[] { count });

		} catch (Exception e) {
			log.error("exception occurred when clearAllMessage.", e);
		} finally {
			// if (queueControl != null) {
			// try {
			// queueControl.resume();
			// } catch (Exception e) {
			// // TODO Auto-generated catch block
			// e.printStackTrace();
			// }
			// }
		}
	}

	public static void main(String[] args) {
		System.out.println(new SimpleDateFormat("yyyy-MM-dd hh:mm:SS")
				.format(new Date(1427366734707L)));
	}

}
