package jp.co.nec.aim.mm.entities;

public enum UnitState {
	WORKING, EXITED, TIMED_OUT;
}
