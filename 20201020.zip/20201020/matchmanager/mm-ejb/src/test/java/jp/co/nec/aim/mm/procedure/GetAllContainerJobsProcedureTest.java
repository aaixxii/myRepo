package jp.co.nec.aim.mm.procedure;

import static org.junit.Assert.assertEquals;

import java.util.List;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;
import javax.transaction.Transactional;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import jp.co.nec.aim.mm.common.JdbcTemplateHelper;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class GetAllContainerJobsProcedureTest {

	@Resource
	private DataSource ds;

	@PersistenceContext(unitName = "aim-db")
	private EntityManager entityManager;

	@Resource
	private JdbcTemplate jdbcTemplate;
	JdbcTemplateHelper helper = new JdbcTemplateHelper();
	private GetAllContainerJobsProcedure getallcontainerjobs;

	@Before
	public void setUp() throws Exception {
		getallcontainerjobs = new GetAllContainerJobsProcedure(ds);

		helper.deleteInquiryJob(jdbcTemplate);
		helper.scene01(jdbcTemplate);
	}

	@After
	public void tearDown() throws Exception {
		helper.deleteInquiryJob(jdbcTemplate);
	}

	@Test
	public void test_jobId1005() {
		List<String> result = getallcontainerjobs.action(1005);
		assertEquals(80, result.size());
	}

	@Test
	public void test_jobId1006() {
		List<String> result = getallcontainerjobs.action(1006);		
		assertEquals(0, result.size());
	}

	@Test
	public void test_jobId1002() {
		List<String>  result = getallcontainerjobs.action(1002);		
		assertEquals(0, result.size());
	}

}
