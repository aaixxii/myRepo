package jp.co.nec.aim.mm.constants;

public enum FunctionType {
	SEARCH, EXTRACTION, VERIFICATION;
}
