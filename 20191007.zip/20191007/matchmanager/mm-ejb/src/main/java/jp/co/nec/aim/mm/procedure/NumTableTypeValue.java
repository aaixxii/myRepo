package jp.co.nec.aim.mm.procedure;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import jp.co.nec.aim.mm.exception.AimRuntimeException;
import oracle.jdbc.OracleConnection;
import oracle.sql.NUMBER;

import org.springframework.jdbc.core.support.AbstractSqlTypeValue;

import com.google.common.collect.Lists;

/**
 * Class represents NUM_TABLE_TYPE
 * 
 * @author mozj
 * 
 */
public class NumTableTypeValue extends AbstractSqlTypeValue {
	// private static final String ALTER_SESSION_SQL =
	// "alter session set events '60025 trace name context forever'";
	private int[] indexs;
	private static final String NUM_TABLE_TYPE = "NUM_TABLE_TYPE";

	public NumTableTypeValue(int[] indexs) {
		this.indexs = indexs;
	}

	@Override
	protected Object createTypeValue(Connection conn, int sqlType,
			String typeName) throws SQLException {
		OracleConnection oraConn = conn.unwrap(OracleConnection.class);
		try {
			return oraConn.createARRAY(NUM_TABLE_TYPE,
					createNUMBERArray(oraConn));
		} catch (SQLException e) {
			throw new AimRuntimeException(e);
		}

	}

	private NUMBER[] createNUMBERArray(OracleConnection oraConn)
			throws SQLException {
		final List<NUMBER> numbers = Lists
				.newArrayListWithCapacity(indexs.length);
		for (int i = 0; i < indexs.length; i++) {
			numbers.add(oraConn.createNUMBER(indexs[i]));

		}
		return numbers.toArray(new NUMBER[] {});
	}

}
