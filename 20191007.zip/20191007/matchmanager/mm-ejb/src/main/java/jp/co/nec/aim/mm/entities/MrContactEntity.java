package jp.co.nec.aim.mm.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the MR_CONTACTS database table.
 * 
 */
@Entity
@Table(name = "MR_CONTACTS")
@NamedQuery(name = "MrContactEntity.findAll", query = "SELECT m FROM MrContactEntity m")
public class MrContactEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "MR_CONTACTS_MRID_GENERATOR", sequenceName = "MR_CONTACTS", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "MR_CONTACTS_MRID_GENERATOR")
	@Column(name = "MR_ID")
	private long mrId;

	@Column(name = "CONTACT_TS")
	private long contactTs;

	public MrContactEntity() {
	}

	public long getMrId() {
		return this.mrId;
	}

	public void setMrId(long mrId) {
		this.mrId = mrId;
	}

	public long getContactTs() {
		return this.contactTs;
	}

	public void setContactTs(long contactTs) {
		this.contactTs = contactTs;
	}

}