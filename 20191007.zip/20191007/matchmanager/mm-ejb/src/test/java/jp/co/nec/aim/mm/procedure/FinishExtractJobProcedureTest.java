package jp.co.nec.aim.mm.procedure;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;
import javax.transaction.Transactional;

import jp.co.nec.aim.message.proto.AIMMessages.PBMuExtractJobResult;
import jp.co.nec.aim.message.proto.AIMMessages.PBMuExtractJobResultItem;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBusinessMessage;
import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerPrintType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.ImagePositionType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.TemplateFormatType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplate;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplateIndexer;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;
import jp.co.nec.aim.mm.dao.DateDao;
import jp.co.nec.aim.mm.dao.SystemConfigDao;
import jp.co.nec.aim.mm.util.ProtobufCreater;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class FinishExtractJobProcedureTest {
	
	@Resource
	private DataSource dataSource;
	@PersistenceContext(unitName = "aim-db")
	private EntityManager entityManager;
	@Resource
	private JdbcTemplate jdbcTemplate;

	private DateDao dateDao;
	private SystemConfigDao systemconfigdao;
	private long curTime;
	private ProtobufCreater  protobufCreater;

	@Before
	public void setUp() throws Exception {
		clearDB();
		prepareData();
		protobufCreater = new ProtobufCreater ();			
		dateDao = new DateDao(dataSource);
		systemconfigdao = new SystemConfigDao(entityManager);
		systemconfigdao.writeAllMissingProperties(dataSource);
		curTime = dateDao.getCurrentTimeMS();

	}
	
	private void clearDB() {
		jdbcTemplate.execute("delete from MU_EXTRACT_LOAD");
		jdbcTemplate.execute("delete from FE_LOT_JOBS");
		jdbcTemplate.execute("delete from FE_JOB_QUEUE");
		jdbcTemplate.execute("delete from MM_EVENTS");
		jdbcTemplate.execute("delete from MATCH_UNITS");
		jdbcTemplate.execute("delete from SYSTEM_CONFIG");
		jdbcTemplate.execute("commit");
	}


	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testprocedure_nomoral() throws InvalidProtocolBufferException, SQLException {		
		ProtobufCreater create = new ProtobufCreater();
		PBMuExtractJobResult result = create.createPBMuExtractJobResult(1000, 1, 1000);
		PBBusinessMessage psMsg = PBBusinessMessage.parseFrom(result.getResult(0).getResult().toByteArray());
		FinishExtractJobProcedure procedure = new FinishExtractJobProcedure(dataSource);				
		int count = procedure.execute(1000, 1000, result.toByteArray(), "UID",psMsg.toByteArray());	
		assertEquals(1, count);	
	}
	
	@Test
	public void testprocedure_nomoral_no_udate() throws InvalidProtocolBufferException, SQLException {		
		ProtobufCreater create = new ProtobufCreater();
		PBMuExtractJobResult result = create.createPBMuExtractJobResult(1000, 1, 1000);
		PBBusinessMessage psMsg = PBBusinessMessage.parseFrom(result.getResult(0).getResult().toByteArray());
		FinishExtractJobProcedure procedure = new FinishExtractJobProcedure(dataSource);				
		int count = procedure.execute(1000, 1001, result.toByteArray(), "UID",psMsg.toByteArray());	
		assertEquals(0, count);	
	}
	
	
	private void prepareData() {
		jdbcTemplate.update("insert into MATCH_UNITS(MU_ID,UNIQUE_ID,CONTACT_URL,STATE)values(1000,'1000','http://127.0.0.1:65521/1','WORKING')");	
		jdbcTemplate.execute("insert into MU_CONTACTS(MU_ID, CONTACT_TS)"+ " values(" + 1000 + ", " + 333 + ")");				
		jdbcTemplate.update("insert into mu_extract_load(mu_id,pressure,update_ts) values(1000,2,333)");
		jdbcTemplate.update("INSERT INTO fe_lot_jobs (LOT_JOB_ID,MU_ID, ASSIGNED_TS, TIMEOUTS)  VALUES(1,1000,333,0)");
		jdbcTemplate.update("insert into FE_JOB_QUEUE (JOB_ID,LOT_JOB_ID,FUNCTION_ID,REFERENCE_ID,PRIORITY,JOB_STATE,MU_ID,SUBMISSION_TS,CALLBACK_STYLE)"
				    + "values(1000,1,1,'8888',4,1,1000,333,0)");
		
	}

}
