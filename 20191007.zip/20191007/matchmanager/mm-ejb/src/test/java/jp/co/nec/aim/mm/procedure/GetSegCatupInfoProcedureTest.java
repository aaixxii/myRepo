package jp.co.nec.aim.mm.procedure;

import java.net.URL;
import java.util.List;

import javax.annotation.Resource;
import javax.sql.DataSource;
import javax.transaction.Transactional;

import jp.co.nec.aim.message.proto.AIMEnumTypes.SegmentAssignedStateType;
import jp.co.nec.aim.mm.segment.sync.CatchUpInfo;
import jp.co.nec.aim.mm.segment.sync.SegDiffPara;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.google.common.collect.Lists;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class GetSegCatupInfoProcedureTest extends
		AbstractTransactionalJUnit4SpringContextTests {
	@Resource
	private DataSource dataSource;
	@Resource
	private JdbcTemplate jdbcTemplate;

	private GetSegCatupInfoProcedure getSegCatupInfoProcedure;

	@Before
	public void setUp() throws Exception {
		getSegCatupInfoProcedure = new GetSegCatupInfoProcedure(dataSource);
		//jdbcTemplate.update("delete from system_init");
		jdbcTemplate.update("delete from person_biometrics");
		jdbcTemplate.update("delete from segment_change_log");
		jdbcTemplate.update("delete from segments");
		jdbcTemplate.update("commit");

	}

	@After
	public void tearDown() throws Exception {
		//jdbcTemplate.update("delete from system_init");
		jdbcTemplate.update("delete from person_biometrics");
		jdbcTemplate.update("delete from segment_change_log");
		jdbcTemplate.update("delete from segments");
		jdbcTemplate.update("commit");
	}

	@Test
	public void testExcuteMu() {
		URL url = this.getClass().getResource("insert_seg_change_log.sql");
		executeSqlScript("file:///" + url.getPath(), false);
		SegDiffPara segDiffP1 = new SegDiffPara(1, 0, 3,
				SegmentAssignedStateType.SEGMENT_ASSIGNED, 10);
		SegDiffPara segDiffP2 = new SegDiffPara(2, 1, 4,
				SegmentAssignedStateType.SEGMENT_ASSIGNED, 10);
		List<SegDiffPara> segDiffPsDiffParas = Lists.newArrayList();
		segDiffPsDiffParas.add(segDiffP1);
		segDiffPsDiffParas.add(segDiffP2);
		getSegCatupInfoProcedure.getSegDiffParas().addAll(segDiffPsDiffParas);
		getSegCatupInfoProcedure.setUnitType(3);
		List<CatchUpInfo> catchUpInfos = getSegCatupInfoProcedure.execute();
		Assert.assertEquals(6, catchUpInfos.size());
		for (int i = 0; i < catchUpInfos.size(); i++) {
			CatchUpInfo catchUpInfo = catchUpInfos.get(i);
			int segmentId = (int) catchUpInfo.getSegmentId();
			switch (segmentId) {
			case 1:
				if (catchUpInfo.getVersion() == 3) {
					Assert.assertEquals(0, catchUpInfo.getBytesString().size());
				} else {
					Assert.assertEquals(2, catchUpInfo.getBytesString().size());
				}
				Assert.assertTrue(catchUpInfo.getVersion() <= 3
						&& catchUpInfo.getVersion() > 0);
				break;
			case 2:
				if (catchUpInfo.getVersion() == 3) {
					Assert.assertEquals(0, catchUpInfo.getBytesString().size());
					Assert.assertTrue(catchUpInfo.getVersion() <= 4
							&& catchUpInfo.getVersion() > 1);
				}
				break;

			default:
				break;
			}

		}
		Assert.assertEquals(6, catchUpInfos.size());
	}

	@Test
	public void testExcuteNoChangeInfo() {
		URL url = this.getClass().getResource("insert_seg_change_log.sql");
		executeSqlScript("file:///" + url.getPath(), false);
		jdbcTemplate.update("delete from segment_change_log");
		jdbcTemplate.update("commit");
		SegDiffPara segDiffP1 = new SegDiffPara(1, 0, 3,
				SegmentAssignedStateType.SEGMENT_ASSIGNED, 10);
		SegDiffPara segDiffP2 = new SegDiffPara(2, 1, 4,
				SegmentAssignedStateType.SEGMENT_ASSIGNED, 10);
		List<SegDiffPara> segDiffPsDiffParas = Lists.newArrayList();
		segDiffPsDiffParas.add(segDiffP1);
		segDiffPsDiffParas.add(segDiffP2);
		getSegCatupInfoProcedure.getSegDiffParas().addAll(segDiffPsDiffParas);
		getSegCatupInfoProcedure.setUnitType(3);
		List<CatchUpInfo> catchUpInfos = getSegCatupInfoProcedure.execute();
		Assert.assertNull(catchUpInfos);
	}

	@Test
	public void testExcuteDm() {
		URL url = this.getClass().getResource("insert_seg_change_log.sql");
		executeSqlScript("file:///" + url.getPath(), false);
		SegDiffPara segDiffP1 = new SegDiffPara(1, 0, 3,
				SegmentAssignedStateType.SEGMENT_ASSIGNED, 10);
		SegDiffPara segDiffP2 = new SegDiffPara(2, 1, 4,
				SegmentAssignedStateType.SEGMENT_ASSIGNED, 10);
		List<SegDiffPara> segDiffPsDiffParas = Lists.newArrayList();
		segDiffPsDiffParas.add(segDiffP1);
		segDiffPsDiffParas.add(segDiffP2);
		getSegCatupInfoProcedure.getSegDiffParas().addAll(segDiffPsDiffParas);
		getSegCatupInfoProcedure.setUnitType(1);
		List<CatchUpInfo> catchUpInfos = getSegCatupInfoProcedure.execute();
		Assert.assertEquals(6, catchUpInfos.size());
		for (int i = 0; i < catchUpInfos.size(); i++) {
			CatchUpInfo catchUpInfo = catchUpInfos.get(i);
			int segmentId = (int) catchUpInfo.getSegmentId();
			switch (segmentId) {
			case 1:
				if (catchUpInfo.getVersion() == 3) {
					Assert.assertEquals(0, catchUpInfo.getBytesString().size());
				} else {
					Assert.assertEquals(0, catchUpInfo.getBytesString().size());
				}
				Assert.assertTrue(catchUpInfo.getVersion() <= 3
						&& catchUpInfo.getVersion() > 0);
				break;
			case 2:
				if (catchUpInfo.getVersion() == 3) {
					Assert.assertEquals(0, catchUpInfo.getBytesString().size());
					Assert.assertTrue(catchUpInfo.getVersion() <= 4
							&& catchUpInfo.getVersion() > 1);
				}
				break;

			default:
				break;
			}

		}
		Assert.assertEquals(6, catchUpInfos.size());
	}

}
