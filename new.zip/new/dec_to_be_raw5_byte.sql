CREATE OR REPLACE FUNCTION  DEC_TO_BE_RAW5_BYTE 
(
  DEC_NUM IN NUMBER  
) RETURN RAW  AUTHID CURRENT_USER IS 
  v_raw_data RAW(10);
  v_hexstr varchar2(10);
  v_inx_byte number :=10;
  v_pad varchar2(10);
BEGIN
  v_hexstr := to_char(DEC_NUM, 'XXXXXXXX');
  --dbms_output.put_line(v_hexstr);
  --dbms_output.put_line(trim(v_hexstr));
  v_raw_data := hextoraw(trim(v_hexstr));
  v_inx_byte := 10- (utl_raw.length(v_raw_data) * 2) -1;
  v_pad := '0';
  for i in 1..v_inx_byte loop
     v_pad := v_pad || '0';
  end loop;
  v_raw_data := UTL_RAW.concat(v_pad, v_raw_data); 
  --dbms_output.put_line(v_raw_data);
  --dbms_output.put_line(utl_raw.length(v_raw_data));
  RETURN v_raw_data;
END DEC_TO_BE_RAW5_BYTE;

/
