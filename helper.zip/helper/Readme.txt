This project is for share object for AIM system.

If you'd like to change something in this project,
you must install helper.jar into NEC Site Repository server(10.17.71.208).

Installing is as follows.

ex)
  # checkout this project
  $ mvn clean package
  $ mvn deploy
  
  

---- How to update version in pom.xml ----
It is a hard task update version in pom.xml. Because we need to synchronize version elements 
in parent pom.xl and child pom.xml by hand.  
version-maven-plugin solves this problem.
To update version in pom.xml, follow the next steps.

1. Update version with version:set command.
 > mvn versions:set -DnewVersion=[X.X.X]
 
2. Confirm build success, no error.
 > mvn clean package
 
3. Remove local backup copy of pom.xml
 > mvn versions:commit
 
 version-maven-plugin creates a local backup copy pom.xml.versionsBackup.
 versions:commit removes this copy file.

4. If you want to cancel updating version, type next command.
 > mvn versions:revert
    