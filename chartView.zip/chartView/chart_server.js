const hostname = '127.0.0.1';
const port = 3000;
const http = require('http');
const fs = require('fs');
var express = require('express');
var app = express();
var path = require('path');
//var xml = require('xml');
var xml2js  = require('xml2js');





app.use(express.static('public'));
app.use(express.static('views'));

app.get('/', function (req, res) {
    fs.readFile(__dirname + '/views/home.html', 'utf-8', function (err, data) {
        if (err) {
            res.setHeader('Content-Type', 'text/plain');
            res.statusCode = 404;
            res.end('Not Founded.');
        } else {
            res.setHeader('Content-Type', 'text/html');
            res.statusCode = 200;
            res.end(data);
        }
    });
});

app.get('/job_results', function (req, res) {
    var name = "";
    if (req.query.name) {
        name = req.query.name;
      }   
      res.set('Content-Type', 'text/xml');  
      res.sendFile(path.join(__dirname, '/job_results', name));      
      //res.send(xml(path.join(__dirname, '/job_results', name)));
      var xmlFile = __dirname + "/job_results" + name;
      var data = fs.readFileSync(xmlFile, 'utf8');      
      var jsonData = xml2js.str2json(data);
      res.json(jsonData);

           
});


app.listen(port, hostname, () => {
    console.log(`Server running at http://${hostname}:${port}/`);
});