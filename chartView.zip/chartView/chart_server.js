const hostname = '127.0.0.1';
const port = 3000;
const http = require('http');
const fs = require('fs');
var express = require('express');
var app = express();
var path = require('path');
url = require('url');

app.use(express.static('public'));
app.use(express.static('views'));

app.get('/', function (req, res) {
    fs.readFile(__dirname + '/views/home.html', 'utf-8', function (err, data) {
        if (err) {
            res.setHeader('Content-Type', 'text/plain');
            res.statusCode = 404;
            res.end('Not Founded.');
        } else {
            res.setHeader('Content-Type', 'text/html');
            res.statusCode = 200;
            res.end(data);
        }
    });
});

app.get('/job_results', function (req, res) {
    var name = "";
    if (req.query.name) {
        name = req.query.name;
    }
    res.set('Content-Type', 'text/plain');
    var xml2js = require('xml2js');
    var parser = new xml2js.Parser();
    var xmlFile = path.join(__dirname, 'job_results', name);
    fs.readFile(xmlFile, function (err, data) {
        if (err) {
            res.statusCode = 404;
            res.end('Not Founded.');
        } else {
            parser.parseString(data, function (err, result) {
                if (err) {
                    res.statusCode = 500;
                    res.end('Parse xml error.');
                } else {
                    res.statusCode = 200;
                    res.end(result);
                }

            });
        }
    });
});

app.get('/images', function (req, res) {
    var name = "";
    if (req.query.name) {
        name = req.query.name;
    }
    var imageFile = path.join(__dirname, 'images', name);
    var imageData = fs.readFileSync(imageFile, "binary");
    var base64Image = imageData.toString("base64");   
    const dataUrl = `data:image/bmp;base64, ${base64Image}`;
    //var dataUrl = 'data:image/bmp;base64' + base64Image;
    res.writeHead(200, "Ok");    
     res.end(dataUrl); 
         
});


app.listen(port, hostname, () => {    
    console.log(`Server running at http://${hostname}:${port}/`);
});