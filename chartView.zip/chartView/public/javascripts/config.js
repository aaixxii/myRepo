const minutia_server_ip = "10.197.23.100";
const minutia_server_port = "17777";
const nodeJs_server_ip = "localhost";
const nodeJs_server_post = "3000";
const get_method = "/getminutia";