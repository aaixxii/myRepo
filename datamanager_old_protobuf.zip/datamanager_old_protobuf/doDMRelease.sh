#!/bin/sh

# ----------------------------------------------------------------------
# Checking   paramters  all are correctly!
# 1. aim_release_version
# 2. currently_aim_branches_version
# 3. dm_developing_version
# exsample : ./doDMRelease.sh 5.0.3  5.0.2 5.0.1
# ----------------------------------------------------------------------
# CHECK Args of doDMRelease()
if test  $# != 3 ; then
	echo Usage : ./doDMRelease.sh   aim_release_version  currently_aim_branches_version   dm_developing_version
	exit
fi
RELEASE_VER=$1
DEV_VER=$2
DM_VER=$3
RPM_COPY_TO_DIR=http://dev01a/shipment/branches/Release/AIM-$RELEASE_VER/AIM-$RELEASE_VER-PKG/AIM-$RELEASE_VER-BASIC/AIMInstaller/pkgs/

RPM_NAME=aim-dm-$DM_VER-0.x86_64.rpm
echo $RPM_NAME
DM_FORM_DIR=DataManager-$DEV_VER/
DM_TAG_DIR=http://dev01a/svn/tags/DataManager/$RELEASE_VER/
DM_RELEASE_TAG_DIR=http://dev01a/svn/tags/Release/AIM-$RELEASE_VER/DataManager/
SVN_USER=xia
SVN_PWD=xia

mkdir release
cd release
# --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# Release DM to shipment
#  Copy dm rpm to http://dev01a/shipment/branches/Release/AIM-{releaseVer}/AIM-{releaseVer}-PKG/AIM-{releaseVer}-BASIC/AIMInstaller/pkgs/
# --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# CHECKOUT  SHIPMENT DIRECTORY OF DM RPM
svn ls --username $SVN_USER --password $SVN_PWD $RPM_COPY_TO_DIR > /dev/null
if test $? = 1 ; then
	svn mkdir --username $SVN_USER --password $SVN_PWD --parents --message "Directory Created By $SVN_USER" $RPM_COPY_TO_DIR
	svn co --username $SVN_USER --password $SVN_PWD $RPM_COPY_TO_DIR
else
	svn co --username $SVN_USER --password $SVN_PWD --depth=empty $RPM_COPY_TO_DIR
	svn ls --username $SVN_USER --password $SVN_PWD $RPM_COPY_TO_DIR/$RPM_NAME
	if test $? = 0 ; then
		svn up --username $SVN_USER --password $SVN_PWD --depth=files pkgs/$RPM_NAME
	fi
fi
cp ../target/rpm/aim-dm/RPMS/x86_64/$RPM_NAME  pkgs/
cd  pkgs
svn add *
svn commit --username $SVN_USER --password $SVN_PWD --message "Update By $SVN_USER"
COMMIT_RESULT=$?
cd ../../
rm -rf release
if test $COMMIT_RESULT -ne 0 ; then
	echo “svn commit for shipment was failed!! Exit without making tag of DM source code.”
	exit
fi

# ----------------------------------------------------------------------------------------------------------------------------------------
# Create Tag  for  DM
# 1. Copy DM sources form branche to http://dev01a/svn/tags/Release/AIM-${releaseVer}/DataManager
# 2. Copy DM sources from branche to http://dev01a/svn/tags/DataManager/${releaseVer}
# -----------------------------------------------------------------------------------------------------------------------------------------

echo "--------------------------------------------------------------------------------"
echo "CREATE DM TAG TO http://dev01a/svn/tags/Release/..."
echo "--------------------------------------------------------------------------------"

# CHECK IF TAG IS ALREADY CREATED OR NOT
svn ls --username $SVN_USER --password $SVN_PWD $DM_RELEASE_TAG_DIR > /dev/null
if test $?  = 0 ; then
	svn delete --username $SVN_USER --password $SVN_PWD --message "Delete Tag by $SVN_USER" $DM_RELEASE_TAG_DIR
else
	svn mkdir --username $SVN_USER --password $SVN_PWD --parents --message "Directory Created By $SVN_USER" $DM_RELEASE_TAG_DIR
fi

# CREATE SOURCE CODE TAG
svn copy --username $SVN_USER --password $SVN_PWD --message "Create Source Code Tag by $SVN_USER" --parents http://dev01a/svn/branches/AIM-$DEV_VER/DataManager  $DM_RELEASE_TAG_DIR

echo "--------------------------------------------------------------------------------------------"
echo "CREATE DM TAG TO http://dev01a/svn/tags/DataManager/.. "
echo "---------------------------------------------------------------------------------------------"

# CHECK IF TAG IS ALREADY CREATED OR NOT
svn ls --username $SVN_USER --password $SVN_PWD $DM_TAG_DIR > /dev/null
if test $? = 0 ; then
	svn delete --username $SVN_USER --password $SVN_PWD --message "Delete Tag by $SVN_USER" $DM_TAG_DIR
else 
        svn mkdir --username $SVN_USER --password $SVN_PWD --parents --message "Directory Created By $SVN_USER" $DM_TAG_DIR
fi

# CREATE SOURCE CODE TAG
svn copy --username $SVN_USER --password $SVN_PWD --message "Create Source Code Tag by$SVN_USER" --parents http://dev01a/svn/branches/AIM-$DEV_VER/DataManager  $DM_TAG_DIR

echo "Completed ......Done!"
