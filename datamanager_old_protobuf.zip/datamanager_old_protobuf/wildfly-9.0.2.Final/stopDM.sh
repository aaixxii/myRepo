#!/bin/sh
bin/jboss-cli.sh --connect --command=:shutdown
count=0;
waitcount=20;
PWD=`pwd`
PID=`ps -ef | grep java |grep -v grep | grep $PWD | awk '{print $2}'`
while(true); do
        RET=`ps -ef | grep java |grep -v grep | grep $PWD|wc | awk '{print $1}'`
        if [ "$RET" = "0" ]; then
                echo "============================================================"
                echo
                echo "  $PWD is stopped!"
                echo
                echo "============================================================"
                break;
        else
                echo "......... $PWD is still running ......."

                let count=$count+1;
                if [ $count -gt $waitcount ]; then
                   kill -s 9 $PID
                fi
        fi
        sleep 1
done