package jp.co.nec.aim.dm.manager;

import static jp.co.nec.aim.dm.persistence.HeaderInfo.SIZE_CHECK_SUM;
import static jp.co.nec.aim.dm.persistence.HeaderInfo.SIZE_SEGMENT_FILE_HEADER;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import jp.co.nec.aim.dm.domain.IndexFile;
import jp.co.nec.aim.dm.domain.SegmentFileName;
import jp.co.nec.aim.dm.exception.DataManagerException;
import jp.co.nec.aim.dm.properties.DynamicProperties;
import jp.co.nec.aim.dm.properties.DynamicPropertyNames;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import au.com.bytecode.opencsv.CSVReader;
import au.com.bytecode.opencsv.CSVWriter;

/**
 * IndexManager keeps seek pointer of Segment File
 * @author kurosu
 *
 */
public class IndexManager {
	/** Declare Logger 1st to avoid NullPointerException */
	private static final Logger log = LoggerFactory.getLogger(IndexManager.class);
	private static long INDEX_BLANK = Long.parseLong((DynamicProperties.getInstance()
			.getPropertyValue(DynamicPropertyNames.INDEX_BLANK)));
	private static final IndexManager INSTANCE = new IndexManager();
	
	/** 
	 * key is SEGMENT_ID, value is Index Map<Long, Long>.
	 * key of Map<Long, Long> is templateId, value is file pointer of template size.
	 *  indexRepository is serialized when MM shutDown. 
	 */
	private ConcurrentHashMap<Integer, Map<Long, Long>> indexRepository;
	
	/** ReentrantReadWriteLock set lock for indexRepository in case (read, write) or (write, write) threads. */
	private ReentrantReadWriteLock readWriteLock;
	private Lock readLock;
	private Lock writeLock;
	
	public static IndexManager getInstance() {
		return INSTANCE;
	}
	
	private IndexManager() {
		readWriteLock = new ReentrantReadWriteLock(true);
		readLock = readWriteLock.readLock();
		writeLock = readWriteLock.writeLock();
		indexRepository = new ConcurrentHashMap<Integer, Map<Long,Long>>();
		if(INDEX_BLANK <= 0) {
			throw new IllegalArgumentException("INDEX_BLANK is not positive, it's" + INDEX_BLANK);
		}
	}

	ConcurrentHashMap<Integer, Map<Long, Long>> createRepositoryMap() {
		ConcurrentHashMap<Integer, Map<Long, Long>> repositoryMap = new ConcurrentHashMap<Integer, Map<Long, Long>>();
		File[] segFiles = SegmentFileInventory.fetchSegmentFiles("Create Indexes of Segment Files ");
		if(segFiles == null || segFiles.length == 0) {
			return repositoryMap;
		}
		for (File segFile : segFiles) {
			Integer segId = SegmentFileName.getSegmentIdFromName(segFile.getName());
			try {
				Long segVersion = SegmentFileIntegrityChecker.checkFile(segFile, segId, false);
				if (segVersion == null) {
					log.warn("Skip loading  segment " + segId
							+ ", because file is corrupt");
					segFile.delete();
				} else {
					log.debug("Datamanager creating index of segment from disk: " + segId);
					Map<Long, Long> indexMap = createIndexMap(segId.intValue());
					if(indexMap == null) {
						log.error("Can't create Index of Segment File, SEGMENT_ID= " + segId);
					} else {
						repositoryMap.put(segId, indexMap);
					}
				}
			} catch (DataManagerException e) {
				log.warn("DataManagerException while reading segment "
						+ segId
						+ " during initial segment inventory... treating file as corrupt.",
						e);
				segFile.delete();
			}
		}	
		return repositoryMap;
	}

	private Map<Long, Long> createIndexMap(int segmentId) {
		SegmentFileName segmentFileName = new SegmentFileName(segmentId);
		return createIndexMap(segmentFileName.getName());
	}

	/**
	 * Read Segment file and create index
	 * @param segmentId
	 * @return
	 */
	Map<Long, Long> createIndexMap(String segmentFilePath) {
		Map<Long, Long> indexMap = new ConcurrentHashMap<Long, Long>();
		RandomAccessFile randFile = null;
		StopWatch stopWatch = new StopWatch();
		try {
			stopWatch.start();
			randFile = new RandomAccessFile(segmentFilePath, "rw");
			long fileLength = randFile.length();
			long lastIndexedPointer = -INDEX_BLANK;
			long seekPos = SIZE_SEGMENT_FILE_HEADER + SIZE_CHECK_SUM;
			while(seekPos < fileLength) {
				randFile.seek(seekPos);
				long pointer = randFile.getFilePointer();
				int templateSize = randFile.readInt();
				if(INDEX_BLANK <= (pointer - lastIndexedPointer)) {
					Long templateId = new Long(randFile.readLong());
					indexMap.put(templateId, new Long(pointer));
					lastIndexedPointer = pointer;
				}
				seekPos += SIZE_CHECK_SUM;
				seekPos += templateSize;
			}
			return indexMap;
		} catch (FileNotFoundException e) {
			log.error(segmentFilePath + " not found.");
			return null;
		} catch (IOException e) {
			log.error("IOException while reading " + segmentFilePath);
			return null;
		} finally {
			stopWatch.stop();
			log.info("It took {} msec to calculate index of {}",
					new Long(stopWatch.getTime()), segmentFilePath);
			IOUtils.closeQuietly(randFile);
		}
	}

	/**
	 * Get start position in Segment File to find templateId
	 * @param segmentId
	 * @param templateId
	 * @return positive value if IndexManager knows the seek start position of (segmentId, tempalteId) 
	 *       returns -1 if tempalteId is less than minimum templateId of Index.
	 */
	public long getPosition(int segmentId, long templateId) {
		if(segmentId < 1) {
			throw new IllegalArgumentException("semgntId = " + segmentId + ", it must be positive");
		}
		if(templateId < 1) {
			throw new IllegalArgumentException("templateId = " + templateId + ", it must be positive");
		}
		
		readLock.lock();
		try {
			Map<Long, Long> indexMap = indexRepository.get(new Integer(segmentId));
			if(indexMap == null) {
				return (long) (SIZE_SEGMENT_FILE_HEADER + SIZE_CHECK_SUM);
			} else {
				Long position = indexMap.get(new Long(templateId));
				if(position != null) {
					return position.longValue();
				}
				if(!indexMap.isEmpty()) {
					List<Long> sortedKeys = new ArrayList<Long>(indexMap.keySet());
					Collections.sort(sortedKeys);
					if(templateId < sortedKeys.get(0).longValue()) {
						return -1L;
					}
					if(sortedKeys.get(sortedKeys.size()-1).longValue() < templateId) {
						return indexMap.get(sortedKeys.get(sortedKeys.size()-1)).longValue();
					}
					for(int index = 0; index < sortedKeys.size()-1; index++) {
						if(sortedKeys.get(index).longValue() < templateId && templateId < sortedKeys.get(index+1).longValue()) {
							return indexMap.get(sortedKeys.get(index)).longValue();
						}
					}
				}
				return (long) (SIZE_SEGMENT_FILE_HEADER + SIZE_CHECK_SUM);
			}
		} finally {
			readLock.unlock();
		}
	}

	/**
	 * Read Segment File and create IndexMap
	 * @param segmentId
	 * 
	 */
	public void putIndexMap(int segmentId) {
		writeLock.lock();
		try {
			Map<Long, Long> indexMap = createIndexMap(segmentId);
			if(indexMap == null) {
				log.warn("Can't create Index for SEGMENT_ID:{}", new Integer(segmentId));
			} else {
				indexRepository.put(new Integer(segmentId), indexMap);
			}
		} finally {
			writeLock.unlock();
		}
	}

	/**
	 * Serialize indexRepository field and save in  
	 */
	public void saveAllIndex() {
		readLock.lock();
		try {
			Set<Integer> keySet = indexRepository.keySet();
			for(Integer key : keySet) {
				CSVWriter writer = null;
				try {
					Map<Long, Long> indexMap = indexRepository.get(key);
					IndexFile indexFile = new IndexFile(key.longValue());
					List<String[]> lines = new ArrayList<String[]>();
					Set<Long> idSet = indexMap.keySet();
					List<Long> templateIds = new ArrayList<Long>(idSet);
					Collections.sort(templateIds);
					for(Long templateId : templateIds) {
						Long position = indexMap.get(templateId);
						lines.add(new String[] {templateId.toString(), position.toString()});
					}
					writer = new CSVWriter(new FileWriter(indexFile.getName()));
					writer.writeAll(lines);
					writer.flush();
				} catch (IOException e) {
					log.warn(e.getMessage(), e);
				} finally {
					IOUtils.closeQuietly(writer);
				}
			}
		} finally {
			readLock.unlock();
		}
	}

	/**
	 * Remove IndexMap of segmentId
	 * @param segmentId
	 */
	public void removeIndex(int segmentId) {
		writeLock.lock();
		try {
			indexRepository.remove(new Integer(segmentId));
		} finally {
			writeLock.unlock();
		}
	}
	
	/**
	 * Read Index file and load into map.
	 * returns Map<Long, Long> if index file exists. returns  null if index file does not exist or error.
	 * @param segmentId
	 * @return
	 */
	Map<Long, Long> readIndexFile(long segmentId) {
		IndexFile indexFile = new IndexFile(segmentId);
		CSVReader reader = null;
		try {
			Map<Long, Long> map = new ConcurrentHashMap<Long, Long>();
			reader = new CSVReader(new FileReader(indexFile.getName()));
			List<String[]> records = reader.readAll();
			for(String[] record : records) {
				Long templateId = Long.valueOf(record[0]);
				Long position = Long.valueOf(record[1]);
				map.put(templateId, position);
			}
			return map;
		} catch (FileNotFoundException e) {
			log.warn(indexFile.getName() + "not found");
			return null;
		} catch (IOException e) {
			log.warn("Can't read " + indexFile.getName());
			return null;
		} finally {
			IOUtils.closeQuietly(reader);
		}
	}

	/**
	 * check blank between latestIndexedPosition and end of file. And add Index if it's over INDEX_BLANK 
	 * @param randFile RnadomAccessFile of Segment File.
	 * @param segmentId
	 * @param templateId 
	 * @throws IOException 
	 */
	public void addIndexEndOfFile(RandomAccessFile randFile, int segmentId, long templateId) throws IOException {
		if(randFile == null) {
			throw new IllegalArgumentException("randFile == null");
		} else if(randFile.getFilePointer() != randFile.length()) {
			log.error("Pointer of RnadomAccessFile is not set at the end of file");
			return;
		}
		if(segmentId < 1) {
			throw new IllegalArgumentException("segmentId = " + segmentId + ", it must be positive");
		}
		if(templateId < 1L) {
			throw new IllegalArgumentException("templateId = " + templateId + ", it must be positive");
		}

		try {
			writeLock.lock();
			long lastIndexedPosition = getLastIndexedPosition(segmentId);
			if(lastIndexedPosition < 0) {
				log.warn("try to add Index for segmentId:{}, but there is not last index", new Integer(segmentId));
				Map<Long, Long> indexMap = new ConcurrentHashMap<Long, Long>();
				indexMap.put(new Long(templateId), new Long(SIZE_SEGMENT_FILE_HEADER + SIZE_CHECK_SUM));
				indexRepository.put(new Integer(segmentId), indexMap);
			} else {
				// Index should be set after CHECK_SUM
				long candidatePos = randFile.length() + SIZE_CHECK_SUM;
				if((candidatePos - lastIndexedPosition) < INDEX_BLANK) {
					return;
				} else {
					Map<Long, Long> indexMap = indexRepository.get(new Integer(segmentId));
					if(indexMap.containsKey(new Long(templateId))) {
						Long pos = indexMap.get(new Long(templateId));
						log.warn("indexMap of segmemtId:{] alredy has index for tempalteId:{}, position:{}",
								new Object[] {new Integer(segmentId), new Long(templateId), pos});
					} else {
						if(log.isDebugEnabled()) {
							log.debug("Add index of segmentId:{} for templateId:{] at postion:{}",
									new Object[] {new Integer(segmentId), new Long(templateId), new Long(candidatePos)});
						}
						indexMap.put(new Long(templateId), new Long(candidatePos));
					}
				}
			}
		} finally {
			writeLock.unlock();
		}
	}

	/**
	 * Get last indexed position
	 * 
	 * @param segmentId
	 * @return positive value if IndexManager has index of segmentId
	 *   -1 if IndexManager does not have index of segmentId or it's empty
	 */
	private long getLastIndexedPosition(int segmentId) {
		Map<Long, Long> indexMap = indexRepository.get(new Integer(segmentId));
		if(indexMap == null || indexMap.isEmpty()) {
			return -1L;
		} else {
			List<Long> indexedIds = new ArrayList<Long>(indexMap.keySet());
			Collections.sort(indexedIds);
			return indexMap.get(indexedIds.get(indexedIds.size()-1)).longValue();
		}
	}

	/**
	 * Load index file into memory if it exist.
	 * If Index file is lost or broken, create Index from segment file
	 * @param segmentId
	 */
	public void loadIndexFile(int segmentId) {
		writeLock.lock();
		try {
			if(indexRepository.get(new Integer(segmentId)) == null) {
				Map<Long, Long> indexMap = readIndexFile((long)segmentId);
				if(indexMap == null) {
					log.warn(".{}.index does not exist or has some error. Create Index from {}.seg again", 
							new Integer(segmentId), new Integer(segmentId));
					indexMap = createIndexMap(segmentId);
				} else if(!isValidIndex(segmentId, indexMap)) {
					log.warn(".{}.index is invalid!. Create Index from .{}.seg again", 
							new Integer(segmentId), new Integer(segmentId));
					indexMap = createIndexMap(segmentId);
				}
				indexRepository.put(new Integer(segmentId), indexMap);
			}
		} finally {
			writeLock.unlock();
		}
	}

	boolean isValidIndex(int segmentId, Map<Long, Long> indexMap) {
		Set<Long> keySet = indexMap.keySet();
		List<Long> indexList = new ArrayList<Long>(keySet);
		if(indexList.size() == 0) {
			return false;
		}
		Collections.sort(indexList);
		long lastIndexedTemplateId = indexList.get(indexList.size()-1).longValue();
		long position = indexMap.get(indexList.get(indexList.size()-1)).longValue();
		SegmentFileName segFileName = new SegmentFileName(new Integer(segmentId));
		RandomAccessFile randFile = null;	
		try {
			randFile = new RandomAccessFile(segFileName.getName(), "rw");
			randFile.seek(position);
			randFile.readInt(); // Ignore templateSize
			long templateId = randFile.readLong();
			if(templateId == lastIndexedTemplateId) {
				return true;
			} else {
				log.warn("last indexed templateId:{} is not equal to in segment file templateId:{}",
						new Long(lastIndexedTemplateId), new Long(templateId));
				return false;
			}
		} catch (FileNotFoundException e) {
			log.warn(e.getMessage(), e);
			return false;
		} catch (IOException e) {
			log.warn(e.getMessage(), e);
			return false;
		} finally {
			IOUtils.closeQuietly(randFile);
		}
	}

	/**
	 * Save IndexMap for segmentId into .{segmentId}.index
	 * @param segmentId
	 */
	public void saveIndex(int segmentId) {
		readLock.lock();
		try {
			Map<Long, Long> indexMap = indexRepository.get(new Integer(segmentId));
			if(indexMap == null) {
				log.warn("Index of {}.seg does not exist in indexRepository", new Integer(segmentId));
			} else {
				IndexFile indexFile = new IndexFile((long) segmentId);
				saveIndexMap(indexMap, indexFile.getName());
			}
		} finally {
			readLock.unlock();
		}
	}
	
	void saveIndexMap(Map<Long, Long> indexMap, String indexFilePath) {
		CSVWriter writer = null;
		try {
			List<String[]> lines = new ArrayList<String[]>();
			Set<Long> idSet = indexMap.keySet();
			List<Long> templateIds = new ArrayList<Long>(idSet);
			Collections.sort(templateIds);
			for(Long templateId : templateIds) {
				Long position = indexMap.get(templateId);
				lines.add(new String[] {templateId.toString(), position.toString()});
			}
			writer = new CSVWriter(new FileWriter(indexFilePath));
			writer.writeAll(lines);
			writer.flush();
		} catch (IOException e) {
			log.warn(e.getMessage(), e);
		} finally {
			IOUtils.closeQuietly(writer);
		}
	}

	@Deprecated
	/**
	 * Only for Test
	 */
	public void clear() {
		indexRepository.clear();
	}

}
