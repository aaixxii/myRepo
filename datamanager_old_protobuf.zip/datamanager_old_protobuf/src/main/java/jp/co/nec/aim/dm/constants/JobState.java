package jp.co.nec.aim.dm.constants;

public enum JobState {
	WAITING_TO_RUN, RUNNING, WAITING_FOR_WRITE_LOCK, ACQUIRED_WRITE_LOCK, EXECUTING, DONE
}
