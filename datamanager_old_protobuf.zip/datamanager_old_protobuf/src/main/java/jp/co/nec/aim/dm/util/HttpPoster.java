package jp.co.nec.aim.dm.util;

import java.io.IOException;

import org.apache.http.HttpEntity;
import org.apache.http.HttpException;
import org.apache.http.client.HttpRequestRetryHandler;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.entity.ContentType;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.protocol.HttpContext;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * HttpPoster
 * 
 * @author liuyq
 * 
 */
public final class HttpPoster {

	/** log instance **/
	private static final Logger log = LoggerFactory.getLogger(HttpPoster.class);

	private static final int SO_TIMEOUT = 5000;
	private static final int CON_TIMEOUT = 5000;
	private static final int RETRY_COUNT = 3;

	/**
	 * post to target URL with header and body
	 * 
	 * @param url
	 * @param header
	 * @param bytes
	 * @param doRetry
	 * @return
	 * @throws IOException
	 */
	public static final HttpResponseInfo post(final String url, byte[] bytes,
			boolean doRetry, Integer soTimeOut) throws HttpException {
		if (log.isDebugEnabled()) {
			log.debug("start http post with specified url: {}.", url);
		}

		HttpPost httpPost = null;
		byte[] ObjectBytes = null;
		int statusCode;
		try (CloseableHttpClient httpClient = doRetry ? HttpClientBuilder
				.create().setRetryHandler(retryHandler).build()
				: HttpClientBuilder.create().disableAutomaticRetries().build()) {

			httpPost = new HttpPost(url);
			httpPost.setConfig(RequestConfig
					.custom()
					.setConnectTimeout(
							soTimeOut == null ? CON_TIMEOUT : soTimeOut)
					.setConnectionRequestTimeout(
							soTimeOut == null ? CON_TIMEOUT : soTimeOut)
					.setSocketTimeout(
							soTimeOut == null ? SO_TIMEOUT : soTimeOut).build());
			// set bytes
			if (bytes != null) {
				ByteArrayEntity entity = new ByteArrayEntity(bytes,
						ContentType.APPLICATION_OCTET_STREAM);
				httpPost.setEntity(entity);
			}

			try (CloseableHttpResponse response = httpClient.execute(httpPost)) {
				statusCode = response.getStatusLine().getStatusCode();
				HttpEntity reEntity = response.getEntity();
				if (reEntity != null) {
					ObjectBytes = EntityUtils.toByteArray(reEntity);
				}
			}
		} catch (IOException e) {
			throw new HttpException("IOException occurred while post to url "
					+ url, e);
		} catch (Exception e) {
			throw new HttpException("IOException occurred while post to url "
					+ url, e);
		}
		return new HttpResponseInfo(statusCode, ObjectBytes);
	}

	/**
	 * The retry handler,default max retry count is 3.
	 */
	private static HttpRequestRetryHandler retryHandler = new HttpRequestRetryHandler() {
		public boolean retryRequest(IOException exception, int executionCount,
				HttpContext context) {
			if (log.isDebugEnabled()) {
				log.debug("start HttpPoster retryRequest..");
			}

			if (executionCount <= RETRY_COUNT) {
				log.warn("Http post, Retried connection {}"
						+ " times, which exceeds the maximum"
						+ " retry count of {}.", executionCount, RETRY_COUNT);
			} else {
				// Do not retry if over max retry count
				throw new RuntimeException("retry the request "
						+ executionCount + " times");
			}
			if (log.isDebugEnabled()) {
				log.debug("end HttpPoster retryRequest..");
			}
			return true;
		}
	};
}
