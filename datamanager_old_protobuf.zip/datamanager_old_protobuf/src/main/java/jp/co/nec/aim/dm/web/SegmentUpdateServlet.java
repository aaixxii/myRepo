package jp.co.nec.aim.dm.web;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.nec.aim.dm.comm.SegmentCatchUp;
import jp.co.nec.aim.dm.log.LogConstants;
import jp.co.nec.aim.dm.log.PerformanceLogger;
import jp.co.nec.aim.dm.util.StopWatch;
import jp.co.nec.aim.message.proto.AIMMessages.PBSegmentSyncRequest;

import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * SegmentUpdateServlet
 * 
 * @author liuyq
 * 
 */
public class SegmentUpdateServlet extends HttpServlet {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -7131282326655066894L;
	private static Logger log = LoggerFactory
			.getLogger(SegmentUpdateServlet.class);
	private SegmentCatchUp catchUp; // the common of segment catch up

	/**
	 * HttpServlet init method
	 */
	public void init(ServletConfig servletConfig) throws ServletException {
		catchUp = new SegmentCatchUp();
	}

	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();

		try {
			log.info("Received Segment Sync POST from MM push operation..");

			PBSegmentSyncRequest request = null;
			try {
				request = PBSegmentSyncRequest.parseFrom(req.getInputStream());
			} catch (Exception ex) {
				res.setStatus(HttpStatus.SC_BAD_REQUEST);
				log.error("Exception occurred when parse the"
						+ " PBSegmentSyncRequest.", ex);
				return;
			}

			// if SegmentUpdates is empty, skip do sync operation
			if (request.getSegmentUpdatesCount() <= 0) {
				log.warn("Nothing to Sync the segment due to SegmentUpdates is empty.");
				res.setStatus(HttpStatus.SC_OK);
				return;
			}

			// catch up the segment
			catchUp.segmentCatchUp(request.getSegmentUpdatesList());

			stopWatch.stop();
			PerformanceLogger.log(LogConstants.COMPONENT_DM, getClass()
					.getSimpleName(), Thread.currentThread().getStackTrace()[1]
					.getMethodName(), stopWatch.elapsedTime());
		} finally {

		}
	}

}
