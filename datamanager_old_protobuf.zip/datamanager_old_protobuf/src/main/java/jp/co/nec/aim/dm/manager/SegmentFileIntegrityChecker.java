package jp.co.nec.aim.dm.manager;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.RandomAccessFile;

import jp.co.nec.aim.dm.constants.DMConstants;
import jp.co.nec.aim.dm.exception.DataManagerException;
import jp.co.nec.aim.helper.SegmentFileConstants;
import jp.co.nec.aim.helper.TemplateHeaderHelper;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.ArrayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SegmentFileIntegrityChecker {

	private static final Logger log = LoggerFactory
			.getLogger(SegmentFileIntegrityChecker.class);

	public SegmentFileIntegrityChecker() {

	}

	public static Long checkFile(File segFile, int segmentId,
			boolean validateSegmentsOnStartup) {
		log.debug("Checking segment " + segmentId + ", file: '"
				+ segFile.getPath() + "'");
		FileInputStream fin = null;
		BufferedInputStream bis = null;
		DataInputStream dataInStream = null;
		RandomAccessFile randomFile = null;
		try {
			randomFile = new RandomAccessFile(segFile, "r");
			long length = randomFile.length();
			fin = new FileInputStream(segFile);
			bis = new BufferedInputStream(fin, DMConstants.BYTE_BUFFER_SIZE);
			dataInStream = new DataInputStream(bis);

			long fileOffSet = 0;
			byte[] headerVersion = new byte[4];
			dataInStream.read(headerVersion);
			fileOffSet += 4;
			int formatId = dataInStream.readUnsignedShort();
			fileOffSet += 2;
			if (formatId < 0) {
				log.error("Segment " + segmentId
						+ " is corrupt because of invalid formatId: "
						+ formatId);
				return null;
			}

			long maxSegmentFileLength = dataInStream.readLong();
			fileOffSet += 8;
			if (maxSegmentFileLength < 0) {
				log.error("Segment "
						+ segmentId
						+ " is corrupt because of invalid maxSegmentFileLength: "
						+ maxSegmentFileLength);
				return null;
			}

			int recordCountFromHeader = dataInStream.readInt();
			log.debug("Segment " + segmentId + " header record count: "
					+ recordCountFromHeader);
			fileOffSet += 4;
			if (recordCountFromHeader < 0) {
				log.error("Segment "
						+ segmentId
						+ " is corrupt because of invalid recordCount in header: "
						+ recordCountFromHeader);
				return null;
			}

			long segmentVersion = dataInStream.readLong();
			log.debug("Segment " + segmentId + " header segment version: "
					+ segmentVersion);
			fileOffSet += 8;
			if (segmentVersion < 0) {
				log.error("Segment "
						+ segmentId
						+ " is corrupt because of invalid because of invalid segmentVersion: "
						+ segmentVersion);
				return null;
			}

			if (!validateSegmentsOnStartup) {
				return segmentVersion;
			}

			int numOfTemplateRecords = 0;
			while (fileOffSet < length) {
				byte givenChecksum = dataInStream.readByte();
				fileOffSet += 1;

				int templateSizeWithHeader = dataInStream.readInt();
				fileOffSet += SegmentFileConstants.SIZE_TSZ;

				long templateId = dataInStream.readLong();
				fileOffSet += SegmentFileConstants.SIZE_TEMPLATE_ID;

				if (templateId <= 0) {
					log.error("Found invalid template ID '" + templateId
							+ "' at record # " + numOfTemplateRecords);
				}

				if (templateSizeWithHeader <= SegmentFileConstants.SIZE_TEMPLATE_HEADER) {
					log.error("Template size in header for template "
							+ templateId
							+ " is less than header itself. Given size: "
							+ templateSizeWithHeader);
					return null;
				}

				int deletedFlag = dataInStream.readByte();
				fileOffSet += SegmentFileConstants.SIZE_DELETE_FLAG;

				if (deletedFlag == 0) {
					numOfTemplateRecords++;
					log.debug("Template ID: " + templateId + ", size: "
							+ templateSizeWithHeader);
				} else if (deletedFlag == 1) {
					log.debug("Template ID " + templateId + ", size: "
							+ templateSizeWithHeader + "  found to be deleted");
				} else {
					log.error("Segment "
							+ segmentId
							+ " is corrupt because it has an invalid deleted flag byte for template "
							+ templateId + ": byte value: '" + deletedFlag
							+ "'");
					return null;
				}
				
				byte[] extBytes = new byte[SegmentFileConstants.SIZE_EXTERNAL_ID];
				int readLength = dataInStream.read(extBytes);
				if(readLength != SegmentFileConstants.SIZE_EXTERNAL_ID) {
					log.error("Can't read externalId from " + segFile.getName());
					return null;
				}

				fileOffSet += SegmentFileConstants.SIZE_EXTERNAL_ID; 
				int index = ArrayUtils.indexOf(extBytes, (byte)0);
				String externalId = null;
				if(index != ArrayUtils.INDEX_NOT_FOUND) {
					externalId = new String(ArrayUtils.subarray(extBytes, 0, index));
				} else {
					externalId = new String(extBytes);
				}

				int eventId = dataInStream.readInt();
				fileOffSet += SegmentFileConstants.SIZE_EVENT_ID;
				
				int templateSize = templateSizeWithHeader
						- SegmentFileConstants.SIZE_TEMPLATE_HEADER;

				byte[] templateData = new byte[templateSize];
				dataInStream.readFully(templateData);
				TemplateHeaderHelper.validateChecksum(templateId, templateData,
						eventId, externalId, givenChecksum);

				fileOffSet += (templateSize);
			}
			if (numOfTemplateRecords != recordCountFromHeader) {
				log.error("Segment "
						+ segmentId
						+ " is corrupt because of the record count doesn't match:"
						+ "template records in file=" + numOfTemplateRecords
						+ "recordCount in header=" + recordCountFromHeader);
				return null;
			}
			if (fileOffSet != length) {
				log.error("Segment "
						+ segmentId
						+ " is corrupt because the file does not end cleanly. The file length in bytes is "
						+ length + ", the last file offset is " + fileOffSet);
				return null;
			}

			return segmentVersion;
		} catch (IOException e) {
			throw new DataManagerException(
					"Error while checking SegmentFile integrity", e);
		} finally {
			IOUtils.closeQuietly(dataInStream);
			IOUtils.closeQuietly(bis);
			IOUtils.closeQuietly(fin);
			IOUtils.closeQuietly(randomFile);
		}
	}

}
