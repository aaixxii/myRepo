package jp.co.nec.aim.dm.constants;

public class SegUpdateServerStatus {
	public static final int SERVER_STATUS_ASSIGNED = 0;
	public static final int SERVER_STATUS_UNASSIGNED = 1;
	public static final int SERVER_STATUS_DEFUNCT = 2;
}
