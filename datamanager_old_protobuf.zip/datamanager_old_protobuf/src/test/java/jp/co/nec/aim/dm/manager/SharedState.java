package jp.co.nec.aim.dm.manager;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import jp.co.nec.aim.dm.exception.DataManagerException;

public class SharedState {
	private final DataSource ds;

	public SharedState() {
		ds = createDataSource();
	}

	/**
	 * @return DataSource
	 * @throws DataManagerException
	 */
	private DataSource createDataSource() throws DataManagerException {
		try {
			Context ctx = new InitialContext();
			DataSource ds = (DataSource) ctx.lookup("java:jboss/OracleDS");
			return ds;
		} catch (NamingException e) {
			throw new DataManagerException("Failed to create datasource", e);
		}
	}

	public DataSource getDataSource() {
		return ds;
	}

}
