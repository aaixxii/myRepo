package jp.co.nec.aim.dm.util;

import java.io.File;
import java.io.IOException;
import java.sql.Types;
import java.util.Date;

import jp.co.nec.aim.dm.properties.DynamicProperties;
import jp.co.nec.aim.dm.properties.DynamicPropertyNames;
import jp.co.nec.aim.helper.SegmentFileConstants;

import org.apache.commons.io.FileUtils;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.support.SqlLobValue;

public class SegmentUtil {

	public static void insertSegmentRecords(int records, int unit,
			int templateSize, JdbcTemplate jdbcTemplate) {
		insertSegmentRecords(records, unit, templateSize, jdbcTemplate, 1L);
	}

	/**
	 * 
	 * @param records
	 *            number of records in PERSON_BIOMETRICS
	 * @param unit
	 *            records per segments.
	 * @param templateSize
	 *            number of templates in 1 segment
	 * @param jdbcTemplate
	 */
	public static void insertSegmentRecords(int records, int unit,
			int templateSize, JdbcTemplate jdbcTemplate, long bioIdStart) {
		{
			// INSERT into PERSON_BIOMETRICS, container_id=1
			String bioSql = "insert into person_biometrics (BIOMETRICS_ID, EXTERNAL_ID, "
					+ "BIOMETRIC_DATA, BIOMETRIC_DATA_LEN, registed_ts, CORRUPTED_FLAG, "
					+ "EVENT_ID, container_id) values(?, ?, ?, ?, ?, 0, 1, 1)";
			int[] argTypes = new int[] { Types.BIGINT, Types.CHAR, Types.BLOB,
					Types.BIGINT, Types.BIGINT };
			byte[] binary = new byte[templateSize];
			for (long id = bioIdStart; id < bioIdStart + records; id++) {
				Object[] args = new Object[] { new Long(id), Long.toString(id),
						new SqlLobValue(binary), new Long(binary.length),
						new Date().getTime() };
				jdbcTemplate.update(bioSql, args, argTypes);
			}
		}
		{
			// INSERT into SEGMENTS, container_id=1
			String segmentSql = "insert into segments (SEGMENT_ID, container_id, "
					+ "BIO_ID_START, BIO_ID_END, BINARY_LENGTH_COMPACTED, RECORD_COUNT, "
					+ "VERSION, REVISION, BINARY_LENGTH_UNCOMPACTED) "
					+ "values(?, 1, ?, ?, ?, ?, ?, 1, ?)";
			int[] argTypes = new int[] { Types.BIGINT, Types.BIGINT,
					Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT,
					Types.BIGINT };
			long start = bioIdStart;
			long end;
			int segmentId = 1;
			while (start < bioIdStart + records) {
				end = start + unit - 1;
				if (records < end) {
					end = records;
				}
				long segmentSize = SegmentFileConstants.SEGMENT_HEADER_SIZE
						+ (templateSize + SegmentFileConstants.SIZE_TEMPLATE_HEADER_CHECKSUM)
						* (end - start + 1);
				Object[] args = new Object[] { new Long(segmentId), // SEGMENT_ID
						new Long(start), // BIO_ID_START
						new Long(end), // BIO_ID_END
						new Long(segmentSize), // BINARY_LENGTH_COMPACTED
						new Long(end - start + 1), // RECORD_COUNT
						new Long(end - start), // VERSION
						new Long(segmentSize) };
				jdbcTemplate.update(segmentSql, args, argTypes);
				for (long bioId = start; bioId <= end; bioId++) {
					insertSegmentChangeLog(segmentId, jdbcTemplate, bioId);
				}
				start += unit;
				segmentId++;
			}
		}
		jdbcTemplate.update("commit");
	}

	public static void cleanSegmentFile() {
		String directory = DynamicProperties.getInstance().getPropertyValue(
				DynamicPropertyNames.SEGMENT_FILE_DIRECTORY);
		File dir = new File(directory);
		File[] files = dir.listFiles();
		for (File file : files) {
			if (file.isFile()) {
				String name = file.getName();
				if (name.startsWith(".")) {
					file.delete();
				} else {
					int index = name.indexOf(".");
					String header = name.substring(0, index);
					if (header.matches("[0-9]+")) {
						file.delete();
					}
				}
			}
		}
	}

	public static void addTemplate(long segmentId, int templateSize,
			JdbcTemplate jdbcTemplate) {
		// add record to PERSON_BIOMETRICS
		long maxBioId = addPersonBiometrics(templateSize, jdbcTemplate);
		updateSegment(jdbcTemplate, segmentId, maxBioId, templateSize);
		// add record to SEGMENT_CHANGE_LOG
		insertSegmentChangeLog(segmentId, jdbcTemplate, maxBioId);
	}

	private static void updateSegment(JdbcTemplate jdbcTemplate,
			long segmentId, long bioId, int templateSize) {
		int version = jdbcTemplate
				.queryForInt("select version from segments where segment_id = "
						+ segmentId);
		version++;
		long recordCount = jdbcTemplate
				.queryForLong("select record_count from segments where segment_id = "
						+ segmentId);
		recordCount++;
		long length = jdbcTemplate
				.queryForLong("select binary_length_uncompacted from segments where segment_id = "
						+ segmentId);
		length += (templateSize + SegmentFileConstants.SIZE_TEMPLATE_HEADER_CHECKSUM);
		String sql = "update segments set version=" + version
				+ ", record_count=" + recordCount + ", bio_id_end=" + bioId
				+ ", binary_length_uncompacted=" + length
				+ " where segment_id=" + segmentId;
		jdbcTemplate.update(sql);
	}

	private static long addPersonBiometrics(int templateSize,
			JdbcTemplate jdbcTemplate) {
		String maxBioIdSql = "select MAX(BIOMETRICS_ID) from PERSON_BIOMETRICS";
		long maxBioId = jdbcTemplate.queryForLong(maxBioIdSql);
		// INSERT into PERSON_BIOMETRICS, container_id=1
		maxBioId++;
		String bioSql = "insert into person_biometrics (BIOMETRICS_ID, EXTERNAL_ID, "
				+ "BIOMETRIC_DATA, BIOMETRIC_DATA_LEN, registed_ts, CORRUPTED_FLAG, "
				+ "EVENT_ID, container_id) values(?, ?, ?, ?, ?, 0, 1, 1)";
		int[] argTypes = new int[] { Types.BIGINT, Types.CHAR, Types.BLOB,
				Types.BIGINT, Types.BIGINT };
		byte[] binary = new byte[templateSize];
		Object[] args = new Object[] { new Long(maxBioId),
				Long.toString(maxBioId), new SqlLobValue(binary),
				new Long(binary.length), new Date().getTime() };
		jdbcTemplate.update(bioSql, args, argTypes);
		return maxBioId;
	}

	public static void insertSegmentChangeLog(long segmentId,
			JdbcTemplate jdbcTemplate, long bioId) {
		int logcount = jdbcTemplate
				.queryForInt("select count(segment_change_id) from segment_change_log");
		long maxChangeId;
		long maxVersion;
		if (logcount == 0) {
			maxVersion = -1L;
			maxChangeId = 0L;
		} else {
			maxVersion = jdbcTemplate
					.queryForLong("select MAX(SEGMENT_VERSION) from SEGMENT_CHANGE_LOG");
			maxChangeId = jdbcTemplate
					.queryForLong("select MAX(SEGMENT_CHANGE_ID) from SEGMENT_CHANGE_LOG");
		}
		long nextVersion = maxVersion + 1L;
		long nextChangeId = maxChangeId + 1L;

		String logSql = "insert into SEGMENT_CHANGE_LOG (SEGMENT_CHANGE_ID, "
				+ "BIOMETRICS_ID, SEGMENT_ID, SEGMENT_VERSION, CHANGE_TYPE) "
				+ "values(?, ?, ?, ?, 0)";
		jdbcTemplate.update(logSql, new Long(nextChangeId), new Long(bioId),
				new Long(segmentId), new Long(nextVersion));
	}

	public static void createDir() {
		String directory = DynamicProperties.getInstance().getPropertyValue(
				DynamicPropertyNames.SEGMENT_FILE_DIRECTORY);
		File dir = new File(directory);
		try {
			if (!dir.exists()) {
				FileUtils.forceMkdir(dir);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
