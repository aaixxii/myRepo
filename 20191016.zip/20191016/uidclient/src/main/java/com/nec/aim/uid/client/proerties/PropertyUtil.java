package com.nec.aim.uid.client.proerties;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PropertyUtil {
	private static Logger logger = LoggerFactory.getLogger(PropertyUtil.class);
	private String properyFullfileName;
	private Properties prop = new Properties();
	private String errMsg = "IOException occurred while reading propery from xm.client.properties file";

	public PropertyUtil(String properyFullfileName) {
		this.properyFullfileName = properyFullfileName;
	}

	/**
	 * 
	 * @return
	 */
	public Set<String> getAllKeySet() {
		Set<String> keys = new HashSet<String>();
		try (InputStream input = new FileInputStream(properyFullfileName)) {
			prop.load(input);
			Set<Object> sets = prop.keySet();
			Iterator<Object> it = sets.iterator();
			while (it.hasNext()) {
				String tmp = (String) it.next();
				keys.add(tmp);
			}
			return keys;
		} catch (IOException e) {
			logger.error(errMsg, e);
			return null;
		}
	}

	/**
	 * 
	 * @param properName
	 * @return
	 */
	public String getPropertyValue(String name) {
		try (InputStream input = new FileInputStream(properyFullfileName)) {
			prop.load(input);
			return prop.getProperty(name).toString();
		} catch (IOException e) {
			logger.error(errMsg, e);
			return null;
		}
	}

	public Integer getPropertyIntValue(String name) {
		try (InputStream input = new FileInputStream(properyFullfileName)) {
			prop.load(input);
			return Integer.parseInt(prop.getProperty(name));
		} catch (IOException e) {
			logger.error(errMsg, e);
			return null;
		}
	}

	public Long getPropertyLongValue(String name) {
		try (InputStream input = new FileInputStream(properyFullfileName)) {
			prop.load(input);
			return Long.parseLong(prop.getProperty(name));
		} catch (IOException e) {
			logger.error(errMsg, e);
			return null;
		}
	}

	public Map<String, Double> getAllValues() {
		Map<String, Double> results = new HashMap<>();
		Set<String> keys = new HashSet<String>();
		try (InputStream input = new FileInputStream(properyFullfileName)) {
			prop.load(input);
			Set<Object> sets = prop.keySet();
			Iterator<Object> it = sets.iterator();
			while (it.hasNext()) {
				String tmp = (String) it.next();
				keys.add(tmp);
			}
			for (String key : keys) {
				results.put(key, Double.valueOf(prop.getProperty(key)));
			}
		} catch (IOException e) {
			logger.error(errMsg, e);
			return null;
		}
		return results;
	}

	public void setPropertyValue(String name, String value) {
		try (OutputStream output = new FileOutputStream(properyFullfileName)) {
			prop.setProperty(name, value);
			prop.store(output, null);
		} catch (IOException e) {
			logger.error("IOException occurred while setting propery from xm.client.properties file", e);
		}
	}

	public int getPropertyCount() {
		try (InputStream input = new FileInputStream(properyFullfileName)) {
			prop.load(input);
			return prop.size();
		} catch (IOException e) {
			logger.error(errMsg, e);
			return -1;
		}
	}
}
