package com.nec.aim.uid.client.common;

public enum SequenceIdType {
	BATCHJOB_ID(0),
	ENROLLMENT_ID(1),	
	REQUST_ID(2);

	
	private long val;
	
	private  SequenceIdType(long val) {
		this.val = val;		
	}
	
	public long getVal() {
		return val;
	}

}
