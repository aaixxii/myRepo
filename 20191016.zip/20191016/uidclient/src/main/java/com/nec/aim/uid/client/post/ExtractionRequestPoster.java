package com.nec.aim.uid.client.post;

import java.io.IOException;

import com.nec.aim.uid.client.util.ProtobufCreater;
import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;
import com.squareup.okhttp.Response;

import jp.co.nec.aim.message.proto.ExtractService.ExtractRequest;
import jp.co.nec.aim.message.proto.ExtractService.ExtractResponse;

public class ExtractionRequestPoster {
	  private static final MediaType MEDIA_TYPE_PLAINTEXT = MediaType.parse("text/plain; charset=utf-8");
			   
	private ProtobufCreater protobufCreater = new ProtobufCreater();
	
	private ExtractResponse postExtractJob() {
		ExtractRequest extReq = protobufCreater.createExtractRequest();
		OkHttpClient client = new OkHttpClient();
		  Request request = new Request.Builder()
			      .url("http://localhost:8080//AIMExtractService/extract")
			      .post(RequestBody.create(MEDIA_TYPE_PLAINTEXT, extReq.toByteArray()))
			      .build();
		  try {
			Response response = client.newCall(request).execute();
			response.body().bytes();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
	}
	

}
