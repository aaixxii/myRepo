package com.nec.aim.uid.client.main;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.aim.uid.client.manager.UidClientManager;
import com.nec.aim.uid.client.runner.UidJobRunner;

public class UidClientMain {
	private static Logger logger = LoggerFactory.getLogger(UidClientMain.class);
	private static final String START = "start";
	private static final String STOP = "stop";
	
	public static void main(String[] args) {		
		UidClientMain uidMain = new UidClientMain();
		uidMain.handleParameter(args);
	}
	
	private void pringUsage() {
		String lineSeparater = System.getProperties().getProperty("line.separator");
		StringBuilder sb = new StringBuilder();
		sb.append("Usage for start xm client:");
		sb.append(lineSeparater);
		sb.append("XmWebServiceClient start");
		logger.info(sb.toString());		
		sb.delete(0, sb.length());

		sb.append("Usage for stop xm client:");
		sb.append(lineSeparater);
		sb.append("XmWebServiceClient stop");
		logger.info(sb.toString());	
	}
	
	private void handleParameter(String[] args) {
		if (args.length < 1) {
			pringUsage();
			System.exit(0);
		}
		if (START.equals(args[0].toLowerCase())) {
			start();
		} else if (STOP.equals(args[0].toLowerCase())) {
			stop();
		} else {
			pringUsage();
			System.exit(0);
		}
	}
	
	public void start() {
		System.setProperty("file.encoding", "UTF-8");
		UidClientManager clietnManager = UidClientManager.getInstance();			
		if (clietnManager.getMapSize() == 0) {
			if (!clietnManager.getAllProperties()) {	
				String errMsg = "There are some wrong in xm.client.properties. or isn't exist!. stop process!";				
				logger.error(errMsg);			
				System.exit(0);	
			} else {
				
			}			
				
			UidJobRunner.getInstance().run();
			logger.info("XM client is started!");	
			
		}	
	
	}	
	
	public void stop() {
		UidClientManager.getInstance().shutdown();
		UidJobRunner.getInstance().setMustRun(false);			
		logger.info("XM client is stoped!");
		System.exit(0);
	}	

}
