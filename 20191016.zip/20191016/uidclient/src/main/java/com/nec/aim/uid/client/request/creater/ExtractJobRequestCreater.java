package com.nec.aim.uid.client.request.creater;

import static com.nec.aim.uid.client.common.UidClientConstants.EXTRACT_JOB_SETING_FILE_FULL_NAME;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Objects;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.aim.uid.client.common.SequenceIdCreator;
import com.nec.aim.uid.client.common.SequenceIdType;
import com.nec.aim.uid.client.manager.UidClientManager;
import com.nec.aim.uid.client.proerties.PropertyUtil;

import jp.co.nec.aim.message.proto.BatchTypeProto.BatchType;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBiometricElement;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBiometricsData;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBusinessMessage;
import jp.co.nec.aim.message.proto.BusinessMessage.PBParameterGroup;
import jp.co.nec.aim.message.proto.BusinessMessage.PBRequest;
import jp.co.nec.aim.message.proto.BusinessMessage.PBRequestParameter;
import jp.co.nec.aim.message.proto.BusinessMessage.PBRequestParameters;
import jp.co.nec.aim.message.proto.ExtractService.ExtractRequest;

public class ExtractJobRequestCreater {
	private static Logger logger = LoggerFactory.getLogger(ExtractJobRequestCreater.class);		
	private String extJobReqParamFilePath;
	private Properties prop = new Properties();
	public ExtractJobRequestCreater(String extJobReqParamFilePath) {
		this.extJobReqParamFilePath = extJobReqParamFilePath;		
	}
	
	public ExtractRequest createExtractRequest() {
		
		return null;
		
	}
	
	private void  getProperties() {
		
		if (Objects.isNull(extJobReqParamFilePath)) {
			extJobReqParamFilePath = UidClientManager.getInstance().getValue(EXTRACT_JOB_SETING_FILE_FULL_NAME);
		}
		try (InputStream input = new FileInputStream(extJobReqParamFilePath)) {
			prop.load(input);
			Integer currentThreadCount = Integer.valueOf(prop.getProperty("CURRENE_THREAD_COUNT"));
			Long extJobTimeOut = Long.valueOf(prop.getProperty("EXTRACT_JOB_TIME_OUT"));
			Integer total_job_count = Integer.valueOf(prop.getProperty("EXTRACT_JOB_COUNT"));
			String batchJobType = prop.getProperty("BATCH_TYPE");
			String refernceId = prop.getProperty("ENROLLMENT_ID");	
			String imageFileUrl = prop.getProperty("IMAGE_FILE_URL");
			String checkSum = prop.getProperty("CHECKSUM");
			ExtractRequest.Builder extReq = ExtractRequest.newBuilder();
			extReq.setBatchJobId(SequenceIdCreator.createNextSequence(SequenceIdType.BATCHJOB_ID));
			extReq.setType(BatchType.valueOf(batchJobType));
			PBBusinessMessage.Builder extPbMsg = PBBusinessMessage.newBuilder();
			PBRequest.Builder req = PBRequest.newBuilder();
			req.setRequestId(String.valueOf(SequenceIdCreator.createNextSequence(SequenceIdType.REQUST_ID)));
			req.setEnrollmentId(refernceId);
			PBBiometricsData.Builder bioData = PBBiometricsData.newBuilder();
			PBBiometricElement.Builder bioElement = PBBiometricElement.newBuilder();
			bioElement.setFilePath(imageFileUrl);
			bioElement.setChecksum(checkSum);
			bioData.setBiometricElement(bioElement.build());
			req.setBiometricsData(bioData.build());
			PBRequestParameters.Builder extReqParam = PBRequestParameters.newBuilder();
			
			Integer groupNameCount = Integer.valueOf(prop.getProperty("GRtypeOUP_NAME_COUNT"));
			for (int i = 1; i <= groupNameCount; i++) {
				String requestParamters = prop.getProperty("REQUEST_PARAMETER" + i);
				String[] paramArr = requestParamters.split("#");
				String gpName = paramArr[0];
				String keyValusList = paramArr[1];
				String[] keyValueArr = keyValusList.split(",");
				PBParameterGroup.Builder pbPG = PBParameterGroup.newBuilder();
				pbPG.setGroupName(gpName);
				for (int j = 0; j < keyValueArr.length; j++) {
					PBRequestParameter.Builder pbParam = PBRequestParameter.newBuilder();
					String[] tmp = keyValueArr[j].split(":");
					pbParam.setParameterName(tmp[0]);
					pbParam.setParameterValue(tmp[1]);
					pbPG.addRequestParameter(pbParam.build());
				}
				extReqParam.addParameterGroup(pbPG.build());
			}
			
			extReq.addBusinessMessage(extPbMsg.build().toByteString());
			
	
			
		} catch (IOException e) {
			logger.error(errMsg, e);
			return null;
		}
	}
	
	

}
