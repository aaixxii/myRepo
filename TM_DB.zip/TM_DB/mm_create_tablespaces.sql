
spool create_tablespaces.log

WHENEVER OSERROR  EXIT FAILURE;
WHENEVER SQLERROR EXIT SQL.SQLCODE;

accept aim_tbsp_dir char   prompt 'Enter a full path for AIM tablespaces directory (no trailing slashes):';

prompt 
prompt Creating AIM tablespaces...
prompt

CREATE  TABLESPACE AIM_BIOMETRICS_DATA
	DATAFILE 
	'&&aim_tbsp_dir/aim_biometrics01.dbf' SIZE 1G  REUSE  AUTOEXTEND ON NEXT 1G MAXSIZE UNLIMITED;


CREATE  TABLESPACE AIM_BIOMETRICS_LOB_DATA
	DATAFILE 
	'&&aim_tbsp_dir/aim_biometrics_lob01.dbf' SIZE 1G  REUSE  AUTOEXTEND ON NEXT 1G MAXSIZE UNLIMITED;


CREATE  TABLESPACE AIM_MAIN_DATA
	DATAFILE 
	'&&aim_tbsp_dir/aim_main_data01.dbf' SIZE 1G  REUSE  AUTOEXTEND ON NEXT 1G MAXSIZE UNLIMITED;


CREATE  TABLESPACE AIM_SEARCH_JOB_DATA
	DATAFILE 
	'&&aim_tbsp_dir/aim_search_job_data01.dbf' SIZE 1G  REUSE  AUTOEXTEND ON NEXT 1G MAXSIZE UNLIMITED;


CREATE  TABLESPACE AIM_SEARCH_JOB_LOB_DATA
	DATAFILE 
	'&&aim_tbsp_dir/aim_search_job_lob_data01.dbf' SIZE 1G  REUSE  AUTOEXTEND ON NEXT 1G MAXSIZE UNLIMITED;


CREATE  TABLESPACE AIM_EXTRACT_JOB_DATA
	DATAFILE 
	'&&aim_tbsp_dir/aim_extract_job_data01.dbf' SIZE 1G  REUSE  AUTOEXTEND ON NEXT 1G MAXSIZE UNLIMITED;


CREATE  TABLESPACE AIM_EXTRACT_JOB_LOB_DATA
	DATAFILE 
	'&&aim_tbsp_dir/aim_extract_job_lob_data01.dbf' SIZE 1G  REUSE  AUTOEXTEND ON NEXT 1G MAXSIZE UNLIMITED;


@@alter_default_profile.sql

exit success;


