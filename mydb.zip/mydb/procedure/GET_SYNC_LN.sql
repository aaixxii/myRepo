###############################################################################
#
#   キュー論理番号生成プロシージャ
#
#   2018.08.15  NEC okano  GCデータ連携用に新規作成
#
###############################################################################
DROP PROCEDURE IF EXISTS GET_SYNC_LN;

    delimiter //
    CREATE PROCEDURE GET_SYNC_LN
    (
        OUT var_ln CHAR(20)
    )
    BEGIN
        DECLARE var_seq char(6);

        CALL GET_SEQUENCE('LN_QUE_MST_SYNC', var_seq);

        # 論理番号生成
        select concat(date_format(now(),'%Y%m%d%H%i%s'), var_seq) into var_ln;

    END;
    //
    delimiter ;
