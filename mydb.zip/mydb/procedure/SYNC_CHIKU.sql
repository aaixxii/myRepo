###############################################################################
#
#   警備先地区同期キュー登録プロシージャ
#
#   2018.08.15  NEC okano  GCデータ連携用に新規作成
#
###############################################################################
DROP PROCEDURE IF EXISTS SYNC_CHIKU;

    delimiter //
    CREATE PROCEDURE SYNC_CHIKU
    (
        IN var_tr_type CHAR(1),
        IN var_entry_sts CHAR(1),
        IN var_ln_chiku CHAR(20),
        IN var_gouki CHAR(7),
        IN var_sub_addr CHAR(4),
        IN var_jigyou_cd CHAR(6),
        IN var_id CHAR(20),
        IN var_name CHAR(80),
        IN var_trigger CHAR(80)
    )
    BEGIN
        DECLARE var_gc_cd char(4);
        DECLARE var_flg_sync char(1);

        # GCコードとマスタ同期フラグを取得する
        select a.GC_CD, a.SYNC_ABL_FLG
        into var_gc_cd, var_flg_sync
        from commondb.K_GC a
        inner join commondb.K_JIGYOU b on a.GC_CD = b.GC_CD
        where b.JIGYOU_CD = var_jigyou_cd;

        # GCコードを取得できた場合
        IF var_gc_cd IS NOT NULL AND var_gc_cd != '' THEN

            # マスタ同期フラグが「1」の場合
            IF var_flg_sync = '1' THEN

                # 号機番号を取得できた場合
                IF var_gouki IS NOT NULL AND var_gouki != '' THEN

                    # サブアドレスを取得できた場合
                    IF var_sub_addr IS NOT NULL THEN

                        # 論理番号生成
                        CALL GET_SYNC_LN(@ln);

                        # キュー登録
                        CALL ENQUE_MST_SYNC
                        (
                            @ln,
                            '000',
                            var_tr_type,
                            var_entry_sts,
                            var_gc_cd,
                            var_trigger
                        );

                        insert into W_CHIKU_SYNC values
                        (
                            @ln,
                            var_ln_chiku,
                            var_gouki,
                            var_sub_addr,
                            'TRIGGER',
                            var_trigger,
                            now(),
                            var_id,
                            var_name,
                            now()
                        );

                    END IF;
                END IF;
            END IF;
        END IF;
    END;
    //
    delimiter ;
