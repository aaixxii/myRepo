###############################################################################
#
#   警報任務区分同期キュー登録プロシージャ
#
#   2018.05.15  NEC okano  GCデータ連携用に新規作成
#
###############################################################################
DROP PROCEDURE IF EXISTS SYNC_NINMU;

    delimiter //
    CREATE PROCEDURE SYNC_NINMU
    (
        IN var_tr_type CHAR(1),
        IN var_entry_sts CHAR(1),
        IN var_ln_chiku CHAR(20),
        IN var_gouki char(7),
        IN var_sd_dev_num CHAR(11),
        IN var_id CHAR(20),
        IN var_name CHAR(80),
        IN var_trigger CHAR(80)
    )
    BEGIN
        DECLARE var_gc_cd char(4);
        DECLARE var_flg_sync char(1);
--        DECLARE var_gouki char(7);
        DECLARE var_sub_addr char(4);

        # GCコードとマスタ同期フラグと号機番号とサブアドレスを取得する
--        select a.GC_CD, a.SYNC_ABL_FLG, f.GOUKI, d.SUB_ADDR
--        into var_gc_cd, var_flg_sync, var_gouki, var_sub_addr
        select a.GC_CD, a.SYNC_ABL_FLG, d.SUB_ADDR
        into var_gc_cd, var_flg_sync, var_sub_addr
        from commondb.K_GC a
        inner join commondb.K_JIGYOU b on a.GC_CD = b.GC_CD
        inner join R_KEIBI c on b.JIGYOU_CD = c.JISSHI_JIGYOU_CD
        inner join R_KB_CHIKU d on c.LN_KEIBI = d.LN_KEIBI
--        inner join R_KEIBI_CTL_DEV e on d.LN_KEIBI = e.LN_KEIBI
--        inner join R_CTL_DEV f on e.LN_CTL_DEV = f.LN_CTL_DEV
        where d.LN_KB_CHIKU = var_ln_chiku;

        # GCコードを取得できた場合
        IF var_gc_cd IS NOT NULL AND var_gc_cd != '' THEN

            # マスタ同期フラグが「1」の場合
            IF var_flg_sync = '1' THEN

                # 号機番号を取得できた場合
                IF var_gouki IS NOT NULL AND var_gouki != '' THEN

                    # サブアドレスを取得できた場合
                    IF var_sub_addr IS NOT NULL THEN

                        # 論理番号生成
                        CALL GET_SYNC_LN(@ln);

                        # キュー登録
                        CALL ENQUE_MST_SYNC
                        (
                            @ln,
                            '003',
                            var_tr_type,
                            var_entry_sts,
                            var_gc_cd,
                            var_trigger
                        );

                        insert into W_NINMU_SYNC values
                        (
                            @ln,
                            var_ln_chiku,
                            var_gouki,
                            var_sub_addr,
                            'TRIGGER',
                            var_trigger,
                            now(),
                            var_id,
                            var_name,
                            now()
                        );

                        insert into W_NINMU_SYNC_DEV_HIST values
                        (
                            @ln,
                            var_ln_chiku,
                            var_tr_type,
                            var_sd_dev_num,
                            'TRIGGER',
                            var_trigger,
                            now(),
                            var_id,
                            var_name,
                            now()
                        );

                    END IF;
                END IF;
            END IF;
        END IF;
    END;
    //
    delimiter ;
