###############################################################################
#
#   画像コマンドキュー(ワーク)(W_QUE_IMG_CMD)登録プロシージャ
#
#   2019.02.14  NEC   次期警備用に新規作成
#
###############################################################################
DROP PROCEDURE IF EXISTS SYNC_WQUEIMGCMD;

    DELIMITER //
    CREATE PROCEDURE SYNC_WQUEIMGCMD
    (
        IN var_ln_que_img_cmd CHAR(20),
        IN var_in_ctl_id CHAR(15),
        IN var_image_req_kbn CHAR(1),
        IN var_ln_dev CHAR(20)
    )
    BEGIN
        DECLARE var_ctl_id CHAR(15);
        DECLARE var_cnt_rec int;
        
        IF var_in_ctl_id IS NOT NULL AND var_in_ctl_id != '' THEN
            # 送信機IDが設定されている場合
            SET var_ctl_id = var_in_ctl_id;
        ELSE
            # 送信機IDが設定されていない場合
            # 設置機器論理番号から送信機IDを取得する
            SELECT CTL.SERIAL_NUM INTO var_ctl_id
            FROM R_CTL_DEV CTL
            WHERE CTL.LN_CTL_DEV = (
            SELECT DISTINCT
                DEVDEV.LN_CTL_DEV
            FROM
                R_DEV_DEV DEVDEV
            WHERE
                DEVDEV.LN_DEV_PAR = var_ln_dev
                    OR DEVDEV.LN_DEV_CHI = var_ln_dev);
        END IF;

        IF var_ctl_id IS NOT NULL AND var_ctl_id != '' THEN
            # ワークに同一情報が登録されていないか確認する
            SELECT COUNT(*) INTO var_cnt_rec
            FROM W_QUE_IMG_CMD
            WHERE LN_QUE_IMG_CMD = var_ln_que_img_cmd
            AND CTL_ID = var_ctl_id
            AND IMAGE_REQ_KBN = var_image_req_kbn;
            # 同一情報が存在する場合は登録しない
            IF var_cnt_rec = 0 THEN
                INSERT INTO W_QUE_IMG_CMD
                VALUES (
                    var_ln_que_img_cmd,
                    var_ctl_id,
                    var_image_req_kbn,
                    null
                );
            END IF;
        END IF;
    END;
    //
    DELIMITER ;
