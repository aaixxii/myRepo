###############################################################################
#
#   マスタ同期キュー登録プロシージャ
#
#   2015.08.01  NEC okano  GCデータ連携用に新規作成
#
###############################################################################
DROP PROCEDURE IF EXISTS ENQUE_MST_SYNC;

    delimiter //
    CREATE PROCEDURE ENQUE_MST_SYNC
    (
        IN var_ln_que CHAR(20),
        IN var_tr_cd CHAR(3),
        IN var_tr_type CHAR(1),
        IN var_entry_sts CHAR(1),
        IN var_gc_cd CHAR(4),
        IN var_trigger CHAR(80)
    )
    BEGIN

        # キュー登録
        insert into W_QUE_MST_SYNC values
        (
            var_ln_que,
            var_tr_cd,
            var_tr_type,
            '0',
            var_entry_sts,
            var_gc_cd,
            0,
            now(),
            null,
            'TRIGGER',
            var_trigger,
            now(),
            'TRIGGER',
            var_trigger,
            now()
        );

    END;
    //
    delimiter ;
