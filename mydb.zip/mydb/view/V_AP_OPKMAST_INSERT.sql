###############################################################################
#
#   警備先マスタ(OPKMAST)インサート用ビュー
#
#   2018.05.15  NEC Fujita  次期警備用に新規作成
#   2019.04.17  NEC Kanazu  次期連携項目見直し
#   2019.05.02  NEC Kanazu  次期連携項目見直し
#
###############################################################################
DROP VIEW IF EXISTS V_AP_OPKMAST_INSERT;
CREATE VIEW V_AP_OPKMAST_INSERT AS
select
    a.LN_KB_CHIKU,                                                       -- R_警備先地区.LN_警備先地区論理番号(検索用)
    null                                        as ＳＧＳ論理番号,       -- (プログラム側で値を設定)
    null                                        as 警備先世代番号,       -- (プログラム側で値を設定)
    null                                        as ＧＣ番号,             -- (プログラム側で値を設定)
    d.GOUKI                                     as 号機番号,             -- R_警備先.号機番号
    c.DENKEI                                    as 電計番号,             -- R_電計番号管理.電計番号
    ' '                                         as コスモ契約用電計番号,
    ' '                                         as 綜管防災清掃用電計番号,
    ' '                                         as 綜管防災防災用電計番号,
    a.SUB_ADDR                                  as サブアドレス,         -- R_警備先地区.サブアドレス
    'M'                                         as 中断マーク,           -- R_警備先.運用状態
    substr(b.KEIBI_PNAME1_KANA, 1, 6)           as 警備先索引,           -- 警備先.警備先通称１カナ
    b.KEIBI_NAME1                               as 警備先名１,           -- R_警備先.警備先名称
    substr(b.KEIBI_NAME1_KANA, 1, 80)           as 警備先名１カナ,
    b.KEIBI_NAME2                               as 警備先名２,
    substr(b.KEIBI_NAME2_KANA, 1, 40)           as 警備先名２カナ,
    b.KEIBISAKI_ABBR_NM                         as 略称名称,             -- R_警備先.警備先名称
    ' '                                         as 略称名称カナ,
    ' '                                         as カナ略称名称,
    b.ADDR_CD                                   as 住所コード,           -- 警備先.住所コード
    b.POST_NUM                                  as 郵便番号,             -- 警備先.郵便番号
    b.KEIBI_ADDR_1                              as 所在地１,             -- R_警備先.警備先住所１
    ' '                                         as 所在地１カナ,
    b.KEIBI_ADDR_2                              as 所在地２,             -- R_警備先.警備先住所１
    ' '                                         as 所在地２カナ,
    ' '                                         as ビル名索引,
    ' '                                         as 個別索引,
    a.SD_KOBETU_NM                              as 個別名称,             -- R_警備先地区.個別名称
    '0'                                         as 警備先電話区分,
    case
        when a.SUB_ADDR = '    ' then replace(b.KEIBI_TEL_NUM,'-','')
        else ' '
    end
                                                as 警備先電話番号,       -- R_警備先.警備先電話番号(サブアドレス'    'のみ連携)
    ' '                                         as 検索用警備先電話番号,
    b.FIRE_NUM                                  as 消防認定番号,         -- 警備先.消防認定番号
    ' '                                         as 業種コード,           -- 警備先.業種_ID
    ' '                                         as 運用業種コード,
    substr(f.NM, 1, 9)                          as 業種,                 -- 業務マスター.業務名
    case
--        when b.FLG_GSHS = '0' then
        when b.GSHS_FLG = '0' then
            case
                when d.SD_LINE_KIND = '0' then ' '                       -- '回線:--/--'
                when d.SD_LINE_KIND = '1' then '61400'                   -- '回線:3G/--'
                when d.SD_LINE_KIND = '2' then '61400'                   -- '回線:IP/3G'
                when d.SD_LINE_KIND = '3' then '09700'                   -- '回線:ｱﾅﾛｸﾞ/3G'
                when d.SD_LINE_KIND = '4' then '61400'                   -- '回線:3G/ｱﾅﾛｸﾞ'
                when d.SD_LINE_KIND = '5' then '61400'                   -- '回線:IP/--'
                when d.SD_LINE_KIND = '6' then '09700'                   -- '回線:ｱﾅﾛｸﾞ/--'
                else ' '
            end
--        when b.FLG_GSHS = '1' then '61500'
        when b.GSHS_FLG = '1' then '61500'
--        when b.FLG_GSHS = '2' then
        when b.GSHS_FLG = '2' then
            case
                when d.SD_LINE_KIND = '0' then ' '                       -- '回線:--/--'
                when d.SD_LINE_KIND = '1' then '61600'                   -- '回線:3G/--'
                when d.SD_LINE_KIND = '2' then '61600'                   -- '回線:IP/3G'
                when d.SD_LINE_KIND = '3' then '09800'                   -- '回線:ｱﾅﾛｸﾞ/3G'
                when d.SD_LINE_KIND = '4' then '61600'                   -- '回線:3G/ｱﾅﾛｸﾞ'
                when d.SD_LINE_KIND = '5' then '61600'                   -- '回線:IP/--'
                when d.SD_LINE_KIND = '6' then '09800'                   -- '回線:ｱﾅﾛｸﾞ/--'
                else ' '
            end
        else ' '
    end
                                                as 機種,                 -- R_警備先.GSHSフラグ,R_制御装置.SD回線種別
    case
--        when b.FLG_GSHS = '0' then 'A'
--        when b.FLG_GSHS = '1' then 'D'
--        when b.FLG_GSHS = '2' then 'A'
        when b.GSHS_FLG = '0' then 'A'
        when b.GSHS_FLG = '1' then 'D'
        when b.GSHS_FLG = '2' then 'A'
        else ' '
    end
                                                as 契約種別,             -- R_警備先.GSHSフラグ
    'F'                                         as 綜警ＫＢ,
    ' '                                         as 特約事項,
    b.ROTEI                                     as 路程,                 -- 警備先.路程
    substr(b.BLD_STAT, 1, 30)                   as 建物状況,
    ' '                                         as 警備区域,
    '0'                                         as 管理電話区分,
    ' '                                         as 管理電話番号,
    ' '                                         as 検索用管理電話番号,
    ifnull(b.POLI_CALL_FLG, '0')                as 警察通報,             -- 警備先.警察通報フラグ
    ifnull(b.FIRE_CALL_FLG, '0')                as 消防通報,             -- 警備先.消防通報フラグ
    '0'                                         as Ｆ０監視,
    ' '                                         as Ｆ０監視タイマ,
    ' '                                         as 監視開始時間,
    ' '                                         as 監視終了時間,
    '1'                                         as 常時監視日フラグ,
    '1111111'                                   as 常時監視曜日,
    '0'                                         as Ｎ０監視,
    '0'                                         as ＫＦ監視,
    '0'                                         as ＫＮ監視,
    '0'                                         as 組込区分,
    ' '                                         as 組込番号,
    DATE_FORMAT(b.START_KEIBI_DATE, '%Y%m%d')   as 警備開始,             -- 警備先.警備開始日
    '0'                                         as Ｆ０放置,
    '0'                                         as 退館確認フラグ,
    ' '                                         as 検索指定,
    '0'                                         as 警備先種別,
    ' '                                         as 店舗番号,
    '0'                                         as 月報提出,
    '0'                                         as ＭＳ送信,
    '0'                                         as 綜警ネット信号送信,
    '0'                                         as 他契約種別,
    '0'                                         as シャッタマーク,
    '0'                                         as 入館タイマフラグ,
    ' '                                         as 入館タイマ値,
    '0'                                         as 退館タイマフラグ,
    ' '                                         as 退館タイマ値,
    '0'                                         as 終了タイマフラグ,
    ' '                                         as 終了タイマ値,
    '0'                                         as ＳＲＴフラグ,
    ' '                                         as ＳＲＴ電話番号,
    ' '                                         as 検索用ＳＲＴ電話番号,
    ' '                                         as ＳＲＴサービス開始日,
    null                                        as 中断再開日付,         -- (プログラム側で値を設定)
    '0'                                         as 鍵無し対応フラグ,
    '0'                                         as 本鍵有無フラグ,
    '0'                                         as コスモ鍵有無フラグ,
    '0'                                         as 予備鍵有無フラグ,
    null                                        as 更新日,               -- (プログラム側で値を設定)
    ' '                                         as ＫＦ監視タイマ,
    '9'                                         as 警備先ランクコード,
    null                                        as コース番号,
    null                                        as 事業所コード
from
    R_KB_CHIKU a
    inner join R_KEIBI b on a.LN_KEIBI = b.LN_KEIBI
    inner join R_KEIBI_CTL_DEV e on b.LN_KEIBI = e.LN_KEIBI
    inner join R_DENKEI_MNG c on b.LN_KEIBI = c.LN_KEIBI
    left join R_CTL_DEV d on e.LN_CTL_DEV = d.LN_CTL_DEV
    left join g6db.M_GYOUSYU f on b.GYOUSYU_ID = f.GYOUSYU_ID       -- 業務マスター
where
    c.LAST_FLG = 1;
