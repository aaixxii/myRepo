﻿###############################################################################
#
#   緊連先名簿マスタ(KRENMEIBOM)同居家族インサート用ビュー
#
#   2018.05.15  NEC Fujita  次期警備用に新規作成
#
###############################################################################
DROP VIEW IF EXISTS V_AP_KRENMEIBOM_DOKYO_INSERT;
CREATE VIEW V_AP_KRENMEIBOM_DOKYO_INSERT AS
select
    a.LN_KB_CHIKU,                                                       -- R_警備先地区.LN_警備先地区論理番号(検索用)
    null                                        as ＳＧＳ論理番号,       -- (プログラム側で値を設定)
    null                                        as 頁番号,               -- (プログラム側で値を設定)
    null                                        as 世代番号,             -- (プログラム側で値を設定)
    concat(
        ifnull(date_format(b.MEIBO_DTL_UPD_TS,'%Y/%m/%d'),date_format(now(),'%Y/%m/%d')),
        ' ',
        case
            when b.MEIBO_UPD_USER_KIND = '1' then 'お客様訂正'
            when b.MEIBO_UPD_USER_KIND = '2' then 'お客様訂正'
            when b.MEIBO_UPD_USER_KIND = 'A' then 'ALSOK訂正'
            else ' '
        end
    )
                                                as 緊連先名簿名称,       -- R_緊急連絡先名簿_同居家族.名簿更新者種別
    ' '                                         as 連絡者特記事項,       -- GC緊急連絡先名簿_同居家族1番目の特記事項
    ' '                                         as 連絡者特記事項２,     -- GC緊急連絡先名簿_同居家族2番目の特記事項
    null                                        as 更新日                -- (プログラム側で値を設定)
from
    R_KB_CHIKU a
    left join R_KNRN_MEIBO_DOKYO b on a.LN_KB_CHIKU = b.LN_KB_CHIKU;
