###############################################################################
#
#   緊連先連絡者マスタ(KRENNAMEM)インサート用ビュー
#
#   2014.08.01  NEC Kobayashi  GCデータ連携用に新規作成
#
###############################################################################
DROP VIEW IF EXISTS V_AP_KRENNAMEM_INSERT;
CREATE VIEW V_AP_KRENNAMEM_INSERT AS
select
    a.LN_KB_CHIKU,                                                       -- R_警備先地区.LN_警備先地区論理番号(検索用)
    d.ORDER_NUM,                                                         -- R_緊急連絡先名簿詳細.表示順(検索用)
    null                                        as ＳＧＳ論理番号,       -- (プログラム側で値を設定)
    null                                        as 頁番号,               -- (プログラム側で値を設定)
    null                                        as 順位,                 -- (プログラム側で値を設定)
    null                                        as 世代番号,             -- (プログラム側で値を設定)
    d.YAKUSYOKU                                 as 役職,                 -- R_緊急連絡先名簿詳細.役職／関係
    d.NM                                        as 氏名,                 -- R_緊急連絡先名簿詳細.緊急連絡者氏名
    d.NM_KANA                                   as 氏名カナ,             -- R_緊急連絡先名簿詳細.緊急連絡者氏名_カナ
    '0'                                         as 電話区分,
    replace(d.TEL_NUM_1,'-','')                 as 電話番号,             -- R_緊急連絡先名簿詳細.緊急連絡者電話番号
    replace(d.TEL_NUM_2,'-','')                 as 検索用電話番号,       -- R_緊急連絡先名簿詳細.緊急連絡者電話番号
    null                                        as 更新日                -- (プログラム側で値を設定)
from
    R_KB_CHIKU a
    inner join R_KB_CHIKU_KNRN_MEIBO_KANKEI b on a.LN_KB_CHIKU = b.LN_KB_CHIKU
    inner join R_KB_CHIKU_KNRN_MEIBO c on b.LN_KB_CHIKU_KNRN_MEIBO_KANKEI = c.LN_KB_CHIKU_KNRN_MEIBO_KANKEI
    inner join R_KB_CHIKU_KNRN_MEIBO_DTL d on c.LN_KB_CHIKU_KNRN_MEIBO = d.LN_KB_CHIKU_KNRN_MEIBO;
