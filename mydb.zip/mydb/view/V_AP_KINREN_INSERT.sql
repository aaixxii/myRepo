﻿###############################################################################
#
#   緊急連絡先マスタ(KINREN)インサート用ビュー
#
#   2018.05.15  NEC Fujita  次期警備用に新規作成
#   2019.05.02  NEC Kanazu  警察・消防の情報を追加
#   2019.05.21  NEC Ishi    統轄窓口の情報を追加
#
###############################################################################
DROP VIEW IF EXISTS V_AP_KINREN_INSERT;
CREATE VIEW V_AP_KINREN_INSERT AS
select
    a.LN_KB_CHIKU,                                                         -- R_警備先地区.LN_警備先地区論理番号(検索用)
    null                                          as ＳＧＳ論理番号,       -- (プログラム側で値を設定)
    null                                          as 緊連世代番号,         -- (プログラム側で値を設定)
    ' '                                           as 連絡区分,
    ifnull(d.KEIYK_NM,' ')                        as 管理会社名称,         -- R_契約先.契約先名称
    ' '                                           as 管理会社名称カナ,
    '0'                                           as 管理会社電話区分,
    replace(ifnull(d.KEIYK_TEL_NUM,' '),'-','')   as 管理会社電話番号,     -- R_契約先.契約先電話番号
    ifnull(e.TOUKATU_NM,' ')                      as 統轄窓口名称,         -- R_緊急連絡先.統括窓口名称
    ifnull(e.TOUKATU_ADDR,' ')                    as 統轄窓口所在地,       -- R_緊急連絡先.統括窓口所在地
    '0'                                           as 統轄窓口電話区分,
    replace(ifnull(e.TOUKATU_TEL_NUM,' '),'-','') as 統轄窓口電話番号,     -- R_緊急連絡先.統括窓口電話番号
    null                                          as 指定連絡先,           -- (プログラム側で値を設定)
    ' '                                           as 指定連絡先特記事項,
    substring(f.NM, 1, 10)                        as 警察所轄署名,
    ' '                                           as 警察電話区分,
    replace(f.TEL_NUM,'-','')                     as 警察電話番号,
    substring(f.TOKKI, 1, 16)                     as 警察特記事項,
    ' '                                           as 警察所轄署名その他,
    ' '                                           as 警察電話区分その他,
    ' '                                           as 警察電話番号その他,
    ' '                                           as 警察特記事項その他,
    substring(g.NM, 1, 10)                        as 消防所轄署名,
    ' '                                           as 消防電話区分,
    replace(g.TEL_NUM,'-','')                     as 消防電話番号,
    substring(g.TOKKI, 1, 16)                     as 消防特記事項,
    ' '                                           as 消防所轄署名その他,
    ' '                                           as 消防電話区分その他,
    ' '                                           as 消防電話番号その他,
    ' '                                           as 消防特記事項その他,
    e.KEIYAKU_TANTO_NM                            as 契約先担当者,         -- R_緊急連絡先名簿.担当者
    ' '                                           as 契約先担当者カナ,
    ' '                                           as 綜警担当者,
    b.JUCHU_JIGYOU_CD                             as 営業窓口事業所コード, -- R_警備先.受注事業所コード
    ' '                                           as 営業担当者,
    null                                          as 更新日                -- (プログラム側で値を設定)
from
    R_KB_CHIKU a
    inner join R_KEIBI b on a.LN_KEIBI = b.LN_KEIBI and b.DEL_FLG = '0'
    inner join R_KEIYK_BUKKEN c on c.LN_BUKKEN = b.LN_BUKKEN and c.DEL_FLG = '0'
    inner join R_KEIYK d on c.LN_KEIYK = d.LN_KEIYK and d.DEL_FLG = '0'
    inner join R_KB_CHIKU_KNRN e on a.LN_KB_CHIKU = e.LN_KB_CHIKU and e.DEL_FLG = '0'
    left join R_KB_CHIKU_POLIFIRE f on f.LN_KB_CHIKU = a.LN_KB_CHIKU and f.KIND = '0' and  f.DEL_FLG = '0'
    left join R_KB_CHIKU_POLIFIRE g on g.LN_KB_CHIKU = a.LN_KB_CHIKU and g.KIND = '1' and  g.DEL_FLG = '0';
