﻿###############################################################################
#
#   W_マスタ同期キュー(W_QUE_MST_SYNC)セレクト用ビュー
#
#   2014.05.15  NEC Fujita  次期警備用に新規作成
#
###############################################################################
DROP VIEW IF EXISTS V_AP_QUE_MST_SYNC;
CREATE VIEW V_AP_QUE_MST_SYNC AS
select
    a.LN_QUE_MST_SYNC   as LN_QUE_MST_SYNC,
    a.TR_CD             as TR_CD,
    a.TR_TYPE           as TR_TYPE,
    a.GC_NUM            as GC_NUM,
    a.STS               as STS,
    a.ENTRY_STS         as ENTRY_STS,
    a.RETRY_NUM         as RETRY_NUM,
    a.RETRY_MSG_TS      as RETRY_MSG_TS,
    a.MESSAGE           as MESSAGE,
    a.UPDATE_TS         as UPDATE_TS,
    b.LN_KB_CHIKU       as KB_CHIKU,
    b.GOUKI             as KB_GOUKI,
    b.SUB_ADDR          as KB_SUB_ADDR,
    c.LN_KB_CHIKU       as KNRN_CHIKU,
    c.GOUKI             as KNRN_GOUKI,
    c.SUB_ADDR          as KNRN_SUB_ADDR,
    d.LN_KB_CHIKU       as MEIBO_CHIKU,
    d.GOUKI             as MEIBO_GOUKI,
    d.SUB_ADDR          as MEIBO_SUB_ADDR,
    e.LN_KB_CHIKU       as NINMU_CHIKU,
    e.GOUKI             as NINMU_GOUKI,
    e.SUB_ADDR          as NINMU_SUB_ADDR
from
--    E_QUE_MST_SYNC a
--    left join E_CHIKU_SYNC b on a.LN_QUE_MST_SYNC = b.LN_QUE_MST_SYNC
--    left join E_KNRN_SYNC c on a.LN_QUE_MST_SYNC = c.LN_QUE_MST_SYNC
--    left join E_KNRN_MEIBO_SYNC d on a.LN_QUE_MST_SYNC = d.LN_QUE_MST_SYNC
--    left join E_NINMU_SYNC e on a.LN_QUE_MST_SYNC = e.LN_QUE_MST_SYNC;
    W_QUE_MST_SYNC a
    left join W_CHIKU_SYNC b on a.LN_QUE_MST_SYNC = b.LN_QUE_MST_SYNC
    left join W_KNRN_SYNC c on a.LN_QUE_MST_SYNC = c.LN_QUE_MST_SYNC
    left join W_KNRN_MEIBO_SYNC d on a.LN_QUE_MST_SYNC = d.LN_QUE_MST_SYNC
    left join W_NINMU_SYNC e on a.LN_QUE_MST_SYNC = e.LN_QUE_MST_SYNC;
