###############################################################################
#
#   緊連先連絡者マスタ(KRENNAMEM)同居家族インサート用ビュー
#
#   2018.05.15  NEC Fujita  次期警備用に新規作成
#
###############################################################################
DROP VIEW IF EXISTS V_AP_KRENNAMEM_DOKYO_INSERT;
CREATE VIEW V_AP_KRENNAMEM_DOKYO_INSERT AS
select
    a.LN_KB_CHIKU,                                                       -- R_警備先地区.LN_警備先地区論理番号(検索用)
    '1'                                     as ORDER_NUM,                -- 1行目シークレットコード
    null                                    as ＳＧＳ論理番号,           -- (プログラム側で値を設定)
    null                                    as 頁番号,                   -- (プログラム側で値を設定)
    null                                    as 順位,                     -- (プログラム側で値を設定)
    null                                    as 世代番号,                 -- (プログラム側で値を設定)
    case
        when b.SECRET_CD_FLG = '0' then 'ｼｰｸﾚｯﾄｺｰﾄﾞ 無'
        when b.SECRET_CD_FLG = '1' then 'ｼｰｸﾚｯﾄｺｰﾄﾞ 有'
        else ' '
    end
                                            as 役職,                     -- R_緊急連絡先名簿_同居家族.シークレットコードフラグ
    b.SECRET_CD                             as 氏名,                     -- R_緊急連絡先名簿_同居家族.シークレットコード
    b.SECRET_CD_KANA                        as 氏名カナ,                 -- R_緊急連絡先名簿_同居家族.シークレットコード_カナ
    '0'                                     as 電話区分,
    ' '                                     as 電話番号,
    ' '                                     as 検索用電話番号,
    null                                    as 更新日                    -- (プログラム側で値を設定)
from
    R_KB_CHIKU a
    left join R_KNRN_MEIBO_DOKYO b on a.LN_KB_CHIKU = b.LN_KB_CHIKU
union all
select
    a.LN_KB_CHIKU,                                                       -- R_警備先地区.LN_警備先地区論理番号(検索用)
    '2'                                     as ORDER_NUM,                -- 2行目空行
    null                                    as ＳＧＳ論理番号,           -- (プログラム側で値を設定)
    null                                    as 頁番号,                   -- (プログラム側で値を設定)
    null                                    as 順位,                     -- (プログラム側で値を設定)
    null                                    as 世代番号,                 -- (プログラム側で値を設定)
    ' '                                     as 役職,
    ' '                                     as 氏名,
    ' '                                     as 氏名カナ,
    '0'                                     as 電話区分,
    ' '                                     as 電話番号,
    ' '                                     as 検索用電話番号,
    null                                    as 更新日                    -- (プログラム側で値を設定)
from
    R_KB_CHIKU a
    left join R_KNRN_MEIBO_DOKYO b on a.LN_KB_CHIKU = b.LN_KB_CHIKU
union all
select
    a.LN_KB_CHIKU,                                                       -- R_警備先地区.LN_警備先地区論理番号(検索用)
    c.ORDER_NUM + 2                         as ORDER_NUM,                -- R_緊急連絡先名簿詳細_同居家族.表示順(検索用)
    null                                    as ＳＧＳ論理番号,           -- (プログラム側で値を設定)
    null                                    as 頁番号,                   -- (プログラム側で値を設定)
    null                                    as 順位,                     -- (プログラム側で値を設定)
    null                                    as 世代番号,                 -- (プログラム側で値を設定)
    c.ZOKUGARA                              as 役職,                     -- R_緊急連絡先名簿詳細_同居家族.続柄
    c.KNRN_NM                               as 氏名,                     -- R_緊急連絡先名簿詳細_同居家族.緊急連絡者氏名
    c.KNRN_NM_KANA                          as 氏名カナ,                 -- R_緊急連絡先名簿詳細_同居家族.緊急連絡者氏名_カナ
    '0'                                     as 電話区分,
    c.BIRTHDAY                              as 電話番号,                 -- R_緊急連絡先名簿詳細_同居家族.生年月日
    ' '                                     as 検索用電話番号,
    null                                    as 更新日                    -- (プログラム側で値を設定)
from
    R_KB_CHIKU a
    inner join R_KNRN_MEIBO_DOKYO b on a.LN_KB_CHIKU = b.LN_KB_CHIKU
--    inner join R_KNRN_MEIBO_DTL_DOKYO c on b.LN_KNRN_MEIBO_DOKYO = c.LN_KNRN_MEIBO_DOKYO;
    inner join R_KNRN_MEIBO_DTL_DOKYO c on b.LN_KNRN_MEIBO_DOKYO = c.LN_KB_CHIKU_KNRN_MEIBO_KANKEI;
