﻿###############################################################################
#
#   警備先コースマスタ(OPKCMST)アップデート用ビュー
#
#   2018.05.15  NEC Fujita  次期警備用に新規作成
#
###############################################################################
DROP VIEW IF EXISTS V_AP_OPKCMST_UPDATE;
CREATE VIEW V_AP_OPKCMST_UPDATE AS
select
    a.LN_KB_CHIKU,                                                       -- R_警備先地区.LN_警備先地区論理番号(検索用)
    null                                        as ＳＧＳ論理番号,       -- (プログラム側で値を設定)
    null                                        as 世代番号,             -- (プログラム側で値を設定)
    b.AREA_CD                                   as コース番号,           -- R_警備先.エリア（コース）コード
    b.JISSHI_JIGYOU_CD                          as 事業所コード,         -- R_警備先.実施事業所コード
    null                                        as 更新日                -- (プログラム側で値を設定)
from
    R_KB_CHIKU a
    inner join R_KEIBI b on a.LN_KEIBI = b.LN_KEIBI;
