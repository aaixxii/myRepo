###############################################################################
#
#   物件(R_BUKKEN)インサート時トリガ
#
#   2018.05.15  NEC Fujita  次期警備用に新規作成
#   2019.04.16  NEC Kanazu  地区論理番号より号機番号取得するSQLに変更
#
###############################################################################
DROP TRIGGER IF EXISTS TG_R_BUKKEN_AF_INS;

    delimiter //
    CREATE TRIGGER TG_R_BUKKEN_AF_INS AFTER INSERT ON R_BUKKEN
    FOR EACH ROW
    BEGIN
        DECLARE done int;
        DECLARE var_entry_sts char(1);
        DECLARE var_ln_chiku char(20);
        DECLARE var_sub_addr char(4);
        DECLARE var_gouki char(7);
        DECLARE var_jigyou_cd char(6);
        DECLARE cur CURSOR FOR
            select distinct a.ENTRY_STS, a.LN_KB_CHIKU, a.SUB_ADDR, e.GOUKI, b.JISSHI_JIGYOU_CD
            from R_KB_CHIKU a
            inner join R_KEIBI b on a.LN_KEIBI = b.LN_KEIBI
            inner join R_DENKEI_MNG c on b.LN_KEIBI = c.LN_KEIBI
            inner join R_KEIBI_CTL_DEV d on c.LN_KEIBI = d.LN_KEIBI
            inner join R_CTL_DEV e on d.LN_CTL_DEV = e.LN_CTL_DEV
            where b.LN_BUKKEN = new.LN_BUKKEN
            and c.LAST_FLG = '1';
        DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;

        SET done = 0;
        OPEN cur;
        WHILE NOT done DO

            # 警備先地区（R_KB_CHIKU）からLN_警備先地区論理番号とサブアドレスを取得する
            # 警備先（R_KEIBI）から号機番号と実施事業所コードを取得する
            FETCH cur INTO var_entry_sts,var_ln_chiku,var_sub_addr,var_gouki,var_jigyou_cd;

            # LN_警備先地区論理番号を取得できた場合
            IF NOT done THEN

                # 警備先地区同期キュー登録プロシージャ
                CALL SYNC_CHIKU
                (
                    '1',
                    var_entry_sts,
                    var_ln_chiku,
                    var_gouki,
                    var_sub_addr,
                    var_jigyou_cd,
                    new.UPDATE_ID,
                    new.UPDATE_NM,
                    'TRIGGER.insert_r_bukken'
                );
                
            END IF;
        END WHILE;
        CLOSE cur;
    END;
    //
    delimiter ;
