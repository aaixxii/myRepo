###############################################################################
#
#   設置機器(R_DEV)インサート時トリガ
#
#   2018.05.15  NEC Fujita  次期警備用に新規作成
#
###############################################################################
DROP TRIGGER IF EXISTS TG_R_DEV_AF_INS;

    delimiter //
    CREATE TRIGGER TG_R_DEV_AF_INS AFTER INSERT ON R_DEV
    FOR EACH ROW
    BEGIN
        DECLARE var_entry_sts char(1);
        DECLARE var_ln_chiku char(20);
        DECLARE var_gouki char(7);
        
        # SD_装置番号がLPかRFの場合
        IF substring(new.SD_DEV_NUM,7,2) = 'LP'
        OR substring(new.SD_DEV_NUM,7,2) = 'RF' THEN
        
            select a.ENTRY_STS, a.LN_KB_CHIKU, f.GOUKI
            into var_entry_sts, var_ln_chiku, var_gouki
            from R_KB_CHIKU a
            inner join R_KEIBI b on a.LN_KEIBI = b.LN_KEIBI
            inner join R_BUKKEN c on b.LN_BUKKEN = c.LN_BUKKEN
            inner join R_DENKEI_MNG d on b.LN_KEIBI = d.LN_KEIBI
            inner join R_KEIBI_CTL_DEV e on b.LN_KEIBI = e.LN_KEIBI
            inner join R_CTL_DEV f on e.LN_CTL_DEV = f.LN_CTL_DEV
            where a.LN_KB_CHIKU = new.LN_KB_CHIKU
            and f.LN_DEV = new.LN_DEV
            and d.LAST_FLG = '1'
            and a.ENTRY_STS = '1'
            limit 0,1;

            # LN_警備先地区論理番号を取得できた場合
            IF var_ln_chiku IS NOT NULL AND var_ln_chiku != '' THEN
            
                # 警報任務区分同期キュー登録プロシージャ
                CALL SYNC_NINMU
                (
                    '1',
                    var_entry_sts,
                    var_ln_chiku,
                    var_gouki,
                    new.SD_DEV_NUM,
                    new.UPDATE_ID,
                    new.UPDATE_NM,
                    'TRIGGER.insert_r_dev'
                );

            END IF;
        END IF;
    END;
    //
    delimiter ;
