###############################################################################
#
#   緊急連絡先名簿_救急情報登録(R_KNRN_MEIBO_KYUKYU)インサート時トリガ
#
#   2018.05.15  NEC Fujita  次期警備用に新規作成
#
###############################################################################
DROP TRIGGER IF EXISTS TG_R_KNRN_MEIBO_KYUKYU_AF_INS;

    delimiter //
    CREATE TRIGGER TG_R_KNRN_MEIBO_KYUKYU_AF_INS AFTER INSERT ON R_KNRN_MEIBO_KYUKYU
    FOR EACH ROW
    BEGIN
        DECLARE done int;
        DECLARE var_entry_sts char(1);
        DECLARE var_ln_chiku char(20);
        DECLARE cur CURSOR FOR
            select a.ENTRY_STS, a.LN_KB_CHIKU
            from R_KB_CHIKU a
            inner join R_KEIBI b on a.LN_KEIBI = b.LN_KEIBI
            inner join R_BUKKEN c on b.LN_BUKKEN = c.LN_BUKKEN
            inner join R_DENKEI_MNG d on b.LN_KEIBI = d.LN_KEIBI
            inner join R_KB_CHIKU_KNRN_MEIBO_KANKEI e on a.LN_KB_CHIKU = e.LN_KB_CHIKU -- 追加
            where e.LN_KB_CHIKU_KNRN_MEIBO_KANKEI = new.LN_KB_CHIKU_KNRN_MEIBO_KANKEI
            and d.LAST_FLG = '1'
            and a.ENTRY_STS = '1';
        DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;

        SET done = 0;
        OPEN cur;
        WHILE NOT done DO

            # 警備先地区からLN_警備先地区論理番号を取得する
            FETCH cur INTO var_entry_sts, var_ln_chiku;

            # LN_警備先地区論理番号を取得できた場合
            IF NOT done THEN

                # 緊連先名簿同期キュー登録プロシージャ
                CALL SYNC_MEIBO
                (
                    '1',
                    var_entry_sts,
                    var_ln_chiku,
                    '',
                    new.UPDATE_ID,
                    new.UPDATE_NM,
                    'TRIGGER.insert_r_knrn_meibo_kyukyu'
                );

            END IF;
        END WHILE;
        CLOSE cur;
    END;
    //
    delimiter ;
