###############################################################################
#
#   R_警備先地区(R_KB_CHIKU)インサート時トリガ
#
#   2018.05.15  NEC Fujita  次期警備用に新規作成
#   2019.03.18  NEC Kanazu  地区論理番号より号機番号取得するSQLに変更
#
###############################################################################
DROP TRIGGER IF EXISTS TG_R_KB_CHIKU_AF_INS;

    delimiter //
    CREATE TRIGGER TG_R_KB_CHIKU_AF_INS AFTER INSERT ON R_KB_CHIKU
    FOR EACH ROW
    BEGIN
        DECLARE var_ln_keibi char(20);
        DECLARE var_gouki char(7);
        DECLARE var_jigyou_cd char(6);

        # 警備先からLN_警備先論理番号と号機番号と実施事業者コードを取得する
        select a.LN_KEIBI, e.GOUKI, a.JISSHI_JIGYOU_CD
        into var_ln_keibi, var_gouki, var_jigyou_cd
        from R_KEIBI a
        inner join R_BUKKEN b on a.LN_BUKKEN = b.LN_BUKKEN
        inner join R_DENKEI_MNG c on a.LN_KEIBI = c.LN_KEIBI
        inner join R_KEIBI_CTL_DEV d on c.LN_KEIBI = d.LN_KEIBI
        inner join R_CTL_DEV e on d.LN_CTL_DEV = e.LN_CTL_DEV
        where a.LN_KEIBI = new.LN_KEIBI
        and c.LAST_FLG = '1'
        and new.ENTRY_STS = '1'
        limit 0,1;

        # LN_警備先論理番号を取得できた場合
        IF var_ln_keibi IS NOT NULL AND var_ln_keibi != '' THEN

            # 警備先地区同期キュー登録プロシージャ
            CALL SYNC_CHIKU
            (
                '1',
                new.ENTRY_STS,
                new.LN_KB_CHIKU,
                var_gouki,
                new.SUB_ADDR,
                var_jigyou_cd,
                new.UPDATE_ID,
                new.UPDATE_NM,
                'TRIGGER.insert_r_kb_chiku'
            );

        END IF;
    END;
    //
    delimiter ;
