###############################################################################
#
#   警備セット忘れ通知(R_KB_SET_WASURE)アップデート時トリガ
#
#   2019.03.05  NEC Fujita  次期警備用に新規作成
#
###############################################################################
DROP TRIGGER IF EXISTS TG_R_KB_SET_WASURE_AF_UPD; 

DELIMITER // 
CREATE TRIGGER TG_R_KB_SET_WASURE_AF_UPD AFTER UPDATE ON R_KB_SET_WASURE 

FOR EACH ROW BEGIN 

	DECLARE VAR_LN_BUKKEN CHAR (20); 
	DECLARE VAR_LN_KB_CHIKU CHAR (20); 

	#更新した警備セット忘れのデータ、紐づく[警備先.LN_物件論理番号]、[警備先地区.LN_警備先地区論理番号]を取得
	SELECT
		KEIBI.LN_BUKKEN
	  , CHIKU.LN_KB_CHIKU
	INTO VAR_LN_BUKKEN, VAR_LN_KB_CHIKU
	FROM
	  R_KB_CHIKU CHIKU
	  INNER JOIN R_KEIBI KEIBI ON KEIBI.LN_KEIBI = CHIKU.LN_KEIBI
	WHERE
	  CHIKU.PATH_INF = new.PATH_INF
	  AND CHIKU.DEL_FLG = 0
	  AND KEIBI.DEL_FLG = 0;

	# [警備先.LN_物件論理番号]、[警備先地区.LN_警備先地区論理番号]を取得できた場合 
	IF VAR_LN_BUKKEN IS NOT NULL AND VAR_LN_BUKKEN != '' THEN 
		IF VAR_LN_KB_CHIKU IS NOT NULL AND VAR_LN_KB_CHIKU != '' THEN

			UPDATE R_AUTO_TAIKAN_KBSET
			SET
			  YOUBI_CD = NEW.YOUBI_CD
			  , TAIKAN_TM = NEW.TAIKAN_TIME
			  , DEL_FLG = NEW.DEL_FLG
			  , UPDATE_ID = 'TRIGGER'
			  , UPDATE_NM = 'TRIGGER.update_r_kb_set_wasure'
			  , UPDATE_TS = NOW() 
			WHERE
			  YOUBI_CD = OLD.YOUBI_CD
			  AND TAIKAN_TM = OLD.TAIKAN_TIME
			  AND DEL_FLG = OLD.DEL_FLG
			  AND LN_BUKKEN = VAR_LN_BUKKEN
			  AND LN_KB_CHIKU = VAR_LN_KB_CHIKU;

		END IF; 
	END IF; 

END; 
//
DELIMITER ;
