###############################################################################
#
#   設置機器(R_DEV)アップデート時トリガ
#
#   2018.05.15  NEC Fujita  次期警備用に新規作成
#
###############################################################################
DROP TRIGGER IF EXISTS TG_R_DEV_AF_UPD;

    delimiter //
    CREATE TRIGGER TG_R_DEV_AF_UPD AFTER UPDATE ON R_DEV
    FOR EACH ROW
    BEGIN
        DECLARE var_entry_sts char(1);
        DECLARE var_ln_chiku char(20);
        DECLARE var_gouki char(7);


        # 削除フラグが設定された場合
        IF new.DEL_FLG = '1' THEN

            # SD_装置番号がLPかRFの場合
            IF substring(old.SD_DEV_NUM,7,2) = 'LP'
            OR substring(old.SD_DEV_NUM,7,2) = 'RF' THEN

                select a.ENTRY_STS, a.LN_KB_CHIKU, f.GOUKI
                into var_entry_sts, var_ln_chiku, var_gouki
                from R_KB_CHIKU a
                inner join R_KEIBI b on a.LN_KEIBI = b.LN_KEIBI
                inner join R_BUKKEN c on b.LN_BUKKEN = c.LN_BUKKEN
                inner join R_DENKEI_MNG d on b.LN_KEIBI = d.LN_KEIBI
                inner join R_KEIBI_CTL_DEV e on e.LN_KEIBI = b.LN_KEIBI
                inner join R_CTL_DEV f on e.LN_CTL_DEV = f.LN_CTL_DEV
                where a.LN_KB_CHIKU = old.LN_KB_CHIKU
                and d.LAST_FLG = '1'
                and a.ENTRY_STS = '1'
                limit 0,1;

                # LN_警備先地区論理番号を取得できた場合
                IF var_ln_chiku IS NOT NULL AND var_ln_chiku != '' THEN

                    # 警報任務区分同期キュー登録プロシージャ
                    CALL SYNC_NINMU
                    (
                        '3',
                        var_entry_sts,
                        var_ln_chiku,
                        var_gouki,
                        old.SD_DEV_NUM,
                        '',
                        '',
                        'TRIGGER.delete_r_dev'
                    );

                END IF;
            END IF;

        ELSE

            # SD_装置番号がLPかRFの場合
            IF substring(new.SD_DEV_NUM,7,2) = 'LP'
            OR substring(new.SD_DEV_NUM,7,2) = 'RF'
            OR substring(old.SD_DEV_NUM,7,2) = 'LP'
            OR substring(old.SD_DEV_NUM,7,2) = 'RF' THEN

                select a.ENTRY_STS, a.LN_KB_CHIKU, f.GOUKI
                into var_entry_sts, var_ln_chiku, var_gouki
                from R_KB_CHIKU a
                inner join R_KEIBI b on a.LN_KEIBI = b.LN_KEIBI
                inner join R_BUKKEN c on b.LN_BUKKEN = c.LN_BUKKEN
                inner join R_DENKEI_MNG d on b.LN_KEIBI = d.LN_KEIBI
                inner join R_KEIBI_CTL_DEV e on b.LN_KEIBI = e.LN_KEIBI
                inner join R_CTL_DEV f on e.LN_CTL_DEV = f.LN_CTL_DEV
                where a.LN_KB_CHIKU = new.LN_KB_CHIKU
                and f.LN_DEV = new.LN_DEV
                and d.LAST_FLG = '1'
                and a.ENTRY_STS = '1'
                limit 0,1;

                # LN_警備先地区論理番号を取得できた場合
                IF var_ln_chiku IS NOT NULL AND var_ln_chiku != '' THEN

                    # SD_装置番号が更新された場合
                    IF new.SD_DEV_NUM != old.SD_DEV_NUM THEN

                        # SD_装置番号の変更前がLPかRFの場合
                        IF substring(old.SD_DEV_NUM,7,2) = 'LP'
                        OR substring(old.SD_DEV_NUM,7,2) = 'RF' THEN

                            # 警報任務区分同期キュー登録プロシージャ
                            CALL SYNC_NINMU
                            (
                                '3',
                                var_entry_sts,
                                var_ln_chiku,
                                var_gouki,
                                old.SD_DEV_NUM,
                                old.UPDATE_ID,
                                old.UPDATE_NM,
                                'TRIGGER.update_r_dev'
                            );

                        END IF;

                        # SD_装置番号の変更後がLPかRFの場合
                        IF substring(new.SD_DEV_NUM,7,2) = 'LP'
                        OR substring(new.SD_DEV_NUM,7,2) = 'RF' THEN

                            # 警報任務区分同期キュー登録プロシージャ
                            CALL SYNC_NINMU
                            (
                                '1',
                                var_entry_sts,
                                var_ln_chiku,
                                var_gouki,
                                new.SD_DEV_NUM,
                                new.UPDATE_ID,
                                new.UPDATE_NM,
                                'TRIGGER.update_r_dev'
                            );

                        END IF;

                    ELSE

                        # 装置名称、警報種別が更新された場合
                        IF ifnull(new.SD_DEV_NM,' ') != ifnull(old.SD_DEV_NM,' ')
                        OR ifnull(new.SD_KEIBI_KIND,' ') != ifnull(old.SD_KEIBI_KIND,' ') THEN

                            # 警報任務区分同期キュー登録プロシージャ
                            CALL SYNC_NINMU
                            (
                                '2',
                                var_entry_sts,
                                var_ln_chiku,
                                var_gouki,
                                new.SD_DEV_NUM,
                                new.UPDATE_ID,
                                new.UPDATE_NM,
                                'TRIGGER.update_r_dev'
                            );

                        END IF;
                    END IF;
                END IF;
            END IF;

        END IF;
    END;
    //
    delimiter ;
