###############################################################################
#
#   警備先(R_KEIBI)アップデート時トリガ
#
#   2018.05.15  NEC Fujita  次期警備用に新規作成
#
###############################################################################
DROP TRIGGER IF EXISTS TG_R_KEIBI_AF_UPD;

    delimiter //
    CREATE TRIGGER TG_R_KEIBI_AF_UPD AFTER UPDATE ON R_KEIBI 
    FOR EACH ROW 
    BEGIN 

    DECLARE var_seq_que_mst_send char(6);
    DECLARE var_fmt_seq_que_mst_send char(6);
    DECLARE var_ln_que_mst_send char(20);
    DECLARE var_gouki char(7);
    DECLARE done int;
    DECLARE var_old_gc_cd char(4);
    DECLARE var_new_gc_cd char(4);
    DECLARE var_entry_sts char(1);
    DECLARE var_ln_chiku char(20);
    DECLARE var_sub_addr char(4);
    DECLARE var_new_gouki char(7);
    DECLARE var_old_gouki char(7);
    DECLARE cur_new CURSOR FOR
        select a.ENTRY_STS, a.LN_KB_CHIKU, a.SUB_ADDR
        from R_KB_CHIKU a
        cross join R_BUKKEN b
        cross join R_DENKEI_MNG c
        where a.LN_KEIBI = new.LN_KEIBI
        and b.LN_BUKKEN = new.LN_BUKKEN
        and c.LN_KEIBI = new.LN_KEIBI
        and c.LAST_FLG = '1'
        and a.ENTRY_STS = '1';
    DECLARE cur_old CURSOR FOR
        select a.ENTRY_STS, a.LN_KB_CHIKU, a.SUB_ADDR
        from R_KB_CHIKU a
        cross join R_BUKKEN b
        cross join R_DENKEI_MNG c
        where a.LN_KEIBI = old.LN_KEIBI
        and b.LN_BUKKEN = old.LN_BUKKEN
        and c.LN_KEIBI = old.LN_KEIBI
        and c.LAST_FLG = '1'
        and a.ENTRY_STS = '1';
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;

    SELECT 
        dev.GOUKI
    into var_new_gouki
    FROM
        R_KEIBI_CTL_DEV ctl, R_CTL_DEV dev
    WHERE
        ctl.LN_KEIBI = NEW.LN_KEIBI
        and ctl.LN_CTL_DEV = dev.LN_CTL_DEV;

    SELECT 
        dev.GOUKI
    into var_old_gouki
    FROM
        R_KEIBI_CTL_DEV ctl, R_CTL_DEV dev
    WHERE
        ctl.LN_KEIBI = OLD.LN_KEIBI
        and ctl.LN_CTL_DEV = dev.LN_CTL_DEV;

    # LN_物件論理番号が更新された場合
    IF ifnull(new.LN_BUKKEN,' ') != ifnull(old.LN_BUKKEN,' ') THEN

        # 更新前のLN_物件論理番号が取得できた場合
        IF old.LN_BUKKEN IS NOT NULL AND old.LN_BUKKEN != '' THEN

            SET done = 0;
            OPEN cur_old;
            WHILE NOT done DO

                # 警備先地区からLN_警備先地区論理番号とサブアドレスを取得する
                FETCH cur_old INTO var_entry_sts, var_ln_chiku, var_sub_addr;

                # LN_警備先地区論理番号を取得できた場合
                IF NOT done THEN

                    # 警備先地区同期キュー登録プロシージャ
                    CALL SYNC_CHIKU
                    (
                        '3',
                        var_entry_sts,
                        var_ln_chiku,
                        var_old_gouki,
                        var_sub_addr,
                        old.JISSHI_JIGYOU_CD,
                        new.UPDATE_ID,
                        new.UPDATE_NM,
                        'TRIGGER.update_r_keibi'
                    );

                END IF;
            END WHILE;
            CLOSE cur_old;
        END IF;

        # 更新後のLN_物件論理番号が取得できた場合
        IF new.LN_BUKKEN IS NOT NULL AND new.LN_BUKKEN != '' THEN

            SET done = 0;
            OPEN cur_new;
            WHILE NOT done DO

                # 警備先地区からLN_警備先地区論理番号とサブアドレスを取得する
                FETCH cur_new INTO var_entry_sts, var_ln_chiku, var_sub_addr;

                # LN_警備先地区論理番号を取得できた場合
                IF NOT done THEN

                    # 警備先地区同期キュー登録プロシージャ
                    CALL SYNC_CHIKU
                    (
                        '1',
                        var_entry_sts,
                        var_ln_chiku,
                        var_new_gouki,
                        var_sub_addr,
                        new.JISSHI_JIGYOU_CD,
                        new.UPDATE_ID,
                        new.UPDATE_NM,
                        'TRIGGER.update_r_keibi'
                    );

                END IF;
            END WHILE;
            CLOSE cur_new;
        END IF;

    # LN_物件論理番号以外の項目が更新された場合
    ELSE

        # 実施事業者コードが変更された場合
        IF new.JISSHI_JIGYOU_CD != old.JISSHI_JIGYOU_CD THEN

            # 変更前と更新後のGCコードを取得する
            select a.GC_CD, b.GC_CD
            into var_old_gc_cd, var_new_gc_cd
            from commondb.K_GC a
            cross join commondb.K_GC b
            inner join commondb.K_JIGYOU c on a.GC_CD = c.GC_CD
            inner join commondb.K_JIGYOU d on b.GC_CD = d.GC_CD
            where c.JIGYOU_CD = old.JISSHI_JIGYOU_CD
            and d.JIGYOU_CD = new.JISSHI_JIGYOU_CD;

            # 更新前と更新後のGCコードが異なる場合
            IF var_old_gc_cd != var_new_gc_cd THEN

                SET done = 0;
                OPEN cur_new;
                WHILE NOT done DO

                    # R_警備先地区からLN_警備先地区論理番号とサブアドレスを取得する
                    FETCH cur_new INTO var_entry_sts, var_ln_chiku, var_sub_addr;

                    # LN_警備先地区論理番号を取得できた場合
                    IF NOT done THEN

                        # 警備先地区同期キュー登録プロシージャ
                        CALL SYNC_CHIKU
                        (
                            '3',
                            var_entry_sts,
                            var_ln_chiku,
                            var_old_gouki,
                            var_sub_addr,
                            old.JISSHI_JIGYOU_CD,
                            new.UPDATE_ID,
                            new.UPDATE_NM,
                            'TRIGGER.update_r_keibi'
                        );

                        # 警備先地区同期キュー登録プロシージャ
                        CALL SYNC_CHIKU
                        (
                            '1',
                            var_entry_sts,
                            var_ln_chiku,
                            var_new_gouki,
                            var_sub_addr,
                            new.JISSHI_JIGYOU_CD,
                            new.UPDATE_ID,
                            new.UPDATE_NM,
                            'TRIGGER.update_r_keibi'
                        );

                    END IF;
                END WHILE;
                CLOSE cur_new;
            END IF;
        END IF;

        # 警備先地区の同期対象の項目が更新された場合
        IF var_new_gouki != var_old_gouki THEN

            SET done = 0;
            OPEN cur_new;
            WHILE NOT done DO

                # R_警備先地区からLN_警備先地区論理番号とサブアドレスを取得する
                FETCH cur_new INTO var_entry_sts, var_ln_chiku, var_sub_addr;

                # LN_警備先地区論理番号を取得できた場合
                IF NOT done THEN

                    # 警備先地区同期キュー登録プロシージャ
                    CALL SYNC_CHIKU
                    (
                        '3',
                        var_entry_sts,
                        var_ln_chiku,
                        var_old_gouki,
                        var_sub_addr,
                        old.JISSHI_JIGYOU_CD,
                        new.UPDATE_ID,
                        new.UPDATE_NM,
                        'TRIGGER.update_r_keibi'
                    );

                    # 警備先地区同期キュー登録プロシージャ
                    CALL SYNC_CHIKU
                    (
                        '1',
                        var_entry_sts,
                        var_ln_chiku,
                        var_new_gouki,
                        var_sub_addr,
                        new.JISSHI_JIGYOU_CD,
                        new.UPDATE_ID,
                        new.UPDATE_NM,
                        'TRIGGER.update_r_keibi'
                    );

                END IF;
            END WHILE;
            CLOSE cur_new;
        END IF;

        # 警備先地区の同期対象の項目が更新された場合
        IF new.KEIBI_NAME1 != old.KEIBI_NAME1 -- 警備先名称→警備先名１
        OR new.AREA_CD != old.AREA_CD
        OR new.JISSHI_JIGYOU_CD != old.JISSHI_JIGYOU_CD
        OR ifnull(new.KEIBI_ADDR_1,' ') != ifnull(old.KEIBI_ADDR_1,' ') THEN -- 警備先住所→警備先住所１

            SET done = 0;
            OPEN cur_new;
            WHILE NOT done DO

                # R_警備先地区からLN_警備先地区論理番号とサブアドレスを取得する
                FETCH cur_new INTO var_entry_sts, var_ln_chiku, var_sub_addr;

                # LN_警備先地区論理番号を取得できた場合
                IF NOT done THEN

                    # 警備先地区同期キュー登録プロシージャ
                    CALL SYNC_CHIKU
                    (
                        '2',
                        var_entry_sts,
                        var_ln_chiku,
                        var_new_gouki,
                        var_sub_addr,
                        new.JISSHI_JIGYOU_CD,
                        new.UPDATE_ID,
                        new.UPDATE_NM,
                        'TRIGGER.update_r_keibi'
                    );

                END IF;
            END WHILE;
            CLOSE cur_new;
        END IF;

        # 緊急連絡先の同期対象の項目が更新された場合
        IF new.JUCHU_JIGYOU_CD != old.JUCHU_JIGYOU_CD THEN

            SET done = 0;
            OPEN cur_new;
            WHILE NOT done DO

                # R_警備先地区からLN_警備先地区論理番号とサブアドレスを取得する
                FETCH cur_new INTO var_entry_sts, var_ln_chiku, var_sub_addr;

                # LN_警備先地区論理番号を取得できた場合
                IF NOT done THEN

                    # 緊急連絡先同期キュー登録プロシージャ
                    CALL SYNC_KINREN
                    (
                        '2',
                        var_entry_sts,
                        var_ln_chiku,
                        'A',
                        new.UPDATE_ID,
                        new.UPDATE_NM,
                        'TRIGGER.update_r_keibi'
                    );

                END IF;
            END WHILE;
            CLOSE cur_new;
        END IF;

        # メイン警備先地区のみの同期対象の項目が更新された場合
        IF ifnull(new.KEIBI_TEL_NUM,' ') != ifnull(old.KEIBI_TEL_NUM,' ') THEN

            SET done = 0;
            OPEN cur_new;
            WHILE NOT done DO

                # R_警備先地区からLN_警備先地区論理番号とサブアドレスを取得する
                FETCH cur_new INTO var_entry_sts, var_ln_chiku, var_sub_addr;

                # LN_警備先地区論理番号を取得できた場合
                IF NOT done THEN

                    # サブアドレスがメイン地区のものである場合
                    IF var_sub_addr = '    ' THEN

                        # 警備先地区同期キュー登録プロシージャ
                        CALL SYNC_CHIKU
                        (
                            '2',
                            var_entry_sts,
                            var_ln_chiku,
                            var_new_gouki,
                            var_sub_addr,
                            new.JISSHI_JIGYOU_CD,
                            new.UPDATE_ID,
                            new.UPDATE_NM,
                            'TRIGGER.update_r_keibi'
                        );

                    END IF;

                END IF;

            END WHILE;
            CLOSE cur_new;
        END IF;


    END IF;

    END;//
    delimiter ;
