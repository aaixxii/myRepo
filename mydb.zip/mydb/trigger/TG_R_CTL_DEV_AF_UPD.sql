###############################################################################
#
#   制御装置(R_CTL_DEV)アップデート時トリガ
#
#   2018.05.15  NEC Fujita  次期警備用に新規作成
#
###############################################################################
DROP TRIGGER IF EXISTS TG_R_CTL_DEV_AF_UPD;

    delimiter //
    CREATE TRIGGER TG_R_CTL_DEV_AF_UPD AFTER UPDATE ON R_CTL_DEV 
    FOR EACH ROW 
    BEGIN 

    DECLARE var_seq_que_mst_send char(6);
    DECLARE var_fmt_seq_que_mst_send char(6);
    DECLARE var_ln_que_mst_send char(20);
    DECLARE var_sd_line_kind char(1);
    DECLARE var_serial_num char(15);
    DECLARE done int;
    DECLARE var_entry_sts char(1);
    DECLARE var_ln_chiku char(20);
    DECLARE var_sub_addr char(4);
    DECLARE var_jigyou_cd char(6);
    DECLARE var_flg_gshs char(1);
    DECLARE cur CURSOR FOR
        select a.ENTRY_STS, a.LN_KB_CHIKU, a.SUB_ADDR, b.JISSHI_JIGYOU_CD, b.GSHS_FLG
        from R_KB_CHIKU a
        inner join R_KEIBI b on a.LN_KEIBI = b.LN_KEIBI
        inner join R_BUKKEN c on b.LN_BUKKEN = c.LN_BUKKEN
        inner join R_DENKEI_MNG d on b.LN_KEIBI = d.LN_KEIBI
        inner join R_KEIBI_CTL_DEV e on b.LN_KEIBI = e.LN_KEIBI
        inner join R_CTL_DEV f on e.LN_CTL_DEV = f.LN_CTL_DEV
        inner join R_DEV g on f.LN_DEV = g.LN_DEV and a.LN_KB_CHIKU = g.LN_KB_CHIKU
        where e.LN_CTL_DEV = new.LN_CTL_DEV
        and d.LAST_FLG = '1'
        and a.ENTRY_STS = '1';
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;

    # 削除フラグが設定された場合
    IF new.DEL_FLG = '1' THEN

        SET done = 0;
        OPEN cur;
        WHILE NOT done DO

            # 警備先地区からLN_警備先地区論理番号を取得する
            FETCH cur INTO var_entry_sts,var_ln_chiku,var_sub_addr,var_jigyou_cd;

            # LN_警備先地区論理番号を取得できた場合
            IF NOT done THEN

                # 警報任務区分同期キュー登録プロシージャ
                CALL SYNC_NINMU
                (
                    '3',
                    var_entry_sts,
                    var_ln_chiku,
                    old.GOUKI,
                    '',
                    '',
                    '',
                    'TRIGGER.delete_r_ctl_dev'
                );

                # 制御装置.SD_回線種別が未設定ではなかった場合
                IF OLD.SD_LINE_KIND<>'' AND OLD.SD_LINE_KIND IS NOT null THEN

                    # 警備先地区同期キュー登録プロシージャ
                    CALL SYNC_CHIKU
                    (
                        '2',
                        var_entry_sts,
                        var_ln_chiku,
                        old.GOUKI,
                        var_sub_addr,
                        var_jigyou_cd,
                        old.UPDATE_ID,
                        old.UPDATE_NM,
                        'TRIGGER.delete_r_ctl_dev'
                    );
                END IF;
            END IF;
        END WHILE;
        CLOSE cur;

    ELSE

        # SD_回線種別が更新された場合
        IF ifnull(new.SD_LINE_KIND,' ') != ifnull(old.SD_LINE_KIND,' ') THEN

            SET done = 0;
            OPEN cur;
            WHILE NOT done DO

                # 警備先地区からLN_警備先地区論理番号を取得する
                FETCH cur INTO var_entry_sts,var_ln_chiku,var_sub_addr,var_jigyou_cd,var_flg_gshs;

                # LN_警備先地区論理番号を取得できた場合
                IF NOT done THEN

                    # 警報任務区分同期キュー登録プロシージャ
                    CALL SYNC_NINMU
                    (
                        '2',
                        var_entry_sts,
                        var_ln_chiku,
                        new.GOUKI,
                        '',
                        new.UPDATE_ID,
                        new.UPDATE_NM,
                        'TRIGGER.update_r_ctl_dev'
                    );

                    # GS,GSMの機種を更新する場合
                    IF ( var_flg_gshs IN ('0','2') ) 
                    AND (( (old.SD_LINE_KIND NOT IN ('1','2','3','4','5','6') OR old.SD_LINE_KIND IS NULL) AND new.SD_LINE_KIND IN ('1','2','3','4','5','6') )
                      OR ( old.SD_LINE_KIND IN ('1','2','4','5') AND (new.SD_LINE_KIND NOT IN ('1','2','4','5') OR new.SD_LINE_KIND IS NULL) )
                      OR ( old.SD_LINE_KIND IN ('3','6') AND (new.SD_LINE_KIND NOT IN ('3','6') OR new.SD_LINE_KIND IS NULL) )
                    ) THEN
                        # 警備先地区同期キュー登録プロシージャ
                        CALL SYNC_CHIKU
                        (
                            '2',
                            var_entry_sts,
                            var_ln_chiku,
                            new.GOUKI,
                            var_sub_addr,
                            var_jigyou_cd,
                            new.UPDATE_ID,
                            new.UPDATE_NM,
                            'TRIGGER.update_r_ctl_dev'
                        );
                    END IF;
                END IF;
            END WHILE;
            CLOSE cur;
        END IF;

        # 警備先地区の同期対象の項目が更新された場合
        IF new.GOUKI != old.GOUKI THEN

            SET done = 0;
            OPEN cur;
            WHILE NOT done DO

                # 警備先地区からLN_警備先地区論理番号を取得する
                FETCH cur INTO var_entry_sts,var_ln_chiku,var_sub_addr,var_jigyou_cd,var_flg_gshs;

                # LN_警備先地区論理番号を取得できた場合
                IF NOT done THEN

                    # 警備先地区同期キュー登録プロシージャ
                    CALL SYNC_CHIKU
                    (
                        '3',
                        var_entry_sts,
                        var_ln_chiku,
                        old.GOUKI,
                        var_sub_addr,
                        var_jigyou_cd,
                        new.UPDATE_ID,
                        new.UPDATE_NM,
                        'TRIGGER.update_r_ctl_dev'
                    );

                    # 警備先地区同期キュー登録プロシージャ
                    CALL SYNC_CHIKU
                    (
                        '1',
                        var_entry_sts,
                        var_ln_chiku,
                        new.GOUKI,
                        var_sub_addr,
                        var_jigyou_cd,
                        new.UPDATE_ID,
                        new.UPDATE_NM,
                        'TRIGGER.update_r_keibi'
                    );
                END IF;

            END WHILE;
            CLOSE cur;

        END IF;

    END IF;

###############################################################################
#   2018.05.15  GCデータ連携用の処理を追加  END
###############################################################################
    END;//
    delimiter ;
