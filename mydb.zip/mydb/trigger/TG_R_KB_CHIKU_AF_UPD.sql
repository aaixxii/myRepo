###############################################################################
#
#   R_警備先地区(R_KB_CHIKU)アップデート時トリガ
#
#   2018.05.15  NEC Fujita  次期警備用に新規作成
#   2019.03.18  NEC Kanazu  地区論理番号より号機番号取得するSQLに変更
#
###############################################################################
DROP TRIGGER IF EXISTS TG_R_KB_CHIKU_AF_UPD;

    delimiter //
    CREATE TRIGGER TG_R_KB_CHIKU_AF_UPD AFTER UPDATE ON R_KB_CHIKU
    FOR EACH ROW
    BEGIN
        DECLARE var_ln_keibi char(20);
        DECLARE var_gouki char(7);
        DECLARE var_jigyou_cd char(6);
        DECLARE var_meibo_upd_user_kind char(1);
        DECLARE var_id_update char(20);
        DECLARE var_update_nm char(80);
        
        # 削除フラグが設定された場合
        IF new.DEL_FLG = '1' THEN
            
            # 警備先からLN_警備先論理番号と号機番号と実施事業者コードを取得する
            select a.LN_KEIBI, e.GOUKI, a.JISSHI_JIGYOU_CD
            into var_ln_keibi, var_gouki, var_jigyou_cd
            from R_KEIBI a
            inner join R_BUKKEN b on a.LN_BUKKEN = b.LN_BUKKEN
            inner join R_DENKEI_MNG c on a.LN_KEIBI = c.LN_KEIBI
            inner join R_KEIBI_CTL_DEV d on c.LN_KEIBI = d.LN_KEIBI
            inner join R_CTL_DEV e on d.LN_CTL_DEV = e.LN_CTL_DEV
            where a.LN_KEIBI = old.LN_KEIBI
            and c.LAST_FLG = '1'
            and old.ENTRY_STS = '1'
            limit 0,1;
            
            # LN_警備先論理番号を取得できた場合
            IF var_ln_keibi IS NOT NULL AND var_ln_keibi != '' THEN

                # 警備先地区同期キュー登録プロシージャ
                CALL SYNC_CHIKU
                (
                    '3',
                    old.ENTRY_STS,
                    old.LN_KB_CHIKU,
                    var_gouki,
                    old.SUB_ADDR,
                    var_jigyou_cd,
                    '',
                    '',
                    'TRIGGER.update_r_kb_chiku(del_flg)'
                );

            END IF;
            
        ELSE
            # サブアドレスが更新された場合
            IF new.SUB_ADDR != old.SUB_ADDR THEN

                # 警備先からLN_警備先論理番号と号機番号と実施事業者コードを取得する
                select a.LN_KEIBI, e.GOUKI, a.JISSHI_JIGYOU_CD
                into var_ln_keibi, var_gouki, var_jigyou_cd
                from R_KEIBI a
                inner join R_BUKKEN b on a.LN_BUKKEN = b.LN_BUKKEN
                inner join R_DENKEI_MNG c on a.LN_KEIBI = c.LN_KEIBI
                inner join R_KEIBI_CTL_DEV d on c.LN_KEIBI = d.LN_KEIBI
                inner join R_CTL_DEV e on d.LN_CTL_DEV = e.LN_CTL_DEV
                where a.LN_KEIBI = new.LN_KEIBI
                and c.LAST_FLG = '1'
                and new.ENTRY_STS = '1'
                limit 0,1;

                # LN_警備先論理番号を取得できた場合
                IF var_ln_keibi IS NOT NULL AND var_ln_keibi != '' THEN

                    # 警備先地区同期キュー登録プロシージャ
                    CALL SYNC_CHIKU
                    (
                        '3',
                        new.ENTRY_STS,
                        new.LN_KB_CHIKU,
                        var_gouki,
                        old.SUB_ADDR,
                        var_jigyou_cd,
                        new.UPDATE_ID,
                        new.UPDATE_NM,
                       'TRIGGER.update_r_kb_chiku'
                    );

                    # 警備先地区同期キュー登録プロシージャ
                    CALL SYNC_CHIKU
                    (
                        '1',
                        new.ENTRY_STS,
                        new.LN_KB_CHIKU,
                        var_gouki,
                        new.SUB_ADDR,
                        var_jigyou_cd,
                        new.UPDATE_ID,
                        new.UPDATE_NM,
                       'TRIGGER.update_r_kb_chiku'
                    );

                END IF;
            END IF;

            # GCにOPKMASTがない間のみ連携する項目(個別名称)が更新された場合
            IF new.SD_KOBETU_NM != old.SD_KOBETU_NM THEN

                # 警備先からLN_警備先論理番号と号機番号と実施事業者コードを取得する
                select a.LN_KEIBI, e.GOUKI, a.JISSHI_JIGYOU_CD
                into var_ln_keibi, var_gouki, var_jigyou_cd
                from R_KEIBI a
                inner join R_BUKKEN b on a.LN_BUKKEN = b.LN_BUKKEN
                inner join R_DENKEI_MNG c on a.LN_KEIBI = c.LN_KEIBI
                inner join R_KEIBI_CTL_DEV d on c.LN_KEIBI = d.LN_KEIBI
                inner join R_CTL_DEV e on d.LN_CTL_DEV = e.LN_CTL_DEV
                where a.LN_KEIBI = new.LN_KEIBI
                and c.LAST_FLG = '1'
                and new.ENTRY_STS = '1'
                limit 0,1;

                # LN_警備先論理番号を取得できた場合
                IF var_ln_keibi IS NOT NULL AND var_ln_keibi != '' THEN

                    # 警備先地区同期キュー登録プロシージャ
                    CALL SYNC_CHIKU
                    (
                        '2',
                        new.ENTRY_STS,
                        new.LN_KB_CHIKU,
                        var_gouki,
                        new.SUB_ADDR,
                        var_jigyou_cd,
                        new.UPDATE_ID,
                        new.UPDATE_NM,
                       'TRIGGER.GC_Unapproved.update_r_kb_chiku'
                    );

                END IF;
            END IF;

            # 登録状態が「0(未登録)⇒1(登録)」に更新された場合
            IF old.ENTRY_STS = '0' AND new.ENTRY_STS = '1' THEN

                # 警備先からLN_警備先論理番号と号機番号と実施事業者コードを取得する
                select a.LN_KEIBI, e.GOUKI, a.JISSHI_JIGYOU_CD
                into var_ln_keibi, var_gouki, var_jigyou_cd
                from R_KEIBI a
                inner join R_BUKKEN b on a.LN_BUKKEN = b.LN_BUKKEN
                inner join R_DENKEI_MNG c on a.LN_KEIBI = c.LN_KEIBI
                inner join R_KEIBI_CTL_DEV d on c.LN_KEIBI = d.LN_KEIBI
                inner join R_CTL_DEV e on d.LN_CTL_DEV = e.LN_CTL_DEV
                where a.LN_KEIBI = new.LN_KEIBI
                and c.LAST_FLG = '1'
                limit 0,1;

                # LN_警備先論理番号を取得できた場合
                IF var_ln_keibi IS NOT NULL AND var_ln_keibi != '' THEN

                    # 警備先地区同期キュー登録プロシージャ
                    CALL SYNC_CHIKU
                    (
                        '1',
                        new.ENTRY_STS,
                        new.LN_KB_CHIKU,
                        var_gouki,
                        new.SUB_ADDR,
                        var_jigyou_cd,
                        new.UPDATE_ID,
                        new.UPDATE_NM,
                       'TRIGGER.update_r_kb_chiku'
                    );

                END IF;
            END IF;

            # 登録状態が「2(一時削除)⇒0(未登録)」に更新された場合
            IF old.ENTRY_STS = '2' AND new.ENTRY_STS = '0' THEN

                # 警備先からLN_警備先論理番号と号機番号と実施事業者コードを取得する
                select a.LN_KEIBI, e.GOUKI, a.JISSHI_JIGYOU_CD
                into var_ln_keibi, var_gouki, var_jigyou_cd
                from R_KEIBI a
                inner join R_BUKKEN b on a.LN_BUKKEN = b.LN_BUKKEN
                inner join R_DENKEI_MNG c on a.LN_KEIBI = c.LN_KEIBI
                inner join R_KEIBI_CTL_DEV d on c.LN_KEIBI = d.LN_KEIBI
                inner join R_CTL_DEV e on d.LN_CTL_DEV = e.LN_CTL_DEV
                where a.LN_KEIBI = new.LN_KEIBI
                and c.LAST_FLG = '1'
                limit 0,1;

                # LN_警備先論理番号を取得できた場合
                IF var_ln_keibi IS NOT NULL AND var_ln_keibi != '' THEN

                    # 警備先地区同期キュー登録プロシージャ
                    CALL SYNC_CHIKU
                    (
                        '3',
                        new.ENTRY_STS,
                        new.LN_KB_CHIKU,
                        var_gouki,
                        new.SUB_ADDR,
                        var_jigyou_cd,
                        new.UPDATE_ID,
                        new.UPDATE_NM,
                       'TRIGGER.update_r_kb_chiku'
                    );

                END IF;
            END IF;

            # 登録状態が「2(一時削除)⇒1(登録)」に更新された場合
            IF old.ENTRY_STS = '2' AND new.ENTRY_STS = '1' THEN

                # 警備先からLN_警備先論理番号と号機番号と実施事業者コードを取得する
                select b.LN_KEIBI, g.GOUKI, b.JISSHI_JIGYOU_CD, e.MEIBO_UPD_USER_KIND, e.UPDATE_ID, e.UPDATE_NM
                into var_ln_keibi, var_gouki, var_jigyou_cd, var_meibo_upd_user_kind, var_id_update, var_update_nm
                from R_KB_CHIKU a
                inner join R_KEIBI b on a.LN_KEIBI = b.LN_KEIBI
                inner join R_BUKKEN c on b.LN_BUKKEN = c.LN_BUKKEN
                inner join R_DENKEI_MNG d on b.LN_KEIBI = d.LN_KEIBI
                left  join R_KNRN_MEIBO_DOKYO e on a.LN_KB_CHIKU = e.LN_KB_CHIKU
                inner join R_KEIBI_CTL_DEV f on d.LN_KEIBI = f.LN_KEIBI
                inner join R_CTL_DEV g on f.LN_CTL_DEV = g.LN_CTL_DEV
                where a.LN_KB_CHIKU = new.LN_KB_CHIKU
                and d.LAST_FLG = '1'
                limit 0,1;
                # LN_警備先論理番号を取得できた場合
                IF var_ln_keibi IS NOT NULL AND var_ln_keibi != '' THEN

                    # 警備先地区同期キュー登録プロシージャ
                    CALL SYNC_CHIKU
                    (
                        '2',
                        new.ENTRY_STS,
                        new.LN_KB_CHIKU,
                        var_gouki,
                        new.SUB_ADDR,
                        var_jigyou_cd,
                        new.UPDATE_ID,
                        new.UPDATE_NM,
                       'TRIGGER.update_r_kb_chiku'
                    );

                    # R_KNRN_MEIBO_DOKYOが取得できた場合のみ、下記の処理を行う
                    IF var_meibo_upd_user_kind IS NOT NULL and var_meibo_upd_user_kind != '' THEN

                        # 緊急連絡先同期キュー登録プロシージャ
                        CALL SYNC_KINREN
                        (
                            '2',
                            new.ENTRY_STS,
                            new.LN_KB_CHIKU,
                            var_meibo_upd_user_kind,
                            var_id_update,
                            var_update_nm,
                            'TRIGGER.update_r_kb_chiku'
                        );

                        # 緊連先名簿同期キュー登録プロシージャ
                        CALL SYNC_MEIBO
                        (
                            '2',
                            new.ENTRY_STS,
                            new.LN_KB_CHIKU,
                            var_meibo_upd_user_kind,
                            var_id_update,
                            var_update_nm,
                            'TRIGGER.update_r_kb_chiku'
                        );

                        # 警報任務区分同期キュー登録プロシージャ
                        CALL SYNC_NINMU
                        (
                            '2',
                            new.ENTRY_STS,
                            new.LN_KB_CHIKU,
                            var_gouki,
                            '',
                            new.UPDATE_ID,
                            new.UPDATE_NM,
                            'TRIGGER.update_r_kb_chiku'
                        );
                    END IF;
                END IF;
            END IF;
        END IF;
    END;
    //
    delimiter ;
