###############################################################################
#
#   画像コマンドキュー(ワーク)(W_QUE_IMG_CMD)アップデート時トリガ
#
#   2019.02.14  NEC   次期警備用に新規作成
#
###############################################################################
DROP TRIGGER IF EXISTS TG_W_QUE_IMG_CMD_UPD;

    DELIMITER //
    CREATE TRIGGER TG_W_QUE_IMG_CMD_UPD AFTER UPDATE ON C_QUE_IMG_CMD 
    FOR EACH ROW
    BEGIN
        IF NEW.STS = '1' THEN
            #状態が'1'の場合：画像コマンドキュー(ワーク).リクエスト送信開始日時の設定

            UPDATE W_QUE_IMG_CMD
            SET REQUEST_SENT_TS = NOW(),
                UPDATE_ID = 'TG_W_QUE_IMG_CMD_UPD',
                UPDATE_NM = 'TG_W_QUE_IMG_CMD_UPD',
                UPDATE_TS = NOW()
            WHERE LN_QUE_IMG_CMD = NEW.LN_QUE_IMG_CMD;

        ELSEIF NEW.STS = 'S' OR NEW.STS = 'E' OR NEW.STS = 'T' THEN
            #状態が'S'、'E'、'T'の場合：画像コマンドキュー(ワーク)のレコード削除

            DELETE FROM W_QUE_IMG_CMD
            WHERE LN_QUE_IMG_CMD = NEW.LN_QUE_IMG_CMD;

        END IF;
    END;
    //
    DELIMITER ;
