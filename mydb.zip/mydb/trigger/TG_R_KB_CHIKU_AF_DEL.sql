###############################################################################
#
#   警備先地区(R_KB_CHIKU)デリート時トリガ
#
#   2018.05.15  NEC Fujita  次期警備用に新規作成
#
###############################################################################
DROP TRIGGER IF EXISTS TG_R_KB_CHIKU_AF_DEL;

    delimiter //
    CREATE TRIGGER TG_R_KB_CHIKU_AF_DEL AFTER DELETE ON R_KB_CHIKU
    FOR EACH ROW
    BEGIN
        DECLARE var_ln_keibi char(20);
        DECLARE var_gouki char(7);
        DECLARE var_jigyou_cd char(6);

        # 警備先からLN_警備先論理番号と号機番号と実施事業者コードを取得する
        select a.LN_KEIBI, e.GOUKI, a.JISSHI_JIGYOU_CD
        into var_ln_keibi, var_gouki, var_jigyou_cd
        from R_KEIBI a
        inner join R_BUKKEN b on a.LN_BUKKEN = b.LN_BUKKEN
        inner join R_DENKEI_MNG c on a.LN_KEIBI = c.LN_KEIBI
        inner join R_KEIBI_CTL_DEV d on c.LN_KEIBI = d.LN_KEIBI
        inner join R_CTL_DEV e on d.LN_CTL_DEV = e.LN_CTL_DEV
        inner join R_DEV f on e.LN_DEV = f.LN_DEV
        where a.LN_KEIBI = old.LN_KEIBI
        and f.LN_KB_CHIKU = old.LN_KB_CHIKU
        and c.LAST_FLG = '1'
        and old.ENTRY_STS = '1';

        # LN_警備先論理番号を取得できた場合
        IF var_ln_keibi IS NOT NULL AND var_ln_keibi != '' THEN

            # 警備先地区同期キュー登録プロシージャ
            CALL SYNC_CHIKU
            (
                '3',
                old.ENTRY_STS,
                old.LN_KB_CHIKU,
                var_gouki,
                old.SUB_ADDR,
                var_jigyou_cd,
                '',
                '',
                'TRIGGER.delete_r_kb_chiku'
            );

        END IF;
    END;
    //
    delimiter ;
