###############################################################################
#
#   警備セット忘れ通知(R_KB_SET_WASURE)インサート時トリガ
#
#   2019.03.05  NEC Fujita  次期警備用に新規作成
#
###############################################################################
DROP TRIGGER IF EXISTS TG_R_KB_SET_WASURE_AF_INS; 

DELIMITER // 
CREATE TRIGGER TG_R_KB_SET_WASURE_AF_INS AFTER INSERT ON R_KB_SET_WASURE 

FOR EACH ROW BEGIN 

	DECLARE VAR_LN_BUKKEN CHAR (20); 
	DECLARE VAR_LN_KB_CHIKU CHAR (20); 
	DECLARE VAR_LN_TAIKAN CHAR (20); 

	#挿入した警備セット忘れのデータ、紐づく[警備先.LN_物件論理番号]、[警備先地区.LN_警備先地区論理番号]を取得
	SELECT
		KEIBI.LN_BUKKEN
	  , CHIKU.LN_KB_CHIKU
	INTO VAR_LN_BUKKEN, VAR_LN_KB_CHIKU
	FROM
	  R_KB_CHIKU CHIKU
	  INNER JOIN R_KEIBI KEIBI ON KEIBI.LN_KEIBI = CHIKU.LN_KEIBI
	WHERE
	  CHIKU.PATH_INF = new.PATH_INF
	  AND CHIKU.DEL_FLG = 0
	  AND KEIBI.DEL_FLG = 0;

	# [警備先.LN_物件論理番号]、[警備先地区.LN_警備先地区論理番号]を取得できた場合 
	IF VAR_LN_BUKKEN IS NOT NULL AND VAR_LN_BUKKEN != '' THEN 
		IF VAR_LN_KB_CHIKU IS NOT NULL AND VAR_LN_KB_CHIKU != '' THEN 		

			# LN_自動退館空室検索実施確認論理番号取得
			CALL GET_SEQUENCE('LN_AUTO_TAIKAN_KBSET', @ln);
			select concat(substring(date_format(now(3),'%Y%m%d%H%i%s%f'),1,17),@ln) into VAR_LN_TAIKAN;

			INSERT INTO R_AUTO_TAIKAN_KBSET 
			VALUES ( 
				 VAR_LN_TAIKAN
				, VAR_LN_BUKKEN
				, VAR_LN_KB_CHIKU
				, '1'
				, new.YOUBI_CD
				, new.TAIKAN_TIME
				, '0'
				, NULL
				, NULL
				, NULL
				, NULL
				, '0'
				, new.DEL_FLG
				, 'TRIGGER'
				, 'TRIGGER.insert_r_kb_set_wasure'
				, NOW()
				, 'TRIGGER'
				, 'TRIGGER.insert_r_kb_set_wasure'
				, NOW()
			);

		END IF; 
	END IF; 

END; 
//
DELIMITER ;
