###############################################################################
#
#   警備先-制御装置連関(R_KEIBI_CTL_DEV)インサート時トリガ
#
#   2019.01.03  NEC kanazu  次期警備用に新規作成
#
###############################################################################
DROP TRIGGER IF EXISTS TG_R_KEIBI_CTL_DEV_AF_INS;

    delimiter //
    CREATE TRIGGER TG_R_KEIBI_CTL_DEV_AF_INS AFTER INSERT ON R_KEIBI_CTL_DEV 
    FOR EACH ROW 
    BEGIN 

    DECLARE var_seq_que_mst_send char(6);
    DECLARE var_fmt_seq_que_mst_send char(6);
    DECLARE var_ln_que_mst_send char(20);
    DECLARE var_sd_line_kind char(1);
    DECLARE var_serial_num char(15);
    DECLARE done int;
    DECLARE var_entry_sts char(1);
    DECLARE var_ln_chiku char(20);
    DECLARE var_gouki char(7);
    DECLARE var_sub_addr char(4);
    DECLARE var_jigyou_cd char(6);
    DECLARE var_insert_ts datetime;
    DECLARE cur CURSOR FOR
        select c.ENTRY_STS, c.LN_KB_CHIKU, e.GOUKI, c.SUB_ADDR, b.JISSHI_JIGYOU_CD, c.INSERT_TS
        from R_KEIBI_CTL_DEV a
        inner join R_KEIBI b on a.LN_KEIBI = b.LN_KEIBI
        inner join R_KB_CHIKU c on b.LN_KEIBI = c.LN_KEIBI
        inner join R_DENKEI_MNG d on b.LN_KEIBI = d.LN_KEIBI
        inner join R_CTL_DEV e on a.LN_CTL_DEV = e.LN_CTL_DEV
        where a.LN_CTL_DEV = new.LN_CTL_DEV
          and a.LN_KEIBI = new.LN_KEIBI
          and d.LAST_FLG = '1'
          and c.ENTRY_STS = '1';
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;

    SET done = 0;
    OPEN cur;
    WHILE NOT done DO
    
        # 警備先地区からLN_警備先地区論理番号を取得する
        FETCH cur INTO var_entry_sts,var_ln_chiku,var_gouki,var_sub_addr,var_jigyou_cd,var_insert_ts;

        # LN_警備先地区論理番号を取得できた場合
        IF NOT done THEN
            
            # 警備先-制御装置連関.登録年月日 と 警備地区.登録年月日 が同一の場合
            IF NEW.INSERT_TS = var_insert_ts THEN
                
                # 警備先地区同期キュー登録プロシージャ
                CALL SYNC_CHIKU
                (
                    '1',
                    var_entry_sts,
                    var_ln_chiku,
                    var_gouki,
                    var_sub_addr,
                    var_jigyou_cd,
                    new.UPDATE_ID,
                    new.UPDATE_NM,
                    'TRIGGER.insert_r_keibi_ctl_dev_From_Chiku'
                );
                
            END IF;
            
        END IF;
    END WHILE;
    CLOSE cur;

    END;//
    delimiter ;
