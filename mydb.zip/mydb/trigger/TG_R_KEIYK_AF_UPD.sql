###############################################################################
#
#   契約先(R_KEIYK)アップデート時トリガ
#
#   2018.05.15  NEC Fujita  次期警備用に新規作成
#
###############################################################################
DROP TRIGGER IF EXISTS TG_R_KEIYK_AF_UPD;

    delimiter //
    CREATE TRIGGER TG_R_KEIYK_AF_UPD AFTER UPDATE ON R_KEIYK
    FOR EACH ROW
    BEGIN
        DECLARE done int;
        DECLARE var_entry_sts char(1);
        DECLARE var_ln_chiku char(20);
        DECLARE cur CURSOR FOR
            select a.ENTRY_STS, a.LN_KB_CHIKU
            from R_KB_CHIKU a
            inner join R_KEIBI b on a.LN_KEIBI = b.LN_KEIBI
            inner join R_BUKKEN c on b.LN_BUKKEN = c.LN_BUKKEN
            inner join R_DENKEI_MNG d on b.LN_KEIBI = d.LN_KEIBI
            inner join R_KEIYK_BUKKEN e on c.LN_BUKKEN = e.LN_BUKKEN
            where e.LN_KEIYK = new.LN_KEIYK
            and d.LAST_FLG = '1'
            and a.ENTRY_STS = '1';
        DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;

        # 緊急連絡先の同期対象の項目が更新された場合
        IF new.KEIYK_NM != old.KEIYK_NM
        OR ifnull(new.KEIYK_TEL_NUM,' ') != ifnull(old.KEIYK_TEL_NUM,' ') THEN

            SET done = 0;
            OPEN cur;
            WHILE NOT done DO

                # 警備先地区からLN_警備先地区論理番号を取得する
                FETCH cur INTO var_entry_sts, var_ln_chiku;

                # LN_警備先地区論理番号を取得できた場合
                IF NOT done THEN

                    # 緊急連絡先同期キュー登録プロシージャ
                    CALL SYNC_KINREN
                    (
                        '2',
                        var_entry_sts,
                        var_ln_chiku,
                        'A',
                        new.UPDATE_ID,
                        new.UPDATE_NM,
                        'TRIGGER.update_r_keiyk'
                    );

                END IF;
            END WHILE;
            CLOSE cur;
        END IF;
    END;
    //
    delimiter ;
