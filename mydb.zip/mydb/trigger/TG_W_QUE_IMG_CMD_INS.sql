###############################################################################
#
#   画像コマンドキュー(ワーク)(W_QUE_IMG_CMD)インサート時トリガ
#
#   2019.02.14  NEC   次期警備用に新規作成
#
###############################################################################
DROP TRIGGER IF EXISTS TG_W_QUE_IMG_CMD_INS;

    DELIMITER //
    CREATE TRIGGER TG_W_QUE_IMG_CMD_INS AFTER INSERT ON C_QUE_IMG_CMD 
    FOR EACH ROW
    BEGIN
        DECLARE var_image_req_kbn char(1);      # 画像要求区分
        DECLARE var_start_sts char(1);          # 起動区分
        DECLARE var_ln_dev char(20);            # 設置機器論理番号
        DECLARE var_array_ln_dev mediumtext;    # 設置機器論理番号群
        DECLARE var_same_send_num INTEGER;      # 同時送信数
        DECLARE var_cnt INTEGER;

        IF NEW.IMAGE_REQ_KBN <> '3' THEN
            # 画像要求区分が'3'以外の場合
            CALL SYNC_WQUEIMGCMD
                (
                    NEW.LN_QUE_IMG_CMD,
                    NEW.CTL_ID,
                    NEW.IMAGE_REQ_KBN,
                    '',
                    'TG_W_QUE_IMG_CMD_INS',
                    'TG_W_QUE_IMG_CMD_INS'
                );
        ELSE
            # 画像要求区分が'3'の場合
            # 起動区分の取得
            SELECT LEFT(NEW.REQ_MSG,1) INTO var_start_sts;
            
            IF var_start_sts = '0' THEN
                #バージョンチェックの場合
                SELECT SUBSTR(SUBSTRING_INDEX(NEW.REQ_MSG, ',', 2), 3, 20) INTO var_ln_dev;
                CALL SYNC_WQUEIMGCMD
                    (
                        NEW.LN_QUE_IMG_CMD,
                        '',
                        NEW.IMAGE_REQ_KBN,
                        var_ln_dev,
                        'TG_W_QUE_IMG_CMD_INS',
                        'TG_W_QUE_IMG_CMD_INS'
                    );
            ELSE
                # 登録・削除の場合
                SET var_cnt = 0;
                # 同時送信数の取得
                SELECT CAST(RIGHT(SUBSTRING_INDEX(NEW.REQ_MSG, ',', 5), 1) AS SIGNED) INTO var_same_send_num;
                SELECT RIGHT(NEW.REQ_MSG, LENGTH(NEW.REQ_MSG) - LENGTH(SUBSTRING_INDEX(NEW.REQ_MSG, ',', 5)) - 1) INTO var_array_ln_dev;
                WHILE var_cnt < var_same_send_num DO
                    SELECT SUBSTR(var_array_ln_dev, (var_cnt - 1) * 21 + 1, 20) INTO var_ln_dev;
                CALL SYNC_WQUEIMGCMD
                    (
                        NEW.LN_QUE_IMG_CMD,
                        '',
                        NEW.IMAGE_REQ_KBN,
                        var_ln_dev,
                        'TG_W_QUE_IMG_CMD_INS',
                        'TG_W_QUE_IMG_CMD_INS'
                    );
                    SET var_cnt = var_cnt + 1;
                END WHILE;
            END IF;
        END IF;
    END;
    //
    DELIMITER ;
